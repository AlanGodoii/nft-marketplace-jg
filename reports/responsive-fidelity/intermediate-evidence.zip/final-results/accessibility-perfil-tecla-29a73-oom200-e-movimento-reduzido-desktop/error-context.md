# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> perfil: teclado, foco, zoom200% e movimento reduzido
- Location: tests/accessibility.spec.ts:35:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - link "Pular para o conteúdo" [ref=f1e4] [cursor=pointer]:
    - /url: "#conteudo"
  - banner [ref=f1e5]:
    - generic [ref=f1e6]:
      - link "Kurio — início" [ref=f1e7] [cursor=pointer]:
        - /url: /
        - text: KURIO
      - navigation "Navegação principal" [ref=f1e8]:
        - link "Início" [ref=f1e9] [cursor=pointer]:
          - /url: /
        - link "Mercado" [ref=f1e10] [cursor=pointer]:
          - /url: /#catalogo
        - link "Criadores" [ref=f1e11] [cursor=pointer]:
          - /url: /#criadores
        - link "Aprenda" [ref=f1e12] [cursor=pointer]:
          - /url: /#diario
      - generic [ref=f1e13]:
        - button "Abrir busca do mercado" [ref=f1e14]
        - link "Carrinho, 0 itens" [ref=f1e15] [cursor=pointer]:
          - /url: /carrinho
          - generic [aria-hidden] [ref=f1e21]: "0"
        - group [ref=f1e22]:
          - status "Usuário conectado" [ref=f1e27] [cursor=pointer]: Alice
        - button "Sair" [ref=f1e29]
  - main [ref=f1e30]:
    - status "Conexão em tempo real" [ref=f1e31]: Atualizações ao vivo conectadas.
    - generic [ref=f1e32]:
      - complementary "Meu perfil" [ref=f1e33]:
        - heading "Meu perfil" [level=2] [ref=f1e34]
        - link "Dados do perfil" [ref=f1e35] [cursor=pointer]:
          - /url: /perfil
        - link "Carteiras" [ref=f1e39] [cursor=pointer]:
          - /url: /carteiras
        - link "Meus pedidos" [ref=f1e43] [cursor=pointer]:
          - /url: /pedido/confirmacao
        - link "Lista de interesse" [ref=f1e47] [cursor=pointer]:
          - /url: /favoritos
        - button "Ofertas" [ref=f1e50]
        - button "Arquivos baixados" [ref=f1e54]
        - button "Suporte" [ref=f1e58]
        - button "Sair da conta" [ref=f1e63]: Sair
        - status
      - generic [ref=f1e65]:
        - heading "Perfil do colecionador" [level=1] [ref=f1e67]
        - generic [ref=f1e68]:
          - form "Dados do perfil" [ref=f1e69]:
            - heading "Informações do colecionador" [level=2] [ref=f1e70]
            - generic [ref=f1e71]:
              - generic [ref=f1e72]:
                - generic [ref=f1e73]: Nome de exibição*
                - textbox "Nome de exibição*" [ref=f1e74]: Alice
                - paragraph
              - generic [ref=f1e75]:
                - generic [ref=f1e76]: Nome de usuário
                - textbox "Nome de usuário" [ref=f1e77]
                - paragraph
              - generic [ref=f1e78]:
                - generic [ref=f1e79]: E-mail*
                - textbox "E-mail*" [ref=f1e80]: alice@kurio.test
                - paragraph
            - group [ref=f1e81]:
              - generic "Informações adicionais" [ref=f1e82] [cursor=pointer]
              - generic [ref=f1e83]:
                - generic [ref=f1e84]:
                  - generic [ref=f1e85]: Website
                  - textbox "Website" [ref=f1e86]
                  - paragraph
                - generic [ref=f1e87]:
                  - generic [ref=f1e88]: Biografia
                  - textbox "Biografia" [active] [ref=f1e89]
                  - paragraph
            - button "Salvar perfil" [ref=f1e90]
          - form "Carteira vinculada ao perfil" [ref=f1e91]:
            - generic [ref=f1e92]:
              - generic [ref=f1e93]: Nome ENS*
              - textbox "Nome ENS*" [ref=f1e94]: alice.eth
            - generic [ref=f1e95]:
              - generic [ref=f1e96]: Apelido da carteira*
              - textbox "Apelido da carteira*" [ref=f1e97]: Principal
            - button "Salvar carteira vinculada" [ref=f1e98]
          - region [ref=f1e99]:
            - heading "Avatar" [level=2] [ref=f1e100]
            - img "Nenhum avatar cadastrado" [ref=f1e101]
            - generic [ref=f1e106]: Imagem do avatar
            - button "Imagem do avatar" [ref=f1e107]
            - paragraph [ref=f1e108]: PNG, JPEG ou WebP. Até 256 KiB e 4096×4096 px. SVG não é aceito.
            - alert
            - status
            - button "Alterar" [ref=f1e110]
          - form "Alterar senha" [ref=f1e111]:
            - heading "Alterar senha" [level=2] [ref=f1e112]
            - paragraph [ref=f1e113]: Após salvar, todas as sessões serão encerradas. Entre novamente com a nova senha. Sua coleção e seus pedidos serão preservados.
            - generic [ref=f1e114]:
              - text: Senha atual
              - textbox "Senha atual" [ref=f1e115]
              - paragraph
            - generic [ref=f1e116]:
              - text: Nova senha
              - textbox "Nova senha" [ref=f1e117]
              - paragraph
            - generic [ref=f1e118]:
              - text: Confirmar nova senha
              - textbox "Confirmar nova senha" [ref=f1e119]
              - paragraph
            - button "Alterar senha e sair" [ref=f1e120]
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | import AxeBuilder from '@axe-core/playwright'
  3  | import { add, apiQuote, login, request, reset } from './helpers/market'
  4  | 
  5  | const groups = [
  6  |   ['/', '/nfts/nft-002', '/carrinho'],
  7  |   ['/checkout', '/perfil', '/carteiras'],
  8  |   ['/pedido/confirmacao', '/login', '/cadastro'],
  9  | ]
  10 | for (const width of [390, 768, 1440]) for (const [index, paths] of groups.entries()) {
  11 |   test(`acessibilidade das nove telas em ${width}px grupo${index + 1}`, async ({ page }, testInfo) => {
  12 |     await page.setViewportSize({ width, height: 1000 })
  13 |     await reset(page)
  14 |     await login(page, 'alice', '/perfil')
  15 |     await add(page)
  16 |     for (const path of paths) {
  17 |       if (path === '/pedido/confirmacao') {
  18 |         const { input } = await apiQuote(page)
  19 |         const created = await request(page, '/api/orders', 'POST', input, { 'Idempotency-Key': `a11y-confirmed-${width}` })
  20 |         expect(created.status).toBe(201)
  21 |         await page.goto(`${path}?orderId=${created.body.id}`)
  22 |         await expect(page.getByTestId('order-receipt')).toBeVisible()
  23 |       } else await page.goto(path)
  24 |       await expect(page.getByTestId('realtime-status')).toHaveAttribute('data-transport', 'websocket')
  25 |       await expect(page.locator('[aria-busy="true"]')).toHaveCount(0)
  26 |       await page.evaluate(() => document.fonts.ready)
  27 |       const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze()
  28 |       expect(result.violations, `${path}: ${JSON.stringify(result.violations.map(v => ({ id: v.id, targets: v.nodes.map(n => n.target) })))}`).toEqual([])
  29 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  30 |       await page.screenshot({ path: testInfo.outputPath(`screen-${path.replaceAll('/', '_') || 'home'}-${width}.png`), fullPage: true })
  31 |     }
  32 |   })
  33 | }
  34 | 
  35 | test('perfil: teclado, foco, zoom200% e movimento reduzido', async ({ page }) => {
  36 |   await reset(page); await login(page, 'alice', '/perfil')
  37 |   await page.emulateMedia({ reducedMotion: 'reduce' })
  38 |   await page.getByLabel('Nome de exibição', { exact: true }).focus()
  39 |   await page.keyboard.press('Tab')
  40 |   await expect(page.getByLabel('Nome de usuário', { exact: true })).toBeFocused()
  41 |   await page.getByText('Informações adicionais', { exact: true }).click()
  42 |   await page.getByLabel('Biografia').focus()
  43 |   expect(await page.getByLabel('Biografia').evaluate(node => getComputedStyle(node).outlineStyle)).not.toBe('none')
  44 |   // CSS zoom doubles actual content size in a fixed viewport; check reflow and usable controls.
  45 |   await page.evaluate(() => { document.documentElement.style.zoom = '2' })
> 46 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
     |                                                                                         ^ Error: expect(received).toBe(expected) // Object.is equality
  47 |   await page.getByRole('button', { name: 'Salvar perfil', exact: true }).click()
  48 |   await expect(page.getByText('Perfil atualizado.', { exact: true })).toBeVisible()
  49 |   const duration = await page.locator('.kurio-theme').evaluate(node => getComputedStyle(node).animationDuration)
  50 |   expect(parseFloat(duration)).toBeLessThan(0.01)
  51 | })
  52 | 
```