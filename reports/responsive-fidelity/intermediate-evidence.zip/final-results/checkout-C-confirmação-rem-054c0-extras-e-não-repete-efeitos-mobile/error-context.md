# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: checkout.spec.ts >> C: confirmação remove somente quantidades compradas, preserva extras e não repete efeitos
- Location: tests/checkout.spec.ts:238:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.uncheck: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('checkbox', { name: 'Comprar Neon Vessel #003', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Pular para o conteúdo" [ref=f2e4] [cursor=pointer]:
    - /url: "#conteudo"
  - status "Usuário conectado" [ref=f2e5]: Alice
  - banner [ref=f2e6]:
    - link "Voltar" [ref=f2e7] [cursor=pointer]:
      - /url: /carrinho
    - generic [ref=f2e10]: Pagamento com carteira
    - button "Abrir menu" [ref=f2e11]
  - main [ref=f2e12]:
    - status "Conexão em tempo real" [ref=f2e13]: Atualizações ao vivo conectadas.
    - generic [ref=f2e14]:
      - heading "Checkout" [level=1] [ref=f2e15]
      - link "Voltar ao carrinho" [ref=f2e16] [cursor=pointer]:
        - /url: /carrinho
      - region "Seleção de carteira" [ref=f2e17]:
        - generic [ref=f2e18]:
          - heading "Carteira cadastrada" [level=2] [ref=f2e19]
          - link "Trocar carteira" [ref=f2e20] [cursor=pointer]:
            - /url: /carteiras
        - button "Principal alice.eth Rede ethereum" [pressed] [ref=f2e22]:
          - generic [ref=f2e26]:
            - strong [ref=f2e27]: Principal
            - generic [ref=f2e28]: alice.eth
            - generic [ref=f2e29]: Rede ethereum
        - heading "Carteira e rede" [level=2] [ref=f2e30]
        - generic [ref=f2e31]:
          - button [ref=f2e32]
          - button [pressed] [ref=f2e39]
          - button [ref=f2e47]
      - generic [ref=f2e54]:
        - generic [ref=f2e55]:
          - generic [ref=f2e56]:
            - heading "Carteira e rede" [level=2] [ref=f2e57]
            - paragraph [ref=f2e58]: Principal · metamask · 0x1111111111111111111111111111111111111111
            - text: Rede de pagamento
            - combobox "Rede de pagamento" [ref=f2e59]:
              - option "Ethereum" [selected]
              - option "Polygon"
              - option "Solana"
            - generic [ref=f2e60]:
              - button "Conectar carteira" [ref=f2e61]
              - button "Desconectar carteira" [ref=f2e62]
            - status [ref=f2e63]: Carteira desconectada.
          - form "Dados do pagamento" [ref=f2e64]:
            - heading "Perfil do colecionador" [level=2] [ref=f2e65]
            - group [ref=f2e66]:
              - generic "Dados do colecionador" [ref=f2e67] [cursor=pointer]
            - button "Revalidar e revisar compra" [disabled]
        - complementary [ref=f2e68]:
          - heading "Seus NFTs" [level=2] [ref=f2e69]
          - paragraph [ref=f2e70]: Escolha as edições e quantidades desta compra. Itens não selecionados ficam no carrinho.
          - group [ref=f2e71]:
            - generic "Revisar NFTs e cupom" [ref=f2e72] [cursor=pointer]
          - generic "Valores da compra" [ref=f2e73]:
            - generic [ref=f2e74]:
              - term [ref=f2e75]: Total
              - definition [ref=f2e76]: 0.986000000000000001 ETH
          - paragraph [ref=f2e77]: Estimativa. Revalide antes de confirmar a compra.
```

# Test source

```ts
  145 |   await expect(page.getByText('NFT adicionado ao carrinho.', { exact: false })).toBeVisible()
  146 |   await page.goto('/carrinho')
  147 |   await page.getByRole('link', { name: 'Conectar e finalizar' }).click()
  148 |   await expect(page.getByRole('heading', { name: 'Entrar', exact: true })).toBeVisible()
  149 |   await page.getByLabel('E-mail', { exact: true }).fill('alice@kurio.test')
  150 |   await page.getByLabel('Senha', { exact: true }).fill('Kurio123!')
  151 |   await page.getByRole('button', { name: 'Entrar', exact: true }).click()
  152 |   await expect(page.getByRole('heading', { name: 'Checkout', exact: true })).toBeVisible()
  153 |   await configure(page, { name: 'normal', latencyMs: 10, orderDelayMs: 1800 })
  154 |   await review(page)
  155 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  156 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  157 |   await expect(page.getByTestId('order-receipt')).toHaveCount(0)
  158 |   await expect(page.getByRole('dialog').getByRole('heading', { name: 'Compra confirmada', exact: true })).toBeVisible()
  159 |   await expect(page.getByTestId('order-receipt').getByTestId('checkout-total')).toHaveText('0.306 ETH')
  160 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(1)
  161 |   expect((await request(page, '/api/cart', 'GET')).body.items).toHaveLength(0)
  162 |   await page.reload()
  163 |   await expect(page.getByTestId('order-receipt')).toBeVisible()
  164 | })
  165 | 
  166 | test('C: pagamento recusado preserva carrinho e não apresenta recibo', async ({ page }) => {
  167 |   await login(page)
  168 |   await add(page)
  169 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'rejected', orderDelayMs: 1200 })
  170 |   await review(page)
  171 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  172 |   await expect(page.getByTestId('order-status')).toHaveText('Pagamento recusado')
  173 |   await expect(page.getByRole('alert')).toContainText('carrinho foi preservado')
  174 |   await expect(page.getByTestId('order-receipt')).toHaveCount(0)
  175 |   expect((await request(page, '/api/cart', 'GET')).body.items[0].quantity).toBe(1)
  176 | })
  177 | 
  178 | test('C: mesma chave recupera pedido, conteúdo diferente409 e tentativas concorrentes não duplicam', async ({ page }) => {
  179 |   await login(page)
  180 |   await request(page, '/api/cart/items', 'POST', { nftId: 'nft-002', editionId: 'edition-002', quantity: 1 })
  181 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  182 |   const { input } = await apiQuote(page)
  183 |   const key = 'idempotency-concurrent-001'
  184 |   const results = await Promise.all([request(page, '/api/orders', 'POST', input, { 'Idempotency-Key': key }), request(page, '/api/orders', 'POST', input, { 'Idempotency-Key': key })])
  185 |   expect(results.map(result => result.status).sort()).toEqual([200, 201])
  186 |   expect(results[0].body.id).toBe(results[1].body.id)
  187 |   expect((await request(page, '/api/orders', 'POST', { ...input, quoteId: 'different' }, { 'Idempotency-Key': key })).status).toBe(409)
  188 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(1)
  189 |   await page.goto(`/pedido/confirmacao?orderId=${results[0].body.id}`)
  190 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  191 | })
  192 | 
  193 | test('C: clique repetido de finalizar cria somente um pedido', async ({ page }) => {
  194 |   await login(page); await add(page)
  195 |   await configure(page, { name: 'normal', latencyMs: 100, orderOutcome: 'pending' })
  196 |   await review(page)
  197 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click() })
  198 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  199 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(1)
  200 | })
  201 | 
  202 | test('C: timeout após criação e refresh recuperam a mesma chave e o mesmo pedido', async ({ page }) => {
  203 |   await login(page); await add(page)
  204 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending', orderResponseDelayMs: 11000 })
  205 |   await review(page)
  206 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  207 |   await expect(page.getByRole('alert')).toContainText('demorou demais', { timeout: 12000 })
  208 |   const before = (await request(page, '/api/orders', 'GET')).body.items
  209 |   expect(before).toHaveLength(1)
  210 |   const attempt = await page.evaluate(() => sessionStorage.getItem('kurio.checkout.attempt:alice'))
  211 |   expect((await request(page, '/api/cart', 'GET')).body.items).toHaveLength(1)
  212 |   await page.reload()
  213 |   await page.getByRole('button', { name: 'Recuperar tentativa anterior' }).click()
  214 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  215 |   expect(new URL(page.url()).searchParams.get('orderId')).toBe(before[0].id)
  216 |   expect(JSON.parse((await page.evaluate(() => sessionStorage.getItem('kurio.checkout.attempt:alice')))!).key).toBe(JSON.parse(attempt!).key)
  217 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(1)
  218 | })
  219 | 
  220 | test('C: refresh de pendente recupera estado real e recibo histórico é imutável', async ({ page }) => {
  221 |   await login(page); await add(page)
  222 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  223 |   await review(page)
  224 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  225 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  226 |   const id = new URL(page.url()).searchParams.get('orderId')!
  227 |   await page.reload(); await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  228 |   await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'confirmed' })
  229 |   await expect(page.getByTestId('order-receipt')).toBeVisible()
  230 |   await request(page, '/api/__mock/nft', 'POST', { nftId: 'nft-002', editionId: 'edition-002', price: '9.123456789123456789' })
  231 |   await page.reload()
  232 |   await expect(page.getByTestId('order-receipt').getByTestId('checkout-total')).toHaveText('0.306 ETH')
  233 |   const order = (await request(page, `/api/orders/${id}`, 'GET')).body
  234 |   expect(order.snapshot.items[0].edition.price.amount).toBe('0.29')
  235 |   expect((await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'rejected' })).status).toBe(409)
  236 | })
  237 | 
  238 | test('C: confirmação remove somente quantidades compradas, preserva extras e não repete efeitos', async ({ page }) => {
  239 |   await login(page)
  240 |   await request(page, '/api/cart/items', 'POST', { nftId: 'nft-002', editionId: 'edition-002', quantity: 2 })
  241 |   await request(page, '/api/cart/items', 'POST', { nftId: 'nft-003', editionId: 'edition-003', quantity: 1 })
  242 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  243 |   await page.goto('/checkout')
  244 |   await openCheckoutItems(page)
> 245 |   await page.getByRole('checkbox', { name: 'Comprar Neon Vessel #003', exact: true }).uncheck()
      |                                                                                       ^ Error: locator.uncheck: Test timeout of 30000ms exceeded.
  246 |   await page.getByLabel('Quantidade a comprar de Sage Nomad #002', { exact: true }).fill('1')
  247 |   await page.getByRole('button', { name: 'Conectar carteira', exact: true }).click()
  248 |   await page.getByRole('button', { name: 'Revalidar e revisar compra' }).click()
  249 |   await page.getByRole('dialog').getByRole('checkbox').check()
  250 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  251 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  252 |   const id = new URL(page.url()).searchParams.get('orderId')!
  253 |   await request(page, '/api/cart/items', 'POST', { nftId: 'nft-002', editionId: 'edition-002', quantity: 1 })
  254 |   for (let i = 0; i < 2; i++) expect((await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'confirmed' })).status).toBe(200)
  255 |   const cart = (await request(page, '/api/cart', 'GET')).body
  256 |   expect(cart.items.find((item: { nftId: string }) => item.nftId === 'nft-002').quantity).toBe(2)
  257 |   expect(cart.items.find((item: { nftId: string }) => item.nftId === 'nft-003').quantity).toBe(1)
  258 |   const nft = (await request(page, '/api/nfts/nft-002', 'GET')).body.item
  259 |   expect(nft.editions[0].availability.remaining).toBe(2)
  260 |   await expect(page.getByTestId('order-receipt').getByTestId('checkout-total')).toHaveText('0.306 ETH')
  261 | })
  262 | 
  263 | test('C: backend bloqueia cotação alterada ou expirada e pedido privado de outra conta', async ({ page }) => {
  264 |   await login(page)
  265 |   await request(page, '/api/cart/items', 'POST', { nftId: 'nft-002', editionId: 'edition-002', quantity: 1 })
  266 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  267 |   const first = await apiQuote(page)
  268 |   await request(page, '/api/__mock/nft', 'POST', { nftId: 'nft-002', editionId: 'edition-002', price: '0.39' })
  269 |   expect((await request(page, '/api/orders', 'POST', first.input, { 'Idempotency-Key': 'stale-quote-price' })).status).toBe(409)
  270 |   await page.clock.install()
  271 |   const expired = await apiQuote(page)
  272 |   await page.clock.fastForward(61000)
  273 |   expect((await request(page, '/api/orders', 'POST', expired.input, { 'Idempotency-Key': 'expired-quote-001' })).status).toBe(409)
  274 |   const second = await apiQuote(page)
  275 |   const created = await request(page, '/api/orders', 'POST', second.input, { 'Idempotency-Key': 'private-order-alice' })
  276 |   expect(created.status).toBe(201)
  277 |   if (!await page.getByRole('button', { name: 'Sair', exact: true }).isVisible()) await page.getByRole('button', { name: 'Abrir menu' }).click()
  278 |   await page.getByRole('button', { name: 'Sair', exact: true }).click()
  279 |   await expect(page.getByRole('heading', { name: /SEJA DONO D[OA]/ })).toBeVisible()
  280 |   await login(page, 'bob')
  281 |   expect((await request(page, `/api/orders/${created.body.id}`, 'GET')).status).toBe(404)
  282 |   expect((await request(page, `/api/__mock/orders/${created.body.id}/settle`, 'POST', { status: 'confirmed' })).status).toBe(404)
  283 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(0)
  284 | })
  285 | 
  286 | test('E: expiração no checkout preserva formulário, seleção e retorno após autenticação', async ({ page }) => {
  287 |   await login(page); await add(page)
  288 |   await page.goto('/checkout')
  289 |   await openCollector(page)
  290 |   await page.getByLabel('Nome de exibição', { exact: true }).fill('Alice pagamento')
  291 |   await page.getByLabel('Observação do colecionador (opcional)').fill('Preservar contexto da revisão')
  292 |   await page.getByRole('button', { name: 'Conectar carteira', exact: true }).click()
  293 |   await expect(page.getByText('Carteira conectada (simulação).')).toBeVisible()
  294 |   await expect(page.getByTestId('realtime-status')).toHaveAttribute('data-transport', 'websocket')
  295 |   await configure(page, { name: 'normal', latencyMs: 10, faults: { 'checkout.quote': { latencyMs: 800 } } })
  296 |   const started = page.waitForRequest(request => request.method() === 'POST' && new URL(request.url()).pathname === '/api/checkout/quote')
  297 |   await page.getByRole('button', { name: 'Revalidar e revisar compra' }).click()
  298 |   await started
  299 |   await request(page, '/api/__mock/session/expire', 'POST', {})
  300 |   await expect(page.getByRole('heading', { name: 'Entrar', exact: true })).toBeVisible()
  301 |   expect(new URL(page.url()).searchParams.get('redirect')).toBe('/checkout')
  302 |   await page.getByLabel('E-mail', { exact: true }).fill('alice@kurio.test')
  303 |   await page.getByLabel('Senha', { exact: true }).fill('Kurio123!')
  304 |   await page.getByRole('button', { name: 'Entrar', exact: true }).click()
  305 |   await expect(page.getByRole('heading', { name: 'Checkout', exact: true })).toBeVisible()
  306 |   await expect(page.getByLabel('Nome de exibição', { exact: true })).toHaveValue('Alice pagamento')
  307 |   await expect(page.getByLabel('Observação do colecionador (opcional)')).toHaveValue('Preservar contexto da revisão')
  308 |   expect((await request(page, '/api/cart', 'GET')).body.items).toHaveLength(1)
  309 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(0)
  310 | })
  311 | 
  312 | test('E: API revalida taxa e cupom e rejeita quantidades inválidas ou rede incompatível', async ({ page }) => {
  313 |   await login(page)
  314 |   await request(page, '/api/cart/items', 'POST', { nftId: 'nft-002', editionId: 'edition-002', quantity: 1 })
  315 |   const quote1 = await apiQuote(page)
  316 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending', networkFeeEth: '0.019000000000000001' })
  317 |   expect((await request(page, '/api/orders', 'POST', quote1.input, { 'Idempotency-Key': 'stale-fee-attempt' })).status).toBe(409)
  318 |   const quote2 = await apiQuote(page)
  319 |   expect(quote2.quote.total).toBe('0.309000000000000001')
  320 |   await request(page, '/api/cart/coupon', 'POST', { code: 'KURIO10' })
  321 |   const quote3 = await apiQuote(page)
  322 |   await configure(page, { name: 'normal', latencyMs: 10, expireCoupon: true })
  323 |   expect((await request(page, '/api/orders', 'POST', quote3.input, { 'Idempotency-Key': 'stale-coupon-attempt' })).status).toBe(409)
  324 |   await configure(page, { name: 'normal', latencyMs: 10 })
  325 |   await request(page, '/api/cart/coupon', 'DELETE')
  326 |   const wallet = (await request(page, '/api/wallets', 'GET')).body.items[0]
  327 |   const input = { walletId: wallet.id, network: 'ethereum', collector: wallet.collector, items: [{ itemId: 'nft-002:edition-002', quantity: 1 }] }
  328 |   for (const quantity of [-1, 0.5, 0]) expect((await request(page, '/api/checkout/quote', 'POST', { ...input, items: [{ itemId: 'nft-002:edition-002', quantity }] })).status).toBe(400)
  329 |   expect((await request(page, '/api/checkout/quote', 'POST', { ...input, network: 'polygon' })).status).toBe(400)
  330 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(0)
  331 | })
  332 | 
  333 | test('E: estoque perdido durante processamento recusa pedido e preserva carrinho', async ({ page }) => {
  334 |   await login(page); await add(page)
  335 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  336 |   await review(page)
  337 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  338 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  339 |   const id = new URL(page.url()).searchParams.get('orderId')!
  340 |   await request(page, '/api/__mock/stock', 'POST', { nftId: 'nft-002', editionId: 'edition-002', remaining: 0 })
  341 |   const result = await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'confirmed' })
  342 |   expect(result.body.status).toBe('rejected')
  343 |   await expect(page.getByTestId('order-status')).toHaveText('Pagamento recusado')
  344 |   await expect(page.getByRole('alert')).toContainText('Estoque indisponível')
  345 |   expect((await request(page, '/api/cart', 'GET')).body.items).toHaveLength(1)
```