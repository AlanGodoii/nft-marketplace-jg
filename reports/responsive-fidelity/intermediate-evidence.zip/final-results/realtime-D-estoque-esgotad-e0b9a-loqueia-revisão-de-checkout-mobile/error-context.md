# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: realtime.spec.ts >> D: estoque esgotado via socket bloqueia revisão de checkout
- Location: tests/realtime.spec.ts:72:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  getByText(/Edição indisponível ou estoque esgotado/)
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" getByText(/Edição indisponível ou estoque esgotado/) with timeout 5000ms
  - waiting for getByText(/Edição indisponível ou estoque esgotado/)
    14 × locator resolved to <p role="alert">Edição indisponível ou estoque esgotado. Corrija …</p>
       - unexpected value "hidden"

```

```yaml
- link "Pular para o conteúdo":
  - /url: "#conteudo"
- status "Usuário conectado": Alice
- banner:
  - link "Voltar":
    - /url: /carrinho
  - text: Pagamento com carteira
  - button "Abrir menu"
- main:
  - status "Conexão em tempo real": Atualizações ao vivo conectadas.
  - heading "Checkout" [level=1]
  - link "Voltar ao carrinho":
    - /url: /carrinho
  - region "Seleção de carteira":
    - heading "Carteira cadastrada" [level=2]
    - link "Trocar carteira":
      - /url: /carteiras
    - button "Principal alice.eth Rede ethereum" [pressed]:
      - strong: Principal
      - text: alice.eth Rede ethereum
    - heading "Carteira e rede" [level=2]
    - button "WalletConnect"
    - button "MetaMask" [pressed]
    - button "Coinbase Wallet"
  - status: "Atualização ao vivo: Sage Nomad #002 · Edição original: preço 0.29 ETH, estoque 0. A cotação anterior foi invalidada. Revalide e confirme os valores atualizados."
  - heading "Carteira e rede" [level=2]
  - paragraph: Principal · metamask · 0x1111111111111111111111111111111111111111
  - text: Rede de pagamento
  - combobox "Rede de pagamento":
    - option "Ethereum" [selected]
    - option "Polygon"
    - option "Solana"
  - button "Conectar carteira"
  - button "Desconectar carteira"
  - status: Carteira conectada (simulação).
  - form "Dados do pagamento":
    - heading "Perfil do colecionador" [level=2]
    - group: Dados do colecionador
    - button "Revalidar e revisar compra"
  - complementary:
    - heading "Seus NFTs" [level=2]
    - paragraph: Escolha as edições e quantidades desta compra. Itens não selecionados ficam no carrinho.
    - group: Revisar NFTs e cupom
    - status: Calculando estimativa…
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test'
  2   | import { add, configure, login, request, reset, review } from './helpers/market'
  3   | test.beforeEach(async ({ page }) => reset(page))
  4   | 
  5   | test('D: handshake e nft.updated passam pelo cliente real e invalidam cotação', async ({ page }) => {
  6   |   await login(page); await add(page)
  7   |   await review(page)
  8   |   await expect(page.getByTestId('realtime-status')).toHaveAttribute('data-transport', 'websocket')
  9   |   const changed = await request(page, '/api/__mock/nft', 'POST', { nftId: 'nft-002', editionId: 'edition-002', price: '0.49' })
  10  |   expect(changed.status).toBe(200)
  11  |   await expect(page.getByRole('dialog')).toHaveCount(0)
  12  |   await expect(page.getByText(/A cotação anterior foi invalidada/)).toBeVisible()
  13  |   await page.getByRole('button', { name: 'Revalidar e revisar compra' }).click()
  14  |   const dialog = page.getByRole('dialog')
  15  |   await expect(dialog.getByTestId('checkout-total')).toHaveText('0.506 ETH')
  16  |   await expect(dialog.getByRole('checkbox')).not.toBeChecked()
  17  |   const stats = (await request(page, '/api/__mock/socket/stats', 'GET')).body
  18  |   expect(stats.engineOpens).toBeGreaterThan(0)
  19  |   expect(stats.namespaceConnects).toBeGreaterThan(0)
  20  |   expect(stats.receipts).toContainEqual({ eventId: changed.body.event.eventId, status: 'accepted' })
  21  | })
  22  | 
  23  | test('D: order.updated confirma pelo socket sem polling de pedido', async ({ page }) => {
  24  |   await login(page); await add(page)
  25  |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  26  |   await review(page)
  27  |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  28  |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  29  |   const id = new URL(page.url()).searchParams.get('orderId')!
  30  |   await expect(page.getByRole('button', { name: 'Consultar estado do pedido' })).toBeEnabled()
  31  |   await page.clock.install()
  32  |   const reads: string[] = []
  33  |   page.on('request', request => { if (request.method() === 'GET' && new URL(request.url()).pathname === `/api/orders/${id}`) reads.push(request.url()) })
  34  |   await page.clock.fastForward(2500)
  35  |   expect(reads).toHaveLength(0)
  36  |   await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'confirmed' })
  37  |   await expect(page.getByTestId('order-receipt')).toBeVisible()
  38  |   expect(reads.length).toBeGreaterThan(0)
  39  |   const stats = (await request(page, '/api/__mock/socket/stats', 'GET')).body
  40  |   expect(stats.receipts.some((receipt: { eventId: string; status: string }) => receipt.eventId.startsWith(`order:${id}:2:`) && receipt.status === 'accepted')).toBe(true)
  41  | })
  42  | 
  43  | test('D: catálogo, detalhe e carrinho atualizam por eventos, duplicatas e versões antigas são ignoradas', async ({ page }) => {
  44  |   await login(page); await add(page)
  45  |   await page.goto('/?search=Sage%20Nomad%20%23002')
  46  |   await expect(page.getByTestId('realtime-status')).toHaveAttribute('data-transport', 'websocket')
  47  |   await expect(page.locator('a.nft-card-link')).toContainText('0.29 ETH')
  48  |   const original = (await request(page, '/api/nfts/nft-002', 'GET')).body.item
  49  |   const change = await request(page, '/api/__mock/nft', 'POST', { nftId: 'nft-002', editionId: 'edition-002', price: '0.59' })
  50  |   await expect(page.locator('a.nft-card-link')).toContainText('0.59 ETH')
  51  |   expect((await request(page, '/api/__mock/socket/event', 'POST', { event: change.body.event })).status).toBe(200)
  52  |   await request(page, '/api/__mock/socket/event', 'POST', { event: { type: 'nft.updated', eventId: 'old-nft-001', resourceId: original.id, version: original.version, payload: original } })
  53  |   await expect(page.locator('a.nft-card-link')).toContainText('0.59 ETH')
  54  |   await expect.poll(async () => (await request(page, '/api/__mock/socket/stats', 'GET')).body.receipts).toContainEqual({ eventId: change.body.event.eventId, status: 'ignored' })
  55  |   let stats = (await request(page, '/api/__mock/socket/stats', 'GET')).body
  56  |   expect(stats.receipts).toContainEqual({ eventId: 'old-nft-001', status: 'ignored' })
  57  |   await page.locator('a.nft-card-link').click()
  58  |   await expect(page.locator('.detail-info')).toContainText('0.59 ETH')
  59  |   const detailChange = await request(page, '/api/__mock/nft', 'POST', { nftId: 'nft-002', editionId: 'edition-002', price: '0.69' })
  60  |   await expect(page.locator('.detail-info')).toContainText('0.69 ETH')
  61  |   await expect.poll(async () => (await request(page, '/api/__mock/socket/stats', 'GET')).body.receipts).toContainEqual({ eventId: detailChange.body.event.eventId, status: 'accepted' })
  62  |   await page.goto('/carrinho')
  63  |   await expect(page.getByTestId('realtime-status')).toHaveAttribute('data-transport', 'websocket')
  64  |   await expect(page.getByTestId('total')).toHaveText('0.706 ETH')
  65  |   const cartChange = await request(page, '/api/__mock/nft', 'POST', { nftId: 'nft-002', editionId: 'edition-002', price: '0.79' })
  66  |   await expect(page.getByTestId('total')).toHaveText('0.806 ETH')
  67  |   await expect(page.getByTestId('cart-item')).toContainText('0.79 ETH')
  68  |   stats = (await request(page, '/api/__mock/socket/stats', 'GET')).body
  69  |   expect(stats.receipts).toContainEqual({ eventId: cartChange.body.event.eventId, status: 'accepted' })
  70  | })
  71  | 
  72  | test('D: estoque esgotado via socket bloqueia revisão de checkout', async ({ page }) => {
  73  |   await login(page); await add(page); await review(page)
  74  |   await request(page, '/api/__mock/stock', 'POST', { nftId: 'nft-002', editionId: 'edition-002', remaining: 0 })
  75  |   await expect(page.getByRole('dialog')).toHaveCount(0)
> 76  |   await expect(page.getByText(/Edição indisponível ou estoque esgotado/)).toBeVisible()
      |                                                                           ^ Error: expect(locator).toBeVisible() failed
  77  |   await page.getByRole('button', { name: 'Revalidar e revisar compra' }).click()
  78  |   await expect(page.getByRole('alert').filter({ hasText: 'Estoque, edição ou cupom indisponível' })).toBeVisible()
  79  |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(0)
  80  | })
  81  | 
  82  | test('D: pedido muda offline e reconexão reconcilia o mesmo pedido por REST', async ({ page }) => {
  83  |   await login(page); await add(page)
  84  |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  85  |   await review(page)
  86  |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  87  |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  88  |   const id = new URL(page.url()).searchParams.get('orderId')!
  89  |   const openedBefore = (await request(page, '/api/__mock/socket/stats', 'GET')).body.engineOpens
  90  |   await request(page, '/api/__mock/socket', 'POST', { action: 'disconnect' })
  91  |   await expect(page.getByTestId('realtime-status')).toContainText('Reconectando')
  92  |   await expect.poll(async () => (await request(page, '/api/__mock/socket/stats', 'GET')).body.engineOpens).toBeGreaterThan(openedBefore)
  93  |   await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'confirmed' })
  94  |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  95  |   await expect(page.getByTestId('order-receipt')).toHaveCount(0)
  96  |   const reads: string[] = []
  97  |   page.on('request', request => { if (request.method() === 'GET' && new URL(request.url()).pathname === `/api/orders/${id}`) reads.push(request.url()) })
  98  |   await request(page, '/api/__mock/socket', 'POST', { action: 'resume' })
  99  |   await expect(page.getByTestId('realtime-status')).toContainText('Atualizações ao vivo conectadas.')
  100 |   await expect(page.getByTestId('order-receipt')).toBeVisible()
  101 |   expect(reads.length).toBeGreaterThan(0)
  102 |   expect(new URL(page.url()).searchParams.get('orderId')).toBe(id)
  103 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(1)
  104 | })
  105 | 
  106 | test('D: refresh offline de pedido pendente recupera confirmação persistida sem duplicar', async ({ page }) => {
  107 |   await login(page); await add(page)
  108 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  109 |   await review(page)
  110 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  111 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  112 |   const id = new URL(page.url()).searchParams.get('orderId')!
  113 |   await request(page, '/api/__mock/socket', 'POST', { action: 'disconnect' })
  114 |   await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'confirmed' })
  115 |   await page.reload()
  116 |   await expect(page.getByTestId('order-receipt')).toBeVisible()
  117 |   expect(new URL(page.url()).searchParams.get('orderId')).toBe(id)
  118 |   expect((await request(page, '/api/orders', 'GET')).body.items).toHaveLength(1)
  119 | })
  120 | 
  121 | test('D: eventos antigos e duplicados não regridem pedido terminal ou limpam carrinho novamente', async ({ page }) => {
  122 |   await login(page); await add(page)
  123 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  124 |   await review(page)
  125 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  126 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  127 |   const id = new URL(page.url()).searchParams.get('orderId')!
  128 |   const pending = (await request(page, `/api/orders/${id}`, 'GET')).body
  129 |   await request(page, `/api/__mock/orders/${id}/settle`, 'POST', { status: 'confirmed' })
  130 |   await expect(page.getByTestId('order-receipt')).toBeVisible()
  131 |   await request(page, '/api/cart/items', 'POST', { nftId: 'nft-002', editionId: 'edition-002', quantity: 1 })
  132 |   const order = (await request(page, `/api/orders/${id}`, 'GET')).body
  133 |   const stats = (await request(page, '/api/__mock/socket/stats', 'GET')).body
  134 |   const event = { type: 'order.updated', eventId: `order:${id}:2:${stats.sessionId.slice(0, 12)}`, resourceId: id, version: 2, userId: 'alice', sessionId: stats.sessionId, payload: order }
  135 |   await request(page, '/api/__mock/socket/event', 'POST', { event })
  136 |   await request(page, '/api/__mock/socket/event', 'POST', { event: { ...event, eventId: 'older-order-packet', version: 1, payload: pending } })
  137 |   const regressing = { ...pending, version: 3 }
  138 |   await request(page, '/api/__mock/socket/event', 'POST', { event: { ...event, eventId: 'terminal-regression-packet', version: 3, payload: regressing } })
  139 |   await expect(page.getByTestId('order-receipt')).toBeVisible()
  140 |   expect((await request(page, '/api/cart', 'GET')).body.items[0].quantity).toBe(1)
  141 |   const after = (await request(page, '/api/__mock/socket/stats', 'GET')).body
  142 |   for (const eventId of [event.eventId, 'older-order-packet', 'terminal-regression-packet']) expect(after.receipts).toContainEqual({ eventId, status: 'ignored' })
  143 | })
  144 | 
  145 | test('D: troca de usuário encerra socket anterior e rejeita evento privado de outra sessão', async ({ page }) => {
  146 |   await login(page); await add(page)
  147 |   await configure(page, { name: 'normal', latencyMs: 10, orderOutcome: 'pending' })
  148 |   await review(page)
  149 |   await page.getByRole('button', { name: 'Finalizar compra', exact: true }).click()
  150 |   await expect(page.getByTestId('order-status')).toHaveText('Pedido pendente')
  151 |   const id = new URL(page.url()).searchParams.get('orderId')!
  152 |   const order = (await request(page, `/api/orders/${id}`, 'GET')).body
  153 |   const aliceSession = (await request(page, '/api/__mock/socket/stats', 'GET')).body.sessionId
  154 |   if (!await page.getByRole('button', { name: 'Sair', exact: true }).isVisible()) await page.getByRole('button', { name: 'Abrir menu' }).click()
  155 |   await page.getByRole('button', { name: 'Sair', exact: true }).click()
  156 |   await expect(page.getByRole('heading', { name: /SEJA DONO D[OA]/ })).toBeVisible()
  157 |   await login(page, 'bob', '/pedido/confirmacao')
  158 |   await expect(page.getByText('Nenhum pedido selecionado. Você ainda não tem pedidos.')).toBeVisible()
  159 |   await expect(page.getByTestId('realtime-status')).toHaveAttribute('data-transport', 'websocket')
  160 |   await request(page, '/api/__mock/socket/event', 'POST', { audience: 'all', event: { type: 'order.updated', eventId: 'private-wrong-session', resourceId: id, version: order.version, userId: 'alice', sessionId: aliceSession, payload: order } })
  161 |   await expect(page.getByTestId('order-receipt')).toHaveCount(0)
  162 |   const stats = (await request(page, '/api/__mock/socket/stats', 'GET')).body
  163 |   expect(stats.receipts).toContainEqual({ eventId: 'private-wrong-session', status: 'ignored' })
  164 |   expect(stats.active).toBe(1)
  165 |   expect((await request(page, `/api/orders/${id}`, 'GET')).status).toBe(404)
  166 | })
  167 | 
```