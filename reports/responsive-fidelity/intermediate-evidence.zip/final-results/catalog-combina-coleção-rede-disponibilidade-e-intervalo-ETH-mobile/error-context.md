# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: catalog.spec.ts >> combina coleção, rede, disponibilidade e intervalo ETH
- Location: tests/catalog.spec.ts:65:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - link "Pular para o conteúdo" [ref=f1e4] [cursor=pointer]:
    - /url: "#conteudo"
  - navigation "Menu inferior" [ref=f1e5]:
    - link "Início" [ref=f1e6] [cursor=pointer]:
      - /url: /
    - link "Favoritos" [ref=f1e10] [cursor=pointer]:
      - /url: /favoritos
    - link "Carteiras" [ref=f1e13] [cursor=pointer]:
      - /url: /carteiras
    - link "Carrinho" [ref=f1e17] [cursor=pointer]:
      - /url: /carrinho
    - button "Abrir menu" [ref=f1e23]
  - main [ref=f1e24]:
    - status "Conexão em tempo real" [ref=f1e25]: Atualizações ao vivo conectadas.
    - generic [ref=f1e26]:
      - generic [ref=f1e27]:
        - generic [ref=f1e28]:
          - generic [ref=f1e29]: Buscar NFTs
          - searchbox "Buscar NFTs" [ref=f1e30]
        - button "Abrir filtros do catálogo" [expanded] [ref=f1e31]
      - region [ref=f1e32]:
        - generic [ref=f1e33]:
          - paragraph [ref=f1e34]: Bem-vindo à Kurio
          - heading "SEJA DONO DA CULTURA DIGITAL" [level=1] [ref=f1e35]: SEJA DONO DACULTURA DIGITAL
          - paragraph [ref=f1e36]: Descubra NFTs selecionados de criadores do mundo todo.
          - link "EXPLORAR" [ref=f1e37] [cursor=pointer]:
            - /url: "#catalogo"
        - 'img "Arte original Kurio: macaco de jaqueta verde" [ref=f1e42]'
      - region [ref=f1e47]:
        - generic [ref=f1e48]:
          - group [ref=f1e49]:
            - generic "Filtrar NFTs" [ref=f1e50] [cursor=pointer]
            - generic [ref=f1e52]:
              - generic [ref=f1e53]:
                - heading "Filtros" [level=2] [ref=f1e54]
                - button "Limpar" [ref=f1e56]
              - group "Filtrar catálogo de NFTs" [ref=f1e57]:
                - generic [ref=f1e59]:
                  - generic [ref=f1e60]: Coleção
                  - combobox "Coleção" [ref=f1e61]:
                    - option "Todas as coleções"
                    - option "Genesis" [selected]
                    - option "Nomads"
                    - option "Signals"
                - generic [ref=f1e62]:
                  - generic [ref=f1e63]: Rede
                  - combobox "Rede" [ref=f1e64]:
                    - option "Todas as redes"
                    - option "Ethereum"
                    - option "Polygon" [selected]
                    - option "Solana"
                - generic [ref=f1e65]:
                  - paragraph [ref=f1e66]: Faixa de preço
                  - group "Faixa de preço" [ref=f1e67]:
                    - generic [ref=f1e68]:
                      - generic [ref=f1e69]: Mínimo
                      - spinbutton "Mínimo" [ref=f1e70]: "0.1"
                    - generic [ref=f1e71]:
                      - generic [ref=f1e72]: Máximo
                      - spinbutton "Máximo" [active] [ref=f1e73]: "1.5"
                - generic [ref=f1e74]:
                  - paragraph [ref=f1e75]: Disponibilidade
                  - generic [ref=f1e76]:
                    - checkbox "Disponíveis para compra" [checked] [ref=f1e77]
                    - text: Disponíveis para compra
          - generic [ref=f1e78]:
            - group "Categorias do catálogo" [ref=f1e79]:
              - button "Todos os NFTs" [pressed] [ref=f1e80]
              - button "Novos lançamentos" [ref=f1e81]
              - button "Em alta" [ref=f1e82]
            - paragraph [ref=f1e83]: "Novos lançamentos: publicados desde 1 de novembro de 2026. Em alta: seleção de edições disponíveis, sem estatística de vendas."
            - generic:
              - heading "Explore os NFTs" [level=2] [ref=f1e84]
              - paragraph [ref=f1e85]: 2 NFTs encontrados
            - generic [ref=f1e87]:
              - generic [ref=f1e88]: Ordenar por
              - combobox "Ordenar por" [ref=f1e89]:
                - option "Mais recentes" [selected]
                - option "Menor preço"
                - option "Maior preço"
          - generic [ref=f1e90]:
            - status
            - button "Atualizar catálogo ↻" [ref=f1e91]
          - generic [ref=f1e93]:
            - generic [ref=f1e94]:
              - link [ref=f1e95] [cursor=pointer]:
                - /url: /nfts/nft-013
                - 'img "Arte original de Emerald Ape #013" [ref=f1e97]'
                - generic [ref=f1e98]:
                  - 'heading "Emerald Ape #013" [level=3] [ref=f1e99]'
                  - paragraph [ref=f1e102]: 0.19 ETH
              - button "Adicionar aos favoritos" [ref=f1e105]
            - generic [ref=f1e106]:
              - link [ref=f1e107] [cursor=pointer]:
                - /url: /nfts/nft-004
                - 'img "Arte original de Cosmic Bloom #004" [ref=f1e109]'
                - generic [ref=f1e110]:
                  - 'heading "Cosmic Bloom #004" [level=3] [ref=f1e111]'
                  - paragraph [ref=f1e114]: 0.390000000000000002 ETH
              - button "Adicionar aos favoritos" [ref=f1e117]
          - navigation "Paginação do catálogo" [ref=f1e118]:
            - button "Página anterior" [disabled]
            - generic [ref=f1e119]: Página 1 de 1
            - button "Próxima página" [disabled]
```