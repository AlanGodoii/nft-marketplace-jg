# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: checkout.spec.ts >> B: visitante retorna ao checkout, conecta carteira e revisa cotação com cupom
- Location: tests/checkout.spec.ts:58:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "Pular para o conteúdo" [ref=f3e4] [cursor=pointer]:
    - /url: "#conteudo"
  - status "Usuário conectado" [ref=f3e5]: Alice
  - banner [ref=f3e6]:
    - link "Voltar" [ref=f3e7] [cursor=pointer]:
      - /url: /carrinho
    - generic [ref=f3e10]: Pagamento com carteira
    - button "Abrir menu" [ref=f3e11]
  - main [ref=f3e12]:
    - status "Conexão em tempo real" [ref=f3e13]: Atualizações ao vivo conectadas.
    - generic [ref=f3e14]:
      - heading "Checkout" [level=1] [ref=f3e15]
      - link "Voltar ao carrinho" [ref=f3e16] [cursor=pointer]:
        - /url: /carrinho
      - region "Seleção de carteira" [ref=f3e17]:
        - generic [ref=f3e18]:
          - heading "Carteira cadastrada" [level=2] [ref=f3e19]
          - link "Trocar carteira" [ref=f3e20] [cursor=pointer]:
            - /url: /carteiras
        - button "Principal alice.eth Rede ethereum" [pressed] [ref=f3e22]:
          - generic [ref=f3e26]:
            - strong [ref=f3e27]: Principal
            - generic [ref=f3e28]: alice.eth
            - generic [ref=f3e29]: Rede ethereum
        - heading "Carteira e rede" [level=2] [ref=f3e30]
        - generic [ref=f3e31]:
          - button [ref=f3e32]
          - button [pressed] [ref=f3e39]
          - button [ref=f3e47]
      - generic [ref=f3e54]:
        - generic [ref=f3e55]:
          - generic [ref=f3e56]:
            - heading "Carteira e rede" [level=2] [ref=f3e57]
            - paragraph [ref=f3e58]: Principal · metamask · 0x1111111111111111111111111111111111111111
            - text: Rede de pagamento
            - combobox "Rede de pagamento" [ref=f3e59]:
              - option "Ethereum" [selected]
              - option "Polygon"
              - option "Solana"
            - generic [ref=f3e60]:
              - button "Conectar carteira" [ref=f3e61]
              - button "Desconectar carteira" [ref=f3e62]
            - status [ref=f3e63]: Carteira desconectada.
          - form "Dados do pagamento" [ref=f3e64]:
            - heading "Perfil do colecionador" [level=2] [ref=f3e65]
            - group [ref=f3e66]:
              - generic "Dados do colecionador" [ref=f3e67] [cursor=pointer]
            - button "Revalidar e revisar compra" [disabled]
        - complementary [ref=f3e68]:
          - heading "Seus NFTs" [level=2] [ref=f3e69]
          - paragraph [ref=f3e70]: Escolha as edições e quantidades desta compra. Itens não selecionados ficam no carrinho.
          - group [ref=f3e71]:
            - generic "Revisar NFTs e cupom" [ref=f3e72] [cursor=pointer]
          - generic "Valores da compra" [ref=f3e73]:
            - generic [ref=f3e74]:
              - term [ref=f3e75]: Total
              - definition [ref=f3e76]: 0.596 ETH
          - paragraph [ref=f3e77]: Estimativa. Revalide antes de confirmar a compra.
```