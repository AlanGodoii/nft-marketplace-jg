# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fidelity.spec.ts >> artes originais acompanham detalhe, favoritos, carrinho e checkout pela API
- Location: tests/fidelity.spec.ts:4:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.nft-card img:visible')
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.nft-card img:visible') with timeout 5000ms
  - waiting for locator('.nft-card img:visible')
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "Pular para o conteúdo" [ref=f3e4] [cursor=pointer]:
    - /url: "#conteudo"
  - status "Usuário conectado" [ref=f3e5]: Alice
  - banner [ref=f3e6]:
    - link "Voltar" [ref=f3e7] [cursor=pointer]:
      - /url: /
    - generic [ref=f3e10]: Favoritos
  - navigation "Menu inferior" [ref=f3e11]:
    - link "Início" [ref=f3e12] [cursor=pointer]:
      - /url: /
    - link "Favoritos" [ref=f3e16] [cursor=pointer]:
      - /url: /favoritos
    - link "Carteiras" [ref=f3e19] [cursor=pointer]:
      - /url: /carteiras
    - link "Carrinho" [ref=f3e23] [cursor=pointer]:
      - /url: /carrinho
    - button "Abrir menu" [ref=f3e29]
  - main [ref=f3e30]:
    - status "Conexão em tempo real" [ref=f3e31]: Atualizações ao vivo conectadas.
    - generic [ref=f3e34]:
      - heading "Favoritos" [level=1] [ref=f3e35]
      - status [ref=f3e36]: Você ainda não tem favoritos.
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {add,login,reset,request,openCheckoutItems} from './helpers/market'
  3  | test.beforeEach(async({page})=>reset(page))
  4  | test('artes originais acompanham detalhe, favoritos, carrinho e checkout pela API',async({page})=>{
  5  |  await login(page,'alice','/favoritos'); await add(page)
  6  |  await expect(page.locator('.detail-art img')).toHaveAttribute('src','/assets/figma/home/sage-nomad.webp')
  7  |  await page.getByRole('button',{name:'Adicionar aos favoritos',exact:true}).click()
> 8  |  await page.goto('/favoritos');await expect(page.locator('.nft-card img:visible')).toHaveCount(1)
     |                                                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  9  |  await page.goto('/carrinho');await expect(page.locator('.cart-art img')).toHaveAttribute('src','/assets/figma/home/sage-nomad.webp')
  10 |  await page.goto('/checkout');await openCheckoutItems(page);await expect(page.locator('.checkout-art img')).toHaveAttribute('src','/assets/figma/home/sage-nomad.webp')
  11 |  expect(await page.locator('.checkout-art img').evaluate((image:HTMLImageElement)=>image.complete&&image.naturalWidth>0)).toBe(true)
  12 |  expect((await request(page,'/api/cart','GET')).body.items[0].quantity).toBe(1)
  13 | })
  14 | test('stepper respeita estoque e atualiza cotação real sem cálculo local',async({page})=>{
  15 |  await add(page);await page.goto('/carrinho')
  16 |  const row=page.getByTestId('cart-item');await row.getByRole('button',{name:'Aumentar quantidade de Sage Nomad #002'}).click()
  17 |  await expect(row.getByLabel('Quantidade',{exact:true})).toHaveValue('2');await expect(page.getByTestId('subtotal')).toHaveText('0.58 ETH')
  18 |  await page.reload();await expect(page.getByTestId('cart-item').getByLabel('Quantidade',{exact:true})).toHaveValue('2')
  19 | })
  20 | test('header e menu da conta permanecem disponíveis no detalhe, sem navegação antiga',async({page})=>{
  21 |  await login(page,'alice','/nfts/nft-002')
  22 |  if((page.viewportSize()?.width??0)>=1024){
  23 |   await expect(page.getByRole('navigation',{name:'Navegação principal'}).getByRole('link',{name:'Mercado',exact:true})).toHaveClass(/is-active/)
  24 |   await page.locator('.desktop-account summary').click();await page.locator('.desktop-account').getByRole('link',{name:'Perfil',exact:true}).click()
  25 |  }else{
  26 |   await page.getByRole('button',{name:'Abrir menu'}).click();await page.getByRole('navigation',{name:'Navegação principal'}).getByRole('link',{name:'Perfil',exact:true}).click()
  27 |  }
  28 |  await expect(page.getByRole('heading',{name:'Perfil do colecionador',exact:true})).toBeVisible()
  29 |  await expect(page.locator('.kurio-header')).toHaveCount(0)
  30 | })
  31 | test('login usa composição desktop ou mobile sem fingir OAuth',async({page})=>{
  32 |  if((page.viewportSize()?.width??0)>=1024){await expect(page.getByRole('dialog')).toBeVisible();await expect(page.locator('.auth-backdrop .nft-card')).toHaveCount(9)}
  33 |  else{await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.auth-wordmark')).toHaveText('KURIO')}
  34 |  await page.getByRole('button',{name:'Continuar com Google'}).click();await expect(page.getByRole('status').filter({hasText:'indisponível'})).toBeVisible()
  35 |  await expect(page.getByLabel('Usuário conectado')).toHaveCount(0)
  36 | })
  37 | 
```