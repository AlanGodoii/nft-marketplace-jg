# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fidelity.spec.ts >> ENS e apelido do perfil gravam na carteira vinculada pela API
- Location: tests/fidelity.spec.ts:53:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Carteira vinculada atualizada.', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Carteira vinculada atualizada.', { exact: true }) with timeout 5000ms
  - waiting for getByText('Carteira vinculada atualizada.', { exact: true })

```

```yaml
- link "Pular para o conteúdo":
  - /url: "#conteudo"
- banner:
  - link "Kurio — início":
    - /url: /
    - text: KURIO
  - navigation "Navegação principal":
    - link "Início":
      - /url: /
    - link "Mercado":
      - /url: /#catalogo
    - link "Criadores":
      - /url: /#criadores
    - link "Aprenda":
      - /url: /#diario
  - button "Abrir busca do mercado"
  - link "Carrinho, 0 itens":
    - /url: /carrinho
  - group:
    - status "Usuário conectado": Alice
  - button "Sair"
- main:
  - status "Conexão em tempo real": Atualizações ao vivo conectadas.
  - complementary "Meu perfil":
    - heading "Meu perfil" [level=2]
    - link "Dados do perfil":
      - /url: /perfil
    - link "Carteiras":
      - /url: /carteiras
    - link "Meus pedidos":
      - /url: /pedido/confirmacao
    - link "Lista de interesse":
      - /url: /favoritos
    - button "Ofertas"
    - button "Arquivos baixados"
    - button "Suporte"
    - button "Sair da conta": Sair
    - status
  - heading "Perfil do colecionador" [level=1]
  - form "Dados do perfil":
    - heading "Informações do colecionador" [level=2]
    - text: Nome de exibição*
    - textbox "Nome de exibição*": Alice
    - paragraph
    - text: Nome de usuário
    - textbox "Nome de usuário"
    - paragraph
    - text: E-mail*
    - textbox "E-mail*": alice@kurio.test
    - paragraph
    - group: Informações adicionais
    - button "Salvar perfil"
  - form "Carteira vinculada ao perfil":
    - text: Nome ENS*
    - textbox "Nome ENS*": nova-alice.eth
    - text: Apelido da carteira*
    - textbox "Apelido da carteira*": Coleção principal
    - button "Salvar carteira vinculada"
  - region "Avatar":
    - heading "Avatar" [level=2]
    - img "Nenhum avatar cadastrado"
    - text: Imagem do avatar
    - button "Imagem do avatar"
    - paragraph: PNG, JPEG ou WebP. Até 256 KiB e 4096×4096 px. SVG não é aceito.
    - alert
    - status
    - button "Alterar"
  - form "Alterar senha":
    - heading "Alterar senha" [level=2]
    - paragraph: Após salvar, todas as sessões serão encerradas. Entre novamente com a nova senha. Sua coleção e seus pedidos serão preservados.
    - text: Senha atual
    - textbox "Senha atual"
    - paragraph
    - text: Nova senha
    - textbox "Nova senha"
    - paragraph
    - text: Confirmar nova senha
    - textbox "Confirmar nova senha"
    - paragraph
    - button "Alterar senha e sair"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {add,login,reset,request,openCheckoutItems} from './helpers/market'
  3  | test.beforeEach(async({page})=>reset(page))
  4  | test('artes originais acompanham detalhe, favoritos, carrinho e checkout pela API',async({page})=>{
  5  |  await login(page,'alice','/favoritos'); await add(page)
  6  |  await expect(page.locator('.detail-art img')).toHaveAttribute('src','/assets/figma/home/sage-nomad.webp')
  7  |  await page.getByRole('button',{name:'Adicionar aos favoritos',exact:true}).click()
  8  |  await expect(page.getByRole('button',{name:'Remover dos favoritos',exact:true})).toBeEnabled()
  9  |  await page.goto('/favoritos');await expect(page.locator('.nft-card img:visible')).toHaveCount(1)
  10 |  await page.goto('/carrinho');await expect(page.locator('.cart-art img')).toHaveAttribute('src','/assets/figma/home/sage-nomad.webp')
  11 |  await page.goto('/checkout');await openCheckoutItems(page);await expect(page.locator('.checkout-art img')).toHaveAttribute('src','/assets/figma/home/sage-nomad.webp')
  12 |  expect(await page.locator('.checkout-art img').evaluate((image:HTMLImageElement)=>image.complete&&image.naturalWidth>0)).toBe(true)
  13 |  expect((await request(page,'/api/cart','GET')).body.items[0].quantity).toBe(1)
  14 | })
  15 | test('stepper respeita estoque e atualiza cotação real sem cálculo local',async({page})=>{
  16 |  await add(page);await page.goto('/carrinho')
  17 |  const row=page.getByTestId('cart-item');await row.getByRole('button',{name:'Aumentar quantidade de Sage Nomad #002'}).click()
  18 |  await expect(row.getByLabel('Quantidade',{exact:true})).toHaveValue('2');await expect(page.getByTestId('subtotal')).toHaveText('0.58 ETH')
  19 |  await page.reload();await expect(page.getByTestId('cart-item').getByLabel('Quantidade',{exact:true})).toHaveValue('2')
  20 | })
  21 | test('header e menu da conta permanecem disponíveis no detalhe, sem navegação antiga',async({page})=>{
  22 |  await login(page,'alice','/nfts/nft-002')
  23 |  if((page.viewportSize()?.width??0)>=1024){
  24 |   await expect(page.getByRole('navigation',{name:'Navegação principal'}).getByRole('link',{name:'Mercado',exact:true})).toHaveClass(/is-active/)
  25 |   await page.locator('.desktop-account summary').click();await page.locator('.desktop-account').getByRole('link',{name:'Perfil',exact:true}).click()
  26 |  }else{
  27 |   await page.getByRole('button',{name:'Abrir menu'}).click();await page.getByRole('navigation',{name:'Navegação principal'}).getByRole('link',{name:'Perfil',exact:true}).click()
  28 |  }
  29 |  await expect(page.getByRole('heading',{name:'Perfil do colecionador',exact:true})).toBeVisible()
  30 |  await expect(page.locator('.kurio-header')).toHaveCount(0)
  31 | })
  32 | test('login usa composição desktop ou mobile sem fingir OAuth',async({page})=>{
  33 |  if((page.viewportSize()?.width??0)>=1024){await expect(page.getByRole('dialog')).toBeVisible();await expect(page.locator('.auth-backdrop .nft-card')).toHaveCount(9)}
  34 |  else{await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.auth-wordmark')).toHaveText('KURIO')}
  35 |  await page.getByRole('button',{name:'Continuar com Google'}).click();await expect(page.getByRole('status').filter({hasText:'indisponível'})).toBeVisible()
  36 |  await expect(page.getByLabel('Usuário conectado')).toHaveCount(0)
  37 | })
  38 | 
  39 | test('provedor selecionado usa a carteira persistida e não atravessa contas',async({page})=>{
  40 |  await login(page);await add(page)
  41 |  const mobile=(page.viewportSize()?.width??0)<1024
  42 |  await page.goto(mobile?'/checkout':'/carteiras')
  43 |  const saved=page.waitForResponse(response=>new URL(response.url()).pathname.startsWith('/api/wallets/')&&response.request().method()==='PATCH')
  44 |  if(mobile) await page.getByRole('button',{name:'Coinbase Wallet',exact:true}).click()
  45 |  else {await page.getByLabel('Tipo de carteira',{exact:true}).selectOption('coinbase');await page.getByRole('button',{name:'Salvar carteira',exact:true}).click()}
  46 |  expect((await saved).status()).toBe(200)
  47 |  expect((await request(page,'/api/wallets','GET')).body.items[0].provider).toBe('coinbase')
  48 |  await page.reload()
  49 |  if(mobile) await expect(page.getByRole('button',{name:'Coinbase Wallet',exact:true})).toHaveAttribute('aria-pressed','true')
  50 |  else await expect(page.getByLabel('Tipo de carteira',{exact:true})).toHaveValue('coinbase')
  51 |  await login(page,'bob','/carteiras');expect((await request(page,'/api/wallets','GET')).body.items[0].provider).toBe('metamask')
  52 | })
  53 | test('ENS e apelido do perfil gravam na carteira vinculada pela API',async({page})=>{
  54 |  await login(page,'alice','/perfil')
  55 |  await page.getByLabel('Nome ENS',{exact:true}).fill('nova-alice.eth')
  56 |  await page.getByLabel('Apelido da carteira',{exact:true}).fill('Coleção principal')
  57 |  await page.getByRole('button',{name:'Salvar carteira vinculada',exact:true}).click()
> 58 |  await expect(page.getByText('Carteira vinculada atualizada.',{exact:true})).toBeVisible()
     |                                                                              ^ Error: expect(locator).toBeVisible() failed
  59 |  const wallet=(await request(page,'/api/wallets','GET')).body.items[0]
  60 |  expect(wallet.collector.ensName).toBe('nova-alice.eth');expect(wallet.label).toBe('Coleção principal')
  61 |  await page.reload();await expect(page.getByLabel('Nome ENS',{exact:true})).toHaveValue('nova-alice.eth')
  62 | })
  63 | 
```