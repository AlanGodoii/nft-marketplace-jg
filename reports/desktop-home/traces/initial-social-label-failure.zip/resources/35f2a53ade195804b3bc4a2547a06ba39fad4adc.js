import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/route-error.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { ErrorState } from "/src/components/async-state.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/route-error.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function RouteError() {
	_s();
	const router = useRouter();
	return /* @__PURE__ */ _jsxDEV(ErrorState, {
		message: "Não foi possível carregar esta página ou verificar a sessão.",
		retry: () => void router.invalidate()
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 10
	}, this);
}
_s(RouteError, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
	return [useRouter];
});
_c = RouteError;
var _c;
$RefreshReg$(_c, "RouteError");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/route-error.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/route-error.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/route-error.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/route-error.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxrQkFBa0I7Ozs7QUFDM0IsT0FBTyxTQUFTLGFBQWE7O0NBQzNCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE9BQU8sd0JBQUMsWUFBRDtFQUFZLFNBQVE7RUFBK0QsYUFBYSxLQUFLLE9BQU8sV0FBVztDQUFJOzs7OztBQUNwSSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJyb3V0ZS1lcnJvci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IEVycm9yU3RhdGUgfSBmcm9tICcuL2FzeW5jLXN0YXRlJ1xuZXhwb3J0IGZ1bmN0aW9uIFJvdXRlRXJyb3IoKSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIHJldHVybiA8RXJyb3JTdGF0ZSBtZXNzYWdlPVwiTsOjbyBmb2kgcG9zc8OtdmVsIGNhcnJlZ2FyIGVzdGEgcMOhZ2luYSBvdSB2ZXJpZmljYXIgYSBzZXNzw6NvLlwiIHJldHJ5PXsoKSA9PiB2b2lkIHJvdXRlci5pbnZhbGlkYXRlKCl9IC8+XG59XG4iXX0=