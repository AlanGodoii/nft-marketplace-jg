import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/catalog-filters.tsx");const useId = __vite__cjsImport0_react["useId"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { SlidersHorizontal } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-filters.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function CatalogFilters({ filters, onFiltersChange, collections, networks, disabled, facets }) {
	_s();
	const id = useId();
	const update = (patch) => onFiltersChange({
		...filters,
		...patch
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "catalog-filters",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "filter-top flex items-center justify-between gap-4 border-b pb-6",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "flex items-center gap-3 text-lg font-bold",
					children: [/* @__PURE__ */ _jsxDEV(SlidersHorizontal, {
						"aria-hidden": "true",
						className: "size-5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 67
					}, this), "Filtros"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					variant: "link",
					className: "px-0 text-xs",
					disabled,
					onClick: () => update({
						collection: "",
						network: "",
						minPrice: "",
						maxPrice: "",
						availableOnly: false
					}),
					children: "Limpar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", {
				disabled,
				"aria-describedby": disabled ? `${id}-filters-unavailable` : undefined,
				className: "space-y-7 pt-6 disabled:opacity-60",
				children: [
					/* @__PURE__ */ _jsxDEV("legend", {
						className: "sr-only",
						children: "Filtrar catálogo de NFTs"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "filter-collection",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "desktop-home-only filter-label",
								children: "Coleções"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 29,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "desktop-home-only filter-option-list",
								children: collections.map((option) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									"aria-pressed": filters.collection === option.id,
									onClick: () => update({ collection: filters.collection === option.id ? "" : option.id }),
									children: [/* @__PURE__ */ _jsxDEV("span", { children: option.name }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 30,
										columnNumber: 268
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: facets?.collections[option.id] !== undefined ? `(${facets.collections[option.id]})` : "" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 30,
										columnNumber: 294
									}, this)]
								}, option.id, true, {
									fileName: _jsxFileName,
									lineNumber: 30,
									columnNumber: 92
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 30,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: `${id}-collection`,
								className: "mb-4 block text-sm font-medium",
								children: "Coleção"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("select", {
								id: `${id}-collection`,
								className: "kurio-select w-full",
								value: filters.collection,
								onChange: (event) => update({ collection: event.target.value }),
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Todas as coleções"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 33,
										columnNumber: 13
									}, this),
									filters.collection && !collections.some((option) => option.id === filters.collection) && /* @__PURE__ */ _jsxDEV("option", {
										value: filters.collection,
										children: filters.collection
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 34,
										columnNumber: 101
									}, this),
									collections.map((option) => /* @__PURE__ */ _jsxDEV("option", {
										value: option.id,
										children: option.name
									}, option.id, false, {
										fileName: _jsxFileName,
										lineNumber: 35,
										columnNumber: 40
									}, this))
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "filter-network",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "desktop-home-only filter-label",
								children: "Rede"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 39,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "desktop-home-only filter-option-list",
								children: networks.map((option) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									"aria-pressed": filters.network === option.id,
									onClick: () => update({ network: filters.network === option.id ? "" : option.id }),
									children: [/* @__PURE__ */ _jsxDEV("span", { children: option.name }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 40,
										columnNumber: 256
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: facets?.networks[option.id] !== undefined ? `(${facets.networks[option.id]})` : "" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 40,
										columnNumber: 282
									}, this)]
								}, option.id, true, {
									fileName: _jsxFileName,
									lineNumber: 40,
									columnNumber: 89
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: `${id}-network`,
								className: "mb-4 block text-sm font-medium",
								children: "Rede"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("select", {
								id: `${id}-network`,
								className: "kurio-select w-full",
								value: filters.network,
								onChange: (event) => update({ network: event.target.value }),
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Todas as redes"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 43,
										columnNumber: 13
									}, this),
									filters.network && !networks.some((option) => option.id === filters.network) && /* @__PURE__ */ _jsxDEV("option", {
										value: filters.network,
										children: filters.network
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 44,
										columnNumber: 92
									}, this),
									networks.map((option) => /* @__PURE__ */ _jsxDEV("option", {
										value: option.id,
										children: option.name
									}, option.id, false, {
										fileName: _jsxFileName,
										lineNumber: 45,
										columnNumber: 37
									}, this))
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 42,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "filter-price border-t pt-6",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								id: `${id}-price-label`,
								className: "mb-4 text-sm font-medium",
								children: "Faixa de preço"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								className: "desktop-home-only price-range",
								type: "range",
								"aria-label": "Limite de preço em ETH",
								min: "0",
								max: "3",
								step: "0.01",
								value: filters.maxPrice || "3",
								onChange: (event) => update({ maxPrice: event.target.value })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3",
								role: "group",
								"aria-labelledby": `${id}-price-label`,
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									htmlFor: `${id}-min-price`,
									className: "mb-2 block text-xs text-muted-foreground",
									children: "Mínimo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 18
								}, this), /* @__PURE__ */ _jsxDEV(Input, {
									id: `${id}-min-price`,
									type: "number",
									min: "0",
									step: "any",
									placeholder: "Mínimo",
									value: filters.minPrice,
									onChange: (event) => update({ minPrice: event.target.value }),
									className: "h-11 rounded-sm"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									htmlFor: `${id}-max-price`,
									className: "mb-2 block text-xs text-muted-foreground",
									children: "Máximo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 56,
									columnNumber: 18
								}, this), /* @__PURE__ */ _jsxDEV(Input, {
									id: `${id}-max-price`,
									type: "number",
									min: "0",
									step: "any",
									placeholder: "Máximo",
									value: filters.maxPrice,
									onChange: (event) => update({ maxPrice: event.target.value }),
									className: "h-11 rounded-sm"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 57,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 56,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								className: "desktop-home-only apply-price",
								type: "button",
								onClick: () => update({
									minPrice: filters.minPrice,
									maxPrice: filters.maxPrice
								}),
								children: "Aplicar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "filter-availability border-t pt-6",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "mb-4 text-sm font-medium",
							children: "Disponibilidade"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("label", {
							className: "flex items-center gap-3 text-sm text-muted-foreground",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								className: "size-4 accent-primary",
								checked: filters.availableOnly,
								onChange: (event) => update({ availableOnly: event.target.checked })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 13
							}, this), "Disponíveis para compra"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 7
			}, this),
			disabled && /* @__PURE__ */ _jsxDEV("p", {
				id: `${id}-filters-unavailable`,
				className: "mt-6 text-xs leading-6 text-muted-foreground",
				children: "Os filtros serão habilitados quando o catálogo estiver disponível."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 20
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_s(CatalogFilters, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=");
_c = CatalogFilters;
var _c;
$RefreshReg$(_c, "CatalogFilters");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/components/catalog-filters.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-filters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-filters.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBQ3RCLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsY0FBYztBQUN2QixTQUFTLGFBQWE7Ozs7QUFXdEIsT0FBTyxTQUFTLGVBQWUsRUFBRSxTQUFTLGlCQUFpQixhQUFhLFVBQVUsVUFBVSxVQUFpQjs7Q0FDM0csTUFBTSxLQUFLLE1BQU07Q0FDakIsTUFBTSxVQUFVLFVBQW1DLGdCQUFnQjtFQUFFLEdBQUc7RUFBUyxHQUFHO0NBQU0sQ0FBQztDQUMzRixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUEwRCx3QkFBQyxtQkFBRDtNQUFtQixlQUFZO01BQU8sV0FBVTtLQUFVOzs7O2VBQUMsU0FBVzs7Ozs7Y0FDaEksd0JBQUMsUUFBRDtLQUFRLFNBQVE7S0FBTyxXQUFVO0tBQXlCO0tBQVUsZUFBZSxPQUFPO01BQ3hGLFlBQVk7TUFBSSxTQUFTO01BQUksVUFBVTtNQUFJLFVBQVU7TUFBSSxlQUFlO0tBQzFFLENBQUM7ZUFBRztJQUFjOzs7O1lBQ2Y7Ozs7OztHQUNMLHdCQUFDLFlBQUQ7SUFBb0I7SUFBVSxvQkFBa0IsV0FBVyxHQUFHLEdBQUcsd0JBQXdCO0lBQVcsV0FBVTtjQUE5RztLQUNFLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO2dCQUFVO0tBQWdDOzs7OztLQUM1RCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFpQztPQUFXOzs7OztPQUN6RCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBd0MsWUFBWSxLQUFJLFdBQVUsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBeUIsZ0JBQWMsUUFBUSxlQUFlLE9BQU87U0FBSSxlQUFlLE9BQU8sRUFBRSxZQUFZLFFBQVEsZUFBZSxPQUFPLEtBQUssS0FBSyxPQUFPLEdBQUcsQ0FBQzttQkFBN0ssQ0FBZ0wsd0JBQUMsUUFBRCxZQUFPLE9BQU8sS0FBVzs7OzttQkFBQyx3QkFBQyxRQUFELFlBQU8sUUFBUSxZQUFZLE9BQU8sUUFBUSxZQUFZLElBQUksT0FBTyxZQUFZLE9BQU8sSUFBSSxLQUFLLEdBQVM7Ozs7aUJBQVM7V0FBOVIsT0FBTzs7OztlQUF1UixDQUFDO09BQU87Ozs7O09BQ2xaLHdCQUFDLFNBQUQ7UUFBTyxTQUFTLEdBQUcsR0FBRztRQUFjLFdBQVU7a0JBQWlDO09BQWM7Ozs7O09BQzdGLHdCQUFDLFVBQUQ7UUFBUSxJQUFJLEdBQUcsR0FBRztRQUFjLFdBQVU7UUFBc0IsT0FBTyxRQUFRO1FBQVksV0FBVSxVQUFTLE9BQU8sRUFBRSxZQUFZLE1BQU0sT0FBTyxNQUFNLENBQUM7a0JBQXZKO1NBQ0Usd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQUc7U0FBeUI7Ozs7O1NBQ3pDLFFBQVEsY0FBYyxDQUFDLFlBQVksTUFBSyxXQUFVLE9BQU8sT0FBTyxRQUFRLFVBQVUsS0FBSyx3QkFBQyxVQUFEO1VBQVEsT0FBTyxRQUFRO29CQUFhLFFBQVE7U0FBbUI7Ozs7O1NBQ3RKLFlBQVksS0FBSSxXQUFVLHdCQUFDLFVBQUQ7VUFBd0IsT0FBTyxPQUFPO29CQUFLLE9BQU87U0FBYSxHQUFsRCxPQUFPOzs7O2dCQUEyQyxDQUFDO1FBQ3JGOzs7Ozs7TUFDTDs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBaUM7T0FBTzs7Ozs7T0FDckQsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQXdDLFNBQVMsS0FBSSxXQUFVLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQXlCLGdCQUFjLFFBQVEsWUFBWSxPQUFPO1NBQUksZUFBZSxPQUFPLEVBQUUsU0FBUyxRQUFRLFlBQVksT0FBTyxLQUFLLEtBQUssT0FBTyxHQUFHLENBQUM7bUJBQXBLLENBQXVLLHdCQUFDLFFBQUQsWUFBTyxPQUFPLEtBQVc7Ozs7bUJBQUMsd0JBQUMsUUFBRCxZQUFPLFFBQVEsU0FBUyxPQUFPLFFBQVEsWUFBWSxJQUFJLE9BQU8sU0FBUyxPQUFPLElBQUksS0FBSyxHQUFTOzs7O2lCQUFTO1dBQS9RLE9BQU87Ozs7ZUFBd1EsQ0FBQztPQUFPOzs7OztPQUNoWSx3QkFBQyxTQUFEO1FBQU8sU0FBUyxHQUFHLEdBQUc7UUFBVyxXQUFVO2tCQUFpQztPQUFXOzs7OztPQUN2Rix3QkFBQyxVQUFEO1FBQVEsSUFBSSxHQUFHLEdBQUc7UUFBVyxXQUFVO1FBQXNCLE9BQU8sUUFBUTtRQUFTLFdBQVUsVUFBUyxPQUFPLEVBQUUsU0FBUyxNQUFNLE9BQU8sTUFBTSxDQUFDO2tCQUE5STtTQUNFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFHO1NBQXNCOzs7OztTQUN0QyxRQUFRLFdBQVcsQ0FBQyxTQUFTLE1BQUssV0FBVSxPQUFPLE9BQU8sUUFBUSxPQUFPLEtBQUssd0JBQUMsVUFBRDtVQUFRLE9BQU8sUUFBUTtvQkFBVSxRQUFRO1NBQWdCOzs7OztTQUN2SSxTQUFTLEtBQUksV0FBVSx3QkFBQyxVQUFEO1VBQXdCLE9BQU8sT0FBTztvQkFBSyxPQUFPO1NBQWEsR0FBbEQsT0FBTzs7OztnQkFBMkMsQ0FBQztRQUNsRjs7Ozs7O01BQ0w7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsS0FBRDtRQUFHLElBQUksR0FBRyxHQUFHO1FBQWUsV0FBVTtrQkFBMkI7T0FBaUI7Ozs7O09BQ2xGLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO1FBQWdDLE1BQUs7UUFBUSxjQUFXO1FBQXlCLEtBQUk7UUFBSSxLQUFJO1FBQUksTUFBSztRQUFPLE9BQU8sUUFBUSxZQUFZO1FBQUssV0FBVSxVQUFTLE9BQU8sRUFBRSxVQUFVLE1BQU0sT0FBTyxNQUFNLENBQUM7T0FBSTs7Ozs7T0FDNU4sd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBeUIsTUFBSztRQUFRLG1CQUFpQixHQUFHLEdBQUc7a0JBQTVFLENBQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQ7U0FBTyxTQUFTLEdBQUcsR0FBRztTQUFhLFdBQVU7bUJBQTJDO1FBQWE7Ozs7a0JBQ3hHLHdCQUFDLE9BQUQ7U0FBTyxJQUFJLEdBQUcsR0FBRztTQUFhLE1BQUs7U0FBUyxLQUFJO1NBQUksTUFBSztTQUFNLGFBQVk7U0FBUyxPQUFPLFFBQVE7U0FDakcsV0FBVSxVQUFTLE9BQU8sRUFBRSxVQUFVLE1BQU0sT0FBTyxNQUFNLENBQUM7U0FBRyxXQUFVO1FBQW1COzs7O2dCQUN6Rjs7OztrQkFDTCx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRDtTQUFPLFNBQVMsR0FBRyxHQUFHO1NBQWEsV0FBVTttQkFBMkM7UUFBYTs7OztrQkFDeEcsd0JBQUMsT0FBRDtTQUFPLElBQUksR0FBRyxHQUFHO1NBQWEsTUFBSztTQUFTLEtBQUk7U0FBSSxNQUFLO1NBQU0sYUFBWTtTQUFTLE9BQU8sUUFBUTtTQUNqRyxXQUFVLFVBQVMsT0FBTyxFQUFFLFVBQVUsTUFBTSxPQUFPLE1BQU0sQ0FBQztTQUFHLFdBQVU7UUFBbUI7Ozs7Z0JBQ3pGOzs7O2dCQUNGOzs7Ozs7T0FDTCx3QkFBQyxRQUFEO1FBQVEsV0FBVTtRQUFnQyxNQUFLO1FBQVMsZUFBZSxPQUFPO1NBQUUsVUFBVSxRQUFRO1NBQVUsVUFBVSxRQUFRO1FBQVMsQ0FBQztrQkFBRztPQUFlOzs7OztNQUMvSjs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBMkI7TUFBa0I7Ozs7Z0JBQzFELHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxNQUFLO1FBQVcsV0FBVTtRQUF3QixTQUFTLFFBQVE7UUFDeEUsV0FBVSxVQUFTLE9BQU8sRUFBRSxlQUFlLE1BQU0sT0FBTyxRQUFRLENBQUM7T0FBSTs7OztpQkFBQyx5QkFFbkU7Ozs7O2NBQ0o7Ozs7OztJQUNHOzs7Ozs7R0FDVCxZQUFZLHdCQUFDLEtBQUQ7SUFBRyxJQUFJLEdBQUcsR0FBRztJQUF1QixXQUFVO2NBQStDO0dBQXFFOzs7OztFQUM1Szs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiY2F0YWxvZy1maWx0ZXJzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VJZCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgU2xpZGVyc0hvcml6b250YWwgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5pbXBvcnQgdHlwZSB7IENvbGxlY3Rpb24sIE5ldHdvcmsgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnXG5pbXBvcnQgdHlwZSB7IENhdGFsb2dDb250cm9scyB9IGZyb20gJy4uL3R5cGVzJ1xuXG5pbnRlcmZhY2UgUHJvcHMgZXh0ZW5kcyBQaWNrPENhdGFsb2dDb250cm9scywgJ2ZpbHRlcnMnIHwgJ29uRmlsdGVyc0NoYW5nZSc+IHtcbiAgY29sbGVjdGlvbnM6IENvbGxlY3Rpb25bXVxuICBuZXR3b3JrczogTmV0d29ya1tdXG4gIGZhY2V0cz86IHsgY29sbGVjdGlvbnM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj47IG5ldHdvcmtzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+IH1cbiAgZGlzYWJsZWQ6IGJvb2xlYW5cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENhdGFsb2dGaWx0ZXJzKHsgZmlsdGVycywgb25GaWx0ZXJzQ2hhbmdlLCBjb2xsZWN0aW9ucywgbmV0d29ya3MsIGRpc2FibGVkLCBmYWNldHMgfTogUHJvcHMpIHtcbiAgY29uc3QgaWQgPSB1c2VJZCgpXG4gIGNvbnN0IHVwZGF0ZSA9IChwYXRjaDogUGFydGlhbDx0eXBlb2YgZmlsdGVycz4pID0+IG9uRmlsdGVyc0NoYW5nZSh7IC4uLmZpbHRlcnMsIC4uLnBhdGNoIH0pXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjYXRhbG9nLWZpbHRlcnNcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLXRvcCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgYm9yZGVyLWIgcGItNlwiPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdGV4dC1sZyBmb250LWJvbGRcIj48U2xpZGVyc0hvcml6b250YWwgYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwic2l6ZS01XCIgLz5GaWx0cm9zPC9oMj5cbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwibGlua1wiIGNsYXNzTmFtZT1cInB4LTAgdGV4dC14c1wiIGRpc2FibGVkPXtkaXNhYmxlZH0gb25DbGljaz17KCkgPT4gdXBkYXRlKHtcbiAgICAgICAgICBjb2xsZWN0aW9uOiAnJywgbmV0d29yazogJycsIG1pblByaWNlOiAnJywgbWF4UHJpY2U6ICcnLCBhdmFpbGFibGVPbmx5OiBmYWxzZSxcbiAgICAgICAgfSl9PkxpbXBhcjwvQnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZmllbGRzZXQgZGlzYWJsZWQ9e2Rpc2FibGVkfSBhcmlhLWRlc2NyaWJlZGJ5PXtkaXNhYmxlZCA/IGAke2lkfS1maWx0ZXJzLXVuYXZhaWxhYmxlYCA6IHVuZGVmaW5lZH0gY2xhc3NOYW1lPVwic3BhY2UteS03IHB0LTYgZGlzYWJsZWQ6b3BhY2l0eS02MFwiPlxuICAgICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5GaWx0cmFyIGNhdMOhbG9nbyBkZSBORlRzPC9sZWdlbmQ+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLWNvbGxlY3Rpb25cIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJkZXNrdG9wLWhvbWUtb25seSBmaWx0ZXItbGFiZWxcIj5Db2xlw6fDtWVzPC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVza3RvcC1ob21lLW9ubHkgZmlsdGVyLW9wdGlvbi1saXN0XCI+e2NvbGxlY3Rpb25zLm1hcChvcHRpb24gPT4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIga2V5PXtvcHRpb24uaWR9IGFyaWEtcHJlc3NlZD17ZmlsdGVycy5jb2xsZWN0aW9uID09PSBvcHRpb24uaWR9IG9uQ2xpY2s9eygpID0+IHVwZGF0ZSh7IGNvbGxlY3Rpb246IGZpbHRlcnMuY29sbGVjdGlvbiA9PT0gb3B0aW9uLmlkID8gJycgOiBvcHRpb24uaWQgfSl9PjxzcGFuPntvcHRpb24ubmFtZX08L3NwYW4+PHNwYW4+e2ZhY2V0cz8uY29sbGVjdGlvbnNbb3B0aW9uLmlkXSAhPT0gdW5kZWZpbmVkID8gYCgke2ZhY2V0cy5jb2xsZWN0aW9uc1tvcHRpb24uaWRdfSlgIDogJyd9PC9zcGFuPjwvYnV0dG9uPil9PC9kaXY+XG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2Ake2lkfS1jb2xsZWN0aW9uYH0gY2xhc3NOYW1lPVwibWItNCBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+Q29sZcOnw6NvPC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0IGlkPXtgJHtpZH0tY29sbGVjdGlvbmB9IGNsYXNzTmFtZT1cImt1cmlvLXNlbGVjdCB3LWZ1bGxcIiB2YWx1ZT17ZmlsdGVycy5jb2xsZWN0aW9ufSBvbkNoYW5nZT17ZXZlbnQgPT4gdXBkYXRlKHsgY29sbGVjdGlvbjogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfT5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5Ub2RhcyBhcyBjb2xlw6fDtWVzPC9vcHRpb24+XG4gICAgICAgICAgICB7ZmlsdGVycy5jb2xsZWN0aW9uICYmICFjb2xsZWN0aW9ucy5zb21lKG9wdGlvbiA9PiBvcHRpb24uaWQgPT09IGZpbHRlcnMuY29sbGVjdGlvbikgJiYgPG9wdGlvbiB2YWx1ZT17ZmlsdGVycy5jb2xsZWN0aW9ufT57ZmlsdGVycy5jb2xsZWN0aW9ufTwvb3B0aW9uPn1cbiAgICAgICAgICAgIHtjb2xsZWN0aW9ucy5tYXAob3B0aW9uID0+IDxvcHRpb24ga2V5PXtvcHRpb24uaWR9IHZhbHVlPXtvcHRpb24uaWR9PntvcHRpb24ubmFtZX08L29wdGlvbj4pfVxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItbmV0d29ya1wiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImRlc2t0b3AtaG9tZS1vbmx5IGZpbHRlci1sYWJlbFwiPlJlZGU8L3A+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZXNrdG9wLWhvbWUtb25seSBmaWx0ZXItb3B0aW9uLWxpc3RcIj57bmV0d29ya3MubWFwKG9wdGlvbiA9PiA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBrZXk9e29wdGlvbi5pZH0gYXJpYS1wcmVzc2VkPXtmaWx0ZXJzLm5ldHdvcmsgPT09IG9wdGlvbi5pZH0gb25DbGljaz17KCkgPT4gdXBkYXRlKHsgbmV0d29yazogZmlsdGVycy5uZXR3b3JrID09PSBvcHRpb24uaWQgPyAnJyA6IG9wdGlvbi5pZCB9KX0+PHNwYW4+e29wdGlvbi5uYW1lfTwvc3Bhbj48c3Bhbj57ZmFjZXRzPy5uZXR3b3Jrc1tvcHRpb24uaWRdICE9PSB1bmRlZmluZWQgPyBgKCR7ZmFjZXRzLm5ldHdvcmtzW29wdGlvbi5pZF19KWAgOiAnJ308L3NwYW4+PC9idXR0b24+KX08L2Rpdj5cbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YCR7aWR9LW5ldHdvcmtgfSBjbGFzc05hbWU9XCJtYi00IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW1cIj5SZWRlPC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0IGlkPXtgJHtpZH0tbmV0d29ya2B9IGNsYXNzTmFtZT1cImt1cmlvLXNlbGVjdCB3LWZ1bGxcIiB2YWx1ZT17ZmlsdGVycy5uZXR3b3JrfSBvbkNoYW5nZT17ZXZlbnQgPT4gdXBkYXRlKHsgbmV0d29yazogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfT5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5Ub2RhcyBhcyByZWRlczwvb3B0aW9uPlxuICAgICAgICAgICAge2ZpbHRlcnMubmV0d29yayAmJiAhbmV0d29ya3Muc29tZShvcHRpb24gPT4gb3B0aW9uLmlkID09PSBmaWx0ZXJzLm5ldHdvcmspICYmIDxvcHRpb24gdmFsdWU9e2ZpbHRlcnMubmV0d29ya30+e2ZpbHRlcnMubmV0d29ya308L29wdGlvbj59XG4gICAgICAgICAgICB7bmV0d29ya3MubWFwKG9wdGlvbiA9PiA8b3B0aW9uIGtleT17b3B0aW9uLmlkfSB2YWx1ZT17b3B0aW9uLmlkfT57b3B0aW9uLm5hbWV9PC9vcHRpb24+KX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLXByaWNlIGJvcmRlci10IHB0LTZcIj5cbiAgICAgICAgICA8cCBpZD17YCR7aWR9LXByaWNlLWxhYmVsYH0gY2xhc3NOYW1lPVwibWItNCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+RmFpeGEgZGUgcHJlw6dvPC9wPlxuICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9XCJkZXNrdG9wLWhvbWUtb25seSBwcmljZS1yYW5nZVwiIHR5cGU9XCJyYW5nZVwiIGFyaWEtbGFiZWw9XCJMaW1pdGUgZGUgcHJlw6dvIGVtIEVUSFwiIG1pbj1cIjBcIiBtYXg9XCIzXCIgc3RlcD1cIjAuMDFcIiB2YWx1ZT17ZmlsdGVycy5tYXhQcmljZSB8fCAnMyd9IG9uQ2hhbmdlPXtldmVudCA9PiB1cGRhdGUoeyBtYXhQcmljZTogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfSAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWxsZWRieT17YCR7aWR9LXByaWNlLWxhYmVsYH0+XG4gICAgICAgICAgICA8ZGl2PjxsYWJlbCBodG1sRm9yPXtgJHtpZH0tbWluLXByaWNlYH0gY2xhc3NOYW1lPVwibWItMiBibG9jayB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk3DrW5pbW88L2xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXQgaWQ9e2Ake2lkfS1taW4tcHJpY2VgfSB0eXBlPVwibnVtYmVyXCIgbWluPVwiMFwiIHN0ZXA9XCJhbnlcIiBwbGFjZWhvbGRlcj1cIk3DrW5pbW9cIiB2YWx1ZT17ZmlsdGVycy5taW5QcmljZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gdXBkYXRlKHsgbWluUHJpY2U6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX0gY2xhc3NOYW1lPVwiaC0xMSByb3VuZGVkLXNtXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj48bGFiZWwgaHRtbEZvcj17YCR7aWR9LW1heC1wcmljZWB9IGNsYXNzTmFtZT1cIm1iLTIgYmxvY2sgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5Nw6F4aW1vPC9sYWJlbD5cbiAgICAgICAgICAgICAgPElucHV0IGlkPXtgJHtpZH0tbWF4LXByaWNlYH0gdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBzdGVwPVwiYW55XCIgcGxhY2Vob2xkZXI9XCJNw6F4aW1vXCIgdmFsdWU9e2ZpbHRlcnMubWF4UHJpY2V9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2V2ZW50ID0+IHVwZGF0ZSh7IG1heFByaWNlOiBldmVudC50YXJnZXQudmFsdWUgfSl9IGNsYXNzTmFtZT1cImgtMTEgcm91bmRlZC1zbVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8QnV0dG9uIGNsYXNzTmFtZT1cImRlc2t0b3AtaG9tZS1vbmx5IGFwcGx5LXByaWNlXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHVwZGF0ZSh7IG1pblByaWNlOiBmaWx0ZXJzLm1pblByaWNlLCBtYXhQcmljZTogZmlsdGVycy5tYXhQcmljZSB9KX0+QXBsaWNhcjwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItYXZhaWxhYmlsaXR5IGJvcmRlci10IHB0LTZcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi00IHRleHQtc20gZm9udC1tZWRpdW1cIj5EaXNwb25pYmlsaWRhZGU8L3A+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2xhc3NOYW1lPVwic2l6ZS00IGFjY2VudC1wcmltYXJ5XCIgY2hlY2tlZD17ZmlsdGVycy5hdmFpbGFibGVPbmx5fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gdXBkYXRlKHsgYXZhaWxhYmxlT25seTogZXZlbnQudGFyZ2V0LmNoZWNrZWQgfSl9IC8+XG4gICAgICAgICAgICBEaXNwb27DrXZlaXMgcGFyYSBjb21wcmFcbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICB7ZGlzYWJsZWQgJiYgPHAgaWQ9e2Ake2lkfS1maWx0ZXJzLXVuYXZhaWxhYmxlYH0gY2xhc3NOYW1lPVwibXQtNiB0ZXh0LXhzIGxlYWRpbmctNiB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5PcyBmaWx0cm9zIHNlcsOjbyBoYWJpbGl0YWRvcyBxdWFuZG8gbyBjYXTDoWxvZ28gZXN0aXZlciBkaXNwb27DrXZlbC48L3A+fVxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=