import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/not-found.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { buttonVariants } from "/src/components/ui/button.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/not-found.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function NotFound() {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-3xl font-semibold",
				children: "Página não encontrada"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-muted-foreground",
				children: "O endereço acessado não existe."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				className: buttonVariants(),
				children: "Voltar ao início"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = NotFound;
var _c;
$RefreshReg$(_c, "NotFound");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/not-found.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/not-found.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/not-found.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/not-found.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsc0JBQXNCOzs7QUFFL0IsT0FBTyxTQUFTLFdBQVc7Q0FDekIsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXlCO0dBQXlCOzs7OztHQUNoRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF3QjtHQUFrQzs7Ozs7R0FDdkUsd0JBQUMsTUFBRDtJQUFNLElBQUc7SUFBSSxXQUFXLGVBQWU7Y0FBRztHQUFzQjs7Ozs7RUFDekQ7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm5vdC1mb3VuZC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBidXR0b25WYXJpYW50cyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5cbmV4cG9ydCBmdW5jdGlvbiBOb3RGb3VuZCgpIHtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LXNlbWlib2xkXCI+UMOhZ2luYSBuw6NvIGVuY29udHJhZGE8L2gxPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+TyBlbmRlcmXDp28gYWNlc3NhZG8gbsOjbyBleGlzdGUuPC9wPlxuICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPXtidXR0b25WYXJpYW50cygpfT5Wb2x0YXIgYW8gaW7DrWNpbzwvTGluaz5cbiAgICA8L3NlY3Rpb24+XG4gIClcbn1cbiJdfQ==