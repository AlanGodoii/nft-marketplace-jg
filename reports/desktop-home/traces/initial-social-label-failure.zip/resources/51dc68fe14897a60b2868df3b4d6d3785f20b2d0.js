import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/header.tsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import { AuthActions } from "/src/features/auth/auth-actions.tsx";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { useDesktop } from "/src/lib/use-desktop.ts";
import { Link, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { Menu, ShoppingBag, X } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { DesktopHomeHeader } from "/src/components/layout/desktop-home-header.tsx?t=1793942997328";
import { Button, buttonVariants } from "/src/components/ui/button.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/layout/header.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
const links = [
	{
		to: "/",
		label: "Início"
	},
	{
		to: "/perfil",
		label: "Perfil"
	},
	{
		to: "/carteiras",
		label: "Carteiras"
	},
	{
		to: "/favoritos",
		label: "Favoritos"
	},
	{
		to: "/login",
		label: "Entrar"
	},
	{
		to: "/cadastro",
		label: "Cadastrar"
	}
];
export function Header() {
	_s();
	const [menuOpen, setMenuOpen] = useState(false);
	const desktop = useDesktop();
	const isHome = useRouterState({ select: (state) => state.location.pathname === "/" });
	if (desktop && isHome) return /* @__PURE__ */ _jsxDEV(DesktopHomeHeader, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 33
	}, this);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("header", {
		className: "kurio-header legacy-header",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "kurio-container header-inner",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					"aria-label": "Kurio — início",
					className: "kurio-wordmark",
					onClick: () => setMenuOpen(false),
					children: ["kurio", /* @__PURE__ */ _jsxDEV("span", {
						"aria-hidden": "true",
						children: "."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 117
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					id: "main-navigation",
					"aria-label": "Navegação principal",
					className: `header-links ${menuOpen ? "is-open" : ""}`,
					children: links.map(({ to, label }) => /* @__PURE__ */ _jsxDEV(Link, {
						to,
						activeOptions: { exact: true },
						className: "header-link",
						activeProps: {
							className: "is-active",
							"aria-current": "page"
						},
						onClick: () => setMenuOpen(false),
						children: label
					}, to, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex shrink-0 items-center gap-3",
					children: [
						/* @__PURE__ */ _jsxDEV(AuthActions, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 59
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/carrinho",
							"aria-label": "Carrinho",
							className: buttonVariants({
								variant: "outline",
								className: "size-11 rounded-sm"
							}),
							onClick: () => setMenuOpen(false),
							children: /* @__PURE__ */ _jsxDEV(ShoppingBag, {
								"aria-hidden": "true",
								className: "size-5"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							variant: "outline",
							className: "mobile-menu-toggle size-11 rounded-sm",
							"aria-label": menuOpen ? "Fechar menu" : "Abrir menu",
							"aria-controls": "main-navigation",
							"aria-expanded": menuOpen,
							onClick: () => setMenuOpen(!menuOpen),
							children: menuOpen ? /* @__PURE__ */ _jsxDEV(X, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 25
							}, this) : /* @__PURE__ */ _jsxDEV(Menu, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 52
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_s(Header, "b28ZNaBXGqPf4LbADhKfF58vGGs=", false, function() {
	return [useDesktop, useRouterState];
});
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/header.tsx?t=1793942997328";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/layout/header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/layout/header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/layout/header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxNQUFNLHNCQUFzQjtBQUNyQyxTQUFTLE1BQU0sYUFBYSxTQUFTO0FBQ3JDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsUUFBUSxzQkFBc0I7Ozs7QUFFdkMsTUFBTSxRQUFRO0NBQ1o7RUFBRSxJQUFJO0VBQUssT0FBTztDQUFTO0NBQzNCO0VBQUUsSUFBSTtFQUFXLE9BQU87Q0FBUztDQUNqQztFQUFFLElBQUk7RUFBYyxPQUFPO0NBQVk7Q0FDdkM7RUFBRSxJQUFJO0VBQWMsT0FBTztDQUFZO0NBQ3ZDO0VBQUUsSUFBSTtFQUFVLE9BQU87Q0FBUztDQUNoQztFQUFFLElBQUk7RUFBYSxPQUFPO0NBQVk7QUFDeEM7QUFFQSxPQUFPLFNBQVMsU0FBUzs7Q0FDdkIsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEtBQUs7Q0FDOUMsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsTUFBTSxTQUFTLGVBQWUsRUFBRSxTQUFRLFVBQVMsTUFBTSxTQUFTLGFBQWEsSUFBSSxDQUFDO0NBQ2xGLElBQUksV0FBVyxRQUFRLE9BQU8sd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O0NBQ2xELE9BQ0UsK0NBQ0Esd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFDaEIsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO0tBQUksY0FBVztLQUFpQixXQUFVO0tBQWlCLGVBQWUsWUFBWSxLQUFLO2VBQXBHLENBQXVHLFNBQUssd0JBQUMsUUFBRDtNQUFNLGVBQVk7Z0JBQU87S0FBTzs7OzthQUFPOzs7Ozs7SUFDbkosd0JBQUMsT0FBRDtLQUFLLElBQUc7S0FBa0IsY0FBVztLQUFzQixXQUFXLGdCQUFnQixXQUFXLFlBQVk7ZUFDMUcsTUFBTSxLQUFLLEVBQUUsSUFBSSxZQUNoQix3QkFBQyxNQUFEO01BQW1CO01BQUksZUFBZSxFQUFFLE9BQU8sS0FBSztNQUFHLFdBQVU7TUFDL0QsYUFBYTtPQUFFLFdBQVc7T0FBYSxnQkFBZ0I7TUFBTztNQUM5RCxlQUFlLFlBQVksS0FBSztnQkFBSTtLQUFZLEdBRnZDOzs7O1lBRXVDLENBQ25EO0lBQ0U7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUFrRCx3QkFBQyxhQUFELENBQWM7Ozs7O01BQzlELHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQVksY0FBVztPQUFXLFdBQVcsZUFBZTtRQUFFLFNBQVM7UUFBVyxXQUFXO09BQXFCLENBQUM7T0FBRyxlQUFlLFlBQVksS0FBSztpQkFDN0osd0JBQUMsYUFBRDtRQUFhLGVBQVk7UUFBTyxXQUFVO09BQVU7Ozs7O01BQ2hEOzs7OztNQUNOLHdCQUFDLFFBQUQ7T0FBUSxTQUFRO09BQVUsV0FBVTtPQUF3QyxjQUFZLFdBQVcsZ0JBQWdCO09BQ2pILGlCQUFjO09BQWtCLGlCQUFlO09BQVUsZUFBZSxZQUFZLENBQUMsUUFBUTtpQkFDNUYsV0FBVyx3QkFBQyxHQUFELEVBQUcsZUFBWSxPQUFROzs7O2tCQUFJLHdCQUFDLE1BQUQsRUFBTSxlQUFZLE9BQVE7Ozs7O01BQzNEOzs7OztLQUNMOzs7Ozs7R0FDRjs7Ozs7O0NBQ0M7Ozs7VUFDTjs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJoZWFkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEF1dGhBY3Rpb25zIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2F1dGgtYWN0aW9ucydcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VEZXNrdG9wIH0gZnJvbSAnQC9saWIvdXNlLWRlc2t0b3AnXG5pbXBvcnQgeyBMaW5rLCB1c2VSb3V0ZXJTdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBNZW51LCBTaG9wcGluZ0JhZywgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IERlc2t0b3BIb21lSGVhZGVyIH0gZnJvbSAnLi9kZXNrdG9wLWhvbWUtaGVhZGVyJ1xuaW1wb3J0IHsgQnV0dG9uLCBidXR0b25WYXJpYW50cyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5cbmNvbnN0IGxpbmtzID0gW1xuICB7IHRvOiAnLycsIGxhYmVsOiAnSW7DrWNpbycgfSxcbiAgeyB0bzogJy9wZXJmaWwnLCBsYWJlbDogJ1BlcmZpbCcgfSxcbiAgeyB0bzogJy9jYXJ0ZWlyYXMnLCBsYWJlbDogJ0NhcnRlaXJhcycgfSxcbiAgeyB0bzogJy9mYXZvcml0b3MnLCBsYWJlbDogJ0Zhdm9yaXRvcycgfSxcbiAgeyB0bzogJy9sb2dpbicsIGxhYmVsOiAnRW50cmFyJyB9LFxuICB7IHRvOiAnL2NhZGFzdHJvJywgbGFiZWw6ICdDYWRhc3RyYXInIH0sXG5dIGFzIGNvbnN0XG5cbmV4cG9ydCBmdW5jdGlvbiBIZWFkZXIoKSB7XG4gIGNvbnN0IFttZW51T3Blbiwgc2V0TWVudU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IGRlc2t0b3AgPSB1c2VEZXNrdG9wKClcbiAgY29uc3QgaXNIb21lID0gdXNlUm91dGVyU3RhdGUoeyBzZWxlY3Q6IHN0YXRlID0+IHN0YXRlLmxvY2F0aW9uLnBhdGhuYW1lID09PSAnLycgfSlcbiAgaWYgKGRlc2t0b3AgJiYgaXNIb21lKSByZXR1cm4gPERlc2t0b3BIb21lSGVhZGVyIC8+XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImt1cmlvLWhlYWRlciBsZWdhY3ktaGVhZGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImt1cmlvLWNvbnRhaW5lciBoZWFkZXItaW5uZXJcIj5cbiAgICAgICAgPExpbmsgdG89XCIvXCIgYXJpYS1sYWJlbD1cIkt1cmlvIOKAlCBpbsOtY2lvXCIgY2xhc3NOYW1lPVwia3VyaW8td29yZG1hcmtcIiBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3BlbihmYWxzZSl9Pmt1cmlvPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+Ljwvc3Bhbj48L0xpbms+XG4gICAgICAgIDxuYXYgaWQ9XCJtYWluLW5hdmlnYXRpb25cIiBhcmlhLWxhYmVsPVwiTmF2ZWdhw6fDo28gcHJpbmNpcGFsXCIgY2xhc3NOYW1lPXtgaGVhZGVyLWxpbmtzICR7bWVudU9wZW4gPyAnaXMtb3BlbicgOiAnJ31gfT5cbiAgICAgICAgICB7bGlua3MubWFwKCh7IHRvLCBsYWJlbCB9KSA9PiAoXG4gICAgICAgICAgICA8TGluayBrZXk9e3RvfSB0bz17dG99IGFjdGl2ZU9wdGlvbnM9e3sgZXhhY3Q6IHRydWUgfX0gY2xhc3NOYW1lPVwiaGVhZGVyLWxpbmtcIlxuICAgICAgICAgICAgICBhY3RpdmVQcm9wcz17eyBjbGFzc05hbWU6ICdpcy1hY3RpdmUnLCAnYXJpYS1jdXJyZW50JzogJ3BhZ2UnIH19XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKGZhbHNlKX0+e2xhYmVsfTwvTGluaz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9uYXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj48QXV0aEFjdGlvbnMgLz5cbiAgICAgICAgICA8TGluayB0bz1cIi9jYXJyaW5ob1wiIGFyaWEtbGFiZWw9XCJDYXJyaW5ob1wiIGNsYXNzTmFtZT17YnV0dG9uVmFyaWFudHMoeyB2YXJpYW50OiAnb3V0bGluZScsIGNsYXNzTmFtZTogJ3NpemUtMTEgcm91bmRlZC1zbScgfSl9IG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgICA8U2hvcHBpbmdCYWcgYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwic2l6ZS01XCIgLz5cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIGNsYXNzTmFtZT1cIm1vYmlsZS1tZW51LXRvZ2dsZSBzaXplLTExIHJvdW5kZWQtc21cIiBhcmlhLWxhYmVsPXttZW51T3BlbiA/ICdGZWNoYXIgbWVudScgOiAnQWJyaXIgbWVudSd9XG4gICAgICAgICAgICBhcmlhLWNvbnRyb2xzPVwibWFpbi1uYXZpZ2F0aW9uXCIgYXJpYS1leHBhbmRlZD17bWVudU9wZW59IG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKCFtZW51T3Blbil9PlxuICAgICAgICAgICAge21lbnVPcGVuID8gPFggYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4gOiA8TWVudSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPn1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2hlYWRlcj5cbiAgICA8Lz5cbiAgKVxufVxuIl19