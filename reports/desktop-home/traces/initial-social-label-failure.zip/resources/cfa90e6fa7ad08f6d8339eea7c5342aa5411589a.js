import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/auth-actions.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { Button } from "/src/components/ui/button.tsx";
import { apiErrorMessage } from "/src/lib/api.ts";
import { logout, useSession } from "/src/features/auth/api.ts";
import { adoptSession } from "/src/features/auth/lifecycle.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/auth/auth-actions.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function AuthActions({ showName = true }) {
	_s();
	const session = useSession();
	const router = useRouter();
	const mutation = useMutation({
		mutationFn: logout,
		retry: false,
		onSuccess: async () => {
			await adoptSession(null, null);
			await router.navigate({ to: "/" });
			await router.invalidate();
		}
	});
	if (!session.data) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "session-actions",
		children: [
			showName && /* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs",
				"aria-label": "Usuário conectado",
				children: session.data.user.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 18
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				disabled: mutation.isPending,
				onClick: () => mutation.mutate(),
				children: "Sair"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 5
			}, this),
			mutation.isError && /* @__PURE__ */ _jsxDEV("span", {
				role: "alert",
				className: "text-xs",
				children: apiErrorMessage(mutation.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 26
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 10
	}, this);
}
_s(AuthActions, "ul8mSdesPlEASlD25M941zdBC3M=", false, function() {
	return [
		useSession,
		useRouter,
		useMutation
	];
});
_c = AuthActions;
var _c;
$RefreshReg$(_c, "AuthActions");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/auth-actions.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/auth/auth-actions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/auth/auth-actions.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/auth/auth-actions.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsUUFBUSxrQkFBa0I7QUFDbkMsU0FBUyxvQkFBb0I7Ozs7QUFDN0IsT0FBTyxTQUFTLFlBQVksRUFBRSxXQUFXLFFBQWdDOztDQUN2RSxNQUFNLFVBQVUsV0FBVztDQUMzQixNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLFdBQVcsWUFBWTtFQUFFLFlBQVk7RUFBUSxPQUFPO0VBQU8sV0FBVyxZQUFZO0dBQ3RGLE1BQU0sYUFBYSxNQUFNLElBQUk7R0FDN0IsTUFBTSxPQUFPLFNBQVMsRUFBRSxJQUFJLElBQUksQ0FBQztHQUNqQyxNQUFNLE9BQU8sV0FBVztFQUMxQjtDQUFFLENBQUM7Q0FDSCxJQUFJLENBQUMsUUFBUSxNQUFNLE9BQU87Q0FDMUIsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0osWUFBWSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtJQUFVLGNBQVc7Y0FBcUIsUUFBUSxLQUFLLEtBQUs7R0FBVzs7Ozs7R0FDcEcsd0JBQUMsUUFBRDtJQUFRLFNBQVE7SUFBVSxVQUFVLFNBQVM7SUFBVyxlQUFlLFNBQVMsT0FBTztjQUFHO0dBQVk7Ozs7O0dBQ3JHLFNBQVMsV0FBVyx3QkFBQyxRQUFEO0lBQU0sTUFBSztJQUFRLFdBQVU7Y0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0dBQVE7Ozs7O0VBQ2hHOzs7Ozs7QUFDUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhdXRoLWFjdGlvbnMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBhcGlFcnJvck1lc3NhZ2UgfSBmcm9tICdAL2xpYi9hcGknXG5pbXBvcnQgeyBsb2dvdXQsIHVzZVNlc3Npb24gfSBmcm9tICcuL2FwaSdcbmltcG9ydCB7IGFkb3B0U2Vzc2lvbiB9IGZyb20gJy4vbGlmZWN5Y2xlJ1xuZXhwb3J0IGZ1bmN0aW9uIEF1dGhBY3Rpb25zKHsgc2hvd05hbWUgPSB0cnVlIH06IHsgc2hvd05hbWU/OiBib29sZWFuIH0pIHtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKVxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuICBjb25zdCBtdXRhdGlvbiA9IHVzZU11dGF0aW9uKHsgbXV0YXRpb25GbjogbG9nb3V0LCByZXRyeTogZmFsc2UsIG9uU3VjY2VzczogYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGFkb3B0U2Vzc2lvbihudWxsLCBudWxsKVxuICAgIGF3YWl0IHJvdXRlci5uYXZpZ2F0ZSh7IHRvOiAnLycgfSlcbiAgICBhd2FpdCByb3V0ZXIuaW52YWxpZGF0ZSgpXG4gIH0gfSlcbiAgaWYgKCFzZXNzaW9uLmRhdGEpIHJldHVybiBudWxsXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInNlc3Npb24tYWN0aW9uc1wiPlxuICAgIHtzaG93TmFtZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCIgYXJpYS1sYWJlbD1cIlVzdcOhcmlvIGNvbmVjdGFkb1wiPntzZXNzaW9uLmRhdGEudXNlci5uYW1lfTwvc3Bhbj59XG4gICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIGRpc2FibGVkPXttdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IG11dGF0aW9uLm11dGF0ZSgpfT5TYWlyPC9CdXR0b24+XG4gICAge211dGF0aW9uLmlzRXJyb3IgJiYgPHNwYW4gcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwidGV4dC14c1wiPnthcGlFcnJvck1lc3NhZ2UobXV0YXRpb24uZXJyb3IpfTwvc3Bhbj59XG4gIDwvZGl2PlxufVxuIl19