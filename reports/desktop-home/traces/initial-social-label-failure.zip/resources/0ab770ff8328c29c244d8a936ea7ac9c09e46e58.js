import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/catalog-grid.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { PackageOpen } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { Button } from "/src/components/ui/button.tsx";
import { NftCard, NftCardSkeleton } from "/src/features/catalog/components/nft-card.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-grid.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function CatalogGrid({ catalog, onRetry }) {
	if (catalog.status === "loading") {
		return /* @__PURE__ */ _jsxDEV("div", {
			role: "status",
			"aria-busy": "true",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: "Carregando catálogo de NFTs"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "nft-grid",
				children: Array.from({ length: 6 }, (_, index) => /* @__PURE__ */ _jsxDEV(NftCardSkeleton, {}, index, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 76
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this);
	}
	if (catalog.status === "success" && catalog.data.items.length > 0) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "nft-grid",
			children: catalog.data.items.map((nft) => /* @__PURE__ */ _jsxDEV(NftCard, { nft }, nft.id, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 69
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 12
		}, this);
	}
	const isError = catalog.status === "error";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "catalog-empty",
		role: isError ? "alert" : "status",
		children: [
			/* @__PURE__ */ _jsxDEV(PackageOpen, {
				"aria-hidden": "true",
				className: "size-10 text-primary"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h3", {
				className: "text-lg font-medium",
				children: isError ? "Não foi possível carregar os NFTs" : catalog.status === "success" ? "Nenhum NFT encontrado" : "Catálogo ainda não disponível"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "max-w-sm text-sm leading-7 text-muted-foreground",
				children: isError ? catalog.message : catalog.status === "success" ? "Tente ajustar os filtros da busca." : "Os NFTs aparecerão aqui quando a fonte de dados estiver conectada."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 7
			}, this),
			isError && onRetry && /* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				onClick: onRetry,
				children: "Tentar novamente"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 30
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
}
_c = CatalogGrid;
var _c;
$RefreshReg$(_c, "CatalogGrid");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/components/catalog-grid.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-grid.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-grid.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-grid.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxjQUFjO0FBRXZCLFNBQVMsU0FBUyx1QkFBdUI7OztBQUV6QyxPQUFPLFNBQVMsWUFBWSxFQUFFLFNBQVMsV0FHcEM7Q0FDRCxJQUFJLFFBQVEsV0FBVyxXQUFXO0VBQ2hDLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLE1BQUs7R0FBUyxhQUFVO2FBQTdCLENBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBVTtHQUFpQzs7OzthQUMzRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFZLE1BQU0sS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJLEdBQUcsVUFBVSx3QkFBQyxpQkFBRCxDQUE4QixHQUFSOzs7O1dBQVEsQ0FBQztHQUFPOzs7O1dBQ3RHOzs7Ozs7Q0FFVDtDQUNBLElBQUksUUFBUSxXQUFXLGFBQWEsUUFBUSxLQUFLLE1BQU0sU0FBUyxHQUFHO0VBQ2pFLE9BQU8sd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBWSxRQUFRLEtBQUssTUFBTSxLQUFJLFFBQU8sd0JBQUMsU0FBRCxFQUFjLElBQW1CLEdBQVQsSUFBSTs7OztVQUFLLENBQUM7RUFBTzs7Ozs7Q0FDM0c7Q0FDQSxNQUFNLFVBQVUsUUFBUSxXQUFXO0NBQ25DLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBZ0IsTUFBTSxVQUFVLFVBQVU7WUFBekQ7R0FDRSx3QkFBQyxhQUFEO0lBQWEsZUFBWTtJQUFPLFdBQVU7R0FBd0I7Ozs7O0dBQ2xFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXVCLFVBQVUsc0NBQXNDLFFBQVEsV0FBVyxZQUFZLDBCQUEwQjtHQUFvQzs7Ozs7R0FDbEwsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixVQUFVLFFBQVEsVUFBVSxRQUFRLFdBQVcsWUFBWSx1Q0FBdUM7R0FDbEc7Ozs7O0dBQ0YsV0FBVyxXQUFXLHdCQUFDLFFBQUQ7SUFBUSxTQUFRO0lBQVUsU0FBUztjQUFTO0dBQXdCOzs7OztFQUN4Rjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiY2F0YWxvZy1ncmlkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYWNrYWdlT3BlbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgdHlwZSB7IENhdGFsb2dQYWdlLCBSZW1vdGVEYXRhIH0gZnJvbSAnLi4vdHlwZXMnXG5pbXBvcnQgeyBOZnRDYXJkLCBOZnRDYXJkU2tlbGV0b24gfSBmcm9tICcuL25mdC1jYXJkJ1xuXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ0dyaWQoeyBjYXRhbG9nLCBvblJldHJ5IH06IHtcbiAgY2F0YWxvZzogUmVtb3RlRGF0YTxDYXRhbG9nUGFnZT5cbiAgb25SZXRyeT86ICgpID0+IHZvaWRcbn0pIHtcbiAgaWYgKGNhdGFsb2cuc3RhdHVzID09PSAnbG9hZGluZycpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiByb2xlPVwic3RhdHVzXCIgYXJpYS1idXN5PVwidHJ1ZVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+Q2FycmVnYW5kbyBjYXTDoWxvZ28gZGUgTkZUczwvc3Bhbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuZnQtZ3JpZFwiPntBcnJheS5mcm9tKHsgbGVuZ3RoOiA2IH0sIChfLCBpbmRleCkgPT4gPE5mdENhcmRTa2VsZXRvbiBrZXk9e2luZGV4fSAvPil9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbiAgaWYgKGNhdGFsb2cuc3RhdHVzID09PSAnc3VjY2VzcycgJiYgY2F0YWxvZy5kYXRhLml0ZW1zLmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJuZnQtZ3JpZFwiPntjYXRhbG9nLmRhdGEuaXRlbXMubWFwKG5mdCA9PiA8TmZ0Q2FyZCBuZnQ9e25mdH0ga2V5PXtuZnQuaWR9IC8+KX08L2Rpdj5cbiAgfVxuICBjb25zdCBpc0Vycm9yID0gY2F0YWxvZy5zdGF0dXMgPT09ICdlcnJvcidcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctZW1wdHlcIiByb2xlPXtpc0Vycm9yID8gJ2FsZXJ0JyA6ICdzdGF0dXMnfT5cbiAgICAgIDxQYWNrYWdlT3BlbiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJzaXplLTEwIHRleHQtcHJpbWFyeVwiIC8+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bVwiPntpc0Vycm9yID8gJ07Do28gZm9pIHBvc3PDrXZlbCBjYXJyZWdhciBvcyBORlRzJyA6IGNhdGFsb2cuc3RhdHVzID09PSAnc3VjY2VzcycgPyAnTmVuaHVtIE5GVCBlbmNvbnRyYWRvJyA6ICdDYXTDoWxvZ28gYWluZGEgbsOjbyBkaXNwb27DrXZlbCd9PC9oMz5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1heC13LXNtIHRleHQtc20gbGVhZGluZy03IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICB7aXNFcnJvciA/IGNhdGFsb2cubWVzc2FnZSA6IGNhdGFsb2cuc3RhdHVzID09PSAnc3VjY2VzcycgPyAnVGVudGUgYWp1c3RhciBvcyBmaWx0cm9zIGRhIGJ1c2NhLicgOiAnT3MgTkZUcyBhcGFyZWNlcsOjbyBhcXVpIHF1YW5kbyBhIGZvbnRlIGRlIGRhZG9zIGVzdGl2ZXIgY29uZWN0YWRhLid9XG4gICAgICA8L3A+XG4gICAgICB7aXNFcnJvciAmJiBvblJldHJ5ICYmIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtvblJldHJ5fT5UZW50YXIgbm92YW1lbnRlPC9CdXR0b24+fVxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=