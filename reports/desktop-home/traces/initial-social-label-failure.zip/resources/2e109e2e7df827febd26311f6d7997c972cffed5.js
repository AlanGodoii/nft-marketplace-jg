import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/desktop-home-header.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link, useNavigate, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { Search, ShoppingCart, LogIn, UserRound } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { Button, buttonVariants } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { AuthActions } from "/src/features/auth/auth-actions.tsx";
import { useSession } from "/src/features/auth/api.ts";
import { useCart } from "/src/features/cart/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function DesktopHomeHeader() {
	_s();
	const isHome = useRouterState({ select: (state) => state.location.pathname === "/" });
	// Mount only on Home: other screens retain their header and query lifecycles.
	return isHome ? /* @__PURE__ */ _jsxDEV(HomeHeader, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 19
	}, this) : null;
}
_s(DesktopHomeHeader, "NTBeqhYWg6x6LLz0xFmM0w8qcw8=", false, function() {
	return [useRouterState];
});
_c = DesktopHomeHeader;
function HomeHeader() {
	_s2();
	const [searchOpen, setSearchOpen] = useState(false);
	const [term, setTerm] = useState("");
	const navigate = useNavigate();
	const session = useSession();
	const cart = useCart();
	const quantity = cart.data?.items.reduce((sum, item) => sum + item.quantity, 0);
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "desktop-home-header desktop-home-only",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "kurio-container desktop-header-inner",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					"aria-label": "Kurio — início",
					className: "desktop-wordmark",
					children: "KURIO"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": "Navegação principal",
					className: "desktop-primary-nav",
					children: [
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/",
							"aria-current": "page",
							className: "is-active",
							children: "Início"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#catalogo",
							children: "Mercado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#criadores",
							children: "Criadores"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 40
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#diario",
							children: "Aprenda"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 74
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "desktop-header-actions",
					children: [
						/* @__PURE__ */ _jsxDEV(Button, {
							variant: "ghost",
							"aria-label": "Abrir busca do mercado",
							"aria-expanded": searchOpen,
							"aria-controls": "header-market-search",
							onClick: () => setSearchOpen((value) => !value),
							children: /* @__PURE__ */ _jsxDEV(Search, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 30,
								columnNumber: 180
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/carrinho",
							"aria-label": quantity === undefined ? "Carrinho" : `Carrinho, ${quantity} itens`,
							className: "desktop-cart",
							children: [/* @__PURE__ */ _jsxDEV(ShoppingCart, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 136
							}, this), quantity !== undefined && /* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: quantity
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 198
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 9
						}, this),
						session.data ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("details", {
							className: "desktop-account",
							children: [/* @__PURE__ */ _jsxDEV("summary", { children: [/* @__PURE__ */ _jsxDEV(UserRound, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 73
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								role: "status",
								"aria-label": "Usuário conectado",
								children: session.data.user.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 105
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 64
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/perfil",
									children: "Perfil"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 16
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/carteiras",
									children: "Carteiras"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 48
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/favoritos",
									children: "Favoritos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 86
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/pedido/confirmacao",
									children: "Pedidos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 124
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 11
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 27
						}, this), /* @__PURE__ */ _jsxDEV(AuthActions, { showName: false }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 25
						}, this) : /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							className: buttonVariants({ className: "desktop-login" }),
							children: [/* @__PURE__ */ _jsxDEV(LogIn, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 34,
								columnNumber: 134
							}, this), "Entrar"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 57
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 7
				}, this),
				searchOpen && /* @__PURE__ */ _jsxDEV("form", {
					id: "header-market-search",
					className: "desktop-header-search",
					onSubmit: (event) => {
						event.preventDefault();
						void navigate({
							to: "/",
							search: (previous) => ({
								...previous,
								search: term,
								page: 1
							}),
							hash: "catalogo"
						});
						setSearchOpen(false);
					},
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "header-search",
							children: "Buscar no mercado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV(Input, {
							id: "header-search",
							type: "search",
							value: term,
							maxLength: 120,
							onChange: (event) => setTerm(event.target.value),
							onKeyDown: (event) => {
								if (event.key === "Escape") setSearchOpen(false);
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 65
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							type: "submit",
							children: "Buscar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 258
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 22
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 5
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 10
	}, this);
}
_s2(HomeHeader, "sAroSOZpt14UeTSDR1E1NKZqhVQ=", false, function() {
	return [
		useNavigate,
		useSession,
		useCart
	];
});
_c2 = HomeHeader;
var _c, _c2;
$RefreshReg$(_c, "DesktopHomeHeader");
$RefreshReg$(_c2, "HomeHeader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/desktop-home-header.tsx?t=1793942997328";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLGFBQWEsc0JBQXNCO0FBQ2xELFNBQVMsUUFBUSxjQUFjLE9BQU8saUJBQWlCO0FBQ3ZELFNBQVMsUUFBUSxzQkFBc0I7QUFDdkMsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsZUFBZTs7OztBQUV4QixPQUFPLFNBQVMsb0JBQW9COztDQUNsQyxNQUFNLFNBQVMsZUFBZSxFQUFFLFNBQVEsVUFBUyxNQUFNLFNBQVMsYUFBYSxJQUFJLENBQUM7O0NBRWxGLE9BQU8sU0FBUyx3QkFBQyxZQUFELENBQWE7Ozs7WUFBSTtBQUNuQzs7Ozs7QUFDQSxTQUFTLGFBQWE7O0NBQ3BCLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDbkMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsTUFBTSxPQUFPLFFBQVE7Q0FDckIsTUFBTSxXQUFXLEtBQUssTUFBTSxNQUFNLFFBQVEsS0FBSyxTQUFTLE1BQU0sS0FBSyxVQUFVLENBQUM7Q0FDOUUsT0FBTyx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUN2Qix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsTUFBRDtLQUFNLElBQUc7S0FBSSxjQUFXO0tBQWlCLFdBQVU7ZUFBbUI7SUFBVzs7Ozs7SUFDakYsd0JBQUMsT0FBRDtLQUFLLGNBQVc7S0FBc0IsV0FBVTtlQUFoRDtNQUNFLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQUksZ0JBQWE7T0FBTyxXQUFVO2lCQUFZO01BQVk7Ozs7O01BQ25FLHdCQUFDLEtBQUQ7T0FBRyxNQUFLO2lCQUFZO01BQVU7Ozs7O01BQUMsd0JBQUMsS0FBRDtPQUFHLE1BQUs7aUJBQWE7TUFBWTs7Ozs7TUFBQyx3QkFBQyxLQUFEO09BQUcsTUFBSztpQkFBVTtNQUFVOzs7OztLQUMxRjs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQ7T0FBUSxTQUFRO09BQVEsY0FBVztPQUF5QixpQkFBZTtPQUFZLGlCQUFjO09BQXVCLGVBQWUsZUFBYyxVQUFTLENBQUMsS0FBSztpQkFBRyx3QkFBQyxRQUFELEVBQVEsZUFBWSxPQUFROzs7OztNQUFTOzs7OztNQUNoTix3QkFBQyxNQUFEO09BQU0sSUFBRztPQUFZLGNBQVksYUFBYSxZQUFZLGFBQWEsYUFBYSxTQUFTO09BQVMsV0FBVTtpQkFBaEgsQ0FBK0gsd0JBQUMsY0FBRCxFQUFjLGVBQVksT0FBUTs7OztpQkFBRSxhQUFhLGFBQWEsd0JBQUMsUUFBRDtRQUFNLGVBQVk7a0JBQVE7T0FBZTs7OztlQUFROzs7Ozs7TUFDN08sUUFBUSxPQUFPLGdEQUFFLHdCQUFDLFdBQUQ7T0FBUyxXQUFVO2lCQUFuQixDQUFxQyx3QkFBQyxXQUFELGFBQVMsd0JBQUMsV0FBRCxFQUFXLGVBQVksT0FBUTs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQU0sTUFBSztRQUFTLGNBQVc7a0JBQXFCLFFBQVEsS0FBSyxLQUFLO09BQVc7Ozs7ZUFBVTs7OztpQkFDekwsd0JBQUMsT0FBRDtRQUFLLHdCQUFDLE1BQUQ7U0FBTSxJQUFHO21CQUFVO1FBQVk7Ozs7O1FBQUMsd0JBQUMsTUFBRDtTQUFNLElBQUc7bUJBQWE7UUFBZTs7Ozs7UUFBQyx3QkFBQyxNQUFEO1NBQU0sSUFBRzttQkFBYTtRQUFlOzs7OztRQUFDLHdCQUFDLE1BQUQ7U0FBTSxJQUFHO21CQUFzQjtRQUFhOzs7OztPQUFNOzs7O2VBQzVKOzs7OztnQkFBQyx3QkFBQyxhQUFELEVBQWEsVUFBVSxNQUFROzs7O2NBQUc7Ozs7aUJBQUksd0JBQUMsTUFBRDtPQUFNLElBQUc7T0FBUyxXQUFXLGVBQWUsRUFBRSxXQUFXLGdCQUFnQixDQUFDO2lCQUExRSxDQUE2RSx3QkFBQyxPQUFELEVBQU8sZUFBWSxPQUFROzs7O2lCQUFDLFFBQVk7Ozs7OztLQUNsSzs7Ozs7O0lBQ0osY0FBYyx3QkFBQyxRQUFEO0tBQU0sSUFBRztLQUF1QixXQUFVO0tBQXdCLFdBQVUsVUFBUztNQUNsRyxNQUFNLGVBQWU7TUFBRyxLQUFLLFNBQVM7T0FBRSxJQUFJO09BQUssU0FBUSxjQUFhO1FBQUUsR0FBRztRQUFVLFFBQVE7UUFBTSxNQUFNO09BQUU7T0FBSSxNQUFNO01BQVcsQ0FBQztNQUFHLGNBQWMsS0FBSztLQUN6SjtlQUZlO01BR2Isd0JBQUMsU0FBRDtPQUFPLFNBQVE7aUJBQWdCO01BQXdCOzs7OztNQUFDLHdCQUFDLE9BQUQ7T0FBTyxJQUFHO09BQWdCLE1BQUs7T0FBUyxPQUFPO09BQU0sV0FBVztPQUFLLFdBQVUsVUFBUyxRQUFRLE1BQU0sT0FBTyxLQUFLO09BQUcsWUFBVyxVQUFTO1FBQUUsSUFBSSxNQUFNLFFBQVEsVUFBVSxjQUFjLEtBQUs7T0FBRTtNQUFJOzs7OztNQUFDLHdCQUFDLFFBQUQ7T0FBUSxNQUFLO2lCQUFTO01BQWM7Ozs7O0tBQ3pSOzs7Ozs7R0FDSDs7Ozs7O0NBQ0M7Ozs7O0FBQ1YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiZGVza3RvcC1ob21lLWhlYWRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlLCB1c2VSb3V0ZXJTdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBTZWFyY2gsIFNob3BwaW5nQ2FydCwgTG9nSW4sIFVzZXJSb3VuZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IEJ1dHRvbiwgYnV0dG9uVmFyaWFudHMgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5pbXBvcnQgeyBBdXRoQWN0aW9ucyB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9hdXRoLWFjdGlvbnMnXG5pbXBvcnQgeyB1c2VTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2FwaSdcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tICdAL2ZlYXR1cmVzL2NhcnQvcXVlcmllcydcblxuZXhwb3J0IGZ1bmN0aW9uIERlc2t0b3BIb21lSGVhZGVyKCkge1xuICBjb25zdCBpc0hvbWUgPSB1c2VSb3V0ZXJTdGF0ZSh7IHNlbGVjdDogc3RhdGUgPT4gc3RhdGUubG9jYXRpb24ucGF0aG5hbWUgPT09ICcvJyB9KVxuICAvLyBNb3VudCBvbmx5IG9uIEhvbWU6IG90aGVyIHNjcmVlbnMgcmV0YWluIHRoZWlyIGhlYWRlciBhbmQgcXVlcnkgbGlmZWN5Y2xlcy5cbiAgcmV0dXJuIGlzSG9tZSA/IDxIb21lSGVhZGVyIC8+IDogbnVsbFxufVxuZnVuY3Rpb24gSG9tZUhlYWRlcigpIHtcbiAgY29uc3QgW3NlYXJjaE9wZW4sIHNldFNlYXJjaE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt0ZXJtLCBzZXRUZXJtXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKVxuICBjb25zdCBjYXJ0ID0gdXNlQ2FydCgpXG4gIGNvbnN0IHF1YW50aXR5ID0gY2FydC5kYXRhPy5pdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgaXRlbS5xdWFudGl0eSwgMClcbiAgcmV0dXJuIDxoZWFkZXIgY2xhc3NOYW1lPVwiZGVza3RvcC1ob21lLWhlYWRlciBkZXNrdG9wLWhvbWUtb25seVwiPlxuICAgIDxkaXYgY2xhc3NOYW1lPVwia3VyaW8tY29udGFpbmVyIGRlc2t0b3AtaGVhZGVyLWlubmVyXCI+XG4gICAgICA8TGluayB0bz1cIi9cIiBhcmlhLWxhYmVsPVwiS3VyaW8g4oCUIGluw61jaW9cIiBjbGFzc05hbWU9XCJkZXNrdG9wLXdvcmRtYXJrXCI+S1VSSU88L0xpbms+XG4gICAgICA8bmF2IGFyaWEtbGFiZWw9XCJOYXZlZ2HDp8OjbyBwcmluY2lwYWxcIiBjbGFzc05hbWU9XCJkZXNrdG9wLXByaW1hcnktbmF2XCI+XG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIGFyaWEtY3VycmVudD1cInBhZ2VcIiBjbGFzc05hbWU9XCJpcy1hY3RpdmVcIj5JbsOtY2lvPC9MaW5rPlxuICAgICAgICA8YSBocmVmPVwiI2NhdGFsb2dvXCI+TWVyY2FkbzwvYT48YSBocmVmPVwiI2NyaWFkb3Jlc1wiPkNyaWFkb3JlczwvYT48YSBocmVmPVwiI2RpYXJpb1wiPkFwcmVuZGE8L2E+XG4gICAgICA8L25hdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVza3RvcC1oZWFkZXItYWN0aW9uc1wiPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIGFyaWEtbGFiZWw9XCJBYnJpciBidXNjYSBkbyBtZXJjYWRvXCIgYXJpYS1leHBhbmRlZD17c2VhcmNoT3Blbn0gYXJpYS1jb250cm9scz1cImhlYWRlci1tYXJrZXQtc2VhcmNoXCIgb25DbGljaz17KCkgPT4gc2V0U2VhcmNoT3Blbih2YWx1ZSA9PiAhdmFsdWUpfT48U2VhcmNoIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+PC9CdXR0b24+XG4gICAgICAgIDxMaW5rIHRvPVwiL2NhcnJpbmhvXCIgYXJpYS1sYWJlbD17cXVhbnRpdHkgPT09IHVuZGVmaW5lZCA/ICdDYXJyaW5obycgOiBgQ2FycmluaG8sICR7cXVhbnRpdHl9IGl0ZW5zYH0gY2xhc3NOYW1lPVwiZGVza3RvcC1jYXJ0XCI+PFNob3BwaW5nQ2FydCBhcmlhLWhpZGRlbj1cInRydWVcIiAvPntxdWFudGl0eSAhPT0gdW5kZWZpbmVkICYmIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPntxdWFudGl0eX08L3NwYW4+fTwvTGluaz5cbiAgICAgICAge3Nlc3Npb24uZGF0YSA/IDw+PGRldGFpbHMgY2xhc3NOYW1lPVwiZGVza3RvcC1hY2NvdW50XCI+PHN1bW1hcnk+PFVzZXJSb3VuZCBhcmlhLWhpZGRlbj1cInRydWVcIiAvPjxzcGFuIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWxhYmVsPVwiVXN1w6FyaW8gY29uZWN0YWRvXCI+e3Nlc3Npb24uZGF0YS51c2VyLm5hbWV9PC9zcGFuPjwvc3VtbWFyeT5cbiAgICAgICAgICA8ZGl2PjxMaW5rIHRvPVwiL3BlcmZpbFwiPlBlcmZpbDwvTGluaz48TGluayB0bz1cIi9jYXJ0ZWlyYXNcIj5DYXJ0ZWlyYXM8L0xpbms+PExpbmsgdG89XCIvZmF2b3JpdG9zXCI+RmF2b3JpdG9zPC9MaW5rPjxMaW5rIHRvPVwiL3BlZGlkby9jb25maXJtYWNhb1wiPlBlZGlkb3M8L0xpbms+PC9kaXY+XG4gICAgICAgIDwvZGV0YWlscz48QXV0aEFjdGlvbnMgc2hvd05hbWU9e2ZhbHNlfSAvPjwvPiA6IDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPXtidXR0b25WYXJpYW50cyh7IGNsYXNzTmFtZTogJ2Rlc2t0b3AtbG9naW4nIH0pfT48TG9nSW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5FbnRyYXI8L0xpbms+fVxuICAgICAgPC9kaXY+XG4gICAgICB7c2VhcmNoT3BlbiAmJiA8Zm9ybSBpZD1cImhlYWRlci1tYXJrZXQtc2VhcmNoXCIgY2xhc3NOYW1lPVwiZGVza3RvcC1oZWFkZXItc2VhcmNoXCIgb25TdWJtaXQ9e2V2ZW50ID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTsgdm9pZCBuYXZpZ2F0ZSh7IHRvOiAnLycsIHNlYXJjaDogcHJldmlvdXMgPT4gKHsgLi4ucHJldmlvdXMsIHNlYXJjaDogdGVybSwgcGFnZTogMSB9KSwgaGFzaDogJ2NhdGFsb2dvJyB9KTsgc2V0U2VhcmNoT3BlbihmYWxzZSlcbiAgICAgIH19PlxuICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImhlYWRlci1zZWFyY2hcIj5CdXNjYXIgbm8gbWVyY2FkbzwvbGFiZWw+PElucHV0IGlkPVwiaGVhZGVyLXNlYXJjaFwiIHR5cGU9XCJzZWFyY2hcIiB2YWx1ZT17dGVybX0gbWF4TGVuZ3RoPXsxMjB9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRUZXJtKGV2ZW50LnRhcmdldC52YWx1ZSl9IG9uS2V5RG93bj17ZXZlbnQgPT4geyBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJykgc2V0U2VhcmNoT3BlbihmYWxzZSkgfX0gLz48QnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5CdXNjYXI8L0J1dHRvbj5cbiAgICAgIDwvZm9ybT59XG4gICAgPC9kaXY+XG4gIDwvaGVhZGVyPlxufVxuIl19