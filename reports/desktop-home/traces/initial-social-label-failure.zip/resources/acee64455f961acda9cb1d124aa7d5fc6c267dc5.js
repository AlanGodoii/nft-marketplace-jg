import { useIsMutating, useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { cartSchema, quoteSchema } from "/src/contracts/cart.ts";
import { api } from "/src/lib/api.ts";
import { getGuestId, identityEpoch } from "/src/lib/identity.ts";
import { scopedRequest } from "/src/lib/scoped-request.ts";
import { useRealtime } from "/src/features/realtime/state.ts";
import { useSession } from "/src/features/auth/api.ts";
export function useCartScope() {
	const session = useSession();
	return {
		scope: session.data?.user.id ? `user:${session.data.user.id}` : `guest:${getGuestId()}`,
		ready: session.isSuccess
	};
}
export const cartKey = (scope) => [
	"cart",
	scope,
	"data"
];
export function useCart() {
	const { scope, ready } = useCartScope();
	return useQuery({
		queryKey: cartKey(scope),
		enabled: ready,
		staleTime: 0,
		queryFn: async ({ signal }) => cartSchema.parse((await api.get("/cart", { signal })).data)
	});
}
export function useQuote(cart) {
	const { scope, ready } = useCartScope();
	const live = useRealtime();
	const snapshotCurrent = !!cart && cart.items.every((item) => item.nft.version >= (live.nftVersions[item.nftId] ?? 0));
	const query = useQuery({
		queryKey: [
			"cart",
			scope,
			"quote",
			cart?.version,
			cart?.items.map((item) => `${item.id}:${item.nft.version}`)
		],
		enabled: ready && snapshotCurrent,
		staleTime: 0,
		queryFn: async ({ signal }) => quoteSchema.parse((await api.get("/cart/quote", { signal })).data)
	});
	return {
		...query,
		snapshotCurrent
	};
}
export function useCartMutation() {
	const client = useQueryClient();
	const { scope } = useCartScope();
	const epochAtRender = identityEpoch();
	return useMutation({
		mutationKey: [
			"cart",
			scope,
			"mutation"
		],
		retry: false,
		mutationFn: async (action) => {
			const config = action.type === "add" ? {
				method: "POST",
				url: "/cart/items",
				data: action.item
			} : action.type === "update" ? {
				method: "PATCH",
				url: `/cart/items/${encodeURIComponent(action.id)}`,
				data: { quantity: action.quantity }
			} : action.type === "remove" ? {
				method: "DELETE",
				url: `/cart/items/${encodeURIComponent(action.id)}`
			} : action.type === "coupon" ? {
				method: "POST",
				url: "/cart/coupon",
				data: { code: action.code }
			} : {
				method: "DELETE",
				url: "/cart/coupon"
			};
			return cartSchema.parse((await scopedRequest(config, epochAtRender)).data);
		},
		onMutate: async () => {
			const epoch = identityEpoch();
			await client.cancelQueries({ queryKey: ["cart", scope] });
			return { epoch };
		},
		onSuccess: (data, _action, context) => {
			if (context?.epoch === identityEpoch()) client.setQueryData(cartKey(scope), data);
		},
		onSettled: (_data, _error, _action, context) => {
			if (context?.epoch === identityEpoch()) return client.invalidateQueries({ queryKey: ["cart", scope] });
		}
	});
}
export function useCartBusy() {
	const { scope } = useCartScope();
	return useIsMutating({ mutationKey: ["cart", scope] }) > 0;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLGFBQWEsVUFBVSxzQkFBc0I7QUFDckUsU0FBUyxZQUFZLG1CQUFrRDtBQUN2RSxTQUFTLFdBQVc7QUFDcEIsU0FBUyxZQUFZLHFCQUFxQjtBQUMxQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGtCQUFrQjtBQUMzQixPQUFPLFNBQVMsZUFBZTtDQUM3QixNQUFNLFVBQVUsV0FBVztDQUMzQixPQUFPO0VBQUUsT0FBTyxRQUFRLE1BQU0sS0FBSyxLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUssT0FBTyxTQUFTLFdBQVc7RUFBSyxPQUFPLFFBQVE7Q0FBVTtBQUM3SDtBQUNBLE9BQU8sTUFBTSxXQUFXLFVBQWtCO0NBQUM7Q0FBUTtDQUFPO0FBQU07QUFDaEUsT0FBTyxTQUFTLFVBQVU7Q0FDeEIsTUFBTSxFQUFFLE9BQU8sVUFBVSxhQUFhO0NBQ3RDLE9BQU8sU0FBUztFQUFFLFVBQVUsUUFBUSxLQUFLO0VBQUcsU0FBUztFQUFPLFdBQVc7RUFDckUsU0FBUyxPQUFPLEVBQUUsYUFBYSxXQUFXLE9BQU8sTUFBTSxJQUFJLElBQWEsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFDLENBQUUsSUFBSTtDQUNwRyxDQUFDO0FBQ0g7QUFDQSxPQUFPLFNBQVMsU0FBUyxNQUFhO0NBQ3BDLE1BQU0sRUFBRSxPQUFPLFVBQVUsYUFBYTtDQUFHLE1BQU0sT0FBTyxZQUFZO0NBQ2xFLE1BQU0sa0JBQWtCLENBQUMsQ0FBQyxRQUFRLEtBQUssTUFBTSxPQUFNLFNBQVEsS0FBSyxJQUFJLFlBQVksS0FBSyxZQUFZLEtBQUssVUFBVSxFQUFFO0NBQ2xILE1BQU0sUUFBUSxTQUFTO0VBQUUsVUFBVTtHQUFDO0dBQVE7R0FBTztHQUFTLE1BQU07R0FBUyxNQUFNLE1BQU0sS0FBSSxTQUFRLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxJQUFJLFNBQVM7RUFBQztFQUFHLFNBQVMsU0FBUztFQUFpQixXQUFXO0VBQ25MLFNBQVMsT0FBTyxFQUFFLGFBQWEsWUFBWSxPQUFPLE1BQU0sSUFBSSxJQUFhLGVBQWUsRUFBRSxPQUFPLENBQUMsRUFBQyxDQUFFLElBQUk7Q0FDM0csQ0FBQztDQUNELE9BQU87RUFBRSxHQUFHO0VBQU87Q0FBZ0I7QUFDckM7QUFFQSxPQUFPLFNBQVMsa0JBQWtCO0NBQ2hDLE1BQU0sU0FBUyxlQUFlO0NBQzlCLE1BQU0sRUFBRSxVQUFVLGFBQWE7Q0FDL0IsTUFBTSxnQkFBZ0IsY0FBYztDQUNwQyxPQUFPLFlBQVk7RUFBRSxhQUFhO0dBQUM7R0FBUTtHQUFPO0VBQVU7RUFBRyxPQUFPO0VBQ3BFLFlBQVksT0FBTyxXQUF1QjtHQUN4QyxNQUFNLFNBQVMsT0FBTyxTQUFTLFFBQVE7SUFBRSxRQUFRO0lBQVEsS0FBSztJQUFlLE1BQU0sT0FBTztHQUFLLElBQzNGLE9BQU8sU0FBUyxXQUFXO0lBQUUsUUFBUTtJQUFTLEtBQUssZUFBZSxtQkFBbUIsT0FBTyxFQUFFO0lBQUssTUFBTSxFQUFFLFVBQVUsT0FBTyxTQUFTO0dBQUUsSUFDckksT0FBTyxTQUFTLFdBQVc7SUFBRSxRQUFRO0lBQVUsS0FBSyxlQUFlLG1CQUFtQixPQUFPLEVBQUU7R0FBSSxJQUNqRyxPQUFPLFNBQVMsV0FBVztJQUFFLFFBQVE7SUFBUSxLQUFLO0lBQWdCLE1BQU0sRUFBRSxNQUFNLE9BQU8sS0FBSztHQUFFLElBQzVGO0lBQUUsUUFBUTtJQUFVLEtBQUs7R0FBZTtHQUNsRCxPQUFPLFdBQVcsT0FBTyxNQUFNLGNBQWMsUUFBUSxhQUFhLEVBQUMsQ0FBRSxJQUFJO0VBQzNFO0VBQ0EsVUFBVSxZQUFZO0dBQUUsTUFBTSxRQUFRLGNBQWM7R0FBRyxNQUFNLE9BQU8sY0FBYyxFQUFFLFVBQVUsQ0FBQyxRQUFRLEtBQUssRUFBRSxDQUFDO0dBQUcsT0FBTyxFQUFFLE1BQU07RUFBRTtFQUNuSSxZQUFZLE1BQU0sU0FBUyxZQUFZO0dBQUUsSUFBSSxTQUFTLFVBQVUsY0FBYyxHQUFHLE9BQU8sYUFBYSxRQUFRLEtBQUssR0FBRyxJQUFJO0VBQUU7RUFDM0gsWUFBWSxPQUFPLFFBQVEsU0FBUyxZQUFZO0dBQUUsSUFBSSxTQUFTLFVBQVUsY0FBYyxHQUFHLE9BQU8sT0FBTyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsUUFBUSxLQUFLLEVBQUUsQ0FBQztFQUFFO0NBQzNKLENBQUM7QUFDSDtBQUNBLE9BQU8sU0FBUyxjQUFjO0NBQUUsTUFBTSxFQUFFLFVBQVUsYUFBYTtDQUFHLE9BQU8sY0FBYyxFQUFFLGFBQWEsQ0FBQyxRQUFRLEtBQUssRUFBRSxDQUFDLElBQUk7QUFBRSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdWVyaWVzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUlzTXV0YXRpbmcsIHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBjYXJ0U2NoZW1hLCBxdW90ZVNjaGVtYSwgdHlwZSBDYXJ0SXRlbUlucHV0LCB0eXBlIENhcnQgfSBmcm9tICdAL2NvbnRyYWN0cy9jYXJ0J1xuaW1wb3J0IHsgYXBpIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgZ2V0R3Vlc3RJZCwgaWRlbnRpdHlFcG9jaCB9IGZyb20gJ0AvbGliL2lkZW50aXR5J1xuaW1wb3J0IHsgc2NvcGVkUmVxdWVzdCB9IGZyb20gJ0AvbGliL3Njb3BlZC1yZXF1ZXN0J1xuaW1wb3J0IHsgdXNlUmVhbHRpbWUgfSBmcm9tICdAL2ZlYXR1cmVzL3JlYWx0aW1lL3N0YXRlJ1xuaW1wb3J0IHsgdXNlU2Vzc2lvbiB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9hcGknXG5leHBvcnQgZnVuY3Rpb24gdXNlQ2FydFNjb3BlKCkge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpXG4gIHJldHVybiB7IHNjb3BlOiBzZXNzaW9uLmRhdGE/LnVzZXIuaWQgPyBgdXNlcjoke3Nlc3Npb24uZGF0YS51c2VyLmlkfWAgOiBgZ3Vlc3Q6JHtnZXRHdWVzdElkKCl9YCwgcmVhZHk6IHNlc3Npb24uaXNTdWNjZXNzIH1cbn1cbmV4cG9ydCBjb25zdCBjYXJ0S2V5ID0gKHNjb3BlOiBzdHJpbmcpID0+IFsnY2FydCcsIHNjb3BlLCAnZGF0YSddIGFzIGNvbnN0XG5leHBvcnQgZnVuY3Rpb24gdXNlQ2FydCgpIHtcbiAgY29uc3QgeyBzY29wZSwgcmVhZHkgfSA9IHVzZUNhcnRTY29wZSgpXG4gIHJldHVybiB1c2VRdWVyeSh7IHF1ZXJ5S2V5OiBjYXJ0S2V5KHNjb3BlKSwgZW5hYmxlZDogcmVhZHksIHN0YWxlVGltZTogMCxcbiAgICBxdWVyeUZuOiBhc3luYyAoeyBzaWduYWwgfSkgPT4gY2FydFNjaGVtYS5wYXJzZSgoYXdhaXQgYXBpLmdldDx1bmtub3duPignL2NhcnQnLCB7IHNpZ25hbCB9KSkuZGF0YSksXG4gIH0pXG59XG5leHBvcnQgZnVuY3Rpb24gdXNlUXVvdGUoY2FydD86IENhcnQpIHtcbiAgY29uc3QgeyBzY29wZSwgcmVhZHkgfSA9IHVzZUNhcnRTY29wZSgpOyBjb25zdCBsaXZlID0gdXNlUmVhbHRpbWUoKVxuICBjb25zdCBzbmFwc2hvdEN1cnJlbnQgPSAhIWNhcnQgJiYgY2FydC5pdGVtcy5ldmVyeShpdGVtID0+IGl0ZW0ubmZ0LnZlcnNpb24gPj0gKGxpdmUubmZ0VmVyc2lvbnNbaXRlbS5uZnRJZF0gPz8gMCkpXG4gIGNvbnN0IHF1ZXJ5ID0gdXNlUXVlcnkoeyBxdWVyeUtleTogWydjYXJ0Jywgc2NvcGUsICdxdW90ZScsIGNhcnQ/LnZlcnNpb24sIGNhcnQ/Lml0ZW1zLm1hcChpdGVtID0+IGAke2l0ZW0uaWR9OiR7aXRlbS5uZnQudmVyc2lvbn1gKV0sIGVuYWJsZWQ6IHJlYWR5ICYmIHNuYXBzaG90Q3VycmVudCwgc3RhbGVUaW1lOiAwLFxuICAgIHF1ZXJ5Rm46IGFzeW5jICh7IHNpZ25hbCB9KSA9PiBxdW90ZVNjaGVtYS5wYXJzZSgoYXdhaXQgYXBpLmdldDx1bmtub3duPignL2NhcnQvcXVvdGUnLCB7IHNpZ25hbCB9KSkuZGF0YSksXG4gIH0pXG4gIHJldHVybiB7IC4uLnF1ZXJ5LCBzbmFwc2hvdEN1cnJlbnQgfVxufVxudHlwZSBDYXJ0QWN0aW9uID0geyB0eXBlOiAnYWRkJzsgaXRlbTogQ2FydEl0ZW1JbnB1dCB9IHwgeyB0eXBlOiAndXBkYXRlJzsgaWQ6IHN0cmluZzsgcXVhbnRpdHk6IG51bWJlciB9IHwgeyB0eXBlOiAncmVtb3ZlJzsgaWQ6IHN0cmluZyB9IHwgeyB0eXBlOiAnY291cG9uJzsgY29kZTogc3RyaW5nIH0gfCB7IHR5cGU6ICdyZW1vdmUtY291cG9uJyB9XG5leHBvcnQgZnVuY3Rpb24gdXNlQ2FydE11dGF0aW9uKCkge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4gIGNvbnN0IHsgc2NvcGUgfSA9IHVzZUNhcnRTY29wZSgpXG4gIGNvbnN0IGVwb2NoQXRSZW5kZXIgPSBpZGVudGl0eUVwb2NoKClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsnY2FydCcsIHNjb3BlLCAnbXV0YXRpb24nXSwgcmV0cnk6IGZhbHNlLFxuICAgIG11dGF0aW9uRm46IGFzeW5jIChhY3Rpb246IENhcnRBY3Rpb24pID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGFjdGlvbi50eXBlID09PSAnYWRkJyA/IHsgbWV0aG9kOiAnUE9TVCcsIHVybDogJy9jYXJ0L2l0ZW1zJywgZGF0YTogYWN0aW9uLml0ZW0gfVxuICAgICAgICA6IGFjdGlvbi50eXBlID09PSAndXBkYXRlJyA/IHsgbWV0aG9kOiAnUEFUQ0gnLCB1cmw6IGAvY2FydC9pdGVtcy8ke2VuY29kZVVSSUNvbXBvbmVudChhY3Rpb24uaWQpfWAsIGRhdGE6IHsgcXVhbnRpdHk6IGFjdGlvbi5xdWFudGl0eSB9IH1cbiAgICAgICAgICA6IGFjdGlvbi50eXBlID09PSAncmVtb3ZlJyA/IHsgbWV0aG9kOiAnREVMRVRFJywgdXJsOiBgL2NhcnQvaXRlbXMvJHtlbmNvZGVVUklDb21wb25lbnQoYWN0aW9uLmlkKX1gIH1cbiAgICAgICAgICAgIDogYWN0aW9uLnR5cGUgPT09ICdjb3Vwb24nID8geyBtZXRob2Q6ICdQT1NUJywgdXJsOiAnL2NhcnQvY291cG9uJywgZGF0YTogeyBjb2RlOiBhY3Rpb24uY29kZSB9IH1cbiAgICAgICAgICAgICAgOiB7IG1ldGhvZDogJ0RFTEVURScsIHVybDogJy9jYXJ0L2NvdXBvbicgfVxuICAgICAgcmV0dXJuIGNhcnRTY2hlbWEucGFyc2UoKGF3YWl0IHNjb3BlZFJlcXVlc3QoY29uZmlnLCBlcG9jaEF0UmVuZGVyKSkuZGF0YSlcbiAgICB9LFxuICAgIG9uTXV0YXRlOiBhc3luYyAoKSA9PiB7IGNvbnN0IGVwb2NoID0gaWRlbnRpdHlFcG9jaCgpOyBhd2FpdCBjbGllbnQuY2FuY2VsUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ2NhcnQnLCBzY29wZV0gfSk7IHJldHVybiB7IGVwb2NoIH0gfSxcbiAgICBvblN1Y2Nlc3M6IChkYXRhLCBfYWN0aW9uLCBjb250ZXh0KSA9PiB7IGlmIChjb250ZXh0Py5lcG9jaCA9PT0gaWRlbnRpdHlFcG9jaCgpKSBjbGllbnQuc2V0UXVlcnlEYXRhKGNhcnRLZXkoc2NvcGUpLCBkYXRhKSB9LFxuICAgIG9uU2V0dGxlZDogKF9kYXRhLCBfZXJyb3IsIF9hY3Rpb24sIGNvbnRleHQpID0+IHsgaWYgKGNvbnRleHQ/LmVwb2NoID09PSBpZGVudGl0eUVwb2NoKCkpIHJldHVybiBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydjYXJ0Jywgc2NvcGVdIH0pIH0sXG4gIH0pXG59XG5leHBvcnQgZnVuY3Rpb24gdXNlQ2FydEJ1c3koKSB7IGNvbnN0IHsgc2NvcGUgfSA9IHVzZUNhcnRTY29wZSgpOyByZXR1cm4gdXNlSXNNdXRhdGluZyh7IG11dGF0aW9uS2V5OiBbJ2NhcnQnLCBzY29wZV0gfSkgPiAwIH1cbiJdfQ==