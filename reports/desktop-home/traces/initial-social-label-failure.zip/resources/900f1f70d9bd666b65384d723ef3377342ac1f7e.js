import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/home-editorial.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { buttonVariants } from "/src/components/ui/button.tsx";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "/src/components/ui/dialog.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/components/home-editorial.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
const root = "/assets/figma/home/";
export function HomeSpotlight({ nft }) {
	if (!nft?.image.desktopSrc) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "desktop-home-only home-spotlight",
		children: [
			/* @__PURE__ */ _jsxDEV("p", { children: "NFT EM DESTAQUE" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("h3", { children: "DESCUBRA ESTA EDIÇÃO" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 27
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				to: "/nfts/$nftId",
				params: { nftId: nft.id },
				children: [/* @__PURE__ */ _jsxDEV("img", {
					src: nft.image.desktopSrc,
					alt: `Arte original de ${nft.name}`,
					width: "310",
					height: "310",
					loading: "lazy"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 56
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: nft.name }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 167
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 10
	}, this);
}
_c = HomeSpotlight;
const articles = [
	{
		art: "neon-vessel",
		date: "12 de setembro",
		minutes: 6,
		title: "Como funciona a propriedade de NFTs",
		description: "Aprenda a colecionar, negociar e verificar ativos digitais."
	},
	{
		art: "emerald-ape",
		date: "13 de setembro",
		minutes: 2,
		title: "10 artistas digitais para acompanhar",
		description: "Conheça criadores que moldam a cultura digital."
	},
	{
		art: "sage-nomad",
		date: "15 de setembro",
		minutes: 3,
		title: "Raridade, atributos e procedência",
		description: "Entenda raridade, procedência, direitos autorais e utilidade."
	},
	{
		art: "golden-beat",
		date: "15 de setembro",
		minutes: 2,
		title: "Como proteger sua carteira",
		description: "Proteja sua carteira, seus ativos e sua identidade."
	}
];
export function HomeEditorial() {
	_s();
	const [article, setArticle] = useState(null);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "home-editorial desktop-home-only",
		children: [
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": "Explore o marketplace",
				className: "home-promos",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("img", {
					src: root + "emerald-ape.webp",
					alt: "Arte Kurio: macaco de jaqueta verde",
					width: "290",
					height: "250",
					loading: "lazy"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 12
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("h2", { children: [
						"Lançamentos gênesis",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 161
						}, this),
						"de edição limitada"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 138
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Colecione edições escassas diretamente dos criadores antes da revelação pública." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 190
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						search: (previous) => ({
							...previous,
							tab: "new",
							page: 1
						}),
						hash: "catalogo",
						className: buttonVariants(),
						children: ["Explorar ", /* @__PURE__ */ _jsxDEV(ArrowRight, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 404
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 277
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 133
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("img", {
					src: root + "neon-vessel.webp",
					alt: "Arte Kurio: macaco de terno claro",
					width: "290",
					height: "250",
					loading: "lazy"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 12
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("h2", { children: [
						"Arte digital selecionada",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 164
						}, this),
						"e muito mais"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 136
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Explore novos artistas, coleções verificadas e obras digitais que definem a cultura." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 187
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						search: (previous) => ({
							...previous,
							tab: "all",
							page: 1
						}),
						hash: "catalogo",
						className: buttonVariants(),
						children: ["Explorar ", /* @__PURE__ */ _jsxDEV(ArrowRight, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 405
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 278
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 131
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "diario",
				"aria-labelledby": "diario-title",
				className: "home-journal",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						id: "diario-title",
						children: "Diário da Cunhagem"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Histórias, guias e insights para colecionadores sobre o universo da propriedade digital." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 52
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "journal-grid",
						children: articles.map((item) => /* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("img", {
							src: root + item.art + ".webp",
							alt: "",
							width: "270",
							height: "198",
							loading: "lazy"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 9
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "article-meta",
								children: [
									item.date,
									" | Leitura de ",
									item.minutes,
									" min"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 14
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", { children: item.title }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 89
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: item.description }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 110
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setArticle(item.title),
								"aria-label": `Ler mais: ${item.title} (prévia editorial)`,
								children: "Ler mais →"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 135
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 9
						}, this)] }, item.title, true, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 59
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: article !== null,
				onOpenChange: (open) => {
					if (!open) setArticle(null);
				},
				children: /* @__PURE__ */ _jsxDEV(DialogContent, {
					className: "kurio-theme",
					children: /* @__PURE__ */ _jsxDEV(DialogHeader, { children: [/* @__PURE__ */ _jsxDEV(DialogTitle, { children: article }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 145
					}, this), /* @__PURE__ */ _jsxDEV(DialogDescription, { children: "Prévia editorial do layout original. O conteúdo completo dos artigos está fora do escopo desta demonstração e não está disponível." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 181
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 131
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 92
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 10
	}, this);
}
_s(HomeEditorial, "P94/jea0U8L4V51KodIJd6a693c=");
_c2 = HomeEditorial;
var _c, _c2;
$RefreshReg$(_c, "HomeSpotlight");
$RefreshReg$(_c2, "HomeEditorial");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/components/home-editorial.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/components/home-editorial.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/components/home-editorial.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/components/home-editorial.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsUUFBUSxlQUFlLG1CQUFtQixjQUFjLG1CQUFtQjs7OztBQUVwRixNQUFNLE9BQU87QUFDYixPQUFPLFNBQVMsY0FBYyxFQUFFLE9BQXNCO0NBQ3BELElBQUksQ0FBQyxLQUFLLE1BQU0sWUFBWSxPQUFPO0NBQ25DLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNMLHdCQUFDLEtBQUQsWUFBRyxrQkFBa0I7Ozs7O0dBQUMsd0JBQUMsTUFBRCxZQUFJLHVCQUF3Qjs7Ozs7R0FDbEQsd0JBQUMsTUFBRDtJQUFNLElBQUc7SUFBZSxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7Y0FBaEQsQ0FBbUQsd0JBQUMsT0FBRDtLQUFLLEtBQUssSUFBSSxNQUFNO0tBQVksS0FBSyxvQkFBb0IsSUFBSTtLQUFRLE9BQU07S0FBTSxRQUFPO0tBQU0sU0FBUTtJQUFROzs7O2NBQUMsd0JBQUMsUUFBRCxZQUFPLElBQUksS0FBVzs7OztZQUFPOzs7Ozs7RUFDNUw7Ozs7OztBQUNQOztBQUNBLE1BQU0sV0FBVztDQUNmO0VBQUUsS0FBSztFQUFlLE1BQU07RUFBa0IsU0FBUztFQUFHLE9BQU87RUFBdUMsYUFBYTtDQUE4RDtDQUNuTDtFQUFFLEtBQUs7RUFBZSxNQUFNO0VBQWtCLFNBQVM7RUFBRyxPQUFPO0VBQXdDLGFBQWE7Q0FBa0Q7Q0FDeEs7RUFBRSxLQUFLO0VBQWMsTUFBTTtFQUFrQixTQUFTO0VBQUcsT0FBTztFQUFxQyxhQUFhO0NBQWdFO0NBQ2xMO0VBQUUsS0FBSztFQUFlLE1BQU07RUFBa0IsU0FBUztFQUFHLE9BQU87RUFBOEIsYUFBYTtDQUFzRDtBQUNwSztBQUNBLE9BQU8sU0FBUyxnQkFBZ0I7O0NBQzlCLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBd0IsSUFBSTtDQUMxRCxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDTCx3QkFBQyxXQUFEO0lBQVMsY0FBVztJQUF3QixXQUFVO2NBQXRELENBQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE9BQUQ7S0FBSyxLQUFLLE9BQU87S0FBb0IsS0FBSTtLQUFzQyxPQUFNO0tBQU0sUUFBTztLQUFNLFNBQVE7SUFBUTs7OztjQUFDLHdCQUFDLE9BQUQ7S0FBSyx3QkFBQyxNQUFEO01BQUk7TUFBbUIsd0JBQUMsTUFBRCxDQUFLOzs7OztNQUFDO0tBQXNCOzs7OztLQUFDLHdCQUFDLEtBQUQsWUFBRyxtRkFBbUY7Ozs7O0tBQUMsd0JBQUMsTUFBRDtNQUFNLElBQUc7TUFBSSxTQUFRLGNBQWE7T0FBRSxHQUFHO09BQVUsS0FBSztPQUFPLE1BQU07TUFBRTtNQUFJLE1BQUs7TUFBVyxXQUFXLGVBQWU7Z0JBQW5ILENBQXNILGFBQVMsd0JBQUMsWUFBRCxFQUFZLGVBQVksT0FBUTs7OztjQUFPOzs7Ozs7SUFBTTs7OztZQUFNOzs7O2NBQ2hjLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxPQUFEO0tBQUssS0FBSyxPQUFPO0tBQW9CLEtBQUk7S0FBb0MsT0FBTTtLQUFNLFFBQU87S0FBTSxTQUFRO0lBQVE7Ozs7Y0FBQyx3QkFBQyxPQUFEO0tBQUssd0JBQUMsTUFBRDtNQUFJO01BQXdCLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7TUFBQztLQUFnQjs7Ozs7S0FBQyx3QkFBQyxLQUFELFlBQUcsdUZBQXVGOzs7OztLQUFDLHdCQUFDLE1BQUQ7TUFBTSxJQUFHO01BQUksU0FBUSxjQUFhO09BQUUsR0FBRztPQUFVLEtBQUs7T0FBTyxNQUFNO01BQUU7TUFBSSxNQUFLO01BQVcsV0FBVyxlQUFlO2dCQUFuSCxDQUFzSCxhQUFTLHdCQUFDLFlBQUQsRUFBWSxlQUFZLE9BQVE7Ozs7Y0FBTzs7Ozs7O0lBQU07Ozs7WUFBTTs7OztZQUMxYjs7Ozs7O0dBQ1Qsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBUyxtQkFBZ0I7SUFBZSxXQUFVO2NBQTlEO0tBQ0Usd0JBQUMsTUFBRDtNQUFJLElBQUc7Z0JBQWU7S0FBc0I7Ozs7O0tBQUMsd0JBQUMsS0FBRCxZQUFHLDJGQUEyRjs7Ozs7S0FDM0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWdCLFNBQVMsS0FBSSxTQUFRLHdCQUFDLFdBQUQsYUFDbEQsd0JBQUMsT0FBRDtPQUFLLEtBQUssT0FBTyxLQUFLLE1BQU07T0FBUyxLQUFJO09BQUcsT0FBTTtPQUFNLFFBQU87T0FBTSxTQUFRO01BQVE7Ozs7Z0JBQ3JGLHdCQUFDLE9BQUQ7T0FBSyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUE2QixLQUFLO1NBQUs7U0FBZSxLQUFLO1NBQVE7UUFBTzs7Ozs7O09BQUMsd0JBQUMsTUFBRCxZQUFLLEtBQUssTUFBVTs7Ozs7T0FBQyx3QkFBQyxLQUFELFlBQUksS0FBSyxZQUFlOzs7OztPQUFDLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZSxXQUFXLEtBQUssS0FBSztRQUFHLGNBQVksYUFBYSxLQUFLLE1BQU07a0JBQXNCO09BQWtCOzs7OztNQUFNOzs7O2NBQ3RRLEtBSHlELEtBQUs7Ozs7YUFHOUQsQ0FBQztLQUFPOzs7OztJQUNWOzs7Ozs7R0FDVCx3QkFBQyxRQUFEO0lBQVEsTUFBTSxZQUFZO0lBQU0sZUFBYyxTQUFRO0tBQUUsSUFBSSxDQUFDLE1BQU0sV0FBVyxJQUFJO0lBQUU7Y0FBRyx3QkFBQyxlQUFEO0tBQWUsV0FBVTtlQUFjLHdCQUFDLGNBQUQsYUFBYyx3QkFBQyxhQUFELFlBQWMsUUFBcUI7Ozs7ZUFBQyx3QkFBQyxtQkFBRCxZQUFtQixxSUFBcUo7Ozs7YUFBZTs7Ozs7SUFBZ0I7Ozs7O0dBQVM7Ozs7O0VBQzdYOzs7Ozs7QUFDUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJob21lLWVkaXRvcmlhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgQXJyb3dSaWdodCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGJ1dHRvblZhcmlhbnRzIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nQ29udGVudCwgRGlhbG9nRGVzY3JpcHRpb24sIERpYWxvZ0hlYWRlciwgRGlhbG9nVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZGlhbG9nJ1xuaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnXG5jb25zdCByb290ID0gJy9hc3NldHMvZmlnbWEvaG9tZS8nXG5leHBvcnQgZnVuY3Rpb24gSG9tZVNwb3RsaWdodCh7IG5mdCB9OiB7IG5mdD86IE5mdCB9KSB7XG4gIGlmICghbmZ0Py5pbWFnZS5kZXNrdG9wU3JjKSByZXR1cm4gbnVsbFxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJkZXNrdG9wLWhvbWUtb25seSBob21lLXNwb3RsaWdodFwiPlxuICAgIDxwPk5GVCBFTSBERVNUQVFVRTwvcD48aDM+REVTQ1VCUkEgRVNUQSBFREnDh8ODTzwvaDM+XG4gICAgPExpbmsgdG89XCIvbmZ0cy8kbmZ0SWRcIiBwYXJhbXM9e3sgbmZ0SWQ6IG5mdC5pZCB9fT48aW1nIHNyYz17bmZ0LmltYWdlLmRlc2t0b3BTcmN9IGFsdD17YEFydGUgb3JpZ2luYWwgZGUgJHtuZnQubmFtZX1gfSB3aWR0aD1cIjMxMFwiIGhlaWdodD1cIjMxMFwiIGxvYWRpbmc9XCJsYXp5XCIgLz48c3Bhbj57bmZ0Lm5hbWV9PC9zcGFuPjwvTGluaz5cbiAgPC9kaXY+XG59XG5jb25zdCBhcnRpY2xlcyA9IFtcbiAgeyBhcnQ6ICduZW9uLXZlc3NlbCcsIGRhdGU6ICcxMiBkZSBzZXRlbWJybycsIG1pbnV0ZXM6IDYsIHRpdGxlOiAnQ29tbyBmdW5jaW9uYSBhIHByb3ByaWVkYWRlIGRlIE5GVHMnLCBkZXNjcmlwdGlvbjogJ0FwcmVuZGEgYSBjb2xlY2lvbmFyLCBuZWdvY2lhciBlIHZlcmlmaWNhciBhdGl2b3MgZGlnaXRhaXMuJyB9LFxuICB7IGFydDogJ2VtZXJhbGQtYXBlJywgZGF0ZTogJzEzIGRlIHNldGVtYnJvJywgbWludXRlczogMiwgdGl0bGU6ICcxMCBhcnRpc3RhcyBkaWdpdGFpcyBwYXJhIGFjb21wYW5oYXInLCBkZXNjcmlwdGlvbjogJ0Nvbmhlw6dhIGNyaWFkb3JlcyBxdWUgbW9sZGFtIGEgY3VsdHVyYSBkaWdpdGFsLicgfSxcbiAgeyBhcnQ6ICdzYWdlLW5vbWFkJywgZGF0ZTogJzE1IGRlIHNldGVtYnJvJywgbWludXRlczogMywgdGl0bGU6ICdSYXJpZGFkZSwgYXRyaWJ1dG9zIGUgcHJvY2Vkw6puY2lhJywgZGVzY3JpcHRpb246ICdFbnRlbmRhIHJhcmlkYWRlLCBwcm9jZWTDqm5jaWEsIGRpcmVpdG9zIGF1dG9yYWlzIGUgdXRpbGlkYWRlLicgfSxcbiAgeyBhcnQ6ICdnb2xkZW4tYmVhdCcsIGRhdGU6ICcxNSBkZSBzZXRlbWJybycsIG1pbnV0ZXM6IDIsIHRpdGxlOiAnQ29tbyBwcm90ZWdlciBzdWEgY2FydGVpcmEnLCBkZXNjcmlwdGlvbjogJ1Byb3RlamEgc3VhIGNhcnRlaXJhLCBzZXVzIGF0aXZvcyBlIHN1YSBpZGVudGlkYWRlLicgfSxcbl1cbmV4cG9ydCBmdW5jdGlvbiBIb21lRWRpdG9yaWFsKCkge1xuICBjb25zdCBbYXJ0aWNsZSwgc2V0QXJ0aWNsZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJob21lLWVkaXRvcmlhbCBkZXNrdG9wLWhvbWUtb25seVwiPlxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9XCJFeHBsb3JlIG8gbWFya2V0cGxhY2VcIiBjbGFzc05hbWU9XCJob21lLXByb21vc1wiPlxuICAgICAgPGRpdj48aW1nIHNyYz17cm9vdCArICdlbWVyYWxkLWFwZS53ZWJwJ30gYWx0PVwiQXJ0ZSBLdXJpbzogbWFjYWNvIGRlIGphcXVldGEgdmVyZGVcIiB3aWR0aD1cIjI5MFwiIGhlaWdodD1cIjI1MFwiIGxvYWRpbmc9XCJsYXp5XCIgLz48ZGl2PjxoMj5MYW7Dp2FtZW50b3MgZ8OqbmVzaXM8YnIgLz5kZSBlZGnDp8OjbyBsaW1pdGFkYTwvaDI+PHA+Q29sZWNpb25lIGVkacOnw7VlcyBlc2Nhc3NhcyBkaXJldGFtZW50ZSBkb3MgY3JpYWRvcmVzIGFudGVzIGRhIHJldmVsYcOnw6NvIHDDumJsaWNhLjwvcD48TGluayB0bz1cIi9cIiBzZWFyY2g9e3ByZXZpb3VzID0+ICh7IC4uLnByZXZpb3VzLCB0YWI6ICduZXcnLCBwYWdlOiAxIH0pfSBoYXNoPVwiY2F0YWxvZ29cIiBjbGFzc05hbWU9e2J1dHRvblZhcmlhbnRzKCl9PkV4cGxvcmFyIDxBcnJvd1JpZ2h0IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+PC9MaW5rPjwvZGl2PjwvZGl2PlxuICAgICAgPGRpdj48aW1nIHNyYz17cm9vdCArICduZW9uLXZlc3NlbC53ZWJwJ30gYWx0PVwiQXJ0ZSBLdXJpbzogbWFjYWNvIGRlIHRlcm5vIGNsYXJvXCIgd2lkdGg9XCIyOTBcIiBoZWlnaHQ9XCIyNTBcIiBsb2FkaW5nPVwibGF6eVwiIC8+PGRpdj48aDI+QXJ0ZSBkaWdpdGFsIHNlbGVjaW9uYWRhPGJyIC8+ZSBtdWl0byBtYWlzPC9oMj48cD5FeHBsb3JlIG5vdm9zIGFydGlzdGFzLCBjb2xlw6fDtWVzIHZlcmlmaWNhZGFzIGUgb2JyYXMgZGlnaXRhaXMgcXVlIGRlZmluZW0gYSBjdWx0dXJhLjwvcD48TGluayB0bz1cIi9cIiBzZWFyY2g9e3ByZXZpb3VzID0+ICh7IC4uLnByZXZpb3VzLCB0YWI6ICdhbGwnLCBwYWdlOiAxIH0pfSBoYXNoPVwiY2F0YWxvZ29cIiBjbGFzc05hbWU9e2J1dHRvblZhcmlhbnRzKCl9PkV4cGxvcmFyIDxBcnJvd1JpZ2h0IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+PC9MaW5rPjwvZGl2PjwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgICA8c2VjdGlvbiBpZD1cImRpYXJpb1wiIGFyaWEtbGFiZWxsZWRieT1cImRpYXJpby10aXRsZVwiIGNsYXNzTmFtZT1cImhvbWUtam91cm5hbFwiPlxuICAgICAgPGgyIGlkPVwiZGlhcmlvLXRpdGxlXCI+RGnDoXJpbyBkYSBDdW5oYWdlbTwvaDI+PHA+SGlzdMOzcmlhcywgZ3VpYXMgZSBpbnNpZ2h0cyBwYXJhIGNvbGVjaW9uYWRvcmVzIHNvYnJlIG8gdW5pdmVyc28gZGEgcHJvcHJpZWRhZGUgZGlnaXRhbC48L3A+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImpvdXJuYWwtZ3JpZFwiPnthcnRpY2xlcy5tYXAoaXRlbSA9PiA8YXJ0aWNsZSBrZXk9e2l0ZW0udGl0bGV9PlxuICAgICAgICA8aW1nIHNyYz17cm9vdCArIGl0ZW0uYXJ0ICsgJy53ZWJwJ30gYWx0PVwiXCIgd2lkdGg9XCIyNzBcIiBoZWlnaHQ9XCIxOThcIiBsb2FkaW5nPVwibGF6eVwiIC8+XG4gICAgICAgIDxkaXY+PHAgY2xhc3NOYW1lPVwiYXJ0aWNsZS1tZXRhXCI+e2l0ZW0uZGF0ZX0gfCBMZWl0dXJhIGRlIHtpdGVtLm1pbnV0ZXN9IG1pbjwvcD48aDM+e2l0ZW0udGl0bGV9PC9oMz48cD57aXRlbS5kZXNjcmlwdGlvbn08L3A+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0QXJ0aWNsZShpdGVtLnRpdGxlKX0gYXJpYS1sYWJlbD17YExlciBtYWlzOiAke2l0ZW0udGl0bGV9IChwcsOpdmlhIGVkaXRvcmlhbClgfT5MZXIgbWFpcyDihpI8L2J1dHRvbj48L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT4pfTwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgICA8RGlhbG9nIG9wZW49e2FydGljbGUgIT09IG51bGx9IG9uT3BlbkNoYW5nZT17b3BlbiA9PiB7IGlmICghb3Blbikgc2V0QXJ0aWNsZShudWxsKSB9fT48RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJrdXJpby10aGVtZVwiPjxEaWFsb2dIZWFkZXI+PERpYWxvZ1RpdGxlPnthcnRpY2xlfTwvRGlhbG9nVGl0bGU+PERpYWxvZ0Rlc2NyaXB0aW9uPlByw6l2aWEgZWRpdG9yaWFsIGRvIGxheW91dCBvcmlnaW5hbC4gTyBjb250ZcO6ZG8gY29tcGxldG8gZG9zIGFydGlnb3MgZXN0w6EgZm9yYSBkbyBlc2NvcG8gZGVzdGEgZGVtb25zdHJhw6fDo28gZSBuw6NvIGVzdMOhIGRpc3BvbsOtdmVsLjwvRGlhbG9nRGVzY3JpcHRpb24+PC9EaWFsb2dIZWFkZXI+PC9EaWFsb2dDb250ZW50PjwvRGlhbG9nPlxuICA8L2Rpdj5cbn1cbiJdfQ==