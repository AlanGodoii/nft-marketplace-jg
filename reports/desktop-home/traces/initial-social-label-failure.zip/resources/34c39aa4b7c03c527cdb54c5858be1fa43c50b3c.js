import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/skeleton.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { cn } from "/node_modules/.vite/deps/cn.js?v=22c23eb4";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/ui/skeleton.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		"data-slot": "skeleton",
		className: cn("skeleton-shimmer rounded-md bg-muted", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = Skeleton;
export { Skeleton };
var _c;
$RefreshReg$(_c, "Skeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/skeleton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/ui/skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/ui/skeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/ui/skeleton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVOzs7QUFFbkIsU0FBUyxTQUFTLEVBQUUsV0FBVyxHQUFHLFNBQXNDO0NBQ3RFLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQUcsd0NBQXdDLFNBQVM7RUFDL0QsR0FBSTtDQUNMOzs7OztBQUVMOztBQUVBLFNBQVMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsic2tlbGV0b24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNuIH0gZnJvbSBcImNuXCJcblxuZnVuY3Rpb24gU2tlbGV0b24oeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPFwiZGl2XCI+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwic2tlbGV0b25cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcInNrZWxldG9uLXNoaW1tZXIgcm91bmRlZC1tZCBiZy1tdXRlZFwiLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IHsgU2tlbGV0b24gfVxuIl19