// node_modules/clsx/dist/clsx.mjs
function r(e) {
	var t, f, n = "";
	if ("string" == typeof e || "number" == typeof e) n += e;
	else if ("object" == typeof e) if (Array.isArray(e)) {
		var o = e.length;
		for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
	} else for (f in e) e[f] && (n && (n += " "), n += f);
	return n;
}
function clsx() {
	for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
	return n;
}
// node_modules/class-variance-authority/dist/index.mjs
/**
* Copyright 2022 Joe Bell. All rights reserved.
*
* This file is licensed to you under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with the
* License. You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/ var falsyToString = (value) => typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
var cx = clsx;
var cva = (base, config) => (props) => {
	var _config_compoundVariants;
	if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
	const { variants, defaultVariants } = config;
	const getVariantClassNames = Object.keys(variants).map((variant) => {
		const variantProp = props === null || props === void 0 ? void 0 : props[variant];
		const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
		if (variantProp === null) return null;
		const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
		return variants[variant][variantKey];
	});
	const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param) => {
		let [key, value] = param;
		if (value === void 0) return acc;
		acc[key] = value;
		return acc;
	}, {});
	return cx(base, getVariantClassNames, config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param) => {
		let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param;
		return Object.entries(compoundVariantOptions).every((param) => {
			let [key, value] = param;
			return Array.isArray(value) ? value.includes({
				...defaultVariants,
				...propsWithoutUndefined
			}[key]) : {
				...defaultVariants,
				...propsWithoutUndefined
			}[key] === value;
		}) ? [
			...acc,
			cvClass,
			cvClassName
		] : acc;
	}, []), props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
};
export { cva, cx };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xhc3MtdmFyaWFuY2UtYXV0aG9yaXR5LmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL2Nsc3gvZGlzdC9jbHN4Lm1qcyIsIi4uLy4uL2NsYXNzLXZhcmlhbmNlLWF1dGhvcml0eS9kaXN0L2luZGV4Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiByKGUpe3ZhciB0LGYsbj1cIlwiO2lmKFwic3RyaW5nXCI9PXR5cGVvZiBlfHxcIm51bWJlclwiPT10eXBlb2YgZSluKz1lO2Vsc2UgaWYoXCJvYmplY3RcIj09dHlwZW9mIGUpaWYoQXJyYXkuaXNBcnJheShlKSl7dmFyIG89ZS5sZW5ndGg7Zm9yKHQ9MDt0PG87dCsrKWVbdF0mJihmPXIoZVt0XSkpJiYobiYmKG4rPVwiIFwiKSxuKz1mKX1lbHNlIGZvcihmIGluIGUpZVtmXSYmKG4mJihuKz1cIiBcIiksbis9Zik7cmV0dXJuIG59ZXhwb3J0IGZ1bmN0aW9uIGNsc3goKXtmb3IodmFyIGUsdCxmPTAsbj1cIlwiLG89YXJndW1lbnRzLmxlbmd0aDtmPG87ZisrKShlPWFyZ3VtZW50c1tmXSkmJih0PXIoZSkpJiYobiYmKG4rPVwiIFwiKSxuKz10KTtyZXR1cm4gbn1leHBvcnQgZGVmYXVsdCBjbHN4OyIsIi8qKlxuICogQ29weXJpZ2h0IDIwMjIgSm9lIEJlbGwuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKlxuICogVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHRvIHlvdSB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wXG4gKiAodGhlIFwiTGljZW5zZVwiKTsgeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZVxuICogTGljZW5zZS4gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVRcbiAqIFdBUlJBTlRJRVMgT1IgUkVQUkVTRU5UQVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlXG4gKiBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9ucyB1bmRlclxuICogdGhlIExpY2Vuc2UuXG4gKi8gaW1wb3J0IHsgY2xzeCB9IGZyb20gXCJjbHN4XCI7XG5jb25zdCBmYWxzeVRvU3RyaW5nID0gKHZhbHVlKT0+dHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiA/IGAke3ZhbHVlfWAgOiB2YWx1ZSA9PT0gMCA/IFwiMFwiIDogdmFsdWU7XG5leHBvcnQgY29uc3QgY3ggPSBjbHN4O1xuZXhwb3J0IGNvbnN0IGN2YSA9IChiYXNlLCBjb25maWcpPT4ocHJvcHMpPT57XG4gICAgICAgIHZhciBfY29uZmlnX2NvbXBvdW5kVmFyaWFudHM7XG4gICAgICAgIGlmICgoY29uZmlnID09PSBudWxsIHx8IGNvbmZpZyA9PT0gdm9pZCAwID8gdm9pZCAwIDogY29uZmlnLnZhcmlhbnRzKSA9PSBudWxsKSByZXR1cm4gY3goYmFzZSwgcHJvcHMgPT09IG51bGwgfHwgcHJvcHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHByb3BzLmNsYXNzLCBwcm9wcyA9PT0gbnVsbCB8fCBwcm9wcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogcHJvcHMuY2xhc3NOYW1lKTtcbiAgICAgICAgY29uc3QgeyB2YXJpYW50cywgZGVmYXVsdFZhcmlhbnRzIH0gPSBjb25maWc7XG4gICAgICAgIGNvbnN0IGdldFZhcmlhbnRDbGFzc05hbWVzID0gT2JqZWN0LmtleXModmFyaWFudHMpLm1hcCgodmFyaWFudCk9PntcbiAgICAgICAgICAgIGNvbnN0IHZhcmlhbnRQcm9wID0gcHJvcHMgPT09IG51bGwgfHwgcHJvcHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHByb3BzW3ZhcmlhbnRdO1xuICAgICAgICAgICAgY29uc3QgZGVmYXVsdFZhcmlhbnRQcm9wID0gZGVmYXVsdFZhcmlhbnRzID09PSBudWxsIHx8IGRlZmF1bHRWYXJpYW50cyA9PT0gdm9pZCAwID8gdm9pZCAwIDogZGVmYXVsdFZhcmlhbnRzW3ZhcmlhbnRdO1xuICAgICAgICAgICAgaWYgKHZhcmlhbnRQcm9wID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IHZhcmlhbnRLZXkgPSBmYWxzeVRvU3RyaW5nKHZhcmlhbnRQcm9wKSB8fCBmYWxzeVRvU3RyaW5nKGRlZmF1bHRWYXJpYW50UHJvcCk7XG4gICAgICAgICAgICByZXR1cm4gdmFyaWFudHNbdmFyaWFudF1bdmFyaWFudEtleV07XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBwcm9wc1dpdGhvdXRVbmRlZmluZWQgPSBwcm9wcyAmJiBPYmplY3QuZW50cmllcyhwcm9wcykucmVkdWNlKChhY2MsIHBhcmFtKT0+e1xuICAgICAgICAgICAgbGV0IFtrZXksIHZhbHVlXSA9IHBhcmFtO1xuICAgICAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWNjO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYWNjW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiBhY2M7XG4gICAgICAgIH0sIHt9KTtcbiAgICAgICAgY29uc3QgZ2V0Q29tcG91bmRWYXJpYW50Q2xhc3NOYW1lcyA9IGNvbmZpZyA9PT0gbnVsbCB8fCBjb25maWcgPT09IHZvaWQgMCA/IHZvaWQgMCA6IChfY29uZmlnX2NvbXBvdW5kVmFyaWFudHMgPSBjb25maWcuY29tcG91bmRWYXJpYW50cykgPT09IG51bGwgfHwgX2NvbmZpZ19jb21wb3VuZFZhcmlhbnRzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfY29uZmlnX2NvbXBvdW5kVmFyaWFudHMucmVkdWNlKChhY2MsIHBhcmFtKT0+e1xuICAgICAgICAgICAgbGV0IHsgY2xhc3M6IGN2Q2xhc3MsIGNsYXNzTmFtZTogY3ZDbGFzc05hbWUsIC4uLmNvbXBvdW5kVmFyaWFudE9wdGlvbnMgfSA9IHBhcmFtO1xuICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKGNvbXBvdW5kVmFyaWFudE9wdGlvbnMpLmV2ZXJ5KChwYXJhbSk9PntcbiAgICAgICAgICAgICAgICBsZXQgW2tleSwgdmFsdWVdID0gcGFyYW07XG4gICAgICAgICAgICAgICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUuaW5jbHVkZXMoe1xuICAgICAgICAgICAgICAgICAgICAuLi5kZWZhdWx0VmFyaWFudHMsXG4gICAgICAgICAgICAgICAgICAgIC4uLnByb3BzV2l0aG91dFVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIH1ba2V5XSkgOiAoe1xuICAgICAgICAgICAgICAgICAgICAuLi5kZWZhdWx0VmFyaWFudHMsXG4gICAgICAgICAgICAgICAgICAgIC4uLnByb3BzV2l0aG91dFVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIH0pW2tleV0gPT09IHZhbHVlO1xuICAgICAgICAgICAgfSkgPyBbXG4gICAgICAgICAgICAgICAgLi4uYWNjLFxuICAgICAgICAgICAgICAgIGN2Q2xhc3MsXG4gICAgICAgICAgICAgICAgY3ZDbGFzc05hbWVcbiAgICAgICAgICAgIF0gOiBhY2M7XG4gICAgICAgIH0sIFtdKTtcbiAgICAgICAgcmV0dXJuIGN4KGJhc2UsIGdldFZhcmlhbnRDbGFzc05hbWVzLCBnZXRDb21wb3VuZFZhcmlhbnRDbGFzc05hbWVzLCBwcm9wcyA9PT0gbnVsbCB8fCBwcm9wcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogcHJvcHMuY2xhc3MsIHByb3BzID09PSBudWxsIHx8IHByb3BzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwcm9wcy5jbGFzc05hbWUpO1xuICAgIH07XG5cbiJdLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVMsRUFBRSxHQUFFO0NBQUMsSUFBSSxHQUFFLEdBQUUsSUFBRTtDQUFHLElBQUcsWUFBVSxPQUFPLEtBQUcsWUFBVSxPQUFPLEdBQUUsS0FBRztNQUFPLElBQUcsWUFBVSxPQUFPLEdBQUUsSUFBRyxNQUFNLFFBQVEsQ0FBQyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUU7RUFBTyxLQUFJLElBQUUsR0FBRSxJQUFFLEdBQUUsS0FBSSxFQUFFLE9BQUssSUFBRSxFQUFFLEVBQUUsRUFBRSxPQUFLLE1BQUksS0FBRyxNQUFLLEtBQUc7Q0FBRSxPQUFNLEtBQUksS0FBSyxHQUFFLEVBQUUsT0FBSyxNQUFJLEtBQUcsTUFBSyxLQUFHO0NBQUcsT0FBTztBQUFDO0FBQUMsU0FBZ0IsT0FBTTtDQUFDLEtBQUksSUFBSSxHQUFFLEdBQUUsSUFBRSxHQUFFLElBQUUsSUFBRyxJQUFFLFVBQVUsUUFBTyxJQUFFLEdBQUUsS0FBSSxDQUFDLElBQUUsVUFBVSxRQUFNLElBQUUsRUFBRSxDQUFDLE9BQUssTUFBSSxLQUFHLE1BQUssS0FBRztDQUFHLE9BQU87QUFBQzs7Ozs7Ozs7Ozs7Ozs7OztHQ2UvVyxJQUFNLGlCQUFpQixVQUFRLE9BQU8sVUFBVSxZQUFZLEdBQUcsVUFBVSxVQUFVLElBQUksTUFBTTtBQUM3RixJQUFhLEtBQUs7QUFDbEIsSUFBYSxPQUFPLE1BQU0sWUFBVSxVQUFRO0NBQ3BDLElBQUk7Q0FDSixLQUFLLFdBQVcsUUFBUSxXQUFXLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxhQUFhLE1BQU0sT0FBTyxHQUFHLE1BQU0sVUFBVSxRQUFRLFVBQVUsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxRQUFRLFVBQVUsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLFNBQVM7Q0FDdk4sTUFBTSxFQUFFLFVBQVUsb0JBQW9CO0NBQ3RDLE1BQU0sdUJBQXVCLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxLQUFLLFlBQVU7RUFDOUQsTUFBTSxjQUFjLFVBQVUsUUFBUSxVQUFVLEtBQUssSUFBSSxLQUFLLElBQUksTUFBTTtFQUN4RSxNQUFNLHFCQUFxQixvQkFBb0IsUUFBUSxvQkFBb0IsS0FBSyxJQUFJLEtBQUssSUFBSSxnQkFBZ0I7RUFDN0csSUFBSSxnQkFBZ0IsTUFBTSxPQUFPO0VBQ2pDLE1BQU0sYUFBYSxjQUFjLFdBQVcsS0FBSyxjQUFjLGtCQUFrQjtFQUNqRixPQUFPLFNBQVMsUUFBUSxDQUFDO0NBQzdCLENBQUM7Q0FDRCxNQUFNLHdCQUF3QixTQUFTLE9BQU8sUUFBUSxLQUFLLENBQUMsQ0FBQyxRQUFRLEtBQUssVUFBUTtFQUM5RSxJQUFJLENBQUMsS0FBSyxTQUFTO0VBQ25CLElBQUksVUFBVSxLQUFBLEdBQ1YsT0FBTztFQUVYLElBQUksT0FBTztFQUNYLE9BQU87Q0FDWCxHQUFHLENBQUMsQ0FBQztDQWtCTCxPQUFPLEdBQUcsTUFBTSxzQkFqQnFCLFdBQVcsUUFBUSxXQUFXLEtBQUssSUFBSSxLQUFLLEtBQUssMkJBQTJCLE9BQU8sc0JBQXNCLFFBQVEsNkJBQTZCLEtBQUssSUFBSSxLQUFLLElBQUkseUJBQXlCLFFBQVEsS0FBSyxVQUFRO0VBQy9PLElBQUksRUFBRSxPQUFPLFNBQVMsV0FBVyxhQUFhLEdBQUcsMkJBQTJCO0VBQzVFLE9BQU8sT0FBTyxRQUFRLHNCQUFzQixDQUFDLENBQUMsT0FBTyxVQUFRO0dBQ3pELElBQUksQ0FBQyxLQUFLLFNBQVM7R0FDbkIsT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sU0FBUztJQUN6QyxHQUFHO0lBQ0gsR0FBRztHQUNQLEVBQUUsSUFBSSxJQUFLO0lBQ1AsR0FBRztJQUNILEdBQUc7R0FDUCxFQUFHLFNBQVM7RUFDaEIsQ0FBQyxJQUFJO0dBQ0QsR0FBRztHQUNIO0dBQ0E7RUFDSixJQUFJO0NBQ1IsR0FBRyxDQUFDLENBQUMsR0FDK0QsVUFBVSxRQUFRLFVBQVUsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxRQUFRLFVBQVUsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLFNBQVM7QUFDaE0iLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxXX0=