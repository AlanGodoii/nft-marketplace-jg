import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/session-boundary.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { getToken, onSessionExpired, registerSessionCleanup } from "/src/lib/identity.ts";
import { Button } from "/src/components/ui/button.tsx";
import { useSession, sessionKey } from "/src/features/auth/api.ts";
import { clearScopedData } from "/src/features/auth/lifecycle.ts";
import { safeReturnTo } from "/src/features/auth/redirect.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/auth/session-boundary.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function SessionBoundary() {
	_s();
	const session = useSession();
	const { data: activeSession, refetch } = session;
	const router = useRouter();
	const client = useQueryClient();
	useEffect(() => onSessionExpired(() => {
		void clearScopedData().then(() => {
			client.setQueryData(sessionKey, null);
			void router.navigate({
				to: "/login",
				search: { redirect: safeReturnTo(router.state.location.href) },
				replace: true
			});
		});
	}), [client, router]);
	useEffect(() => {
		if (!activeSession) return;
		const timer = window.setTimeout(() => {
			void refetch();
		}, Math.max(0, Date.parse(activeSession.expiresAt) - Date.now()));
		const storageChanged = (event) => {
			if (event.key === "kurio.mock.commerce.v1") {
				void client.invalidateQueries({ queryKey: sessionKey });
				void client.invalidateQueries({ predicate: (query) => query.queryKey[0] === "private" || query.queryKey[0] === "cart" });
			}
		};
		window.addEventListener("storage", storageChanged);
		const stop = () => {
			clearTimeout(timer);
			window.removeEventListener("storage", storageChanged);
		};
		const unregister = registerSessionCleanup(stop);
		return () => {
			stop();
			unregister();
		};
	}, [
		client,
		activeSession,
		refetch
	]);
	if (session.isError && getToken()) return /* @__PURE__ */ _jsxDEV("div", {
		role: "alert",
		className: "mb-6 rounded border p-4",
		children: ["Não foi possível verificar sua sessão. ", /* @__PURE__ */ _jsxDEV(Button, {
			onClick: () => void refetch(),
			children: "Verificar sessão novamente"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 138
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 45
	}, this);
	return null;
}
_s(SessionBoundary, "nnGj2wfY5NPGPlx1yMO/Erad7rg=", false, function() {
	return [
		useSession,
		useRouter,
		useQueryClient
	];
});
_c = SessionBoundary;
var _c;
$RefreshReg$(_c, "SessionBoundary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/session-boundary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/auth/session-boundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/auth/session-boundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/auth/session-boundary.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxVQUFVLGtCQUFrQiw4QkFBOEI7QUFDbkUsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsWUFBWSxrQkFBa0I7QUFDdkMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxvQkFBb0I7Ozs7QUFFN0IsT0FBTyxTQUFTLGtCQUFrQjs7Q0FDaEMsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsTUFBTSxFQUFFLE1BQU0sZUFBZSxZQUFZO0NBQ3pDLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sU0FBUyxlQUFlO0NBQzlCLGdCQUFnQix1QkFBdUI7RUFDckMsS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDLFdBQVc7R0FDaEMsT0FBTyxhQUFhLFlBQVksSUFBSTtHQUNwQyxLQUFLLE9BQU8sU0FBUztJQUFFLElBQUk7SUFBVSxRQUFRLEVBQUUsVUFBVSxhQUFhLE9BQU8sTUFBTSxTQUFTLElBQUksRUFBRTtJQUFHLFNBQVM7R0FBSyxDQUFDO0VBQ3RILENBQUM7Q0FDSCxDQUFDLEdBQUcsQ0FBQyxRQUFRLE1BQU0sQ0FBQztDQUNwQixnQkFBZ0I7RUFDZCxJQUFJLENBQUMsZUFBZTtFQUNwQixNQUFNLFFBQVEsT0FBTyxpQkFBaUI7R0FBRSxLQUFLLFFBQVE7RUFBRSxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxjQUFjLFNBQVMsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDO0VBQ3ZILE1BQU0sa0JBQWtCLFVBQXdCO0dBQzlDLElBQUksTUFBTSxRQUFRLDBCQUEwQjtJQUMxQyxLQUFLLE9BQU8sa0JBQWtCLEVBQUUsVUFBVSxXQUFXLENBQUM7SUFDdEQsS0FBSyxPQUFPLGtCQUFrQixFQUFFLFlBQVcsVUFBUyxNQUFNLFNBQVMsT0FBTyxhQUFhLE1BQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQztHQUN2SDtFQUNGO0VBQ0EsT0FBTyxpQkFBaUIsV0FBVyxjQUFjO0VBQ2pELE1BQU0sYUFBYTtHQUFFLGFBQWEsS0FBSztHQUFHLE9BQU8sb0JBQW9CLFdBQVcsY0FBYztFQUFFO0VBQ2hHLE1BQU0sYUFBYSx1QkFBdUIsSUFBSTtFQUM5QyxhQUFhO0dBQUUsS0FBSztHQUFHLFdBQVc7RUFBRTtDQUN0QyxHQUFHO0VBQUM7RUFBUTtFQUFlO0NBQU8sQ0FBQztDQUNuQyxJQUFJLFFBQVEsV0FBVyxTQUFTLEdBQUcsT0FBTyx3QkFBQyxPQUFEO0VBQUssTUFBSztFQUFRLFdBQVU7WUFBNUIsQ0FBc0QsMkNBQXVDLHdCQUFDLFFBQUQ7R0FBUSxlQUFlLEtBQUssUUFBUTthQUFHO0VBQWtDOzs7O1VBQU07Ozs7OztDQUN0TixPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsic2Vzc2lvbi1ib3VuZGFyeS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBnZXRUb2tlbiwgb25TZXNzaW9uRXhwaXJlZCwgcmVnaXN0ZXJTZXNzaW9uQ2xlYW51cCB9IGZyb20gJ0AvbGliL2lkZW50aXR5J1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IHVzZVNlc3Npb24sIHNlc3Npb25LZXkgfSBmcm9tICcuL2FwaSdcbmltcG9ydCB7IGNsZWFyU2NvcGVkRGF0YSB9IGZyb20gJy4vbGlmZWN5Y2xlJ1xuaW1wb3J0IHsgc2FmZVJldHVyblRvIH0gZnJvbSAnLi9yZWRpcmVjdCdcblxuZXhwb3J0IGZ1bmN0aW9uIFNlc3Npb25Cb3VuZGFyeSgpIHtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKVxuICBjb25zdCB7IGRhdGE6IGFjdGl2ZVNlc3Npb24sIHJlZmV0Y2ggfSA9IHNlc3Npb25cbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuICB1c2VFZmZlY3QoKCkgPT4gb25TZXNzaW9uRXhwaXJlZCgoKSA9PiB7XG4gICAgdm9pZCBjbGVhclNjb3BlZERhdGEoKS50aGVuKCgpID0+IHtcbiAgICAgIGNsaWVudC5zZXRRdWVyeURhdGEoc2Vzc2lvbktleSwgbnVsbClcbiAgICAgIHZvaWQgcm91dGVyLm5hdmlnYXRlKHsgdG86ICcvbG9naW4nLCBzZWFyY2g6IHsgcmVkaXJlY3Q6IHNhZmVSZXR1cm5Ubyhyb3V0ZXIuc3RhdGUubG9jYXRpb24uaHJlZikgfSwgcmVwbGFjZTogdHJ1ZSB9KVxuICAgIH0pXG4gIH0pLCBbY2xpZW50LCByb3V0ZXJdKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghYWN0aXZlU2Vzc2lvbikgcmV0dXJuXG4gICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7IHZvaWQgcmVmZXRjaCgpIH0sIE1hdGgubWF4KDAsIERhdGUucGFyc2UoYWN0aXZlU2Vzc2lvbi5leHBpcmVzQXQpIC0gRGF0ZS5ub3coKSkpXG4gICAgY29uc3Qgc3RvcmFnZUNoYW5nZWQgPSAoZXZlbnQ6IFN0b3JhZ2VFdmVudCkgPT4ge1xuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ2t1cmlvLm1vY2suY29tbWVyY2UudjEnKSB7XG4gICAgICAgIHZvaWQgY2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHNlc3Npb25LZXkgfSlcbiAgICAgICAgdm9pZCBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBwcmVkaWNhdGU6IHF1ZXJ5ID0+IHF1ZXJ5LnF1ZXJ5S2V5WzBdID09PSAncHJpdmF0ZScgfHwgcXVlcnkucXVlcnlLZXlbMF0gPT09ICdjYXJ0JyB9KVxuICAgICAgfVxuICAgIH1cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc3RvcmFnZScsIHN0b3JhZ2VDaGFuZ2VkKVxuICAgIGNvbnN0IHN0b3AgPSAoKSA9PiB7IGNsZWFyVGltZW91dCh0aW1lcik7IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdzdG9yYWdlJywgc3RvcmFnZUNoYW5nZWQpIH1cbiAgICBjb25zdCB1bnJlZ2lzdGVyID0gcmVnaXN0ZXJTZXNzaW9uQ2xlYW51cChzdG9wKVxuICAgIHJldHVybiAoKSA9PiB7IHN0b3AoKTsgdW5yZWdpc3RlcigpIH1cbiAgfSwgW2NsaWVudCwgYWN0aXZlU2Vzc2lvbiwgcmVmZXRjaF0pXG4gIGlmIChzZXNzaW9uLmlzRXJyb3IgJiYgZ2V0VG9rZW4oKSkgcmV0dXJuIDxkaXYgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwibWItNiByb3VuZGVkIGJvcmRlciBwLTRcIj5Ow6NvIGZvaSBwb3Nzw612ZWwgdmVyaWZpY2FyIHN1YSBzZXNzw6NvLiA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHZvaWQgcmVmZXRjaCgpfT5WZXJpZmljYXIgc2Vzc8OjbyBub3ZhbWVudGU8L0J1dHRvbj48L2Rpdj5cbiAgcmV0dXJuIG51bGxcbn1cbiJdfQ==