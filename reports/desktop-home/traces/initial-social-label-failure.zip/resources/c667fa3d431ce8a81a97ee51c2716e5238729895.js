import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/carteiras.tsx");const $$splitComponentImporter = () => import("/src/routes/carteiras.tsx?tsr-split=component");
import { lazyRouteComponent } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { createFileRoute } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { requireSession } from "/src/features/auth/guard.ts";
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
export const Route = createFileRoute("/carteiras")({
	beforeLoad: requireSession,
	component: TSRSplitComponent
});
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("/workspace/nft-marketplace-jg/src/routes/carteiras.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/carteiras" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/carteiras";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/carteiras.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/routes/carteiras.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/routes/carteiras.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/routes/carteiras.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTQSx1QkFBdUI7QUFDaEMsU0FBU0Msc0JBQXNCO0FBQXVCLE1BQUFDLDJCQUFBO0NBQUEsTUFBQUMsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixVQUFBRyxTQUFBLEtBQUFDO0NBQUEsT0FBQUYsVUFBQSxvQ0FBQUcsbUJBQUFDLDBCQUFBO0FBQUE7QUFBQSxJQUFBTCxZQUFBRCxLQUFBO0NBQUEsQ0FBQUMsWUFBQUQsSUFBQUcsU0FBQSx1Q0FBQUo7QUFBQTtBQUV0RCxPQUFPLE1BQU1RLFFBQVFWLGdCQUFnQixZQUFZLENBQUMsQ0FBQztDQUFFVyxZQUFZVjtDQUFnQlcsV0FBU1Y7QUFBYyxDQUFDO0FBQUMsTUFBQUMsTUFBQUMsWUFBQUQ7QUFBQSxJQUFBQSxPQUFBLE9BQUFVLFdBQUE7Q0FBQVYsSUFBQUcsU0FBQTtDQUFBLE1BQUFRLGtCQUFBRCxPQUFBRSxpQ0FBQTtFQUFBLE1BQUFDLHFCQUFBLElBQUFDLElBQUE7RUFBQSxNQUFBQyw0QkFBQUwsT0FBQU07RUFBQU4sT0FBQU0sbUNBQUFDLFFBQUE7R0FBQSxNQUFBQyxpQkFBQUgsNEJBQUFFLEdBQUE7R0FBQSxNQUFBRSxnQkFBQU4sbUJBQUFPLElBQUFILElBQUFJLEVBQUE7R0FBQSxXQUFBSCxnQkFBQSxHQUFBQyxhQUFBO0VBQUE7RUFBQSxTQUFBTixtQkFBQTtDQUFBO0NBQUFGLGdCQUFBRSxtQkFBQVMsSUFBQTtBQUFBO0FBQUEsZ0JBQUFDLHVCQUFBO0NBQUE7QUFBQTs7QUFBQSxJQUFBdEIsWUFBQUQsS0FBQTtDQUFBLE1BQUFBLE1BQUFDLFlBQUFEO0NBQUEsTUFBQUUsVUFBQUYsSUFBQUcsU0FBQTtDQUFBLE1BQUFxQixvQkFBQSxTQUFBQSxrQkFBQUMsU0FBQUMsVUFBQTtFQUFBLE1BQUFDLFNBQUFqQixPQUFBa0I7RUFBQSxNQUFBQyxXQUFBRixPQUFBRyxXQUFBTDtFQUFBLEtBQUFJLFVBQUE7RUFBQSxNQUFBRSwyQkFBQSxJQUFBQyxJQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxNQUFBQyx3QkFBQTtFQUFBRix5QkFBQUcsU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFNBQUFILHNCQUFBRSxPQUFBTixTQUFBTyxRQUFBRDtFQUFBO0VBQUEsTUFBQUUsNEJBQUEsb0JBQUFSLFNBQUFPLFlBQUEsb0JBQUFWLFNBQUFVO0VBQUEsTUFBQUUsZ0JBQUE7R0FBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxJQUFBRCwyQkFBQUMsY0FBQUosU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFdBQUFELE9BQUFULFNBQUFVLFNBQUFWLFNBQUFVLFFBQUFELE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBSSxjQUFBO0dBQUEsR0FBQWIsU0FBQVU7R0FBQSxHQUFBSDtFQUFBO0VBQUFKLFNBQUFPLFVBQUFHO0VBQUFWLFNBQUFXLE9BQUFELFdBQUE7RUFBQVosT0FBQWMsbUJBQUFaLFVBQUFILFNBQUFnQixNQUFBO0VBQUFmLE9BQUFnQixVQUFBaEIsT0FBQWlCLGVBQUE7RUFBQUMsbUJBQUFoQixRQUFBO0VBQUFGLE9BQUFtQixpQkFBQUMsTUFBQTtFQUFBcEIsT0FBQXFCLGdCQUFBO0VBQUEsU0FBQUgsbUJBQUFJLFdBQUE7R0FBQXZCLFNBQUFVLFVBQUFhLFVBQUFiO0dBQUFWLFNBQUF3QixjQUFBRCxVQUFBQztHQUFBeEIsU0FBQXlCLFFBQUFGLFVBQUFFO0dBQUF6QixTQUFBMEIsTUFBQUgsVUFBQUc7R0FBQTFCLFNBQUEyQixZQUFBSixVQUFBSTtHQUFBM0IsU0FBQTRCLE1BQUFMLFVBQUFLO0VBQUE7Q0FBQTtDQUFBLE1BQUFDLGlCQUFBLGdCQUFBckQsUUFBQTtDQUFBLElBQUFxRCxnQkFBQTtFQUFBckQsUUFBQSxrQkFBQXFEO0NBQUE7Q0FBQSxNQUFBQyxnQkFBQSxPQUFBOUMsV0FBQSxlQUFBNkMsaUJBQUE3QyxPQUFBa0IsZ0JBQUFFLGFBQUF5QixrQkFBQW5EO0NBQUEsSUFBQW1ELGtCQUFBQyxtQ0FBQWpELE9BQUE7RUFBQWlCLGtCQUFBK0IsZ0JBQUFoRCxLQUFBO0VBQUFMLFFBQUEsOEJBQUFLO0NBQUE7Q0FBQVAsSUFBQXlELFFBQUFDLGNBQUE7RUFBQSxJQUFBbkQsU0FBQW1ELHVCQUFBbkQsT0FBQTtHQUFBLE1BQUFrQixVQUFBdkIsUUFBQTtHQUFBLElBQUF1QixTQUFBO0lBQUF2QixRQUFBLGtCQUFBdUI7R0FBQTtHQUFBLElBQUF2QixRQUFBLGdDQUFBd0QsVUFBQW5ELE9BQUE7SUFBQSxPQUFBTCxRQUFBO0lBQUE7R0FBQTtHQUFBc0Isa0JBQUFDLFNBQUFpQyxVQUFBbkQsS0FBQTtFQUFBO0NBQUE7QUFBQSIsIm5hbWVzIjpbImNyZWF0ZUZpbGVSb3V0ZSIsInJlcXVpcmVTZXNzaW9uIiwiVFNSU3BsaXRDb21wb25lbnQiLCJob3QiLCJpbXBvcnQiLCJob3REYXRhIiwiZGF0YSIsInVuZGVmaW5lZCIsImxhenlSb3V0ZUNvbXBvbmVudCIsIiQkc3BsaXRDb21wb25lbnRJbXBvcnRlciIsIlJvdXRlIiwiYmVmb3JlTG9hZCIsImNvbXBvbmVudCIsIndpbmRvdyIsInRzclJlYWN0UmVmcmVzaCIsIl9fVFNSX1JFQUNUX1JFRlJFU0hfXyIsImlnbm9yZWRFeHBvcnRzQnlJZCIsIk1hcCIsInByZXZpb3VzR2V0SWdub3JlZEV4cG9ydHMiLCJfX2dldFJlYWN0UmVmcmVzaElnbm9yZWRFeHBvcnRzIiwiY3R4IiwiaWdub3JlZEV4cG9ydHMiLCJtb2R1bGVJZ25vcmVkIiwiZ2V0IiwiaWQiLCJzZXQiLCJUU1JGYXN0UmVmcmVzaEFuY2hvciIsImhhbmRsZVJvdXRlVXBkYXRlIiwicm91dGVJZCIsIm5ld1JvdXRlIiwicm91dGVyIiwiX19UU1JfUk9VVEVSX18iLCJvbGRSb3V0ZSIsInJvdXRlc0J5SWQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbktleXMiLCJTZXQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbnMiLCJmb3JFYWNoIiwia2V5Iiwib3B0aW9ucyIsInByZXNlcnZlQ29tcG9uZW50SWRlbnRpdHkiLCJjb21wb25lbnRLZXlzIiwibmV4dE9wdGlvbnMiLCJ1cGRhdGUiLCJfcmVwbGFjZVJvdXRlQ2h1bmsiLCJsYXp5Rm4iLCJzZXRSb3V0ZXMiLCJidWlsZFJvdXRlVHJlZSIsInN5bmNIb3RSb3V0ZUV4cG9ydCIsInJlc29sdmVQYXRoQ2FjaGUiLCJjbGVhciIsIl9yZWZyZXNoUm91dGUiLCJsaXZlUm91dGUiLCJwYXJlbnRSb3V0ZSIsIl9wYXRoIiwiX2lkIiwiX2Z1bGxQYXRoIiwiX3RvIiwiaW5pdGlhbFJvdXRlSWQiLCJleGlzdGluZ1JvdXRlIiwiYWNjZXB0IiwibmV3TW9kdWxlIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNhcnRlaXJhcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlRmlsZVJvdXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHJlcXVpcmVTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2d1YXJkJ1xuaW1wb3J0IHsgV2FsbGV0c1BhZ2UgfSBmcm9tICdAL2ZlYXR1cmVzL3dhbGxldHMvd2FsbGV0cy1wYWdlJ1xuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvY2FydGVpcmFzJykoeyBiZWZvcmVMb2FkOiByZXF1aXJlU2Vzc2lvbiwgY29tcG9uZW50OiBXYWxsZXRzUGFnZSB9KVxuIl0sImZpbGUiOiIvd29ya3NwYWNlL25mdC1tYXJrZXRwbGFjZS1qZy9zcmMvcm91dGVzL2NhcnRlaXJhcy50c3gifQ==