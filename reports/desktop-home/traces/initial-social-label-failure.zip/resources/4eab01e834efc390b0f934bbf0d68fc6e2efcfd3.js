import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=22c23eb4";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=22c23eb4";
import { a as isReactVersionAtLeast, d as useStableCallback, f as useRefWithInit, i as NOOP, l as useIsoLayoutEffect, o as useMergedRefs, r as EMPTY_OBJECT, t as useRenderElement } from "/node_modules/.vite/deps/useRenderElement-CZQFg9u0.js?v=22c23eb4";
import { a as getWindow, c as isLastTraversableNode, d as isShadowRoot, i as getParentNode, l as isNode, n as getComputedStyle$1, o as isElement, r as getNodeName, s as isHTMLElement, t as useButton, u as isOverflowElement } from "/node_modules/.vite/deps/useButton-CRG4Stvb.js?v=22c23eb4";
import { a as useId, c as escapeKey, d as none, f as outsidePress, h as createChangeEventDetails, i as useBaseUiId, l as focusOut, m as triggerPress, n as useTimeout, o as useForcedRerendering, r as useOnMount, s as closePress, t as Timeout, u as imperativeAction } from "/node_modules/.vite/deps/useTimeout-BjiHMGRn.js?v=22c23eb4";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=22c23eb4";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-CRx58tZq.js?v=22c23eb4";
import { n as require_shim, t as require_with_selector } from "/node_modules/.vite/deps/with-selector-BkKkVbnc.js?v=22c23eb4";
// node_modules/@base-ui/utils/owner.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var import_jsx_runtime = require_jsx_runtime();
function ownerDocument(node) {
	return node?.ownerDocument || document;
}
// node_modules/@base-ui/react/dialog/root/DialogRootContext.mjs
var DialogRootContext = /*#__PURE__*/ import_react.createContext(void 0);
DialogRootContext.displayName = "DialogRootContext";
function useDialogRootContext(optional) {
	const store = import_react.useContext(DialogRootContext);
	if (!optional && store === void 0) throw new Error("Base UI: DialogRootContext is missing. Dialog parts must be placed within <Dialog.Root>.");
	return store;
}
// node_modules/@base-ui/react/internals/TransitionStatusDataAttributes.mjs
/**
* Present when the component begins animating in.
*/
var startingStyle$4 = "data-starting-style";
/**
* Present when the component is animating out.
*/
var endingStyle$4 = "data-ending-style";
// node_modules/@base-ui/react/internals/stateAttributesMapping.mjs
var STARTING_HOOK = { [startingStyle$4]: "" };
var ENDING_HOOK = { [endingStyle$4]: "" };
var transitionStatusMapping = { transitionStatus(value) {
	if (value === "starting") return STARTING_HOOK;
	if (value === "ending") return ENDING_HOOK;
	return null;
} };
// node_modules/@base-ui/react/utils/CommonPopupDataAttributes.mjs
/**
* Present when the popup is open.
*/
var open$3 = "data-open";
/**
* Present when the popup is closed.
*/
var closed$3 = "data-closed";
/**
* Present when the popup begins animating in.
*/
var startingStyle$3 = startingStyle$4;
/**
* Present when the popup is animating out.
*/
var endingStyle$3 = endingStyle$4;
/**
* Present when the anchor is hidden.
*/
var anchorHidden = "data-anchor-hidden";
// node_modules/@base-ui/react/utils/CommonTriggerDataAttributes.mjs
/**
* Present when the popup is open.
*/
var popupOpen$1 = "data-popup-open";
// node_modules/@base-ui/react/utils/popupStateMapping.mjs
var TRIGGER_HOOK = { [popupOpen$1]: "" };
var POPUP_OPEN_HOOK = { [open$3]: "" };
var POPUP_CLOSED_HOOK = { [closed$3]: "" };
var ANCHOR_HIDDEN_HOOK = { [anchorHidden]: "" };
var triggerOpenStateMapping = { open(value) {
	if (value) return TRIGGER_HOOK;
	return null;
} };
var popupStateMapping = {
	open(value) {
		if (value) return POPUP_OPEN_HOOK;
		return POPUP_CLOSED_HOOK;
	},
	anchorHidden(value) {
		if (value) return ANCHOR_HIDDEN_HOOK;
		return null;
	}
};
var popupTransitionStateMapping = {
	...popupStateMapping,
	...transitionStatusMapping
};
// node_modules/@base-ui/react/dialog/backdrop/DialogBackdrop.mjs
/**
* An overlay displayed beneath the popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogBackdrop = /*#__PURE__*/ import_react.forwardRef(function DialogBackdrop(componentProps, forwardedRef) {
	const { render, className, style, forceRender = false, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const open = store.useState("open");
	const nested = store.useState("nested");
	const mounted = store.useState("mounted");
	const state = {
		open,
		transitionStatus: store.useState("transitionStatus")
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: [store.context.backdropRef, forwardedRef],
		stateAttributesMapping: popupTransitionStateMapping,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: {
				userSelect: "none",
				WebkitUserSelect: "none"
			}
		}, elementProps],
		enabled: forceRender || !nested
	});
});
DialogBackdrop.displayName = "DialogBackdrop";
// node_modules/@base-ui/react/dialog/close/DialogClose.mjs
/**
* A button that closes the dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogClose = /*#__PURE__*/ import_react.forwardRef(function DialogClose(componentProps, forwardedRef) {
	const { render, className, style, disabled = false, nativeButton = true, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const open = store.useState("open");
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const state = { disabled };
	function handleClick(event) {
		if (open) store.setOpen(false, createChangeEventDetails(closePress, event.nativeEvent));
	}
	return useRenderElement("button", componentProps, {
		state,
		ref: [forwardedRef, buttonRef],
		props: [
			{ onClick: handleClick },
			elementProps,
			getButtonProps
		]
	});
});
DialogClose.displayName = "DialogClose";
// node_modules/@base-ui/react/dialog/description/DialogDescription.mjs
/**
* A paragraph with additional information about the dialog.
* Renders a `<p>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogDescription = /*#__PURE__*/ import_react.forwardRef(function DialogDescription(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const id = useBaseUiId(idProp);
	store.useSyncedValueWithCleanup("descriptionElementId", id);
	return useRenderElement("p", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
DialogDescription.displayName = "DialogDescription";
// node_modules/@base-ui/utils/platform/shared.mjs
/**
* Reads `navigator.userAgent` / `navigator.platform` (legacy but universally
* supported) into a normalized shape. In development, prefers the modern
* `navigator.userAgentData` API on Chromium to avoid DevTools warnings about
* the deprecated reads; that branch is dead-code-eliminated in production
* builds to keep the bundle small.
*
* Returns empty/zero values when `navigator` is undefined (SSR), so every
* derived flag safely evaluates to `false`.
*/
function readRawData() {
	if (typeof navigator === "undefined") return {
		userAgent: "",
		platform: "",
		maxTouchPoints: 0
	};
	{
		const uaData = navigator.userAgentData;
		if (uaData && Array.isArray(uaData.brands)) return {
			userAgent: uaData.brands.map(({ brand, version }) => `${brand}/${version}`).join(" "),
			platform: uaData.platform ?? navigator.platform ?? "",
			maxTouchPoints: navigator.maxTouchPoints ?? 0
		};
	}
	return {
		userAgent: navigator.userAgent,
		platform: navigator.platform ?? "",
		maxTouchPoints: navigator.maxTouchPoints ?? 0
	};
}
var { userAgent, platform, maxTouchPoints } = readRawData();
var lowerUserAgent = userAgent.toLowerCase();
var lowerPlatform = platform.toLowerCase();
// node_modules/@base-ui/utils/platform/os.mjs
/** iPhone, iPad (including iPadOS 13+ reporting as macOS), iPod. */
var ios = /^i(os$|p)/.test(lowerPlatform) || lowerPlatform === "macintel" && maxTouchPoints > 1;
/** Android phones, tablets, and embedded Android browsers. */
var ANDROID_STRING = "android";
var android = lowerPlatform === ANDROID_STRING || lowerUserAgent.includes(ANDROID_STRING);
/** macOS desktop. Excludes iPadOS, which reports as `MacIntel`. */
var mac = !ios && lowerPlatform.startsWith("mac");
lowerPlatform.startsWith("win");
!android && /^(linux|chrome os)/.test(lowerPlatform);
/** Any Apple OS (`mac || ios`). */
var apple = mac || ios;
// node_modules/@base-ui/utils/platform/engine.mjs
/** WebKit: Safari, all iOS browsers, GNOME Web. Excludes Blink. */
var webkit = typeof CSS !== "undefined" && !!CSS.supports?.("-webkit-backdrop-filter:none");
!webkit && lowerUserAgent.includes("firefox");
!webkit && lowerUserAgent.includes("chrom");
// node_modules/@base-ui/utils/platform/screen-reader.mjs
/**
* The user *may* be using VoiceOver — actual activation is not detectable.
* True on any Apple platform (macOS, iOS, iPadOS).
*/
var voiceOver = apple;
// node_modules/@base-ui/utils/platform/env.mjs
/** Running in jsdom or HappyDOM (used by unit tests). */
var jsdom = /jsdom|happydom/.test(lowerUserAgent);
// node_modules/@base-ui/react/floating-ui-react/utils/event.mjs
function stopEvent(event) {
	event.preventDefault();
	event.stopPropagation();
}
function isReactEvent(event) {
	return "nativeEvent" in event;
}
function isVirtualClick(event) {
	if (event.pointerType === "" && event.isTrusted) return true;
	if (android && event.pointerType) return event.type === "click" && event.buttons === 1;
	return event.detail === 0 && !event.pointerType;
}
function isVirtualPointerEvent(event) {
	if (jsdom) return false;
	return !android && event.width === 0 && event.height === 0 || event.type === "pointerdown" && event.width === 1 && event.height === 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "mouse" && (android || event.buttons === 0) || event.width < 1 && event.height < 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "touch";
}
function isMouseLikePointerType(pointerType, strict) {
	const values = ["mouse", "pen"];
	if (!strict) values.push("", void 0);
	return values.includes(pointerType);
}
function isClickLikeEvent(event) {
	const type = event.type;
	return type === "click" || type === "mousedown" || type === "keydown" || type === "keyup";
}
// node_modules/@base-ui/utils/shadowDom.mjs
function activeElement(doc) {
	let element = doc.activeElement;
	while (element?.shadowRoot?.activeElement != null) element = element.shadowRoot.activeElement;
	return element;
}
function contains(parent, child) {
	if (!parent || !child) return false;
	const rootNode = child.getRootNode?.();
	if (parent.contains(child)) return true;
	if (rootNode && isShadowRoot(rootNode)) {
		let next = child;
		while (next) {
			if (parent === next) return true;
			next = next.parentNode || next.host;
		}
	}
	return false;
}
/**
* Finds the closest matching element in the composed tree, crossing slots and shadow roots.
* `:scope` is not supported.
*/
function closest(node, selector) {
	let current = node;
	while (current) {
		if (isElement(current) && current.matches(selector)) return current;
		current = current.assignedSlot ?? current.parentNode ?? (isShadowRoot(current) ? current.host : null);
	}
	return null;
}
function getTarget(event) {
	if ("composedPath" in event) return event.composedPath()[0] ?? event.target;
	return event.target;
}
// node_modules/@base-ui/react/floating-ui-react/utils/constants.mjs
var FOCUSABLE_ATTRIBUTE = "data-base-ui-focusable";
// node_modules/@base-ui/react/floating-ui-react/utils/element.mjs
function isEventTargetWithin(event, node) {
	if (node == null) return false;
	if ("composedPath" in event) return event.composedPath().includes(node);
	const eventAgain = event;
	return eventAgain.target != null && node.contains(eventAgain.target);
}
function isRootElement(element) {
	return element.matches("html,body");
}
function isTypeableElement(element) {
	return isHTMLElement(element) && element.matches("input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])");
}
function isTypeableCombobox(element) {
	if (!element) return false;
	return element.getAttribute("role") === "combobox" && isTypeableElement(element);
}
function getFloatingFocusElement(floatingElement) {
	if (!floatingElement) return null;
	return floatingElement.hasAttribute("data-base-ui-focusable") ? floatingElement : floatingElement.querySelector(`[data-base-ui-focusable]`) || floatingElement;
}
// node_modules/@base-ui/utils/addEventListener.mjs
/**
* Adds an event listener and returns a cleanup function to remove it.
*/
function addEventListener(target, type, listener, options) {
	target.addEventListener(type, listener, options);
	return () => {
		target.removeEventListener(type, listener, options);
	};
}
// node_modules/@base-ui/utils/mergeCleanups.mjs
/**
* Combines multiple cleanup functions into a single cleanup function.
*/
function mergeCleanups(...cleanups) {
	return () => {
		for (let i = 0; i < cleanups.length; i += 1) {
			const cleanup = cleanups[i];
			if (cleanup) cleanup();
		}
	};
}
// node_modules/@base-ui/utils/useValueAsRef.mjs
/**
* Untracks the provided value by turning it into a ref to remove its reactivity.
*
* Used to access the passed value inside `React.useEffect` without causing the effect to re-run when the value changes.
*/
function useValueAsRef(value) {
	const latest = useRefWithInit(createLatestRef, value).current;
	latest.next = value;
	useIsoLayoutEffect(latest.effect);
	return latest;
}
function createLatestRef(value) {
	const latest = {
		current: value,
		next: value,
		effect: () => {
			latest.current = latest.next;
		}
	};
	return latest;
}
// node_modules/@base-ui/utils/useAnimationFrame.mjs
/** Unlike `setTimeout`, rAF doesn't guarantee a positive integer return value, so we can't have
* a monomorphic `uint` type with `0` meaning empty.
* See warning note at:
* https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame#return_value */
var EMPTY = null;
var LAST_RAF = globalThis.requestAnimationFrame;
var Scheduler = class {
	callbacks = [];
	callbacksCount = 0;
	nextId = 1;
	startId = 1;
	isScheduled = false;
	tick = (timestamp) => {
		this.isScheduled = false;
		const currentCallbacks = this.callbacks;
		const currentCallbacksCount = this.callbacksCount;
		this.callbacks = [];
		this.callbacksCount = 0;
		this.startId = this.nextId;
		if (currentCallbacksCount > 0) for (let i = 0; i < currentCallbacks.length; i += 1) currentCallbacks[i]?.(timestamp);
	};
	request(fn) {
		const id = this.nextId;
		this.nextId += 1;
		this.callbacks.push(fn);
		this.callbacksCount += 1;
		const didRAFChange = LAST_RAF !== requestAnimationFrame && (LAST_RAF = requestAnimationFrame, true);
		if (!this.isScheduled || didRAFChange) {
			requestAnimationFrame(this.tick);
			this.isScheduled = true;
		}
		return id;
	}
	cancel(id) {
		const index = id - this.startId;
		if (index < 0 || index >= this.callbacks.length) return;
		if (this.callbacks[index] === null) return;
		this.callbacks[index] = null;
		this.callbacksCount -= 1;
	}
};
var scheduler = new Scheduler();
var AnimationFrame = class AnimationFrame {
	static create() {
		return new AnimationFrame();
	}
	static request(fn) {
		return scheduler.request(fn);
	}
	static cancel(id) {
		return scheduler.cancel(id);
	}
	currentId = EMPTY;
	/**
	* Executes `fn` after `delay`, clearing any previously scheduled call.
	*/
	request(fn) {
		this.cancel();
		this.currentId = scheduler.request(() => {
			this.currentId = EMPTY;
			fn();
		});
	}
	cancel = () => {
		if (this.currentId !== EMPTY) {
			scheduler.cancel(this.currentId);
			this.currentId = EMPTY;
		}
	};
	disposeEffect = () => {
		return this.cancel;
	};
};
/**
* A `requestAnimationFrame` with automatic cleanup and guard.
*/
function useAnimationFrame() {
	const timeout = useRefWithInit(AnimationFrame.create).current;
	useOnMount(timeout.disposeEffect);
	return timeout;
}
// node_modules/@base-ui/utils/visuallyHidden.mjs
var visuallyHiddenBase = {
	clipPath: "inset(50%)",
	overflow: "hidden",
	whiteSpace: "nowrap",
	border: 0,
	padding: 0,
	width: 1,
	height: 1,
	margin: -1
};
var visuallyHidden = {
	...visuallyHiddenBase,
	position: "fixed",
	margin: 0,
	top: 0,
	left: 0
};
({ ...visuallyHiddenBase });
// node_modules/@base-ui/react/utils/FocusGuard.mjs
/**
* @internal
*/
var FocusGuard = /*#__PURE__*/ import_react.forwardRef(function FocusGuard(props, ref) {
	const [role, setRole] = import_react.useState();
	useIsoLayoutEffect(() => {
		if (voiceOver && webkit) setRole("button");
	}, []);
	const restProps = {
		tabIndex: 0,
		role
	};
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
		...props,
		ref,
		style: visuallyHidden,
		"aria-hidden": role ? void 0 : true,
		...restProps,
		"data-base-ui-focus-guard": ""
	});
});
FocusGuard.displayName = "FocusGuard";
// node_modules/@base-ui/react/floating-ui-react/utils/composite.mjs
function isHiddenByStyles(styles) {
	return styles.visibility === "hidden" || styles.visibility === "collapse";
}
function isElementVisible(element, styles = element ? getComputedStyle$1(element) : null) {
	if (!element || !element.isConnected || !styles || isHiddenByStyles(styles)) return false;
	if (typeof element.checkVisibility === "function") return element.checkVisibility();
	return styles.display !== "none" && styles.display !== "contents";
}
// node_modules/@base-ui/react/floating-ui-react/utils/tabbable.mjs
var CANDIDATE_SELECTOR = "a[href],button,input,select,textarea,summary,details,iframe,object,embed,[tabindex],[contenteditable]:not([contenteditable=\"false\"]),audio[controls],video[controls]";
function getParentElement(element) {
	const assignedSlot = element.assignedSlot;
	if (assignedSlot) return assignedSlot;
	if (element.parentElement) return element.parentElement;
	const rootNode = element.getRootNode();
	return isShadowRoot(rootNode) ? rootNode.host : null;
}
function getDetailsSummary(details) {
	for (const child of Array.from(details.children)) if (getNodeName(child) === "summary") return child;
	return null;
}
function isWithinOpenDetailsSummary(element, details) {
	const summary = getDetailsSummary(details);
	return !!summary && (element === summary || contains(summary, element));
}
function isFocusableCandidate(element) {
	const nodeName = element ? getNodeName(element) : "";
	return element != null && element.matches(CANDIDATE_SELECTOR) && (nodeName !== "summary" || element.parentElement != null && getNodeName(element.parentElement) === "details" && getDetailsSummary(element.parentElement) === element) && (nodeName !== "details" || getDetailsSummary(element) == null) && (nodeName !== "input" || element.type !== "hidden");
}
function isFocusableElement(element) {
	if (!isFocusableCandidate(element) || !element.isConnected || element.matches(":disabled")) return false;
	for (let current = element; current; current = getParentElement(current)) {
		const isAncestor = current !== element;
		const isSlot = getNodeName(current) === "slot";
		if (current.hasAttribute("inert")) return false;
		if (isAncestor && getNodeName(current) === "details" && !current.open && !isWithinOpenDetailsSummary(element, current) || current.hasAttribute("hidden") || !isSlot && !isVisibleInTabbableTree(current, isAncestor)) return false;
	}
	return true;
}
function isVisibleInTabbableTree(element, isAncestor) {
	const styles = getComputedStyle$1(element);
	if (!isAncestor) return isElementVisible(element, styles);
	return styles.display !== "none";
}
function getTabIndex(element) {
	const tabIndex = element.tabIndex;
	if (tabIndex < 0) {
		const nodeName = getNodeName(element);
		if (nodeName === "details" || nodeName === "audio" || nodeName === "video" || isHTMLElement(element) && element.isContentEditable) return 0;
	}
	return tabIndex;
}
function getNamedRadioInput(element) {
	if (getNodeName(element) !== "input") return null;
	const input = element;
	return input.type === "radio" && input.name !== "" ? input : null;
}
function isTabbableRadio(element, candidates) {
	const input = getNamedRadioInput(element);
	if (!input) return true;
	const checkedRadio = candidates.find((candidate) => {
		const radio = getNamedRadioInput(candidate);
		return radio?.name === input.name && radio.form === input.form && radio.checked;
	});
	if (checkedRadio) return checkedRadio === input;
	return candidates.find((candidate) => {
		const radio = getNamedRadioInput(candidate);
		return radio?.name === input.name && radio.form === input.form;
	}) === input;
}
function getComposedChildren(container) {
	if (isHTMLElement(container) && getNodeName(container) === "slot") {
		const assignedElements = container.assignedElements({ flatten: true });
		if (assignedElements.length > 0) return assignedElements;
	}
	if (isHTMLElement(container) && container.shadowRoot) return Array.from(container.shadowRoot.children);
	return Array.from(container.children);
}
function appendCandidates(container, list) {
	getComposedChildren(container).forEach((child) => {
		if (isFocusableCandidate(child)) list.push(child);
		appendCandidates(child, list);
	});
}
function appendMatchingElements(container, selector, list) {
	getComposedChildren(container).forEach((child) => {
		if (isHTMLElement(child) && child.matches(selector)) list.push(child);
		appendMatchingElements(child, selector, list);
	});
}
function isTabbable(element) {
	return isFocusableElement(element) && getTabIndex(element) >= 0;
}
function focusable(container) {
	const candidates = [];
	appendCandidates(container, candidates);
	return candidates.filter(isFocusableElement);
}
function tabbable(container) {
	const candidates = focusable(container);
	return candidates.filter((element) => getTabIndex(element) >= 0 && isTabbableRadio(element, candidates));
}
function getTabbableIn(container, dir) {
	const list = tabbable(container);
	const len = list.length;
	if (len === 0) return;
	const active = activeElement(ownerDocument(container));
	const index = list.indexOf(active);
	return list[index === -1 ? dir === 1 ? 0 : len - 1 : index + dir];
}
function getNextTabbable(referenceElement) {
	return getTabbableIn(ownerDocument(referenceElement).body, 1) || referenceElement;
}
function getPreviousTabbable(referenceElement) {
	return getTabbableIn(ownerDocument(referenceElement).body, -1) || referenceElement;
}
function isOutsideEvent(event, container) {
	const containerElement = container || event.currentTarget;
	const relatedTarget = event.relatedTarget;
	return !relatedTarget || !contains(containerElement, relatedTarget);
}
function disableFocusInside(container) {
	tabbable(container).forEach((element) => {
		element.dataset.tabindex = element.getAttribute("tabindex") || "";
		element.setAttribute("tabindex", "-1");
	});
}
function enableFocusInside(container) {
	const elements = [];
	appendMatchingElements(container, "[data-tabindex]", elements);
	elements.forEach((element) => {
		const tabindex = element.dataset.tabindex;
		delete element.dataset.tabindex;
		if (tabindex) element.setAttribute("tabindex", tabindex);
		else element.removeAttribute("tabindex");
	});
}
// node_modules/@base-ui/react/floating-ui-react/utils/nodes.mjs
function getNodeChildren(nodes, id, onlyOpenChildren = true) {
	return nodes.filter((node) => node.parentId === id).flatMap((child) => [...!onlyOpenChildren || child.context?.open ? [child] : [], ...getNodeChildren(nodes, child.id, onlyOpenChildren)]);
}
function getNodeAncestors(nodes, id) {
	let allAncestors = [];
	let currentParentId = nodes.find((node) => node.id === id)?.parentId;
	while (currentParentId) {
		const currentNode = nodes.find((node) => node.id === currentParentId);
		currentParentId = currentNode?.parentId;
		if (currentNode) allAncestors = allAncestors.concat(currentNode);
	}
	return allAncestors;
}
// node_modules/@base-ui/react/floating-ui-react/utils/createAttribute.mjs
function createAttribute(name) {
	return `data-base-ui-${name}`;
}
// node_modules/@base-ui/react/floating-ui-react/utils/enqueueFocus.mjs
var rafId = 0;
function enqueueFocus(el, options = {}) {
	const { preventScroll = false, sync = false, shouldFocus } = options;
	cancelAnimationFrame(rafId);
	function exec() {
		if (shouldFocus && !shouldFocus()) return;
		el?.focus({ preventScroll });
	}
	if (sync) {
		exec();
		return NOOP;
	}
	const currentRafId = requestAnimationFrame(exec);
	rafId = currentRafId;
	return () => {
		if (rafId === currentRafId) {
			cancelAnimationFrame(currentRafId);
			rafId = 0;
		}
	};
}
// node_modules/@base-ui/react/floating-ui-react/utils/markOthers.mjs
var markerName = "data-base-ui-inert";
var ariaHiddenCounterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledElementsSet = /* @__PURE__ */ new WeakSet();
var markerCounterMap = /* @__PURE__ */ new WeakMap();
var lockCount = 0;
function unwrapHost(node) {
	if (!node) return null;
	return isShadowRoot(node) ? node.host : unwrapHost(node.parentNode);
}
var correctElements = (parent, targets) => targets.map((target) => {
	if (parent.contains(target)) return target;
	const correctedTarget = unwrapHost(target);
	if (parent.contains(correctedTarget)) return correctedTarget;
	return null;
}).filter((x) => x != null);
var buildKeepSet = (targets) => {
	const keep = /* @__PURE__ */ new Set();
	targets.forEach((target) => {
		let node = target;
		while (node && !keep.has(node)) {
			keep.add(node);
			node = node.parentNode;
		}
	});
	return keep;
};
var collectOutsideElements = (root, keepElements, stopElements) => {
	const outside = [];
	const walk = (parent) => {
		if (!parent || stopElements.has(parent)) return;
		Array.from(parent.children).forEach((node) => {
			if (getNodeName(node) === "script") return;
			if (keepElements.has(node)) walk(node);
			else outside.push(node);
		});
	};
	walk(root);
	return outside;
};
function applyAttributeToOthers(uncorrectedAvoidElements, body, ariaHidden, { mark = true }) {
	const avoidElements = correctElements(body, uncorrectedAvoidElements);
	const markerTargets = mark ? collectOutsideElements(body, buildKeepSet(avoidElements), new Set(avoidElements)) : [];
	const hiddenElements = [];
	const markedElements = [];
	if (ariaHidden) {
		const ariaLiveElements = correctElements(body, Array.from(body.querySelectorAll("[aria-live]")));
		const controlElements = avoidElements.concat(ariaLiveElements);
		collectOutsideElements(body, buildKeepSet(controlElements), new Set(controlElements)).forEach((node) => {
			const attr = node.getAttribute("aria-hidden");
			const alreadyHidden = attr !== null && attr !== "false";
			const counterValue = (ariaHiddenCounterMap.get(node) || 0) + 1;
			ariaHiddenCounterMap.set(node, counterValue);
			hiddenElements.push(node);
			if (counterValue === 1 && alreadyHidden) uncontrolledElementsSet.add(node);
			if (!alreadyHidden) node.setAttribute("aria-hidden", "true");
		});
	}
	if (mark) markerTargets.forEach((node) => {
		const markerValue = (markerCounterMap.get(node) || 0) + 1;
		markerCounterMap.set(node, markerValue);
		markedElements.push(node);
		if (markerValue === 1) node.setAttribute(markerName, "");
	});
	lockCount += 1;
	return () => {
		hiddenElements.forEach((element) => {
			const counterValue = (ariaHiddenCounterMap.get(element) || 0) - 1;
			ariaHiddenCounterMap.set(element, counterValue);
			if (!counterValue) {
				if (!uncontrolledElementsSet.has(element)) element.removeAttribute("aria-hidden");
				uncontrolledElementsSet.delete(element);
			}
		});
		if (mark) markedElements.forEach((element) => {
			const markerValue = (markerCounterMap.get(element) || 0) - 1;
			markerCounterMap.set(element, markerValue);
			if (!markerValue) element.removeAttribute(markerName);
		});
		lockCount -= 1;
		if (!lockCount) {
			ariaHiddenCounterMap = /* @__PURE__ */ new WeakMap();
			uncontrolledElementsSet = /* @__PURE__ */ new WeakSet();
			markerCounterMap = /* @__PURE__ */ new WeakMap();
		}
	};
}
function markOthers(avoidElements, options = {}) {
	const { ariaHidden = false, mark = true } = options;
	const body = ownerDocument(avoidElements[0]).body;
	return applyAttributeToOthers(avoidElements, body, ariaHidden, { mark });
}
// node_modules/@base-ui/react/internals/constants.mjs
var CLICK_TRIGGER_IDENTIFIER = "data-base-ui-click-trigger";
/**
* Special visually hidden styles for the aria-owns owner element to ensure owned element
* accessibility in iOS/Safari/VoiceControl.
* The owner element is an empty span, so most of the common visually hidden styles are not needed.
* @see https://github.com/floating-ui/floating-ui/issues/3403
*/
var ownerVisuallyHidden = {
	clipPath: "inset(50%)",
	position: "fixed",
	top: 0,
	left: 0
};
// node_modules/@base-ui/react/floating-ui-react/components/FloatingPortal.mjs
var PortalContext = /*#__PURE__*/ import_react.createContext(null);
PortalContext.displayName = "PortalContext";
var usePortalContext = () => import_react.useContext(PortalContext);
var attr = createAttribute("portal");
function useFloatingPortalNode(props = {}) {
	const { ref, container: containerProp, componentProps = EMPTY_OBJECT, elementProps } = props;
	const uniqueId = useId();
	const parentPortalNode = usePortalContext()?.portalNode;
	const [containerElement, setContainerElement] = import_react.useState(null);
	const [portalNode, setPortalNode] = import_react.useState(null);
	const setPortalNodeRef = useStableCallback((node) => {
		if (node !== null) setPortalNode(node);
	});
	const containerRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (containerProp === null) {
			if (containerRef.current) {
				containerRef.current = null;
				setPortalNode(null);
				setContainerElement(null);
			}
			return;
		}
		const resolvedContainer = (containerProp && (isNode(containerProp) ? containerProp : containerProp.current)) ?? parentPortalNode ?? document.body;
		if (resolvedContainer == null) {
			if (containerRef.current) {
				containerRef.current = null;
				setPortalNode(null);
				setContainerElement(null);
			}
			return;
		}
		if (containerRef.current !== resolvedContainer) {
			containerRef.current = resolvedContainer;
			setPortalNode(null);
			setContainerElement(resolvedContainer);
		}
	}, [containerProp, parentPortalNode]);
	const portalElement = useRenderElement("div", componentProps, {
		ref: [ref, setPortalNodeRef],
		props: [{
			id: uniqueId,
			[attr]: ""
		}, elementProps]
	});
	const portalSubtree = containerElement && portalElement ? /*#__PURE__*/ import_react_dom.createPortal(portalElement, containerElement) : null;
	return {
		node: portalNode,
		nodeId: /*#__PURE__*/ import_react.isValidElement(portalElement) ? portalElement.props.id : void 0,
		subtree: portalSubtree
	};
}
/**
* Portals the floating element into a given container element — by default,
* outside of the app root and into the body.
* This is necessary to ensure the floating element can appear outside any
* potential parent containers that cause clipping (such as `overflow: hidden`),
* while retaining its location in the React tree.
* @see https://floating-ui.com/docs/FloatingPortal
* @internal
*/
var FloatingPortal = /*#__PURE__*/ import_react.forwardRef(function FloatingPortal(componentProps, forwardedRef) {
	const { render, className, style, children, container, portalOwnerRole, ...elementProps } = componentProps;
	const { node: portalNode, nodeId: portalNodeId, subtree: portalSubtree } = useFloatingPortalNode({
		container,
		ref: forwardedRef,
		componentProps,
		elementProps
	});
	const beforeOutsideRef = import_react.useRef(null);
	const afterOutsideRef = import_react.useRef(null);
	const beforeInsideRef = import_react.useRef(null);
	const afterInsideRef = import_react.useRef(null);
	const [focusManagerState, setFocusManagerState] = import_react.useState(null);
	const focusInsideDisabledRef = import_react.useRef(false);
	const modal = focusManagerState?.modal;
	const open = focusManagerState?.open;
	const shouldRenderGuards = !!focusManagerState && !focusManagerState.modal && focusManagerState.open && !!portalNode;
	import_react.useEffect(() => {
		if (!portalNode || modal) return;
		function onFocus(event) {
			if (portalNode && event.relatedTarget && isOutsideEvent(event)) {
				if (event.type === "focusin") {
					if (focusInsideDisabledRef.current) {
						enableFocusInside(portalNode);
						focusInsideDisabledRef.current = false;
					}
				} else {
					disableFocusInside(portalNode);
					focusInsideDisabledRef.current = true;
				}
			}
		}
		return mergeCleanups(addEventListener(portalNode, "focusin", onFocus, true), addEventListener(portalNode, "focusout", onFocus, true));
	}, [portalNode, modal]);
	useIsoLayoutEffect(() => {
		if (!portalNode || open !== true || !focusInsideDisabledRef.current) return;
		enableFocusInside(portalNode);
		focusInsideDisabledRef.current = false;
	}, [open, portalNode]);
	const portalContextValue = import_react.useMemo(() => ({
		beforeOutsideRef,
		afterOutsideRef,
		beforeInsideRef,
		afterInsideRef,
		portalNode,
		setFocusManagerState
	}), [portalNode]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [portalSubtree, /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(PortalContext.Provider, {
		value: portalContextValue,
		children: [
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
				"data-type": "outside",
				ref: beforeOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) beforeInsideRef.current?.focus();
					else getPreviousTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
				}
			}),
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
				role: portalOwnerRole,
				"aria-owns": portalNodeId,
				style: ownerVisuallyHidden
			}),
			portalNode && /*#__PURE__*/ import_react_dom.createPortal(children, portalNode),
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
				"data-type": "outside",
				ref: afterOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) afterInsideRef.current?.focus();
					else {
						getNextTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
						if (focusManagerState?.closeOnFocusOut) focusManagerState?.onOpenChange(false, createChangeEventDetails("focus-out", event.nativeEvent));
					}
				}
			})
		]
	})] });
});
FloatingPortal.displayName = "FloatingPortal";
// node_modules/@base-ui/react/floating-ui-react/utils/createEventEmitter.mjs
function createEventEmitter() {
	const map = /* @__PURE__ */ new Map();
	return {
		emit(event, data) {
			map.get(event)?.forEach((listener) => listener(data));
		},
		on(event, listener) {
			if (!map.has(event)) map.set(event, /* @__PURE__ */ new Set());
			map.get(event).add(listener);
		},
		off(event, listener) {
			map.get(event)?.delete(listener);
		}
	};
}
// node_modules/@base-ui/react/floating-ui-react/components/FloatingTree.mjs
var FloatingNodeContext = /*#__PURE__*/ import_react.createContext(null);
FloatingNodeContext.displayName = "FloatingNodeContext";
var FloatingTreeContext = /*#__PURE__*/ import_react.createContext(null);
FloatingTreeContext.displayName = "FloatingTreeContext";
var useFloatingParentNodeId = () => import_react.useContext(FloatingNodeContext)?.id || null;
/**
* Returns the nearest floating tree context, if available.
*/
var useFloatingTree = (externalTree) => {
	const contextTree = import_react.useContext(FloatingTreeContext);
	return externalTree ?? contextTree;
};
// node_modules/@base-ui/react/utils/resolveRef.mjs
/**
* If the provided argument is a ref object, returns its `current` value.
* Otherwise, returns the argument itself.
*/
function resolveRef(maybeRef) {
	if (maybeRef == null) return maybeRef;
	return "current" in maybeRef ? maybeRef.current : maybeRef;
}
// node_modules/@base-ui/react/floating-ui-react/components/FloatingFocusManager.mjs
function getEventType(event, lastInteractionType) {
	const win = getWindow(getTarget(event));
	if (event instanceof win.KeyboardEvent) return "keyboard";
	if (event instanceof win.FocusEvent) return lastInteractionType || "keyboard";
	if ("pointerType" in event) return event.pointerType || (isVirtualClick(event) ? "keyboard" : lastInteractionType || "mouse");
	if ("touches" in event) return "touch";
	if (event instanceof win.MouseEvent) return lastInteractionType || (event.detail === 0 ? "keyboard" : "mouse");
	return "";
}
var LIST_LIMIT = 20;
var previouslyFocusedElements = [];
function clearDisconnectedPreviouslyFocusedElements() {
	previouslyFocusedElements = previouslyFocusedElements.filter((entry) => {
		return entry.deref()?.isConnected;
	});
}
function addPreviouslyFocusedElement(element) {
	clearDisconnectedPreviouslyFocusedElements();
	if (element && getNodeName(element) !== "body") {
		previouslyFocusedElements.push(new WeakRef(element));
		if (previouslyFocusedElements.length > LIST_LIMIT) previouslyFocusedElements = previouslyFocusedElements.slice(-20);
	}
}
function getPreviouslyFocusedElement() {
	clearDisconnectedPreviouslyFocusedElements();
	return previouslyFocusedElements[previouslyFocusedElements.length - 1]?.deref();
}
function getFirstTabbableElement(container) {
	if (!container) return null;
	if (isTabbable(container)) return container;
	return tabbable(container)[0] || container;
}
function handleTabIndex(floatingFocusElement) {
	if (floatingFocusElement.hasAttribute("tabindex") && !floatingFocusElement.hasAttribute("data-tabindex")) return;
	if (!floatingFocusElement.getAttribute("role")?.includes("dialog")) return;
	const tabbableContent = focusable(floatingFocusElement).filter((element) => {
		const dataTabIndex = element.getAttribute("data-tabindex") || "";
		return isTabbable(element) || element.hasAttribute("data-tabindex") && !dataTabIndex.startsWith("-");
	});
	const tabIndex = floatingFocusElement.getAttribute("tabindex");
	if (tabbableContent.length === 0) {
		if (tabIndex !== "0") {
			floatingFocusElement.setAttribute("tabindex", "0");
			floatingFocusElement.setAttribute("data-tabindex", "0");
		}
	} else if (tabIndex !== "-1" || floatingFocusElement.hasAttribute("data-tabindex") && floatingFocusElement.getAttribute("data-tabindex") !== "-1") {
		floatingFocusElement.setAttribute("tabindex", "-1");
		floatingFocusElement.setAttribute("data-tabindex", "-1");
	}
}
/**
* Provides focus management for the floating element.
* @see https://floating-ui.com/docs/FloatingFocusManager
* @internal
*/
function FloatingFocusManager(props) {
	const { context: store, children, disabled = false, initialFocus = true, returnFocus = true, explicitReturnFocus, restoreFocus = false, modal = true, closeOnFocusOut = true, openInteractionType = "", nextFocusableElement, previousFocusableElement, beforeContentFocusGuardRef, externalTree, getInsideElements } = props;
	const open = store.useState("open");
	const domReference = store.useState("domReferenceElement");
	const floating = store.useState("floatingElement");
	const { events, dataRef } = store.context;
	const getNodeId = useStableCallback(() => dataRef.current.floatingContext?.nodeId);
	const ignoreInitialFocus = initialFocus === false;
	const isUntrappedTypeableCombobox = isTypeableCombobox(domReference) && ignoreInitialFocus;
	const initialFocusRef = useValueAsRef(initialFocus);
	const returnFocusRef = useValueAsRef(returnFocus);
	const explicitReturnFocusRef = useValueAsRef(explicitReturnFocus);
	const openInteractionTypeRef = useValueAsRef(openInteractionType);
	const openRef = useValueAsRef(open);
	const tree = useFloatingTree(externalTree);
	const portalContext = usePortalContext();
	const preventReturnFocusRef = import_react.useRef(false);
	const isPointerDownRef = import_react.useRef(false);
	const pointerDownOutsideRef = import_react.useRef(false);
	const lastFocusedTabbableRef = import_react.useRef(null);
	const closeTypeRef = import_react.useRef("");
	const lastInteractionTypeRef = import_react.useRef("");
	const beforeGuardRef = import_react.useRef(null);
	const afterGuardRef = import_react.useRef(null);
	const mergedBeforeGuardRef = useMergedRefs(beforeGuardRef, beforeContentFocusGuardRef, portalContext?.beforeInsideRef);
	const mergedAfterGuardRef = useMergedRefs(afterGuardRef, portalContext?.afterInsideRef);
	const blurTimeout = useTimeout();
	const pointerDownTimeout = useTimeout();
	const restoreFocusFrame = useAnimationFrame();
	const isInsidePortal = portalContext != null;
	const floatingFocusElement = getFloatingFocusElement(floating);
	const getTabbableContent = useStableCallback((container = floatingFocusElement) => {
		return container ? tabbable(container) : [];
	});
	const getResolvedInsideElements = useStableCallback(() => getInsideElements?.().filter((element) => element != null) ?? []);
	import_react.useEffect(() => {
		if (disabled || !modal) return;
		function onKeyDown(event) {
			if (event.key === "Tab") {
				if (contains(floatingFocusElement, activeElement(ownerDocument(floatingFocusElement))) && getTabbableContent().length === 0 && !isUntrappedTypeableCombobox) stopEvent(event);
			}
		}
		return addEventListener(ownerDocument(floatingFocusElement), "keydown", onKeyDown);
	}, [
		disabled,
		floatingFocusElement,
		modal,
		isUntrappedTypeableCombobox,
		getTabbableContent
	]);
	import_react.useEffect(() => {
		if (disabled || !open) return;
		const doc = ownerDocument(floatingFocusElement);
		function clearPointerDownOutside() {
			pointerDownOutsideRef.current = false;
		}
		function onPointerDown(event) {
			const target = getTarget(event);
			const insideElements = getResolvedInsideElements();
			const pointerTargetInside = contains(floating, target) || contains(domReference, target) || contains(portalContext?.portalNode, target) || insideElements.some((element) => element === target || contains(element, target));
			pointerDownOutsideRef.current = !pointerTargetInside;
			lastInteractionTypeRef.current = event.pointerType || "keyboard";
			if (closest(target, `[data-base-ui-click-trigger]`)) {
				isPointerDownRef.current = true;
				pointerDownTimeout.start(0, () => {
					isPointerDownRef.current = false;
				});
			}
		}
		function onKeyDown() {
			lastInteractionTypeRef.current = "keyboard";
		}
		return mergeCleanups(addEventListener(doc, "pointerdown", onPointerDown, true), addEventListener(doc, "pointerup", clearPointerDownOutside, true), addEventListener(doc, "pointercancel", clearPointerDownOutside, true), addEventListener(doc, "keydown", onKeyDown, true), clearPointerDownOutside);
	}, [
		disabled,
		floating,
		domReference,
		floatingFocusElement,
		open,
		portalContext,
		pointerDownTimeout,
		getResolvedInsideElements
	]);
	import_react.useEffect(() => {
		if (disabled || !closeOnFocusOut) return;
		const doc = ownerDocument(floatingFocusElement);
		function handlePointerDown() {
			isPointerDownRef.current = true;
			pointerDownTimeout.start(0, () => {
				isPointerDownRef.current = false;
			});
		}
		function handleFocusIn(event) {
			const target = getTarget(event);
			if (isTabbable(target)) lastFocusedTabbableRef.current = target;
		}
		function handleFocusOutside(event) {
			const relatedTarget = event.relatedTarget;
			const currentTarget = event.currentTarget;
			const target = getTarget(event);
			if (modal && relatedTarget == null && target != null && contains(floating, target)) addPreviouslyFocusedElement(target);
			queueMicrotask(() => {
				const nodeId = getNodeId();
				const triggers = store.context.triggerElements;
				const insideElements = getResolvedInsideElements();
				const isRelatedFocusGuard = relatedTarget?.hasAttribute(createAttribute("focus-guard")) && [
					beforeGuardRef.current,
					afterGuardRef.current,
					portalContext?.beforeInsideRef.current,
					portalContext?.afterInsideRef.current,
					portalContext?.beforeOutsideRef.current,
					portalContext?.afterOutsideRef.current,
					resolveRef(previousFocusableElement),
					resolveRef(nextFocusableElement)
				].includes(relatedTarget);
				const movedToUnrelatedNode = !(contains(domReference, relatedTarget) || contains(floating, relatedTarget) || contains(relatedTarget, floating) || contains(portalContext?.portalNode, relatedTarget) || insideElements.some((element) => element === relatedTarget || contains(element, relatedTarget)) || triggers.hasMatchingElement((trigger) => contains(trigger, relatedTarget)) || isRelatedFocusGuard || tree && (getNodeChildren(tree.nodesRef.current, nodeId).find((node) => contains(node.context?.elements.floating, relatedTarget) || contains(node.context?.elements.domReference, relatedTarget)) || getNodeAncestors(tree.nodesRef.current, nodeId).find((node) => [node.context?.elements.floating, getFloatingFocusElement(node.context?.elements.floating)].includes(relatedTarget) || node.context?.elements.domReference === relatedTarget)));
				if (currentTarget === domReference && floatingFocusElement) handleTabIndex(floatingFocusElement);
				if (restoreFocus && currentTarget !== domReference && !isElementVisible(target) && activeElement(doc) === doc.body) {
					if (isHTMLElement(floatingFocusElement)) {
						floatingFocusElement.focus();
						if (restoreFocus === "popup") {
							restoreFocusFrame.request(() => {
								floatingFocusElement.focus();
							});
							return;
						}
					}
					const tabbableContent = getTabbableContent();
					const prevTabbable = lastFocusedTabbableRef.current;
					const nodeToFocus = (prevTabbable && tabbableContent.includes(prevTabbable) ? prevTabbable : null) || tabbableContent[tabbableContent.length - 1] || floatingFocusElement;
					if (isHTMLElement(nodeToFocus)) nodeToFocus.focus();
				}
				if (dataRef.current.insideReactTree) {
					dataRef.current.insideReactTree = false;
					return;
				}
				if ((isUntrappedTypeableCombobox ? true : !modal) && relatedTarget && movedToUnrelatedNode && !isPointerDownRef.current && (isUntrappedTypeableCombobox || relatedTarget !== getPreviouslyFocusedElement())) {
					preventReturnFocusRef.current = true;
					store.setOpen(false, createChangeEventDetails(focusOut, event));
				}
			});
		}
		function markInsideReactTree() {
			if (pointerDownOutsideRef.current) return;
			dataRef.current.insideReactTree = true;
			blurTimeout.start(0, () => {
				dataRef.current.insideReactTree = false;
			});
		}
		const domReferenceElement = isHTMLElement(domReference) ? domReference : null;
		if (!floating && !domReferenceElement) return;
		return mergeCleanups(domReferenceElement && addEventListener(domReferenceElement, "focusout", handleFocusOutside), domReferenceElement && addEventListener(domReferenceElement, "pointerdown", handlePointerDown), floating && addEventListener(floating, "focusin", handleFocusIn), floating && addEventListener(floating, "focusout", handleFocusOutside), floating && portalContext && addEventListener(floating, "focusout", markInsideReactTree, true));
	}, [
		disabled,
		domReference,
		floating,
		floatingFocusElement,
		modal,
		tree,
		portalContext,
		store,
		closeOnFocusOut,
		restoreFocus,
		getTabbableContent,
		isUntrappedTypeableCombobox,
		getNodeId,
		dataRef,
		blurTimeout,
		pointerDownTimeout,
		restoreFocusFrame,
		nextFocusableElement,
		previousFocusableElement,
		getResolvedInsideElements
	]);
	import_react.useEffect(() => {
		if (disabled || !floating || !open) return;
		const portalNodes = Array.from(portalContext?.portalNode?.querySelectorAll(`[${createAttribute("portal")}]`) || []);
		const rootAncestorComboboxDomReference = (tree ? getNodeAncestors(tree.nodesRef.current, getNodeId()) : []).find((node) => isTypeableCombobox(node.context?.elements.domReference || null))?.context?.elements.domReference;
		const ariaHiddenCleanup = markOthers([
			...[
				floating,
				...portalNodes,
				beforeGuardRef.current,
				afterGuardRef.current,
				portalContext?.beforeOutsideRef.current,
				portalContext?.afterOutsideRef.current,
				...getResolvedInsideElements()
			],
			rootAncestorComboboxDomReference,
			resolveRef(previousFocusableElement),
			resolveRef(nextFocusableElement),
			isUntrappedTypeableCombobox ? domReference : null
		].filter((x) => x != null), {
			ariaHidden: modal || isUntrappedTypeableCombobox,
			mark: false
		});
		const markerCleanup = markOthers([floating, ...portalNodes].filter((x) => x != null));
		return () => {
			markerCleanup();
			ariaHiddenCleanup();
		};
	}, [
		open,
		disabled,
		domReference,
		floating,
		modal,
		portalContext,
		isUntrappedTypeableCombobox,
		tree,
		getNodeId,
		nextFocusableElement,
		previousFocusableElement,
		getResolvedInsideElements
	]);
	useIsoLayoutEffect(() => {
		if (!open || disabled || !isHTMLElement(floatingFocusElement)) return;
		closeTypeRef.current = "";
		lastInteractionTypeRef.current = "";
		const doc = ownerDocument(floatingFocusElement);
		const previouslyFocusedElement = activeElement(doc);
		queueMicrotask(() => {
			const initialFocusValueOrFn = initialFocusRef.current;
			const resolvedInitialFocus = typeof initialFocusValueOrFn === "function" ? initialFocusValueOrFn(openInteractionTypeRef.current || "") : initialFocusValueOrFn;
			if (resolvedInitialFocus === void 0 || resolvedInitialFocus === false) return;
			if (contains(floatingFocusElement, previouslyFocusedElement)) return;
			let focusableElements = null;
			const getDefaultFocusElement = () => {
				if (focusableElements == null) focusableElements = getTabbableContent(floatingFocusElement);
				return focusableElements[0] || floatingFocusElement;
			};
			let elToFocus;
			if (resolvedInitialFocus === true || resolvedInitialFocus === null) elToFocus = getDefaultFocusElement();
			else elToFocus = resolveRef(resolvedInitialFocus);
			elToFocus = elToFocus || getDefaultFocusElement();
			const hadFocusInside = contains(floatingFocusElement, activeElement(doc));
			const openEvent = dataRef.current.openEvent;
			const openedByVirtualPress = openEvent?.type === "mousedown" && isVirtualClick(openEvent);
			enqueueFocus(elToFocus, {
				sync: openedByVirtualPress,
				preventScroll: elToFocus === floatingFocusElement,
				shouldFocus() {
					if (!openRef.current) return false;
					if (hadFocusInside) return true;
					const currentActiveElement = activeElement(doc);
					return !(currentActiveElement !== elToFocus && contains(floatingFocusElement, currentActiveElement));
				}
			});
		});
	}, [
		disabled,
		open,
		floatingFocusElement,
		getTabbableContent,
		initialFocusRef,
		openInteractionTypeRef,
		openRef,
		dataRef
	]);
	const pendingReturnFocusRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (disabled || !floatingFocusElement) {
			pendingReturnFocusRef.current = null;
			return;
		}
		if (pendingReturnFocusRef.current) {
			pendingReturnFocusRef.current.cancelled = true;
			pendingReturnFocusRef.current = null;
		}
		const doc = ownerDocument(floatingFocusElement);
		const elementFocusedBeforeOpen = activeElement(doc);
		const preferPreviousFocus = openInteractionTypeRef.current == null;
		addPreviouslyFocusedElement(elementFocusedBeforeOpen);
		function onOpenChangeLocal(details) {
			if (!details.open) closeTypeRef.current = getEventType(details.nativeEvent, lastInteractionTypeRef.current);
			if (details.reason === "focus-out" && details.triggerElement?.hasAttribute(createAttribute("focus-guard")) || details.reason === "trigger-hover" && details.nativeEvent.type === "mouseleave") preventReturnFocusRef.current = true;
			if (details.reason !== "outside-press") return;
			if (details.nested) preventReturnFocusRef.current = false;
			else if (isVirtualClick(details.nativeEvent) || isVirtualPointerEvent(details.nativeEvent)) preventReturnFocusRef.current = false;
			else {
				let isPreventScrollSupported = false;
				ownerDocument(floatingFocusElement).createElement("div").focus({ get preventScroll() {
					isPreventScrollSupported = true;
					return false;
				} });
				if (isPreventScrollSupported) preventReturnFocusRef.current = false;
				else preventReturnFocusRef.current = true;
			}
		}
		events.on("openchange", onOpenChangeLocal);
		function getReturnElement(closeType) {
			const returnFocusValueOrFn = returnFocusRef.current;
			let resolvedReturnFocusValue = typeof returnFocusValueOrFn === "function" ? returnFocusValueOrFn(closeType) : returnFocusValueOrFn;
			if (resolvedReturnFocusValue === void 0 || resolvedReturnFocusValue === false) return null;
			if (resolvedReturnFocusValue === null) resolvedReturnFocusValue = true;
			const referenceReturnElement = domReference?.isConnected ? domReference : null;
			const previousReturnElement = elementFocusedBeforeOpen?.isConnected && getNodeName(elementFocusedBeforeOpen) !== "body" ? elementFocusedBeforeOpen : null;
			let defaultReturnElement = preferPreviousFocus ? previousReturnElement || referenceReturnElement : referenceReturnElement || previousReturnElement;
			if (!defaultReturnElement) defaultReturnElement = getPreviouslyFocusedElement() || null;
			if (typeof resolvedReturnFocusValue === "boolean") return defaultReturnElement;
			return resolveRef(resolvedReturnFocusValue) || defaultReturnElement || null;
		}
		return () => {
			events.off("openchange", onOpenChangeLocal);
			const activeEl = activeElement(doc);
			const insideElements = getResolvedInsideElements();
			const isFocusInsideFloatingTree = contains(floating, activeEl) || insideElements.some((element) => element === activeEl || contains(element, activeEl)) || tree && getNodeChildren(tree.nodesRef.current, getNodeId(), false).some((node) => contains(node.context?.elements.floating, activeEl));
			const returnFocusValueOrFn = returnFocusRef.current;
			const closeType = closeTypeRef.current;
			const returnElement = getReturnElement(closeType);
			const job = { cancelled: false };
			pendingReturnFocusRef.current = job;
			queueMicrotask(() => {
				if (pendingReturnFocusRef.current === job) pendingReturnFocusRef.current = null;
				const tabbableReturnElement = getFirstTabbableElement(returnElement);
				const hasExplicitReturnFocus = explicitReturnFocusRef.current ?? typeof returnFocusValueOrFn !== "boolean";
				if (!job.cancelled && returnFocusValueOrFn && !preventReturnFocusRef.current && isHTMLElement(tabbableReturnElement) && (!hasExplicitReturnFocus && tabbableReturnElement !== activeEl && activeEl !== doc.body ? isFocusInsideFloatingTree : true)) {
					const focusOptions = { preventScroll: true };
					if (closeType === "keyboard") focusOptions.focusVisible = true;
					tabbableReturnElement.focus(focusOptions);
				}
				preventReturnFocusRef.current = false;
			});
		};
	}, [
		disabled,
		floating,
		floatingFocusElement,
		returnFocusRef,
		explicitReturnFocusRef,
		openInteractionTypeRef,
		events,
		tree,
		domReference,
		getNodeId,
		getResolvedInsideElements
	]);
	useIsoLayoutEffect(() => {
		if (!webkit || open || !floating) return;
		const activeEl = activeElement(ownerDocument(floating));
		if (!isHTMLElement(activeEl) || !isTypeableElement(activeEl)) return;
		if (contains(floating, activeEl)) activeEl.blur();
	}, [open, floating]);
	useIsoLayoutEffect(() => {
		if (disabled || !portalContext) return;
		portalContext.setFocusManagerState({
			modal,
			closeOnFocusOut,
			open,
			onOpenChange: store.setOpen,
			domReference
		});
		return () => {
			portalContext.setFocusManagerState(null);
		};
	}, [
		disabled,
		portalContext,
		modal,
		open,
		store,
		closeOnFocusOut,
		domReference
	]);
	useIsoLayoutEffect(() => {
		if (disabled || !floatingFocusElement) return;
		handleTabIndex(floatingFocusElement);
		return () => {
			queueMicrotask(clearDisconnectedPreviouslyFocusedElements);
		};
	}, [disabled, floatingFocusElement]);
	const shouldRenderGuards = !disabled && (modal ? !isUntrappedTypeableCombobox : true) && (isInsidePortal || modal);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		shouldRenderGuards && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			"data-type": "inside",
			ref: mergedBeforeGuardRef,
			onFocus: (event) => {
				if (modal) {
					const els = getTabbableContent();
					enqueueFocus(els[els.length - 1]);
				} else if (portalContext?.portalNode) {
					preventReturnFocusRef.current = false;
					if (isOutsideEvent(event, portalContext.portalNode)) getNextTabbable(domReference)?.focus();
					else resolveRef(previousFocusableElement ?? portalContext.beforeOutsideRef)?.focus();
				}
			}
		}),
		children,
		shouldRenderGuards && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			"data-type": "inside",
			ref: mergedAfterGuardRef,
			onFocus: (event) => {
				if (modal) enqueueFocus(getTabbableContent()[0]);
				else if (portalContext?.portalNode) {
					if (closeOnFocusOut) preventReturnFocusRef.current = true;
					if (isOutsideEvent(event, portalContext.portalNode)) getPreviousTabbable(domReference)?.focus();
					else resolveRef(nextFocusableElement ?? portalContext.afterOutsideRef)?.focus();
				}
			}
		})
	] });
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useClick.mjs
/**
* Opens or closes the floating element when clicking the reference element.
* @see https://floating-ui.com/docs/useClick
*/
function useClick(store, props = {}) {
	const { enabled = true, event: eventOption = "click", toggle = true, ignoreMouse = false, stickIfOpen = true, touchOpenDelay = 0, reason = triggerPress } = props;
	const dataRef = store.context.dataRef;
	const pointerTypeRef = import_react.useRef(void 0);
	const frame = useAnimationFrame();
	const touchOpenTimeout = useTimeout();
	const reference = import_react.useMemo(() => {
		function setOpenWithTouchDelay(nextOpen, nativeEvent, target, pointerType) {
			const details = createChangeEventDetails(reason, nativeEvent, target);
			if (nextOpen && pointerType === "touch" && touchOpenDelay > 0) touchOpenTimeout.start(touchOpenDelay, () => {
				store.setOpen(true, details);
			});
			else store.setOpen(nextOpen, details);
		}
		function getNextOpen(open, currentTarget, isClickLikeOpenEvent) {
			const openEvent = dataRef.current.openEvent;
			const hasClickedOnInactiveTrigger = store.select("domReferenceElement") !== currentTarget;
			if (open && hasClickedOnInactiveTrigger) return true;
			if (!open) return true;
			if (!toggle) return true;
			if (openEvent && (typeof stickIfOpen === "function" ? stickIfOpen() : stickIfOpen)) return !isClickLikeOpenEvent(openEvent.type);
			return false;
		}
		return {
			onPointerDown(event) {
				pointerTypeRef.current = isMouseLikePointerType(event.pointerType, true) && isVirtualPointerEvent(event.nativeEvent) ? "virtual" : event.pointerType;
			},
			onMouseDown(event) {
				const pointerType = pointerTypeRef.current;
				const nativeEvent = event.nativeEvent;
				const open = store.select("open");
				if (event.button !== 0 || eventOption === "click" || isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
				const nextOpen = getNextOpen(open, event.currentTarget, (openEventType) => openEventType === "click" || openEventType === "mousedown");
				const target = getTarget(nativeEvent);
				const isTypeable = isTypeableElement(target);
				if (isTypeable || pointerType === "virtual") {
					setOpenWithTouchDelay(nextOpen, nativeEvent, isTypeable ? target : event.currentTarget, pointerType);
					return;
				}
				const eventCurrentTarget = event.currentTarget;
				frame.request(() => {
					setOpenWithTouchDelay(nextOpen, nativeEvent, eventCurrentTarget, pointerType);
				});
			},
			onClick(event) {
				if (eventOption === "mousedown-only") return;
				const pointerType = pointerTypeRef.current;
				if (eventOption === "mousedown" && pointerType) {
					pointerTypeRef.current = void 0;
					return;
				}
				if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
				setOpenWithTouchDelay(getNextOpen(store.select("open"), event.currentTarget, (openEventType) => openEventType === "click" || openEventType === "mousedown" || openEventType === "keydown" || openEventType === "keyup"), event.nativeEvent, event.currentTarget, pointerType);
			},
			onKeyDown() {
				pointerTypeRef.current = void 0;
			}
		};
	}, [
		dataRef,
		eventOption,
		ignoreMouse,
		reason,
		store,
		stickIfOpen,
		toggle,
		frame,
		touchOpenTimeout,
		touchOpenDelay
	]);
	return import_react.useMemo(() => enabled ? { reference } : EMPTY_OBJECT, [enabled, reference]);
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useDismiss.mjs
function alwaysFalse() {
	return false;
}
function normalizeProp(normalizable) {
	return {
		escapeKey: typeof normalizable === "boolean" ? normalizable : normalizable?.escapeKey ?? false,
		outsidePress: typeof normalizable === "boolean" ? normalizable : normalizable?.outsidePress ?? true
	};
}
/**
* Closes the floating element when a dismissal is requested — by default, when
* the user presses the `escape` key or outside of the floating element.
* @see https://floating-ui.com/docs/useDismiss
*/
function useDismiss(store, props = {}) {
	const { enabled = true, escapeKey: escapeKey$1 = true, outsidePress: outsidePressProp = true, outsidePressEvent = "sloppy", referencePress = alwaysFalse, bubbles, externalTree } = props;
	const open = store.useState("open");
	const floatingElement = store.useState("floatingElement");
	const { dataRef, events } = store.context;
	const tree = useFloatingTree(externalTree);
	const outsidePressFn = useStableCallback(typeof outsidePressProp === "function" ? outsidePressProp : () => false);
	const outsidePress$1 = typeof outsidePressProp === "function" ? outsidePressFn : outsidePressProp;
	const outsidePressEnabled = outsidePress$1 !== false;
	const getOutsidePressEventProp = useStableCallback(() => outsidePressEvent);
	const { escapeKey: escapeKeyBubbles, outsidePress: outsidePressBubbles } = normalizeProp(bubbles);
	const pressStartedInsideRef = import_react.useRef(false);
	const pressStartPreventedRef = import_react.useRef(false);
	const suppressNextOutsideClickRef = import_react.useRef(false);
	const sawPressWhileOpenRef = import_react.useRef(false);
	const isComposingRef = import_react.useRef(false);
	const currentPointerTypeRef = import_react.useRef("");
	const touchStateRef = import_react.useRef(null);
	const cancelDismissOnEndTimeout = useTimeout();
	const clearInsideReactTreeTimeout = useTimeout();
	const compositionTimeout = useTimeout();
	const clearInsideReactTree = useStableCallback(() => {
		clearInsideReactTreeTimeout.clear();
		dataRef.current.insideReactTree = false;
	});
	const hasBlockingChild = useStableCallback((bubbleKey) => {
		const nodeId = dataRef.current.floatingContext?.nodeId;
		return (tree ? getNodeChildren(tree.nodesRef.current, nodeId) : []).some((child) => child.context?.open && !child.context.dataRef.current[bubbleKey]);
	});
	const isEventWithinOwnElements = useStableCallback((event) => {
		return isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement"));
	});
	const closeOnReferencePress = useStableCallback((event) => {
		if (!referencePress()) return;
		store.setOpen(false, createChangeEventDetails(triggerPress, event.nativeEvent));
	});
	const closeOnEscapeKeyDown = useStableCallback((event) => {
		if (!open || !enabled || !escapeKey$1 || event.key !== "Escape") return;
		const native = isReactEvent(event) ? event.nativeEvent : event;
		if (isComposingRef.current || native.isComposing) return;
		if (!escapeKeyBubbles && hasBlockingChild("__escapeKeyBubbles")) return;
		const eventDetails = createChangeEventDetails(escapeKey, native);
		store.setOpen(false, eventDetails);
		if (!eventDetails.isCanceled) event.preventDefault();
		if (!escapeKeyBubbles && !eventDetails.isPropagationAllowed) event.stopPropagation();
	});
	const markInsideReactTree = useStableCallback(() => {
		dataRef.current.insideReactTree = true;
		clearInsideReactTreeTimeout.start(0, clearInsideReactTree);
	});
	const markPressStartedInsideReactTree = useStableCallback((event) => {
		if (!open || !enabled || event.button !== 0) return;
		const target = getTarget(event.nativeEvent);
		if (!contains(store.select("floatingElement"), target)) return;
		if (!pressStartedInsideRef.current) {
			pressStartedInsideRef.current = true;
			pressStartPreventedRef.current = false;
		}
	});
	const markInsidePressStartPrevented = useStableCallback((event) => {
		if (!open || !enabled) return;
		if (!(event.defaultPrevented || event.nativeEvent.defaultPrevented)) return;
		if (pressStartedInsideRef.current) pressStartPreventedRef.current = true;
	});
	import_react.useEffect(() => {
		function handleOpenChange(details) {
			if (!details.open) sawPressWhileOpenRef.current = false;
		}
		events.on("openchange", handleOpenChange);
		return () => {
			events.off("openchange", handleOpenChange);
		};
	}, [events]);
	import_react.useEffect(() => clearInsideReactTree, [clearInsideReactTree]);
	import_react.useEffect(() => {
		if (!open || !enabled) {
			if (!open) {
				sawPressWhileOpenRef.current = false;
				isComposingRef.current = false;
				currentPointerTypeRef.current = "";
				touchStateRef.current = null;
			}
			return clearInsideReactTree;
		}
		dataRef.current.__escapeKeyBubbles = escapeKeyBubbles;
		dataRef.current.__outsidePressBubbles = outsidePressBubbles;
		const preventedPressSuppressionTimeout = new Timeout();
		const doc = ownerDocument(floatingElement);
		function handleCompositionStart() {
			compositionTimeout.clear();
			isComposingRef.current = true;
		}
		function handleCompositionEnd() {
			isComposingRef.current = true;
			compositionTimeout.start(webkit ? 5 : 0, () => {
				isComposingRef.current = false;
			});
		}
		function suppressImmediateOutsideClickAfterPreventedStart() {
			suppressNextOutsideClickRef.current = true;
			preventedPressSuppressionTimeout.start(0, () => {
				suppressNextOutsideClickRef.current = false;
			});
		}
		function resetPressStartState() {
			pressStartedInsideRef.current = false;
			pressStartPreventedRef.current = false;
		}
		function getOutsidePressEvent() {
			const type = currentPointerTypeRef.current;
			const computedType = type === "pen" || !type ? "mouse" : type;
			const outsidePressEventValue = getOutsidePressEventProp();
			const resolved = typeof outsidePressEventValue === "function" ? outsidePressEventValue() : outsidePressEventValue;
			if (typeof resolved === "string") return resolved;
			return resolved[computedType];
		}
		function shouldIgnoreEvent(event) {
			const computedOutsidePressEvent = getOutsidePressEvent();
			return computedOutsidePressEvent === "intentional" && event.type !== "click" || computedOutsidePressEvent === "sloppy" && event.type === "click";
		}
		function isEventWithinFloatingTree(event) {
			const nodeId = dataRef.current.floatingContext?.nodeId;
			const targetIsInsideChildren = tree && getNodeChildren(tree.nodesRef.current, nodeId).some((node) => isEventTargetWithin(event, node.context?.elements.floating));
			return isEventWithinOwnElements(event) || targetIsInsideChildren;
		}
		function closeOnPressOutside(event) {
			if (shouldIgnoreEvent(event)) {
				if (event.type !== "click" && !isEventWithinOwnElements(event)) {
					preventedPressSuppressionTimeout.clear();
					suppressNextOutsideClickRef.current = false;
				}
				clearInsideReactTree();
				return;
			}
			if (dataRef.current.insideReactTree) {
				clearInsideReactTree();
				return;
			}
			const target = getTarget(event);
			const inertSelector = `[${createAttribute("inert")}]`;
			const targetRoot = isElement(target) ? target.getRootNode() : null;
			const markers = Array.from((isShadowRoot(targetRoot) ? targetRoot : ownerDocument(store.select("floatingElement"))).querySelectorAll(inertSelector));
			const triggers = store.context.triggerElements;
			if (target && (triggers.hasElement(target) || triggers.hasMatchingElement((trigger) => contains(trigger, target)))) return;
			let targetRootAncestor = isElement(target) ? target : null;
			while (targetRootAncestor && !isLastTraversableNode(targetRootAncestor)) {
				const nextParent = getParentNode(targetRootAncestor);
				if (isLastTraversableNode(nextParent) || !isElement(nextParent)) break;
				targetRootAncestor = nextParent;
			}
			if (markers.length && isElement(target) && !isRootElement(target) && !contains(target, store.select("floatingElement")) && markers.every((marker) => !contains(targetRootAncestor, marker))) return;
			if (isHTMLElement(target) && !("touches" in event)) {
				const lastTraversableNode = isLastTraversableNode(target);
				const style = getComputedStyle$1(target);
				const scrollRe = /auto|scroll/;
				const isScrollableX = lastTraversableNode || scrollRe.test(style.overflowX);
				const isScrollableY = lastTraversableNode || scrollRe.test(style.overflowY);
				const canScrollX = isScrollableX && target.clientWidth > 0 && target.scrollWidth > target.clientWidth;
				const canScrollY = isScrollableY && target.clientHeight > 0 && target.scrollHeight > target.clientHeight;
				const isRTL = style.direction === "rtl";
				const pressedVerticalScrollbar = canScrollY && (isRTL ? event.offsetX <= target.offsetWidth - target.clientWidth : event.offsetX > target.clientWidth);
				const pressedHorizontalScrollbar = canScrollX && event.offsetY > target.clientHeight;
				if (pressedVerticalScrollbar || pressedHorizontalScrollbar) return;
			}
			if (isEventWithinFloatingTree(event)) return;
			if (getOutsidePressEvent() === "intentional") {
				if (event.detail !== 0 && !isVirtualClick(event) && !sawPressWhileOpenRef.current) return;
				if (suppressNextOutsideClickRef.current) {
					preventedPressSuppressionTimeout.clear();
					suppressNextOutsideClickRef.current = false;
					return;
				}
			}
			if (typeof outsidePress$1 === "function" && !outsidePress$1(event)) return;
			if (hasBlockingChild("__outsidePressBubbles")) return;
			store.setOpen(false, createChangeEventDetails(outsidePress, event));
			clearInsideReactTree();
		}
		function handlePointerDown(event) {
			if (getOutsidePressEvent() !== "sloppy" || event.pointerType === "touch" || !store.select("open") || !enabled || isEventWithinOwnElements(event)) return;
			closeOnPressOutside(event);
		}
		function handleTouchStart(event) {
			if (getOutsidePressEvent() !== "sloppy" || !store.select("open") || !enabled || isEventWithinOwnElements(event)) return;
			const touch = event.touches[0];
			if (touch) {
				touchStateRef.current = {
					startTime: Date.now(),
					startX: touch.clientX,
					startY: touch.clientY,
					dismissOnTouchEnd: false,
					dismissOnMouseDown: true
				};
				cancelDismissOnEndTimeout.start(1e3, () => {
					if (touchStateRef.current) {
						touchStateRef.current.dismissOnTouchEnd = false;
						touchStateRef.current.dismissOnMouseDown = false;
					}
				});
			}
		}
		function addTargetEventListenerOnce(event, listener) {
			const target = getTarget(event);
			if (!target) return;
			const unsubscribe = addEventListener(target, event.type, () => {
				listener(event);
				unsubscribe();
			});
		}
		function handleTouchStartCapture(event) {
			currentPointerTypeRef.current = "touch";
			addTargetEventListenerOnce(event, handleTouchStart);
		}
		function closeOnPressOutsideCapture(event) {
			cancelDismissOnEndTimeout.clear();
			if (event.type === "pointerdown") {
				if (event.button === 0) sawPressWhileOpenRef.current = true;
				currentPointerTypeRef.current = event.pointerType;
			}
			if (event.type === "mousedown" && touchStateRef.current && !touchStateRef.current.dismissOnMouseDown) return;
			addTargetEventListenerOnce(event, (targetEvent) => {
				if (targetEvent.type === "pointerdown") handlePointerDown(targetEvent);
				else closeOnPressOutside(targetEvent);
			});
		}
		function handlePressEndCapture(event) {
			if (event.type === "pointercancel") sawPressWhileOpenRef.current = false;
			if (!pressStartedInsideRef.current) return;
			const pressStartedInsideDefaultPrevented = pressStartPreventedRef.current;
			resetPressStartState();
			if (getOutsidePressEvent() !== "intentional") return;
			if (event.type === "pointercancel") {
				if (pressStartedInsideDefaultPrevented) suppressImmediateOutsideClickAfterPreventedStart();
				return;
			}
			if (isEventWithinFloatingTree(event)) return;
			if (pressStartedInsideDefaultPrevented) {
				suppressImmediateOutsideClickAfterPreventedStart();
				return;
			}
			if (typeof outsidePress$1 === "function" && !outsidePress$1(event)) return;
			preventedPressSuppressionTimeout.clear();
			suppressNextOutsideClickRef.current = true;
			clearInsideReactTree();
		}
		function handleTouchMove(event) {
			if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventWithinOwnElements(event)) return;
			const touch = event.touches[0];
			if (!touch) return;
			const deltaX = Math.abs(touch.clientX - touchStateRef.current.startX);
			const deltaY = Math.abs(touch.clientY - touchStateRef.current.startY);
			const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
			if (distance > 5) touchStateRef.current.dismissOnTouchEnd = true;
			if (distance > 10) {
				closeOnPressOutside(event);
				cancelDismissOnEndTimeout.clear();
				touchStateRef.current = null;
			}
		}
		function handleTouchMoveCapture(event) {
			addTargetEventListenerOnce(event, handleTouchMove);
		}
		function handleTouchEnd(event) {
			if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventWithinOwnElements(event)) return;
			if (touchStateRef.current.dismissOnTouchEnd) closeOnPressOutside(event);
			cancelDismissOnEndTimeout.clear();
			touchStateRef.current = null;
		}
		function handleTouchEndCapture(event) {
			addTargetEventListenerOnce(event, handleTouchEnd);
		}
		const unsubscribe = mergeCleanups(escapeKey$1 && mergeCleanups(addEventListener(doc, "keydown", closeOnEscapeKeyDown), addEventListener(doc, "compositionstart", handleCompositionStart), addEventListener(doc, "compositionend", handleCompositionEnd)), outsidePressEnabled && mergeCleanups(addEventListener(doc, "click", closeOnPressOutsideCapture, true), addEventListener(doc, "pointerdown", closeOnPressOutsideCapture, true), addEventListener(doc, "pointerup", handlePressEndCapture, true), addEventListener(doc, "pointercancel", handlePressEndCapture, true), addEventListener(doc, "mousedown", closeOnPressOutsideCapture, true), addEventListener(doc, "mouseup", handlePressEndCapture, true), addEventListener(doc, "touchstart", handleTouchStartCapture, {
			capture: true,
			passive: true
		}), addEventListener(doc, "touchmove", handleTouchMoveCapture, {
			capture: true,
			passive: true
		}), addEventListener(doc, "touchend", handleTouchEndCapture, {
			capture: true,
			passive: true
		})));
		return () => {
			unsubscribe();
			preventedPressSuppressionTimeout.clear();
			resetPressStartState();
			suppressNextOutsideClickRef.current = false;
		};
	}, [
		dataRef,
		floatingElement,
		escapeKey$1,
		outsidePressEnabled,
		outsidePress$1,
		open,
		enabled,
		escapeKeyBubbles,
		outsidePressBubbles,
		closeOnEscapeKeyDown,
		clearInsideReactTree,
		getOutsidePressEventProp,
		hasBlockingChild,
		isEventWithinOwnElements,
		tree,
		store,
		cancelDismissOnEndTimeout,
		compositionTimeout
	]);
	const reference = import_react.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		onPointerDown: closeOnReferencePress,
		onClick: closeOnReferencePress
	}), [closeOnEscapeKeyDown, closeOnReferencePress]);
	const floating = import_react.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		onPointerDown: markInsidePressStartPrevented,
		onMouseDown: markInsidePressStartPrevented,
		onClickCapture: markInsideReactTree,
		onMouseDownCapture(event) {
			markInsideReactTree();
			markPressStartedInsideReactTree(event);
		},
		onPointerDownCapture(event) {
			markInsideReactTree();
			markPressStartedInsideReactTree(event);
		},
		onMouseUpCapture: markInsideReactTree,
		onTouchEndCapture: markInsideReactTree,
		onTouchMoveCapture: markInsideReactTree
	}), [
		closeOnEscapeKeyDown,
		markInsideReactTree,
		markPressStartedInsideReactTree,
		markInsidePressStartPrevented
	]);
	return import_react.useMemo(() => enabled ? {
		reference,
		floating,
		trigger: reference
	} : {}, [
		enabled,
		reference,
		floating
	]);
}
// node_modules/@base-ui/react/utils/popups/popupHandle.mjs
/**
* Minimal store contract exposed by popup handles to detached triggers.
*
* Detached triggers read `store` during render and subscribe to be notified when the handle switches
* between its fallback store and a root's live store.
*
* @template HandleStore Store shape exposed to detached triggers.
*/
/**
* Store shape holding a trigger registry, required by `BasePopupHandle.openByTrigger` to resolve a
* trigger element by id on both the attached root's store and the fallback store.
*/
/**
* Store shape required by `BasePopupHandle.openByTrigger`/`closePopup` to drive open/close state.
* Only the root-owned `Store` needs this — the `HandleStore` view exposed to detached triggers may
* omit `setOpen` entirely (as Dialog and PreviewCard's do) since it is never called while detached.
*/
/**
* Shared implementation for popup handles that coordinate detached triggers with a mounted root.
*
* Subclasses provide the component-specific imperative methods, while this base class owns the
* fallback store, root store attachment stack, subscriber notifications, and development warning for
* overlapping roots.
*
* @template HandleStore Store shape exposed to detached triggers.
* @template Store Root-owned store attached by the component root.
*/
var BasePopupHandle = class {
	/**
	* Stores of every root currently using this handle, in attach order. A handle is meant to be used
	* by a single mounted root, but roots can transiently overlap (e.g. during an animated route
	* transition), so this stack lets `attachStore`'s cleanup restore the previous root instead of
	* leaving a still-mounted root uncontrollable when a newer overlapping root detaches first.
	*/
	attachedStores = [];
	/**
	* Store of the root that currently controls the handle: the most recently attached one still
	* mounted, or `null` when no root is attached. Imperative methods are no-ops while this is `null`.
	*/
	attachedStoreValue = null;
	/**
	* Listeners notified when `attachedStore` changes, so detached triggers can follow the store pointer.
	*/
	storeListeners = /* @__PURE__ */ new Set();
	/**
	* Creates a handle backed by the store used while no root is attached.
	*
	* @param fallbackStore Inert, closed store handed to detached triggers while no root is attached,
	* so they can render and register without a mounted root. Triggers register into whichever store
	* `store` currently resolves to, so while detached they live in this store's trigger map and
	* migrate themselves to the root's store (and back) as it attaches/detaches.
	* @param componentName Component name used to prefix dev warnings, e.g. `'Menu'` produces
	* `MenuHandle.open()` in warning text.
	* @param throwOnMissingTrigger Whether `open(triggerId)` throws when no trigger with that id is
	* registered. Anchored popups (Menu, Popover, Tooltip, PreviewCard) need a trigger to anchor to,
	* so they throw; Dialog is not anchored and instead opens unassociated with a dev warning.
	*/
	constructor(fallbackStore, componentName, throwOnMissingTrigger = true) {
		this.fallbackStore = fallbackStore;
		this.componentName = componentName;
		this.throwOnMissingTrigger = throwOnMissingTrigger;
	}
	get attachedStore() {
		return this.attachedStoreValue;
	}
	/**
	* Store that detached triggers read from: the attached root's store, or an inert fallback store
	* used while no root is attached.
	* @internal
	*/
	get store() {
		return this.attachedStoreValue ?? this.fallbackStore;
	}
	/**
	* Stable fallback store used for server rendering and hydration. Root stores cannot be recorded on
	* the handle during render because a handle can be shared by concurrent server-rendered requests.
	* @internal
	*/
	get serverStore() {
		return this.fallbackStore;
	}
	/**
	* Subscribes to changes of the attached store pointer so detached triggers re-render and re-bind
	* when a root attaches or detaches. Returns a function that removes the listener.
	* @internal
	*/
	subscribeStore(listener) {
		this.storeListeners.add(listener);
		return () => {
			this.storeListeners.delete(listener);
		};
	}
	/**
	* Points the handle at a root's store and notifies subscribers so detached triggers re-render and
	* re-register into it (their registration effect migrates them when the store pointer changes).
	* Returns a cleanup function that detaches the store again.
	* @internal
	*/
	attachStore(newStore) {
		this.attachedStores.push(newStore);
		this.setActiveStore(newStore);
		if (this.attachedStores.length > 1) {
			const dev = this;
			(dev.overlapWarningFrame ??= AnimationFrame.create()).request(() => {
				if (this.attachedStores.length > 1) console.warn("Base UI: A handle is attached to more than one mounted root at the same time. The most recently mounted root takes over and the previous one stops being controlled by the handle. A handle should be used by a single root that stays mounted for the lifetime of the handle.");
			});
		}
		return () => {
			const index = this.attachedStores.lastIndexOf(newStore);
			if (index !== -1) this.attachedStores.splice(index, 1);
			this.setActiveStore(this.attachedStores[this.attachedStores.length - 1] ?? null);
		};
	}
	/**
	* Sets the store that currently controls the handle and notifies subscribers when it changes, so
	* detached triggers re-render and migrate their registration to the new store.
	*/
	setActiveStore(store) {
		if (this.attachedStoreValue !== store) {
			this.attachedStoreValue = store;
			this.storeListeners.forEach((listener) => {
				listener();
			});
		}
	}
	/**
	* Opens the attached root's store and associates it with the trigger with the given id, or a
	* no-op (with a dev warning) while no root is attached. Shared by every concrete handle's public
	* `open()` method, which only narrows the parameter type.
	*
	* When a trigger id is given but no matching trigger is registered, anchored popups throw (see
	* `throwOnMissingTrigger`); Dialog opens unassociated with a dev warning instead.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the popup, or `null`/`undefined` to open
	* without associating any trigger.
	*/
	openByTrigger(triggerId) {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn(`Base UI: ${this.componentName}Handle.open() was called while no root using this handle is mounted. The call was ignored; mount a root with this handle before opening it imperatively.`);
			return;
		}
		let triggerElement;
		if (triggerId) {
			for (let i = this.attachedStores.length - 1; i >= 0 && !triggerElement; i -= 1) triggerElement = this.attachedStores[i].context.triggerElements.getById(triggerId);
			triggerElement ??= this.fallbackStore.context.triggerElements.getById(triggerId);
		}
		if (triggerId && !triggerElement) {
			if (this.throwOnMissingTrigger) throw new Error(`Base UI: ${this.componentName}Handle.open() was called with the trigger id "${triggerId}", but no matching trigger is registered with this handle. An anchored popup cannot open without a trigger to anchor to. Pass the id of a mounted ${this.componentName}.Trigger that has this handle set on its "handle" prop.`);
			console.warn(`Base UI: ${this.componentName}Handle.open: No trigger found with id "${triggerId}". The popup will open, but the trigger will not be associated with it.`);
		}
		attachedStore.setOpen(true, createChangeEventDetails(imperativeAction, void 0, triggerElement));
	}
	/**
	* Closes the popup by setting the attached root's store to closed, or a no-op (with a dev warning)
	* while no root is attached. Shared by every concrete handle's public `close()` method.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	closePopup() {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn(`Base UI: ${this.componentName}Handle.close() was called while no root using this handle is mounted. The call was ignored.`);
			return;
		}
		attachedStore.setOpen(false, createChangeEventDetails(imperativeAction));
	}
};
// node_modules/@base-ui/react/floating-ui-react/hooks/useSyncedFloatingRootContext.mjs
/**
* Narrowed to the store members this hook uses so consumers do not need to provide
* unrelated store capabilities.
*/
/**
* Keeps the provided FloatingRootStore in sync with the provided PopupStore.
*/
function useSyncedFloatingRootContext(options) {
	const { popupStore, treatPopupAsFloatingElement = false, floatingRootContext: store, floatingId, nested, onOpenChange } = options;
	const open = popupStore.useState("open");
	const referenceElement = popupStore.useState("activeTriggerElement");
	const floatingElement = popupStore.useState(treatPopupAsFloatingElement ? "popupElement" : "positionerElement");
	const handleOpenChange = onOpenChange;
	popupStore.useSyncedValue("floatingId", floatingId);
	useIsoLayoutEffect(() => {
		const valuesToSync = {
			open,
			floatingId,
			referenceElement,
			floatingElement
		};
		if (isElement(referenceElement)) valuesToSync.domReferenceElement = referenceElement;
		if (store.state.positionReference === store.state.referenceElement) valuesToSync.positionReference = referenceElement;
		store.update(valuesToSync);
	}, [
		open,
		floatingId,
		referenceElement,
		floatingElement,
		store
	]);
	store.context.onOpenChange = handleOpenChange;
	store.context.nested = nested;
	return store;
}
// node_modules/@base-ui/react/internals/useTransitionStatus.mjs
/**
* Provides a status string for CSS animations.
* @param open - a boolean that determines if the element is open.
* @param enableIdleState - a boolean that enables the `'idle'` state between `'starting'` and `'ending'`
* @param deferEndingState - a boolean that delays the `'ending'` state by a frame
* @param animateInitialOpen - a boolean that makes an element which mounts already open still go
*   through `'starting'`. Off by default so content that was open on the first render (a
*   `defaultOpen` popup on page load, SSR'd markup) doesn't animate in.
*/
function useTransitionStatus(open, enableIdleState = false, deferEndingState = false, animateInitialOpen = false) {
	const [transitionStatus, setTransitionStatus] = import_react.useState(open && enableIdleState ? "idle" : void 0);
	const [mounted, setMounted] = import_react.useState(open && !animateInitialOpen);
	if (open && !mounted) {
		setMounted(true);
		setTransitionStatus("starting");
	}
	if (!open && mounted && transitionStatus !== "ending" && !deferEndingState) setTransitionStatus("ending");
	if (!open && !mounted && transitionStatus === "ending") setTransitionStatus(void 0);
	useIsoLayoutEffect(() => {
		if (!open && mounted && transitionStatus !== "ending" && deferEndingState) {
			const frame = AnimationFrame.request(() => {
				setTransitionStatus("ending");
			});
			return () => {
				AnimationFrame.cancel(frame);
			};
		}
	}, [
		open,
		mounted,
		transitionStatus,
		deferEndingState
	]);
	useIsoLayoutEffect(() => {
		if (!open || enableIdleState || transitionStatus === void 0) return;
		const frame = AnimationFrame.request(() => {
			setTransitionStatus(void 0);
		});
		return () => {
			AnimationFrame.cancel(frame);
		};
	}, [
		enableIdleState,
		open,
		transitionStatus
	]);
	useIsoLayoutEffect(() => {
		if (!open || !enableIdleState) return;
		if (open && mounted && transitionStatus !== "idle") setTransitionStatus("starting");
		const frame = AnimationFrame.request(() => {
			setTransitionStatus("idle");
		});
		return () => {
			AnimationFrame.cancel(frame);
		};
	}, [
		enableIdleState,
		open,
		mounted,
		transitionStatus
	]);
	return {
		mounted,
		setMounted,
		transitionStatus
	};
}
// node_modules/@base-ui/react/utils/getFiniteAnimations.mjs
/**
* Excludes infinite animations, whose finished promises never resolve while they run.
*/
function getFiniteAnimations(element, options) {
	return element.getAnimations(options).filter((animation) => {
		const timing = animation.effect?.getTiming();
		return timing?.duration !== Infinity && timing?.iterations !== Infinity;
	});
}
// node_modules/@base-ui/react/internals/useAnimationsFinished.mjs
var pendingCallbacks = null;
/**
* Runs the callback in a synchronous flush before the browser paints, so that the
* browser doesn't paint an intermediate frame: https://github.com/mui/base-ui/issues/979
* Callbacks that become ready within the same microtask checkpoint (e.g. multiple elements
* whose animations finish together) are batched into a single commit:
* https://github.com/mui/base-ui/issues/5481
*/
function flushBeforePaint(fn) {
	if (!pendingCallbacks) {
		const callbacks = [];
		pendingCallbacks = callbacks;
		queueMicrotask(() => {
			pendingCallbacks = null;
			import_react_dom.flushSync(() => {
				for (const callback of callbacks) callback();
			});
		});
	}
	pendingCallbacks.push(fn);
}
/**
* Executes a function once all animations have finished on the provided element.
* If an animation is canceled, waits for any replacement animations before executing.
* @param elementOrRef - The element to watch for animations.
* @param waitForStartingStyleRemoved - Whether to wait for [data-starting-style] to be removed before checking for animations.
* @param batch - Whether completions ready in the same microtask may be coalesced into a single
* commit. A batched callback runs before earlier callbacks' React updates have committed, so only
* opt in when the callback doesn't read state that another completion can change.
* @returns A function that takes a callback to execute once all animations have finished, and an optional AbortSignal to abort the callback
*/
function useAnimationsFinished(elementOrRef, waitForStartingStyleRemoved = false, batch = false) {
	const frame = useAnimationFrame();
	return useStableCallback((fnToExecute, signal = null) => {
		frame.cancel();
		const element = resolveRef(elementOrRef);
		if (element == null) return;
		const resolvedElement = element;
		const done = () => {
			if (!batch) {
				import_react_dom.flushSync(fnToExecute);
				return;
			}
			flushBeforePaint(() => {
				if (!signal?.aborted) fnToExecute();
			});
		};
		if (typeof resolvedElement.getAnimations !== "function" || globalThis.BASE_UI_ANIMATIONS_DISABLED) {
			fnToExecute();
			return;
		}
		function exec() {
			Promise.all(getFiniteAnimations(resolvedElement).map((animation) => animation.finished.then(NOOP))).then(() => {
				if (!signal?.aborted) done();
			}, () => {
				if (signal?.aborted) return;
				if (getFiniteAnimations(resolvedElement).some((animation) => animation.pending || animation.playState !== "finished")) {
					exec();
					return;
				}
				done();
			});
		}
		if (waitForStartingStyleRemoved) {
			const startingStyleAttribute = startingStyle$4;
			if (!resolvedElement.hasAttribute(startingStyleAttribute)) {
				frame.request(exec);
				return;
			}
			const attributeObserver = new MutationObserver(() => {
				if (!resolvedElement.hasAttribute(startingStyleAttribute)) {
					attributeObserver.disconnect();
					exec();
				}
			});
			attributeObserver.observe(resolvedElement, {
				attributes: true,
				attributeFilter: [startingStyleAttribute]
			});
			signal?.addEventListener("abort", () => attributeObserver.disconnect(), { once: true });
			return;
		}
		frame.request(exec);
	});
}
// node_modules/@base-ui/react/internals/useOpenChangeComplete.mjs
/**
* Calls the provided function when the CSS open/close animation or transition completes.
*/
function useOpenChangeComplete(parameters) {
	const { enabled = true, open, ref, batch = false, onComplete: onCompleteParam } = parameters;
	const onComplete = useStableCallback(onCompleteParam);
	const runOnceAnimationsFinish = useAnimationsFinished(ref, open, batch);
	import_react.useEffect(() => {
		if (!enabled) return;
		const abortController = new AbortController();
		runOnceAnimationsFinish(onComplete, abortController.signal);
		return () => {
			abortController.abort();
		};
	}, [
		enabled,
		open,
		onComplete,
		runOnceAnimationsFinish
	]);
}
// node_modules/@base-ui/react/internals/useUnmountAfterClose.mjs
/**
* Keeps a popup mounted through its closing animation and unmounts it once the animation
* finishes, unless the close cycle opted out through `preventUnmountOnClose`.
* Store-agnostic: hosts sync `mounted` and `transitionStatus` wherever they need them.
*
* @returns `forceUnmount` unmounts the popup immediately. It is a no-op once the popup is already
*   unmounted, so calling it after the automatic unmount doesn't repeat the completion callback,
*   and a call while the popup is open only takes effect if a close commits in the same batch.
*/
function useUnmountAfterClose(parameters) {
	const { open, ref, preventUnmountOnClose, setPreventUnmountOnClose: setPreventUnmountOnCloseParam, onUnmount, animateInitialOpen } = parameters;
	const setPreventUnmountOnClose = useStableCallback(setPreventUnmountOnCloseParam);
	const { mounted, setMounted, transitionStatus } = useTransitionStatus(open, false, false, animateInitialOpen);
	const preventUnmountingOnClose = open ? false : preventUnmountOnClose;
	useIsoLayoutEffect(() => {
		if (open) setPreventUnmountOnClose(false);
	}, [open, setPreventUnmountOnClose]);
	const mountedRef = import_react.useRef(mounted);
	const pendingUnmountRef = import_react.useRef(false);
	const rerender = useForcedRerendering();
	const unmount = () => {
		mountedRef.current = false;
		setMounted(false);
		onUnmount();
	};
	useIsoLayoutEffect(() => {
		mountedRef.current = mounted;
		if (pendingUnmountRef.current) {
			pendingUnmountRef.current = false;
			if (!open && mounted) unmount();
		}
	});
	const forceUnmount = useStableCallback(() => {
		if (!mountedRef.current) return;
		if (open) {
			pendingUnmountRef.current = true;
			rerender();
			return;
		}
		unmount();
	});
	useOpenChangeComplete({
		enabled: mounted && !open && !preventUnmountingOnClose,
		open,
		ref,
		onComplete() {
			if (!open) forceUnmount();
		}
	});
	return {
		mounted,
		transitionStatus,
		preventUnmountingOnClose,
		forceUnmount
	};
}
// node_modules/@base-ui/react/utils/popups/popupStoreUtils.mjs
var FOCUSABLE_POPUP_PROPS = {
	tabIndex: -1,
	[FOCUSABLE_ATTRIBUTE]: ""
};
/**
* Returns the default `initialFocus` resolver for a popup. When opened by touch it focuses the
* popup element itself to prevent the virtual keyboard from opening (required for Android
* specifically; iOS handles this automatically). Otherwise it falls back to the default behavior.
*/
function createDefaultInitialFocus(popupRef) {
	return (interactionType) => interactionType === "touch" ? popupRef.current : true;
}
/**
* The subset of a popup handle that a Root needs to bind its store to. Both the real handle classes
* and any test double satisfy it.
*/
/**
* Creates and owns a popup store on behalf of a Root part. The store is created exactly once, with
* controlled props and root state synced separately after creation. Sets up the synced floating
* root context and returns the store.
*
* @param createStore Factory that builds the store. Called exactly once, receiving the floating id
* and whether the popup is nested inside another floating element, both resolved on the first render.
* @param treatPopupAsFloatingElement Whether the popup element is passed to Floating UI as the
* floating element instead of the default positioner.
*/
function usePopupRootStore(createStore, treatPopupAsFloatingElement = false) {
	const floatingId = useId();
	const nested = useFloatingParentNodeId() != null;
	const store = useRefWithInit(() => createStore(floatingId, nested)).current;
	useSyncedFloatingRootContext({
		popupStore: store,
		treatPopupAsFloatingElement,
		floatingRootContext: store.state.floatingRootContext,
		floatingId,
		nested,
		onOpenChange: store.setOpen
	});
	return store;
}
/**
* Attaches a Root's store to a handle for this component's committed lifetime. Popup Roots render
* it before their interactions and user children so its layout effect runs before descendant layout
* effects. This lets descendants call the handle during the Root's initial commit without attaching
* during render, which would leak suspended or abandoned stores. Store subscribers are notified by
* `attachStore` in this ordinary layout phase, where React permits synchronous updates.
*
* Popup Roots must render this component only when a handle is present so handle-less Roots avoid
* mounting an extra fiber and layout effect.
*/
function PopupHandleAttachment({ handle, store }) {
	useIsoLayoutEffect(() => {
		return handle.attachStore(store);
	}, [handle, store]);
	return null;
}
function syncTriggerCount(store) {
	const triggerCount = store.context.triggerElements.size;
	if (store.select("open") && store.state.triggerCount !== triggerCount) store.set("triggerCount", triggerCount);
}
/**
* Returns a stable callback ref that registers/unregisters the trigger element in the store.
*
* Stable so a downstream ref merger that retains the callback it was first given still reaches the
* trigger's current store. The registration is tracked as a `(store, id, element)` triple, so
* unregistering targets the store the element was actually registered in.
*
* Since the callback never changes, the caller must re-run it from a layout effect keyed on
* `[store, id]` to migrate an already-registered element. That effect is also what registers the
* element in the first place when `id` only resolves after the first commit (React 17's `useId`
* fallback), because the register call made while the id is still `undefined` does nothing.
*
* @param id Id of the trigger.
* @param store The Store instance where the trigger should be registered.
*/
function useTriggerRegistration(id, store) {
	const registrationRef = import_react.useRef(null);
	return useStableCallback((element) => {
		const registration = registrationRef.current;
		if (registration !== null) {
			if (registration.element === element && registration.store === store && registration.id === id) return;
			registrationRef.current = null;
			const registeredStore = registration.store;
			if (registeredStore.context.triggerElements.getById(registration.id) === registration.element) {
				registeredStore.context.triggerElements.delete(registration.id);
				syncTriggerCount(registeredStore);
			}
		}
		if (element !== null && id !== void 0) {
			registrationRef.current = {
				store,
				id,
				element
			};
			store.context.triggerElements.add(id, element);
			syncTriggerCount(store);
		}
	});
}
function createPopupOpenState(state, open, trigger, preventUnmountOnClose = false) {
	let preventUnmountingOnClose = state.preventUnmountingOnClose;
	if (open) preventUnmountingOnClose = false;
	else if (preventUnmountOnClose) preventUnmountingOnClose = true;
	const triggerId = trigger?.id ?? null;
	let activeTriggerId = state.activeTriggerId;
	let activeTriggerElement = state.activeTriggerElement;
	if (triggerId || open) {
		activeTriggerId = triggerId;
		activeTriggerElement = trigger ?? null;
	}
	return {
		open,
		preventUnmountingOnClose,
		activeTriggerId,
		activeTriggerElement,
		openedWithoutTrigger: open ? trigger == null : state.openedWithoutTrigger
	};
}
/**
* Sets up trigger data forwarding to the store.
*
* @param triggerId Id of the trigger.
* @param triggerElementRef Ref for the trigger DOM element.
* @param store The Store instance managing the popup state.
* @param stateUpdates An object with state updates to apply when the trigger is active.
*/
function useTriggerDataForwarding(triggerId, triggerElementRef, store, stateUpdates) {
	const isMountedByThisTrigger = store.useState("isMountedByTrigger", triggerId);
	const baseRegisterTrigger = useTriggerRegistration(triggerId, store);
	const applyTriggerData = useStableCallback((element) => {
		const open = store.select("open");
		const activeTriggerId = store.select("activeTriggerId");
		if (activeTriggerId === triggerId) {
			const changes = {
				activeTriggerElement: element,
				...open ? stateUpdates : null
			};
			store.update(changes);
			return;
		}
		if (activeTriggerId == null && open && !store.state.openedWithoutTrigger) {
			const changes = {
				activeTriggerId: triggerId ?? null,
				activeTriggerElement: element,
				...stateUpdates
			};
			store.update(changes);
		}
	});
	const registerTrigger = useStableCallback((element) => {
		baseRegisterTrigger(element);
		if (element) applyTriggerData(element);
	});
	useIsoLayoutEffect(() => {
		registerTrigger(triggerElementRef.current);
		return () => registerTrigger(null);
	}, [
		registerTrigger,
		triggerElementRef,
		store,
		triggerId
	]);
	useIsoLayoutEffect(() => {
		if (isMountedByThisTrigger) {
			const changes = {
				activeTriggerElement: triggerElementRef.current,
				...stateUpdates
			};
			store.update(changes);
		}
	}, [
		isMountedByThisTrigger,
		store,
		triggerElementRef,
		...Object.values(stateUpdates)
	]);
	return {
		registerTrigger,
		isMountedByThisTrigger
	};
}
/**
* Keeps trigger registration state synchronized while the popup is open.
*
* When a popup opens without an explicit trigger id and exactly one trigger is registered, that
* trigger is claimed as the active trigger, unless the open request deliberately carried no trigger
* (`openedWithoutTrigger`). When the active trigger id is still registered but its
* element changed, the active element is refreshed. When the active trigger id is missing from the
* registry but the same element is still registered under a different id (e.g. the rendered trigger
* carries its own DOM `id` that differs from Base UI's internal trigger id), the active id is
* reassociated to the registered id instead of being treated as lost. When the active trigger
* unregisters, the default path preserves existing ownership so non-closing popup families do not
* silently claim a different trigger while staying open.
*
* If `closeOnActiveTriggerUnmount` is enabled, unregistering a previously resolved active trigger
* requests a close after a microtask so a same-tick replacement trigger with the same id can
* register first. An active trigger id that has not matched a registered trigger yet is treated as
* pending and does not request a close.
*
* This should be called on the Root part.
*
* @param store The Store instance managing the popup state.
* @param options Options for active trigger unmount behavior.
*/
function useImplicitActiveTrigger(store, options = {}) {
	const { closeOnActiveTriggerUnmount = false } = options;
	const resolvedActiveTriggerIdRef = import_react.useRef(null);
	const open = store.useState("open");
	const reactiveTriggerCount = store.useState("triggerCount");
	const activeTriggerId = store.useState("activeTriggerId");
	const reactiveActiveTriggerElement = store.useState("activeTriggerElement");
	useIsoLayoutEffect(() => {
		if (!open) {
			resolvedActiveTriggerIdRef.current = null;
			if (store.state.triggerCount !== 0) store.set("triggerCount", 0);
			if (store.state.openedWithoutTrigger) store.set("openedWithoutTrigger", false);
			return;
		}
		const triggerCount = store.context.triggerElements.size;
		const stateUpdates = {};
		if (store.state.triggerCount !== triggerCount) stateUpdates.triggerCount = triggerCount;
		const currentActiveTriggerId = store.select("activeTriggerId");
		let lostActiveTriggerId = null;
		if (currentActiveTriggerId) {
			const activeTriggerElement = store.context.triggerElements.getById(currentActiveTriggerId);
			if (!activeTriggerElement) {
				for (const [triggerId, triggerElement] of store.context.triggerElements.entries()) if (triggerElement === store.state.activeTriggerElement) {
					stateUpdates.activeTriggerId = triggerId;
					stateUpdates.activeTriggerElement = triggerElement;
					resolvedActiveTriggerIdRef.current = triggerId;
					break;
				}
				if (stateUpdates.activeTriggerId === void 0) {
					if (resolvedActiveTriggerIdRef.current === currentActiveTriggerId) lostActiveTriggerId = currentActiveTriggerId;
					else resolvedActiveTriggerIdRef.current = null;
				}
			} else {
				resolvedActiveTriggerIdRef.current = currentActiveTriggerId;
				if (activeTriggerElement !== store.state.activeTriggerElement) stateUpdates.activeTriggerElement = activeTriggerElement;
			}
		} else resolvedActiveTriggerIdRef.current = null;
		if (!lostActiveTriggerId && !currentActiveTriggerId && !store.state.openedWithoutTrigger && triggerCount === 1) {
			const iteratorResult = store.context.triggerElements.entries().next();
			if (!iteratorResult.done) {
				const [implicitTriggerId, implicitTriggerElement] = iteratorResult.value;
				stateUpdates.activeTriggerId = implicitTriggerId;
				stateUpdates.activeTriggerElement = implicitTriggerElement;
				resolvedActiveTriggerIdRef.current = implicitTriggerId;
			}
		}
		if (stateUpdates.triggerCount !== void 0 || stateUpdates.activeTriggerId !== void 0 || stateUpdates.activeTriggerElement !== void 0) store.update(stateUpdates);
		if (lostActiveTriggerId) {
			if (closeOnActiveTriggerUnmount) queueMicrotask(() => {
				if (store.select("open") && store.select("activeTriggerId") === lostActiveTriggerId && !store.context.triggerElements.getById(lostActiveTriggerId)) {
					const eventDetails = createChangeEventDetails(none);
					store.setOpen(false, eventDetails);
					if (!eventDetails.isCanceled) store.update({
						activeTriggerId: null,
						activeTriggerElement: null
					});
				}
			});
		}
	}, [
		open,
		store,
		reactiveTriggerCount,
		activeTriggerId,
		reactiveActiveTriggerElement,
		closeOnActiveTriggerUnmount
	]);
}
/**
* Manages the mounted state of the popup.
* Sets up the transition status listeners and handles unmounting when needed.
* Updates the `mounted`, `transitionStatus`, and `preventUnmountingOnClose` states in the store.
*
* @param open Whether the popup is open.
* @param store The Store instance managing the popup state.
* @param onUnmount Optional callback to be called when the popup is unmounted.
* @param animateInitialOpen Whether a popup that mounts already open should still play its enter
*   transition. Defaults to `false`, so content that was open on the first render (a `defaultOpen`
*   popup on page load, SSR'd markup) appears without animating. Opt in for popups whose subtree
*   only mounts in response to something the user did, such as a submenu inside a menu popup.
*
* @returns A function to forcibly unmount the popup. It is a no-op once the popup is already
*   unmounted, so calling it after the automatic unmount doesn't repeat the completion callback.
*/
function useOpenStateTransitions(open, store, onUnmount, animateInitialOpen) {
	const { mounted, transitionStatus, forceUnmount } = useUnmountAfterClose({
		open,
		ref: store.context.popupRef,
		preventUnmountOnClose: store.useState("preventUnmountingOnClose"),
		setPreventUnmountOnClose: (preventUnmountOnClose) => store.set("preventUnmountingOnClose", preventUnmountOnClose),
		animateInitialOpen,
		onUnmount() {
			store.update({
				activeTriggerId: null,
				activeTriggerElement: null,
				mounted: false,
				preventUnmountingOnClose: false
			});
			onUnmount?.();
			store.context.onOpenChangeComplete?.(false);
		}
	});
	useRefWithInit(() => {
		store.set("mounted", mounted);
		return null;
	});
	store.useSyncedValues({
		mounted,
		transitionStatus
	});
	return {
		forceUnmount,
		transitionStatus
	};
}
function usePopupInteractionProps(store, statePart) {
	store.useSyncedValues(statePart);
	useIsoLayoutEffect(() => () => {
		store.update({
			activeTriggerProps: EMPTY_OBJECT,
			inactiveTriggerProps: EMPTY_OBJECT,
			popupProps: EMPTY_OBJECT
		});
	}, [store]);
}
function usePopupRootSync(store, open) {
	useIsoLayoutEffect(() => {
		if (!open && store.state.openMethod !== null) store.set("openMethod", null);
	}, [open, store]);
	useIsoLayoutEffect(() => () => {
		if (store.state.openMethod !== null) store.set("openMethod", null);
	}, [store]);
}
// node_modules/@base-ui/react/utils/popups/popupTriggerMap.mjs
/**
* Development-only reverse index of element to registered id, keyed by the owning map.
*
* Registration would otherwise have to scan every entry to detect an element claimed by two ids,
* making the mount of many triggers sharing one handle quadratic. Kept module-scoped, lazily
* initialized, and read only from `process.env.NODE_ENV` guards so production builds drop it along
* with the checks.
*/
var devElementIdsByMap;
function getDevElementIds(map) {
	devElementIdsByMap ??= /* @__PURE__ */ new WeakMap();
	let elementIds = devElementIdsByMap.get(map);
	if (!elementIds) {
		elementIds = /* @__PURE__ */ new WeakMap();
		devElementIdsByMap.set(map, elementIds);
	}
	return elementIds;
}
/**
* Data structure to keep track of popup trigger elements by their IDs.
*
* Element lookups iterate the id map rather than maintaining a parallel Set. Registration is O(1),
* while `hasElement` and `hasMatchingElement` are linear in the number of triggers.
*/
var PopupTriggerMap = class {
	idMap = /* @__PURE__ */ new Map();
	/**
	* Adds a trigger element with the given ID.
	*
	* Note: The provided element is assumed to not be registered under multiple IDs.
	*/
	add(id, element) {
		{
			const elementIds = getDevElementIds(this);
			const existingId = elementIds.get(element);
			if (existingId !== void 0 && existingId !== id) throw new Error("Base UI: A trigger element cannot be registered under multiple IDs in PopupTriggerMap.");
			const previousElement = this.idMap.get(id);
			if (previousElement !== void 0 && previousElement !== element) elementIds.delete(previousElement);
			elementIds.set(element, id);
		}
		this.idMap.set(id, element);
	}
	/**
	* Removes the trigger element with the given ID.
	*/
	delete(id) {
		{
			const element = this.idMap.get(id);
			if (element !== void 0) devElementIdsByMap?.get(this)?.delete(element);
		}
		this.idMap.delete(id);
	}
	/**
	* Whether the given element is registered as a trigger.
	*/
	hasElement(element) {
		for (const registered of this.idMap.values()) if (registered === element) return true;
		return false;
	}
	/**
	* Whether there is a registered trigger element matching the given predicate.
	*/
	hasMatchingElement(predicate) {
		for (const element of this.idMap.values()) if (predicate(element)) return true;
		return false;
	}
	/**
	* Returns the trigger element associated with the given ID, or undefined if no such element exists.
	*/
	getById(id) {
		return this.idMap.get(id);
	}
	/**
	* Returns an iterable of all registered trigger entries, where each entry is a tuple of [id, element].
	*/
	entries() {
		return this.idMap.entries();
	}
	/**
	* Returns an iterable of all registered trigger elements.
	*/
	elements() {
		return this.idMap.values();
	}
	/**
	* Returns the number of registered trigger elements.
	*/
	get size() {
		return this.idMap.size;
	}
};
// node_modules/@base-ui/utils/fastHooks.mjs
var hooks = [];
var currentInstance = void 0;
function getInstance() {
	return currentInstance;
}
function register(hook) {
	hooks.push(hook);
}
/**
* Wraps a component function to enable performance optimizations for internal hooks.
*
* **Performance Optimization:**
* Components wrapped with `fastComponent` have access to a shared "instance" context that enables
* specialized hook implementations to batch operations and reduce overhead. The wrapper creates a
* stable instance object that persists across renders, sets it as the current context, calls
* registered hooks before and after rendering, then clears the context. The primary benefit is
* with `useStore`, where multiple store subscriptions within the same component are collapsed into
* a single `useSyncExternalStore` subscription per store, significantly reducing re-render overhead.
* This optimization is only active on React 19+; on earlier versions `useStore` falls back to a
* separate subscription per call.
*
* **Requirements:**
* - The component function should follow standard React component patterns
* - `useStore` calls must keep a stable order and count across renders, as batched hooks are
*   matched by call index
* - Do not rely on the instance context outside of specialized hooks
*
* @param fn - The component function to wrap
* @returns A wrapped component with the same signature as the input function
*
* @example
* ```tsx
* // Wrapping a component to enable optimized useStore batching
* export const TooltipRoot = fastComponent(function TooltipRoot(props) {
*   // These useStore calls share a single subscription
*   const open = useStore(store, (state) => state.open);
*   const disabled = useStore(store, (state) => state.disabled);
*   const value = useStore(store, (state) => state.value);
*   // ...
* });
* ```
*/
function fastComponent(fn) {
	const FastComponent = (props, forwardedRef) => {
		const instance = useRefWithInit(createInstance).current;
		let result;
		try {
			currentInstance = instance;
			for (const hook of hooks) hook.before(instance);
			result = fn(props, forwardedRef);
			for (const hook of hooks) hook.after(instance);
			instance.didInitialize = true;
		} finally {
			currentInstance = void 0;
		}
		return result;
	};
	FastComponent.displayName = fn.displayName || fn.name;
	return FastComponent;
}
/**
* Wraps a component function with ref forwarding to enable performance optimizations for internal hooks.
*
* This is a convenience wrapper that combines `fastComponent` with `React.forwardRef`, enabling
* both performance optimizations and proper ref forwarding. See `fastComponent` for details on
* the performance benefits.
*
* @param fn - The component function that accepts props and a forwarded ref
* @returns A wrapped component with ref forwarding enabled
*
* @example
* ```tsx
* // Wrapping a component with ref forwarding and optimized hooks
* export const TooltipTrigger = fastComponentRef(function TooltipTrigger(
*   props,
*   forwardedRef
* ) {
*   const store = useContext(TooltipContext);
*   const open = useStore(store, (state) => state.open);
*   // ... component logic with ref
*   return <button ref={forwardedRef} {...props} />;
* });
* ```
*/
function fastComponentRef(fn) {
	return /*#__PURE__*/ import_react.forwardRef(fastComponent(fn));
}
function createInstance() {
	return { didInitialize: false };
}
// node_modules/@base-ui/utils/store/useStore.mjs
var import_shim = require_shim();
var import_with_selector = require_with_selector();
var useStoreImplementation = isReactVersionAtLeast(19) ? useStoreFast : useStoreLegacy;
function useStore(store, selector, a1, a2, a3) {
	return useStoreImplementation(store, selector, a1, a2, a3);
}
function useStoreR19(store, selector, a1, a2, a3) {
	const getSelection = import_react.useCallback(() => selector(store.getSnapshot(), a1, a2, a3), [
		store,
		selector,
		a1,
		a2,
		a3
	]);
	return (0, import_shim.useSyncExternalStore)(store.subscribe, getSelection, getSelection);
}
register({
	before(instance) {
		instance.syncIndex = 0;
		if (!instance.didInitialize) {
			instance.syncTick = 1;
			instance.syncHooks = [];
			instance.didChangeStore = true;
			instance.getSnapshot = () => {
				let didChange = false;
				for (let i = 0; i < instance.syncHooks.length; i += 1) {
					const hook = instance.syncHooks[i];
					const value = hook.selector(hook.store.state, hook.a1, hook.a2, hook.a3);
					if (!Object.is(hook.value, value)) {
						didChange = true;
						hook.value = value;
					}
				}
				if (didChange) instance.syncTick += 1;
				return instance.syncTick;
			};
		}
	},
	after(instance) {
		if (instance.syncHooks.length > 0) {
			if (instance.didChangeStore) {
				instance.didChangeStore = false;
				instance.subscribe = (onStoreChange) => {
					const stores = /* @__PURE__ */ new Set();
					for (const hook of instance.syncHooks) stores.add(hook.store);
					const unsubscribes = [];
					for (const store of stores) unsubscribes.push(store.subscribe(onStoreChange));
					return () => {
						for (const unsubscribe of unsubscribes) unsubscribe();
					};
				};
			}
			(0, import_shim.useSyncExternalStore)(instance.subscribe, instance.getSnapshot, instance.getSnapshot);
		}
	}
});
function useStoreFast(store, selector, a1, a2, a3) {
	const instance = getInstance();
	if (!instance) return useStoreR19(store, selector, a1, a2, a3);
	const index = instance.syncIndex;
	instance.syncIndex += 1;
	let hook;
	if (!instance.didInitialize) {
		hook = {
			store,
			selector,
			a1,
			a2,
			a3,
			value: selector(store.getSnapshot(), a1, a2, a3)
		};
		instance.syncHooks.push(hook);
	} else {
		hook = instance.syncHooks[index];
		if (hook.store !== store || hook.selector !== selector || !Object.is(hook.a1, a1) || !Object.is(hook.a2, a2) || !Object.is(hook.a3, a3)) {
			if (hook.store !== store) instance.didChangeStore = true;
			hook.store = store;
			hook.selector = selector;
			hook.a1 = a1;
			hook.a2 = a2;
			hook.a3 = a3;
			hook.value = selector(store.getSnapshot(), a1, a2, a3);
		}
	}
	return hook.value;
}
function useStoreLegacy(store, selector, a1, a2, a3) {
	return (0, import_with_selector.useSyncExternalStoreWithSelector)(store.subscribe, store.getSnapshot, store.getSnapshot, (state) => selector(state, a1, a2, a3));
}
// node_modules/@base-ui/utils/store/Store.mjs
/**
* A data store implementation that allows subscribing to state changes and updating the state.
* It uses an observer pattern to notify subscribers when the state changes.
*/
var Store = class {
	/**
	* Creates a store with the given initial state, constructing the class it is called on.
	* Calling it on a generic base class (e.g. `ReactStore.create(...)`) constructs that
	* class but degrades the inferred instance type to `Store`; use `new` there instead.
	*/
	static create(state) {
		return new this(state);
	}
	/**
	* The current state of the store.
	* This property is updated immediately when the state changes as a result of calling {@link setState}, {@link update}, or {@link set}.
	* To subscribe to state changes, use the {@link useState} method. The value returned by {@link useState} is updated after the component renders (similarly to React's useState).
	* The values can be used directly (to avoid subscribing to the store) in effects or event handlers.
	*
	* Do not modify properties in state directly. Instead, use the provided methods to ensure proper state management and listener notification.
	*/
	constructor(state) {
		this.state = state;
		this.listeners = /* @__PURE__ */ new Set();
		this.updateTick = 0;
	}
	/**
	* Registers a listener that will be called whenever the store's state changes.
	*
	* @param fn The listener function to be called on state changes.
	* @returns A function to unsubscribe the listener.
	*/
	subscribe = (fn) => {
		this.listeners.add(fn);
		return () => {
			this.listeners.delete(fn);
		};
	};
	/**
	* Returns the current state of the store.
	*/
	getSnapshot = () => {
		return this.state;
	};
	/**
	* Updates the entire store's state and notifies all registered listeners.
	*
	* @param newState The new state to set for the store.
	*/
	setState(newState) {
		if (this.state === newState) return;
		this.state = newState;
		this.updateTick += 1;
		const currentTick = this.updateTick;
		for (const listener of this.listeners) {
			if (currentTick !== this.updateTick) return;
			listener(newState);
		}
	}
	/**
	* Merges the provided changes into the current state and notifies listeners if there are changes.
	* Each value must match its state key. Pass an exact known subset rather than a broad
	* `Partial<State>`, which may contain `undefined` for required state fields.
	*
	* @param changes An object containing the changes to apply to the current state.
	*/
	update(changes) {
		for (const key in changes) if (!Object.is(this.state[key], changes[key])) {
			this.setState({
				...this.state,
				...changes
			});
			return;
		}
	}
	/**
	* Sets a specific key in the store's state to a new value and notifies listeners if the value has changed.
	*
	* @param key The key in the store's state to update.
	* @param value The new value to set for the specified key.
	*/
	set(key, value) {
		if (!Object.is(this.state[key], value)) this.setState({
			...this.state,
			[key]: value
		});
	}
	/**
	* Gives the state a new reference and updates all registered listeners.
	*/
	notifyAll() {
		const newState = { ...this.state };
		this.setState(newState);
	}
	use(selector, a1, a2, a3) {
		return useStore(this, selector, a1, a2, a3);
	}
};
// node_modules/@base-ui/utils/store/ReactStore.mjs
/**
* A Store that supports controlled state keys, non-reactive values and provides utility methods for React.
*/
var ReactStore = class extends Store {
	/**
	* Creates a new ReactStore instance.
	*
	* @param state Initial state of the store.
	* @param context Non-reactive context values.
	* @param selectors Optional selectors for use with `useState`.
	*/
	constructor(state, context = {}, selectors) {
		super(state);
		this.context = context;
		this.selectors = selectors;
	}
	/**
	* Non-reactive values such as refs, callbacks, etc.
	*/
	/**
	* Synchronizes a single external value into the store.
	*
	* Note that the while the value in `state` is updated immediately, the value returned
	* by `useState` is updated before the next render (similarly to React's `useState`).
	*/
	useSyncedValue(key, value) {
		import_react.useDebugValue(key);
		const store = this;
		useIsoLayoutEffect(() => {
			if (store.state[key] !== value) store.set(key, value);
		}, [
			store,
			key,
			value
		]);
	}
	/**
	* Synchronizes a single external value into the store and
	* cleans it up (sets to `undefined`) on unmount.
	*
	* Note that the while the value in `state` is updated immediately, the value returned
	* by `useState` is updated before the next render (similarly to React's `useState`).
	*/
	useSyncedValueWithCleanup(key, value) {
		const store = this;
		useIsoLayoutEffect(() => {
			if (store.state[key] !== value) store.set(key, value);
			return () => {
				store.set(key, void 0);
			};
		}, [
			store,
			key,
			value
		]);
	}
	/**
	* Synchronizes multiple external values into the store.
	* Each value must match its state key. Pass an exact known subset rather than a broad
	* `Partial<State>`, which may contain `undefined` for required state fields.
	*
	* Note that the while the values in `state` are updated immediately, the values returned
	* by `useState` are updated before the next render (similarly to React's `useState`).
	*
	* @param statePart An exact subset of state fields to synchronize. Unknown keys are not accepted.
	*/
	useSyncedValues(statePart) {
		const store = this;
		{
			import_react.useDebugValue(statePart, (p) => Object.keys(p));
			const keys = import_react.useRef(Object.keys(statePart)).current;
			const nextKeys = Object.keys(statePart);
			if (keys.length !== nextKeys.length || keys.some((key, index) => key !== nextKeys[index])) console.error("ReactStore.useSyncedValues expects the same prop keys on every render. Keys should be stable.");
		}
		const dependencies = Object.values(statePart);
		useIsoLayoutEffect(() => {
			store.update(statePart);
		}, [store, ...dependencies]);
	}
	/**
	* Registers a controllable prop pair (`controlled`, `defaultValue`) for a specific key. If `controlled`
	* is non-undefined, the store's state at `key` is updated to match `controlled`.
	*/
	useControlledProp(key, controlled) {
		import_react.useDebugValue(key);
		const store = this;
		const isControlled = controlled !== void 0;
		useIsoLayoutEffect(() => {
			if (isControlled && !Object.is(store.state[key], controlled)) store.setState({
				...store.state,
				[key]: controlled
			});
		}, [
			store,
			key,
			controlled,
			isControlled
		]);
		{
			const cache = this.controlledValues ??= /* @__PURE__ */ new Map();
			if (!cache.has(key)) cache.set(key, isControlled);
			const previouslyControlled = cache.get(key);
			if (previouslyControlled !== void 0 && previouslyControlled !== isControlled) console.error(`A component is changing the ${previouslyControlled ? "" : "un"}controlled state of ${key.toString()} to be ${previouslyControlled ? "un" : ""}controlled. Elements should not switch from uncontrolled to controlled (or vice versa).`);
		}
	}
	/** Gets the current value from the store using a selector with the provided key.
	*
	* @param key Key of the selector to use.
	*/
	select(key, a1, a2, a3) {
		const selector = this.selectors[key];
		return selector(this.state, a1, a2, a3);
	}
	/**
	* Returns a value from the store's state using a selector function.
	* Used to subscribe to specific parts of the state.
	* This methods causes a rerender whenever the selected state changes.
	*
	* @param key Key of the selector to use.
	*/
	useState(key, a1, a2, a3) {
		import_react.useDebugValue(key);
		return useStore(this, this.selectors[key], a1, a2, a3);
	}
	/**
	* Wraps a function with `useStableCallback` to ensure it has a stable reference
	* and assigns it to the context.
	*
	* @param key Key of the event callback. Must be a function in the context.
	* @param fn Function to assign.
	*/
	useContextCallback(key, fn) {
		import_react.useDebugValue(key);
		const stableFunction = useStableCallback(fn ?? NOOP);
		this.context[key] = stableFunction;
	}
	/**
	* Returns a stable setter function for a specific key in the store's state.
	* It's commonly used to pass as a ref callback to React elements.
	*
	* @param key Key of the state to set.
	*/
	useStateSetter(key) {
		const ref = import_react.useRef(void 0);
		if (ref.current === void 0) ref.current = (value) => {
			this.set(key, value);
		};
		return ref.current;
	}
	/**
	* Observes changes derived from the store's selectors and calls the listener when the selected value changes.
	*
	* @param key Key of the selector to observe.
	* @param listener Listener function called when the selector result changes.
	*/
	observe(selector, listener) {
		let selectFn;
		if (typeof selector === "function") selectFn = selector;
		else selectFn = this.selectors[selector];
		let prevValue = selectFn(this.state);
		listener(prevValue, prevValue, this);
		return this.subscribe((nextState) => {
			const nextValue = selectFn(nextState);
			if (!Object.is(prevValue, nextValue)) {
				const oldValue = prevValue;
				prevValue = nextValue;
				listener(nextValue, oldValue, this);
			}
		});
	}
};
// node_modules/@base-ui/react/floating-ui-react/components/FloatingRootStore.mjs
var selectors$1 = {
	open: (state) => state.open,
	transitionStatus: (state) => state.transitionStatus,
	domReferenceElement: (state) => state.domReferenceElement,
	referenceElement: (state) => state.positionReference ?? state.referenceElement,
	floatingElement: (state) => state.floatingElement,
	floatingId: (state) => state.floatingId
};
var FloatingRootStore = class extends ReactStore {
	constructor(options) {
		const { syncOnly, nested, onOpenChange, triggerElements, ...initialState } = options;
		super({
			...initialState,
			positionReference: initialState.referenceElement,
			domReferenceElement: initialState.referenceElement
		}, {
			onOpenChange,
			dataRef: { current: {} },
			events: createEventEmitter(),
			nested,
			triggerElements
		}, selectors$1);
		this.syncOnly = syncOnly;
	}
	/**
	* Syncs the event used by hover logic to distinguish hover-open from click-like interaction.
	*/
	syncOpenEvent = (newOpen, event) => {
		if (!newOpen || !this.state.open || event != null && isClickLikeEvent(event)) this.context.dataRef.current.openEvent = newOpen ? event : void 0;
	};
	/**
	* Runs the root-owned side effects for an open state change.
	*/
	dispatchOpenChange = (newOpen, eventDetails) => {
		this.syncOpenEvent(newOpen, eventDetails.event);
		const details = {
			open: newOpen,
			reason: eventDetails.reason,
			nativeEvent: eventDetails.event,
			nested: this.context.nested,
			triggerElement: eventDetails.trigger
		};
		this.context.events.emit("openchange", details);
	};
	/**
	* Emits the `openchange` event through the internal event emitter and calls the `onOpenChange` handler with the provided arguments.
	*
	* @param newOpen The new open state.
	* @param eventDetails Details about the event that triggered the open state change.
	*/
	setOpen = (newOpen, eventDetails) => {
		if (this.syncOnly) {
			this.context.onOpenChange?.(newOpen, eventDetails);
			return;
		}
		this.dispatchOpenChange(newOpen, eventDetails);
		this.context.onOpenChange?.(newOpen, eventDetails);
	};
};
// node_modules/@base-ui/react/utils/popups/store.mjs
/**
* State common to all popup stores.
*/
function createInitialPopupStoreState(triggerElements, floatingId, nested = false) {
	return {
		open: false,
		openProp: void 0,
		mounted: false,
		transitionStatus: void 0,
		floatingRootContext: new FloatingRootStore({
			open: false,
			transitionStatus: void 0,
			floatingElement: null,
			referenceElement: null,
			triggerElements,
			floatingId,
			syncOnly: true,
			nested,
			onOpenChange: void 0
		}),
		floatingId,
		triggerCount: 0,
		preventUnmountingOnClose: false,
		payload: void 0,
		activeTriggerId: null,
		activeTriggerElement: null,
		openedWithoutTrigger: false,
		triggerIdProp: void 0,
		popupElement: null,
		positionerElement: null,
		activeTriggerProps: EMPTY_OBJECT,
		inactiveTriggerProps: EMPTY_OBJECT,
		popupProps: EMPTY_OBJECT
	};
}
var activeTriggerIdSelector = (state) => state.triggerIdProp ?? state.activeTriggerId;
var openSelector = (state) => state.openProp ?? state.open;
var popupIdSelector = (state) => {
	return (state.popupElement?.id ?? state.floatingId) || void 0;
};
function triggerOwnsOpenPopup(state, triggerId) {
	return triggerId !== void 0 && openSelector(state) && activeTriggerIdSelector(state) === triggerId;
}
function triggerOwnsOpenPopupOrIsOnlyTrigger(state, triggerId) {
	if (triggerOwnsOpenPopup(state, triggerId)) return true;
	return triggerId !== void 0 && openSelector(state) && activeTriggerIdSelector(state) == null && !state.openedWithoutTrigger && state.triggerCount === 1;
}
var popupStoreSelectors = {
	open: openSelector,
	mounted: (state) => state.mounted,
	transitionStatus: (state) => openSelector(state) && !state.mounted ? "starting" : state.transitionStatus,
	floatingRootContext: (state) => state.floatingRootContext,
	triggerCount: (state) => state.triggerCount,
	preventUnmountingOnClose: (state) => state.preventUnmountingOnClose,
	payload: (state) => state.payload,
	activeTriggerId: activeTriggerIdSelector,
	activeTriggerElement: (state) => state.mounted ? state.activeTriggerElement : null,
	popupId: popupIdSelector,
	/**
	* Whether the trigger with the given ID was used to open the popup.
	*/
	isTriggerActive: (state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId,
	/**
	* Whether the popup is open and was activated by a trigger with the given ID.
	*/
	isOpenedByTrigger: (state, triggerId) => triggerOwnsOpenPopup(state, triggerId),
	/**
	* Whether the popup is mounted and was activated by a trigger with the given ID.
	*/
	isMountedByTrigger: (state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId && state.mounted,
	triggerProps: (state, isActive) => isActive ? state.activeTriggerProps : state.inactiveTriggerProps,
	/**
	* Popup id for the trigger that currently owns the open popup.
	*/
	triggerPopupId: (state, triggerId) => triggerOwnsOpenPopupOrIsOnlyTrigger(state, triggerId) ? popupIdSelector(state) : void 0,
	popupProps: (state) => state.popupProps,
	popupElement: (state) => state.popupElement,
	positionerElement: (state) => state.positionerElement
};
/**
* Store members a detached handle-backed trigger reads or invokes for trigger registration and data
* forwarding. `set`/`update` are included only for trigger-count and trigger-data bookkeeping; on a
* detached (inert) store they are intentionally no-ops, so a write through them is not guaranteed to
* be durable. Component handle-store views Pick these from their concrete store (preserving its
* context and selectors) and add any component-specific trigger-invoked members such as `setOpen`.
*/
/**
* The subset of a popup store that trigger registration and data forwarding rely on. Narrow enough
* that an inert store can be passed while detached.
*/
// node_modules/@base-ui/react/utils/popups/usePopupHandleStore.mjs
/**
* Reads the store currently exposed by a popup handle and subscribes to store-pointer changes.
* Detached triggers use this to follow a handle as a root attaches or detaches: while no root is
* attached, the handle exposes its fallback store; once a root attaches, subscribers re-render and
* read from the live root store.
*
* Returns `undefined` when no handle is provided so callers can fall back to their root context.
*
* @param handle The popup handle to read from, or `undefined` when the trigger is not handle-bound.
*/
function usePopupHandleStore(handle) {
	const subscribe = import_react.useCallback((listener) => {
		if (handle === void 0) return NOOP;
		return handle.subscribeStore(listener);
	}, [handle]);
	const getSnapshot = import_react.useCallback(() => {
		return handle === void 0 ? void 0 : handle.store;
	}, [handle]);
	return (0, import_shim.useSyncExternalStore)(subscribe, getSnapshot, () => handle?.serverStore);
}
// node_modules/@base-ui/react/dialog/portal/DialogPortalContext.mjs
var DialogPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
DialogPortalContext.displayName = "DialogPortalContext";
function useDialogPortalContext() {
	const value = import_react.useContext(DialogPortalContext);
	if (value === void 0) throw new Error("Base UI: <Dialog.Portal> is missing.");
	return value;
}
var COMPOSITE_KEYS = /* @__PURE__ */ new Set([
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"Home",
	"End"
]);
// node_modules/@base-ui/react/dialog/popup/DialogPopupCssVars.mjs
var DialogPopupCssVars_exports = /* @__PURE__ */ __exportAll({ nestedDialogs: () => nestedDialogs });
/**
* Indicates how many dialogs are nested within.
* @type {number}
*/
var nestedDialogs = "--nested-dialogs";
// node_modules/@base-ui/react/dialog/popup/DialogPopupDataAttributes.mjs
var DialogPopupDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed$2,
	endingStyle: () => endingStyle$2,
	nested: () => nested$1,
	nestedDialogOpen: () => nestedDialogOpen$1,
	open: () => open$2,
	startingStyle: () => startingStyle$2
});
/**
* Present when the dialog is open.
*/
var open$2 = open$3;
/**
* Present when the dialog is closed.
*/
var closed$2 = closed$3;
/**
* Present when the dialog begins animating in.
*/
var startingStyle$2 = startingStyle$3;
/**
* Present when the dialog is animating out.
*/
var endingStyle$2 = endingStyle$3;
/**
* Present when the dialog is nested within another dialog.
*/
var nested$1 = "data-nested";
/**
* Present when the dialog has other open dialogs nested within it.
*/
var nestedDialogOpen$1 = "data-nested-dialog-open";
// node_modules/@base-ui/react/dialog/utils/stateAttributesMapping.mjs
/**
* Shared by `Dialog.Popup` and `Dialog.Viewport`, whose states have the same shape.
* `nested` is not mapped: unmapped `true` booleans already render as `data-nested`.
*/
var dialogStateAttributesMapping = {
	...popupStateMapping,
	...transitionStatusMapping,
	nestedDialogOpen(value) {
		return value ? { [nestedDialogOpen$1]: "" } : null;
	}
};
// node_modules/@base-ui/react/dialog/popup/DialogPopup.mjs
/**
* A container for the dialog contents.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogPopup = /*#__PURE__*/ import_react.forwardRef(function DialogPopup(componentProps, forwardedRef) {
	const { render, className, style, finalFocus, initialFocus, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const descriptionElementId = store.useState("descriptionElementId");
	const disablePointerDismissal = store.useState("disablePointerDismissal");
	const floatingRootContext = store.useState("floatingRootContext");
	const rootPopupProps = store.useState("popupProps");
	const modal = store.useState("modal");
	const mounted = store.useState("mounted");
	const nested = store.useState("nested");
	const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
	const open = store.useState("open");
	const openMethod = store.useState("openMethod");
	const titleElementId = store.useState("titleElementId");
	const transitionStatus = store.useState("transitionStatus");
	const role = store.useState("role");
	const floatingId = floatingRootContext.useState("floatingId");
	useDialogPortalContext();
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	const resolvedInitialFocus = initialFocus === void 0 ? createDefaultInitialFocus(store.context.popupRef) : initialFocus;
	const nestedDialogOpen = nestedOpenDialogCount > 0;
	const setPopupElement = store.useStateSetter("popupElement");
	const element = useRenderElement("div", componentProps, {
		state: {
			open,
			nested,
			transitionStatus,
			nestedDialogOpen
		},
		props: [
			rootPopupProps,
			{
				id: floatingId,
				"aria-labelledby": titleElementId,
				"aria-describedby": descriptionElementId,
				role,
				...FOCUSABLE_POPUP_PROPS,
				hidden: !mounted,
				onKeyDown(event) {
					if (COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
				},
				style: { [nestedDialogs]: nestedOpenDialogCount }
			},
			elementProps
		],
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement
		],
		stateAttributesMapping: dialogStateAttributesMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingRootContext,
		openInteractionType: openMethod,
		disabled: !mounted,
		closeOnFocusOut: !disablePointerDismissal,
		initialFocus: resolvedInitialFocus,
		returnFocus: finalFocus,
		modal: modal !== false,
		restoreFocus: "popup",
		children: element
	});
});
DialogPopup.displayName = "DialogPopup";
// node_modules/@base-ui/utils/inertValue.mjs
function inertValue(value) {
	if (isReactVersionAtLeast(19)) return value;
	return value ? "true" : void 0;
}
// node_modules/@base-ui/react/utils/InternalBackdrop.mjs
/**
* @internal
*/
var InternalBackdrop = /*#__PURE__*/ import_react.forwardRef(function InternalBackdrop(props, ref) {
	const { cutout, ...otherProps } = props;
	let clipPath;
	if (cutout) {
		const rect = cutout.getBoundingClientRect();
		clipPath = `polygon(0% 0%,100% 0%,100% 100%,0% 100%,0% 0%,${rect.left}px ${rect.top}px,${rect.left}px ${rect.bottom}px,${rect.right}px ${rect.bottom}px,${rect.right}px ${rect.top}px,${rect.left}px ${rect.top}px)`;
	}
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		ref,
		role: "presentation",
		"data-base-ui-inert": "",
		...otherProps,
		style: {
			position: "fixed",
			inset: 0,
			userSelect: "none",
			WebkitUserSelect: "none",
			clipPath
		}
	});
});
InternalBackdrop.displayName = "InternalBackdrop";
// node_modules/@base-ui/react/dialog/portal/DialogPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogPortal = /*#__PURE__*/ import_react.forwardRef(function DialogPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	const store = useDialogRootContext();
	const mounted = store.useState("mounted");
	const modal = store.useState("modal");
	const open = store.useState("open");
	if (!(mounted || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DialogPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(FloatingPortal, {
			ref: forwardedRef,
			...portalProps,
			children: [mounted && modal === true && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
				ref: store.context.internalBackdropRef,
				inert: inertValue(!open)
			}), props.children]
		})
	});
});
DialogPortal.displayName = "DialogPortal";
// node_modules/@base-ui/utils/useScrollLock.mjs
var originalHtmlStyles = {};
var originalBodyStyles = {};
var originalHtmlScrollBehavior = "";
function getViewportScroller(html, body) {
	return isOverflowElement(html) ? html : body;
}
function isPageScrollLocked(win, html, body) {
	return /hidden|clip/.test(win.getComputedStyle(getViewportScroller(html, body)).overflowY);
}
function hasInsetScrollbars(referenceElement) {
	if (typeof document === "undefined") return false;
	const doc = ownerDocument(referenceElement);
	return getWindow(doc).innerWidth - doc.documentElement.clientWidth > 0;
}
function supportsStableScrollbarGutter(referenceElement) {
	if (!(typeof CSS !== "undefined" && CSS.supports && CSS.supports("scrollbar-gutter", "stable")) || typeof document === "undefined") return false;
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const scrollContainer = getViewportScroller(html, body);
	const originalScrollContainerOverflowY = scrollContainer.style.overflowY;
	const originalHtmlStyleGutter = html.style.scrollbarGutter;
	html.style.scrollbarGutter = "stable";
	scrollContainer.style.overflowY = "scroll";
	const before = scrollContainer.offsetWidth;
	scrollContainer.style.overflowY = "hidden";
	const after = scrollContainer.offsetWidth;
	scrollContainer.style.overflowY = originalScrollContainerOverflowY;
	html.style.scrollbarGutter = originalHtmlStyleGutter;
	return before === after;
}
function preventScrollOverlayScrollbars(referenceElement) {
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const elementToLock = getViewportScroller(html, body);
	const originalElementToLockStyles = {
		overflowY: elementToLock.style.overflowY,
		overflowX: elementToLock.style.overflowX
	};
	Object.assign(elementToLock.style, {
		overflowY: "hidden",
		overflowX: "hidden"
	});
	return () => {
		Object.assign(elementToLock.style, originalElementToLockStyles);
	};
}
function preventScrollInsetScrollbars(referenceElement) {
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const win = getWindow(html);
	let scrollTop = 0;
	let scrollLeft = 0;
	let updateGutterOnly = false;
	const resizeFrame = AnimationFrame.create();
	if (webkit && (win.visualViewport?.scale ?? 1) !== 1) return () => {};
	function lockScroll() {
		const htmlStyles = win.getComputedStyle(html);
		const bodyStyles = win.getComputedStyle(body);
		const scrollbarGutterValue = (htmlStyles.scrollbarGutter || "").includes("both-edges") ? "stable both-edges" : "stable";
		scrollTop = html.scrollTop;
		scrollLeft = html.scrollLeft;
		originalHtmlStyles = {
			scrollbarGutter: html.style.scrollbarGutter,
			overflowY: html.style.overflowY,
			overflowX: html.style.overflowX
		};
		originalHtmlScrollBehavior = html.style.scrollBehavior;
		originalBodyStyles = {
			position: body.style.position,
			height: body.style.height,
			width: body.style.width,
			boxSizing: body.style.boxSizing,
			overflowY: body.style.overflowY,
			overflowX: body.style.overflowX,
			scrollBehavior: body.style.scrollBehavior
		};
		const isScrollableY = html.scrollHeight > html.clientHeight;
		const isScrollableX = html.scrollWidth > html.clientWidth;
		const hasConstantOverflowY = htmlStyles.overflowY === "scroll" || bodyStyles.overflowY === "scroll";
		const hasConstantOverflowX = htmlStyles.overflowX === "scroll" || bodyStyles.overflowX === "scroll";
		const scrollbarWidth = Math.max(0, win.innerWidth - body.clientWidth);
		const scrollbarHeight = Math.max(0, win.innerHeight - body.clientHeight);
		const marginY = parseFloat(bodyStyles.marginTop) + parseFloat(bodyStyles.marginBottom);
		const marginX = parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight);
		const elementToLock = getViewportScroller(html, body);
		updateGutterOnly = supportsStableScrollbarGutter(referenceElement);
		if (updateGutterOnly) {
			html.style.scrollbarGutter = scrollbarGutterValue;
			elementToLock.style.overflowY = "hidden";
			elementToLock.style.overflowX = "hidden";
			return;
		}
		Object.assign(html.style, {
			scrollbarGutter: scrollbarGutterValue,
			overflowY: "hidden",
			overflowX: "hidden"
		});
		if (isScrollableY || hasConstantOverflowY) html.style.overflowY = "scroll";
		if (isScrollableX || hasConstantOverflowX) html.style.overflowX = "scroll";
		Object.assign(body.style, {
			position: "relative",
			height: marginY || scrollbarHeight ? `calc(100dvh - ${marginY + scrollbarHeight}px)` : "100dvh",
			width: marginX || scrollbarWidth ? `calc(100vw - ${marginX + scrollbarWidth}px)` : "100vw",
			boxSizing: "border-box",
			overflowY: "hidden",
			overflowX: "hidden",
			scrollBehavior: "unset"
		});
		body.scrollTop = scrollTop;
		body.scrollLeft = scrollLeft;
		html.setAttribute("data-base-ui-scroll-locked", "");
		html.style.scrollBehavior = "unset";
	}
	function cleanup() {
		Object.assign(html.style, originalHtmlStyles);
		Object.assign(body.style, originalBodyStyles);
		if (!updateGutterOnly) {
			html.scrollTop = scrollTop;
			html.scrollLeft = scrollLeft;
			html.removeAttribute("data-base-ui-scroll-locked");
			html.style.scrollBehavior = originalHtmlScrollBehavior;
		}
	}
	function handleResize() {
		cleanup();
		resizeFrame.request(lockScroll);
	}
	lockScroll();
	const unsubscribeResize = addEventListener(win, "resize", handleResize);
	return () => {
		resizeFrame.cancel();
		cleanup();
		if (typeof win.removeEventListener === "function") unsubscribeResize();
	};
}
var ScrollLocker = class {
	lockCount = 0;
	restore = null;
	timeoutLock = Timeout.create();
	timeoutUnlock = Timeout.create();
	acquire(referenceElement) {
		this.lockCount += 1;
		if (this.lockCount === 1 && this.restore === null) this.timeoutLock.start(0, () => this.lock(referenceElement));
		return this.release;
	}
	release = () => {
		this.lockCount -= 1;
		if (this.lockCount === 0 && this.restore) this.timeoutUnlock.start(0, this.unlock);
	};
	unlock = () => {
		if (this.lockCount === 0 && this.restore) {
			this.restore?.();
			this.restore = null;
		}
	};
	lock(referenceElement) {
		if (this.lockCount === 0 || this.restore !== null) return;
		const doc = ownerDocument(referenceElement);
		const html = doc.documentElement;
		const body = doc.body;
		const win = getWindow(html);
		if (isPageScrollLocked(win, html, body)) {
			const observer = new win.MutationObserver(() => {
				if (isPageScrollLocked(win, html, body)) return;
				observer.disconnect();
				this.restore = null;
				this.lock(referenceElement);
			});
			const options = { attributes: true };
			observer.observe(html, options);
			observer.observe(body, options);
			this.restore = () => observer.disconnect();
			return;
		}
		const hasOverlayScrollbars = ios || !hasInsetScrollbars(referenceElement);
		this.restore = hasOverlayScrollbars ? preventScrollOverlayScrollbars(referenceElement) : preventScrollInsetScrollbars(referenceElement);
	}
};
var SCROLL_LOCKER = new ScrollLocker();
/**
* Locks the scroll of the document when enabled.
*
* @param enabled - Whether to enable the scroll lock.
* @param referenceElement - Element to use as a reference for lock calculations.
*/
function useScrollLock(enabled = true, referenceElement = null) {
	useIsoLayoutEffect(() => {
		if (!enabled) return;
		return SCROLL_LOCKER.acquire(referenceElement);
	}, [enabled, referenceElement]);
}
// node_modules/@base-ui/react/dialog/root/useDialogRoot.mjs
function DialogInteractions({ store, parentContext, isDrawer }) {
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const disablePointerDismissal = store.useState("disablePointerDismissal");
	const modal = store.useState("modal");
	const popupElement = store.useState("popupElement");
	const floatingRootContext = store.useState("floatingRootContext");
	const [ownNestedOpenDialogs, setOwnNestedOpenDialogs] = import_react.useState(0);
	const [ownNestedOpenDrawers, setOwnNestedOpenDrawers] = import_react.useState(0);
	const isTopmost = ownNestedOpenDialogs === 0;
	const dismiss = useDismiss(floatingRootContext, {
		outsidePressEvent() {
			if (store.context.internalBackdropRef.current || store.context.backdropRef.current) return "intentional";
			return {
				mouse: modal === "trap-focus" ? "sloppy" : "intentional",
				touch: "sloppy"
			};
		},
		outsidePress(event) {
			if (!store.context.outsidePressEnabledRef.current) return false;
			if ("button" in event && event.button !== 0) return false;
			if ("touches" in event) {
				if (event.type === "touchend") {
					if (event.changedTouches.length !== 1 || event.touches.length !== 0) return false;
				} else if (event.touches.length !== 1) return false;
			}
			const target = getTarget(event);
			if (isTopmost && !disablePointerDismissal) {
				if (modal) {
					const internalBackdrop = store.context.internalBackdropRef.current;
					const backdrop = store.context.backdropRef.current;
					return internalBackdrop || backdrop ? internalBackdrop === target || backdrop === target || contains(target, popupElement) && !target?.hasAttribute("data-base-ui-portal") : true;
				}
				return true;
			}
			return false;
		},
		escapeKey: isTopmost
	});
	useScrollLock(open && modal === true, popupElement);
	store.useContextCallback("onNestedDialogOpen", (dialogCount, drawerCount) => {
		if (!store.select("open") && !store.select("mounted")) return;
		setOwnNestedOpenDialogs(dialogCount);
		setOwnNestedOpenDrawers(drawerCount);
	});
	useIsoLayoutEffect(() => {
		if (!open && !mounted) {
			setOwnNestedOpenDialogs(0);
			setOwnNestedOpenDrawers(0);
		}
	}, [open, mounted]);
	useIsoLayoutEffect(() => {
		if (parentContext?.onNestedDialogOpen) {
			if (open) parentContext.onNestedDialogOpen(ownNestedOpenDialogs + 1, ownNestedOpenDrawers + (isDrawer ? 1 : 0));
		}
		return () => {
			if (parentContext?.onNestedDialogOpen && open) parentContext.onNestedDialogOpen(0, 0);
		};
	}, [
		isDrawer,
		open,
		ownNestedOpenDialogs,
		ownNestedOpenDrawers,
		parentContext
	]);
	usePopupInteractionProps(store, {
		activeTriggerProps: dismiss.reference,
		inactiveTriggerProps: dismiss.trigger,
		popupProps: dismiss.floating,
		nestedOpenDialogCount: ownNestedOpenDialogs,
		nestedOpenDrawerCount: ownNestedOpenDrawers
	});
	return null;
}
// node_modules/@base-ui/react/utils/NullStore.mjs
/**
* A `ReactStore` whose state never changes.
*
* Useful for fallback stores that need to support normal store reads while detached from the
* component that owns real state. Context values may still contain mutable refs or maps.
*/
var NullStore = class extends ReactStore {
	setState(_newState) {}
	update(_changes) {}
	set(_key, _value) {}
	notifyAll() {}
};
// node_modules/@base-ui/react/dialog/store/DialogStore.mjs
var selectors = {
	...popupStoreSelectors,
	modal: (state) => state.modal,
	nested: (state) => state.nested,
	nestedOpenDialogCount: (state) => state.nestedOpenDialogCount,
	nestedOpenDrawerCount: (state) => state.nestedOpenDrawerCount,
	disablePointerDismissal: (state) => state.disablePointerDismissal,
	openMethod: (state) => state.openMethod,
	descriptionElementId: (state) => state.descriptionElementId,
	titleElementId: (state) => state.titleElementId,
	viewportElement: (state) => state.viewportElement,
	role: (state) => state.role
};
/**
* The subset of `DialogStore` that detached handle-backed triggers rely on. Both the real
* `DialogStore` and the inert fallback store satisfy it, so a trigger can read from whichever
* store the handle currently exposes.
*/
var DialogStore = class extends ReactStore {
	constructor(initialState, floatingId, nested) {
		const triggerElements = new PopupTriggerMap();
		const state = createInitialState(initialState, triggerElements, floatingId, nested);
		super(state, createInitialContext(triggerElements), selectors);
	}
	setOpen = (nextOpen, eventDetails) => {
		eventDetails.preventUnmountOnClose = () => {
			this.set("preventUnmountingOnClose", true);
		};
		if (!nextOpen && eventDetails.trigger == null && this.state.activeTriggerId != null) eventDetails.trigger = this.state.activeTriggerElement ?? void 0;
		this.context.onOpenChange?.(nextOpen, eventDetails);
		if (eventDetails.isCanceled) return;
		this.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
		this.update(createPopupOpenState(this.state, nextOpen, eventDetails.trigger));
	};
};
/**
* Creates the inert fallback store used by detached handle-backed triggers while no
* `Dialog.Root` is attached. It preserves a dialog-specific trigger registry in context so
* detached triggers can register before migrating to the live root store.
*/
function createNullDialogStore() {
	const triggerElements = new PopupTriggerMap();
	return new NullStore(Object.freeze(createInitialState(void 0, triggerElements)), Object.freeze(createInitialContext(triggerElements)), selectors);
}
function createInitialState(initialState, triggerElements, floatingId, nested = false) {
	return {
		...createInitialPopupStoreState(triggerElements, floatingId, nested),
		modal: true,
		disablePointerDismissal: false,
		viewportElement: null,
		descriptionElementId: void 0,
		titleElementId: void 0,
		openMethod: null,
		nested: false,
		nestedOpenDialogCount: 0,
		nestedOpenDrawerCount: 0,
		role: "dialog",
		...initialState
	};
}
function createInitialContext(triggerElements) {
	return {
		popupRef: /*#__PURE__*/ import_react.createRef(),
		backdropRef: /*#__PURE__*/ import_react.createRef(),
		internalBackdropRef: /*#__PURE__*/ import_react.createRef(),
		outsidePressEnabledRef: { current: true },
		triggerElements,
		onOpenChange: void 0,
		onOpenChangeComplete: void 0
	};
}
// node_modules/@base-ui/react/dialog/root/useRenderDialogRoot.mjs
function useRenderDialogRoot(mode, props) {
	const { children, open: openProp, defaultOpen = false, onOpenChange, onOpenChangeComplete, disablePointerDismissal: disablePointerDismissalProp = false, modal: modalProp = true, actionsRef, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null } = props;
	const isDrawer = mode === "drawer";
	const isAlertDialog = mode === "alert-dialog";
	const modal = isAlertDialog ? true : modalProp;
	const disablePointerDismissal = isAlertDialog || disablePointerDismissalProp;
	const role = isAlertDialog ? "alertdialog" : "dialog";
	const parentStore = useDialogRootContext(true);
	const rootState = {
		modal,
		disablePointerDismissal,
		nested: parentStore != null,
		role
	};
	const store = usePopupRootStore((floatingId, floatingNested) => new DialogStore({
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp,
		...rootState
	}, floatingId, floatingNested), true);
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useSyncedValues(rootState);
	store.useContextCallback("onOpenChange", onOpenChange);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const payload = store.useState("payload");
	usePopupRootSync(store, open);
	useImplicitActiveTrigger(store);
	const { forceUnmount } = useOpenStateTransitions(open, store);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: () => store.setOpen(false, createChangeEventDetails(imperativeAction))
	}), [forceUnmount, store]);
	const shouldRenderInteractions = open || mounted || handle != null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(DialogRootContext.Provider, {
		value: store,
		children: [
			handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
				handle,
				store
			}),
			shouldRenderInteractions && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DialogInteractions, {
				store,
				parentContext: parentStore?.context,
				isDrawer
			}),
			typeof children === "function" ? children({ payload }) : children
		]
	});
}
// node_modules/@base-ui/react/dialog/root/DialogRoot.mjs
/**
* Groups all parts of the dialog.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogRoot = fastComponent(function DialogRoot(props) {
	return useRenderDialogRoot("dialog", props);
});
DialogRoot.displayName = "DialogRoot";
// node_modules/@base-ui/react/dialog/viewport/DialogViewport.mjs
/**
* A positioning container for the dialog popup that can be made scrollable.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogViewport = /*#__PURE__*/ import_react.forwardRef(function DialogViewport(componentProps, forwardedRef) {
	const { render, className, style, children, ...elementProps } = componentProps;
	const keepMounted = useDialogPortalContext();
	const store = useDialogRootContext();
	const open = store.useState("open");
	const nested = store.useState("nested");
	const transitionStatus = store.useState("transitionStatus");
	const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
	const mounted = store.useState("mounted");
	const setViewportElement = store.useStateSetter("viewportElement");
	return useRenderElement("div", componentProps, {
		enabled: keepMounted || mounted,
		state: {
			open,
			nested,
			transitionStatus,
			nestedDialogOpen: nestedOpenDialogCount > 0
		},
		ref: [forwardedRef, setViewportElement],
		stateAttributesMapping: dialogStateAttributesMapping,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: { pointerEvents: !open ? "none" : void 0 },
			children
		}, elementProps]
	});
});
DialogViewport.displayName = "DialogViewport";
// node_modules/@base-ui/react/dialog/title/DialogTitle.mjs
/**
* A heading that labels the dialog.
* Renders an `<h2>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogTitle = /*#__PURE__*/ import_react.forwardRef(function DialogTitle(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const id = useBaseUiId(idProp);
	store.useSyncedValueWithCleanup("titleElementId", id);
	return useRenderElement("h2", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
DialogTitle.displayName = "DialogTitle";
// node_modules/@base-ui/utils/useEnhancedClickHandler.mjs
/**
* Provides a cross-browser way to determine the type of the pointer used to click.
* Safari and Firefox do not provide the PointerEvent to the click handler (they use MouseEvent) yet.
* Additionally, this implementation detects if the click was triggered by the keyboard.
*
* @param handler The function to be called when the button is clicked. The first parameter is the original event and the second parameter is the pointer type.
*/
function useEnhancedClickHandler(handler) {
	const lastClickInteractionTypeRef = import_react.useRef("");
	const handlePointerDown = import_react.useCallback((event) => {
		if (event.defaultPrevented) return;
		lastClickInteractionTypeRef.current = event.pointerType;
		handler(event, event.pointerType);
	}, [handler]);
	return {
		onClick: import_react.useCallback((event) => {
			if (event.detail === 0) {
				handler(event, "keyboard");
				return;
			}
			if ("pointerType" in event) handler(event, event.pointerType);
			else handler(event, lastClickInteractionTypeRef.current);
			lastClickInteractionTypeRef.current = "";
		}, [handler]),
		onPointerDown: handlePointerDown
	};
}
// node_modules/@base-ui/react/utils/useOpenInteractionType.mjs
function useOpenMethodTriggerProps(open, setOpenMethod) {
	const { onClick, onPointerDown } = useEnhancedClickHandler(useStableCallback((_, interactionType) => {
		if (!(typeof open === "function" ? open() : open)) setOpenMethod(interactionType || (ios ? "touch" : ""));
	}));
	return import_react.useMemo(() => ({
		onClick,
		onPointerDown
	}), [onClick, onPointerDown]);
}
// node_modules/@base-ui/react/dialog/trigger/DialogTrigger.mjs
/**
* A button that opens the dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogTrigger = fastComponentRef(function DialogTrigger(componentProps, forwardedRef) {
	const { render, className, style, disabled = false, nativeButton = true, id: idProp, payload, handle, ...elementProps } = componentProps;
	const dialogRootStore = useDialogRootContext(true);
	const store = usePopupHandleStore(handle) ?? dialogRootStore;
	if (!store) throw new Error("Base UI: <Dialog.Trigger> must be used within <Dialog.Root> or provided with a handle.");
	const thisTriggerId = useBaseUiId(idProp);
	const floatingContext = store.useState("floatingRootContext");
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const popupId = store.useState("triggerPopupId", thisTriggerId);
	const triggerElementRef = import_react.useRef(null);
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, { payload });
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const click = useClick(floatingContext);
	const interactionTypeProps = useOpenMethodTriggerProps(() => store.select("open"), (interactionType) => {
		store.set("openMethod", interactionType);
	});
	const state = {
		disabled,
		open: isOpenedByThisTrigger
	};
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	return useRenderElement("button", componentProps, {
		state,
		ref: [
			buttonRef,
			forwardedRef,
			registerTrigger,
			triggerElementRef
		],
		props: [
			click.reference,
			rootTriggerProps,
			interactionTypeProps,
			{
				[CLICK_TRIGGER_IDENTIFIER]: "",
				id: thisTriggerId,
				"aria-haspopup": "dialog",
				"aria-expanded": isOpenedByThisTrigger,
				"aria-controls": popupId
			},
			elementProps,
			getButtonProps
		],
		stateAttributesMapping: triggerOpenStateMapping
	});
});
DialogTrigger.displayName = "DialogTrigger";
// node_modules/@base-ui/react/dialog/store/DialogHandle.mjs
/**
* Controls a Dialog imperatively and associates detached `Dialog.Trigger` components with a
* `Dialog.Root`. Create one with `Dialog.createHandle()` and pass it to the `handle` prop of the
* root and of any triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var DialogHandle = class extends BasePopupHandle {
	constructor() {
		super(createNullDialogStore(), "Dialog", false);
	}
	/**
	* Opens the dialog, optionally associating it with a trigger.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the dialog. The trigger must be a matching
	* `Dialog.Trigger` with this handle passed as a prop. Pass `null` to open without associating any trigger.
	*/
	open(triggerId) {
		this.openByTrigger(triggerId);
	}
	/**
	* Opens the dialog with the given payload, without associating it with any trigger.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param payload Payload to set when opening the dialog. It is exposed to the root's render-prop children.
	*/
	openWithPayload(payload) {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn("Base UI: DialogHandle.openWithPayload() was called while no root using this handle is mounted. The call and its payload were ignored; mount a root with this handle before opening it imperatively.");
			return;
		}
		attachedStore.set("payload", payload);
		attachedStore.setOpen(true, createChangeEventDetails(imperativeAction));
	}
	/**
	* Closes the dialog.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	close() {
		this.closePopup();
	}
	/**
	* Whether the dialog is currently open. Returns `false` while no root is attached to the handle.
	*/
	get isOpen() {
		return this.attachedStore?.select("open") ?? false;
	}
};
/**
* Creates a new handle to connect a Dialog.Root with detached Dialog.Trigger components.
*/
function createDialogHandle() {
	return new DialogHandle();
}
// node_modules/@base-ui/react/dialog/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Backdrop: () => DialogBackdrop,
	Close: () => DialogClose,
	Description: () => DialogDescription,
	Handle: () => DialogHandle,
	Popup: () => DialogPopup,
	Portal: () => DialogPortal,
	Root: () => DialogRoot,
	Title: () => DialogTitle,
	Trigger: () => DialogTrigger,
	Viewport: () => DialogViewport,
	createHandle: () => createDialogHandle
});
// node_modules/@base-ui/react/dialog/backdrop/DialogBackdropDataAttributes.mjs
var DialogBackdropDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed$1,
	endingStyle: () => endingStyle$1,
	open: () => open$1,
	startingStyle: () => startingStyle$1
});
/**
* Present when the dialog is open.
*/
var open$1 = open$3;
/**
* Present when the dialog is closed.
*/
var closed$1 = closed$3;
/**
* Present when the dialog begins animating in.
*/
var startingStyle$1 = startingStyle$3;
/**
* Present when the dialog is animating out.
*/
var endingStyle$1 = endingStyle$3;
// node_modules/@base-ui/react/dialog/close/DialogCloseDataAttributes.mjs
var DialogCloseDataAttributes_exports = /* @__PURE__ */ __exportAll({ disabled: () => disabled$1 });
/**
* Present when the button is disabled.
*/
var disabled$1 = "data-disabled";
// node_modules/@base-ui/react/dialog/viewport/DialogViewportDataAttributes.mjs
var DialogViewportDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed,
	endingStyle: () => endingStyle,
	nested: () => nested,
	nestedDialogOpen: () => nestedDialogOpen,
	open: () => open,
	startingStyle: () => startingStyle
});
/**
* Present when the dialog is open.
*/
var open = open$3;
/**
* Present when the dialog is closed.
*/
var closed = closed$3;
/**
* Present when the dialog begins animating in.
*/
var startingStyle = startingStyle$3;
/**
* Present when the dialog is animating out.
*/
var endingStyle = endingStyle$3;
/**
* Present when the dialog is nested within another dialog.
*/
var nested = "data-nested";
/**
* Present when the dialog has other open dialogs nested within it.
*/
var nestedDialogOpen = "data-nested-dialog-open";
// node_modules/@base-ui/react/dialog/trigger/DialogTriggerDataAttributes.mjs
var DialogTriggerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	disabled: () => disabled,
	popupOpen: () => popupOpen
});
/**
* Present when the trigger is disabled.
*/
var disabled = "data-disabled";
/**
* Present when the corresponding dialog is open.
*/
var popupOpen = popupOpen$1;
export { index_parts_exports as Dialog, DialogBackdropDataAttributes_exports as DialogBackdropDataAttributes, DialogCloseDataAttributes_exports as DialogCloseDataAttributes, DialogPopupCssVars_exports as DialogPopupCssVariables, DialogPopupDataAttributes_exports as DialogPopupDataAttributes, DialogTriggerDataAttributes_exports as DialogTriggerDataAttributes, DialogViewportDataAttributes_exports as DialogViewportDataAttributes };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQ0EsU0FBZ0IsY0FBYyxNQUFNO0NBQ2xDLE9BQU8sTUFBTSxpQkFBaUI7QUFDaEM7O0FDQ0EsSUFBYSxvQkFBaUMsMkJBQU0sY0FBYyxNQUFTO0FBQ2hDLGtCQUFrQixjQUFjO0FBQzNFLFNBQWdCLHFCQUFxQixVQUFVO0NBQzdDLE1BQU0scUJBQWMsV0FBVyxpQkFBaUI7Q0FDaEQsSUFBSSxDQUFDLFlBQVksVUFBVSxRQUN6QixNQUFNLElBQUksTUFBOEMsMEZBQW9IO0NBRTlLLE9BQU87QUFDVDs7Ozs7QUNUQSxJQUFhQSxrQkFBZ0I7Ozs7QUFLN0IsSUFBYUMsZ0JBQWM7O0FDTjNCLElBQU0sZ0JBQWdCLEdBQ25CQyxrQkFBK0MsR0FDbEQ7QUFDQSxJQUFNLGNBQWMsR0FDakJDLGdCQUE2QyxHQUNoRDtBQUNBLElBQWEsMEJBQTBCLEVBQ3JDLGlCQUFpQixPQUFPO0NBQ3RCLElBQUksVUFBVSxZQUNaLE9BQU87Q0FFVCxJQUFJLFVBQVUsVUFDWixPQUFPO0NBRVQsT0FBTztBQUNULEVBQ0Y7Ozs7O0FDYkEsSUFBYUMsU0FBTzs7OztBQUtwQixJQUFhQyxXQUFTOzs7O0FBS3RCLElBQWFMLGtCQUFnQkU7Ozs7QUFLN0IsSUFBYUQsZ0JBQWNFOzs7O0FBSzNCLElBQWEsZUFBZTs7Ozs7QUN0QjVCLElBQWFHLGNBQVk7O0FDQ3pCLElBQU0sZUFBZSxHQUNsQkMsY0FBd0MsR0FDM0M7QUFLQSxJQUFNLGtCQUFrQixHQUNyQkMsU0FBaUMsR0FDcEM7QUFDQSxJQUFNLG9CQUFvQixHQUN2QkMsV0FBbUMsR0FDdEM7QUFDQSxJQUFNLHFCQUFxQixHQUN4QkMsZUFBeUMsR0FDNUM7QUFDQSxJQUFhLDBCQUEwQixFQUNyQyxLQUFLLE9BQU87Q0FDVixJQUFJLE9BQ0YsT0FBTztDQUVULE9BQU87QUFDVCxFQUNGO0FBU0EsSUFBYSxvQkFBb0I7Q0FDL0IsS0FBSyxPQUFPO0VBQ1YsSUFBSSxPQUNGLE9BQU87RUFFVCxPQUFPO0NBQ1Q7Q0FDQSxhQUFhLE9BQU87RUFDbEIsSUFBSSxPQUNGLE9BQU87RUFFVCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQWEsOEJBQThCO0NBQ3pDLEdBQUc7Q0FDSCxHQUFHO0FBQ0w7Ozs7Ozs7O0FDeENBLElBQWEsaUJBQThCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ2hILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxjQUFjLE9BQ2QsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sU0FBUyxNQUFNLFNBQVMsUUFBUTtDQUN0QyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FFeEMsTUFBTSxRQUFRO0VBQ1o7RUFDQSxrQkFIdUIsTUFBTSxTQUFTLGtCQUd2QjtDQUNqQjtDQUNBLE9BQU8saUJBQWlCLE9BQU8sZ0JBQWdCO0VBQzdDO0VBQ0EsS0FBSyxDQUFDLE1BQU0sUUFBUSxhQUFhLFlBQVk7RUFDN0Msd0JBQXdCO0VBQ3hCLE9BQU8sQ0FBQztHQUNOLE1BQU07R0FDTixRQUFRLENBQUM7R0FDVCxPQUFPO0lBQ0wsWUFBWTtJQUNaLGtCQUFrQjtHQUNwQjtFQUNGLEdBQUcsWUFBWTtFQUNmLFNBQVMsZUFBZSxDQUFDO0NBQzNCLENBQUM7QUFDSCxDQUFDO0FBQzBDLGVBQWUsY0FBYzs7Ozs7Ozs7QUM5QnhFLElBQWEsY0FBMkIsMkJBQU0sV0FBVyxTQUFTLFlBQVksZ0JBQWdCLGNBQWM7Q0FDMUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFdBQVcsT0FDWCxlQUFlLE1BQ2YsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sRUFDSixnQkFDQSxjQUNFLFVBQVU7RUFDWjtFQUNBLFFBQVE7Q0FDVixDQUFDO0NBQ0QsTUFBTSxRQUFRLEVBQ1osU0FDRjtDQUNBLFNBQVMsWUFBWSxPQUFPO0VBQzFCLElBQUksTUFDRixNQUFNLFFBQVEsT0FBTyx5QkFBeUJDLFlBQW9CLE1BQU0sV0FBVyxDQUFDO0NBRXhGO0NBQ0EsT0FBTyxpQkFBaUIsVUFBVSxnQkFBZ0I7RUFDaEQ7RUFDQSxLQUFLLENBQUMsY0FBYyxTQUFTO0VBQzdCLE9BQU87R0FBQyxFQUNOLFNBQVMsWUFDWDtHQUFHO0dBQWM7RUFBYztDQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxZQUFZLGNBQWM7Ozs7Ozs7O0FDckNyRSxJQUFhLG9CQUFpQywyQkFBTSxXQUFXLFNBQVMsa0JBQWtCLGdCQUFnQixjQUFjO0NBQ3RILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxJQUFJLFFBQ0osR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxLQUFLLFlBQVksTUFBTTtDQUM3QixNQUFNLDBCQUEwQix3QkFBd0IsRUFBRTtDQUMxRCxPQUFPLGlCQUFpQixLQUFLLGdCQUFnQjtFQUMzQyxLQUFLO0VBQ0wsT0FBTyxDQUFDLEVBQ04sR0FDRixHQUFHLFlBQVk7Q0FDakIsQ0FBQztBQUNILENBQUM7QUFDMEMsa0JBQWtCLGNBQWM7Ozs7Ozs7Ozs7OztBQ3BCM0UsU0FBUyxjQUFjO0NBQ3JCLElBQUksT0FBTyxjQUFjLGFBQ3ZCLE9BQU87RUFDTCxXQUFXO0VBQ1gsVUFBVTtFQUNWLGdCQUFnQjtDQUNsQjtDQUV5QztFQUN6QyxNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLFVBQVUsTUFBTSxRQUFRLE9BQU8sTUFBTSxHQUN2QyxPQUFPO0dBQ0wsV0FBVyxPQUFPLE9BQU8sS0FBSyxFQUM1QixPQUNBLGNBQ0ksR0FBRyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQ3JDLFVBQVUsT0FBTyxZQUFZLFVBQVUsWUFBWTtHQUNuRCxnQkFBZ0IsVUFBVSxrQkFBa0I7RUFDOUM7Q0FFSjtDQUNBLE9BQU87RUFDTCxXQUFXLFVBQVU7RUFDckIsVUFBVSxVQUFVLFlBQVk7RUFDaEMsZ0JBQWdCLFVBQVUsa0JBQWtCO0NBQzlDO0FBQ0Y7QUFDQSxJQUFNLEVBQ0osV0FDQSxVQUNBLG1CQUNFLFlBQVk7QUFDaEIsSUFBYSxpQkFBaUIsVUFBVSxZQUFZO0FBQ3BELElBQWEsZ0JBQWdCLFNBQVMsWUFBWTs7O0FDckNsRCxJQUFhLE1BQU0sWUFBWSxLQUFLLGFBQWEsS0FBSyxrQkFBa0IsY0FBYyxpQkFBaUI7O0FBR3ZHLElBQU0saUJBQWlCO0FBQ3ZCLElBQWEsVUFBVSxrQkFBa0Isa0JBQWtCLGVBQWUsU0FBUyxjQUFjOztBQUdqRyxJQUFhLE1BQU0sQ0FBQyxPQUFPLGNBQWMsV0FBVyxLQUFLO0FBR2xDLGNBQWMsV0FBVyxLQUFLO0FBR2hDLENBQUMsV0FBVyxxQkFBcUIsS0FBSyxhQUFhOztBQUd4RSxJQUFhLFFBQVEsT0FBTzs7O0FDaEI1QixJQUFhLFNBQVMsT0FBTyxRQUFRLGVBQWUsQ0FBQyxDQUFDLElBQUksV0FBVyw4QkFBOEI7QUFPOUUsQ0FBQyxVQUFVLGVBQWUsU0FBUyxTQUFTO0FBTzVDLENBQUMsVUFBVSxlQUFlLFNBQVMsT0FBTzs7Ozs7O0FDVC9ELElBQWEsWUFBWTs7O0FDUnpCLElBQWEsUUFBUSxpQkFBaUIsS0FBSyxjQUFjOztBQ0Z6RCxTQUFnQixVQUFVLE9BQU87Q0FDL0IsTUFBTSxlQUFlO0NBQ3JCLE1BQU0sZ0JBQWdCO0FBQ3hCO0FBQ0EsU0FBZ0IsYUFBYSxPQUFPO0NBQ2xDLE9BQU8saUJBQWlCO0FBQzFCO0FBR0EsU0FBZ0IsZUFBZSxPQUFPO0NBQ3BDLElBQUksTUFBTSxnQkFBZ0IsTUFBTSxNQUFNLFdBQ3BDLE9BQU87Q0FFVCxJQUFJQyxXQUF1QixNQUFNLGFBQy9CLE9BQU8sTUFBTSxTQUFTLFdBQVcsTUFBTSxZQUFZO0NBRXJELE9BQU8sTUFBTSxXQUFXLEtBQUssQ0FBQyxNQUFNO0FBQ3RDO0FBQ0EsU0FBZ0Isc0JBQXNCLE9BQU87Q0FDM0MsSUFBSUMsT0FDRixPQUFPO0NBRVQsT0FBTyxDQUFDRCxXQUF1QixNQUFNLFVBQVUsS0FBSyxNQUFNLFdBQVcsS0FJckUsTUFBTSxTQUFTLGlCQUFpQixNQUFNLFVBQVUsS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLGFBQWEsS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLGdCQUFnQixZQUFZQSxXQUF1QixNQUFNLFlBQVksTUFFcE0sTUFBTSxRQUFRLEtBQUssTUFBTSxTQUFTLEtBQUssTUFBTSxhQUFhLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxnQkFBZ0I7QUFDN0c7QUFDQSxTQUFnQix1QkFBdUIsYUFBYSxRQUFRO0NBRzFELE1BQU0sU0FBUyxDQUFDLFNBQVMsS0FBSztDQUM5QixJQUFJLENBQUMsUUFDSCxPQUFPLEtBQUssSUFBSSxNQUFTO0NBRTNCLE9BQU8sT0FBTyxTQUFTLFdBQVc7QUFDcEM7QUFDQSxTQUFnQixpQkFBaUIsT0FBTztDQUN0QyxNQUFNLE9BQU8sTUFBTTtDQUNuQixPQUFPLFNBQVMsV0FBVyxTQUFTLGVBQWUsU0FBUyxhQUFhLFNBQVM7QUFDcEY7O0FDMUNBLFNBQWdCLGNBQWMsS0FBSztDQUNqQyxJQUFJLFVBQVUsSUFBSTtDQUNsQixPQUFPLFNBQVMsWUFBWSxpQkFBaUIsTUFDM0MsVUFBVSxRQUFRLFdBQVc7Q0FFL0IsT0FBTztBQUNUO0FBQ0EsU0FBZ0IsU0FBUyxRQUFRLE9BQU87Q0FDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUNkLE9BQU87Q0FFVCxNQUFNLFdBQVcsTUFBTSxjQUFjO0NBR3JDLElBQUksT0FBTyxTQUFTLEtBQUssR0FDdkIsT0FBTztDQUlULElBQUksWUFBWSxhQUFhLFFBQVEsR0FBRztFQUN0QyxJQUFJLE9BQU87RUFDWCxPQUFPLE1BQU07R0FDWCxJQUFJLFdBQVcsTUFDYixPQUFPO0dBRVQsT0FBTyxLQUFLLGNBQWMsS0FBSztFQUNqQztDQUNGO0NBQ0EsT0FBTztBQUNUOzs7OztBQU9BLFNBQWdCLFFBQVEsTUFBTSxVQUFVO0NBQ3RDLElBQUksVUFBVTtDQUNkLE9BQU8sU0FBUztFQUNkLElBQUksVUFBVSxPQUFPLEtBQUssUUFBUSxRQUFRLFFBQVEsR0FDaEQsT0FBTztFQUVULFVBQVUsUUFBUSxnQkFBZ0IsUUFBUSxlQUFlLGFBQWEsT0FBTyxJQUFJLFFBQVEsT0FBTztDQUNsRztDQUNBLE9BQU87QUFDVDtBQUNBLFNBQWdCLFVBQVUsT0FBTztDQUMvQixJQUFJLGtCQUFrQixPQUdwQixPQUFPLE1BQU0sYUFBYSxDQUFDLENBQUMsTUFBTSxNQUFNO0NBSzFDLE9BQU8sTUFBTTtBQUNmOztBQ3pEQSxJQUFhLHNCQUFzQjs7QUNxQm5DLFNBQWdCLG9CQUFvQixPQUFPLE1BQU07Q0FDL0MsSUFBSSxRQUFRLE1BQ1YsT0FBTztDQUVULElBQUksa0JBQWtCLE9BQ3BCLE9BQU8sTUFBTSxhQUFhLENBQUMsQ0FBQyxTQUFTLElBQUk7Q0FJM0MsTUFBTSxhQUFhO0NBQ25CLE9BQU8sV0FBVyxVQUFVLFFBQVEsS0FBSyxTQUFTLFdBQVcsTUFBTTtBQUNyRTtBQUNBLFNBQWdCLGNBQWMsU0FBUztDQUNyQyxPQUFPLFFBQVEsUUFBUSxXQUFXO0FBQ3BDO0FBQ0EsU0FBZ0Isa0JBQWtCLFNBQVM7Q0FDekMsT0FBTyxjQUFjLE9BQU8sS0FBSyxRQUFRLDhIQUF5QjtBQUNwRTtBQUlBLFNBQWdCLG1CQUFtQixTQUFTO0NBQzFDLElBQUksQ0FBQyxTQUNILE9BQU87Q0FFVCxPQUFPLFFBQVEsYUFBYSxNQUFNLE1BQU0sY0FBYyxrQkFBa0IsT0FBTztBQUNqRjtBQWFBLFNBQWdCLHdCQUF3QixpQkFBaUI7Q0FDdkQsSUFBSSxDQUFDLGlCQUNILE9BQU87Q0FNVCxPQUFPLGdCQUFnQixxQ0FBZ0MsSUFBSSxrQkFBa0IsZ0JBQWdCLGNBQWMsMEJBQTBCLEtBQUs7QUFDNUk7Ozs7O0FDakVBLFNBQWdCLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxTQUFTO0NBQ2hFLE9BQU8saUJBQWlCLE1BQU0sVUFBVSxPQUFPO0NBQy9DLGFBQWE7RUFDWCxPQUFPLG9CQUFvQixNQUFNLFVBQVUsT0FBTztDQUNwRDtBQUNGOzs7OztBQ05BLFNBQWdCLGNBQWMsR0FBRyxVQUFVO0NBQ3pDLGFBQWE7RUFDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUssR0FBRztHQUMzQyxNQUFNLFVBQVUsU0FBUztHQUN6QixJQUFJLFNBQ0YsUUFBUTtFQUVaO0NBQ0Y7QUFDRjs7Ozs7OztBQ0ZBLFNBQWdCLGNBQWMsT0FBTztDQUNuQyxNQUFNLFNBQVMsZUFBZSxpQkFBaUIsS0FBSyxDQUFDLENBQUM7Q0FDdEQsT0FBTyxPQUFPO0NBR2QsbUJBQW1CLE9BQU8sTUFBTTtDQUNoQyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQixPQUFPO0NBQzlCLE1BQU0sU0FBUztFQUNiLFNBQVM7RUFDVCxNQUFNO0VBQ04sY0FBYztHQUNaLE9BQU8sVUFBVSxPQUFPO0VBQzFCO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7Ozs7OztBQ25CQSxJQUFNLFFBQVE7QUFDZCxJQUFJLFdBQVcsV0FBVztBQUMxQixJQUFNLFlBQU4sTUFBZ0I7Q0FTZCxZQUFZLENBQUM7Q0FDYixpQkFBaUI7Q0FDakIsU0FBUztDQUNULFVBQVU7Q0FDVixjQUFjO0NBQ2QsUUFBTyxjQUFhO0VBQ2xCLEtBQUssY0FBYztFQUNuQixNQUFNLG1CQUFtQixLQUFLO0VBQzlCLE1BQU0sd0JBQXdCLEtBQUs7RUFHbkMsS0FBSyxZQUFZLENBQUM7RUFDbEIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxVQUFVLEtBQUs7RUFDcEIsSUFBSSx3QkFBd0IsR0FDMUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGlCQUFpQixRQUFRLEtBQUssR0FDaEQsaUJBQWlCLEVBQUUsR0FBRyxTQUFTO0NBR3JDO0NBQ0EsUUFBUSxJQUFJO0VBQ1YsTUFBTSxLQUFLLEtBQUs7RUFDaEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxVQUFVLEtBQUssRUFBRTtFQUN0QixLQUFLLGtCQUFrQjtFQUt2QixNQUFNLGVBQXdELGFBQWEsMEJBQTBCLFdBQVcsdUJBQXVCO0VBQ3ZJLElBQUksQ0FBQyxLQUFLLGVBQWUsY0FBYztHQUNyQyxzQkFBc0IsS0FBSyxJQUFJO0dBQy9CLEtBQUssY0FBYztFQUNyQjtFQUNBLE9BQU87Q0FDVDtDQUNBLE9BQU8sSUFBSTtFQUNULE1BQU0sUUFBUSxLQUFLLEtBQUs7RUFDeEIsSUFBSSxRQUFRLEtBQUssU0FBUyxLQUFLLFVBQVUsUUFDdkM7RUFFRixJQUFJLEtBQUssVUFBVSxXQUFXLE1BQzVCO0VBRUYsS0FBSyxVQUFVLFNBQVM7RUFDeEIsS0FBSyxrQkFBa0I7Q0FDekI7QUFDRjtBQUNBLElBQUksWUFBWSxJQUFJLFVBQVU7QUFzQjlCLElBQWEsaUJBQWIsTUFBYSxlQUFlO0NBQzFCLE9BQU8sU0FBUztFQUNkLE9BQU8sSUFBSSxlQUFlO0NBQzVCO0NBQ0EsT0FBTyxRQUFRLElBQUk7RUFDakIsT0FBTyxVQUFVLFFBQVEsRUFBRTtDQUM3QjtDQUNBLE9BQU8sT0FBTyxJQUFJO0VBQ2hCLE9BQU8sVUFBVSxPQUFPLEVBQUU7Q0FDNUI7Q0FDQSxZQUFZOzs7O0NBS1osUUFBUSxJQUFJO0VBQ1YsS0FBSyxPQUFPO0VBQ1osS0FBSyxZQUFZLFVBQVUsY0FBYztHQUN2QyxLQUFLLFlBQVk7R0FDakIsR0FBRztFQUNMLENBQUM7Q0FDSDtDQUNBLGVBQWU7RUFDYixJQUFJLEtBQUssY0FBYyxPQUFPO0dBQzVCLFVBQVUsT0FBTyxLQUFLLFNBQVM7R0FDL0IsS0FBSyxZQUFZO0VBQ25CO0NBQ0Y7Q0FDQSxzQkFBc0I7RUFDcEIsT0FBTyxLQUFLO0NBQ2Q7QUFDRjs7OztBQUtBLFNBQWdCLG9CQUFvQjtDQUNsQyxNQUFNLFVBQVUsZUFBZSxlQUFlLE1BQU0sQ0FBQyxDQUFDO0NBQ3RELFdBQVcsUUFBUSxhQUFhO0NBQ2hDLE9BQU87QUFDVDs7QUNqSUEsSUFBTSxxQkFBcUI7Q0FDekIsVUFBVTtDQUNWLFVBQVU7Q0FDVixZQUFZO0NBQ1osUUFBUTtDQUNSLFNBQVM7Q0FDVCxPQUFPO0NBQ1AsUUFBUTtDQUNSLFFBQVE7QUFDVjtBQUNBLElBQWEsaUJBQWlCO0NBQzVCLEdBQUc7Q0FDSCxVQUFVO0NBQ1YsUUFBUTtDQUNSLEtBQUs7Q0FDTCxNQUFNO0FBQ1I7Q0FHRSxFQURBLEdBQUcsbUJBQ087Ozs7O0FDUlosSUFBYSxhQUEwQiwyQkFBTSxXQUFXLFNBQVMsV0FBVyxPQUFPLEtBQUs7Q0FDdEYsTUFBTSxDQUFDLE1BQU0sd0JBQWlCLFNBQVM7Q0FDdkMseUJBQXlCO0VBS3ZCLElBQUlFLGFBQW1DQyxRQUNyQyxRQUFRLFFBQVE7Q0FFcEIsR0FBRyxDQUFDLENBQUM7Q0FDTCxNQUFNLFlBQVk7RUFDaEIsVUFBVTtFQUVWO0NBQ0Y7Q0FDQSxPQUFvQiwwQ0FBSyxRQUFRO0VBQy9CLEdBQUc7RUFDRTtFQUNMLE9BQU87RUFDUCxlQUFlLE9BQU8sU0FBWTtFQUNsQyxHQUFHO0VBQ0gsNEJBQTRCO0NBQzlCLENBQUM7QUFDSCxDQUFDO0FBQzBDLFdBQVcsY0FBYzs7QUNrWXBFLFNBQWdCLGlCQUFpQixRQUFRO0NBQ3ZDLE9BQU8sT0FBTyxlQUFlLFlBQVksT0FBTyxlQUFlO0FBQ2pFO0FBQ0EsU0FBZ0IsaUJBQWlCLFNBQVMsU0FBUyxVQUFVQyxtQkFBaUIsT0FBTyxJQUFJLE1BQU07Q0FDN0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLGVBQWUsQ0FBQyxVQUFVLGlCQUFpQixNQUFNLEdBQ3hFLE9BQU87Q0FFVCxJQUFJLE9BQU8sUUFBUSxvQkFBb0IsWUFDckMsT0FBTyxRQUFRLGdCQUFnQjtDQUVqQyxPQUFPLE9BQU8sWUFBWSxVQUFVLE9BQU8sWUFBWTtBQUN6RDs7QUM3YUEsSUFBTSxxQkFBcUI7QUFDM0IsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxNQUFNLGVBQWUsUUFBUTtDQUM3QixJQUFJLGNBQ0YsT0FBTztDQUVULElBQUksUUFBUSxlQUNWLE9BQU8sUUFBUTtDQUVqQixNQUFNLFdBQVcsUUFBUSxZQUFZO0NBQ3JDLE9BQU8sYUFBYSxRQUFRLElBQUksU0FBUyxPQUFPO0FBQ2xEO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUztDQUNsQyxLQUFLLE1BQU0sU0FBUyxNQUFNLEtBQUssUUFBUSxRQUFRLEdBQzdDLElBQUksWUFBWSxLQUFLLE1BQU0sV0FDekIsT0FBTztDQUdYLE9BQU87QUFDVDtBQUNBLFNBQVMsMkJBQTJCLFNBQVMsU0FBUztDQUNwRCxNQUFNLFVBQVUsa0JBQWtCLE9BQU87Q0FDekMsT0FBTyxDQUFDLENBQUMsWUFBWSxZQUFZLFdBQVcsU0FBUyxTQUFTLE9BQU87QUFDdkU7QUFDQSxTQUFTLHFCQUFxQixTQUFTO0NBQ3JDLE1BQU0sV0FBVyxVQUFVLFlBQVksT0FBTyxJQUFJO0NBQ2xELE9BQU8sV0FBVyxRQUFRLFFBQVEsUUFBUSxrQkFBa0IsTUFBTSxhQUFhLGFBQWEsUUFBUSxpQkFBaUIsUUFBUSxZQUFZLFFBQVEsYUFBYSxNQUFNLGFBQWEsa0JBQWtCLFFBQVEsYUFBYSxNQUFNLGFBQWEsYUFBYSxhQUFhLGtCQUFrQixPQUFPLEtBQUssVUFBVSxhQUFhLFdBQVcsUUFBUSxTQUFTO0FBQ3hWO0FBQ0EsU0FBUyxtQkFBbUIsU0FBUztDQUNuQyxJQUFJLENBQUMscUJBQXFCLE9BQU8sS0FBSyxDQUFDLFFBQVEsZUFBZSxRQUFRLFFBQVEsV0FBVyxHQUN2RixPQUFPO0NBRVQsS0FBSyxJQUFJLFVBQVUsU0FBUyxTQUFTLFVBQVUsaUJBQWlCLE9BQU8sR0FBRztFQUN4RSxNQUFNLGFBQWEsWUFBWTtFQUMvQixNQUFNLFNBQVMsWUFBWSxPQUFPLE1BQU07RUFDeEMsSUFBSSxRQUFRLGFBQWEsT0FBTyxHQUM5QixPQUFPO0VBRVQsSUFBSSxjQUFjLFlBQVksT0FBTyxNQUFNLGFBQWEsQ0FBQyxRQUFRLFFBQVEsQ0FBQywyQkFBMkIsU0FBUyxPQUFPLEtBQUssUUFBUSxhQUFhLFFBQVEsS0FBSyxDQUFDLFVBQVUsQ0FBQyx3QkFBd0IsU0FBUyxVQUFVLEdBQ2pOLE9BQU87Q0FFWDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsd0JBQXdCLFNBQVMsWUFBWTtDQUNwRCxNQUFNLFNBQVNBLG1CQUFpQixPQUFPO0NBQ3ZDLElBQUksQ0FBQyxZQUNILE9BQU8saUJBQWlCLFNBQVMsTUFBTTtDQUV6QyxPQUFPLE9BQU8sWUFBWTtBQUM1QjtBQUNBLFNBQVMsWUFBWSxTQUFTO0NBQzVCLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLElBQUksV0FBVyxHQUFHO0VBQ2hCLE1BQU0sV0FBVyxZQUFZLE9BQU87RUFDcEMsSUFBSSxhQUFhLGFBQWEsYUFBYSxXQUFXLGFBQWEsV0FBVyxjQUFjLE9BQU8sS0FBSyxRQUFRLG1CQUM5RyxPQUFPO0NBRVg7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG1CQUFtQixTQUFTO0NBQ25DLElBQUksWUFBWSxPQUFPLE1BQU0sU0FDM0IsT0FBTztDQUVULE1BQU0sUUFBUTtDQUNkLE9BQU8sTUFBTSxTQUFTLFdBQVcsTUFBTSxTQUFTLEtBQUssUUFBUTtBQUMvRDtBQUNBLFNBQVMsZ0JBQWdCLFNBQVMsWUFBWTtDQUM1QyxNQUFNLFFBQVEsbUJBQW1CLE9BQU87Q0FDeEMsSUFBSSxDQUFDLE9BQ0gsT0FBTztDQUVULE1BQU0sZUFBZSxXQUFXLE1BQUssY0FBYTtFQUNoRCxNQUFNLFFBQVEsbUJBQW1CLFNBQVM7RUFDMUMsT0FBTyxPQUFPLFNBQVMsTUFBTSxRQUFRLE1BQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtDQUMxRSxDQUFDO0NBQ0QsSUFBSSxjQUNGLE9BQU8saUJBQWlCO0NBRTFCLE9BQU8sV0FBVyxNQUFLLGNBQWE7RUFDbEMsTUFBTSxRQUFRLG1CQUFtQixTQUFTO0VBQzFDLE9BQU8sT0FBTyxTQUFTLE1BQU0sUUFBUSxNQUFNLFNBQVMsTUFBTTtDQUM1RCxDQUFDLE1BQU07QUFDVDtBQUNBLFNBQVMsb0JBQW9CLFdBQVc7Q0FDdEMsSUFBSSxjQUFjLFNBQVMsS0FBSyxZQUFZLFNBQVMsTUFBTSxRQUFRO0VBQ2pFLE1BQU0sbUJBQW1CLFVBQVUsaUJBQWlCLEVBQ2xELFNBQVMsS0FDWCxDQUFDO0VBQ0QsSUFBSSxpQkFBaUIsU0FBUyxHQUM1QixPQUFPO0NBRVg7Q0FDQSxJQUFJLGNBQWMsU0FBUyxLQUFLLFVBQVUsWUFDeEMsT0FBTyxNQUFNLEtBQUssVUFBVSxXQUFXLFFBQVE7Q0FFakQsT0FBTyxNQUFNLEtBQUssVUFBVSxRQUFRO0FBQ3RDO0FBQ0EsU0FBUyxpQkFBaUIsV0FBVyxNQUFNO0NBQ3pDLG9CQUFvQixTQUFTLENBQUMsQ0FBQyxTQUFRLFVBQVM7RUFDOUMsSUFBSSxxQkFBcUIsS0FBSyxHQUM1QixLQUFLLEtBQUssS0FBSztFQUVqQixpQkFBaUIsT0FBTyxJQUFJO0NBQzlCLENBQUM7QUFDSDtBQUNBLFNBQVMsdUJBQXVCLFdBQVcsVUFBVSxNQUFNO0NBQ3pELG9CQUFvQixTQUFTLENBQUMsQ0FBQyxTQUFRLFVBQVM7RUFDOUMsSUFBSSxjQUFjLEtBQUssS0FBSyxNQUFNLFFBQVEsUUFBUSxHQUNoRCxLQUFLLEtBQUssS0FBSztFQUVqQix1QkFBdUIsT0FBTyxVQUFVLElBQUk7Q0FDOUMsQ0FBQztBQUNIO0FBQ0EsU0FBZ0IsV0FBVyxTQUFTO0NBQ2xDLE9BQU8sbUJBQW1CLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSztBQUNoRTtBQUNBLFNBQWdCLFVBQVUsV0FBVztDQUNuQyxNQUFNLGFBQWEsQ0FBQztDQUNwQixpQkFBaUIsV0FBVyxVQUFVO0NBQ3RDLE9BQU8sV0FBVyxPQUFPLGtCQUFrQjtBQUM3QztBQUNBLFNBQWdCLFNBQVMsV0FBVztDQUNsQyxNQUFNLGFBQWEsVUFBVSxTQUFTO0NBQ3RDLE9BQU8sV0FBVyxRQUFPLFlBQVcsWUFBWSxPQUFPLEtBQUssS0FBSyxnQkFBZ0IsU0FBUyxVQUFVLENBQUM7QUFDdkc7QUFDQSxTQUFTLGNBQWMsV0FBVyxLQUFLO0NBQ3JDLE1BQU0sT0FBTyxTQUFTLFNBQVM7Q0FDL0IsTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSSxRQUFRLEdBQ1Y7Q0FFRixNQUFNLFNBQVMsY0FBYyxjQUFjLFNBQVMsQ0FBQztDQUNyRCxNQUFNLFFBQVEsS0FBSyxRQUFRLE1BQU07Q0FHakMsT0FBTyxLQURXLFVBQVUsS0FBSyxRQUFRLElBQUksSUFBSSxNQUFNLElBQUksUUFBUTtBQUVyRTtBQUNBLFNBQWdCLGdCQUFnQixrQkFBa0I7Q0FDaEQsT0FBTyxjQUFjLGNBQWMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNuRTtBQUNBLFNBQWdCLG9CQUFvQixrQkFBa0I7Q0FDcEQsT0FBTyxjQUFjLGNBQWMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztBQUNwRTtBQXNCQSxTQUFnQixlQUFlLE9BQU8sV0FBVztDQUMvQyxNQUFNLG1CQUFtQixhQUFhLE1BQU07Q0FDNUMsTUFBTSxnQkFBZ0IsTUFBTTtDQUM1QixPQUFPLENBQUMsaUJBQWlCLENBQUMsU0FBUyxrQkFBa0IsYUFBYTtBQUNwRTtBQUNBLFNBQWdCLG1CQUFtQixXQUFXO0NBRTVDLFNBRGtDLFNBQ25CLENBQUMsQ0FBQyxTQUFRLFlBQVc7RUFDbEMsUUFBUSxRQUFRLFdBQVcsUUFBUSxhQUFhLFVBQVUsS0FBSztFQUMvRCxRQUFRLGFBQWEsWUFBWSxJQUFJO0NBQ3ZDLENBQUM7QUFDSDtBQUNBLFNBQWdCLGtCQUFrQixXQUFXO0NBQzNDLE1BQU0sV0FBVyxDQUFDO0NBQ2xCLHVCQUF1QixXQUFXLG1CQUFtQixRQUFRO0NBQzdELFNBQVMsU0FBUSxZQUFXO0VBQzFCLE1BQU0sV0FBVyxRQUFRLFFBQVE7RUFDakMsT0FBTyxRQUFRLFFBQVE7RUFDdkIsSUFBSSxVQUNGLFFBQVEsYUFBYSxZQUFZLFFBQVE7T0FFekMsUUFBUSxnQkFBZ0IsVUFBVTtDQUV0QyxDQUFDO0FBQ0g7O0FDaE1BLFNBQWdCLGdCQUFnQixPQUFPLElBQUksbUJBQW1CLE1BQU07Q0FFbEUsT0FEdUIsTUFBTSxRQUFPLFNBQVEsS0FBSyxhQUFhLEVBQzFDLENBQUMsQ0FBQyxTQUFRLFVBQVMsQ0FBQyxHQUFJLENBQUMsb0JBQW9CLE1BQU0sU0FBUyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUMsR0FBSSxHQUFHLGdCQUFnQixPQUFPLE1BQU0sSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzlKO0FBQ0EsU0FBZ0IsaUJBQWlCLE9BQU8sSUFBSTtDQUMxQyxJQUFJLGVBQWUsQ0FBQztDQUNwQixJQUFJLGtCQUFrQixNQUFNLE1BQUssU0FBUSxLQUFLLE9BQU8sRUFBRSxDQUFDLEVBQUU7Q0FDMUQsT0FBTyxpQkFBaUI7RUFDdEIsTUFBTSxjQUFjLE1BQU0sTUFBSyxTQUFRLEtBQUssT0FBTyxlQUFlO0VBQ2xFLGtCQUFrQixhQUFhO0VBQy9CLElBQUksYUFDRixlQUFlLGFBQWEsT0FBTyxXQUFXO0NBRWxEO0NBQ0EsT0FBTztBQUNUOztBQ2pCQSxTQUFnQixnQkFBZ0IsTUFBTTtDQUNwQyxPQUFPLGdCQUFnQjtBQUN6Qjs7QUNEQSxJQUFJLFFBQVE7QUFDWixTQUFnQixhQUFhLElBQUksVUFBVSxDQUFDLEdBQUc7Q0FDN0MsTUFBTSxFQUNKLGdCQUFnQixPQUNoQixPQUFPLE9BQ1AsZ0JBQ0U7Q0FDSixxQkFBcUIsS0FBSztDQUMxQixTQUFTLE9BQU87RUFDZCxJQUFJLGVBQWUsQ0FBQyxZQUFZLEdBQzlCO0VBRUYsSUFBSSxNQUFNLEVBQ1IsY0FDRixDQUFDO0NBQ0g7Q0FDQSxJQUFJLE1BQU07RUFDUixLQUFLO0VBQ0wsT0FBTztDQUNUO0NBQ0EsTUFBTSxlQUFlLHNCQUFzQixJQUFJO0NBQy9DLFFBQVE7Q0FDUixhQUFhO0VBQ1gsSUFBSSxVQUFVLGNBQWM7R0FDMUIscUJBQXFCLFlBQVk7R0FDakMsUUFBUTtFQUNWO0NBQ0Y7QUFDRjs7QUN6QkEsSUFBTSxhQUFhO0FBQ25CLElBQUksdUNBQXVCLElBQUksUUFBUTtBQUN2QyxJQUFJLDBDQUEwQixJQUFJLFFBQVE7QUFDMUMsSUFBSSxtQ0FBbUIsSUFBSSxRQUFRO0FBQ25DLElBQUksWUFBWTtBQUNoQixTQUFTLFdBQVcsTUFBTTtDQUN4QixJQUFJLENBQUMsTUFDSCxPQUFPO0NBRVQsT0FBTyxhQUFhLElBQUksSUFBSSxLQUFLLE9BQU8sV0FBVyxLQUFLLFVBQVU7QUFDcEU7QUFDQSxJQUFNLG1CQUFtQixRQUFRLFlBQVksUUFBUSxLQUFJLFdBQVU7Q0FDakUsSUFBSSxPQUFPLFNBQVMsTUFBTSxHQUN4QixPQUFPO0NBRVQsTUFBTSxrQkFBa0IsV0FBVyxNQUFNO0NBQ3pDLElBQUksT0FBTyxTQUFTLGVBQWUsR0FDakMsT0FBTztDQUVULE9BQU87QUFDVCxDQUFDLENBQUMsQ0FBQyxRQUFPLE1BQUssS0FBSyxJQUFJO0FBQ3hCLElBQU0sZ0JBQWUsWUFBVztDQUM5QixNQUFNLHVCQUFPLElBQUksSUFBSTtDQUNyQixRQUFRLFNBQVEsV0FBVTtFQUN4QixJQUFJLE9BQU87RUFDWCxPQUFPLFFBQVEsQ0FBQyxLQUFLLElBQUksSUFBSSxHQUFHO0dBQzlCLEtBQUssSUFBSSxJQUFJO0dBQ2IsT0FBTyxLQUFLO0VBQ2Q7Q0FDRixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsSUFBTSwwQkFBMEIsTUFBTSxjQUFjLGlCQUFpQjtDQUNuRSxNQUFNLFVBQVUsQ0FBQztDQUNqQixNQUFNLFFBQU8sV0FBVTtFQUNyQixJQUFJLENBQUMsVUFBVSxhQUFhLElBQUksTUFBTSxHQUNwQztFQUVGLE1BQU0sS0FBSyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVEsU0FBUTtHQUMxQyxJQUFJLFlBQVksSUFBSSxNQUFNLFVBQ3hCO0dBRUYsSUFBSSxhQUFhLElBQUksSUFBSSxHQUN2QixLQUFLLElBQUk7UUFFVCxRQUFRLEtBQUssSUFBSTtFQUVyQixDQUFDO0NBQ0g7Q0FDQSxLQUFLLElBQUk7Q0FDVCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLHVCQUF1QiwwQkFBMEIsTUFBTSxZQUFZLEVBQzFFLE9BQU8sUUFDTjtDQUNELE1BQU0sZ0JBQWdCLGdCQUFnQixNQUFNLHdCQUF3QjtDQUNwRSxNQUFNLGdCQUFnQixPQUFPLHVCQUF1QixNQUFNLGFBQWEsYUFBYSxHQUFHLElBQUksSUFBSSxhQUFhLENBQUMsSUFBSSxDQUFDO0NBQ2xILE1BQU0saUJBQWlCLENBQUM7Q0FDeEIsTUFBTSxpQkFBaUIsQ0FBQztDQUN4QixJQUFJLFlBQVk7RUFDZCxNQUFNLG1CQUFtQixnQkFBZ0IsTUFBTSxNQUFNLEtBQUssS0FBSyxpQkFBaUIsYUFBYSxDQUFDLENBQUM7RUFDL0YsTUFBTSxrQkFBa0IsY0FBYyxPQUFPLGdCQUFnQjtFQUU3RCx1QkFEOEMsTUFBTSxhQUFhLGVBQWUsR0FBRyxJQUFJLElBQUksZUFBZSxDQUM3RixDQUFDLENBQUMsU0FBUSxTQUFRO0dBQzdCLE1BQU0sT0FBTyxLQUFLLGFBQWEsYUFBYTtHQUM1QyxNQUFNLGdCQUFnQixTQUFTLFFBQVEsU0FBUztHQUNoRCxNQUFNLGdCQUFnQixxQkFBcUIsSUFBSSxJQUFJLEtBQUssS0FBSztHQUM3RCxxQkFBcUIsSUFBSSxNQUFNLFlBQVk7R0FDM0MsZUFBZSxLQUFLLElBQUk7R0FDeEIsSUFBSSxpQkFBaUIsS0FBSyxlQUN4Qix3QkFBd0IsSUFBSSxJQUFJO0dBRWxDLElBQUksQ0FBQyxlQUNILEtBQUssYUFBYSxlQUFlLE1BQU07RUFFM0MsQ0FBQztDQUNIO0NBQ0EsSUFBSSxNQUNGLGNBQWMsU0FBUSxTQUFRO0VBQzVCLE1BQU0sZUFBZSxpQkFBaUIsSUFBSSxJQUFJLEtBQUssS0FBSztFQUN4RCxpQkFBaUIsSUFBSSxNQUFNLFdBQVc7RUFDdEMsZUFBZSxLQUFLLElBQUk7RUFDeEIsSUFBSSxnQkFBZ0IsR0FDbEIsS0FBSyxhQUFhLFlBQVksRUFBRTtDQUVwQyxDQUFDO0NBRUgsYUFBYTtDQUNiLGFBQWE7RUFDWCxlQUFlLFNBQVEsWUFBVztHQUNoQyxNQUFNLGdCQUFnQixxQkFBcUIsSUFBSSxPQUFPLEtBQUssS0FBSztHQUNoRSxxQkFBcUIsSUFBSSxTQUFTLFlBQVk7R0FDOUMsSUFBSSxDQUFDLGNBQWM7SUFDakIsSUFBSSxDQUFDLHdCQUF3QixJQUFJLE9BQU8sR0FDdEMsUUFBUSxnQkFBZ0IsYUFBYTtJQUV2Qyx3QkFBd0IsT0FBTyxPQUFPO0dBQ3hDO0VBQ0YsQ0FBQztFQUNELElBQUksTUFDRixlQUFlLFNBQVEsWUFBVztHQUNoQyxNQUFNLGVBQWUsaUJBQWlCLElBQUksT0FBTyxLQUFLLEtBQUs7R0FDM0QsaUJBQWlCLElBQUksU0FBUyxXQUFXO0dBQ3pDLElBQUksQ0FBQyxhQUNILFFBQVEsZ0JBQWdCLFVBQVU7RUFFdEMsQ0FBQztFQUVILGFBQWE7RUFDYixJQUFJLENBQUMsV0FBVztHQUNkLHVDQUF1QixJQUFJLFFBQVE7R0FDbkMsMENBQTBCLElBQUksUUFBUTtHQUN0QyxtQ0FBbUIsSUFBSSxRQUFRO0VBQ2pDO0NBQ0Y7QUFDRjtBQUNBLFNBQWdCLFdBQVcsZUFBZSxVQUFVLENBQUMsR0FBRztDQUN0RCxNQUFNLEVBQ0osYUFBYSxPQUNiLE9BQU8sU0FDTDtDQUNKLE1BQU0sT0FBTyxjQUFjLGNBQWMsRUFBRSxDQUFDLENBQUM7Q0FDN0MsT0FBTyx1QkFBdUIsZUFBZSxNQUFNLFlBQVksRUFDN0QsS0FDRixDQUFDO0FBQ0g7O0FDMUhBLElBQWEsMkJBQTJCOzs7Ozs7O0FBNEJ4QyxJQUFhLHNCQUFzQjtDQUNqQyxVQUFVO0NBQ1YsVUFBVTtDQUNWLEtBQUs7Q0FDTCxNQUFNO0FBQ1I7O0FDckJBLElBQU0sZ0JBQTZCLDJCQUFNLGNBQWMsSUFBSTtBQUNoQixjQUFjLGNBQWM7QUFDdkUsSUFBYSxzQ0FBK0IsV0FBVyxhQUFhO0FBQ3BFLElBQU0sT0FBTyxnQkFBZ0IsUUFBUTtBQUNyQyxTQUFnQixzQkFBc0IsUUFBUSxDQUFDLEdBQUc7Q0FDaEQsTUFBTSxFQUNKLEtBQ0EsV0FBVyxlQUNYLGlCQUFpQixjQUNqQixpQkFDRTtDQUNKLE1BQU0sV0FBVyxNQUFNO0NBRXZCLE1BQU0sbUJBRGdCLGlCQUNlLENBQUMsRUFBRTtDQUN4QyxNQUFNLENBQUMsa0JBQWtCLG9DQUE2QixTQUFTLElBQUk7Q0FDbkUsTUFBTSxDQUFDLFlBQVksOEJBQXVCLFNBQVMsSUFBSTtDQUN2RCxNQUFNLG1CQUFtQixtQkFBa0IsU0FBUTtFQUNqRCxJQUFJLFNBQVMsTUFJWCxjQUFjLElBQUk7Q0FFdEIsQ0FBQztDQUNELE1BQU0sNEJBQXFCLE9BQU8sSUFBSTtDQUN0Qyx5QkFBeUI7RUFFdkIsSUFBSSxrQkFBa0IsTUFBTTtHQUMxQixJQUFJLGFBQWEsU0FBUztJQUN4QixhQUFhLFVBQVU7SUFDdkIsY0FBYyxJQUFJO0lBQ2xCLG9CQUFvQixJQUFJO0dBQzFCO0dBQ0E7RUFDRjtFQUNBLE1BQU0scUJBQXFCLGtCQUFrQixPQUFPLGFBQWEsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhLG9CQUFvQixTQUFTO0VBQzdJLElBQUkscUJBQXFCLE1BQU07R0FDN0IsSUFBSSxhQUFhLFNBQVM7SUFDeEIsYUFBYSxVQUFVO0lBQ3ZCLGNBQWMsSUFBSTtJQUNsQixvQkFBb0IsSUFBSTtHQUMxQjtHQUNBO0VBQ0Y7RUFDQSxJQUFJLGFBQWEsWUFBWSxtQkFBbUI7R0FDOUMsYUFBYSxVQUFVO0dBQ3ZCLGNBQWMsSUFBSTtHQUNsQixvQkFBb0IsaUJBQWlCO0VBQ3ZDO0NBQ0YsR0FBRyxDQUFDLGVBQWUsZ0JBQWdCLENBQUM7Q0FDcEMsTUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU8sZ0JBQWdCO0VBQzVELEtBQUssQ0FBQyxLQUFLLGdCQUFnQjtFQUMzQixPQUFPLENBQUM7R0FDTixJQUFJO0lBQ0gsT0FBTztFQUNWLEdBQUcsWUFBWTtDQUNqQixDQUFDO0NBSUQsTUFBTSxnQkFBZ0Isb0JBQW9CLGdCQUE2QiwrQkFBUyxhQUFhLGVBQWUsZ0JBQWdCLElBQUk7Q0FDaEksT0FBTztFQUNMLE1BQU07RUFHTixRQUFxQiwyQkFBTSxlQUFlLGFBQWEsSUFBSSxjQUFjLE1BQU0sS0FBSztFQUNwRixTQUFTO0NBQ1g7QUFDRjs7Ozs7Ozs7OztBQVdBLElBQWEsaUJBQThCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ2hILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxVQUNBLFdBQ0EsaUJBQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sRUFDSixNQUFNLFlBQ04sUUFBUSxjQUNSLFNBQVMsa0JBQ1Asc0JBQXNCO0VBQ3hCO0VBQ0EsS0FBSztFQUNMO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxnQ0FBeUIsT0FBTyxJQUFJO0NBQzFDLE1BQU0sK0JBQXdCLE9BQU8sSUFBSTtDQUN6QyxNQUFNLCtCQUF3QixPQUFPLElBQUk7Q0FDekMsTUFBTSw4QkFBdUIsT0FBTyxJQUFJO0NBQ3hDLE1BQU0sQ0FBQyxtQkFBbUIscUNBQThCLFNBQVMsSUFBSTtDQUNyRSxNQUFNLHNDQUErQixPQUFPLEtBQUs7Q0FDakQsTUFBTSxRQUFRLG1CQUFtQjtDQUNqQyxNQUFNLE9BQU8sbUJBQW1CO0NBQ2hDLE1BQU0scUJBQXFCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsU0FBUyxrQkFBa0IsUUFBUSxDQUFDLENBQUM7Q0FHMUcsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLGNBQWMsT0FDakI7RUFNRixTQUFTLFFBQVEsT0FBTztHQUN0QixJQUFJLGNBQWMsTUFBTSxpQkFBaUIsZUFBZSxLQUFLLEdBQUc7SUFDOUQsSUFBSSxNQUFNLFNBQVMsV0FDYjtTQUFBLHVCQUF1QixTQUFTO01BQ2xDLGtCQUFrQixVQUFVO01BQzVCLHVCQUF1QixVQUFVO0tBQ25DO1dBQ0s7S0FDTCxtQkFBbUIsVUFBVTtLQUM3Qix1QkFBdUIsVUFBVTtJQUNuQztHQUNGO0VBQ0Y7RUFJQSxPQUFPLGNBQWMsaUJBQWlCLFlBQVksV0FBVyxTQUFTLElBQUksR0FBRyxpQkFBaUIsWUFBWSxZQUFZLFNBQVMsSUFBSSxDQUFDO0NBQ3RJLEdBQUcsQ0FBQyxZQUFZLEtBQUssQ0FBQztDQUN0Qix5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLGNBQWMsU0FBUyxRQUFRLENBQUMsdUJBQXVCLFNBQzFEO0VBSUYsa0JBQWtCLFVBQVU7RUFDNUIsdUJBQXVCLFVBQVU7Q0FDbkMsR0FBRyxDQUFDLE1BQU0sVUFBVSxDQUFDO0NBQ3JCLE1BQU0sa0NBQTJCLGVBQWU7RUFDOUM7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsSUFBSSxDQUFDLFVBQVUsQ0FBQztDQUNoQixPQUFvQix3REFBWSxVQUFVLEVBQ3hDLFVBQVUsQ0FBQyxlQUE0QiwyQ0FBTSxjQUFjLFVBQVU7RUFDbkUsT0FBTztFQUNQLFVBQVU7R0FBQyxzQkFBc0IsY0FBMkIsMENBQUssWUFBWTtJQUMzRSxhQUFhO0lBQ2IsS0FBSztJQUNMLFVBQVMsVUFBUztLQUNoQixJQUFJLGVBQWUsT0FBTyxVQUFVLEdBQ2xDLGdCQUFnQixTQUFTLE1BQU07VUFJL0Isb0JBRnFCLG9CQUFvQixrQkFBa0IsZUFBZSxJQUUvRCxDQUFDLEVBQUUsTUFBTTtJQUV4QjtHQUNGLENBQUM7R0FBRyxzQkFBc0IsY0FBMkIsMENBQUssUUFBUTtJQUNoRSxNQUFNO0lBQ04sYUFBYTtJQUNiLE9BQU87R0FDVCxDQUFDO0dBQUcsY0FBMkIsK0JBQVMsYUFBYSxVQUFVLFVBQVU7R0FBRyxzQkFBc0IsY0FBMkIsMENBQUssWUFBWTtJQUM1SSxhQUFhO0lBQ2IsS0FBSztJQUNMLFVBQVMsVUFBUztLQUNoQixJQUFJLGVBQWUsT0FBTyxVQUFVLEdBQ2xDLGVBQWUsU0FBUyxNQUFNO1VBQ3pCO01BR0wsZ0JBRnFCLG9CQUFvQixrQkFBa0IsZUFBZSxJQUUvRCxDQUFDLEVBQUUsTUFBTTtNQUNwQixJQUFJLG1CQUFtQixpQkFDckIsbUJBQW1CLGFBQWEsT0FBTyx5QkFBeUIsYUFBa0IsTUFBTSxXQUFXLENBQUM7S0FFeEc7SUFDRjtHQUNGLENBQUM7RUFBQztDQUNKLENBQUMsQ0FBQyxFQUNKLENBQUM7QUFDSCxDQUFDO0FBQzBDLGVBQWUsY0FBYzs7QUNsTnhFLFNBQWdCLHFCQUFxQjtDQUNuQyxNQUFNLHNCQUFNLElBQUksSUFBSTtDQUNwQixPQUFPO0VBQ0wsS0FBSyxPQUFPLE1BQU07R0FDaEIsSUFBSSxJQUFJLEtBQUssQ0FBQyxFQUFFLFNBQVEsYUFBWSxTQUFTLElBQUksQ0FBQztFQUNwRDtFQUNBLEdBQUcsT0FBTyxVQUFVO0dBQ2xCLElBQUksQ0FBQyxJQUFJLElBQUksS0FBSyxHQUNoQixJQUFJLElBQUksdUJBQU8sSUFBSSxJQUFJLENBQUM7R0FFMUIsSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDLElBQUksUUFBUTtFQUM3QjtFQUNBLElBQUksT0FBTyxVQUFVO0dBQ25CLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRSxPQUFPLFFBQVE7RUFDakM7Q0FDRjtBQUNGOztBQ1JBLElBQU0sc0JBQW1DLDJCQUFNLGNBQWMsSUFBSTtBQUN0QixvQkFBb0IsY0FBYztBQUM3RSxJQUFNLHNCQUFtQywyQkFBTSxjQUFjLElBQUk7QUFNdEIsb0JBQW9CLGNBQWM7QUFDN0UsSUFBYSw2Q0FBc0MsV0FBVyxtQkFBbUIsQ0FBQyxFQUFFLE1BQU07Ozs7QUFLMUYsSUFBYSxtQkFBa0IsaUJBQWdCO0NBQzdDLE1BQU0sMkJBQW9CLFdBQVcsbUJBQW1CO0NBQ3hELE9BQU8sZ0JBQWdCO0FBQ3pCOzs7Ozs7QUNyQkEsU0FBZ0IsV0FBVyxVQUFVO0NBQ25DLElBQUksWUFBWSxNQUNkLE9BQU87Q0FFVCxPQUFPLGFBQWEsV0FBVyxTQUFTLFVBQVU7QUFDcEQ7O0FDcUJBLFNBQVMsYUFBYSxPQUFPLHFCQUFxQjtDQUNoRCxNQUFNLE1BQU1DLFVBQVksVUFBVSxLQUFLLENBQUM7Q0FDeEMsSUFBSSxpQkFBaUIsSUFBSSxlQUN2QixPQUFPO0NBRVQsSUFBSSxpQkFBaUIsSUFBSSxZQUd2QixPQUFPLHVCQUF1QjtDQUVoQyxJQUFJLGlCQUFpQixPQUduQixPQUFPLE1BQU0sZ0JBQWdCLGVBQWUsS0FBSyxJQUFJLGFBQWEsdUJBQXVCO0NBRTNGLElBQUksYUFBYSxPQUNmLE9BQU87Q0FFVCxJQUFJLGlCQUFpQixJQUFJLFlBRXZCLE9BQU8sd0JBQXdCLE1BQU0sV0FBVyxJQUFJLGFBQWE7Q0FFbkUsT0FBTztBQUNUO0FBQ0EsSUFBTSxhQUFhO0FBQ25CLElBQUksNEJBQTRCLENBQUM7QUFDakMsU0FBUyw2Q0FBNkM7Q0FDcEQsNEJBQTRCLDBCQUEwQixRQUFPLFVBQVM7RUFDcEUsT0FBTyxNQUFNLE1BQU0sQ0FBQyxFQUFFO0NBQ3hCLENBQUM7QUFDSDtBQUNBLFNBQVMsNEJBQTRCLFNBQVM7Q0FDNUMsMkNBQTJDO0NBQzNDLElBQUksV0FBVyxZQUFZLE9BQU8sTUFBTSxRQUFRO0VBQzlDLDBCQUEwQixLQUFLLElBQUksUUFBUSxPQUFPLENBQUM7RUFDbkQsSUFBSSwwQkFBMEIsU0FBUyxZQUNyQyw0QkFBNEIsMEJBQTBCLE1BQU0sR0FBVztDQUUzRTtBQUNGO0FBQ0EsU0FBUyw4QkFBOEI7Q0FDckMsMkNBQTJDO0NBQzNDLE9BQU8sMEJBQTBCLDBCQUEwQixTQUFTLEVBQUUsRUFBRSxNQUFNO0FBQ2hGO0FBQ0EsU0FBUyx3QkFBd0IsV0FBVztDQUMxQyxJQUFJLENBQUMsV0FDSCxPQUFPO0NBRVQsSUFBSSxXQUFXLFNBQVMsR0FDdEIsT0FBTztDQUVULE9BQU8sU0FBUyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ25DO0FBQ0EsU0FBUyxlQUFlLHNCQUFzQjtDQUM1QyxJQUFJLHFCQUFxQixhQUFhLFVBQVUsS0FBSyxDQUFDLHFCQUFxQixhQUFhLGVBQWUsR0FDckc7Q0FFRixJQUFJLENBQUMscUJBQXFCLGFBQWEsTUFBTSxDQUFDLEVBQUUsU0FBUyxRQUFRLEdBQy9EO0NBR0YsTUFBTSxrQkFEb0IsVUFBVSxvQkFDSSxDQUFDLENBQUMsUUFBTyxZQUFXO0VBQzFELE1BQU0sZUFBZSxRQUFRLGFBQWEsZUFBZSxLQUFLO0VBQzlELE9BQU8sV0FBVyxPQUFPLEtBQUssUUFBUSxhQUFhLGVBQWUsS0FBSyxDQUFDLGFBQWEsV0FBVyxHQUFHO0NBQ3JHLENBQUM7Q0FDRCxNQUFNLFdBQVcscUJBQXFCLGFBQWEsVUFBVTtDQUM3RCxJQUFJLGdCQUFnQixXQUFXLEdBQ3pCO01BQUEsYUFBYSxLQUFLO0dBQ3BCLHFCQUFxQixhQUFhLFlBQVksR0FBRztHQUdqRCxxQkFBcUIsYUFBYSxpQkFBaUIsR0FBRztFQUN4RDtRQUNLLElBQUksYUFBYSxRQUFRLHFCQUFxQixhQUFhLGVBQWUsS0FBSyxxQkFBcUIsYUFBYSxlQUFlLE1BQU0sTUFBTTtFQUNqSixxQkFBcUIsYUFBYSxZQUFZLElBQUk7RUFDbEQscUJBQXFCLGFBQWEsaUJBQWlCLElBQUk7Q0FDekQ7QUFDRjs7Ozs7O0FBTUEsU0FBZ0IscUJBQXFCLE9BQU87Q0FDMUMsTUFBTSxFQUNKLFNBQVMsT0FDVCxVQUNBLFdBQVcsT0FDWCxlQUFlLE1BQ2YsY0FBYyxNQUNkLHFCQUNBLGVBQWUsT0FDZixRQUFRLE1BQ1Isa0JBQWtCLE1BQ2xCLHNCQUFzQixJQUN0QixzQkFDQSwwQkFDQSw0QkFDQSxjQUNBLHNCQUNFO0NBQ0osTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sZUFBZSxNQUFNLFNBQVMscUJBQXFCO0NBQ3pELE1BQU0sV0FBVyxNQUFNLFNBQVMsaUJBQWlCO0NBQ2pELE1BQU0sRUFDSixRQUNBLFlBQ0UsTUFBTTtDQUNWLE1BQU0sWUFBWSx3QkFBd0IsUUFBUSxRQUFRLGlCQUFpQixNQUFNO0NBQ2pGLE1BQU0scUJBQXFCLGlCQUFpQjtDQUs1QyxNQUFNLDhCQUE4QixtQkFBbUIsWUFBWSxLQUFLO0NBQ3hFLE1BQU0sa0JBQWtCLGNBQWMsWUFBWTtDQUNsRCxNQUFNLGlCQUFpQixjQUFjLFdBQVc7Q0FHaEQsTUFBTSx5QkFBeUIsY0FBYyxtQkFBbUI7Q0FDaEUsTUFBTSx5QkFBeUIsY0FBYyxtQkFBbUI7Q0FDaEUsTUFBTSxVQUFVLGNBQWMsSUFBSTtDQUNsQyxNQUFNLE9BQU8sZ0JBQWdCLFlBQVk7Q0FDekMsTUFBTSxnQkFBZ0IsaUJBQWlCO0NBQ3ZDLE1BQU0scUNBQThCLE9BQU8sS0FBSztDQUNoRCxNQUFNLGdDQUF5QixPQUFPLEtBQUs7Q0FDM0MsTUFBTSxxQ0FBOEIsT0FBTyxLQUFLO0NBQ2hELE1BQU0sc0NBQStCLE9BQU8sSUFBSTtDQUNoRCxNQUFNLDRCQUFxQixPQUFPLEVBQUU7Q0FDcEMsTUFBTSxzQ0FBK0IsT0FBTyxFQUFFO0NBQzlDLE1BQU0sOEJBQXVCLE9BQU8sSUFBSTtDQUN4QyxNQUFNLDZCQUFzQixPQUFPLElBQUk7Q0FDdkMsTUFBTSx1QkFBdUIsY0FBYyxnQkFBZ0IsNEJBQTRCLGVBQWUsZUFBZTtDQUNySCxNQUFNLHNCQUFzQixjQUFjLGVBQWUsZUFBZSxjQUFjO0NBQ3RGLE1BQU0sY0FBYyxXQUFXO0NBQy9CLE1BQU0scUJBQXFCLFdBQVc7Q0FDdEMsTUFBTSxvQkFBb0Isa0JBQWtCO0NBQzVDLE1BQU0saUJBQWlCLGlCQUFpQjtDQUN4QyxNQUFNLHVCQUF1Qix3QkFBd0IsUUFBUTtDQUM3RCxNQUFNLHFCQUFxQixtQkFBbUIsWUFBWSx5QkFBeUI7RUFDakYsT0FBTyxZQUFZLFNBQVMsU0FBUyxJQUFJLENBQUM7Q0FDNUMsQ0FBQztDQUNELE1BQU0sNEJBQTRCLHdCQUF3QixvQkFBb0IsQ0FBQyxDQUFDLFFBQU8sWUFBVyxXQUFXLElBQUksS0FBSyxDQUFDLENBQUM7Q0FHeEgsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxZQUFZLENBQUMsT0FDZjtFQUVGLFNBQVMsVUFBVSxPQUFPO0dBQ3hCLElBQUksTUFBTSxRQUFRLE9BRVo7UUFBQSxTQUFTLHNCQUFzQixjQUFjLGNBQWMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLG1CQUFtQixDQUFDLENBQUMsV0FBVyxLQUFLLENBQUMsNkJBQzlILFVBQVUsS0FBSztHQUFBO0VBR3JCO0VBRUEsT0FBTyxpQkFESyxjQUFjLG9CQUNGLEdBQUssV0FBVyxTQUFTO0NBQ25ELEdBQUc7RUFBQztFQUFVO0VBQXNCO0VBQU87RUFBNkI7Q0FBa0IsQ0FBQztDQUczRixhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksQ0FBQyxNQUNmO0VBRUYsTUFBTSxNQUFNLGNBQWMsb0JBQW9CO0VBQzlDLFNBQVMsMEJBQTBCO0dBQ2pDLHNCQUFzQixVQUFVO0VBQ2xDO0VBQ0EsU0FBUyxjQUFjLE9BQU87R0FDNUIsTUFBTSxTQUFTLFVBQVUsS0FBSztHQUM5QixNQUFNLGlCQUFpQiwwQkFBMEI7R0FDakQsTUFBTSxzQkFBc0IsU0FBUyxVQUFVLE1BQU0sS0FBSyxTQUFTLGNBQWMsTUFBTSxLQUFLLFNBQVMsZUFBZSxZQUFZLE1BQU0sS0FBSyxlQUFlLE1BQUssWUFBVyxZQUFZLFVBQVUsU0FBUyxTQUFTLE1BQU0sQ0FBQztHQUN6TixzQkFBc0IsVUFBVSxDQUFDO0dBQ2pDLHVCQUF1QixVQUFVLE1BQU0sZUFBZTtHQUN0RCxJQUFJLFFBQVEsUUFBUSw4QkFBK0IsR0FBRztJQUNwRCxpQkFBaUIsVUFBVTtJQUczQixtQkFBbUIsTUFBTSxTQUFTO0tBQ2hDLGlCQUFpQixVQUFVO0lBQzdCLENBQUM7R0FDSDtFQUNGO0VBQ0EsU0FBUyxZQUFZO0dBQ25CLHVCQUF1QixVQUFVO0VBQ25DO0VBQ0EsT0FBTyxjQUFjLGlCQUFpQixLQUFLLGVBQWUsZUFBZSxJQUFJLEdBQUcsaUJBQWlCLEtBQUssYUFBYSx5QkFBeUIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLGlCQUFpQix5QkFBeUIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLFdBQVcsV0FBVyxJQUFJLEdBRzFRLHVCQUF1QjtDQUN6QixHQUFHO0VBQUM7RUFBVTtFQUFVO0VBQWM7RUFBc0I7RUFBTTtFQUFlO0VBQW9CO0NBQXlCLENBQUM7Q0FHL0gsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxZQUFZLENBQUMsaUJBQ2Y7RUFFRixNQUFNLE1BQU0sY0FBYyxvQkFBb0I7RUFHOUMsU0FBUyxvQkFBb0I7R0FDM0IsaUJBQWlCLFVBQVU7R0FDM0IsbUJBQW1CLE1BQU0sU0FBUztJQUNoQyxpQkFBaUIsVUFBVTtHQUM3QixDQUFDO0VBQ0g7RUFDQSxTQUFTLGNBQWMsT0FBTztHQUM1QixNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLElBQUksV0FBVyxNQUFNLEdBQ25CLHVCQUF1QixVQUFVO0VBRXJDO0VBQ0EsU0FBUyxtQkFBbUIsT0FBTztHQUNqQyxNQUFNLGdCQUFnQixNQUFNO0dBQzVCLE1BQU0sZ0JBQWdCLE1BQU07R0FDNUIsTUFBTSxTQUFTLFVBQVUsS0FBSztHQUs5QixJQUFJLFNBQVMsaUJBQWlCLFFBQVEsVUFBVSxRQUFRLFNBQVMsVUFBVSxNQUFNLEdBQy9FLDRCQUE0QixNQUFNO0dBRXBDLHFCQUFxQjtJQUNuQixNQUFNLFNBQVMsVUFBVTtJQUN6QixNQUFNLFdBQVcsTUFBTSxRQUFRO0lBQy9CLE1BQU0saUJBQWlCLDBCQUEwQjtJQUNqRCxNQUFNLHNCQUFzQixlQUFlLGFBQWEsZ0JBQWdCLGFBQWEsQ0FBQyxLQUFLO0tBQUMsZUFBZTtLQUFTLGNBQWM7S0FBUyxlQUFlLGdCQUFnQjtLQUFTLGVBQWUsZUFBZTtLQUFTLGVBQWUsaUJBQWlCO0tBQVMsZUFBZSxnQkFBZ0I7S0FBUyxXQUFXLHdCQUF3QjtLQUFHLFdBQVcsb0JBQW9CO0lBQUMsQ0FBQyxDQUFDLFNBQVMsYUFBYTtJQUN6WSxNQUFNLHVCQUF1QixFQUFFLFNBQVMsY0FBYyxhQUFhLEtBQUssU0FBUyxVQUFVLGFBQWEsS0FBSyxTQUFTLGVBQWUsUUFBUSxLQUFLLFNBQVMsZUFBZSxZQUFZLGFBQWEsS0FBSyxlQUFlLE1BQUssWUFBVyxZQUFZLGlCQUFpQixTQUFTLFNBQVMsYUFBYSxDQUFDLEtBQUssU0FBUyxvQkFBbUIsWUFBVyxTQUFTLFNBQVMsYUFBYSxDQUFDLEtBQUssdUJBQXVCLFNBQVMsZ0JBQWdCLEtBQUssU0FBUyxTQUFTLE1BQU0sQ0FBQyxDQUFDLE1BQUssU0FBUSxTQUFTLEtBQUssU0FBUyxTQUFTLFVBQVUsYUFBYSxLQUFLLFNBQVMsS0FBSyxTQUFTLFNBQVMsY0FBYyxhQUFhLENBQUMsS0FBSyxpQkFBaUIsS0FBSyxTQUFTLFNBQVMsTUFBTSxDQUFDLENBQUMsTUFBSyxTQUFRLENBQUMsS0FBSyxTQUFTLFNBQVMsVUFBVSx3QkFBd0IsS0FBSyxTQUFTLFNBQVMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLGFBQWEsS0FBSyxLQUFLLFNBQVMsU0FBUyxpQkFBaUIsYUFBYTtJQUN2ekIsSUFBSSxrQkFBa0IsZ0JBQWdCLHNCQUNwQyxlQUFlLG9CQUFvQjtJQUtyQyxJQUFJLGdCQUFnQixrQkFBa0IsZ0JBQWdCLENBQUMsaUJBQWlCLE1BQU0sS0FBSyxjQUFjLEdBQUcsTUFBTSxJQUFJLE1BQU07S0FHbEgsSUFBSSxjQUFjLG9CQUFvQixHQUFHO01BQ3ZDLHFCQUFxQixNQUFNO01BRzNCLElBQUksaUJBQWlCLFNBQVM7T0FLNUIsa0JBQWtCLGNBQWM7UUFDOUIscUJBQXFCLE1BQU07T0FDN0IsQ0FBQztPQUNEO01BQ0Y7S0FDRjtLQUNBLE1BQU0sa0JBQWtCLG1CQUFtQjtLQUMzQyxNQUFNLGVBQWUsdUJBQXVCO0tBQzVDLE1BQU0sZUFBZSxnQkFBZ0IsZ0JBQWdCLFNBQVMsWUFBWSxJQUFJLGVBQWUsU0FBUyxnQkFBZ0IsZ0JBQWdCLFNBQVMsTUFBTTtLQUNySixJQUFJLGNBQWMsV0FBVyxHQUMzQixZQUFZLE1BQU07SUFFdEI7SUFHQSxJQUFJLFFBQVEsUUFBUSxpQkFBaUI7S0FDbkMsUUFBUSxRQUFRLGtCQUFrQjtLQUNsQztJQUNGO0lBSUEsS0FBSyw4QkFBOEIsT0FBTyxDQUFDLFVBQVUsaUJBQWlCLHdCQUF3QixDQUFDLGlCQUFpQixZQVFoSCwrQkFBK0Isa0JBQWtCLDRCQUE0QixJQUFJO0tBQy9FLHNCQUFzQixVQUFVO0tBQ2hDLE1BQU0sUUFBUSxPQUFPLHlCQUF5QkMsVUFBa0IsS0FBSyxDQUFDO0lBQ3hFO0dBQ0YsQ0FBQztFQUNIO0VBQ0EsU0FBUyxzQkFBc0I7R0FDN0IsSUFBSSxzQkFBc0IsU0FDeEI7R0FFRixRQUFRLFFBQVEsa0JBQWtCO0dBQ2xDLFlBQVksTUFBTSxTQUFTO0lBQ3pCLFFBQVEsUUFBUSxrQkFBa0I7R0FDcEMsQ0FBQztFQUNIO0VBQ0EsTUFBTSxzQkFBc0IsY0FBYyxZQUFZLElBQUksZUFBZTtFQUN6RSxJQUFJLENBQUMsWUFBWSxDQUFDLHFCQUNoQjtFQUVGLE9BQU8sY0FBYyx1QkFBdUIsaUJBQWlCLHFCQUFxQixZQUFZLGtCQUFrQixHQUFHLHVCQUF1QixpQkFBaUIscUJBQXFCLGVBQWUsaUJBQWlCLEdBQUcsWUFBWSxpQkFBaUIsVUFBVSxXQUFXLGFBQWEsR0FBRyxZQUFZLGlCQUFpQixVQUFVLFlBQVksa0JBQWtCLEdBQUcsWUFBWSxpQkFBaUIsaUJBQWlCLFVBQVUsWUFBWSxxQkFBcUIsSUFBSSxDQUFDO0NBQzdiLEdBQUc7RUFBQztFQUFVO0VBQWM7RUFBVTtFQUFzQjtFQUFPO0VBQU07RUFBZTtFQUFPO0VBQWlCO0VBQWM7RUFBb0I7RUFBNkI7RUFBVztFQUFTO0VBQWE7RUFBb0I7RUFBbUI7RUFBc0I7RUFBMEI7Q0FBeUIsQ0FBQztDQUdqVSxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksQ0FBQyxZQUFZLENBQUMsTUFDNUI7RUFJRixNQUFNLGNBQWMsTUFBTSxLQUFLLGVBQWUsWUFBWSxpQkFBaUIsSUFBSSxnQkFBZ0IsUUFBUSxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7RUFFbEgsTUFBTSxvQ0FEWSxPQUFPLGlCQUFpQixLQUFLLFNBQVMsU0FBUyxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQzlCLE1BQUssU0FBUSxtQkFBbUIsS0FBSyxTQUFTLFNBQVMsZ0JBQWdCLElBQUksQ0FBQyxDQUFDLEVBQUUsU0FBUyxTQUFTO0VBR3BKLE1BQU0sb0JBQW9CLFdBREg7R0FBQyxHQUFHO0lBREk7SUFBVSxHQUFHO0lBQWEsZUFBZTtJQUFTLGNBQWM7SUFBUyxlQUFlLGlCQUFpQjtJQUFTLGVBQWUsZ0JBQWdCO0lBQVMsR0FBRywwQkFBMEI7R0FDdks7R0FBRztHQUFrQyxXQUFXLHdCQUF3QjtHQUFHLFdBQVcsb0JBQW9CO0dBQUcsOEJBQThCLGVBQWU7RUFBSSxDQUFDLENBQUMsUUFBTyxNQUFLLEtBQUssSUFDM0wsR0FBZ0I7R0FDbkQsWUFBWSxTQUFTO0dBQ3JCLE1BQU07RUFDUixDQUFDO0VBRUQsTUFBTSxnQkFBZ0IsV0FETyxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQyxRQUFPLE1BQUssS0FBSyxJQUN4QyxDQUFvQjtFQUNyRCxhQUFhO0dBQ1gsY0FBYztHQUNkLGtCQUFrQjtFQUNwQjtDQUNGLEdBQUc7RUFBQztFQUFNO0VBQVU7RUFBYztFQUFVO0VBQU87RUFBZTtFQUE2QjtFQUFNO0VBQVc7RUFBc0I7RUFBMEI7Q0FBeUIsQ0FBQztDQUcxTCx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFFBQVEsWUFBWSxDQUFDLGNBQWMsb0JBQW9CLEdBQzFEO0VBRUYsYUFBYSxVQUFVO0VBQ3ZCLHVCQUF1QixVQUFVO0VBQ2pDLE1BQU0sTUFBTSxjQUFjLG9CQUFvQjtFQUM5QyxNQUFNLDJCQUEyQixjQUFjLEdBQUc7RUFHbEQscUJBQXFCO0dBQ25CLE1BQU0sd0JBQXdCLGdCQUFnQjtHQUM5QyxNQUFNLHVCQUF1QixPQUFPLDBCQUEwQixhQUFhLHNCQUFzQix1QkFBdUIsV0FBVyxFQUFFLElBQUk7R0FHekksSUFBSSx5QkFBeUIsVUFBYSx5QkFBeUIsT0FDakU7R0FHRixJQURxQyxTQUFTLHNCQUFzQix3QkFDckMsR0FDN0I7R0FFRixJQUFJLG9CQUFvQjtHQUN4QixNQUFNLCtCQUErQjtJQUNuQyxJQUFJLHFCQUFxQixNQUN2QixvQkFBb0IsbUJBQW1CLG9CQUFvQjtJQUU3RCxPQUFPLGtCQUFrQixNQUFNO0dBQ2pDO0dBQ0EsSUFBSTtHQUNKLElBQUkseUJBQXlCLFFBQVEseUJBQXlCLE1BQzVELFlBQVksdUJBQXVCO1FBRW5DLFlBQVksV0FBVyxvQkFBb0I7R0FFN0MsWUFBWSxhQUFhLHVCQUF1QjtHQUNoRCxNQUFNLGlCQUFpQixTQUFTLHNCQUFzQixjQUFjLEdBQUcsQ0FBQztHQUl4RSxNQUFNLFlBQVksUUFBUSxRQUFRO0dBQ2xDLE1BQU0sdUJBQXVCLFdBQVcsU0FBUyxlQUFlLGVBQWUsU0FBUztHQUd4RixhQUFrQixXQUFXO0lBQzNCLE1BQU07SUFDTixlQUFlLGNBQWM7SUFDN0IsY0FBYztLQUlaLElBQUksQ0FBQyxRQUFRLFNBQ1gsT0FBTztLQUVULElBQUksZ0JBQ0YsT0FBTztLQUVULE1BQU0sdUJBQXVCLGNBQWMsR0FBRztLQUU5QyxPQUFPLEVBRGtCLHlCQUF5QixhQUFhLFNBQVMsc0JBQXNCLG9CQUFvQjtJQUVwSDtHQUNGLENBQUM7RUFDSCxDQUFDO0NBQ0gsR0FBRztFQUFDO0VBQVU7RUFBTTtFQUFzQjtFQUFvQjtFQUFpQjtFQUF3QjtFQUFTO0NBQU8sQ0FBQztDQUl4SCxNQUFNLHFDQUE4QixPQUFPLElBQUk7Q0FHL0MseUJBQXlCO0VBQ3ZCLElBQUksWUFBWSxDQUFDLHNCQUFzQjtHQUNyQyxzQkFBc0IsVUFBVTtHQUNoQztFQUNGO0VBQ0EsSUFBSSxzQkFBc0IsU0FBUztHQUNqQyxzQkFBc0IsUUFBUSxZQUFZO0dBQzFDLHNCQUFzQixVQUFVO0VBQ2xDO0VBQ0EsTUFBTSxNQUFNLGNBQWMsb0JBQW9CO0VBQzlDLE1BQU0sMkJBQTJCLGNBQWMsR0FBRztFQUlsRCxNQUFNLHNCQUFzQix1QkFBdUIsV0FBVztFQUM5RCw0QkFBNEIsd0JBQXdCO0VBQ3BELFNBQVMsa0JBQWtCLFNBQVM7R0FDbEMsSUFBSSxDQUFDLFFBQVEsTUFDWCxhQUFhLFVBQVUsYUFBYSxRQUFRLGFBQWEsdUJBQXVCLE9BQU87R0FJekYsSUFBSSxRQUFRLFdBQVcsZUFBb0IsUUFBUSxnQkFBZ0IsYUFBYSxnQkFBZ0IsYUFBYSxDQUFDLEtBQUssUUFBUSxXQUFXLG1CQUF3QixRQUFRLFlBQVksU0FBUyxjQUN6TCxzQkFBc0IsVUFBVTtHQUVsQyxJQUFJLFFBQVEsV0FBVyxpQkFDckI7R0FFRixJQUFJLFFBQVEsUUFDVixzQkFBc0IsVUFBVTtRQUMzQixJQUFJLGVBQWUsUUFBUSxXQUFXLEtBQUssc0JBQXNCLFFBQVEsV0FBVyxHQUN6RixzQkFBc0IsVUFBVTtRQUMzQjtJQU1MLElBQUksMkJBQTJCO0lBQy9CLGNBQWMsb0JBQW9CLENBQUMsQ0FBQyxjQUFjLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFDN0QsSUFBSSxnQkFBZ0I7S0FDbEIsMkJBQTJCO0tBQzNCLE9BQU87SUFDVCxFQUNGLENBQUM7SUFDRCxJQUFJLDBCQUNGLHNCQUFzQixVQUFVO1NBRWhDLHNCQUFzQixVQUFVO0dBRXBDO0VBQ0Y7RUFDQSxPQUFPLEdBQUcsY0FBYyxpQkFBaUI7RUFDekMsU0FBUyxpQkFBaUIsV0FBVztHQUNuQyxNQUFNLHVCQUF1QixlQUFlO0dBQzVDLElBQUksMkJBQTJCLE9BQU8seUJBQXlCLGFBQWEscUJBQXFCLFNBQVMsSUFBSTtHQUc5RyxJQUFJLDZCQUE2QixVQUFhLDZCQUE2QixPQUN6RSxPQUFPO0dBRVQsSUFBSSw2QkFBNkIsTUFDL0IsMkJBQTJCO0dBRTdCLE1BQU0seUJBQXlCLGNBQWMsY0FBYyxlQUFlO0dBQzFFLE1BQU0sd0JBQXdCLDBCQUEwQixlQUFlLFlBQVksd0JBQXdCLE1BQU0sU0FBUywyQkFBMkI7R0FDckosSUFBSSx1QkFBdUIsc0JBQXNCLHlCQUF5Qix5QkFBeUIsMEJBQTBCO0dBQzdILElBQUksQ0FBQyxzQkFDSCx1QkFBdUIsNEJBQTRCLEtBQUs7R0FFMUQsSUFBSSxPQUFPLDZCQUE2QixXQUN0QyxPQUFPO0dBRVQsT0FBTyxXQUFXLHdCQUF3QixLQUFLLHdCQUF3QjtFQUN6RTtFQUNBLGFBQWE7R0FDWCxPQUFPLElBQUksY0FBYyxpQkFBaUI7R0FDMUMsTUFBTSxXQUFXLGNBQWMsR0FBRztHQUNsQyxNQUFNLGlCQUFpQiwwQkFBMEI7R0FDakQsTUFBTSw0QkFBNEIsU0FBUyxVQUFVLFFBQVEsS0FBSyxlQUFlLE1BQUssWUFBVyxZQUFZLFlBQVksU0FBUyxTQUFTLFFBQVEsQ0FBQyxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssU0FBUyxTQUFTLFVBQVUsR0FBRyxLQUFLLENBQUMsQ0FBQyxNQUFLLFNBQVEsU0FBUyxLQUFLLFNBQVMsU0FBUyxVQUFVLFFBQVEsQ0FBQztHQUc1UixNQUFNLHVCQUF1QixlQUFlO0dBQzVDLE1BQU0sWUFBWSxhQUFhO0dBQy9CLE1BQU0sZ0JBQWdCLGlCQUFpQixTQUFTO0dBQ2hELE1BQU0sTUFBTSxFQUNWLFdBQVcsTUFDYjtHQUNBLHNCQUFzQixVQUFVO0dBQ2hDLHFCQUFxQjtJQUNuQixJQUFJLHNCQUFzQixZQUFZLEtBQ3BDLHNCQUFzQixVQUFVO0lBSWxDLE1BQU0sd0JBQXdCLHdCQUF3QixhQUFhO0lBRW5FLE1BQU0seUJBRU4sdUJBQXVCLFdBQVcsT0FBTyx5QkFBeUI7SUFDbEUsSUFBSSxDQUFDLElBQUksYUFBYSx3QkFBd0IsQ0FBQyxzQkFBc0IsV0FBVyxjQUFjLHFCQUFxQixNQUluSCxDQUFDLDBCQUEwQiwwQkFBMEIsWUFBWSxhQUFhLElBQUksT0FBTyw0QkFBNEIsT0FBTztLQUMxSCxNQUFNLGVBQWUsRUFDbkIsZUFBZSxLQUNqQjtLQUNBLElBQUksY0FBYyxZQUNoQixhQUFhLGVBQWU7S0FFOUIsc0JBQXNCLE1BQU0sWUFBWTtJQUMxQztJQUdBLHNCQUFzQixVQUFVO0dBQ2xDLENBQUM7RUFDSDtDQUNGLEdBQUc7RUFBQztFQUFVO0VBQVU7RUFBc0I7RUFBZ0I7RUFBd0I7RUFBd0I7RUFBUTtFQUFNO0VBQWM7RUFBVztDQUF5QixDQUFDO0NBSy9LLHlCQUF5QjtFQUN2QixJQUFJLENBQUNILFVBQTBCLFFBQVEsQ0FBQyxVQUN0QztFQUVGLE1BQU0sV0FBVyxjQUFjLGNBQWMsUUFBUSxDQUFDO0VBQ3RELElBQUksQ0FBQyxjQUFjLFFBQVEsS0FBSyxDQUFDLGtCQUFrQixRQUFRLEdBQ3pEO0VBRUYsSUFBSSxTQUFTLFVBQVUsUUFBUSxHQUM3QixTQUFTLEtBQUs7Q0FFbEIsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDO0NBSW5CLHlCQUF5QjtFQUN2QixJQUFJLFlBQVksQ0FBQyxlQUNmO0VBRUYsY0FBYyxxQkFBcUI7R0FDakM7R0FDQTtHQUNBO0dBQ0EsY0FBYyxNQUFNO0dBQ3BCO0VBQ0YsQ0FBQztFQUNELGFBQWE7R0FDWCxjQUFjLHFCQUFxQixJQUFJO0VBQ3pDO0NBQ0YsR0FBRztFQUFDO0VBQVU7RUFBZTtFQUFPO0VBQU07RUFBTztFQUFpQjtDQUFZLENBQUM7Q0FHL0UseUJBQXlCO0VBQ3ZCLElBQUksWUFBWSxDQUFDLHNCQUNmO0VBRUYsZUFBZSxvQkFBb0I7RUFDbkMsYUFBYTtHQUNYLGVBQWUsMENBQTBDO0VBQzNEO0NBQ0YsR0FBRyxDQUFDLFVBQVUsb0JBQW9CLENBQUM7Q0FDbkMsTUFBTSxxQkFBcUIsQ0FBQyxhQUFhLFFBQVEsQ0FBQyw4QkFBOEIsVUFBVSxrQkFBa0I7Q0FDNUcsT0FBb0Isd0RBQVksVUFBVSxFQUN4QyxVQUFVO0VBQUMsc0JBQW1DLDBDQUFLLFlBQVk7R0FDN0QsYUFBYTtHQUNiLEtBQUs7R0FDTCxVQUFTLFVBQVM7SUFDaEIsSUFBSSxPQUFPO0tBQ1QsTUFBTSxNQUFNLG1CQUFtQjtLQUUvQixhQUFrQixJQUFJLElBQUksU0FBUyxFQUFFO0lBQ3ZDLE9BQU8sSUFBSSxlQUFlLFlBQVk7S0FDcEMsc0JBQXNCLFVBQVU7S0FDaEMsSUFBSSxlQUFlLE9BQU8sY0FBYyxVQUFVLEdBRWhELGdCQURxQyxZQUMxQixDQUFDLEVBQUUsTUFBTTtVQUVwQixXQUFXLDRCQUE0QixjQUFjLGdCQUFnQixDQUFDLEVBQUUsTUFBTTtJQUVsRjtHQUNGO0VBQ0YsQ0FBQztFQUFHO0VBQVUsc0JBQW1DLDBDQUFLLFlBQVk7R0FDaEUsYUFBYTtHQUNiLEtBQUs7R0FDTCxVQUFTLFVBQVM7SUFDaEIsSUFBSSxPQUVGLGFBQWtCLG1CQUFtQixDQUFDLENBQUMsRUFBRTtTQUNwQyxJQUFJLGVBQWUsWUFBWTtLQUNwQyxJQUFJLGlCQUNGLHNCQUFzQixVQUFVO0tBRWxDLElBQUksZUFBZSxPQUFPLGNBQWMsVUFBVSxHQUVoRCxvQkFEeUMsWUFDOUIsQ0FBQyxFQUFFLE1BQU07VUFFcEIsV0FBVyx3QkFBd0IsY0FBYyxlQUFlLENBQUMsRUFBRSxNQUFNO0lBRTdFO0dBQ0Y7RUFDRixDQUFDO0NBQUMsRUFDSixDQUFDO0FBQ0g7Ozs7OztBQ3ptQkEsU0FBZ0IsU0FBUyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0NBQzFDLE1BQU0sRUFDSixVQUFVLE1BQ1YsT0FBTyxjQUFjLFNBQ3JCLFNBQVMsTUFDVCxjQUFjLE9BQ2QsY0FBYyxNQUNkLGlCQUFpQixHQUNqQixTQUFTSSxpQkFDUDtDQUNKLE1BQU0sVUFBVSxNQUFNLFFBQVE7Q0FDOUIsTUFBTSw4QkFBdUIsT0FBTyxNQUFTO0NBQzdDLE1BQU0sUUFBUSxrQkFBa0I7Q0FDaEMsTUFBTSxtQkFBbUIsV0FBVztDQUNwQyxNQUFNLHlCQUFrQixjQUFjO0VBQ3BDLFNBQVMsc0JBQXNCLFVBQVUsYUFBYSxRQUFRLGFBQWE7R0FDekUsTUFBTSxVQUFVLHlCQUF5QixRQUFRLGFBQWEsTUFBTTtHQUNwRSxJQUFJLFlBQVksZ0JBQWdCLFdBQVcsaUJBQWlCLEdBQzFELGlCQUFpQixNQUFNLHNCQUFzQjtJQUMzQyxNQUFNLFFBQVEsTUFBTSxPQUFPO0dBQzdCLENBQUM7UUFFRCxNQUFNLFFBQVEsVUFBVSxPQUFPO0VBRW5DO0VBQ0EsU0FBUyxZQUFZLE1BQU0sZUFBZSxzQkFBc0I7R0FDOUQsTUFBTSxZQUFZLFFBQVEsUUFBUTtHQUNsQyxNQUFNLDhCQUE4QixNQUFNLE9BQU8scUJBQXFCLE1BQU07R0FDNUUsSUFBSSxRQUFRLDZCQUVWLE9BQU87R0FFVCxJQUFJLENBQUMsTUFFSCxPQUFPO0dBRVQsSUFBSSxDQUFDLFFBRUgsT0FBTztHQUVULElBQUksY0FBYyxPQUFPLGdCQUFnQixhQUFhLFlBQVksSUFBSSxjQUVwRSxPQUFPLENBQUMscUJBQXFCLFVBQVUsSUFBSTtHQUk3QyxPQUFPO0VBQ1Q7RUFDQSxPQUFPO0dBQ0wsY0FBYyxPQUFPO0lBS25CLGVBQWUsVUFBVSx1QkFBdUIsTUFBTSxhQUFhLElBQUksS0FBSyxzQkFBc0IsTUFBTSxXQUFXLElBQUksWUFBWSxNQUFNO0dBQzNJO0dBQ0EsWUFBWSxPQUFPO0lBQ2pCLE1BQU0sY0FBYyxlQUFlO0lBQ25DLE1BQU0sY0FBYyxNQUFNO0lBQzFCLE1BQU0sT0FBTyxNQUFNLE9BQU8sTUFBTTtJQUloQyxJQUFJLE1BQU0sV0FBVyxLQUFLLGdCQUFnQixXQUFXLHVCQUF1QixhQUFhLElBQUksS0FBSyxhQUNoRztJQUVGLE1BQU0sV0FBVyxZQUFZLE1BQU0sTUFBTSxnQkFBZSxrQkFBaUIsa0JBQWtCLFdBQVcsa0JBQWtCLFdBQVc7SUFNbkksTUFBTSxTQUFTLFVBQVUsV0FBVztJQUNwQyxNQUFNLGFBQWEsa0JBQWtCLE1BQU07SUFDM0MsSUFBSSxjQUFjLGdCQUFnQixXQUFXO0tBRTNDLHNCQUFzQixVQUFVLGFBQWEsYUFBYSxTQUFTLE1BQU0sZUFBZSxXQUFXO0tBQ25HO0lBQ0Y7SUFJQSxNQUFNLHFCQUFxQixNQUFNO0lBSWpDLE1BQU0sY0FBYztLQUNsQixzQkFBc0IsVUFBVSxhQUFhLG9CQUFvQixXQUFXO0lBQzlFLENBQUM7R0FDSDtHQUNBLFFBQVEsT0FBTztJQUNiLElBQUksZ0JBQWdCLGtCQUNsQjtJQUVGLE1BQU0sY0FBYyxlQUFlO0lBQ25DLElBQUksZ0JBQWdCLGVBQWUsYUFBYTtLQUM5QyxlQUFlLFVBQVU7S0FDekI7SUFDRjtJQUNBLElBQUksdUJBQXVCLGFBQWEsSUFBSSxLQUFLLGFBQy9DO0lBSUYsc0JBRGlCLFlBREosTUFBTSxPQUFPLE1BQ00sR0FBRyxNQUFNLGdCQUFlLGtCQUFpQixrQkFBa0IsV0FBVyxrQkFBa0IsZUFBZSxrQkFBa0IsYUFBYSxrQkFBa0IsT0FDM0osR0FBRyxNQUFNLGFBQWEsTUFBTSxlQUFlLFdBQVc7R0FDckY7R0FDQSxZQUFZO0lBQ1YsZUFBZSxVQUFVO0dBQzNCO0VBQ0Y7Q0FDRixHQUFHO0VBQUM7RUFBUztFQUFhO0VBQWE7RUFBUTtFQUFPO0VBQWE7RUFBUTtFQUFPO0VBQWtCO0NBQWMsQ0FBQztDQUNuSCxvQkFBYSxjQUFjLFVBQVUsRUFDbkMsVUFDRixJQUFJLGNBQWMsQ0FBQyxTQUFTLFNBQVMsQ0FBQztBQUN4Qzs7QUM5R0EsU0FBUyxjQUFjO0NBQ3JCLE9BQU87QUFDVDtBQUNBLFNBQWdCLGNBQWMsY0FBYztDQUMxQyxPQUFPO0VBQ0wsV0FBVyxPQUFPLGlCQUFpQixZQUFZLGVBQWUsY0FBYyxhQUFhO0VBQ3pGLGNBQWMsT0FBTyxpQkFBaUIsWUFBWSxlQUFlLGNBQWMsZ0JBQWdCO0NBQ2pHO0FBQ0Y7Ozs7OztBQU1BLFNBQWdCLFdBQVcsT0FBTyxRQUFRLENBQUMsR0FBRztDQUM1QyxNQUFNLEVBQ0osVUFBVSxNQUNWLHlCQUFZLE1BQ1osY0FBYyxtQkFBbUIsTUFDakMsb0JBQW9CLFVBQ3BCLGlCQUFpQixhQUNqQixTQUNBLGlCQUNFO0NBQ0osTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxpQkFBaUI7Q0FDeEQsTUFBTSxFQUNKLFNBQ0EsV0FDRSxNQUFNO0NBQ1YsTUFBTSxPQUFPLGdCQUFnQixZQUFZO0NBQ3pDLE1BQU0saUJBQWlCLGtCQUFrQixPQUFPLHFCQUFxQixhQUFhLHlCQUF5QixLQUFLO0NBQ2hILE1BQU1DLGlCQUFlLE9BQU8scUJBQXFCLGFBQWEsaUJBQWlCO0NBQy9FLE1BQU0sc0JBQXNCQSxtQkFBaUI7Q0FDN0MsTUFBTSwyQkFBMkIsd0JBQXdCLGlCQUFpQjtDQUMxRSxNQUFNLEVBQ0osV0FBVyxrQkFDWCxjQUFjLHdCQUNaLGNBQWMsT0FBTztDQUN6QixNQUFNLHFDQUE4QixPQUFPLEtBQUs7Q0FDaEQsTUFBTSxzQ0FBK0IsT0FBTyxLQUFLO0NBRWpELE1BQU0sMkNBQW9DLE9BQU8sS0FBSztDQUd0RCxNQUFNLG9DQUE2QixPQUFPLEtBQUs7Q0FDL0MsTUFBTSw4QkFBdUIsT0FBTyxLQUFLO0NBQ3pDLE1BQU0scUNBQThCLE9BQU8sRUFBRTtDQUM3QyxNQUFNLDZCQUFzQixPQUFPLElBQUk7Q0FDdkMsTUFBTSw0QkFBNEIsV0FBVztDQUM3QyxNQUFNLDhCQUE4QixXQUFXO0NBRS9DLE1BQU0scUJBQXFCLFdBQVc7Q0FDdEMsTUFBTSx1QkFBdUIsd0JBQXdCO0VBQ25ELDRCQUE0QixNQUFNO0VBQ2xDLFFBQVEsUUFBUSxrQkFBa0I7Q0FDcEMsQ0FBQztDQUNELE1BQU0sbUJBQW1CLG1CQUFrQixjQUFhO0VBQ3RELE1BQU0sU0FBUyxRQUFRLFFBQVEsaUJBQWlCO0VBRWhELFFBRGlCLE9BQU8sZ0JBQWdCLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFBSSxDQUFDLEdBQzFELE1BQUssVUFBUyxNQUFNLFNBQVMsUUFBUSxDQUFDLE1BQU0sUUFBUSxRQUFRLFFBQVEsVUFBVTtDQUNoRyxDQUFDO0NBQ0QsTUFBTSwyQkFBMkIsbUJBQWtCLFVBQVM7RUFDMUQsT0FBTyxvQkFBb0IsT0FBTyxNQUFNLE9BQU8saUJBQWlCLENBQUMsS0FBSyxvQkFBb0IsT0FBTyxNQUFNLE9BQU8scUJBQXFCLENBQUM7Q0FDdEksQ0FBQztDQUNELE1BQU0sd0JBQXdCLG1CQUFrQixVQUFTO0VBQ3ZELElBQUksQ0FBQyxlQUFlLEdBQ2xCO0VBRUYsTUFBTSxRQUFRLE9BQU8seUJBQXlCRCxjQUFzQixNQUFNLFdBQVcsQ0FBQztDQUN4RixDQUFDO0NBQ0QsTUFBTSx1QkFBdUIsbUJBQWtCLFVBQVM7RUFDdEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUNFLGVBQWEsTUFBTSxRQUFRLFVBQ25EO0VBRUYsTUFBTSxTQUFTLGFBQWEsS0FBSyxJQUFJLE1BQU0sY0FBYztFQUt6RCxJQUFJLGVBQWUsV0FBVyxPQUFPLGFBQ25DO0VBRUYsSUFBSSxDQUFDLG9CQUFvQixpQkFBaUIsb0JBQW9CLEdBQzVEO0VBRUYsTUFBTSxlQUFlLHlCQUF5QkMsV0FBbUIsTUFBTTtFQUN2RSxNQUFNLFFBQVEsT0FBTyxZQUFZO0VBQ2pDLElBQUksQ0FBQyxhQUFhLFlBQ2hCLE1BQU0sZUFBZTtFQUV2QixJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxzQkFDckMsTUFBTSxnQkFBZ0I7Q0FFMUIsQ0FBQztDQUNELE1BQU0sc0JBQXNCLHdCQUF3QjtFQUNsRCxRQUFRLFFBQVEsa0JBQWtCO0VBQ2xDLDRCQUE0QixNQUFNLEdBQUcsb0JBQW9CO0NBQzNELENBQUM7Q0FDRCxNQUFNLGtDQUFrQyxtQkFBa0IsVUFBUztFQUNqRSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsTUFBTSxXQUFXLEdBQ3hDO0VBRUYsTUFBTSxTQUFTLFVBQVUsTUFBTSxXQUFXO0VBSTFDLElBQUksQ0FBQyxTQUFTLE1BQU0sT0FBTyxpQkFBaUIsR0FBRyxNQUFNLEdBQ25EO0VBRUYsSUFBSSxDQUFDLHNCQUFzQixTQUFTO0dBQ2xDLHNCQUFzQixVQUFVO0dBQ2hDLHVCQUF1QixVQUFVO0VBQ25DO0NBQ0YsQ0FBQztDQUNELE1BQU0sZ0NBQWdDLG1CQUFrQixVQUFTO0VBQy9ELElBQUksQ0FBQyxRQUFRLENBQUMsU0FDWjtFQUVGLElBQUksRUFBRSxNQUFNLG9CQUFvQixNQUFNLFlBQVksbUJBQ2hEO0VBRUYsSUFBSSxzQkFBc0IsU0FDeEIsdUJBQXVCLFVBQVU7Q0FFckMsQ0FBQztDQUlELGFBQU0sZ0JBQWdCO0VBQ3BCLFNBQVMsaUJBQWlCLFNBQVM7R0FHakMsSUFBSSxDQUFDLFFBQVEsTUFDWCxxQkFBcUIsVUFBVTtFQUVuQztFQUNBLE9BQU8sR0FBRyxjQUFjLGdCQUFnQjtFQUN4QyxhQUFhO0dBQ1gsT0FBTyxJQUFJLGNBQWMsZ0JBQWdCO0VBQzNDO0NBQ0YsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUlYLGFBQU0sZ0JBQWdCLHNCQUFzQixDQUFDLG9CQUFvQixDQUFDO0NBQ2xFLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUztHQUdyQixJQUFJLENBQUMsTUFBTTtJQUNULHFCQUFxQixVQUFVO0lBQy9CLGVBQWUsVUFBVTtJQUN6QixzQkFBc0IsVUFBVTtJQUNoQyxjQUFjLFVBQVU7R0FDMUI7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxRQUFRLFFBQVEscUJBQXFCO0VBQ3JDLFFBQVEsUUFBUSx3QkFBd0I7RUFDeEMsTUFBTSxtQ0FBbUMsSUFBSSxRQUFRO0VBQ3JELE1BQU0sTUFBTSxjQUFjLGVBQWU7RUFDekMsU0FBUyx5QkFBeUI7R0FDaEMsbUJBQW1CLE1BQU07R0FDekIsZUFBZSxVQUFVO0VBQzNCO0VBQ0EsU0FBUyx1QkFBdUI7R0FLOUIsZUFBZSxVQUFVO0dBQ3pCLG1CQUFtQixNQUduQlAsU0FBeUIsSUFBSSxTQUFTO0lBQ3BDLGVBQWUsVUFBVTtHQUMzQixDQUFDO0VBQ0g7RUFDQSxTQUFTLG1EQUFtRDtHQUMxRCw0QkFBNEIsVUFBVTtHQUd0QyxpQ0FBaUMsTUFBTSxTQUFTO0lBQzlDLDRCQUE0QixVQUFVO0dBQ3hDLENBQUM7RUFDSDtFQUNBLFNBQVMsdUJBQXVCO0dBQzlCLHNCQUFzQixVQUFVO0dBQ2hDLHVCQUF1QixVQUFVO0VBQ25DO0VBQ0EsU0FBUyx1QkFBdUI7R0FDOUIsTUFBTSxPQUFPLHNCQUFzQjtHQUNuQyxNQUFNLGVBQWUsU0FBUyxTQUFTLENBQUMsT0FBTyxVQUFVO0dBQ3pELE1BQU0seUJBQXlCLHlCQUF5QjtHQUN4RCxNQUFNLFdBQVcsT0FBTywyQkFBMkIsYUFBYSx1QkFBdUIsSUFBSTtHQUMzRixJQUFJLE9BQU8sYUFBYSxVQUN0QixPQUFPO0dBRVQsT0FBTyxTQUFTO0VBQ2xCO0VBQ0EsU0FBUyxrQkFBa0IsT0FBTztHQUNoQyxNQUFNLDRCQUE0QixxQkFBcUI7R0FDdkQsT0FBTyw4QkFBOEIsaUJBQWlCLE1BQU0sU0FBUyxXQUFXLDhCQUE4QixZQUFZLE1BQU0sU0FBUztFQUMzSTtFQUNBLFNBQVMsMEJBQTBCLE9BQU87R0FDeEMsTUFBTSxTQUFTLFFBQVEsUUFBUSxpQkFBaUI7R0FDaEQsTUFBTSx5QkFBeUIsUUFBUSxnQkFBZ0IsS0FBSyxTQUFTLFNBQVMsTUFBTSxDQUFDLENBQUMsTUFBSyxTQUFRLG9CQUFvQixPQUFPLEtBQUssU0FBUyxTQUFTLFFBQVEsQ0FBQztHQUM5SixPQUFPLHlCQUF5QixLQUFLLEtBQUs7RUFDNUM7RUFDQSxTQUFTLG9CQUFvQixPQUFPO0dBQ2xDLElBQUksa0JBQWtCLEtBQUssR0FBRztJQUc1QixJQUFJLE1BQU0sU0FBUyxXQUFXLENBQUMseUJBQXlCLEtBQUssR0FBRztLQUM5RCxpQ0FBaUMsTUFBTTtLQUN2Qyw0QkFBNEIsVUFBVTtJQUN4QztJQUNBLHFCQUFxQjtJQUNyQjtHQUNGO0dBQ0EsSUFBSSxRQUFRLFFBQVEsaUJBQWlCO0lBQ25DLHFCQUFxQjtJQUNyQjtHQUNGO0dBQ0EsTUFBTSxTQUFTLFVBQVUsS0FBSztHQUM5QixNQUFNLGdCQUFnQixJQUFJLGdCQUFnQixPQUFPLEVBQUU7R0FDbkQsTUFBTSxhQUFhLFVBQVUsTUFBTSxJQUFJLE9BQU8sWUFBWSxJQUFJO0dBQzlELE1BQU0sVUFBVSxNQUFNLE1BQU0sYUFBYSxVQUFVLElBQUksYUFBYSxjQUFjLE1BQU0sT0FBTyxpQkFBaUIsQ0FBQyxHQUFHLGlCQUFpQixhQUFhLENBQUM7R0FDbkosTUFBTSxXQUFXLE1BQU0sUUFBUTtHQUcvQixJQUFJLFdBQVcsU0FBUyxXQUFXLE1BQU0sS0FBSyxTQUFTLG9CQUFtQixZQUFXLFNBQVMsU0FBUyxNQUFNLENBQUMsSUFDNUc7R0FFRixJQUFJLHFCQUFxQixVQUFVLE1BQU0sSUFBSSxTQUFTO0dBQ3RELE9BQU8sc0JBQXNCLENBQUMsc0JBQXNCLGtCQUFrQixHQUFHO0lBQ3ZFLE1BQU0sYUFBYSxjQUFjLGtCQUFrQjtJQUNuRCxJQUFJLHNCQUFzQixVQUFVLEtBQUssQ0FBQyxVQUFVLFVBQVUsR0FDNUQ7SUFFRixxQkFBcUI7R0FDdkI7R0FJQSxJQUFJLFFBQVEsVUFBVSxVQUFVLE1BQU0sS0FBSyxDQUFDLGNBQWMsTUFBTSxLQUVoRSxDQUFDLFNBQVMsUUFBUSxNQUFNLE9BQU8saUJBQWlCLENBQUMsS0FHakQsUUFBUSxPQUFNLFdBQVUsQ0FBQyxTQUFTLG9CQUFvQixNQUFNLENBQUMsR0FDM0Q7R0FLRixJQUFJLGNBQWMsTUFBTSxLQUFLLEVBQUUsYUFBYSxRQUFRO0lBQ2xELE1BQU0sc0JBQXNCLHNCQUFzQixNQUFNO0lBQ3hELE1BQU0sUUFBUUMsbUJBQWlCLE1BQU07SUFDckMsTUFBTSxXQUFXO0lBQ2pCLE1BQU0sZ0JBQWdCLHVCQUF1QixTQUFTLEtBQUssTUFBTSxTQUFTO0lBQzFFLE1BQU0sZ0JBQWdCLHVCQUF1QixTQUFTLEtBQUssTUFBTSxTQUFTO0lBQzFFLE1BQU0sYUFBYSxpQkFBaUIsT0FBTyxjQUFjLEtBQUssT0FBTyxjQUFjLE9BQU87SUFDMUYsTUFBTSxhQUFhLGlCQUFpQixPQUFPLGVBQWUsS0FBSyxPQUFPLGVBQWUsT0FBTztJQUM1RixNQUFNLFFBQVEsTUFBTSxjQUFjO0lBT2xDLE1BQU0sMkJBQTJCLGVBQWUsUUFBUSxNQUFNLFdBQVcsT0FBTyxjQUFjLE9BQU8sY0FBYyxNQUFNLFVBQVUsT0FBTztJQUMxSSxNQUFNLDZCQUE2QixjQUFjLE1BQU0sVUFBVSxPQUFPO0lBQ3hFLElBQUksNEJBQTRCLDRCQUM5QjtHQUVKO0dBQ0EsSUFBSSwwQkFBMEIsS0FBSyxHQUNqQztHQUlGLElBQUkscUJBQXFCLE1BQU0sZUFBZTtJQUc1QyxJQUFJLE1BQU0sV0FBVyxLQUFLLENBQUMsZUFBZSxLQUFLLEtBQUssQ0FBQyxxQkFBcUIsU0FDeEU7SUFNRixJQUFJLDRCQUE0QixTQUFTO0tBQ3ZDLGlDQUFpQyxNQUFNO0tBQ3ZDLDRCQUE0QixVQUFVO0tBQ3RDO0lBQ0Y7R0FDRjtHQUNBLElBQUksT0FBT0ksbUJBQWlCLGNBQWMsQ0FBQ0EsZUFBYSxLQUFLLEdBQzNEO0dBRUYsSUFBSSxpQkFBaUIsdUJBQXVCLEdBQzFDO0dBRUYsTUFBTSxRQUFRLE9BQU8seUJBQXlCRyxjQUFzQixLQUFLLENBQUM7R0FDMUUscUJBQXFCO0VBQ3ZCO0VBQ0EsU0FBUyxrQkFBa0IsT0FBTztHQUNoQyxJQUFJLHFCQUFxQixNQUFNLFlBQVksTUFBTSxnQkFBZ0IsV0FBVyxDQUFDLE1BQU0sT0FBTyxNQUFNLEtBQUssQ0FBQyxXQUFXLHlCQUF5QixLQUFLLEdBQzdJO0dBRUYsb0JBQW9CLEtBQUs7RUFDM0I7RUFDQSxTQUFTLGlCQUFpQixPQUFPO0dBQy9CLElBQUkscUJBQXFCLE1BQU0sWUFBWSxDQUFDLE1BQU0sT0FBTyxNQUFNLEtBQUssQ0FBQyxXQUFXLHlCQUF5QixLQUFLLEdBQzVHO0dBRUYsTUFBTSxRQUFRLE1BQU0sUUFBUTtHQUM1QixJQUFJLE9BQU87SUFDVCxjQUFjLFVBQVU7S0FDdEIsV0FBVyxLQUFLLElBQUk7S0FDcEIsUUFBUSxNQUFNO0tBQ2QsUUFBUSxNQUFNO0tBQ2QsbUJBQW1CO0tBQ25CLG9CQUFvQjtJQUN0QjtJQUNBLDBCQUEwQixNQUFNLFdBQVk7S0FDMUMsSUFBSSxjQUFjLFNBQVM7TUFDekIsY0FBYyxRQUFRLG9CQUFvQjtNQUMxQyxjQUFjLFFBQVEscUJBQXFCO0tBQzdDO0lBQ0YsQ0FBQztHQUNIO0VBQ0Y7RUFDQSxTQUFTLDJCQUEyQixPQUFPLFVBQVU7R0FDbkQsTUFBTSxTQUFTLFVBQVUsS0FBSztHQUM5QixJQUFJLENBQUMsUUFDSDtHQUVGLE1BQU0sY0FBYyxpQkFBaUIsUUFBUSxNQUFNLFlBQVk7SUFDN0QsU0FBUyxLQUFLO0lBQ2QsWUFBWTtHQUNkLENBQUM7RUFDSDtFQUNBLFNBQVMsd0JBQXdCLE9BQU87R0FDdEMsc0JBQXNCLFVBQVU7R0FDaEMsMkJBQTJCLE9BQU8sZ0JBQWdCO0VBQ3BEO0VBQ0EsU0FBUywyQkFBMkIsT0FBTztHQUN6QywwQkFBMEIsTUFBTTtHQUloQyxJQUFJLE1BQU0sU0FBUyxlQUFlO0lBRWhDLElBQUksTUFBTSxXQUFXLEdBQ25CLHFCQUFxQixVQUFVO0lBRWpDLHNCQUFzQixVQUFVLE1BQU07R0FDeEM7R0FDQSxJQUFJLE1BQU0sU0FBUyxlQUFlLGNBQWMsV0FBVyxDQUFDLGNBQWMsUUFBUSxvQkFDaEY7R0FFRiwyQkFBMkIsUUFBTyxnQkFBZTtJQUMvQyxJQUFJLFlBQVksU0FBUyxlQUN2QixrQkFBa0IsV0FBVztTQUU3QixvQkFBb0IsV0FBVztHQUVuQyxDQUFDO0VBQ0g7RUFDQSxTQUFTLHNCQUFzQixPQUFPO0dBR3BDLElBQUksTUFBTSxTQUFTLGlCQUNqQixxQkFBcUIsVUFBVTtHQUVqQyxJQUFJLENBQUMsc0JBQXNCLFNBQ3pCO0dBRUYsTUFBTSxxQ0FBcUMsdUJBQXVCO0dBQ2xFLHFCQUFxQjtHQUNyQixJQUFJLHFCQUFxQixNQUFNLGVBQzdCO0dBRUYsSUFBSSxNQUFNLFNBQVMsaUJBQWlCO0lBQ2xDLElBQUksb0NBQ0YsaURBQWlEO0lBRW5EO0dBQ0Y7R0FDQSxJQUFJLDBCQUEwQixLQUFLLEdBQ2pDO0dBT0YsSUFBSSxvQ0FBb0M7SUFDdEMsaURBQWlEO0lBQ2pEO0dBQ0Y7R0FHQSxJQUFJLE9BQU9ILG1CQUFpQixjQUFjLENBQUNBLGVBQWEsS0FBSyxHQUMzRDtHQUVGLGlDQUFpQyxNQUFNO0dBQ3ZDLDRCQUE0QixVQUFVO0dBQ3RDLHFCQUFxQjtFQUN2QjtFQUNBLFNBQVMsZ0JBQWdCLE9BQU87R0FDOUIsSUFBSSxxQkFBcUIsTUFBTSxZQUFZLENBQUMsY0FBYyxXQUFXLHlCQUF5QixLQUFLLEdBQ2pHO0dBRUYsTUFBTSxRQUFRLE1BQU0sUUFBUTtHQUM1QixJQUFJLENBQUMsT0FDSDtHQUVGLE1BQU0sU0FBUyxLQUFLLElBQUksTUFBTSxVQUFVLGNBQWMsUUFBUSxNQUFNO0dBQ3BFLE1BQU0sU0FBUyxLQUFLLElBQUksTUFBTSxVQUFVLGNBQWMsUUFBUSxNQUFNO0dBQ3BFLE1BQU0sV0FBVyxLQUFLLEtBQUssU0FBUyxTQUFTLFNBQVMsTUFBTTtHQUM1RCxJQUFJLFdBQVcsR0FDYixjQUFjLFFBQVEsb0JBQW9CO0dBRTVDLElBQUksV0FBVyxJQUFJO0lBQ2pCLG9CQUFvQixLQUFLO0lBQ3pCLDBCQUEwQixNQUFNO0lBQ2hDLGNBQWMsVUFBVTtHQUMxQjtFQUNGO0VBQ0EsU0FBUyx1QkFBdUIsT0FBTztHQUNyQywyQkFBMkIsT0FBTyxlQUFlO0VBQ25EO0VBQ0EsU0FBUyxlQUFlLE9BQU87R0FDN0IsSUFBSSxxQkFBcUIsTUFBTSxZQUFZLENBQUMsY0FBYyxXQUFXLHlCQUF5QixLQUFLLEdBQ2pHO0dBRUYsSUFBSSxjQUFjLFFBQVEsbUJBQ3hCLG9CQUFvQixLQUFLO0dBRTNCLDBCQUEwQixNQUFNO0dBQ2hDLGNBQWMsVUFBVTtFQUMxQjtFQUNBLFNBQVMsc0JBQXNCLE9BQU87R0FDcEMsMkJBQTJCLE9BQU8sY0FBYztFQUNsRDtFQUNBLE1BQU0sY0FBYyxjQUFjQyxlQUFhLGNBQWMsaUJBQWlCLEtBQUssV0FBVyxvQkFBb0IsR0FBRyxpQkFBaUIsS0FBSyxvQkFBb0Isc0JBQXNCLEdBQUcsaUJBQWlCLEtBQUssa0JBQWtCLG9CQUFvQixDQUFDLEdBQUcsdUJBQXVCLGNBQWMsaUJBQWlCLEtBQUssU0FBUyw0QkFBNEIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLGVBQWUsNEJBQTRCLElBQUksR0FBRyxpQkFBaUIsS0FBSyxhQUFhLHVCQUF1QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssaUJBQWlCLHVCQUF1QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssYUFBYSw0QkFBNEIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLFdBQVcsdUJBQXVCLElBQUksR0FBRyxpQkFBaUIsS0FBSyxjQUFjLHlCQUF5QjtHQUM3dUIsU0FBUztHQUNULFNBQVM7RUFDWCxDQUFDLEdBQUcsaUJBQWlCLEtBQUssYUFBYSx3QkFBd0I7R0FDN0QsU0FBUztHQUNULFNBQVM7RUFDWCxDQUFDLEdBQUcsaUJBQWlCLEtBQUssWUFBWSx1QkFBdUI7R0FDM0QsU0FBUztHQUNULFNBQVM7RUFDWCxDQUFDLENBQUMsQ0FBQztFQUNILGFBQWE7R0FDWCxZQUFZO0dBQ1osaUNBQWlDLE1BQU07R0FDdkMscUJBQXFCO0dBQ3JCLDRCQUE0QixVQUFVO0VBQ3hDO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBaUJBO0VBQVc7RUFBcUJEO0VBQWM7RUFBTTtFQUFTO0VBQWtCO0VBQXFCO0VBQXNCO0VBQXNCO0VBQTBCO0VBQWtCO0VBQTBCO0VBQU07RUFBTztFQUEyQjtDQUFrQixDQUFDO0NBQy9TLE1BQU0seUJBQWtCLGVBQWU7RUFDckMsV0FBVztFQUNYLGVBQWU7RUFDZixTQUFTO0NBQ1gsSUFBSSxDQUFDLHNCQUFzQixxQkFBcUIsQ0FBQztDQUNqRCxNQUFNLHdCQUFpQixlQUFlO0VBQ3BDLFdBQVc7RUFJWCxlQUFlO0VBQ2YsYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixtQkFBbUIsT0FBTztHQUN4QixvQkFBb0I7R0FDcEIsZ0NBQWdDLEtBQUs7RUFDdkM7RUFDQSxxQkFBcUIsT0FBTztHQUMxQixvQkFBb0I7R0FDcEIsZ0NBQWdDLEtBQUs7RUFDdkM7RUFDQSxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLG9CQUFvQjtDQUN0QixJQUFJO0VBQUM7RUFBc0I7RUFBcUI7RUFBaUM7Q0FBNkIsQ0FBQztDQUMvRyxvQkFBYSxjQUFjLFVBQVU7RUFDbkM7RUFDQTtFQUNBLFNBQVM7Q0FDWCxJQUFJLENBQUMsR0FBRztFQUFDO0VBQVM7RUFBVztDQUFRLENBQUM7QUFDeEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL2RBLElBQWEsa0JBQWIsTUFBNkI7Ozs7Ozs7Q0FPM0IsaUJBQWlCLENBQUM7Ozs7O0NBTWxCLHFCQUFxQjs7OztDQUtyQixpQ0FBaUIsSUFBSSxJQUFJOzs7Ozs7Ozs7Ozs7OztDQWV6QixZQUFZLGVBQWUsZUFBZSx3QkFBd0IsTUFBTTtFQUN0RSxLQUFLLGdCQUFnQjtFQUNyQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLHdCQUF3QjtDQUMvQjtDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU8sS0FBSztDQUNkOzs7Ozs7Q0FPQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssc0JBQXNCLEtBQUs7Q0FDekM7Ozs7OztDQU9BLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUs7Q0FDZDs7Ozs7O0NBT0EsZUFBZSxVQUFVO0VBQ3ZCLEtBQUssZUFBZSxJQUFJLFFBQVE7RUFDaEMsYUFBYTtHQUNYLEtBQUssZUFBZSxPQUFPLFFBQVE7RUFDckM7Q0FDRjs7Ozs7OztDQVFBLFlBQVksVUFBVTtFQUNwQixLQUFLLGVBQWUsS0FBSyxRQUFRO0VBQ2pDLEtBQUssZUFBZSxRQUFRO0VBRTFCLElBQUksS0FBSyxlQUFlLFNBQVMsR0FBRztHQVFsQyxNQUFNLE1BQU07R0FDWixDQUFDLElBQUksd0JBQXdCLGVBQWUsT0FBTyxHQUFHLGNBQWM7SUFDbEUsSUFBSSxLQUFLLGVBQWUsU0FBUyxHQUMvQixRQUFRLEtBQUssZ1JBQTBSO0dBRTNTLENBQUM7RUFDSDtFQUVGLGFBQWE7R0FDWCxNQUFNLFFBQVEsS0FBSyxlQUFlLFlBQVksUUFBUTtHQUN0RCxJQUFJLFVBQVUsSUFDWixLQUFLLGVBQWUsT0FBTyxPQUFPLENBQUM7R0FLckMsS0FBSyxlQUFlLEtBQUssZUFBZSxLQUFLLGVBQWUsU0FBUyxNQUFNLElBQUk7RUFDakY7Q0FDRjs7Ozs7Q0FNQSxlQUFlLE9BQU87RUFDcEIsSUFBSSxLQUFLLHVCQUF1QixPQUFPO0dBQ3JDLEtBQUsscUJBQXFCO0dBQzFCLEtBQUssZUFBZSxTQUFRLGFBQVk7SUFDdEMsU0FBUztHQUNYLENBQUM7RUFDSDtDQUNGOzs7Ozs7Ozs7Ozs7OztDQWVBLGNBQWMsV0FBVztFQUN2QixNQUFNLGdCQUFnQixLQUFLO0VBQzNCLElBQUksa0JBQWtCLE1BQU07R0FFeEIsUUFBUSxLQUFLLFlBQVksS0FBSyxjQUFjLHlKQUE4SjtHQUU1TTtFQUNGO0VBU0EsSUFBSTtFQUNKLElBQUksV0FBVztHQUNiLEtBQUssSUFBSSxJQUFJLEtBQUssZUFBZSxTQUFTLEdBQUcsS0FBSyxLQUFLLENBQUMsZ0JBQWdCLEtBQUssR0FDM0UsaUJBQWlCLEtBQUssZUFBZSxFQUFFLENBQUMsUUFBUSxnQkFBZ0IsUUFBUSxTQUFTO0dBRW5GLG1CQUFtQixLQUFLLGNBQWMsUUFBUSxnQkFBZ0IsUUFBUSxTQUFTO0VBQ2pGO0VBQ0EsSUFBSSxhQUFhLENBQUMsZ0JBQWdCO0dBQ2hDLElBQUksS0FBSyx1QkFDUCxNQUFNLElBQUksTUFBOEMsWUFBWSxLQUFLLGNBQWMsZ0RBQWdELFVBQVUsb0pBQW1LLEtBQUssY0FBYyx3REFBcUk7R0FHNWMsUUFBUSxLQUFLLFlBQVksS0FBSyxjQUFjLHlDQUF5QyxVQUFVLHdFQUE2RTtFQUVoTDtFQUNBLGNBQWMsUUFBUSxNQUFNLHlCQUF5Qkksa0JBQTBCLFFBQVcsY0FBYyxDQUFDO0NBQzNHOzs7Ozs7O0NBUUEsYUFBYTtFQUNYLE1BQU0sZ0JBQWdCLEtBQUs7RUFDM0IsSUFBSSxrQkFBa0IsTUFBTTtHQUV4QixRQUFRLEtBQUssWUFBWSxLQUFLLGNBQWMsNEZBQWlHO0dBRS9JO0VBQ0Y7RUFDQSxjQUFjLFFBQVEsT0FBTyx5QkFBeUJBLGdCQUF3QixDQUFDO0NBQ2pGO0FBQ0Y7Ozs7Ozs7OztBQ2hOQSxTQUFnQiw2QkFBNkIsU0FBUztDQUNwRCxNQUFNLEVBQ0osWUFDQSw4QkFBOEIsT0FDOUIscUJBQXFCLE9BQ3JCLFlBQ0EsUUFDQSxpQkFDRTtDQUNKLE1BQU0sT0FBTyxXQUFXLFNBQVMsTUFBTTtDQUN2QyxNQUFNLG1CQUFtQixXQUFXLFNBQVMsc0JBQXNCO0NBQ25FLE1BQU0sa0JBQWtCLFdBQVcsU0FBUyw4QkFBOEIsaUJBQWlCLG1CQUFtQjtDQUM5RyxNQUFNLG1CQUFtQjtDQUN6QixXQUFXLGVBQWUsY0FBYyxVQUFVO0NBQ2xELHlCQUF5QjtFQUN2QixNQUFNLGVBQWU7R0FDbkI7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLElBQUksVUFBVSxnQkFBZ0IsR0FDNUIsYUFBYSxzQkFBc0I7RUFFckMsSUFBSSxNQUFNLE1BQU0sc0JBQXNCLE1BQU0sTUFBTSxrQkFDaEQsYUFBYSxvQkFBb0I7RUFFbkMsTUFBTSxPQUFPLFlBQVk7Q0FDM0IsR0FBRztFQUFDO0VBQU07RUFBWTtFQUFrQjtFQUFpQjtDQUFLLENBQUM7Q0FHL0QsTUFBTSxRQUFRLGVBQWU7Q0FDN0IsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsT0FBTztBQUNUOzs7Ozs7Ozs7OztBQ2pDQSxTQUFnQixvQkFBb0IsTUFBTSxrQkFBa0IsT0FBTyxtQkFBbUIsT0FBTyxxQkFBcUIsT0FBTztDQUN2SCxNQUFNLENBQUMsa0JBQWtCLG9DQUE2QixTQUFTLFFBQVEsa0JBQWtCLFNBQVMsTUFBUztDQUkzRyxNQUFNLENBQUMsU0FBUywyQkFBb0IsU0FBUyxRQUFRLENBQUMsa0JBQWtCO0NBQ3hFLElBQUksUUFBUSxDQUFDLFNBQVM7RUFDcEIsV0FBVyxJQUFJO0VBQ2Ysb0JBQW9CLFVBQVU7Q0FDaEM7Q0FDQSxJQUFJLENBQUMsUUFBUSxXQUFXLHFCQUFxQixZQUFZLENBQUMsa0JBQ3hELG9CQUFvQixRQUFRO0NBRTlCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxxQkFBcUIsVUFDNUMsb0JBQW9CLE1BQVM7Q0FFL0IseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxRQUFRLFdBQVcscUJBQXFCLFlBQVksa0JBQWtCO0dBQ3pFLE1BQU0sUUFBUSxlQUFlLGNBQWM7SUFDekMsb0JBQW9CLFFBQVE7R0FDOUIsQ0FBQztHQUNELGFBQWE7SUFDWCxlQUFlLE9BQU8sS0FBSztHQUM3QjtFQUNGO0NBRUYsR0FBRztFQUFDO0VBQU07RUFBUztFQUFrQjtDQUFnQixDQUFDO0NBQ3RELHlCQUF5QjtFQUV2QixJQUFJLENBQUMsUUFBUSxtQkFBbUIscUJBQXFCLFFBQ25EO0VBRUYsTUFBTSxRQUFRLGVBQWUsY0FBYztHQUd6QyxvQkFBb0IsTUFBUztFQUMvQixDQUFDO0VBQ0QsYUFBYTtHQUNYLGVBQWUsT0FBTyxLQUFLO0VBQzdCO0NBQ0YsR0FBRztFQUFDO0VBQWlCO0VBQU07Q0FBZ0IsQ0FBQztDQUM1Qyx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFDWjtFQUVGLElBQUksUUFBUSxXQUFXLHFCQUFxQixRQUMxQyxvQkFBb0IsVUFBVTtFQUVoQyxNQUFNLFFBQVEsZUFBZSxjQUFjO0dBQ3pDLG9CQUFvQixNQUFNO0VBQzVCLENBQUM7RUFDRCxhQUFhO0dBQ1gsZUFBZSxPQUFPLEtBQUs7RUFDN0I7Q0FDRixHQUFHO0VBQUM7RUFBaUI7RUFBTTtFQUFTO0NBQWdCLENBQUM7Q0FDckQsT0FBTztFQUNMO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7Ozs7O0FDdkVBLFNBQWdCLG9CQUFvQixTQUFTLFNBQVM7Q0FDcEQsT0FBTyxRQUFRLGNBQWMsT0FBTyxDQUFDLENBQUMsUUFBTyxjQUFhO0VBQ3hELE1BQU0sU0FBUyxVQUFVLFFBQVEsVUFBVTtFQUMzQyxPQUFPLFFBQVEsYUFBYSxZQUFZLFFBQVEsZUFBZTtDQUNqRSxDQUFDO0FBQ0g7O0FDQ0EsSUFBSSxtQkFBbUI7Ozs7Ozs7O0FBU3ZCLFNBQVMsaUJBQWlCLElBQUk7Q0FDNUIsSUFBSSxDQUFDLGtCQUFrQjtFQUNyQixNQUFNLFlBQVksQ0FBQztFQUNuQixtQkFBbUI7RUFDbkIscUJBQXFCO0dBQ25CLG1CQUFtQjtHQUNuQixpQkFBUyxnQkFBZ0I7SUFDdkIsS0FBSyxNQUFNLFlBQVksV0FDckIsU0FBUztHQUViLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxpQkFBaUIsS0FBSyxFQUFFO0FBQzFCOzs7Ozs7Ozs7OztBQVlBLFNBQWdCLHNCQUFzQixjQUFjLDhCQUE4QixPQUFPLFFBQVEsT0FBTztDQUN0RyxNQUFNLFFBQVEsa0JBQWtCO0NBQ2hDLE9BQU8sbUJBQW1CLGFBTTFCLFNBQVMsU0FBUztFQUNoQixNQUFNLE9BQU87RUFDYixNQUFNLFVBQVUsV0FBVyxZQUFZO0VBQ3ZDLElBQUksV0FBVyxNQUNiO0VBRUYsTUFBTSxrQkFBa0I7RUFDeEIsTUFBTSxhQUFhO0dBQ2pCLElBQUksQ0FBQyxPQUFPO0lBS1YsaUJBQVMsVUFBVSxXQUFXO0lBQzlCO0dBQ0Y7R0FDQSx1QkFBdUI7SUFFckIsSUFBSSxDQUFDLFFBQVEsU0FDWCxZQUFZO0dBRWhCLENBQUM7RUFDSDtFQUNBLElBQUksT0FBTyxnQkFBZ0Isa0JBQWtCLGNBQWMsV0FBVyw2QkFBNkI7R0FDakcsWUFBWTtHQUNaO0VBQ0Y7RUFDQSxTQUFTLE9BQU87R0FFZCxRQUFRLElBQUksb0JBQW9CLGVBQWUsQ0FBQyxDQUFDLEtBQUksY0FBYSxVQUFVLFNBQVMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVztJQUMzRyxJQUFJLENBQUMsUUFBUSxTQUNYLEtBQUs7R0FFVCxTQUFTO0lBQ1AsSUFBSSxRQUFRLFNBQ1Y7SUFHRixJQUQwQixvQkFBb0IsZUFDMUIsQ0FBQyxDQUFDLE1BQUssY0FBYSxVQUFVLFdBQVcsVUFBVSxjQUFjLFVBQVUsR0FBRztLQUdoRyxLQUFLO0tBQ0w7SUFDRjtJQUNBLEtBQUs7R0FDUCxDQUFDO0VBQ0g7RUFDQSxJQUFJLDZCQUE2QjtHQUMvQixNQUFNLHlCQUF5QnRCO0dBSS9CLElBQUksQ0FBQyxnQkFBZ0IsYUFBYSxzQkFBc0IsR0FBRztJQUN6RCxNQUFNLFFBQVEsSUFBSTtJQUNsQjtHQUNGO0dBR0EsTUFBTSxvQkFBb0IsSUFBSSx1QkFBdUI7SUFDbkQsSUFBSSxDQUFDLGdCQUFnQixhQUFhLHNCQUFzQixHQUFHO0tBQ3pELGtCQUFrQixXQUFXO0tBQzdCLEtBQUs7SUFDUDtHQUNGLENBQUM7R0FDRCxrQkFBa0IsUUFBUSxpQkFBaUI7SUFDekMsWUFBWTtJQUNaLGlCQUFpQixDQUFDLHNCQUFzQjtHQUMxQyxDQUFDO0dBQ0QsUUFBUSxpQkFBaUIsZUFBZSxrQkFBa0IsV0FBVyxHQUFHLEVBQ3RFLE1BQU0sS0FDUixDQUFDO0dBQ0Q7RUFDRjtFQUNBLE1BQU0sUUFBUSxJQUFJO0NBQ3BCLENBQUM7QUFDSDs7Ozs7QUN0SEEsU0FBZ0Isc0JBQXNCLFlBQVk7Q0FDaEQsTUFBTSxFQUNKLFVBQVUsTUFDVixNQUNBLEtBQ0EsUUFBUSxPQUNSLFlBQVksb0JBQ1Y7Q0FDSixNQUFNLGFBQWEsa0JBQWtCLGVBQWU7Q0FDcEQsTUFBTSwwQkFBMEIsc0JBQXNCLEtBQUssTUFBTSxLQUFLO0NBQ3RFLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxTQUNIO0VBRUYsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDNUMsd0JBQXdCLFlBQVksZ0JBQWdCLE1BQU07RUFDMUQsYUFBYTtHQUNYLGdCQUFnQixNQUFNO0VBQ3hCO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBTTtFQUFZO0NBQXVCLENBQUM7QUFDekQ7Ozs7Ozs7Ozs7O0FDWkEsU0FBZ0IscUJBQXFCLFlBQVk7Q0FDL0MsTUFBTSxFQUNKLE1BQ0EsS0FDQSx1QkFDQSwwQkFBMEIsK0JBQzFCLFdBQ0EsdUJBQ0U7Q0FDSixNQUFNLDJCQUEyQixrQkFBa0IsNkJBQTZCO0NBQ2hGLE1BQU0sRUFDSixTQUNBLFlBQ0EscUJBQ0Usb0JBQW9CLE1BQU0sT0FBTyxPQUFPLGtCQUFrQjtDQU85RCxNQUFNLDJCQUEyQixPQUFPLFFBQVE7Q0FDaEQseUJBQXlCO0VBQ3ZCLElBQUksTUFDRix5QkFBeUIsS0FBSztDQUVsQyxHQUFHLENBQUMsTUFBTSx3QkFBd0IsQ0FBQztDQU1uQyxNQUFNLDBCQUFtQixPQUFPLE9BQU87Q0FDdkMsTUFBTSxpQ0FBMEIsT0FBTyxLQUFLO0NBQzVDLE1BQU0sV0FBVyxxQkFBcUI7Q0FDdEMsTUFBTSxnQkFBZ0I7RUFDcEIsV0FBVyxVQUFVO0VBQ3JCLFdBQVcsS0FBSztFQUNoQixVQUFVO0NBQ1o7Q0FDQSx5QkFBeUI7RUFDdkIsV0FBVyxVQUFVO0VBQ3JCLElBQUksa0JBQWtCLFNBQVM7R0FDN0Isa0JBQWtCLFVBQVU7R0FDNUIsSUFBSSxDQUFDLFFBQVEsU0FDWCxRQUFRO0VBRVo7Q0FDRixDQUFDO0NBQ0QsTUFBTSxlQUFlLHdCQUF3QjtFQUMzQyxJQUFJLENBQUMsV0FBVyxTQUNkO0VBRUYsSUFBSSxNQUFNO0dBS1Isa0JBQWtCLFVBQVU7R0FDNUIsU0FBUztHQUNUO0VBQ0Y7RUFDQSxRQUFRO0NBQ1YsQ0FBQztDQUNELHNCQUFzQjtFQUNwQixTQUFTLFdBQVcsQ0FBQyxRQUFRLENBQUM7RUFDOUI7RUFDQTtFQUNBLGFBQWE7R0FDWCxJQUFJLENBQUMsTUFDSCxhQUFhO0VBRWpCO0NBQ0YsQ0FBQztDQUNELE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7O0FDbEZBLElBQWEsd0JBQXdCO0NBQ25DLFVBQVU7RUFDVCxzQkFBc0I7QUFDekI7Ozs7OztBQU9BLFNBQWdCLDBCQUEwQixVQUFVO0NBQ2xELFFBQU8sb0JBQW1CLG9CQUFvQixVQUFVLFNBQVMsVUFBVTtBQUM3RTs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQWdCLGtCQUFrQixhQUFhLDhCQUE4QixPQUFPO0NBQ2xGLE1BQU0sYUFBYSxNQUFNO0NBQ3pCLE1BQU0sU0FBUyx3QkFBd0IsS0FBSztDQUM1QyxNQUFNLFFBQVEscUJBQXFCLFlBQVksWUFBWSxNQUFNLENBQUMsQ0FBQyxDQUFDO0NBQ3BFLDZCQUE2QjtFQUMzQixZQUFZO0VBQ1o7RUFDQSxxQkFBcUIsTUFBTSxNQUFNO0VBQ2pDO0VBQ0E7RUFDQSxjQUFjLE1BQU07Q0FDdEIsQ0FBQztDQUNELE9BQU87QUFDVDs7Ozs7Ozs7Ozs7QUFZQSxTQUFnQixzQkFBc0IsRUFDcEMsUUFDQSxTQUNDO0NBQ0QseUJBQXlCO0VBQ3ZCLE9BQU8sT0FBTyxZQUFZLEtBQUs7Q0FDakMsR0FBRyxDQUFDLFFBQVEsS0FBSyxDQUFDO0NBQ2xCLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLE9BQU87Q0FDL0IsTUFBTSxlQUFlLE1BQU0sUUFBUSxnQkFBZ0I7Q0FDbkQsSUFBSSxNQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sTUFBTSxpQkFBaUIsY0FDdkQsTUFBTSxJQUFJLGdCQUFnQixZQUFZO0FBRTFDOzs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQWdCLHVCQUF1QixJQUFJLE9BQU87Q0FDaEQsTUFBTSwrQkFBd0IsT0FBTyxJQUFJO0NBQ3pDLE9BQU8sbUJBQWtCLFlBQVc7RUFDbEMsTUFBTSxlQUFlLGdCQUFnQjtFQUNyQyxJQUFJLGlCQUFpQixNQUFNO0dBQ3pCLElBQUksYUFBYSxZQUFZLFdBQVcsYUFBYSxVQUFVLFNBQVMsYUFBYSxPQUFPLElBRTFGO0dBRUYsZ0JBQWdCLFVBQVU7R0FDMUIsTUFBTSxrQkFBa0IsYUFBYTtHQUNyQyxJQUFJLGdCQUFnQixRQUFRLGdCQUFnQixRQUFRLGFBQWEsRUFBRSxNQUFNLGFBQWEsU0FBUztJQUM3RixnQkFBZ0IsUUFBUSxnQkFBZ0IsT0FBTyxhQUFhLEVBQUU7SUFDOUQsaUJBQWlCLGVBQWU7R0FDbEM7RUFDRjtFQUNBLElBQUksWUFBWSxRQUFRLE9BQU8sUUFBVztHQUN4QyxnQkFBZ0IsVUFBVTtJQUN4QjtJQUNBO0lBQ0E7R0FDRjtHQUNBLE1BQU0sUUFBUSxnQkFBZ0IsSUFBSSxJQUFJLE9BQU87R0FDN0MsaUJBQWlCLEtBQUs7RUFDeEI7Q0FDRixDQUFDO0FBQ0g7QUFDQSxTQUFnQixxQkFBcUIsT0FBTyxNQUFNLFNBQVMsd0JBQXdCLE9BQU87Q0FDeEYsSUFBSSwyQkFBMkIsTUFBTTtDQUNyQyxJQUFJLE1BRUYsMkJBQTJCO01BQ3RCLElBQUksdUJBQ1QsMkJBQTJCO0NBRTdCLE1BQU0sWUFBWSxTQUFTLE1BQU07Q0FDakMsSUFBSSxrQkFBa0IsTUFBTTtDQUM1QixJQUFJLHVCQUF1QixNQUFNO0NBSWpDLElBQUksYUFBYSxNQUFNO0VBQ3JCLGtCQUFrQjtFQUNsQix1QkFBdUIsV0FBVztDQUNwQztDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQU1BLHNCQUFzQixPQUFPLFdBQVcsT0FBTyxNQUFNO0NBQ3ZEO0FBQ0Y7Ozs7Ozs7OztBQTREQSxTQUFnQix5QkFBeUIsV0FBVyxtQkFBbUIsT0FBTyxjQUFjO0NBQzFGLE1BQU0seUJBQXlCLE1BQU0sU0FBUyxzQkFBc0IsU0FBUztDQUM3RSxNQUFNLHNCQUFzQix1QkFBdUIsV0FBVyxLQUFLO0NBS25FLE1BQU0sbUJBQW1CLG1CQUFrQixZQUFXO0VBQ3BELE1BQU0sT0FBTyxNQUFNLE9BQU8sTUFBTTtFQUNoQyxNQUFNLGtCQUFrQixNQUFNLE9BQU8saUJBQWlCO0VBQ3RELElBQUksb0JBQW9CLFdBQVc7R0FDakMsTUFBTSxVQUFVO0lBQ2Qsc0JBQXNCO0lBQ3RCLEdBQUksT0FBTyxlQUFlO0dBQzVCO0dBQ0EsTUFBTSxPQUFPLE9BQU87R0FDcEI7RUFDRjtFQUNBLElBQUksbUJBQW1CLFFBQVEsUUFBUSxDQUFDLE1BQU0sTUFBTSxzQkFBc0I7R0FLeEUsTUFBTSxVQUFVO0lBQ2QsaUJBQWlCLGFBQWE7SUFDOUIsc0JBQXNCO0lBQ3RCLEdBQUc7R0FDTDtHQUNBLE1BQU0sT0FBTyxPQUFPO0VBQ3RCO0NBQ0YsQ0FBQztDQUlELE1BQU0sa0JBQWtCLG1CQUFrQixZQUFXO0VBQ25ELG9CQUFvQixPQUFPO0VBQzNCLElBQUksU0FDRixpQkFBaUIsT0FBTztDQUU1QixDQUFDO0NBSUQseUJBQXlCO0VBQ3ZCLGdCQUFnQixrQkFBa0IsT0FBTztFQUN6QyxhQUFhLGdCQUFnQixJQUFJO0NBQ25DLEdBQUc7RUFBQztFQUFpQjtFQUFtQjtFQUFPO0NBQVMsQ0FBQztDQUN6RCx5QkFBeUI7RUFDdkIsSUFBSSx3QkFBd0I7R0FDMUIsTUFBTSxVQUFVO0lBQ2Qsc0JBQXNCLGtCQUFrQjtJQUN4QyxHQUFHO0dBQ0w7R0FDQSxNQUFNLE9BQU8sT0FBTztFQUN0QjtDQUVGLEdBQUc7RUFBQztFQUF3QjtFQUFPO0VBQW1CLEdBQUcsT0FBTyxPQUFPLFlBQVk7Q0FBQyxDQUFDO0NBQ3JGLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBd0JBLFNBQWdCLHlCQUF5QixPQUFPLFVBQVUsQ0FBQyxHQUFHO0NBQzVELE1BQU0sRUFDSiw4QkFBOEIsVUFDNUI7Q0FFSixNQUFNLDBDQUFtQyxPQUFPLElBQUk7Q0FDcEQsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sdUJBQXVCLE1BQU0sU0FBUyxjQUFjO0NBRzFELE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxpQkFBaUI7Q0FNeEQsTUFBTSwrQkFBK0IsTUFBTSxTQUFTLHNCQUFzQjtDQUMxRSx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLE1BQU07R0FDVCwyQkFBMkIsVUFBVTtHQUNyQyxJQUFJLE1BQU0sTUFBTSxpQkFBaUIsR0FDL0IsTUFBTSxJQUFJLGdCQUFnQixDQUFDO0dBSzdCLElBQUksTUFBTSxNQUFNLHNCQUNkLE1BQU0sSUFBSSx3QkFBd0IsS0FBSztHQUV6QztFQUNGO0VBQ0EsTUFBTSxlQUFlLE1BQU0sUUFBUSxnQkFBZ0I7RUFDbkQsTUFBTSxlQUFlLENBQUM7RUFDdEIsSUFBSSxNQUFNLE1BQU0saUJBQWlCLGNBQy9CLGFBQWEsZUFBZTtFQUU5QixNQUFNLHlCQUF5QixNQUFNLE9BQU8saUJBQWlCO0VBQzdELElBQUksc0JBQXNCO0VBQzFCLElBQUksd0JBQXdCO0dBQzFCLE1BQU0sdUJBQXVCLE1BQU0sUUFBUSxnQkFBZ0IsUUFBUSxzQkFBc0I7R0FDekYsSUFBSSxDQUFDLHNCQUFzQjtJQUN6QixLQUFLLE1BQU0sQ0FBQyxXQUFXLG1CQUFtQixNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsR0FDOUUsSUFBSSxtQkFBbUIsTUFBTSxNQUFNLHNCQUFzQjtLQUN2RCxhQUFhLGtCQUFrQjtLQUMvQixhQUFhLHVCQUF1QjtLQUNwQywyQkFBMkIsVUFBVTtLQUNyQztJQUNGO0lBRUYsSUFBSSxhQUFhLG9CQUFvQixRQUFXO0tBQzlDLElBQUksMkJBQTJCLFlBQVksd0JBQ3pDLHNCQUFzQjtVQUV0QiwyQkFBMkIsVUFBVTtJQUV6QztHQUNGLE9BQU87SUFDTCwyQkFBMkIsVUFBVTtJQUNyQyxJQUFJLHlCQUF5QixNQUFNLE1BQU0sc0JBQ3ZDLGFBQWEsdUJBQXVCO0dBRXhDO0VBQ0YsT0FDRSwyQkFBMkIsVUFBVTtFQUV2QyxJQUFJLENBQUMsdUJBQXVCLENBQUMsMEJBQTBCLENBQUMsTUFBTSxNQUFNLHdCQUF3QixpQkFBaUIsR0FBRztHQUM5RyxNQUFNLGlCQUFpQixNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsQ0FBQyxDQUFDLEtBQUs7R0FDcEUsSUFBSSxDQUFDLGVBQWUsTUFBTTtJQUN4QixNQUFNLENBQUMsbUJBQW1CLDBCQUEwQixlQUFlO0lBQ25FLGFBQWEsa0JBQWtCO0lBQy9CLGFBQWEsdUJBQXVCO0lBQ3BDLDJCQUEyQixVQUFVO0dBQ3ZDO0VBQ0Y7RUFDQSxJQUFJLGFBQWEsaUJBQWlCLFVBQWEsYUFBYSxvQkFBb0IsVUFBYSxhQUFhLHlCQUF5QixRQUNqSSxNQUFNLE9BQU8sWUFBWTtFQUUzQixJQUFJLHFCQUNFO09BQUEsNkJBRUYscUJBQXFCO0lBQ25CLElBQUksTUFBTSxPQUFPLE1BQU0sS0FBSyxNQUFNLE9BQU8saUJBQWlCLE1BQU0sdUJBQXVCLENBQUMsTUFBTSxRQUFRLGdCQUFnQixRQUFRLG1CQUFtQixHQUFHO0tBQ2xKLE1BQU0sZUFBZSx5QkFBeUJ1QixJQUFZO0tBQzFELE1BQU0sUUFBUSxPQUFPLFlBQVk7S0FHakMsSUFBSSxDQUFDLGFBQWEsWUFDaEIsTUFBTSxPQUFPO01BQ1gsaUJBQWlCO01BQ2pCLHNCQUFzQjtLQUN4QixDQUFDO0lBRUw7R0FDRixDQUFDO0VBQUE7Q0FHUCxHQUFHO0VBQUM7RUFBTTtFQUFPO0VBQXNCO0VBQWlCO0VBQThCO0NBQTJCLENBQUM7QUFDcEg7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JBLFNBQWdCLHdCQUF3QixNQUFNLE9BQU8sV0FBVyxvQkFBb0I7Q0FDbEYsTUFBTSxFQUNKLFNBQ0Esa0JBQ0EsaUJBQ0UscUJBQXFCO0VBQ3ZCO0VBQ0EsS0FBSyxNQUFNLFFBQVE7RUFDbkIsdUJBQXVCLE1BQU0sU0FBUywwQkFBMEI7RUFDaEUsMkJBQTBCLDBCQUF5QixNQUFNLElBQUksNEJBQTRCLHFCQUFxQjtFQUM5RztFQUNBLFlBQVk7R0FDVixNQUFNLE9BQU87SUFDWCxpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLFNBQVM7SUFDVCwwQkFBMEI7R0FDNUIsQ0FBQztHQUNELFlBQVk7R0FDWixNQUFNLFFBQVEsdUJBQXVCLEtBQUs7RUFDNUM7Q0FDRixDQUFDO0NBSUQscUJBQXFCO0VBQ25CLE1BQU0sSUFBSSxXQUFXLE9BQU87RUFDNUIsT0FBTztDQUNULENBQUM7Q0FDRCxNQUFNLGdCQUFnQjtFQUNwQjtFQUNBO0NBQ0YsQ0FBQztDQUNELE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQWdCLHlCQUF5QixPQUFPLFdBQVc7Q0FDekQsTUFBTSxnQkFBZ0IsU0FBUztDQUMvQiwrQkFBK0I7RUFDN0IsTUFBTSxPQUFPO0dBQ1gsb0JBQW9CO0dBQ3BCLHNCQUFzQjtHQUN0QixZQUFZO0VBQ2QsQ0FBQztDQUNILEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDWjtBQUNBLFNBQWdCLGlCQUFpQixPQUFPLE1BQU07Q0FDNUMseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxRQUFRLE1BQU0sTUFBTSxlQUFlLE1BQ3RDLE1BQU0sSUFBSSxjQUFjLElBQUk7Q0FFaEMsR0FBRyxDQUFDLE1BQU0sS0FBSyxDQUFDO0NBQ2hCLCtCQUErQjtFQUM3QixJQUFJLE1BQU0sTUFBTSxlQUFlLE1BQzdCLE1BQU0sSUFBSSxjQUFjLElBQUk7Q0FFaEMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUNaOzs7Ozs7Ozs7O0FDcGRBLElBQUk7QUFDSixTQUFTLGlCQUFpQixLQUFLO0NBQzdCLHVDQUF1QixJQUFJLFFBQVE7Q0FDbkMsSUFBSSxhQUFhLG1CQUFtQixJQUFJLEdBQUc7Q0FDM0MsSUFBSSxDQUFDLFlBQVk7RUFDZiw2QkFBYSxJQUFJLFFBQVE7RUFDekIsbUJBQW1CLElBQUksS0FBSyxVQUFVO0NBQ3hDO0NBQ0EsT0FBTztBQUNUOzs7Ozs7O0FBUUEsSUFBYSxrQkFBYixNQUE2QjtDQUMzQix3QkFBUSxJQUFJLElBQUk7Ozs7OztDQU9oQixJQUFJLElBQUksU0FBUztFQUM0QjtHQUN6QyxNQUFNLGFBQWEsaUJBQWlCLElBQUk7R0FDeEMsTUFBTSxhQUFhLFdBQVcsSUFBSSxPQUFPO0dBQ3pDLElBQUksZUFBZSxVQUFhLGVBQWUsSUFHN0MsTUFBTSxJQUFJLE1BQU0sd0ZBQXdGO0dBSzFHLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxJQUFJLEVBQUU7R0FDekMsSUFBSSxvQkFBb0IsVUFBYSxvQkFBb0IsU0FDdkQsV0FBVyxPQUFPLGVBQWU7R0FFbkMsV0FBVyxJQUFJLFNBQVMsRUFBRTtFQUM1QjtFQUNBLEtBQUssTUFBTSxJQUFJLElBQUksT0FBTztDQUM1Qjs7OztDQUtBLE9BQU8sSUFBSTtFQUNrQztHQUN6QyxNQUFNLFVBQVUsS0FBSyxNQUFNLElBQUksRUFBRTtHQUNqQyxJQUFJLFlBQVksUUFDZCxvQkFBb0IsSUFBSSxJQUFJLENBQUMsRUFBRSxPQUFPLE9BQU87RUFFakQ7RUFDQSxLQUFLLE1BQU0sT0FBTyxFQUFFO0NBQ3RCOzs7O0NBS0EsV0FBVyxTQUFTO0VBQ2xCLEtBQUssTUFBTSxjQUFjLEtBQUssTUFBTSxPQUFPLEdBQ3pDLElBQUksZUFBZSxTQUNqQixPQUFPO0VBR1gsT0FBTztDQUNUOzs7O0NBS0EsbUJBQW1CLFdBQVc7RUFDNUIsS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLE9BQU8sR0FDdEMsSUFBSSxVQUFVLE9BQU8sR0FDbkIsT0FBTztFQUdYLE9BQU87Q0FDVDs7OztDQUtBLFFBQVEsSUFBSTtFQUNWLE9BQU8sS0FBSyxNQUFNLElBQUksRUFBRTtDQUMxQjs7OztDQUtBLFVBQVU7RUFDUixPQUFPLEtBQUssTUFBTSxRQUFRO0NBQzVCOzs7O0NBS0EsV0FBVztFQUNULE9BQU8sS0FBSyxNQUFNLE9BQU87Q0FDM0I7Ozs7Q0FLQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssTUFBTTtDQUNwQjtBQUNGOztBQ3BIQSxJQUFNLFFBQVEsQ0FBQztBQUNmLElBQUksa0JBQWtCO0FBQ3RCLFNBQWdCLGNBQWM7Q0FDNUIsT0FBTztBQUNUO0FBSUEsU0FBZ0IsU0FBUyxNQUFNO0NBQzdCLE1BQU0sS0FBSyxJQUFJO0FBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9DQSxTQUFnQixjQUFjLElBQUk7Q0FDaEMsTUFBTSxpQkFBaUIsT0FBTyxpQkFBaUI7RUFDN0MsTUFBTSxXQUFXLGVBQWUsY0FBYyxDQUFDLENBQUM7RUFDaEQsSUFBSTtFQUNKLElBQUk7R0FDRixrQkFBa0I7R0FDbEIsS0FBSyxNQUFNLFFBQVEsT0FDakIsS0FBSyxPQUFPLFFBQVE7R0FFdEIsU0FBUyxHQUFHLE9BQU8sWUFBWTtHQUMvQixLQUFLLE1BQU0sUUFBUSxPQUNqQixLQUFLLE1BQU0sUUFBUTtHQUVyQixTQUFTLGdCQUFnQjtFQUMzQixVQUFVO0dBQ1Isa0JBQWtCO0VBQ3BCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsY0FBYyxjQUFjLEdBQUcsZUFBZSxHQUFHO0NBQ2pELE9BQU87QUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTBCQSxTQUFnQixpQkFBaUIsSUFBSTtDQUNuQyxPQUFvQiwyQkFBTSxXQUFXLGNBQWMsRUFBRSxDQUFDO0FBQ3hEO0FBQ0EsU0FBUyxpQkFBaUI7Q0FDeEIsT0FBTyxFQUNMLGVBQWUsTUFDakI7QUFDRjs7OztBQzVGQSxJQUFNLHlCQURnQyxzQkFBc0IsRUFDRCxJQUFJLGVBQWU7QUFDOUUsU0FBZ0IsU0FBUyxPQUFPLFVBQVUsSUFBSSxJQUFJLElBQUk7Q0FDcEQsT0FBTyx1QkFBdUIsT0FBTyxVQUFVLElBQUksSUFBSSxFQUFFO0FBQzNEO0FBQ0EsU0FBUyxZQUFZLE9BQU8sVUFBVSxJQUFJLElBQUksSUFBSTtDQUNoRCxNQUFNLDRCQUFxQixrQkFBa0IsU0FBUyxNQUFNLFlBQVksR0FBRyxJQUFJLElBQUksRUFBRSxHQUFHO0VBQUM7RUFBTztFQUFVO0VBQUk7RUFBSTtDQUFFLENBQUM7Q0FDckgsV0FBT0Msa0NBQXFCLE1BQU0sV0FBVyxjQUFjLFlBQVk7QUFDekU7QUFDQSxTQUFTO0NBQ1AsT0FBTyxVQUFVO0VBQ2YsU0FBUyxZQUFZO0VBQ3JCLElBQUksQ0FBQyxTQUFTLGVBQWU7R0FDM0IsU0FBUyxXQUFXO0dBQ3BCLFNBQVMsWUFBWSxDQUFDO0dBQ3RCLFNBQVMsaUJBQWlCO0dBQzFCLFNBQVMsb0JBQW9CO0lBQzNCLElBQUksWUFBWTtJQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxVQUFVLFFBQVEsS0FBSyxHQUFHO0tBQ3JELE1BQU0sT0FBTyxTQUFTLFVBQVU7S0FDaEMsTUFBTSxRQUFRLEtBQUssU0FBUyxLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRTtLQUN2RSxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssT0FBTyxLQUFLLEdBQUc7TUFDakMsWUFBWTtNQUNaLEtBQUssUUFBUTtLQUNmO0lBQ0Y7SUFDQSxJQUFJLFdBQ0YsU0FBUyxZQUFZO0lBRXZCLE9BQU8sU0FBUztHQUNsQjtFQUNGO0NBQ0Y7Q0FDQSxNQUFNLFVBQVU7RUFDZCxJQUFJLFNBQVMsVUFBVSxTQUFTLEdBQUc7R0FDakMsSUFBSSxTQUFTLGdCQUFnQjtJQUMzQixTQUFTLGlCQUFpQjtJQUMxQixTQUFTLGFBQVksa0JBQWlCO0tBQ3BDLE1BQU0seUJBQVMsSUFBSSxJQUFJO0tBQ3ZCLEtBQUssTUFBTSxRQUFRLFNBQVMsV0FDMUIsT0FBTyxJQUFJLEtBQUssS0FBSztLQUV2QixNQUFNLGVBQWUsQ0FBQztLQUN0QixLQUFLLE1BQU0sU0FBUyxRQUNsQixhQUFhLEtBQUssTUFBTSxVQUFVLGFBQWEsQ0FBQztLQUVsRCxhQUFhO01BQ1gsS0FBSyxNQUFNLGVBQWUsY0FDeEIsWUFBWTtLQUVoQjtJQUNGO0dBQ0Y7R0FFQSxzQ0FBcUIsU0FBUyxXQUFXLFNBQVMsYUFBYSxTQUFTLFdBQVc7RUFDckY7Q0FDRjtBQUNGLENBQUM7QUFDRCxTQUFTLGFBQWEsT0FBTyxVQUFVLElBQUksSUFBSSxJQUFJO0NBQ2pELE1BQU0sV0FBVyxZQUFZO0NBQzdCLElBQUksQ0FBQyxVQUVILE9BQU8sWUFBWSxPQUFPLFVBQVUsSUFBSSxJQUFJLEVBQUU7Q0FFaEQsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsU0FBUyxhQUFhO0NBQ3RCLElBQUk7Q0FDSixJQUFJLENBQUMsU0FBUyxlQUFlO0VBQzNCLE9BQU87R0FDTDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsT0FBTyxTQUFTLE1BQU0sWUFBWSxHQUFHLElBQUksSUFBSSxFQUFFO0VBQ2pEO0VBQ0EsU0FBUyxVQUFVLEtBQUssSUFBSTtDQUM5QixPQUFPO0VBQ0wsT0FBTyxTQUFTLFVBQVU7RUFDMUIsSUFBSSxLQUFLLFVBQVUsU0FBUyxLQUFLLGFBQWEsWUFBWSxDQUFDLE9BQU8sR0FBRyxLQUFLLElBQUksRUFBRSxLQUFLLENBQUMsT0FBTyxHQUFHLEtBQUssSUFBSSxFQUFFLEtBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSyxJQUFJLEVBQUUsR0FBRztHQUN2SSxJQUFJLEtBQUssVUFBVSxPQUNqQixTQUFTLGlCQUFpQjtHQUU1QixLQUFLLFFBQVE7R0FDYixLQUFLLFdBQVc7R0FDaEIsS0FBSyxLQUFLO0dBQ1YsS0FBSyxLQUFLO0dBQ1YsS0FBSyxLQUFLO0dBQ1YsS0FBSyxRQUFRLFNBQVMsTUFBTSxZQUFZLEdBQUcsSUFBSSxJQUFJLEVBQUU7RUFDdkQ7Q0FDRjtDQUNBLE9BQU8sS0FBSztBQUNkO0FBQ0EsU0FBUyxlQUFlLE9BQU8sVUFBVSxJQUFJLElBQUksSUFBSTtDQUNuRCxXQUFPQyx1REFBaUMsTUFBTSxXQUFXLE1BQU0sYUFBYSxNQUFNLGNBQWEsVUFBUyxTQUFTLE9BQU8sSUFBSSxJQUFJLEVBQUUsQ0FBQztBQUNySTs7Ozs7O0FDbkdBLElBQWEsUUFBYixNQUFtQjs7Ozs7O0NBTWpCLE9BQU8sT0FBTyxPQUFPO0VBQ25CLE9BQU8sSUFBSSxLQUFLLEtBQUs7Q0FDdkI7Ozs7Ozs7OztDQWFBLFlBQVksT0FBTztFQUNqQixLQUFLLFFBQVE7RUFDYixLQUFLLDRCQUFZLElBQUksSUFBSTtFQUN6QixLQUFLLGFBQWE7Q0FDcEI7Ozs7Ozs7Q0FRQSxhQUFZLE9BQU07RUFDaEIsS0FBSyxVQUFVLElBQUksRUFBRTtFQUNyQixhQUFhO0dBQ1gsS0FBSyxVQUFVLE9BQU8sRUFBRTtFQUMxQjtDQUNGOzs7O0NBS0Esb0JBQW9CO0VBQ2xCLE9BQU8sS0FBSztDQUNkOzs7Ozs7Q0FPQSxTQUFTLFVBQVU7RUFDakIsSUFBSSxLQUFLLFVBQVUsVUFDakI7RUFFRixLQUFLLFFBQVE7RUFDYixLQUFLLGNBQWM7RUFDbkIsTUFBTSxjQUFjLEtBQUs7RUFDekIsS0FBSyxNQUFNLFlBQVksS0FBSyxXQUFXO0dBQ3JDLElBQUksZ0JBQWdCLEtBQUssWUFHdkI7R0FFRixTQUFTLFFBQVE7RUFDbkI7Q0FDRjs7Ozs7Ozs7Q0FTQSxPQUFPLFNBQVM7RUFDZCxLQUFLLE1BQU0sT0FBTyxTQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssTUFBTSxNQUFNLFFBQVEsSUFBSSxHQUFHO0dBQzdDLEtBQUssU0FBUztJQUNaLEdBQUcsS0FBSztJQUNSLEdBQUc7R0FDTCxDQUFDO0dBQ0Q7RUFDRjtDQUVKOzs7Ozs7O0NBUUEsSUFBSSxLQUFLLE9BQU87RUFDZCxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssTUFBTSxNQUFNLEtBQUssR0FDbkMsS0FBSyxTQUFTO0dBQ1osR0FBRyxLQUFLO0lBQ1AsTUFBTTtFQUNULENBQUM7Q0FFTDs7OztDQUtBLFlBQVk7RUFDVixNQUFNLFdBQVcsRUFDZixHQUFHLEtBQUssTUFDVjtFQUNBLEtBQUssU0FBUyxRQUFRO0NBQ3hCO0NBQ0EsSUFBSSxVQUFVLElBQUksSUFBSSxJQUFJO0VBRXhCLE9BQU8sU0FBUyxNQUFNLFVBQVUsSUFBSSxJQUFJLEVBQUU7Q0FDNUM7QUFDRjs7Ozs7QUMzR0EsSUFBYSxhQUFiLGNBQWdDLE1BQU07Ozs7Ozs7O0NBUXBDLFlBQVksT0FBTyxVQUFVLENBQUMsR0FBRyxXQUFXO0VBQzFDLE1BQU0sS0FBSztFQUNYLEtBQUssVUFBVTtFQUNmLEtBQUssWUFBWTtDQUNuQjs7Ozs7Ozs7OztDQVlBLGVBQWUsS0FBSyxPQUFPO0VBQ3pCLGFBQU0sY0FBYyxHQUFHO0VBRXZCLE1BQU0sUUFBUTtFQUNkLHlCQUF5QjtHQUN2QixJQUFJLE1BQU0sTUFBTSxTQUFTLE9BQ3ZCLE1BQU0sSUFBSSxLQUFLLEtBQUs7RUFFeEIsR0FBRztHQUFDO0dBQU87R0FBSztFQUFLLENBQUM7Q0FDeEI7Ozs7Ozs7O0NBU0EsMEJBQTBCLEtBQUssT0FBTztFQUVwQyxNQUFNLFFBQVE7RUFDZCx5QkFBeUI7R0FDdkIsSUFBSSxNQUFNLE1BQU0sU0FBUyxPQUN2QixNQUFNLElBQUksS0FBSyxLQUFLO0dBRXRCLGFBQWE7SUFDWCxNQUFNLElBQUksS0FBSyxNQUFTO0dBQzFCO0VBQ0YsR0FBRztHQUFDO0dBQU87R0FBSztFQUFLLENBQUM7Q0FDeEI7Ozs7Ozs7Ozs7O0NBWUEsZ0JBQWdCLFdBQVc7RUFFekIsTUFBTSxRQUFRO0VBQzZCO0dBRXpDLGFBQU0sY0FBYyxZQUFXLE1BQUssT0FBTyxLQUFLLENBQUMsQ0FBQztHQUNsRCxNQUFNLG9CQUFhLE9BQU8sT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUM7R0FDbEQsTUFBTSxXQUFXLE9BQU8sS0FBSyxTQUFTO0dBQ3RDLElBQUksS0FBSyxXQUFXLFNBQVMsVUFBVSxLQUFLLE1BQU0sS0FBSyxVQUFVLFFBQVEsU0FBUyxNQUFNLEdBQ3RGLFFBQVEsTUFBTSwrRkFBK0Y7RUFFakg7RUFDQSxNQUFNLGVBQWUsT0FBTyxPQUFPLFNBQVM7RUFDNUMseUJBQXlCO0dBQ3ZCLE1BQU0sT0FBTyxTQUFTO0VBRXhCLEdBQUcsQ0FBQyxPQUFPLEdBQUcsWUFBWSxDQUFDO0NBQzdCOzs7OztDQU1BLGtCQUFrQixLQUFLLFlBQVk7RUFDakMsYUFBTSxjQUFjLEdBQUc7RUFFdkIsTUFBTSxRQUFRO0VBQ2QsTUFBTSxlQUFlLGVBQWU7RUFDcEMseUJBQXlCO0dBQ3ZCLElBQUksZ0JBQWdCLENBQUMsT0FBTyxHQUFHLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FFekQsTUFBTSxTQUFTO0lBQ2IsR0FBRyxNQUFNO0tBQ1IsTUFBTTtHQUNULENBQUM7RUFFTCxHQUFHO0dBQUM7R0FBTztHQUFLO0dBQVk7RUFBWSxDQUFDO0VBQ0U7R0FFekMsTUFBTSxRQUFRLEtBQUsscUNBQXFCLElBQUksSUFBSTtHQUNoRCxJQUFJLENBQUMsTUFBTSxJQUFJLEdBQUcsR0FDaEIsTUFBTSxJQUFJLEtBQUssWUFBWTtHQUU3QixNQUFNLHVCQUF1QixNQUFNLElBQUksR0FBRztHQUMxQyxJQUFJLHlCQUF5QixVQUFhLHlCQUF5QixjQUNqRSxRQUFRLE1BQU0sK0JBQStCLHVCQUF1QixLQUFLLEtBQUssc0JBQXNCLElBQUksU0FBUyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sR0FBRyx3RkFBd0Y7RUFFelA7Q0FDRjs7Ozs7Q0FPQSxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUk7RUFDdEIsTUFBTSxXQUFXLEtBQUssVUFBVTtFQUNoQyxPQUFPLFNBQVMsS0FBSyxPQUFPLElBQUksSUFBSSxFQUFFO0NBQ3hDOzs7Ozs7OztDQVVBLFNBQVMsS0FBSyxJQUFJLElBQUksSUFBSTtFQUN4QixhQUFNLGNBQWMsR0FBRztFQUN2QixPQUFPLFNBQVMsTUFBTSxLQUFLLFVBQVUsTUFBTSxJQUFJLElBQUksRUFBRTtDQUN2RDs7Ozs7Ozs7Q0FTQSxtQkFBbUIsS0FBSyxJQUFJO0VBQzFCLGFBQU0sY0FBYyxHQUFHO0VBQ3ZCLE1BQU0saUJBQWlCLGtCQUFrQixNQUFNLElBQUk7RUFDbkQsS0FBSyxRQUFRLE9BQU87Q0FDdEI7Ozs7Ozs7Q0FRQSxlQUFlLEtBQUs7RUFDbEIsTUFBTSxtQkFBWSxPQUFPLE1BQVM7RUFDbEMsSUFBSSxJQUFJLFlBQVksUUFDbEIsSUFBSSxXQUFVLFVBQVM7R0FDckIsS0FBSyxJQUFJLEtBQUssS0FBSztFQUNyQjtFQUVGLE9BQU8sSUFBSTtDQUNiOzs7Ozs7O0NBU0EsUUFBUSxVQUFVLFVBQVU7RUFDMUIsSUFBSTtFQUNKLElBQUksT0FBTyxhQUFhLFlBQ3RCLFdBQVc7T0FFWCxXQUFXLEtBQUssVUFBVTtFQUU1QixJQUFJLFlBQVksU0FBUyxLQUFLLEtBQUs7RUFDbkMsU0FBUyxXQUFXLFdBQVcsSUFBSTtFQUNuQyxPQUFPLEtBQUssV0FBVSxjQUFhO0dBQ2pDLE1BQU0sWUFBWSxTQUFTLFNBQVM7R0FDcEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxXQUFXLFNBQVMsR0FBRztJQUNwQyxNQUFNLFdBQVc7SUFDakIsWUFBWTtJQUNaLFNBQVMsV0FBVyxVQUFVLElBQUk7R0FDcEM7RUFDRixDQUFDO0NBQ0g7QUFDRjs7QUMzTUEsSUFBTUMsY0FBWTtDQUNoQixPQUFNLFVBQVMsTUFBTTtDQUNyQixtQkFBa0IsVUFBUyxNQUFNO0NBQ2pDLHNCQUFxQixVQUFTLE1BQU07Q0FDcEMsbUJBQWtCLFVBQVMsTUFBTSxxQkFBcUIsTUFBTTtDQUM1RCxrQkFBaUIsVUFBUyxNQUFNO0NBQ2hDLGFBQVksVUFBUyxNQUFNO0FBQzdCO0FBQ0EsSUFBYSxvQkFBYixjQUF1QyxXQUFXO0NBQ2hELFlBQVksU0FBUztFQUNuQixNQUFNLEVBQ0osVUFDQSxRQUNBLGNBQ0EsaUJBQ0EsR0FBRyxpQkFDRDtFQUNKLE1BQU07R0FDSixHQUFHO0dBQ0gsbUJBQW1CLGFBQWE7R0FDaEMscUJBQXFCLGFBQWE7RUFDcEMsR0FBRztHQUNEO0dBQ0EsU0FBUyxFQUNQLFNBQVMsQ0FBQyxFQUNaO0dBQ0EsUUFBUSxtQkFBbUI7R0FDM0I7R0FDQTtFQUNGLEdBQUdBLFdBQVM7RUFDWixLQUFLLFdBQVc7Q0FDbEI7Ozs7Q0FLQSxpQkFBaUIsU0FBUyxVQUFVO0VBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxNQUFNLFFBRzVCLFNBQVMsUUFBUSxpQkFBaUIsS0FBSyxHQUNyQyxLQUFLLFFBQVEsUUFBUSxRQUFRLFlBQVksVUFBVSxRQUFRO0NBRS9EOzs7O0NBS0Esc0JBQXNCLFNBQVMsaUJBQWlCO0VBQzlDLEtBQUssY0FBYyxTQUFTLGFBQWEsS0FBSztFQUM5QyxNQUFNLFVBQVU7R0FDZCxNQUFNO0dBQ04sUUFBUSxhQUFhO0dBQ3JCLGFBQWEsYUFBYTtHQUMxQixRQUFRLEtBQUssUUFBUTtHQUNyQixnQkFBZ0IsYUFBYTtFQUMvQjtFQUNBLEtBQUssUUFBUSxPQUFPLEtBQUssY0FBYyxPQUFPO0NBQ2hEOzs7Ozs7O0NBUUEsV0FBVyxTQUFTLGlCQUFpQjtFQUNuQyxJQUFJLEtBQUssVUFBVTtHQUNqQixLQUFLLFFBQVEsZUFBZSxTQUFTLFlBQVk7R0FDakQ7RUFDRjtFQUNBLEtBQUssbUJBQW1CLFNBQVMsWUFBWTtFQUM3QyxLQUFLLFFBQVEsZUFBZSxTQUFTLFlBQVk7Q0FDbkQ7QUFDRjs7Ozs7QUN0RUEsU0FBZ0IsNkJBQTZCLGlCQUFpQixZQUFZLFNBQVMsT0FBTztDQUN4RixPQUFPO0VBQ0wsTUFBTTtFQUNOLFVBQVU7RUFDVixTQUFTO0VBQ1Qsa0JBQWtCO0VBQ2xCLHFCQUFxQixJQUFJLGtCQUFrQjtHQUN6QyxNQUFNO0dBQ04sa0JBQWtCO0dBQ2xCLGlCQUFpQjtHQUNqQixrQkFBa0I7R0FDbEI7R0FDQTtHQUNBLFVBQVU7R0FDVjtHQUNBLGNBQWM7RUFDaEIsQ0FBQztFQUNEO0VBQ0EsY0FBYztFQUNkLDBCQUEwQjtFQUMxQixTQUFTO0VBQ1QsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixzQkFBc0I7RUFDdEIsZUFBZTtFQUNmLGNBQWM7RUFDZCxtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLHNCQUFzQjtFQUN0QixZQUFZO0NBQ2Q7QUFDRjtBQUNBLElBQU0sMkJBQTBCLFVBQVMsTUFBTSxpQkFBaUIsTUFBTTtBQUN0RSxJQUFNLGdCQUFlLFVBQVMsTUFBTSxZQUFZLE1BQU07QUFDdEQsSUFBTSxtQkFBa0IsVUFBUztDQUUvQixRQURnQixNQUFNLGNBQWMsTUFBTSxNQUFNLGVBQzlCO0FBQ3BCO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTyxXQUFXO0NBQzlDLE9BQU8sY0FBYyxVQUFhLGFBQWEsS0FBSyxLQUFLLHdCQUF3QixLQUFLLE1BQU07QUFDOUY7QUFDQSxTQUFTLG9DQUFvQyxPQUFPLFdBQVc7Q0FDN0QsSUFBSSxxQkFBcUIsT0FBTyxTQUFTLEdBQ3ZDLE9BQU87Q0FFVCxPQUFPLGNBQWMsVUFBYSxhQUFhLEtBQUssS0FBSyx3QkFBd0IsS0FBSyxLQUFLLFFBQVEsQ0FBQyxNQUFNLHdCQUF3QixNQUFNLGlCQUFpQjtBQUMzSjtBQUNBLElBQWEsc0JBQXNCO0NBQ2pDLE1BQU07Q0FDTixVQUFTLFVBQVMsTUFBTTtDQUd4QixtQkFBa0IsVUFBUyxhQUFhLEtBQUssS0FBSyxDQUFDLE1BQU0sVUFBVSxhQUFhLE1BQU07Q0FDdEYsc0JBQXFCLFVBQVMsTUFBTTtDQUNwQyxlQUFjLFVBQVMsTUFBTTtDQUM3QiwyQkFBMEIsVUFBUyxNQUFNO0NBQ3pDLFVBQVMsVUFBUyxNQUFNO0NBQ3hCLGlCQUFpQjtDQUNqQix1QkFBc0IsVUFBUyxNQUFNLFVBQVUsTUFBTSx1QkFBdUI7Q0FDNUUsU0FBUzs7OztDQUlULGtCQUFrQixPQUFPLGNBQWMsY0FBYyxVQUFhLHdCQUF3QixLQUFLLE1BQU07Ozs7Q0FJckcsb0JBQW9CLE9BQU8sY0FBYyxxQkFBcUIsT0FBTyxTQUFTOzs7O0NBSTlFLHFCQUFxQixPQUFPLGNBQWMsY0FBYyxVQUFhLHdCQUF3QixLQUFLLE1BQU0sYUFBYSxNQUFNO0NBQzNILGVBQWUsT0FBTyxhQUFhLFdBQVcsTUFBTSxxQkFBcUIsTUFBTTs7OztDQUkvRSxpQkFBaUIsT0FBTyxjQUFjLG9DQUFvQyxPQUFPLFNBQVMsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJO0NBQ3ZILGFBQVksVUFBUyxNQUFNO0NBQzNCLGVBQWMsVUFBUyxNQUFNO0NBQzdCLG9CQUFtQixVQUFTLE1BQU07QUFDcEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEVBLFNBQWdCLG9CQUFvQixRQUFRO0NBQzFDLE1BQU0seUJBQWtCLGFBQVksYUFBWTtFQUM5QyxJQUFJLFdBQVcsUUFDYixPQUFPO0VBRVQsT0FBTyxPQUFPLGVBQWUsUUFBUTtDQUN2QyxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsTUFBTSwyQkFBb0Isa0JBQWtCO0VBQzFDLE9BQU8sV0FBVyxTQUFZLFNBQVksT0FBTztDQUNuRCxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsV0FBT0Ysa0NBQXFCLFdBQVcsbUJBQW1CLFFBQVEsV0FBVztBQUMvRTs7QUN0QkEsSUFBYSxzQkFBbUMsMkJBQU0sY0FBYyxNQUFTO0FBQ2xDLG9CQUFvQixjQUFjO0FBQzdFLFNBQWdCLHlCQUF5QjtDQUN2QyxNQUFNLHFCQUFjLFdBQVcsbUJBQW1CO0NBQ2xELElBQUksVUFBVSxRQUNaLE1BQU0sSUFBSSxNQUE4QyxzQ0FBZ0U7Q0FFMUgsT0FBTztBQUNUO0FDRkEsSUFBYSxpQ0FBaUIsSUFBSSxJQUFJO0NBQUM7Q0FBVTtDQUFZO0NBQVk7Q0FBYTs7QUFBUyxDQUFDOzs7Ozs7O0FDTmhHLElBQWEsZ0JBQWdCOzs7Ozs7Ozs7Ozs7O0FDQzdCLElBQWF0QixTQUFPSTs7OztBQUlwQixJQUFhSCxXQUFTSTs7OztBQUl0QixJQUFhVCxrQkFBZ0I2Qjs7OztBQUk3QixJQUFhNUIsZ0JBQWM2Qjs7OztBQUkzQixJQUFhQyxXQUFTOzs7O0FBSXRCLElBQWFDLHFCQUFtQjs7Ozs7O0FDakJoQyxJQUFhLCtCQUErQjtDQUMxQyxHQUFHO0NBQ0gsR0FBRztDQUNILGlCQUFpQixPQUFPO0VBQ3RCLE9BQU8sUUFBUSxHQUNaQyxxQkFBNkMsR0FDaEQsSUFBSTtDQUNOO0FBQ0Y7Ozs7Ozs7O0FDSUEsSUFBYSxjQUEyQiwyQkFBTSxXQUFXLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUMxRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsWUFDQSxjQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sdUJBQXVCLE1BQU0sU0FBUyxzQkFBc0I7Q0FDbEUsTUFBTSwwQkFBMEIsTUFBTSxTQUFTLHlCQUF5QjtDQUN4RSxNQUFNLHNCQUFzQixNQUFNLFNBQVMscUJBQXFCO0NBQ2hFLE1BQU0saUJBQWlCLE1BQU0sU0FBUyxZQUFZO0NBQ2xELE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsTUFBTSxTQUFTLE1BQU0sU0FBUyxRQUFRO0NBQ3RDLE1BQU0sd0JBQXdCLE1BQU0sU0FBUyx1QkFBdUI7Q0FDcEUsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sYUFBYSxNQUFNLFNBQVMsWUFBWTtDQUM5QyxNQUFNLGlCQUFpQixNQUFNLFNBQVMsZ0JBQWdCO0NBQ3RELE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sYUFBYSxvQkFBb0IsU0FBUyxZQUFZO0NBQzVELHVCQUF1QjtDQUN2QixzQkFBc0I7RUFDcEI7RUFDQSxLQUFLLE1BQU0sUUFBUTtFQUNuQixhQUFhO0dBQ1gsSUFBSSxNQUNGLE1BQU0sUUFBUSx1QkFBdUIsSUFBSTtFQUU3QztDQUNGLENBQUM7Q0FDRCxNQUFNLHVCQUF1QixpQkFBaUIsU0FBWSwwQkFBMEIsTUFBTSxRQUFRLFFBQVEsSUFBSTtDQUM5RyxNQUFNLG1CQUFtQix3QkFBd0I7Q0FDakQsTUFBTSxrQkFBa0IsTUFBTSxlQUFlLGNBQWM7Q0FPM0QsTUFBTSxVQUFVLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RDtHQU5BO0dBQ0E7R0FDQTtHQUNBO0VBR0k7RUFDSixPQUFPO0dBQUM7R0FBZ0I7SUFDdEIsSUFBSTtJQUNKLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEI7SUFDQSxHQUFHO0lBQ0gsUUFBUSxDQUFDO0lBQ1QsVUFBVSxPQUFPO0tBQ2YsSUFBSSxlQUFlLElBQUksTUFBTSxHQUFHLEdBQzlCLE1BQU0sZ0JBQWdCO0lBRTFCO0lBQ0EsT0FBTyxHQUNKQyxnQkFBbUMsc0JBQ3RDO0dBQ0Y7R0FBRztFQUFZO0VBQ2YsS0FBSztHQUFDO0dBQWMsTUFBTSxRQUFRO0dBQVU7RUFBZTtFQUMzRCx3QkFBd0I7Q0FDMUIsQ0FBQztDQUNELE9BQW9CLDBDQUFLLHNCQUFzQjtFQUM3QyxTQUFTO0VBQ1QscUJBQXFCO0VBQ3JCLFVBQVUsQ0FBQztFQUNYLGlCQUFpQixDQUFDO0VBQ2xCLGNBQWM7RUFDZCxhQUFhO0VBQ2IsT0FBTyxVQUFVO0VBQ2pCLGNBQWM7RUFDZCxVQUFVO0NBQ1osQ0FBQztBQUNILENBQUM7QUFDMEMsWUFBWSxjQUFjOztBQy9GckUsU0FBZ0IsV0FBVyxPQUFPO0NBQ2hDLElBQUksc0JBQXNCLEVBQUUsR0FDMUIsT0FBTztDQUdULE9BQU8sUUFBUSxTQUFTO0FBQzFCOzs7OztBQ0RBLElBQWEsbUJBQWdDLDJCQUFNLFdBQVcsU0FBUyxpQkFBaUIsT0FBTyxLQUFLO0NBQ2xHLE1BQU0sRUFDSixRQUNBLEdBQUcsZUFDRDtDQUNKLElBQUk7Q0FDSixJQUFJLFFBQVE7RUFDVixNQUFNLE9BQU8sT0FBTyxzQkFBc0I7RUFDMUMsV0FBVyxpREFBaUQsS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJO0NBQ2xOO0NBQ0EsT0FBb0IsMENBQUssT0FBTztFQUN6QjtFQUNMLE1BQU07RUFJTixzQkFBc0I7RUFDdEIsR0FBRztFQUNILE9BQU87R0FDTCxVQUFVO0dBQ1YsT0FBTztHQUNQLFlBQVk7R0FDWixrQkFBa0I7R0FDbEI7RUFDRjtDQUNGLENBQUM7QUFDSCxDQUFDO0FBQzBDLGlCQUFpQixjQUFjOzs7Ozs7Ozs7QUNoQjFFLElBQWEsZUFBNEIsMkJBQU0sV0FBVyxTQUFTLGFBQWEsT0FBTyxjQUFjO0NBQ25HLE1BQU0sRUFDSixjQUFjLE9BQ2QsR0FBRyxnQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FFbEMsSUFBSSxFQURpQixXQUFXLGNBRTlCLE9BQU87Q0FFVCxPQUFvQiwwQ0FBSyxvQkFBb0IsVUFBVTtFQUNyRCxPQUFPO0VBQ1AsVUFBdUIsMkNBQU0sZ0JBQWdCO0dBQzNDLEtBQUs7R0FDTCxHQUFHO0dBQ0gsVUFBVSxDQUFDLFdBQVcsVUFBVSxRQUFxQiwwQ0FBSyxrQkFBa0I7SUFDMUUsS0FBSyxNQUFNLFFBQVE7SUFDbkIsT0FBTyxXQUFXLENBQUMsSUFBSTtHQUN6QixDQUFDLEdBQUcsTUFBTSxRQUFRO0VBQ3BCLENBQUM7Q0FDSCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxhQUFhLGNBQWM7O0FDakN0RSxJQUFJLHFCQUFxQixDQUFDO0FBQzFCLElBQUkscUJBQXFCLENBQUM7QUFDMUIsSUFBSSw2QkFBNkI7QUFJakMsU0FBUyxvQkFBb0IsTUFBTSxNQUFNO0NBQ3ZDLE9BQU8sa0JBQWtCLElBQUksSUFBSSxPQUFPO0FBQzFDO0FBQ0EsU0FBUyxtQkFBbUIsS0FBSyxNQUFNLE1BQU07Q0FDM0MsT0FBTyxjQUFjLEtBQUssSUFBSSxpQkFBaUIsb0JBQW9CLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTO0FBQzNGO0FBQ0EsU0FBUyxtQkFBbUIsa0JBQWtCO0NBQzVDLElBQUksT0FBTyxhQUFhLGFBQ3RCLE9BQU87Q0FFVCxNQUFNLE1BQU0sY0FBYyxnQkFBZ0I7Q0FFMUMsT0FEWWpCLFVBQVksR0FDZixDQUFDLENBQUMsYUFBYSxJQUFJLGdCQUFnQixjQUFjO0FBQzVEO0FBQ0EsU0FBUyw4QkFBOEIsa0JBQWtCO0NBRXZELElBQUksRUFEYyxPQUFPLFFBQVEsZUFBZSxJQUFJLFlBQVksSUFBSSxTQUFTLG9CQUFvQixRQUFRLE1BQ3ZGLE9BQU8sYUFBYSxhQUNwQyxPQUFPO0NBRVQsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0NBQzFDLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLE1BQU0sa0JBQWtCLG9CQUFvQixNQUFNLElBQUk7Q0FDdEQsTUFBTSxtQ0FBbUMsZ0JBQWdCLE1BQU07Q0FDL0QsTUFBTSwwQkFBMEIsS0FBSyxNQUFNO0NBQzNDLEtBQUssTUFBTSxrQkFBa0I7Q0FDN0IsZ0JBQWdCLE1BQU0sWUFBWTtDQUNsQyxNQUFNLFNBQVMsZ0JBQWdCO0NBQy9CLGdCQUFnQixNQUFNLFlBQVk7Q0FDbEMsTUFBTSxRQUFRLGdCQUFnQjtDQUM5QixnQkFBZ0IsTUFBTSxZQUFZO0NBQ2xDLEtBQUssTUFBTSxrQkFBa0I7Q0FDN0IsT0FBTyxXQUFXO0FBQ3BCO0FBQ0EsU0FBUywrQkFBK0Isa0JBQWtCO0NBQ3hELE1BQU0sTUFBTSxjQUFjLGdCQUFnQjtDQUMxQyxNQUFNLE9BQU8sSUFBSTtDQUNqQixNQUFNLE9BQU8sSUFBSTtDQU1qQixNQUFNLGdCQUFnQixvQkFBb0IsTUFBTSxJQUFJO0NBQ3BELE1BQU0sOEJBQThCO0VBQ2xDLFdBQVcsY0FBYyxNQUFNO0VBQy9CLFdBQVcsY0FBYyxNQUFNO0NBQ2pDO0NBQ0EsT0FBTyxPQUFPLGNBQWMsT0FBTztFQUNqQyxXQUFXO0VBQ1gsV0FBVztDQUNiLENBQUM7Q0FDRCxhQUFhO0VBQ1gsT0FBTyxPQUFPLGNBQWMsT0FBTywyQkFBMkI7Q0FDaEU7QUFDRjtBQUNBLFNBQVMsNkJBQTZCLGtCQUFrQjtDQUN0RCxNQUFNLE1BQU0sY0FBYyxnQkFBZ0I7Q0FDMUMsTUFBTSxPQUFPLElBQUk7Q0FDakIsTUFBTSxPQUFPLElBQUk7Q0FDakIsTUFBTSxNQUFNQSxVQUFZLElBQUk7Q0FDNUIsSUFBSSxZQUFZO0NBQ2hCLElBQUksYUFBYTtDQUNqQixJQUFJLG1CQUFtQjtDQUN2QixNQUFNLGNBQWMsZUFBZSxPQUFPO0NBRzFDLElBQUlGLFdBQTJCLElBQUksZ0JBQWdCLFNBQVMsT0FBTyxHQUNqRSxhQUFhLENBQUM7Q0FFaEIsU0FBUyxhQUFhO0VBR3BCLE1BQU0sYUFBYSxJQUFJLGlCQUFpQixJQUFJO0VBQzVDLE1BQU0sYUFBYSxJQUFJLGlCQUFpQixJQUFJO0VBRzVDLE1BQU0sd0JBRjJCLFdBQVcsbUJBQW1CLElBQ2pCLFNBQVMsWUFDZixJQUFJLHNCQUFzQjtFQUNsRSxZQUFZLEtBQUs7RUFDakIsYUFBYSxLQUFLO0VBQ2xCLHFCQUFxQjtHQUNuQixpQkFBaUIsS0FBSyxNQUFNO0dBQzVCLFdBQVcsS0FBSyxNQUFNO0dBQ3RCLFdBQVcsS0FBSyxNQUFNO0VBQ3hCO0VBQ0EsNkJBQTZCLEtBQUssTUFBTTtFQUN4QyxxQkFBcUI7R0FDbkIsVUFBVSxLQUFLLE1BQU07R0FDckIsUUFBUSxLQUFLLE1BQU07R0FDbkIsT0FBTyxLQUFLLE1BQU07R0FDbEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsZ0JBQWdCLEtBQUssTUFBTTtFQUM3QjtFQUNBLE1BQU0sZ0JBQWdCLEtBQUssZUFBZSxLQUFLO0VBQy9DLE1BQU0sZ0JBQWdCLEtBQUssY0FBYyxLQUFLO0VBQzlDLE1BQU0sdUJBQXVCLFdBQVcsY0FBYyxZQUFZLFdBQVcsY0FBYztFQUMzRixNQUFNLHVCQUF1QixXQUFXLGNBQWMsWUFBWSxXQUFXLGNBQWM7RUFHM0YsTUFBTSxpQkFBaUIsS0FBSyxJQUFJLEdBQUcsSUFBSSxhQUFhLEtBQUssV0FBVztFQUNwRSxNQUFNLGtCQUFrQixLQUFLLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSyxZQUFZO0VBSXZFLE1BQU0sVUFBVSxXQUFXLFdBQVcsU0FBUyxJQUFJLFdBQVcsV0FBVyxZQUFZO0VBQ3JGLE1BQU0sVUFBVSxXQUFXLFdBQVcsVUFBVSxJQUFJLFdBQVcsV0FBVyxXQUFXO0VBQ3JGLE1BQU0sZ0JBQWdCLG9CQUFvQixNQUFNLElBQUk7RUFDcEQsbUJBQW1CLDhCQUE4QixnQkFBZ0I7RUFPakUsSUFBSSxrQkFBa0I7R0FDcEIsS0FBSyxNQUFNLGtCQUFrQjtHQUM3QixjQUFjLE1BQU0sWUFBWTtHQUNoQyxjQUFjLE1BQU0sWUFBWTtHQUNoQztFQUNGO0VBQ0EsT0FBTyxPQUFPLEtBQUssT0FBTztHQUN4QixpQkFBaUI7R0FDakIsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBQ0QsSUFBSSxpQkFBaUIsc0JBQ25CLEtBQUssTUFBTSxZQUFZO0VBRXpCLElBQUksaUJBQWlCLHNCQUNuQixLQUFLLE1BQU0sWUFBWTtFQUV6QixPQUFPLE9BQU8sS0FBSyxPQUFPO0dBQ3hCLFVBQVU7R0FDVixRQUFRLFdBQVcsa0JBQWtCLGlCQUFpQixVQUFVLGdCQUFnQixPQUFPO0dBQ3ZGLE9BQU8sV0FBVyxpQkFBaUIsZ0JBQWdCLFVBQVUsZUFBZSxPQUFPO0dBQ25GLFdBQVc7R0FFWCxXQUFXO0dBQ1gsV0FBVztHQUNYLGdCQUFnQjtFQUNsQixDQUFDO0VBQ0QsS0FBSyxZQUFZO0VBQ2pCLEtBQUssYUFBYTtFQUNsQixLQUFLLGFBQWEsOEJBQThCLEVBQUU7RUFDbEQsS0FBSyxNQUFNLGlCQUFpQjtDQUM5QjtDQUNBLFNBQVMsVUFBVTtFQUNqQixPQUFPLE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtFQUM1QyxPQUFPLE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtFQUM1QyxJQUFJLENBQUMsa0JBQWtCO0dBQ3JCLEtBQUssWUFBWTtHQUNqQixLQUFLLGFBQWE7R0FDbEIsS0FBSyxnQkFBZ0IsNEJBQTRCO0dBQ2pELEtBQUssTUFBTSxpQkFBaUI7RUFDOUI7Q0FDRjtDQUNBLFNBQVMsZUFBZTtFQUN0QixRQUFRO0VBQ1IsWUFBWSxRQUFRLFVBQVU7Q0FDaEM7Q0FDQSxXQUFXO0NBQ1gsTUFBTSxvQkFBb0IsaUJBQWlCLEtBQUssVUFBVSxZQUFZO0NBQ3RFLGFBQWE7RUFDWCxZQUFZLE9BQU87RUFDbkIsUUFBUTtFQUlSLElBQUksT0FBTyxJQUFJLHdCQUF3QixZQUNyQyxrQkFBa0I7Q0FFdEI7QUFDRjtBQUNBLElBQU0sZUFBTixNQUFtQjtDQUNqQixZQUFZO0NBQ1osVUFBVTtDQUNWLGNBQWMsUUFBUSxPQUFPO0NBQzdCLGdCQUFnQixRQUFRLE9BQU87Q0FDL0IsUUFBUSxrQkFBa0I7RUFDeEIsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxZQUFZLE1BQzNDLEtBQUssWUFBWSxNQUFNLFNBQVMsS0FBSyxLQUFLLGdCQUFnQixDQUFDO0VBRTdELE9BQU8sS0FBSztDQUNkO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxTQUMvQixLQUFLLGNBQWMsTUFBTSxHQUFHLEtBQUssTUFBTTtDQUUzQztDQUNBLGVBQWU7RUFDYixJQUFJLEtBQUssY0FBYyxLQUFLLEtBQUssU0FBUztHQUN4QyxLQUFLLFVBQVU7R0FDZixLQUFLLFVBQVU7RUFDakI7Q0FDRjtDQUNBLEtBQUssa0JBQWtCO0VBQ3JCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxZQUFZLE1BQzNDO0VBRUYsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0VBQzFDLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLE1BQU0sTUFBTUUsVUFBWSxJQUFJO0VBSzVCLElBQUksbUJBQW1CLEtBQUssTUFBTSxJQUFJLEdBQUc7R0FDdkMsTUFBTSxXQUFXLElBQUksSUFBSSx1QkFBdUI7SUFDOUMsSUFBSSxtQkFBbUIsS0FBSyxNQUFNLElBQUksR0FDcEM7SUFFRixTQUFTLFdBQVc7SUFDcEIsS0FBSyxVQUFVO0lBQ2YsS0FBSyxLQUFLLGdCQUFnQjtHQUM1QixDQUFDO0dBSUQsTUFBTSxVQUFVLEVBQ2QsWUFBWSxLQUNkO0dBQ0EsU0FBUyxRQUFRLE1BQU0sT0FBTztHQUM5QixTQUFTLFFBQVEsTUFBTSxPQUFPO0dBQzlCLEtBQUssZ0JBQWdCLFNBQVMsV0FBVztHQUN6QztFQUNGO0VBQ0EsTUFBTSx1QkFBdUJrQixPQUFtQixDQUFDLG1CQUFtQixnQkFBZ0I7RUFRcEYsS0FBSyxVQUFVLHVCQUF1QiwrQkFBK0IsZ0JBQWdCLElBQUksNkJBQTZCLGdCQUFnQjtDQUN4STtBQUNGO0FBQ0EsSUFBTSxnQkFBZ0IsSUFBSSxhQUFhOzs7Ozs7O0FBUXZDLFNBQWdCLGNBQWMsVUFBVSxNQUFNLG1CQUFtQixNQUFNO0NBQ3JFLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsU0FDSDtFQUVGLE9BQU8sY0FBYyxRQUFRLGdCQUFnQjtDQUMvQyxHQUFHLENBQUMsU0FBUyxnQkFBZ0IsQ0FBQztBQUNoQzs7QUN4UUEsU0FBZ0IsbUJBQW1CLEVBQ2pDLE9BQ0EsZUFDQSxZQUNDO0NBQ0QsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLDBCQUEwQixNQUFNLFNBQVMseUJBQXlCO0NBQ3hFLE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLGVBQWUsTUFBTSxTQUFTLGNBQWM7Q0FDbEQsTUFBTSxzQkFBc0IsTUFBTSxTQUFTLHFCQUFxQjtDQUNoRSxNQUFNLENBQUMsc0JBQXNCLHdDQUFpQyxTQUFTLENBQUM7Q0FDeEUsTUFBTSxDQUFDLHNCQUFzQix3Q0FBaUMsU0FBUyxDQUFDO0NBQ3hFLE1BQU0sWUFBWSx5QkFBeUI7Q0FDM0MsTUFBTSxVQUFVLFdBQVcscUJBQXFCO0VBQzlDLG9CQUFvQjtHQUNsQixJQUFJLE1BQU0sUUFBUSxvQkFBb0IsV0FBVyxNQUFNLFFBQVEsWUFBWSxTQUN6RSxPQUFPO0dBSVQsT0FBTztJQUNMLE9BQU8sVUFBVSxlQUFlLFdBQVc7SUFDM0MsT0FBTztHQUNUO0VBQ0Y7RUFDQSxhQUFhLE9BQU87R0FDbEIsSUFBSSxDQUFDLE1BQU0sUUFBUSx1QkFBdUIsU0FDeEMsT0FBTztHQUtULElBQUksWUFBWSxTQUFTLE1BQU0sV0FBVyxHQUN4QyxPQUFPO0dBRVQsSUFBSSxhQUFhLE9BQU87SUFLdEIsSUFBSSxNQUFNLFNBQVMsWUFDYjtTQUFBLE1BQU0sZUFBZSxXQUFXLEtBQUssTUFBTSxRQUFRLFdBQVcsR0FDaEUsT0FBTztJQUFBLE9BRUosSUFBSSxNQUFNLFFBQVEsV0FBVyxHQUNsQyxPQUFPO0dBRVg7R0FDQSxNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLElBQUksYUFBYSxDQUFDLHlCQUF5QjtJQUl6QyxJQUFJLE9BQU87S0FDVCxNQUFNLG1CQUFtQixNQUFNLFFBQVEsb0JBQW9CO0tBQzNELE1BQU0sV0FBVyxNQUFNLFFBQVEsWUFBWTtLQUMzQyxPQUFPLG9CQUFvQixXQUFXLHFCQUFxQixVQUFVLGFBQWEsVUFBVSxTQUFTLFFBQVEsWUFBWSxLQUFLLENBQUMsUUFBUSxhQUFhLHFCQUFxQixJQUFJO0lBQy9LO0lBQ0EsT0FBTztHQUNUO0dBQ0EsT0FBTztFQUNUO0VBQ0EsV0FBVztDQUNiLENBQUM7Q0FDRCxjQUFjLFFBQVEsVUFBVSxNQUFNLFlBQVk7Q0FJbEQsTUFBTSxtQkFBbUIsdUJBQXVCLGFBQWEsZ0JBQWdCO0VBRzNFLElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsTUFBTSxPQUFPLFNBQVMsR0FDbEQ7RUFFRix3QkFBd0IsV0FBVztFQUNuQyx3QkFBd0IsV0FBVztDQUNyQyxDQUFDO0NBQ0QseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUztHQUNyQix3QkFBd0IsQ0FBQztHQUN6Qix3QkFBd0IsQ0FBQztFQUMzQjtDQUNGLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQztDQUdsQix5QkFBeUI7RUFDdkIsSUFBSSxlQUFlLG9CQUNiO09BQUEsTUFDRixjQUFjLG1CQUFtQix1QkFBdUIsR0FBRyx3QkFBd0IsV0FBVyxJQUFJLEVBQUU7RUFBQTtFQUd4RyxhQUFhO0dBQ1gsSUFBSSxlQUFlLHNCQUFzQixNQUN2QyxjQUFjLG1CQUFtQixHQUFHLENBQUM7RUFFekM7Q0FDRixHQUFHO0VBQUM7RUFBVTtFQUFNO0VBQXNCO0VBQXNCO0NBQWEsQ0FBQztDQUM5RSx5QkFBeUIsT0FBTztFQUc5QixvQkFBb0IsUUFBUTtFQUM1QixzQkFBc0IsUUFBUTtFQUc5QixZQUFZLFFBQVE7RUFDcEIsdUJBQXVCO0VBQ3ZCLHVCQUF1QjtDQUN6QixDQUFDO0NBQ0QsT0FBTztBQUNUOzs7Ozs7OztBQy9HQSxJQUFhLFlBQWIsY0FBK0IsV0FBVztDQUl4QyxTQUFTLFdBQVcsQ0FBQztDQUNyQixPQUFPLFVBQVUsQ0FBQztDQUNsQixJQUFJLE1BQU0sUUFBUSxDQUFDO0NBQ25CLFlBQVksQ0FBQztBQUNmOztBQ1hBLElBQU0sWUFBWTtDQUNoQixHQUFHO0NBQ0gsUUFBTyxVQUFTLE1BQU07Q0FDdEIsU0FBUSxVQUFTLE1BQU07Q0FDdkIsd0JBQXVCLFVBQVMsTUFBTTtDQUN0Qyx3QkFBdUIsVUFBUyxNQUFNO0NBQ3RDLDBCQUF5QixVQUFTLE1BQU07Q0FDeEMsYUFBWSxVQUFTLE1BQU07Q0FDM0IsdUJBQXNCLFVBQVMsTUFBTTtDQUNyQyxpQkFBZ0IsVUFBUyxNQUFNO0NBQy9CLGtCQUFpQixVQUFTLE1BQU07Q0FDaEMsT0FBTSxVQUFTLE1BQU07QUFDdkI7Ozs7OztBQVFBLElBQWEsY0FBYixjQUFpQyxXQUFXO0NBQzFDLFlBQVksY0FBYyxZQUFZLFFBQVE7RUFDNUMsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDNUMsTUFBTSxRQUFRLG1CQUFtQixjQUFjLGlCQUFpQixZQUFZLE1BQU07RUFDbEYsTUFBTSxPQUFPLHFCQUFxQixlQUFlLEdBQUcsU0FBUztDQUMvRDtDQUNBLFdBQVcsVUFBVSxpQkFBaUI7RUFDcEMsYUFBYSw4QkFBOEI7R0FDekMsS0FBSyxJQUFJLDRCQUE0QixJQUFJO0VBQzNDO0VBQ0EsSUFBSSxDQUFDLFlBQVksYUFBYSxXQUFXLFFBQVEsS0FBSyxNQUFNLG1CQUFtQixNQUc3RSxhQUFhLFVBQVUsS0FBSyxNQUFNLHdCQUF3QjtFQUU1RCxLQUFLLFFBQVEsZUFBZSxVQUFVLFlBQVk7RUFDbEQsSUFBSSxhQUFhLFlBQ2Y7RUFFRixLQUFLLE1BQU0sb0JBQW9CLG1CQUFtQixVQUFVLFlBQVk7RUFDeEUsS0FBSyxPQUFPLHFCQUFxQixLQUFLLE9BQU8sVUFBVSxhQUFhLE9BQU8sQ0FBQztDQUM5RTtBQUNGOzs7Ozs7QUFPQSxTQUFnQix3QkFBd0I7Q0FDdEMsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7Q0FDNUMsT0FBTyxJQUFJLFVBQVUsT0FBTyxPQUFPLG1CQUFtQixRQUFXLGVBQWUsQ0FBQyxHQUFHLE9BQU8sT0FBTyxxQkFBcUIsZUFBZSxDQUFDLEdBQUcsU0FBUztBQUNySjtBQUNBLFNBQVMsbUJBQW1CLGNBQWMsaUJBQWlCLFlBQVksU0FBUyxPQUFPO0NBZXJGLE9BQU87RUFiTCxHQUFHLDZCQUE2QixpQkFBaUIsWUFBWSxNQUFNO0VBQ25FLE9BQU87RUFDUCx5QkFBeUI7RUFDekIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLFFBQVE7RUFDUix1QkFBdUI7RUFDdkIsdUJBQXVCO0VBQ3ZCLE1BQU07RUFDTixHQUFHO0NBRU07QUFDYjtBQUNBLFNBQVMscUJBQXFCLGlCQUFpQjtDQUM3QyxPQUFPO0VBQ0wsVUFBdUIsMkJBQU0sVUFBVTtFQUN2QyxhQUEwQiwyQkFBTSxVQUFVO0VBQzFDLHFCQUFrQywyQkFBTSxVQUFVO0VBQ2xELHdCQUF3QixFQUN0QixTQUFTLEtBQ1g7RUFDQTtFQUNBLGNBQWM7RUFDZCxzQkFBc0I7Q0FDeEI7QUFDRjs7QUM1RUEsU0FBZ0Isb0JBQW9CLE1BQU0sT0FBTztDQUMvQyxNQUFNLEVBQ0osVUFDQSxNQUFNLFVBQ04sY0FBYyxPQUNkLGNBQ0Esc0JBQ0EseUJBQXlCLDhCQUE4QixPQUN2RCxPQUFPLFlBQVksTUFDbkIsWUFDQSxRQUNBLFdBQVcsZUFDWCxrQkFBa0IsdUJBQXVCLFNBQ3ZDO0NBQ0osTUFBTSxXQUFXLFNBQVM7Q0FDMUIsTUFBTSxnQkFBZ0IsU0FBUztDQUMvQixNQUFNLFFBQVEsZ0JBQWdCLE9BQU87Q0FDckMsTUFBTSwwQkFBMEIsaUJBQWlCO0NBQ2pELE1BQU0sT0FBTyxnQkFBZ0IsZ0JBQWdCO0NBQzdDLE1BQU0sY0FBYyxxQkFBcUIsSUFBSTtDQUU3QyxNQUFNLFlBQVk7RUFDaEI7RUFDQTtFQUNBLFFBSmEsZUFBZTtFQUs1QjtDQUNGO0NBTUEsTUFBTSxRQUFRLG1CQUFtQixZQUFZLG1CQUFtQixJQUFJLFlBQVk7RUFDOUUsTUFBTTtFQUNOO0VBQ0EsaUJBQWlCO0VBQ2pCO0VBQ0EsR0FBRztDQUNMLEdBQUcsWUFBWSxjQUFjLEdBQUcsSUFBSTtDQUNwQyxNQUFNLGtCQUFrQixZQUFZLFFBQVE7Q0FDNUMsTUFBTSxrQkFBa0IsaUJBQWlCLGFBQWE7Q0FDdEQsTUFBTSxnQkFBZ0IsU0FBUztDQUMvQixNQUFNLG1CQUFtQixnQkFBZ0IsWUFBWTtDQUNyRCxNQUFNLG1CQUFtQix3QkFBd0Isb0JBQW9CO0NBQ3JFLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLGlCQUFpQixPQUFPLElBQUk7Q0FDNUIseUJBQXlCLEtBQUs7Q0FDOUIsTUFBTSxFQUNKLGlCQUNFLHdCQUF3QixNQUFNLEtBQUs7Q0FDdkMsYUFBTSxvQkFBb0IsbUJBQW1CO0VBQzNDLFNBQVM7RUFDVCxhQUFhLE1BQU0sUUFBUSxPQUFPLHlCQUF5QlgsZ0JBQXdCLENBQUM7Q0FDdEYsSUFBSSxDQUFDLGNBQWMsS0FBSyxDQUFDO0NBS3pCLE1BQU0sMkJBQTJCLFFBQVEsV0FBVyxVQUFVO0NBQzlELE9BQW9CLDJDQUFNLGtCQUFrQixVQUFVO0VBQ3BELE9BQU87RUFDUCxVQUFVO0dBQUMsVUFBdUIsMENBQUssdUJBQXVCO0lBQ3BEO0lBQ0Q7R0FDVCxDQUFDO0dBQUcsNEJBQXlDLDBDQUFLLG9CQUFvQjtJQUM3RDtJQUNQLGVBQWUsYUFBYTtJQUNsQjtHQUNaLENBQUM7R0FBRyxPQUFPLGFBQWEsYUFBYSxTQUFTLEVBQzVDLFFBQ0YsQ0FBQyxJQUFJO0VBQVE7Q0FDZixDQUFDO0FBQ0g7Ozs7Ozs7O0FDekVBLElBQWEsYUFBYSxjQUFjLFNBQVMsV0FBVyxPQUFPO0NBQ2pFLE9BQU8sb0JBQW9CLFVBQVUsS0FBSztBQUM1QyxDQUFDO0FBQzBDLFdBQVcsY0FBYzs7Ozs7Ozs7QUNBcEUsSUFBYSxpQkFBOEIsMkJBQU0sV0FBVyxTQUFTLGVBQWUsZ0JBQWdCLGNBQWM7Q0FDaEgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFVBQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sY0FBYyx1QkFBdUI7Q0FDM0MsTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxTQUFTLE1BQU0sU0FBUyxRQUFRO0NBQ3RDLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSx3QkFBd0IsTUFBTSxTQUFTLHVCQUF1QjtDQUNwRSxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsTUFBTSxxQkFBcUIsTUFBTSxlQUFlLGlCQUFpQjtDQVNqRSxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QyxTQUZtQixlQUFlO0VBR2xDO0dBUkE7R0FDQTtHQUNBO0dBQ0Esa0JBTHVCLHdCQUF3QjtFQVUzQztFQUNKLEtBQUssQ0FBQyxjQUFjLGtCQUFrQjtFQUN0Qyx3QkFBd0I7RUFDeEIsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLFFBQVEsQ0FBQztHQUNULE9BQU8sRUFDTCxlQUFlLENBQUMsT0FBTyxTQUFTLE9BQ2xDO0dBQ0E7RUFDRixHQUFHLFlBQVk7Q0FDakIsQ0FBQztBQUNILENBQUM7QUFDMEMsZUFBZSxjQUFjOzs7Ozs7OztBQ3pDeEUsSUFBYSxjQUEyQiwyQkFBTSxXQUFXLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUMxRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsSUFBSSxRQUNKLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FDN0IsTUFBTSwwQkFBMEIsa0JBQWtCLEVBQUU7Q0FDcEQsT0FBTyxpQkFBaUIsTUFBTSxnQkFBZ0I7RUFDNUMsS0FBSztFQUNMLE9BQU8sQ0FBQyxFQUNOLEdBQ0YsR0FBRyxZQUFZO0NBQ2pCLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7O0FDcEJyRSxTQUFnQix3QkFBd0IsU0FBUztDQUMvQyxNQUFNLDJDQUFvQyxPQUFPLEVBQUU7Q0FDbkQsTUFBTSxpQ0FBMEIsYUFBWSxVQUFTO0VBQ25ELElBQUksTUFBTSxrQkFDUjtFQUVGLDRCQUE0QixVQUFVLE1BQU07RUFDNUMsUUFBUSxPQUFPLE1BQU0sV0FBVztDQUNsQyxHQUFHLENBQUMsT0FBTyxDQUFDO0NBZVosT0FBTztFQUNMLHNCQWZ3QixhQUFZLFVBQVM7R0FFN0MsSUFBSSxNQUFNLFdBQVcsR0FBRztJQUN0QixRQUFRLE9BQU8sVUFBVTtJQUN6QjtHQUNGO0dBQ0EsSUFBSSxpQkFBaUIsT0FFbkIsUUFBUSxPQUFPLE1BQU0sV0FBVztRQUVoQyxRQUFRLE9BQU8sNEJBQTRCLE9BQU87R0FFcEQsNEJBQTRCLFVBQVU7RUFDeEMsR0FBRyxDQUFDLE9BQU8sQ0FFVTtFQUNuQixlQUFlO0NBQ2pCO0FBQ0Y7O0FDOUJBLFNBQWdCLDBCQUEwQixNQUFNLGVBQWU7Q0FXN0QsTUFBTSxFQUNKLFNBQ0Esa0JBQ0Usd0JBYnVCLG1CQUFtQixHQUFHLG9CQUFvQjtFQUVuRSxJQUFJLEVBRFcsT0FBTyxTQUFTLGFBQWEsS0FBSyxJQUFJLE9BRW5ELGNBQWMsb0JBSWRXLE1BQWtCLFVBQVUsR0FBRztDQUVuQyxDQUk0QixDQUFrQjtDQUM5QyxvQkFBYSxlQUFlO0VBQzFCO0VBQ0E7Q0FDRixJQUFJLENBQUMsU0FBUyxhQUFhLENBQUM7QUFDOUI7Ozs7Ozs7O0FDTEEsSUFBYSxnQkFBZ0IsaUJBQWlCLFNBQVMsY0FBYyxnQkFBZ0IsY0FBYztDQUNqRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsV0FBVyxPQUNYLGVBQWUsTUFDZixJQUFJLFFBQ0osU0FDQSxRQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLGtCQUFrQixxQkFBcUIsSUFBSTtDQUVqRCxNQUFNLFFBRGMsb0JBQW9CLE1BQ2hCLEtBQUs7Q0FDN0IsSUFBSSxDQUFDLE9BQ0gsTUFBTSxJQUFJLE1BQThDLHdGQUFrSDtDQUU1SyxNQUFNLGdCQUFnQixZQUFZLE1BQU07Q0FDeEMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLHFCQUFxQjtDQUM1RCxNQUFNLHdCQUF3QixNQUFNLFNBQVMscUJBQXFCLGFBQWE7Q0FDL0UsTUFBTSxVQUFVLE1BQU0sU0FBUyxrQkFBa0IsYUFBYTtDQUM5RCxNQUFNLGlDQUEwQixPQUFPLElBQUk7Q0FDM0MsTUFBTSxFQUNKLGlCQUNBLDJCQUNFLHlCQUF5QixlQUFlLG1CQUFtQixPQUFPLEVBQ3BFLFFBQ0YsQ0FBQztDQUNELE1BQU0sRUFDSixnQkFDQSxjQUNFLFVBQVU7RUFDWjtFQUNBLFFBQVE7Q0FDVixDQUFDO0NBQ0QsTUFBTSxRQUFRLFNBQVMsZUFBZTtDQUN0QyxNQUFNLHVCQUF1QixnQ0FBZ0MsTUFBTSxPQUFPLE1BQU0sSUFBRyxvQkFBbUI7RUFDcEcsTUFBTSxJQUFJLGNBQWMsZUFBZTtDQUN6QyxDQUFDO0NBQ0QsTUFBTSxRQUFRO0VBQ1o7RUFDQSxNQUFNO0NBQ1I7Q0FDQSxNQUFNLG1CQUFtQixNQUFNLFNBQVMsZ0JBQWdCLHNCQUFzQjtDQUM5RSxPQUFPLGlCQUFpQixVQUFVLGdCQUFnQjtFQUNoRDtFQUNBLEtBQUs7R0FBQztHQUFXO0dBQWM7R0FBaUI7RUFBaUI7RUFDakUsT0FBTztHQUFDLE1BQU07R0FBVztHQUFrQjtHQUFzQjtLQUM5RCwyQkFBMkI7SUFDNUIsSUFBSTtJQUNKLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsaUJBQWlCO0dBQ25CO0dBQUc7R0FBYztFQUFjO0VBQy9CLHdCQUF3QjtDQUMxQixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxjQUFjLGNBQWM7Ozs7Ozs7Ozs7QUNsRXZFLElBQWEsZUFBYixjQUFrQyxnQkFBZ0I7Q0FDaEQsY0FBYztFQUNaLE1BQU0sc0JBQXNCLEdBQUcsVUFBVSxLQUFLO0NBQ2hEOzs7Ozs7Ozs7Q0FVQSxLQUFLLFdBQVc7RUFDZCxLQUFLLGNBQWMsU0FBUztDQUM5Qjs7Ozs7Ozs7Q0FTQSxnQkFBZ0IsU0FBUztFQUN2QixNQUFNLGdCQUFnQixLQUFLO0VBQzNCLElBQUksa0JBQWtCLE1BQU07R0FFeEIsUUFBUSxLQUFLLHFNQUEwTTtHQUV6TjtFQUNGO0VBQ0EsY0FBYyxJQUFJLFdBQVcsT0FBTztFQUNwQyxjQUFjLFFBQVEsTUFBTSx5QkFBeUJYLGdCQUF3QixDQUFDO0NBQ2hGOzs7Ozs7Q0FPQSxRQUFRO0VBQ04sS0FBSyxXQUFXO0NBQ2xCOzs7O0NBS0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLGVBQWUsT0FBTyxNQUFNLEtBQUs7Q0FDL0M7QUFDRjs7OztBQUtBLFNBQWdCLHFCQUFxQjtDQUNuQyxPQUFPLElBQUksYUFBYTtBQUMxQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xFQSxJQUFhcEIsU0FBT0k7Ozs7QUFJcEIsSUFBYUgsV0FBU0k7Ozs7QUFJdEIsSUFBYVQsa0JBQWdCNkI7Ozs7QUFJN0IsSUFBYTVCLGdCQUFjNkI7Ozs7OztBQ2QzQixJQUFhTSxhQUFXOzs7Ozs7Ozs7Ozs7O0FDRXhCLElBQWEsT0FBTzVCOzs7O0FBSXBCLElBQWEsU0FBU0M7Ozs7QUFJdEIsSUFBYSxnQkFBZ0JvQjs7OztBQUk3QixJQUFhLGNBQWNDOzs7O0FBSTNCLElBQWEsU0FBUzs7OztBQUl0QixJQUFhLG1CQUFtQjs7Ozs7Ozs7O0FDcEJoQyxJQUFhLFdBQVc7Ozs7QUFJeEIsSUFBYSxZQUFZdkIiLCJuYW1lcyI6WyJzdGFydGluZ1N0eWxlIiwiZW5kaW5nU3R5bGUiLCJUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZSIsIlRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZSIsIm9wZW4iLCJjbG9zZWQiLCJwb3B1cE9wZW4iLCJDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucG9wdXBPcGVuIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFuY2hvckhpZGRlbiIsIlJFQVNPTlMuY2xvc2VQcmVzcyIsInBsYXRmb3JtLm9zLmFuZHJvaWQiLCJwbGF0Zm9ybS5lbnYuanNkb20iLCJwbGF0Zm9ybS5zY3JlZW5SZWFkZXIudm9pY2VPdmVyIiwicGxhdGZvcm0uZW5naW5lLndlYmtpdCIsImdldENvbXB1dGVkU3R5bGUiLCJvd25lcldpbmRvdyIsIlJFQVNPTlMuZm9jdXNPdXQiLCJSRUFTT05TLnRyaWdnZXJQcmVzcyIsIm91dHNpZGVQcmVzcyIsImVzY2FwZUtleSIsIlJFQVNPTlMuZXNjYXBlS2V5IiwiUkVBU09OUy5vdXRzaWRlUHJlc3MiLCJSRUFTT05TLmltcGVyYXRpdmVBY3Rpb24iLCJSRUFTT05TLm5vbmUiLCJ1c2VTeW5jRXh0ZXJuYWxTdG9yZSIsInVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yIiwic2VsZWN0b3JzIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZSIsIm5lc3RlZCIsIm5lc3RlZERpYWxvZ09wZW4iLCJEaWFsb2dQb3B1cERhdGFBdHRyaWJ1dGVzLm5lc3RlZERpYWxvZ09wZW4iLCJEaWFsb2dQb3B1cENzc1ZhcnMubmVzdGVkRGlhbG9ncyIsInBsYXRmb3JtLm9zLmlvcyIsImRpc2FibGVkIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIi4uLy4uL0BiYXNlLXVpL3V0aWxzL293bmVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9yb290L0RpYWxvZ1Jvb3RDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy9UcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9Db21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL2JhY2tkcm9wL0RpYWxvZ0JhY2tkcm9wLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9jbG9zZS9EaWFsb2dDbG9zZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvZGVzY3JpcHRpb24vRGlhbG9nRGVzY3JpcHRpb24ubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0vc2hhcmVkLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtL29zLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtL2VuZ2luZS5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9wbGF0Zm9ybS9zY3JlZW4tcmVhZGVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtL2Vudi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9ldmVudC5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9zaGFkb3dEb20ubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvY29uc3RhbnRzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2VsZW1lbnQubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lci5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9tZXJnZUNsZWFudXBzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZVZhbHVlQXNSZWYubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlQW5pbWF0aW9uRnJhbWUubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdmlzdWFsbHlIaWRkZW4ubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvRm9jdXNHdWFyZC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9jb21wb3NpdGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvdGFiYmFibGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvbm9kZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvY3JlYXRlQXR0cmlidXRlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2VucXVldWVGb2N1cy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9tYXJrT3RoZXJzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy9jb25zdGFudHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvY29tcG9uZW50cy9GbG9hdGluZ1BvcnRhbC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9jcmVhdGVFdmVudEVtaXR0ZXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvY29tcG9uZW50cy9GbG9hdGluZ1RyZWUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcmVzb2x2ZVJlZi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nRm9jdXNNYW5hZ2VyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZUNsaWNrLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZURpc21pc3MubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcG9wdXBzL3BvcHVwSGFuZGxlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZVN5bmNlZEZsb2F0aW5nUm9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL3VzZVRyYW5zaXRpb25TdGF0dXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvZ2V0RmluaXRlQW5pbWF0aW9ucy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvdXNlQW5pbWF0aW9uc0ZpbmlzaGVkLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy91c2VPcGVuQ2hhbmdlQ29tcGxldGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL3VzZVVubW91bnRBZnRlckNsb3NlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3BvcHVwcy9wb3B1cFN0b3JlVXRpbHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcG9wdXBzL3BvcHVwVHJpZ2dlck1hcC5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9mYXN0SG9va3MubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvc3RvcmUvdXNlU3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvc3RvcmUvU3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvc3RvcmUvUmVhY3RTdG9yZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nUm9vdFN0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3BvcHVwcy9zdG9yZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9wb3B1cHMvdXNlUG9wdXBIYW5kbGVTdG9yZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9ydGFsL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2NvbXBvc2l0ZS9jb21wb3NpdGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3BvcHVwL0RpYWxvZ1BvcHVwQ3NzVmFycy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9wdXAvRGlhbG9nUG9wdXBEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvdXRpbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9wdXAvRGlhbG9nUG9wdXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvaW5lcnRWYWx1ZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9JbnRlcm5hbEJhY2tkcm9wLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9wb3J0YWwvRGlhbG9nUG9ydGFsLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZVNjcm9sbExvY2subWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3Jvb3QvdXNlRGlhbG9nUm9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9OdWxsU3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3N0b3JlL0RpYWxvZ1N0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9yb290L3VzZVJlbmRlckRpYWxvZ1Jvb3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3Jvb3QvRGlhbG9nUm9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvdmlld3BvcnQvRGlhbG9nVmlld3BvcnQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3RpdGxlL0RpYWxvZ1RpdGxlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZUVuaGFuY2VkQ2xpY2tIYW5kbGVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3VzZU9wZW5JbnRlcmFjdGlvblR5cGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3RyaWdnZXIvRGlhbG9nVHJpZ2dlci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvc3RvcmUvRGlhbG9nSGFuZGxlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9iYWNrZHJvcC9EaWFsb2dCYWNrZHJvcERhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9jbG9zZS9EaWFsb2dDbG9zZURhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy92aWV3cG9ydC9EaWFsb2dWaWV3cG9ydERhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy90cmlnZ2VyL0RpYWxvZ1RyaWdnZXJEYXRhQXR0cmlidXRlcy5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHsgZ2V0V2luZG93IGFzIG93bmVyV2luZG93IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5leHBvcnQgZnVuY3Rpb24gb3duZXJEb2N1bWVudChub2RlKSB7XG4gIHJldHVybiBub2RlPy5vd25lckRvY3VtZW50IHx8IGRvY3VtZW50O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IERpYWxvZ1Jvb3RDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ1Jvb3RDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJEaWFsb2dSb290Q29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZURpYWxvZ1Jvb3RDb250ZXh0KG9wdGlvbmFsKSB7XG4gIGNvbnN0IHN0b3JlID0gUmVhY3QudXNlQ29udGV4dChEaWFsb2dSb290Q29udGV4dCk7XG4gIGlmICghb3B0aW9uYWwgJiYgc3RvcmUgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogRGlhbG9nUm9vdENvbnRleHQgaXMgbWlzc2luZy4gRGlhbG9nIHBhcnRzIG11c3QgYmUgcGxhY2VkIHdpdGhpbiA8RGlhbG9nLlJvb3Q+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDI3KSk7XG4gIH1cbiAgcmV0dXJuIHN0b3JlO1xufSIsIi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjb21wb25lbnQgYmVnaW5zIGFuaW1hdGluZyBpbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHN0YXJ0aW5nU3R5bGUgPSAnZGF0YS1zdGFydGluZy1zdHlsZSc7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjb21wb25lbnQgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gJ2RhdGEtZW5kaW5nLXN0eWxlJzsiLCJpbXBvcnQgKiBhcyBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMgZnJvbSBcIi4vVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLm1qc1wiO1xuZXhwb3J0IHsgVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzIH07XG5jb25zdCBTVEFSVElOR19IT09LID0ge1xuICBbVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGVdOiAnJ1xufTtcbmNvbnN0IEVORElOR19IT09LID0ge1xuICBbVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlXTogJydcbn07XG5leHBvcnQgY29uc3QgdHJhbnNpdGlvblN0YXR1c01hcHBpbmcgPSB7XG4gIHRyYW5zaXRpb25TdGF0dXModmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT09ICdzdGFydGluZycpIHtcbiAgICAgIHJldHVybiBTVEFSVElOR19IT09LO1xuICAgIH1cbiAgICBpZiAodmFsdWUgPT09ICdlbmRpbmcnKSB7XG4gICAgICByZXR1cm4gRU5ESU5HX0hPT0s7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59OyIsImltcG9ydCAqIGFzIFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcyBmcm9tIFwiLi4vaW50ZXJuYWxzL1RyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBvcGVuID0gJ2RhdGEtb3Blbic7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBwb3B1cCBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSAnZGF0YS1jbG9zZWQnO1xuXG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgcG9wdXAgYmVnaW5zIGFuaW1hdGluZyBpbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHN0YXJ0aW5nU3R5bGUgPSBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGlzIGFuaW1hdGluZyBvdXQuXG4gKi9cbmV4cG9ydCBjb25zdCBlbmRpbmdTdHlsZSA9IFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGFuY2hvciBpcyBoaWRkZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBhbmNob3JIaWRkZW4gPSAnZGF0YS1hbmNob3ItaGlkZGVuJztcblxuLyoqXG4gKiBJbmRpY2F0ZXMgd2hpY2ggc2lkZSB0aGUgcG9wdXAgaXMgcG9zaXRpb25lZCByZWxhdGl2ZSB0byB0aGUgdHJpZ2dlci5cbiAqIEB0eXBlIHsgJ3RvcCcgfCAnYm90dG9tJyB8ICdsZWZ0JyB8ICdyaWdodCcgfCAnaW5saW5lLWVuZCcgfCAnaW5saW5lLXN0YXJ0J31cbiAqL1xuZXhwb3J0IGNvbnN0IHNpZGUgPSAnZGF0YS1zaWRlJztcblxuLyoqXG4gKiBJbmRpY2F0ZXMgaG93IHRoZSBwb3B1cCBpcyBhbGlnbmVkIHJlbGF0aXZlIHRvIHNwZWNpZmllZCBzaWRlLlxuICogQHR5cGUgeydzdGFydCcgfCAnY2VudGVyJyB8ICdlbmQnfVxuICovXG5leHBvcnQgY29uc3QgYWxpZ24gPSAnZGF0YS1hbGlnbic7IiwiLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBwb3B1cE9wZW4gPSAnZGF0YS1wb3B1cC1vcGVuJztcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gYSBwcmVzc2FibGUgdHJpZ2dlciBpcyBwcmVzc2VkLlxuICovXG5leHBvcnQgY29uc3QgcHJlc3NlZCA9ICdkYXRhLXByZXNzZWQnOyIsImltcG9ydCB7IHRyYW5zaXRpb25TdGF0dXNNYXBwaW5nIH0gZnJvbSBcIi4uL2ludGVybmFscy9zdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyBmcm9tIFwiLi9Db21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzIGZyb20gXCIuL0NvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5tanNcIjtcbmV4cG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMsIENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcyB9O1xuY29uc3QgVFJJR0dFUl9IT09LID0ge1xuICBbQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnBvcHVwT3Blbl06ICcnXG59O1xuY29uc3QgUFJFU1NBQkxFX1RSSUdHRVJfSE9PSyA9IHtcbiAgW0NvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wb3B1cE9wZW5dOiAnJyxcbiAgW0NvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wcmVzc2VkXTogJydcbn07XG5jb25zdCBQT1BVUF9PUEVOX0hPT0sgPSB7XG4gIFtDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW5dOiAnJ1xufTtcbmNvbnN0IFBPUFVQX0NMT1NFRF9IT09LID0ge1xuICBbQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWRdOiAnJ1xufTtcbmNvbnN0IEFOQ0hPUl9ISURERU5fSE9PSyA9IHtcbiAgW0NvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuYW5jaG9ySGlkZGVuXTogJydcbn07XG5leHBvcnQgY29uc3QgdHJpZ2dlck9wZW5TdGF0ZU1hcHBpbmcgPSB7XG4gIG9wZW4odmFsdWUpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBUUklHR0VSX0hPT0s7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59O1xuZXhwb3J0IGNvbnN0IHByZXNzYWJsZVRyaWdnZXJPcGVuU3RhdGVNYXBwaW5nID0ge1xuICBvcGVuKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICByZXR1cm4gUFJFU1NBQkxFX1RSSUdHRVJfSE9PSztcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn07XG5leHBvcnQgY29uc3QgcG9wdXBTdGF0ZU1hcHBpbmcgPSB7XG4gIG9wZW4odmFsdWUpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBQT1BVUF9PUEVOX0hPT0s7XG4gICAgfVxuICAgIHJldHVybiBQT1BVUF9DTE9TRURfSE9PSztcbiAgfSxcbiAgYW5jaG9ySGlkZGVuKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICByZXR1cm4gQU5DSE9SX0hJRERFTl9IT09LO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufTtcbmV4cG9ydCBjb25zdCBwb3B1cFRyYW5zaXRpb25TdGF0ZU1hcHBpbmcgPSB7XG4gIC4uLnBvcHVwU3RhdGVNYXBwaW5nLFxuICAuLi50cmFuc2l0aW9uU3RhdHVzTWFwcGluZ1xufTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIEFuIG92ZXJsYXkgZGlzcGxheWVkIGJlbmVhdGggdGhlIHBvcHVwLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dCYWNrZHJvcCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ0JhY2tkcm9wKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZm9yY2VSZW5kZXIgPSBmYWxzZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBuZXN0ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbmVzdGVkJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCB0cmFuc2l0aW9uU3RhdHVzID0gc3RvcmUudXNlU3RhdGUoJ3RyYW5zaXRpb25TdGF0dXMnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHJlZjogW3N0b3JlLmNvbnRleHQuYmFja2Ryb3BSZWYsIGZvcndhcmRlZFJlZl0sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nLFxuICAgIHByb3BzOiBbe1xuICAgICAgcm9sZTogJ3ByZXNlbnRhdGlvbicsXG4gICAgICBoaWRkZW46ICFtb3VudGVkLFxuICAgICAgc3R5bGU6IHtcbiAgICAgICAgdXNlclNlbGVjdDogJ25vbmUnLFxuICAgICAgICBXZWJraXRVc2VyU2VsZWN0OiAnbm9uZSdcbiAgICAgIH1cbiAgICB9LCBlbGVtZW50UHJvcHNdLFxuICAgIGVuYWJsZWQ6IGZvcmNlUmVuZGVyIHx8ICFuZXN0ZWRcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ0JhY2tkcm9wLmRpc3BsYXlOYW1lID0gXCJEaWFsb2dCYWNrZHJvcFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBjbG9zZXMgdGhlIGRpYWxvZy5cbiAqIFJlbmRlcnMgYSBgPGJ1dHRvbj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgRGlhbG9nXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvZGlhbG9nKVxuICovXG5leHBvcnQgY29uc3QgRGlhbG9nQ2xvc2UgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBEaWFsb2dDbG9zZShjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgbmF0aXZlQnV0dG9uID0gdHJ1ZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCB7XG4gICAgZ2V0QnV0dG9uUHJvcHMsXG4gICAgYnV0dG9uUmVmXG4gIH0gPSB1c2VCdXR0b24oe1xuICAgIGRpc2FibGVkLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uXG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBkaXNhYmxlZFxuICB9O1xuICBmdW5jdGlvbiBoYW5kbGVDbGljayhldmVudCkge1xuICAgIGlmIChvcGVuKSB7XG4gICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5jbG9zZVByZXNzLCBldmVudC5uYXRpdmVFdmVudCkpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnYnV0dG9uJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIGJ1dHRvblJlZl0sXG4gICAgcHJvcHM6IFt7XG4gICAgICBvbkNsaWNrOiBoYW5kbGVDbGlja1xuICAgIH0sIGVsZW1lbnRQcm9wcywgZ2V0QnV0dG9uUHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dDbG9zZS5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nQ2xvc2VcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuLyoqXG4gKiBBIHBhcmFncmFwaCB3aXRoIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGRpYWxvZy5cbiAqIFJlbmRlcnMgYSBgPHA+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuZXhwb3J0IGNvbnN0IERpYWxvZ0Rlc2NyaXB0aW9uID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nRGVzY3JpcHRpb24oY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZVdpdGhDbGVhbnVwKCdkZXNjcmlwdGlvbkVsZW1lbnRJZCcsIGlkKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ3AnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIHByb3BzOiBbe1xuICAgICAgaWRcbiAgICB9LCBlbGVtZW50UHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dEZXNjcmlwdGlvbi5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nRGVzY3JpcHRpb25cIjsiLCIvKipcbiAqIFJlYWRzIGBuYXZpZ2F0b3IudXNlckFnZW50YCAvIGBuYXZpZ2F0b3IucGxhdGZvcm1gIChsZWdhY3kgYnV0IHVuaXZlcnNhbGx5XG4gKiBzdXBwb3J0ZWQpIGludG8gYSBub3JtYWxpemVkIHNoYXBlLiBJbiBkZXZlbG9wbWVudCwgcHJlZmVycyB0aGUgbW9kZXJuXG4gKiBgbmF2aWdhdG9yLnVzZXJBZ2VudERhdGFgIEFQSSBvbiBDaHJvbWl1bSB0byBhdm9pZCBEZXZUb29scyB3YXJuaW5ncyBhYm91dFxuICogdGhlIGRlcHJlY2F0ZWQgcmVhZHM7IHRoYXQgYnJhbmNoIGlzIGRlYWQtY29kZS1lbGltaW5hdGVkIGluIHByb2R1Y3Rpb25cbiAqIGJ1aWxkcyB0byBrZWVwIHRoZSBidW5kbGUgc21hbGwuXG4gKlxuICogUmV0dXJucyBlbXB0eS96ZXJvIHZhbHVlcyB3aGVuIGBuYXZpZ2F0b3JgIGlzIHVuZGVmaW5lZCAoU1NSKSwgc28gZXZlcnlcbiAqIGRlcml2ZWQgZmxhZyBzYWZlbHkgZXZhbHVhdGVzIHRvIGBmYWxzZWAuXG4gKi9cbmZ1bmN0aW9uIHJlYWRSYXdEYXRhKCkge1xuICBpZiAodHlwZW9mIG5hdmlnYXRvciA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4ge1xuICAgICAgdXNlckFnZW50OiAnJyxcbiAgICAgIHBsYXRmb3JtOiAnJyxcbiAgICAgIG1heFRvdWNoUG9pbnRzOiAwXG4gICAgfTtcbiAgfVxuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGNvbnN0IHVhRGF0YSA9IG5hdmlnYXRvci51c2VyQWdlbnREYXRhO1xuICAgIGlmICh1YURhdGEgJiYgQXJyYXkuaXNBcnJheSh1YURhdGEuYnJhbmRzKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdXNlckFnZW50OiB1YURhdGEuYnJhbmRzLm1hcCgoe1xuICAgICAgICAgIGJyYW5kLFxuICAgICAgICAgIHZlcnNpb25cbiAgICAgICAgfSkgPT4gYCR7YnJhbmR9LyR7dmVyc2lvbn1gKS5qb2luKCcgJyksXG4gICAgICAgIHBsYXRmb3JtOiB1YURhdGEucGxhdGZvcm0gPz8gbmF2aWdhdG9yLnBsYXRmb3JtID8/ICcnLFxuICAgICAgICBtYXhUb3VjaFBvaW50czogbmF2aWdhdG9yLm1heFRvdWNoUG9pbnRzID8/IDBcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgdXNlckFnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxuICAgIHBsYXRmb3JtOiBuYXZpZ2F0b3IucGxhdGZvcm0gPz8gJycsXG4gICAgbWF4VG91Y2hQb2ludHM6IG5hdmlnYXRvci5tYXhUb3VjaFBvaW50cyA/PyAwXG4gIH07XG59XG5jb25zdCB7XG4gIHVzZXJBZ2VudCxcbiAgcGxhdGZvcm0sXG4gIG1heFRvdWNoUG9pbnRzXG59ID0gcmVhZFJhd0RhdGEoKTtcbmV4cG9ydCBjb25zdCBsb3dlclVzZXJBZ2VudCA9IHVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpO1xuZXhwb3J0IGNvbnN0IGxvd2VyUGxhdGZvcm0gPSBwbGF0Zm9ybS50b0xvd2VyQ2FzZSgpO1xuZXhwb3J0IHsgbWF4VG91Y2hQb2ludHMgfTsiLCJpbXBvcnQgeyBsb3dlclVzZXJBZ2VudCwgbG93ZXJQbGF0Zm9ybSwgbWF4VG91Y2hQb2ludHMgfSBmcm9tIFwiLi9zaGFyZWQubWpzXCI7XG5cbi8vIGlQYWRPUyAxMysgcmVwb3J0cyBgTWFjSW50ZWxgIGZvciBgbmF2aWdhdG9yLnBsYXRmb3JtYDsgZGlzYW1iaWd1YXRlZCB2aWFcbi8vIGBtYXhUb3VjaFBvaW50c2Agc28gaVBhZCBpcyBjbGFzc2lmaWVkIGFzIGlPUywgbm90IG1hY09TLlxuLy8gaHR0cHM6Ly9naXRodWIuY29tL211aS9iYXNlLXVpL2lzc3Vlcy8xMzA5XG4vKiogaVBob25lLCBpUGFkIChpbmNsdWRpbmcgaVBhZE9TIDEzKyByZXBvcnRpbmcgYXMgbWFjT1MpLCBpUG9kLiAqL1xuZXhwb3J0IGNvbnN0IGlvcyA9IC9eaShvcyR8cCkvLnRlc3QobG93ZXJQbGF0Zm9ybSkgfHwgbG93ZXJQbGF0Zm9ybSA9PT0gJ21hY2ludGVsJyAmJiBtYXhUb3VjaFBvaW50cyA+IDE7XG5cbi8qKiBBbmRyb2lkIHBob25lcywgdGFibGV0cywgYW5kIGVtYmVkZGVkIEFuZHJvaWQgYnJvd3NlcnMuICovXG5jb25zdCBBTkRST0lEX1NUUklORyA9ICdhbmRyb2lkJztcbmV4cG9ydCBjb25zdCBhbmRyb2lkID0gbG93ZXJQbGF0Zm9ybSA9PT0gQU5EUk9JRF9TVFJJTkcgfHwgbG93ZXJVc2VyQWdlbnQuaW5jbHVkZXMoQU5EUk9JRF9TVFJJTkcpO1xuXG4vKiogbWFjT1MgZGVza3RvcC4gRXhjbHVkZXMgaVBhZE9TLCB3aGljaCByZXBvcnRzIGFzIGBNYWNJbnRlbGAuICovXG5leHBvcnQgY29uc3QgbWFjID0gIWlvcyAmJiBsb3dlclBsYXRmb3JtLnN0YXJ0c1dpdGgoJ21hYycpO1xuXG4vKiogV2luZG93cyBkZXNrdG9wLiAqL1xuZXhwb3J0IGNvbnN0IHdpbmRvd3MgPSBsb3dlclBsYXRmb3JtLnN0YXJ0c1dpdGgoJ3dpbicpO1xuXG4vKiogTGludXggZGVza3RvcCAoaW5jbHVkaW5nIENocm9tZSBPUykuICovXG5leHBvcnQgY29uc3QgbGludXggPSAhYW5kcm9pZCAmJiAvXihsaW51eHxjaHJvbWUgb3MpLy50ZXN0KGxvd2VyUGxhdGZvcm0pO1xuXG4vKiogQW55IEFwcGxlIE9TIChgbWFjIHx8IGlvc2ApLiAqL1xuZXhwb3J0IGNvbnN0IGFwcGxlID0gbWFjIHx8IGlvczsiLCJpbXBvcnQgeyBsb3dlclVzZXJBZ2VudCB9IGZyb20gXCIuL3NoYXJlZC5tanNcIjtcblxuLy8gV2ViS2l0IChTYWZhcmksIGFsbCBpT1MgYnJvd3NlcnMsIEdOT01FIFdlYikuIERpc3Rpbmd1aXNoZWQgZnJvbSBCbGluayBieVxuLy8gdGhlIGxlZ2FjeSBgLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXJgIG5hbWUg4oCUIEJsaW5rIGZvcmtlZCBmcm9tIFdlYktpdCBpbiAyMDEzXG4vLyBhbmQgb25seSBzaGlwcyB0aGUgdW5wcmVmaXhlZCBgYmFja2Ryb3AtZmlsdGVyYC5cbi8qKiBXZWJLaXQ6IFNhZmFyaSwgYWxsIGlPUyBicm93c2VycywgR05PTUUgV2ViLiBFeGNsdWRlcyBCbGluay4gKi9cbmV4cG9ydCBjb25zdCB3ZWJraXQgPSB0eXBlb2YgQ1NTICE9PSAndW5kZWZpbmVkJyAmJiAhIUNTUy5zdXBwb3J0cz8uKCctd2Via2l0LWJhY2tkcm9wLWZpbHRlcjpub25lJyk7XG5cbi8vIEFuY2hvcmVkIHRvIGAhd2Via2l0YCBzbyBlbmdpbmVzIGFyZSBtdXR1YWxseSBleGNsdXNpdmUgYnkgY29uc3RydWN0aW9uLlxuLy8gRmlyZWZveC1vbi1pT1MgdXNlcyBXZWJLaXQgKGl0cyBVQSBtYXJrZXIgaXMgYEZ4aU9TL2AsIG5vdCBgRmlyZWZveC9gKTsgdGhlXG4vLyBgIXdlYmtpdGAgcHJlZml4IGFsc28gZGVmZW5kcyBhZ2FpbnN0IGZ1dHVyZSBpT1MtYnJvd3NlciBVQSBjaGFuZ2VzIHRoYXRcbi8vIG1pZ2h0IGluamVjdCBgRmlyZWZveGAgaW50byBhIFdlYktpdC1iYXNlZCBVQS5cbi8qKiBHZWNrbzogRmlyZWZveC4gKi9cbmV4cG9ydCBjb25zdCBnZWNrbyA9ICF3ZWJraXQgJiYgbG93ZXJVc2VyQWdlbnQuaW5jbHVkZXMoJ2ZpcmVmb3gnKTtcblxuLy8gQWxsIENocm9taXVtLWJhc2VkIGJyb3dzZXJzIHNoaXAgYENocm9tZS9gIG9yIGBDaHJvbWl1bS9gIGluIHRoZWlyIFVBIOKAlCBib3RoXG4vLyBzaGFyZSB0aGUgYGNocm9tYCBwcmVmaXgsIHNvIGEgc2luZ2xlIHN1YnN0cmluZyBjaGVjayBjb3ZlcnMgQ2hyb21lLCBFZGdlLFxuLy8gT3BlcmEsIEJyYXZlLCBldGMuIENocm9tZS1vbi1pT1MgdXNlcyBgQ3JpT1MvYCBhbmQgc3RheXMgV2ViS2l0LiBUaGUgcG9zaXRpdmVcbi8vIFVBIGNoZWNrIGFsc28gbWFrZXMgdGhpcyBTU1Itc2FmZSDigJQgYW4gZW1wdHkgVUEgbWF0Y2hlcyBub3RoaW5nLlxuLyoqIEJsaW5rOiBDaHJvbWUsIEVkZ2UsIE9wZXJhLCBCcmF2ZSwgYW5kIG90aGVyIENocm9taXVtLWJhc2VkIGJyb3dzZXJzLiAqL1xuZXhwb3J0IGNvbnN0IGJsaW5rID0gIXdlYmtpdCAmJiBsb3dlclVzZXJBZ2VudC5pbmNsdWRlcygnY2hyb20nKTsiLCJpbXBvcnQgeyBhcHBsZSB9IGZyb20gXCIuL29zLm1qc1wiO1xuXG4vLyBXaGV0aGVyIGEgc2NyZWVuIHJlYWRlciBpcyAqYWN0dWFsbHkqIHJ1bm5pbmcgY2Fubm90IGJlIGRldGVjdGVkLiBUaGVzZSBmbGFnc1xuLy8gaWRlbnRpZnkgcGxhdGZvcm1zIHdoZXJlIGEgc3BlY2lmaWMgc2NyZWVuIHJlYWRlciBjb3VsZCBiZSBhY3RpdmUuIFZvaWNlT3ZlclxuLy8gaXMgdGhlIHN5c3RlbSBzY3JlZW4gcmVhZGVyIG9uIEFwcGxlIHBsYXRmb3JtcyBhbmQgd29ya3Mgd2l0aCBldmVyeSBicm93c2VyXG4vLyB0aGVyZSwgc28gdGhlIGZsYWcgaXMgcHVyZWx5IGFuIE9TIGNoZWNrOyBlbmdpbmUtc3BlY2lmaWMgcXVpcmtzIChlLmcuIHRoZVxuLy8gTlNBY2Nlc3NpYmlsaXR5IHZpcnR1YWwtY3Vyc29yIGZvY3VzIHBhdGgpIHNob3VsZCBiZSBnYXRlZCBhdCB0aGUgY2FsbCBzaXRlLlxuLyoqXG4gKiBUaGUgdXNlciAqbWF5KiBiZSB1c2luZyBWb2ljZU92ZXIg4oCUIGFjdHVhbCBhY3RpdmF0aW9uIGlzIG5vdCBkZXRlY3RhYmxlLlxuICogVHJ1ZSBvbiBhbnkgQXBwbGUgcGxhdGZvcm0gKG1hY09TLCBpT1MsIGlQYWRPUykuXG4gKi9cbmV4cG9ydCBjb25zdCB2b2ljZU92ZXIgPSBhcHBsZTsiLCJpbXBvcnQgeyBsb3dlclVzZXJBZ2VudCB9IGZyb20gXCIuL3NoYXJlZC5tanNcIjtcblxuLyoqIFJ1bm5pbmcgaW4ganNkb20gb3IgSGFwcHlET00gKHVzZWQgYnkgdW5pdCB0ZXN0cykuICovXG5leHBvcnQgY29uc3QganNkb20gPSAvanNkb218aGFwcHlkb20vLnRlc3QobG93ZXJVc2VyQWdlbnQpOyIsImltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0nO1xuZXhwb3J0IGZ1bmN0aW9uIHN0b3BFdmVudChldmVudCkge1xuICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1JlYWN0RXZlbnQoZXZlbnQpIHtcbiAgcmV0dXJuICduYXRpdmVFdmVudCcgaW4gZXZlbnQ7XG59XG5cbi8vIExpY2Vuc2U6IGh0dHBzOi8vZ2l0aHViLmNvbS9hZG9iZS9yZWFjdC1zcGVjdHJ1bS9ibG9iL21haW4vcGFja2FnZXMvQHJlYWN0LWFyaWEvdXRpbHMvc3JjL2lzVmlydHVhbEV2ZW50LnRzXG5leHBvcnQgZnVuY3Rpb24gaXNWaXJ0dWFsQ2xpY2soZXZlbnQpIHtcbiAgaWYgKGV2ZW50LnBvaW50ZXJUeXBlID09PSAnJyAmJiBldmVudC5pc1RydXN0ZWQpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAocGxhdGZvcm0ub3MuYW5kcm9pZCAmJiBldmVudC5wb2ludGVyVHlwZSkge1xuICAgIHJldHVybiBldmVudC50eXBlID09PSAnY2xpY2snICYmIGV2ZW50LmJ1dHRvbnMgPT09IDE7XG4gIH1cbiAgcmV0dXJuIGV2ZW50LmRldGFpbCA9PT0gMCAmJiAhZXZlbnQucG9pbnRlclR5cGU7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNWaXJ0dWFsUG9pbnRlckV2ZW50KGV2ZW50KSB7XG4gIGlmIChwbGF0Zm9ybS5lbnYuanNkb20pIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuICFwbGF0Zm9ybS5vcy5hbmRyb2lkICYmIGV2ZW50LndpZHRoID09PSAwICYmIGV2ZW50LmhlaWdodCA9PT0gMCB8fFxuICAvLyBDaHJvbWUgc3ludGhlc2l6ZXMgYSBzY3JlZW4gcmVhZGVyIHByZXNzIChUYWxrQmFjaywgVm9pY2VPdmVyLCBOVkRBKSBhcyBhIDF4MSBtb3VzZVxuICAvLyBgcG9pbnRlcmRvd25gIHdpdGggbm8gcHJlc3N1cmUuIFRhbGtCYWNrIGNhbiByZXBvcnQgYSBwcmVzc2VkIGJ1dHRvbiwgd2hpbGUgZGVza3RvcFxuICAvLyBtb3VzZSBwcmVzc2VzIGNhbiByZXBvcnQgbm8gcHJlc3N1cmUsIHNvIG9ubHkgcmVxdWlyZSBubyBwcmVzc2VkIGJ1dHRvbiBvZmYgQW5kcm9pZC5cbiAgZXZlbnQudHlwZSA9PT0gJ3BvaW50ZXJkb3duJyAmJiBldmVudC53aWR0aCA9PT0gMSAmJiBldmVudC5oZWlnaHQgPT09IDEgJiYgZXZlbnQucHJlc3N1cmUgPT09IDAgJiYgZXZlbnQuZGV0YWlsID09PSAwICYmIGV2ZW50LnBvaW50ZXJUeXBlID09PSAnbW91c2UnICYmIChwbGF0Zm9ybS5vcy5hbmRyb2lkIHx8IGV2ZW50LmJ1dHRvbnMgPT09IDApIHx8XG4gIC8vIGlPUyBWb2ljZU92ZXIgcmV0dXJucyAwLjMzM+KAoiBmb3Igd2lkdGgvaGVpZ2h0LlxuICBldmVudC53aWR0aCA8IDEgJiYgZXZlbnQuaGVpZ2h0IDwgMSAmJiBldmVudC5wcmVzc3VyZSA9PT0gMCAmJiBldmVudC5kZXRhaWwgPT09IDAgJiYgZXZlbnQucG9pbnRlclR5cGUgPT09ICd0b3VjaCc7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZSwgc3RyaWN0KSB7XG4gIC8vIE9uIHNvbWUgTGludXggbWFjaGluZXMgd2l0aCBDaHJvbWl1bSwgbW91c2UgaW5wdXRzIHJldHVybiBhIGBwb2ludGVyVHlwZWBcbiAgLy8gb2YgXCJwZW5cIjogaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8yMDE1XG4gIGNvbnN0IHZhbHVlcyA9IFsnbW91c2UnLCAncGVuJ107XG4gIGlmICghc3RyaWN0KSB7XG4gICAgdmFsdWVzLnB1c2goJycsIHVuZGVmaW5lZCk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlcy5pbmNsdWRlcyhwb2ludGVyVHlwZSk7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNDbGlja0xpa2VFdmVudChldmVudCkge1xuICBjb25zdCB0eXBlID0gZXZlbnQudHlwZTtcbiAgcmV0dXJuIHR5cGUgPT09ICdjbGljaycgfHwgdHlwZSA9PT0gJ21vdXNlZG93bicgfHwgdHlwZSA9PT0gJ2tleWRvd24nIHx8IHR5cGUgPT09ICdrZXl1cCc7XG59IiwiaW1wb3J0IHsgaXNFbGVtZW50LCBpc1NoYWRvd1Jvb3QgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmV4cG9ydCBmdW5jdGlvbiBhY3RpdmVFbGVtZW50KGRvYykge1xuICBsZXQgZWxlbWVudCA9IGRvYy5hY3RpdmVFbGVtZW50O1xuICB3aGlsZSAoZWxlbWVudD8uc2hhZG93Um9vdD8uYWN0aXZlRWxlbWVudCAhPSBudWxsKSB7XG4gICAgZWxlbWVudCA9IGVsZW1lbnQuc2hhZG93Um9vdC5hY3RpdmVFbGVtZW50O1xuICB9XG4gIHJldHVybiBlbGVtZW50O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNvbnRhaW5zKHBhcmVudCwgY2hpbGQpIHtcbiAgaWYgKCFwYXJlbnQgfHwgIWNoaWxkKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGNvbnN0IHJvb3ROb2RlID0gY2hpbGQuZ2V0Um9vdE5vZGU/LigpO1xuXG4gIC8vIEZpcnN0LCBhdHRlbXB0IHdpdGggdGhlIGZhc3RlciBuYXRpdmUgbWV0aG9kLlxuICBpZiAocGFyZW50LmNvbnRhaW5zKGNoaWxkKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgLy8gVGhlbiBmYWxsIGJhY2sgdG8gdHJhdmVyc2luZyBvdXQgb2Ygc2hhZG93IHJvb3RzIHdoZW4gbmVlZGVkLlxuICBpZiAocm9vdE5vZGUgJiYgaXNTaGFkb3dSb290KHJvb3ROb2RlKSkge1xuICAgIGxldCBuZXh0ID0gY2hpbGQ7XG4gICAgd2hpbGUgKG5leHQpIHtcbiAgICAgIGlmIChwYXJlbnQgPT09IG5leHQpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBuZXh0ID0gbmV4dC5wYXJlbnROb2RlIHx8IG5leHQuaG9zdDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vKipcbiAqIEZpbmRzIHRoZSBjbG9zZXN0IG1hdGNoaW5nIGVsZW1lbnQgaW4gdGhlIGNvbXBvc2VkIHRyZWUsIGNyb3NzaW5nIHNsb3RzIGFuZCBzaGFkb3cgcm9vdHMuXG4gKiBgOnNjb3BlYCBpcyBub3Qgc3VwcG9ydGVkLlxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBjbG9zZXN0KG5vZGUsIHNlbGVjdG9yKSB7XG4gIGxldCBjdXJyZW50ID0gbm9kZTtcbiAgd2hpbGUgKGN1cnJlbnQpIHtcbiAgICBpZiAoaXNFbGVtZW50KGN1cnJlbnQpICYmIGN1cnJlbnQubWF0Y2hlcyhzZWxlY3RvcikpIHtcbiAgICAgIHJldHVybiBjdXJyZW50O1xuICAgIH1cbiAgICBjdXJyZW50ID0gY3VycmVudC5hc3NpZ25lZFNsb3QgPz8gY3VycmVudC5wYXJlbnROb2RlID8/IChpc1NoYWRvd1Jvb3QoY3VycmVudCkgPyBjdXJyZW50Lmhvc3QgOiBudWxsKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRUYXJnZXQoZXZlbnQpIHtcbiAgaWYgKCdjb21wb3NlZFBhdGgnIGluIGV2ZW50KSB7XG4gICAgLy8gVGhlIGNvbXBvc2VkIHBhdGggaXMgZW1wdHkgb25jZSB0aGUgZXZlbnQgaXMgbm8gbG9uZ2VyIGJlaW5nIGRpc3BhdGNoZWQsXG4gICAgLy8gc28gZmFsbCBiYWNrIHRvIGB0YXJnZXRgIGZvciBoYW5kbGVycyBydW5uaW5nIGFmdGVyIGRpc3BhdGNoIGNvbXBsZXRlcy5cbiAgICByZXR1cm4gZXZlbnQuY29tcG9zZWRQYXRoKClbMF0gPz8gZXZlbnQudGFyZ2V0O1xuICB9XG5cbiAgLy8gVFMgYXNzdW1lcyBgY29tcG9zZWRQYXRoKClgIGFsd2F5cyBleGlzdHMsIGJ1dCBvbGRlciBicm93c2VycyB3aXRob3V0XG4gIC8vIHNoYWRvdyBET00gc3VwcG9ydCBzdGlsbCBmYWxsIGJhY2sgdG8gYHRhcmdldGAuXG4gIHJldHVybiBldmVudC50YXJnZXQ7XG59IiwiZXhwb3J0IGNvbnN0IEZPQ1VTQUJMRV9BVFRSSUJVVEUgPSAnZGF0YS1iYXNlLXVpLWZvY3VzYWJsZSc7XG5leHBvcnQgY29uc3QgQUNUSVZFX0tFWSA9ICdhY3RpdmUnO1xuZXhwb3J0IGNvbnN0IFNFTEVDVEVEX0tFWSA9ICdzZWxlY3RlZCc7XG5leHBvcnQgY29uc3QgVFlQRUFCTEVfU0VMRUNUT1IgPSBcImlucHV0Om5vdChbdHlwZT0naGlkZGVuJ10pOm5vdChbZGlzYWJsZWRdKSxcIiArIFwiW2NvbnRlbnRlZGl0YWJsZV06bm90KFtjb250ZW50ZWRpdGFibGU9J2ZhbHNlJ10pLHRleHRhcmVhOm5vdChbZGlzYWJsZWRdKVwiO1xuZXhwb3J0IGNvbnN0IEFSUk9XX0xFRlQgPSAnQXJyb3dMZWZ0JztcbmV4cG9ydCBjb25zdCBBUlJPV19SSUdIVCA9ICdBcnJvd1JpZ2h0JztcbmV4cG9ydCBjb25zdCBBUlJPV19VUCA9ICdBcnJvd1VwJztcbmV4cG9ydCBjb25zdCBBUlJPV19ET1dOID0gJ0Fycm93RG93bic7IiwiaW1wb3J0IHsgaXNFbGVtZW50LCBpc0hUTUxFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNsb3Nlc3QsIGNvbnRhaW5zLCBnZXRUYXJnZXQgfSBmcm9tICdAYmFzZS11aS91dGlscy9zaGFkb3dEb20nO1xuaW1wb3J0IHsgRk9DVVNBQkxFX0FUVFJJQlVURSwgVFlQRUFCTEVfU0VMRUNUT1IgfSBmcm9tIFwiLi9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgKiBhcyBUb29sdGlwVHJpZ2dlckRhdGFBdHRyaWJ1dGVzIGZyb20gXCIuLi8uLi90b29sdGlwL3RyaWdnZXIvVG9vbHRpcFRyaWdnZXJEYXRhQXR0cmlidXRlcy5tanNcIjtcbmV4cG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNsb3Nlc3QsIGNvbnRhaW5zLCBnZXRUYXJnZXQgfTtcbmV4cG9ydCBmdW5jdGlvbiBpc1RhcmdldEluc2lkZUVuYWJsZWRUcmlnZ2VyKHRhcmdldCwgdHJpZ2dlckVsZW1lbnRzKSB7XG4gIGlmICghaXNFbGVtZW50KHRhcmdldCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdGFyZ2V0RWxlbWVudCA9IHRhcmdldDtcbiAgaWYgKHRyaWdnZXJFbGVtZW50cy5oYXNFbGVtZW50KHRhcmdldEVsZW1lbnQpKSB7XG4gICAgcmV0dXJuICF0YXJnZXRFbGVtZW50Lmhhc0F0dHJpYnV0ZShUb29sdGlwVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnRyaWdnZXJEaXNhYmxlZCk7XG4gIH1cbiAgZm9yIChjb25zdCBbLCB0cmlnZ2VyXSBvZiB0cmlnZ2VyRWxlbWVudHMuZW50cmllcygpKSB7XG4gICAgaWYgKGNvbnRhaW5zKHRyaWdnZXIsIHRhcmdldEVsZW1lbnQpKSB7XG4gICAgICByZXR1cm4gIXRyaWdnZXIuaGFzQXR0cmlidXRlKFRvb2x0aXBUcmlnZ2VyRGF0YUF0dHJpYnV0ZXMudHJpZ2dlckRpc2FibGVkKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIG5vZGUpIHtcbiAgaWYgKG5vZGUgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoJ2NvbXBvc2VkUGF0aCcgaW4gZXZlbnQpIHtcbiAgICByZXR1cm4gZXZlbnQuY29tcG9zZWRQYXRoKCkuaW5jbHVkZXMobm9kZSk7XG4gIH1cblxuICAvLyBUUyB0aGlua3MgYGV2ZW50YCBpcyBvZiB0eXBlIG5ldmVyIGFzIGl0IGFzc3VtZXMgYWxsIGJyb3dzZXJzIHN1cHBvcnQgY29tcG9zZWRQYXRoLCBidXQgYnJvd3NlcnMgd2l0aG91dCBzaGFkb3cgZG9tIGRvbid0XG4gIGNvbnN0IGV2ZW50QWdhaW4gPSBldmVudDtcbiAgcmV0dXJuIGV2ZW50QWdhaW4udGFyZ2V0ICE9IG51bGwgJiYgbm9kZS5jb250YWlucyhldmVudEFnYWluLnRhcmdldCk7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNSb290RWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50Lm1hdGNoZXMoJ2h0bWwsYm9keScpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzVHlwZWFibGVFbGVtZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzSFRNTEVsZW1lbnQoZWxlbWVudCkgJiYgZWxlbWVudC5tYXRjaGVzKFRZUEVBQkxFX1NFTEVDVE9SKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0ludGVyYWN0aXZlRWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBjbG9zZXN0KGVsZW1lbnQsIGBidXR0b24sYVtocmVmXSxbcm9sZT1cImJ1dHRvblwiXSxzZWxlY3QsW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pLCR7VFlQRUFCTEVfU0VMRUNUT1J9YCkgIT0gbnVsbDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1R5cGVhYmxlQ29tYm9ib3goZWxlbWVudCkge1xuICBpZiAoIWVsZW1lbnQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIGVsZW1lbnQuZ2V0QXR0cmlidXRlKCdyb2xlJykgPT09ICdjb21ib2JveCcgJiYgaXNUeXBlYWJsZUVsZW1lbnQoZWxlbWVudCk7XG59XG5leHBvcnQgZnVuY3Rpb24gbWF0Y2hlc0ZvY3VzVmlzaWJsZShlbGVtZW50KSB7XG4gIC8vIFdlIGRvbid0IHdhbnQgdG8gYmxvY2sgZm9jdXMgZnJvbSB3b3JraW5nIHdpdGggYHZpc2libGVPbmx5YFxuICAvLyAoSlNET00gZG9lc24ndCBtYXRjaCBgOmZvY3VzLXZpc2libGVgIHdoZW4gdGhlIGVsZW1lbnQgaGFzIGA6Zm9jdXNgKVxuICBpZiAoIWVsZW1lbnQgfHwgcGxhdGZvcm0uZW52LmpzZG9tKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgdHJ5IHtcbiAgICByZXR1cm4gZWxlbWVudC5tYXRjaGVzKCc6Zm9jdXMtdmlzaWJsZScpO1xuICB9IGNhdGNoIChfZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQoZmxvYXRpbmdFbGVtZW50KSB7XG4gIGlmICghZmxvYXRpbmdFbGVtZW50KSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgLy8gVHJ5IHRvIGZpbmQgdGhlIGVsZW1lbnQgdGhhdCBoYXMgYHsuLi5nZXRGbG9hdGluZ1Byb3BzKCl9YCBzcHJlYWQgb24gaXQuXG4gIC8vIFRoaXMgaW5kaWNhdGVzIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIGFjdGluZyBhcyBhIHBvc2l0aW9uaW5nIHdyYXBwZXIsIGFuZFxuICAvLyBzbyBmb2N1cyBzaG91bGQgYmUgbWFuYWdlZCBvbiB0aGUgY2hpbGQgZWxlbWVudCB3aXRoIHRoZSBldmVudCBoYW5kbGVycyBhbmRcbiAgLy8gYXJpYSBwcm9wcy5cbiAgcmV0dXJuIGZsb2F0aW5nRWxlbWVudC5oYXNBdHRyaWJ1dGUoRk9DVVNBQkxFX0FUVFJJQlVURSkgPyBmbG9hdGluZ0VsZW1lbnQgOiBmbG9hdGluZ0VsZW1lbnQucXVlcnlTZWxlY3RvcihgWyR7Rk9DVVNBQkxFX0FUVFJJQlVURX1dYCkgfHwgZmxvYXRpbmdFbGVtZW50O1xufSIsIi8qKlxuICogQWRkcyBhbiBldmVudCBsaXN0ZW5lciBhbmQgcmV0dXJucyBhIGNsZWFudXAgZnVuY3Rpb24gdG8gcmVtb3ZlIGl0LlxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRFdmVudExpc3RlbmVyKHRhcmdldCwgdHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcbiAgdGFyZ2V0LmFkZEV2ZW50TGlzdGVuZXIodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKTtcbiAgfTtcbn0iLCIvKipcbiAqIENvbWJpbmVzIG11bHRpcGxlIGNsZWFudXAgZnVuY3Rpb25zIGludG8gYSBzaW5nbGUgY2xlYW51cCBmdW5jdGlvbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1lcmdlQ2xlYW51cHMoLi4uY2xlYW51cHMpIHtcbiAgcmV0dXJuICgpID0+IHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNsZWFudXBzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICBjb25zdCBjbGVhbnVwID0gY2xlYW51cHNbaV07XG4gICAgICBpZiAoY2xlYW51cCkge1xuICAgICAgICBjbGVhbnVwKCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSBcIi4vdXNlSXNvTGF5b3V0RWZmZWN0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tIFwiLi91c2VSZWZXaXRoSW5pdC5tanNcIjtcblxuLyoqXG4gKiBVbnRyYWNrcyB0aGUgcHJvdmlkZWQgdmFsdWUgYnkgdHVybmluZyBpdCBpbnRvIGEgcmVmIHRvIHJlbW92ZSBpdHMgcmVhY3Rpdml0eS5cbiAqXG4gKiBVc2VkIHRvIGFjY2VzcyB0aGUgcGFzc2VkIHZhbHVlIGluc2lkZSBgUmVhY3QudXNlRWZmZWN0YCB3aXRob3V0IGNhdXNpbmcgdGhlIGVmZmVjdCB0byByZS1ydW4gd2hlbiB0aGUgdmFsdWUgY2hhbmdlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVZhbHVlQXNSZWYodmFsdWUpIHtcbiAgY29uc3QgbGF0ZXN0ID0gdXNlUmVmV2l0aEluaXQoY3JlYXRlTGF0ZXN0UmVmLCB2YWx1ZSkuY3VycmVudDtcbiAgbGF0ZXN0Lm5leHQgPSB2YWx1ZTtcblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIHVzZUlzb0xheW91dEVmZmVjdChsYXRlc3QuZWZmZWN0KTtcbiAgcmV0dXJuIGxhdGVzdDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUxhdGVzdFJlZih2YWx1ZSkge1xuICBjb25zdCBsYXRlc3QgPSB7XG4gICAgY3VycmVudDogdmFsdWUsXG4gICAgbmV4dDogdmFsdWUsXG4gICAgZWZmZWN0OiAoKSA9PiB7XG4gICAgICBsYXRlc3QuY3VycmVudCA9IGxhdGVzdC5uZXh0O1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIGxhdGVzdDtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSBcIi4vdXNlUmVmV2l0aEluaXQubWpzXCI7XG5pbXBvcnQgeyB1c2VPbk1vdW50IH0gZnJvbSBcIi4vdXNlT25Nb3VudC5tanNcIjtcbi8qKiBVbmxpa2UgYHNldFRpbWVvdXRgLCByQUYgZG9lc24ndCBndWFyYW50ZWUgYSBwb3NpdGl2ZSBpbnRlZ2VyIHJldHVybiB2YWx1ZSwgc28gd2UgY2FuJ3QgaGF2ZVxuICogYSBtb25vbW9ycGhpYyBgdWludGAgdHlwZSB3aXRoIGAwYCBtZWFuaW5nIGVtcHR5LlxuICogU2VlIHdhcm5pbmcgbm90ZSBhdDpcbiAqIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9XaW5kb3cvcmVxdWVzdEFuaW1hdGlvbkZyYW1lI3JldHVybl92YWx1ZSAqL1xuY29uc3QgRU1QVFkgPSBudWxsO1xubGV0IExBU1RfUkFGID0gZ2xvYmFsVGhpcy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWU7XG5jbGFzcyBTY2hlZHVsZXIge1xuICAvKiBUaGlzIGltcGxlbWVudGF0aW9uIHVzZXMgYW4gYXJyYXkgYXMgYSBiYWNraW5nIGRhdGEtc3RydWN0dXJlIGZvciBmcmFtZSBjYWxsYmFja3MuXG4gICAqIEl0IGFsbG93cyBgTygxKWAgY2FsbGJhY2sgY2FuY2VsbGluZyBieSBpbnNlcnRpbmcgYSBgbnVsbGAgaW4gdGhlIGFycmF5LCB0aG91Z2ggaXRcbiAgICogbmV2ZXIgY2FsbHMgdGhlIG5hdGl2ZSBgY2FuY2VsQW5pbWF0aW9uRnJhbWVgIGlmIHRoZXJlIGFyZSBubyBmcmFtZXMgbGVmdC4gVGhpcyBjYW5cbiAgICogYmUgbXVjaCBtb3JlIGVmZmljaWVudCBpZiB0aGVyZSBpcyBhIGNhbGwgcGF0dGVybiB0aGF0IGFsdGVybnMgYXNcbiAgICogXCJyZXF1ZXN0LWNhbmNlbC1yZXF1ZXN0LWNhbmNlbC3igKZcIi5cbiAgICogQnV0IGluIHRoZSBjYXNlIG9mIFwicmVxdWVzdC1yZXF1ZXN0LeKApi1jYW5jZWwtY2FuY2VsLeKAplwiLCBpdCBsZWF2ZXMgdGhlIGZpbmFsIGFuaW1hdGlvblxuICAgKiBmcmFtZSB0byBydW4gYW55d2F5LiBXZSB0dXJuIHRoYXQgZnJhbWUgaW50byBhIGBPKDEpYCBuby1vcCB2aWEgYGNhbGxiYWNrc0NvdW50YC4gKi9cblxuICBjYWxsYmFja3MgPSBbXTtcbiAgY2FsbGJhY2tzQ291bnQgPSAwO1xuICBuZXh0SWQgPSAxO1xuICBzdGFydElkID0gMTtcbiAgaXNTY2hlZHVsZWQgPSBmYWxzZTtcbiAgdGljayA9IHRpbWVzdGFtcCA9PiB7XG4gICAgdGhpcy5pc1NjaGVkdWxlZCA9IGZhbHNlO1xuICAgIGNvbnN0IGN1cnJlbnRDYWxsYmFja3MgPSB0aGlzLmNhbGxiYWNrcztcbiAgICBjb25zdCBjdXJyZW50Q2FsbGJhY2tzQ291bnQgPSB0aGlzLmNhbGxiYWNrc0NvdW50O1xuXG4gICAgLy8gVXBkYXRlIHRoZXNlIGJlZm9yZSBpdGVyYXRpbmcsIGNhbGxiYWNrcyBjb3VsZCBjYWxsIGByZXF1ZXN0QW5pbWF0aW9uRnJhbWVgIGFnYWluLlxuICAgIHRoaXMuY2FsbGJhY2tzID0gW107XG4gICAgdGhpcy5jYWxsYmFja3NDb3VudCA9IDA7XG4gICAgdGhpcy5zdGFydElkID0gdGhpcy5uZXh0SWQ7XG4gICAgaWYgKGN1cnJlbnRDYWxsYmFja3NDb3VudCA+IDApIHtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3VycmVudENhbGxiYWNrcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICBjdXJyZW50Q2FsbGJhY2tzW2ldPy4odGltZXN0YW1wKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHJlcXVlc3QoZm4pIHtcbiAgICBjb25zdCBpZCA9IHRoaXMubmV4dElkO1xuICAgIHRoaXMubmV4dElkICs9IDE7XG4gICAgdGhpcy5jYWxsYmFja3MucHVzaChmbik7XG4gICAgdGhpcy5jYWxsYmFja3NDb3VudCArPSAxO1xuXG4gICAgLyogSW4gYSB0ZXN0IGVudmlyb25tZW50IHdpdGggZmFrZSB0aW1lcnMsIGEgZmFrZSBgcmVxdWVzdEFuaW1hdGlvbkZyYW1lYCBjYW4gYmUgY2FsbGVkXG4gICAgICogYnV0IHRoZXJlJ3Mgbm8gZ3VhcmFudGVlIHRoYXQgdGhlIGFuaW1hdGlvbiBmcmFtZSB3aWxsIGFjdHVhbGx5IHJ1biBiZWZvcmUgdGhlIGZha2VcbiAgICAgKiB0aW1lcnMgYXJlIHRlYXJlZCwgd2hpY2ggbGVhdmVzIGBpc1NjaGVkdWxlZGAgc2V0LCBidXQgd29uJ3QgcnVuIG91ciBgdGljaygpYC4gKi9cbiAgICBjb25zdCBkaWRSQUZDaGFuZ2UgPSBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nICYmIExBU1RfUkFGICE9PSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUgJiYgKExBU1RfUkFGID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lLCB0cnVlKTtcbiAgICBpZiAoIXRoaXMuaXNTY2hlZHVsZWQgfHwgZGlkUkFGQ2hhbmdlKSB7XG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGhpcy50aWNrKTtcbiAgICAgIHRoaXMuaXNTY2hlZHVsZWQgPSB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gaWQ7XG4gIH1cbiAgY2FuY2VsKGlkKSB7XG4gICAgY29uc3QgaW5kZXggPSBpZCAtIHRoaXMuc3RhcnRJZDtcbiAgICBpZiAoaW5kZXggPCAwIHx8IGluZGV4ID49IHRoaXMuY2FsbGJhY2tzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodGhpcy5jYWxsYmFja3NbaW5kZXhdID09PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuY2FsbGJhY2tzW2luZGV4XSA9IG51bGw7XG4gICAgdGhpcy5jYWxsYmFja3NDb3VudCAtPSAxO1xuICB9XG59XG5sZXQgc2NoZWR1bGVyID0gbmV3IFNjaGVkdWxlcigpO1xuXG4vKipcbiAqIFJlcGxhY2VzIHRoZSBzaGFyZWQgc2NoZWR1bGVyIGFuZCBkcm9wcyBhbGwgcGVuZGluZyBhbmltYXRpb24gZnJhbWUgY2FsbGJhY2tzLlxuICpcbiAqIEZvciB0ZXN0IGVudmlyb25tZW50cyBvbmx5LiBUaGUgc2NoZWR1bGVyIGlzIHByb2Nlc3MtZ2xvYmFsLCBzbyBhIGNhbGxiYWNrIHNjaGVkdWxlZCBpbiBvbmUgdGVzdFxuICogYnV0IG5ldmVyIHJ1biAoZS5nLiByZXF1ZXN0ZWQgdW5kZXIgZmFrZSB0aW1lcnMgdGhhdCB3ZXJlIHRvcm4gZG93biBiZWZvcmUgdGhlIGZyYW1lIGZpcmVkKSB3b3VsZFxuICogb3RoZXJ3aXNlIHN1cnZpdmUgaW50byBhIGxhdGVyIHRlc3QgYW5kIHJ1biB0aGVyZSBhZ2FpbnN0IHN0YWxlIHN0YXRlLiBDYWxsIGJldHdlZW4gdGVzdHMgdG8gZHJvcFxuICogc3VjaCBsZWZ0b3ZlcnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNldEFuaW1hdGlvbkZyYW1lU2NoZWR1bGVyKCkge1xuICBjb25zdCBwcmV2aW91cyA9IHNjaGVkdWxlcjtcbiAgc2NoZWR1bGVyID0gbmV3IFNjaGVkdWxlcigpO1xuICAvLyBDb250aW51ZSB0aGUgaWQgc2VxdWVuY2Ugc28gYGNhbmNlbCgpYCBjYWxscyBmcm9tIGBBbmltYXRpb25GcmFtZWAgaW5zdGFuY2VzIGNyZWF0ZWQgYmVmb3JlIHRoZVxuICAvLyByZXNldCBjYW5ub3QgY2FuY2VsIGNhbGxiYWNrcyBzY2hlZHVsZWQgYWZ0ZXIgaXQuXG4gIHNjaGVkdWxlci5uZXh0SWQgPSBwcmV2aW91cy5uZXh0SWQ7XG4gIHNjaGVkdWxlci5zdGFydElkID0gcHJldmlvdXMubmV4dElkO1xuICAvLyBBIGZyYW1lIHJlcXVlc3RlZCBiZWZvcmUgdGhlIHJlc2V0IG1heSBzdGlsbCBiZSBwZW5kaW5nIGFuZCBob2xkcyB0aGUgcHJldmlvdXMgc2NoZWR1bGVyJ3NcbiAgLy8gYHRpY2tgOyBlbXB0eSBpdHMgcXVldWUgaW4gcGxhY2Ugc28gdGhhdCBmcmFtZSBydW5zIG5vdGhpbmcgd2hlbiBpdCBldmVudHVhbGx5IGZpcmVzLlxuICBwcmV2aW91cy5jYWxsYmFja3MgPSBbXTtcbiAgcHJldmlvdXMuY2FsbGJhY2tzQ291bnQgPSAwO1xufVxuZXhwb3J0IGNsYXNzIEFuaW1hdGlvbkZyYW1lIHtcbiAgc3RhdGljIGNyZWF0ZSgpIHtcbiAgICByZXR1cm4gbmV3IEFuaW1hdGlvbkZyYW1lKCk7XG4gIH1cbiAgc3RhdGljIHJlcXVlc3QoZm4pIHtcbiAgICByZXR1cm4gc2NoZWR1bGVyLnJlcXVlc3QoZm4pO1xuICB9XG4gIHN0YXRpYyBjYW5jZWwoaWQpIHtcbiAgICByZXR1cm4gc2NoZWR1bGVyLmNhbmNlbChpZCk7XG4gIH1cbiAgY3VycmVudElkID0gRU1QVFk7XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGVzIGBmbmAgYWZ0ZXIgYGRlbGF5YCwgY2xlYXJpbmcgYW55IHByZXZpb3VzbHkgc2NoZWR1bGVkIGNhbGwuXG4gICAqL1xuICByZXF1ZXN0KGZuKSB7XG4gICAgdGhpcy5jYW5jZWwoKTtcbiAgICB0aGlzLmN1cnJlbnRJZCA9IHNjaGVkdWxlci5yZXF1ZXN0KCgpID0+IHtcbiAgICAgIHRoaXMuY3VycmVudElkID0gRU1QVFk7XG4gICAgICBmbigpO1xuICAgIH0pO1xuICB9XG4gIGNhbmNlbCA9ICgpID0+IHtcbiAgICBpZiAodGhpcy5jdXJyZW50SWQgIT09IEVNUFRZKSB7XG4gICAgICBzY2hlZHVsZXIuY2FuY2VsKHRoaXMuY3VycmVudElkKTtcbiAgICAgIHRoaXMuY3VycmVudElkID0gRU1QVFk7XG4gICAgfVxuICB9O1xuICBkaXNwb3NlRWZmZWN0ID0gKCkgPT4ge1xuICAgIHJldHVybiB0aGlzLmNhbmNlbDtcbiAgfTtcbn1cblxuLyoqXG4gKiBBIGByZXF1ZXN0QW5pbWF0aW9uRnJhbWVgIHdpdGggYXV0b21hdGljIGNsZWFudXAgYW5kIGd1YXJkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQW5pbWF0aW9uRnJhbWUoKSB7XG4gIGNvbnN0IHRpbWVvdXQgPSB1c2VSZWZXaXRoSW5pdChBbmltYXRpb25GcmFtZS5jcmVhdGUpLmN1cnJlbnQ7XG4gIHVzZU9uTW91bnQodGltZW91dC5kaXNwb3NlRWZmZWN0KTtcbiAgcmV0dXJuIHRpbWVvdXQ7XG59IiwiY29uc3QgdmlzdWFsbHlIaWRkZW5CYXNlID0ge1xuICBjbGlwUGF0aDogJ2luc2V0KDUwJSknLFxuICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gIHdoaXRlU3BhY2U6ICdub3dyYXAnLFxuICBib3JkZXI6IDAsXG4gIHBhZGRpbmc6IDAsXG4gIHdpZHRoOiAxLFxuICBoZWlnaHQ6IDEsXG4gIG1hcmdpbjogLTFcbn07XG5leHBvcnQgY29uc3QgdmlzdWFsbHlIaWRkZW4gPSB7XG4gIC4uLnZpc3VhbGx5SGlkZGVuQmFzZSxcbiAgcG9zaXRpb246ICdmaXhlZCcsXG4gIG1hcmdpbjogMCxcbiAgdG9wOiAwLFxuICBsZWZ0OiAwXG59O1xuZXhwb3J0IGNvbnN0IHZpc3VhbGx5SGlkZGVuSW5wdXQgPSB7XG4gIC4uLnZpc3VhbGx5SGlkZGVuQmFzZSxcbiAgcG9zaXRpb246ICdhYnNvbHV0ZSdcbn07IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tICdAYmFzZS11aS91dGlscy9wbGF0Zm9ybSc7XG5pbXBvcnQgeyB2aXN1YWxseUhpZGRlbiB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3Zpc3VhbGx5SGlkZGVuJztcblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBGb2N1c0d1YXJkID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRm9jdXNHdWFyZChwcm9wcywgcmVmKSB7XG4gIGNvbnN0IFtyb2xlLCBzZXRSb2xlXSA9IFJlYWN0LnVzZVN0YXRlKCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgLy8gVW5saWtlIE5WREEgYW5kIEpBV1MsIFZvaWNlT3ZlcidzIHZpcnR1YWwgY3Vyc29yIHRyaWdnZXJzIGBvbkZvY3VzYCBhc1xuICAgIC8vIGl0IG1vdmVzIOKAlCBidXQgb25seSBvbiBmb2N1c2FibGUvcm9sZS1idXR0b24gZWxlbWVudHMgdGhyb3VnaCBXZWJLaXQnc1xuICAgIC8vIE5TQWNjZXNzaWJpbGl0eSBwYXRoLiBTZXR0aW5nIGByb2xlPVwiYnV0dG9uXCJgIGxldHMgdGhlIGZvY3VzIHRyYXAgY2F0Y2hcbiAgICAvLyB0aGUgY3Vyc29yLlxuICAgIGlmIChwbGF0Zm9ybS5zY3JlZW5SZWFkZXIudm9pY2VPdmVyICYmIHBsYXRmb3JtLmVuZ2luZS53ZWJraXQpIHtcbiAgICAgIHNldFJvbGUoJ2J1dHRvbicpO1xuICAgIH1cbiAgfSwgW10pO1xuICBjb25zdCByZXN0UHJvcHMgPSB7XG4gICAgdGFiSW5kZXg6IDAsXG4gICAgLy8gUm9sZSBpcyBvbmx5IGZvciBWb2ljZU92ZXJcbiAgICByb2xlXG4gIH07XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChcInNwYW5cIiwge1xuICAgIC4uLnByb3BzLFxuICAgIHJlZjogcmVmLFxuICAgIHN0eWxlOiB2aXN1YWxseUhpZGRlbixcbiAgICBcImFyaWEtaGlkZGVuXCI6IHJvbGUgPyB1bmRlZmluZWQgOiB0cnVlLFxuICAgIC4uLnJlc3RQcm9wcyxcbiAgICBcImRhdGEtYmFzZS11aS1mb2N1cy1ndWFyZFwiOiBcIlwiXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGb2N1c0d1YXJkLmRpc3BsYXlOYW1lID0gXCJGb2N1c0d1YXJkXCI7IiwiaW1wb3J0IHsgZmxvb3IgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMnO1xuaW1wb3J0IHsgZ2V0Q29tcHV0ZWRTdHlsZSB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgc3RvcEV2ZW50IH0gZnJvbSBcIi4vZXZlbnQubWpzXCI7XG5pbXBvcnQgeyBBUlJPV19ET1dOLCBBUlJPV19MRUZULCBBUlJPV19SSUdIVCwgQVJST1dfVVAgfSBmcm9tIFwiLi9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyBjbG9zZXN0IH0gZnJvbSBcIi4vZWxlbWVudC5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBpc0RpZmZlcmVudEdyaWRSb3coaW5kZXgsIGNvbHMsIHByZXZSb3cpIHtcbiAgcmV0dXJuIE1hdGguZmxvb3IoaW5kZXggLyBjb2xzKSAhPT0gcHJldlJvdztcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0luZGV4T3V0T2ZMaXN0Qm91bmRzKGxpc3QsIGluZGV4KSB7XG4gIHJldHVybiBpbmRleCA8IDAgfHwgaW5kZXggPj0gbGlzdC5sZW5ndGg7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0TWluTGlzdEluZGV4KGxpc3RSZWYsIGRpc2FibGVkSW5kaWNlcykge1xuICByZXR1cm4gZmluZE5vbkRpc2FibGVkTGlzdEluZGV4KGxpc3RSZWYuY3VycmVudCwge1xuICAgIGRpc2FibGVkSW5kaWNlc1xuICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRNYXhMaXN0SW5kZXgobGlzdFJlZiwgZGlzYWJsZWRJbmRpY2VzKSB7XG4gIHJldHVybiBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgobGlzdFJlZi5jdXJyZW50LCB7XG4gICAgZGVjcmVtZW50OiB0cnVlLFxuICAgIHN0YXJ0aW5nSW5kZXg6IGxpc3RSZWYuY3VycmVudC5sZW5ndGgsXG4gICAgZGlzYWJsZWRJbmRpY2VzXG4gIH0pO1xufVxuLyoqXG4gKiBUaGUgaW5kZXggb25lIGFycm93IHN0ZXAgbW92ZXMgdGhlIGhpZ2hsaWdodCB0byBmcm9tIGBjdXJyZW50SW5kZXhgLCBvciBgLTFgIHdoZW4gdGhlIHN0ZXBcbiAqIGxlYXZlcyB0aGUgbGlzdC4gYHdyYXBwZWRgIHJlcG9ydHMgYSBqdW1wIGZyb20gb25lIGVuZCBvZiB0aGUgbGlzdCB0byB0aGUgb3RoZXIuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXROZXh0TGlzdEluZGV4KGxpc3QsIGN1cnJlbnRJbmRleCwgb3B0aW9ucykge1xuICBjb25zdCB7XG4gICAgZGVjcmVtZW50LFxuICAgIGxvb3BGb2N1cyxcbiAgICBhbGxvd0VzY2FwZSxcbiAgICBkaXNhYmxlZEluZGljZXMsXG4gICAgbWluSW5kZXgsXG4gICAgbWF4SW5kZXhcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHN0ZXAgPSAoKSA9PiBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgobGlzdCwge1xuICAgIHN0YXJ0aW5nSW5kZXg6IGN1cnJlbnRJbmRleCxcbiAgICBkZWNyZW1lbnQsXG4gICAgZGlzYWJsZWRJbmRpY2VzXG4gIH0pO1xuICBsZXQgaW5kZXg7XG4gIGxldCB3cmFwcGVkID0gZmFsc2U7XG4gIGlmICghbG9vcEZvY3VzKSB7XG4gICAgaW5kZXggPSBkZWNyZW1lbnQgPyBNYXRoLm1heChtaW5JbmRleCwgc3RlcCgpKSA6IE1hdGgubWluKG1heEluZGV4LCBzdGVwKCkpO1xuICB9IGVsc2UgaWYgKGRlY3JlbWVudCA/IGN1cnJlbnRJbmRleCA8PSBtaW5JbmRleCA6IGN1cnJlbnRJbmRleCA+PSBtYXhJbmRleCkge1xuICAgIC8vIEVzY2FwaW5nIGlzIG9ubHkgcG9zc2libGUgZnJvbSBpbnNpZGUgdGhlIGxpc3Q6IGZyb20gb3V0c2lkZSBpdCwgYSBzdGVwIGVudGVycyBhdCB0aGUgZmFyXG4gICAgLy8gZW5kLlxuICAgIGNvbnN0IG91dHNpZGUgPSBkZWNyZW1lbnQgPyAtMSA6IGxpc3QubGVuZ3RoO1xuICAgIGlmIChhbGxvd0VzY2FwZSAmJiBjdXJyZW50SW5kZXggIT09IG91dHNpZGUpIHtcbiAgICAgIGluZGV4ID0gLTE7XG4gICAgfSBlbHNlIHtcbiAgICAgIGluZGV4ID0gZGVjcmVtZW50ID8gbWF4SW5kZXggOiBtaW5JbmRleDtcbiAgICAgIHdyYXBwZWQgPSB0cnVlO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpbmRleCA9IHN0ZXAoKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGluZGV4OiBpc0luZGV4T3V0T2ZMaXN0Qm91bmRzKGxpc3QsIGluZGV4KSA/IC0xIDogaW5kZXgsXG4gICAgd3JhcHBlZFxuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZpbmROb25EaXNhYmxlZExpc3RJbmRleChsaXN0LCB7XG4gIHN0YXJ0aW5nSW5kZXggPSAtMSxcbiAgZGVjcmVtZW50ID0gZmFsc2UsXG4gIGRpc2FibGVkSW5kaWNlcyxcbiAgYW1vdW50ID0gMVxufSA9IHt9KSB7XG4gIGxldCBpbmRleCA9IHN0YXJ0aW5nSW5kZXg7XG4gIGRvIHtcbiAgICBpbmRleCArPSBkZWNyZW1lbnQgPyAtYW1vdW50IDogYW1vdW50O1xuICB9IHdoaWxlIChpbmRleCA+PSAwICYmIGluZGV4IDw9IGxpc3QubGVuZ3RoIC0gMSAmJiBpc0xpc3RJbmRleERpc2FibGVkKGxpc3QsIGluZGV4LCBkaXNhYmxlZEluZGljZXMpKTtcbiAgcmV0dXJuIGluZGV4O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldEdyaWROYXZpZ2F0ZWRJbmRleChsaXN0LCB7XG4gIGV2ZW50LFxuICBvcmllbnRhdGlvbixcbiAgbG9vcEZvY3VzLFxuICBvbkxvb3AsXG4gIHJ0bCxcbiAgY29scyxcbiAgZGlzYWJsZWRJbmRpY2VzLFxuICBtaW5JbmRleCxcbiAgbWF4SW5kZXgsXG4gIHByZXZJbmRleCxcbiAgc3RvcEV2ZW50OiBzdG9wID0gZmFsc2Vcbn0pIHtcbiAgbGV0IG5leHRJbmRleCA9IHByZXZJbmRleDtcbiAgbGV0IHZlcnRpY2FsRGlyZWN0aW9uO1xuICBpZiAoZXZlbnQua2V5ID09PSBBUlJPV19VUCkge1xuICAgIHZlcnRpY2FsRGlyZWN0aW9uID0gJ3VwJztcbiAgfSBlbHNlIGlmIChldmVudC5rZXkgPT09IEFSUk9XX0RPV04pIHtcbiAgICB2ZXJ0aWNhbERpcmVjdGlvbiA9ICdkb3duJztcbiAgfVxuICBpZiAodmVydGljYWxEaXJlY3Rpb24pIHtcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gRGV0ZWN0IHJvdyBzdHJ1Y3R1cmUgb25seSB3aGVuIGhhbmRsaW5nIHZlcnRpY2FsIG5hdmlnYXRpb24uIFRoaXMga2VlcHNcbiAgICAvLyB0aGUgbm9uLXZlcnRpY2FsIGtleSBwYXRocyBmcmVlIGZyb20gcm93IGluZmVyZW5jZSB3b3JrLlxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBjb25zdCByb3dzID0gW107XG4gICAgY29uc3Qgcm93SW5kZXhNYXAgPSBbXTtcbiAgICBsZXQgaGFzUm9sZVJvdyA9IGZhbHNlO1xuICAgIGxldCB2aXNpYmxlSXRlbUNvdW50ID0gMDtcbiAgICB7XG4gICAgICBsZXQgY3VycmVudFJvd0VsID0gbnVsbDtcbiAgICAgIGxldCBjdXJyZW50Um93SW5kZXggPSAtMTtcbiAgICAgIGxpc3QuZm9yRWFjaCgoZWwsIGlkeCkgPT4ge1xuICAgICAgICBpZiAoZWwgPT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2aXNpYmxlSXRlbUNvdW50ICs9IDE7XG4gICAgICAgIGNvbnN0IHJvd0VsID0gY2xvc2VzdChlbCwgJ1tyb2xlPVwicm93XCJdJyk7XG4gICAgICAgIGlmIChyb3dFbCkge1xuICAgICAgICAgIGhhc1JvbGVSb3cgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyb3dFbCAhPT0gY3VycmVudFJvd0VsIHx8IGN1cnJlbnRSb3dJbmRleCA9PT0gLTEpIHtcbiAgICAgICAgICBjdXJyZW50Um93RWwgPSByb3dFbDtcbiAgICAgICAgICBjdXJyZW50Um93SW5kZXggKz0gMTtcbiAgICAgICAgICByb3dzW2N1cnJlbnRSb3dJbmRleF0gPSBbXTtcbiAgICAgICAgfVxuICAgICAgICByb3dzW2N1cnJlbnRSb3dJbmRleF0ucHVzaChpZHgpO1xuICAgICAgICByb3dJbmRleE1hcFtpZHhdID0gY3VycmVudFJvd0luZGV4O1xuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBoYXNEb21Sb3dzID0gZmFsc2U7XG4gICAgbGV0IGluZmVycmVkRG9tQ29scyA9IDA7XG4gICAgaWYgKGhhc1JvbGVSb3cpIHtcbiAgICAgIGZvciAoY29uc3Qgcm93IG9mIHJvd3MpIHtcbiAgICAgICAgY29uc3Qgcm93TGVuZ3RoID0gcm93Lmxlbmd0aDtcbiAgICAgICAgaWYgKHJvd0xlbmd0aCA+IGluZmVycmVkRG9tQ29scykge1xuICAgICAgICAgIGluZmVycmVkRG9tQ29scyA9IHJvd0xlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBpZiAocm93TGVuZ3RoICE9PSBjb2xzKSB7XG4gICAgICAgICAgaGFzRG9tUm93cyA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgaGFzVmlydHVhbGl6ZWRHYXBzID0gaGFzRG9tUm93cyAmJiB2aXNpYmxlSXRlbUNvdW50IDwgbGlzdC5sZW5ndGg7XG4gICAgY29uc3QgdmVydGljYWxDb2xzID0gaW5mZXJyZWREb21Db2xzIHx8IGNvbHM7XG4gICAgY29uc3QgbmF2aWdhdGVWZXJ0aWNhbGx5ID0gZGlyZWN0aW9uID0+IHtcbiAgICAgIGlmICghaGFzRG9tUm93cyB8fCBwcmV2SW5kZXggPT09IC0xKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICBjb25zdCBjdXJyZW50Um93ID0gcm93SW5kZXhNYXBbcHJldkluZGV4XTtcbiAgICAgIGlmIChjdXJyZW50Um93ID09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNvbEluUm93ID0gcm93c1tjdXJyZW50Um93XS5pbmRleE9mKHByZXZJbmRleCk7XG4gICAgICBjb25zdCBzdGVwID0gZGlyZWN0aW9uID09PSAndXAnID8gLTEgOiAxO1xuICAgICAgZm9yIChsZXQgbmV4dFJvdyA9IGN1cnJlbnRSb3cgKyBzdGVwLCBpID0gMDsgaSA8IHJvd3MubGVuZ3RoOyBpICs9IDEsIG5leHRSb3cgKz0gc3RlcCkge1xuICAgICAgICBpZiAobmV4dFJvdyA8IDAgfHwgbmV4dFJvdyA+PSByb3dzLmxlbmd0aCkge1xuICAgICAgICAgIGlmICghbG9vcEZvY3VzIHx8IGhhc1ZpcnR1YWxpemVkR2Fwcykge1xuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICB9XG4gICAgICAgICAgbmV4dFJvdyA9IG5leHRSb3cgPCAwID8gcm93cy5sZW5ndGggLSAxIDogMDtcbiAgICAgICAgICBpZiAob25Mb29wKSB7XG4gICAgICAgICAgICBjb25zdCBjbGFtcGVkQ29sID0gTWF0aC5taW4oY29sSW5Sb3csIHJvd3NbbmV4dFJvd10ubGVuZ3RoIC0gMSk7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXRJdGVtSW5kZXggPSByb3dzW25leHRSb3ddW2NsYW1wZWRDb2xdID8/IHJvd3NbbmV4dFJvd11bMF07XG4gICAgICAgICAgICBjb25zdCByZXR1cm5lZEl0ZW1JbmRleCA9IG9uTG9vcChldmVudCwgcHJldkluZGV4LCB0YXJnZXRJdGVtSW5kZXgpO1xuICAgICAgICAgICAgbmV4dFJvdyA9IHJvd0luZGV4TWFwW3JldHVybmVkSXRlbUluZGV4XSA/PyBuZXh0Um93O1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0YXJnZXRSb3cgPSByb3dzW25leHRSb3ddO1xuICAgICAgICBmb3IgKGxldCBjb2wgPSBNYXRoLm1pbihjb2xJblJvdywgdGFyZ2V0Um93Lmxlbmd0aCAtIDEpOyBjb2wgPj0gMDsgY29sIC09IDEpIHtcbiAgICAgICAgICBjb25zdCBjYW5kaWRhdGUgPSB0YXJnZXRSb3dbY29sXTtcbiAgICAgICAgICBpZiAoIWlzTGlzdEluZGV4RGlzYWJsZWQobGlzdCwgY2FuZGlkYXRlLCBkaXNhYmxlZEluZGljZXMpKSB7XG4gICAgICAgICAgICByZXR1cm4gY2FuZGlkYXRlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9O1xuICAgIGNvbnN0IG5hdmlnYXRlVmVydGljYWxseVdpdGhJbmZlcnJlZFJvd3MgPSBkaXJlY3Rpb24gPT4ge1xuICAgICAgaWYgKCFoYXNWaXJ0dWFsaXplZEdhcHMgfHwgcHJldkluZGV4ID09PSAtMSkge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgICAgY29uc3QgY29sSW5Sb3cgPSBwcmV2SW5kZXggJSB2ZXJ0aWNhbENvbHM7XG4gICAgICBjb25zdCByb3dTdGVwID0gZGlyZWN0aW9uID09PSAndXAnID8gLXZlcnRpY2FsQ29scyA6IHZlcnRpY2FsQ29scztcbiAgICAgIGNvbnN0IGxhc3RSb3dTdGFydCA9IG1heEluZGV4IC0gbWF4SW5kZXggJSB2ZXJ0aWNhbENvbHM7XG4gICAgICBjb25zdCByb3dDb3VudCA9IGZsb29yKG1heEluZGV4IC8gdmVydGljYWxDb2xzKSArIDE7XG4gICAgICBmb3IgKGxldCByb3dTdGFydCA9IHByZXZJbmRleCAtIGNvbEluUm93ICsgcm93U3RlcCwgaSA9IDA7IGkgPCByb3dDb3VudDsgaSArPSAxLCByb3dTdGFydCArPSByb3dTdGVwKSB7XG4gICAgICAgIGlmIChyb3dTdGFydCA8IDAgfHwgcm93U3RhcnQgPiBtYXhJbmRleCkge1xuICAgICAgICAgIGlmICghbG9vcEZvY3VzKSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgIH1cbiAgICAgICAgICByb3dTdGFydCA9IHJvd1N0YXJ0IDwgMCA/IGxhc3RSb3dTdGFydCA6IDA7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgcm93RW5kID0gTWF0aC5taW4ocm93U3RhcnQgKyB2ZXJ0aWNhbENvbHMgLSAxLCBtYXhJbmRleCk7XG4gICAgICAgIGZvciAobGV0IGNhbmRpZGF0ZSA9IE1hdGgubWluKHJvd1N0YXJ0ICsgY29sSW5Sb3csIHJvd0VuZCk7IGNhbmRpZGF0ZSA+PSByb3dTdGFydDsgY2FuZGlkYXRlIC09IDEpIHtcbiAgICAgICAgICBpZiAoIWlzTGlzdEluZGV4RGlzYWJsZWQobGlzdCwgY2FuZGlkYXRlLCBkaXNhYmxlZEluZGljZXMpKSB7XG4gICAgICAgICAgICByZXR1cm4gY2FuZGlkYXRlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9O1xuICAgIGlmIChzdG9wKSB7XG4gICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgIH1cbiAgICBjb25zdCB2ZXJ0aWNhbENhbmRpZGF0ZSA9IG5hdmlnYXRlVmVydGljYWxseSh2ZXJ0aWNhbERpcmVjdGlvbikgPz8gbmF2aWdhdGVWZXJ0aWNhbGx5V2l0aEluZmVycmVkUm93cyh2ZXJ0aWNhbERpcmVjdGlvbik7XG4gICAgaWYgKHZlcnRpY2FsQ2FuZGlkYXRlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIG5leHRJbmRleCA9IHZlcnRpY2FsQ2FuZGlkYXRlO1xuICAgIH0gZWxzZSBpZiAocHJldkluZGV4ID09PSAtMSkge1xuICAgICAgbmV4dEluZGV4ID0gdmVydGljYWxEaXJlY3Rpb24gPT09ICd1cCcgPyBtYXhJbmRleCA6IG1pbkluZGV4O1xuICAgIH0gZWxzZSB7XG4gICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgobGlzdCwge1xuICAgICAgICBzdGFydGluZ0luZGV4OiBwcmV2SW5kZXgsXG4gICAgICAgIGFtb3VudDogdmVydGljYWxDb2xzLFxuICAgICAgICBkZWNyZW1lbnQ6IHZlcnRpY2FsRGlyZWN0aW9uID09PSAndXAnLFxuICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgIH0pO1xuICAgICAgaWYgKGxvb3BGb2N1cykge1xuICAgICAgICBpZiAodmVydGljYWxEaXJlY3Rpb24gPT09ICd1cCcgJiYgKHByZXZJbmRleCAtIHZlcnRpY2FsQ29scyA8IG1pbkluZGV4IHx8IG5leHRJbmRleCA8IDApKSB7XG4gICAgICAgICAgY29uc3QgY29sID0gcHJldkluZGV4ICUgdmVydGljYWxDb2xzO1xuICAgICAgICAgIGNvbnN0IG1heENvbCA9IG1heEluZGV4ICUgdmVydGljYWxDb2xzO1xuICAgICAgICAgIGNvbnN0IG9mZnNldCA9IG1heEluZGV4IC0gKG1heENvbCAtIGNvbCk7XG4gICAgICAgICAgaWYgKG1heENvbCA9PT0gY29sKSB7XG4gICAgICAgICAgICBuZXh0SW5kZXggPSBtYXhJbmRleDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbmV4dEluZGV4ID0gbWF4Q29sID4gY29sID8gb2Zmc2V0IDogb2Zmc2V0IC0gdmVydGljYWxDb2xzO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAob25Mb29wKSB7XG4gICAgICAgICAgICBuZXh0SW5kZXggPSBvbkxvb3AoZXZlbnQsIHByZXZJbmRleCwgbmV4dEluZGV4KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZlcnRpY2FsRGlyZWN0aW9uID09PSAnZG93bicgJiYgcHJldkluZGV4ICsgdmVydGljYWxDb2xzID4gbWF4SW5kZXgpIHtcbiAgICAgICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgobGlzdCwge1xuICAgICAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4ICUgdmVydGljYWxDb2xzIC0gdmVydGljYWxDb2xzLFxuICAgICAgICAgICAgYW1vdW50OiB2ZXJ0aWNhbENvbHMsXG4gICAgICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZiAob25Mb29wKSB7XG4gICAgICAgICAgICBuZXh0SW5kZXggPSBvbkxvb3AoZXZlbnQsIHByZXZJbmRleCwgbmV4dEluZGV4KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGlzSW5kZXhPdXRPZkxpc3RCb3VuZHMobGlzdCwgbmV4dEluZGV4KSkge1xuICAgICAgbmV4dEluZGV4ID0gcHJldkluZGV4O1xuICAgIH1cbiAgfVxuXG4gIC8vIFJlbWFpbnMgb24gdGhlIHNhbWUgcm93L2NvbHVtbi5cbiAgaWYgKG9yaWVudGF0aW9uID09PSAnYm90aCcpIHtcbiAgICBjb25zdCBwcmV2Um93ID0gZmxvb3IocHJldkluZGV4IC8gY29scyk7XG4gICAgaWYgKGV2ZW50LmtleSA9PT0gKHJ0bCA/IEFSUk9XX0xFRlQgOiBBUlJPV19SSUdIVCkpIHtcbiAgICAgIGlmIChzdG9wKSB7XG4gICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICB9XG4gICAgICBpZiAocHJldkluZGV4ICUgY29scyAhPT0gY29scyAtIDEpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gZmluZE5vbkRpc2FibGVkTGlzdEluZGV4KGxpc3QsIHtcbiAgICAgICAgICBzdGFydGluZ0luZGV4OiBwcmV2SW5kZXgsXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAobG9vcEZvY3VzICYmIGlzRGlmZmVyZW50R3JpZFJvdyhuZXh0SW5kZXgsIGNvbHMsIHByZXZSb3cpKSB7XG4gICAgICAgICAgbmV4dEluZGV4ID0gZmluZE5vbkRpc2FibGVkTGlzdEluZGV4KGxpc3QsIHtcbiAgICAgICAgICAgIHN0YXJ0aW5nSW5kZXg6IHByZXZJbmRleCAtIHByZXZJbmRleCAlIGNvbHMgLSAxLFxuICAgICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKG9uTG9vcCkge1xuICAgICAgICAgICAgbmV4dEluZGV4ID0gb25Mb29wKGV2ZW50LCBwcmV2SW5kZXgsIG5leHRJbmRleCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGxvb3BGb2N1cykge1xuICAgICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgobGlzdCwge1xuICAgICAgICAgIHN0YXJ0aW5nSW5kZXg6IHByZXZJbmRleCAtIHByZXZJbmRleCAlIGNvbHMgLSAxLFxuICAgICAgICAgIGRpc2FibGVkSW5kaWNlc1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9uTG9vcCkge1xuICAgICAgICAgIG5leHRJbmRleCA9IG9uTG9vcChldmVudCwgcHJldkluZGV4LCBuZXh0SW5kZXgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoaXNEaWZmZXJlbnRHcmlkUm93KG5leHRJbmRleCwgY29scywgcHJldlJvdykpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gcHJldkluZGV4O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZXZlbnQua2V5ID09PSAocnRsID8gQVJST1dfUklHSFQgOiBBUlJPV19MRUZUKSkge1xuICAgICAgaWYgKHN0b3ApIHtcbiAgICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICAgIH1cbiAgICAgIGlmIChwcmV2SW5kZXggJSBjb2xzICE9PSAwKSB7XG4gICAgICAgIG5leHRJbmRleCA9IGZpbmROb25EaXNhYmxlZExpc3RJbmRleChsaXN0LCB7XG4gICAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4LFxuICAgICAgICAgIGRlY3JlbWVudDogdHJ1ZSxcbiAgICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChsb29wRm9jdXMgJiYgaXNEaWZmZXJlbnRHcmlkUm93KG5leHRJbmRleCwgY29scywgcHJldlJvdykpIHtcbiAgICAgICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgobGlzdCwge1xuICAgICAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4ICsgKGNvbHMgLSBwcmV2SW5kZXggJSBjb2xzKSxcbiAgICAgICAgICAgIGRlY3JlbWVudDogdHJ1ZSxcbiAgICAgICAgICAgIGRpc2FibGVkSW5kaWNlc1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChvbkxvb3ApIHtcbiAgICAgICAgICAgIG5leHRJbmRleCA9IG9uTG9vcChldmVudCwgcHJldkluZGV4LCBuZXh0SW5kZXgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChsb29wRm9jdXMpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gZmluZE5vbkRpc2FibGVkTGlzdEluZGV4KGxpc3QsIHtcbiAgICAgICAgICBzdGFydGluZ0luZGV4OiBwcmV2SW5kZXggKyAoY29scyAtIHByZXZJbmRleCAlIGNvbHMpLFxuICAgICAgICAgIGRlY3JlbWVudDogdHJ1ZSxcbiAgICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChvbkxvb3ApIHtcbiAgICAgICAgICBuZXh0SW5kZXggPSBvbkxvb3AoZXZlbnQsIHByZXZJbmRleCwgbmV4dEluZGV4KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGlzRGlmZmVyZW50R3JpZFJvdyhuZXh0SW5kZXgsIGNvbHMsIHByZXZSb3cpKSB7XG4gICAgICAgIG5leHRJbmRleCA9IHByZXZJbmRleDtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgbGFzdFJvdyA9IGZsb29yKG1heEluZGV4IC8gY29scykgPT09IHByZXZSb3c7XG4gICAgaWYgKGlzSW5kZXhPdXRPZkxpc3RCb3VuZHMobGlzdCwgbmV4dEluZGV4KSkge1xuICAgICAgaWYgKGxvb3BGb2N1cyAmJiBsYXN0Um93KSB7XG4gICAgICAgIG5leHRJbmRleCA9IGV2ZW50LmtleSA9PT0gKHJ0bCA/IEFSUk9XX1JJR0hUIDogQVJST1dfTEVGVCkgPyBtYXhJbmRleCA6IGZpbmROb25EaXNhYmxlZExpc3RJbmRleChsaXN0LCB7XG4gICAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4IC0gcHJldkluZGV4ICUgY29scyAtIDEsXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAob25Mb29wKSB7XG4gICAgICAgICAgbmV4dEluZGV4ID0gb25Mb29wKGV2ZW50LCBwcmV2SW5kZXgsIG5leHRJbmRleCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5leHRJbmRleCA9IHByZXZJbmRleDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG5leHRJbmRleDtcbn1cblxuLyoqIEZvciBlYWNoIGNlbGwgaW5kZXgsIGdldHMgdGhlIGl0ZW0gaW5kZXggdGhhdCBvY2N1cGllcyB0aGF0IGNlbGwgKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVHcmlkQ2VsbE1hcChzaXplcywgY29scywgZGVuc2UpIHtcbiAgY29uc3QgY2VsbE1hcCA9IFtdO1xuICBsZXQgc3RhcnRJbmRleCA9IDA7XG4gIHNpemVzLmZvckVhY2goKHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHRcbiAgfSwgaW5kZXgpID0+IHtcbiAgICBpZiAod2lkdGggPiBjb2xzKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAvLyBUT0RPOiBmaXggbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG11aS9uby1ndWFyZGVkLXRocm93XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgW0Zsb2F0aW5nIFVJXTogSW52YWxpZCBncmlkIC0gaXRlbSB3aWR0aCBhdCBpbmRleCAke2luZGV4fSBpcyBncmVhdGVyIHRoYW4gZ3JpZCBjb2x1bW5zYCk7XG4gICAgICB9XG4gICAgfVxuICAgIGxldCBpdGVtUGxhY2VkID0gZmFsc2U7XG4gICAgaWYgKGRlbnNlKSB7XG4gICAgICBzdGFydEluZGV4ID0gMDtcbiAgICB9XG4gICAgd2hpbGUgKCFpdGVtUGxhY2VkKSB7XG4gICAgICBjb25zdCB0YXJnZXRDZWxscyA9IFtdO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3aWR0aDsgaSArPSAxKSB7XG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgaGVpZ2h0OyBqICs9IDEpIHtcbiAgICAgICAgICB0YXJnZXRDZWxscy5wdXNoKHN0YXJ0SW5kZXggKyBpICsgaiAqIGNvbHMpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoc3RhcnRJbmRleCAlIGNvbHMgKyB3aWR0aCA8PSBjb2xzICYmIHRhcmdldENlbGxzLmV2ZXJ5KGNlbGwgPT4gY2VsbE1hcFtjZWxsXSA9PSBudWxsKSkge1xuICAgICAgICB0YXJnZXRDZWxscy5mb3JFYWNoKGNlbGwgPT4ge1xuICAgICAgICAgIGNlbGxNYXBbY2VsbF0gPSBpbmRleDtcbiAgICAgICAgfSk7XG4gICAgICAgIGl0ZW1QbGFjZWQgPSB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhcnRJbmRleCArPSAxO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG5cbiAgLy8gY29udmVydCBpbnRvIGEgbm9uLXNwYXJzZSBhcnJheVxuICByZXR1cm4gWy4uLmNlbGxNYXBdO1xufVxuXG4vKiogR2V0cyBjZWxsIGluZGV4IG9mIGFuIGl0ZW0ncyBjb3JuZXIgb3IgLTEgd2hlbiBpbmRleCBpcyAtMS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRHcmlkQ2VsbEluZGV4T2ZDb3JuZXIoaW5kZXgsIHNpemVzLCBjZWxsTWFwLCBjb2xzLCBjb3JuZXIpIHtcbiAgaWYgKGluZGV4ID09PSAtMSkge1xuICAgIHJldHVybiAtMTtcbiAgfVxuICBjb25zdCBmaXJzdENlbGxJbmRleCA9IGNlbGxNYXAuaW5kZXhPZihpbmRleCk7XG4gIGNvbnN0IHNpemVJdGVtID0gc2l6ZXNbaW5kZXhdO1xuICBzd2l0Y2ggKGNvcm5lcikge1xuICAgIGNhc2UgJ3RsJzpcbiAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleDtcbiAgICBjYXNlICd0cic6XG4gICAgICBpZiAoIXNpemVJdGVtKSB7XG4gICAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleCArIHNpemVJdGVtLndpZHRoIC0gMTtcbiAgICBjYXNlICdibCc6XG4gICAgICBpZiAoIXNpemVJdGVtKSB7XG4gICAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleCArIChzaXplSXRlbS5oZWlnaHQgLSAxKSAqIGNvbHM7XG4gICAgY2FzZSAnYnInOlxuICAgICAgcmV0dXJuIGNlbGxNYXAubGFzdEluZGV4T2YoaW5kZXgpO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gLTE7XG4gIH1cbn1cblxuLyoqIEdldHMgYWxsIGNlbGwgaW5kaWNlcyB0aGF0IGNvcnJlc3BvbmQgdG8gdGhlIHNwZWNpZmllZCBpbmRpY2VzICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0R3JpZENlbGxJbmRpY2VzKGluZGljZXMsIGNlbGxNYXApIHtcbiAgcmV0dXJuIGNlbGxNYXAuZmxhdE1hcCgoaW5kZXgsIGNlbGxJbmRleCkgPT4gaW5kaWNlcy5pbmNsdWRlcyhpbmRleCkgPyBbY2VsbEluZGV4XSA6IFtdKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0xpc3RJbmRleERpc2FibGVkKGxpc3QsIGluZGV4LCBkaXNhYmxlZEluZGljZXMpIHtcbiAgY29uc3QgaXNFeHBsaWNpdGx5RGlzYWJsZWQgPSB0eXBlb2YgZGlzYWJsZWRJbmRpY2VzID09PSAnZnVuY3Rpb24nID8gZGlzYWJsZWRJbmRpY2VzKGluZGV4KSA6IGRpc2FibGVkSW5kaWNlcz8uaW5jbHVkZXMoaW5kZXgpID8/IGZhbHNlO1xuICBpZiAoaXNFeHBsaWNpdGx5RGlzYWJsZWQpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBjb25zdCBlbGVtZW50ID0gbGlzdFtpbmRleF07XG4gIGlmICghZWxlbWVudCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoIWlzRWxlbWVudFZpc2libGUoZWxlbWVudCkpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8vIEEgbmF0aXZlbHkgZGlzYWJsZWQgZWxlbWVudCBjYW4gbmV2ZXIgcmVjZWl2ZSBmb2N1cywgc28gaXQgbXVzdCBhbHdheXMgYmVcbiAgLy8gc2tpcHBlZCwgZXZlbiB3aGVuIGBkaXNhYmxlZEluZGljZXNgIG1hcmtzIGl0IGFzIGVuYWJsZWQuIE9ubHlcbiAgLy8gYGFyaWEtZGlzYWJsZWRgIGl0ZW1zIGNhbiBiZSBmb2N1c2FibGUtd2hpbGUtZGlzYWJsZWQuXG4gIGlmIChlbGVtZW50Lm1hdGNoZXMoJzpkaXNhYmxlZCcpKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuICFkaXNhYmxlZEluZGljZXMgJiYgKGVsZW1lbnQuaGFzQXR0cmlidXRlKCdkaXNhYmxlZCcpIHx8IGVsZW1lbnQuZ2V0QXR0cmlidXRlKCdhcmlhLWRpc2FibGVkJykgPT09ICd0cnVlJyk7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNIaWRkZW5CeVN0eWxlcyhzdHlsZXMpIHtcbiAgcmV0dXJuIHN0eWxlcy52aXNpYmlsaXR5ID09PSAnaGlkZGVuJyB8fCBzdHlsZXMudmlzaWJpbGl0eSA9PT0gJ2NvbGxhcHNlJztcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0VsZW1lbnRWaXNpYmxlKGVsZW1lbnQsIHN0eWxlcyA9IGVsZW1lbnQgPyBnZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpIDogbnVsbCkge1xuICBpZiAoIWVsZW1lbnQgfHwgIWVsZW1lbnQuaXNDb25uZWN0ZWQgfHwgIXN0eWxlcyB8fCBpc0hpZGRlbkJ5U3R5bGVzKHN0eWxlcykpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKHR5cGVvZiBlbGVtZW50LmNoZWNrVmlzaWJpbGl0eSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiBlbGVtZW50LmNoZWNrVmlzaWJpbGl0eSgpO1xuICB9XG4gIHJldHVybiBzdHlsZXMuZGlzcGxheSAhPT0gJ25vbmUnICYmIHN0eWxlcy5kaXNwbGF5ICE9PSAnY29udGVudHMnO1xufSIsImltcG9ydCB7IGdldENvbXB1dGVkU3R5bGUsIGdldE5vZGVOYW1lLCBpc0hUTUxFbGVtZW50LCBpc1NoYWRvd1Jvb3QgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyBhY3RpdmVFbGVtZW50LCBjb250YWlucyB9IGZyb20gXCIuL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc0VsZW1lbnRWaXNpYmxlIH0gZnJvbSBcIi4vY29tcG9zaXRlLm1qc1wiO1xuY29uc3QgQ0FORElEQVRFX1NFTEVDVE9SID0gJ2FbaHJlZl0sYnV0dG9uLGlucHV0LHNlbGVjdCx0ZXh0YXJlYSxzdW1tYXJ5LGRldGFpbHMsaWZyYW1lLG9iamVjdCxlbWJlZCxbdGFiaW5kZXhdLFtjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPVwiZmFsc2VcIl0pLGF1ZGlvW2NvbnRyb2xzXSx2aWRlb1tjb250cm9sc10nO1xuZnVuY3Rpb24gZ2V0UGFyZW50RWxlbWVudChlbGVtZW50KSB7XG4gIGNvbnN0IGFzc2lnbmVkU2xvdCA9IGVsZW1lbnQuYXNzaWduZWRTbG90O1xuICBpZiAoYXNzaWduZWRTbG90KSB7XG4gICAgcmV0dXJuIGFzc2lnbmVkU2xvdDtcbiAgfVxuICBpZiAoZWxlbWVudC5wYXJlbnRFbGVtZW50KSB7XG4gICAgcmV0dXJuIGVsZW1lbnQucGFyZW50RWxlbWVudDtcbiAgfVxuICBjb25zdCByb290Tm9kZSA9IGVsZW1lbnQuZ2V0Um9vdE5vZGUoKTtcbiAgcmV0dXJuIGlzU2hhZG93Um9vdChyb290Tm9kZSkgPyByb290Tm9kZS5ob3N0IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGdldERldGFpbHNTdW1tYXJ5KGRldGFpbHMpIHtcbiAgZm9yIChjb25zdCBjaGlsZCBvZiBBcnJheS5mcm9tKGRldGFpbHMuY2hpbGRyZW4pKSB7XG4gICAgaWYgKGdldE5vZGVOYW1lKGNoaWxkKSA9PT0gJ3N1bW1hcnknKSB7XG4gICAgICByZXR1cm4gY2hpbGQ7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gaXNXaXRoaW5PcGVuRGV0YWlsc1N1bW1hcnkoZWxlbWVudCwgZGV0YWlscykge1xuICBjb25zdCBzdW1tYXJ5ID0gZ2V0RGV0YWlsc1N1bW1hcnkoZGV0YWlscyk7XG4gIHJldHVybiAhIXN1bW1hcnkgJiYgKGVsZW1lbnQgPT09IHN1bW1hcnkgfHwgY29udGFpbnMoc3VtbWFyeSwgZWxlbWVudCkpO1xufVxuZnVuY3Rpb24gaXNGb2N1c2FibGVDYW5kaWRhdGUoZWxlbWVudCkge1xuICBjb25zdCBub2RlTmFtZSA9IGVsZW1lbnQgPyBnZXROb2RlTmFtZShlbGVtZW50KSA6ICcnO1xuICByZXR1cm4gZWxlbWVudCAhPSBudWxsICYmIGVsZW1lbnQubWF0Y2hlcyhDQU5ESURBVEVfU0VMRUNUT1IpICYmIChub2RlTmFtZSAhPT0gJ3N1bW1hcnknIHx8IGVsZW1lbnQucGFyZW50RWxlbWVudCAhPSBudWxsICYmIGdldE5vZGVOYW1lKGVsZW1lbnQucGFyZW50RWxlbWVudCkgPT09ICdkZXRhaWxzJyAmJiBnZXREZXRhaWxzU3VtbWFyeShlbGVtZW50LnBhcmVudEVsZW1lbnQpID09PSBlbGVtZW50KSAmJiAobm9kZU5hbWUgIT09ICdkZXRhaWxzJyB8fCBnZXREZXRhaWxzU3VtbWFyeShlbGVtZW50KSA9PSBudWxsKSAmJiAobm9kZU5hbWUgIT09ICdpbnB1dCcgfHwgZWxlbWVudC50eXBlICE9PSAnaGlkZGVuJyk7XG59XG5mdW5jdGlvbiBpc0ZvY3VzYWJsZUVsZW1lbnQoZWxlbWVudCkge1xuICBpZiAoIWlzRm9jdXNhYmxlQ2FuZGlkYXRlKGVsZW1lbnQpIHx8ICFlbGVtZW50LmlzQ29ubmVjdGVkIHx8IGVsZW1lbnQubWF0Y2hlcygnOmRpc2FibGVkJykpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChsZXQgY3VycmVudCA9IGVsZW1lbnQ7IGN1cnJlbnQ7IGN1cnJlbnQgPSBnZXRQYXJlbnRFbGVtZW50KGN1cnJlbnQpKSB7XG4gICAgY29uc3QgaXNBbmNlc3RvciA9IGN1cnJlbnQgIT09IGVsZW1lbnQ7XG4gICAgY29uc3QgaXNTbG90ID0gZ2V0Tm9kZU5hbWUoY3VycmVudCkgPT09ICdzbG90JztcbiAgICBpZiAoY3VycmVudC5oYXNBdHRyaWJ1dGUoJ2luZXJ0JykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGlzQW5jZXN0b3IgJiYgZ2V0Tm9kZU5hbWUoY3VycmVudCkgPT09ICdkZXRhaWxzJyAmJiAhY3VycmVudC5vcGVuICYmICFpc1dpdGhpbk9wZW5EZXRhaWxzU3VtbWFyeShlbGVtZW50LCBjdXJyZW50KSB8fCBjdXJyZW50Lmhhc0F0dHJpYnV0ZSgnaGlkZGVuJykgfHwgIWlzU2xvdCAmJiAhaXNWaXNpYmxlSW5UYWJiYWJsZVRyZWUoY3VycmVudCwgaXNBbmNlc3RvcikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpc1Zpc2libGVJblRhYmJhYmxlVHJlZShlbGVtZW50LCBpc0FuY2VzdG9yKSB7XG4gIGNvbnN0IHN0eWxlcyA9IGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gIGlmICghaXNBbmNlc3Rvcikge1xuICAgIHJldHVybiBpc0VsZW1lbnRWaXNpYmxlKGVsZW1lbnQsIHN0eWxlcyk7XG4gIH1cbiAgcmV0dXJuIHN0eWxlcy5kaXNwbGF5ICE9PSAnbm9uZSc7XG59XG5mdW5jdGlvbiBnZXRUYWJJbmRleChlbGVtZW50KSB7XG4gIGNvbnN0IHRhYkluZGV4ID0gZWxlbWVudC50YWJJbmRleDtcbiAgaWYgKHRhYkluZGV4IDwgMCkge1xuICAgIGNvbnN0IG5vZGVOYW1lID0gZ2V0Tm9kZU5hbWUoZWxlbWVudCk7XG4gICAgaWYgKG5vZGVOYW1lID09PSAnZGV0YWlscycgfHwgbm9kZU5hbWUgPT09ICdhdWRpbycgfHwgbm9kZU5hbWUgPT09ICd2aWRlbycgfHwgaXNIVE1MRWxlbWVudChlbGVtZW50KSAmJiBlbGVtZW50LmlzQ29udGVudEVkaXRhYmxlKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRhYkluZGV4O1xufVxuZnVuY3Rpb24gZ2V0TmFtZWRSYWRpb0lucHV0KGVsZW1lbnQpIHtcbiAgaWYgKGdldE5vZGVOYW1lKGVsZW1lbnQpICE9PSAnaW5wdXQnKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgaW5wdXQgPSBlbGVtZW50O1xuICByZXR1cm4gaW5wdXQudHlwZSA9PT0gJ3JhZGlvJyAmJiBpbnB1dC5uYW1lICE9PSAnJyA/IGlucHV0IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGlzVGFiYmFibGVSYWRpbyhlbGVtZW50LCBjYW5kaWRhdGVzKSB7XG4gIGNvbnN0IGlucHV0ID0gZ2V0TmFtZWRSYWRpb0lucHV0KGVsZW1lbnQpO1xuICBpZiAoIWlucHV0KSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgY29uc3QgY2hlY2tlZFJhZGlvID0gY2FuZGlkYXRlcy5maW5kKGNhbmRpZGF0ZSA9PiB7XG4gICAgY29uc3QgcmFkaW8gPSBnZXROYW1lZFJhZGlvSW5wdXQoY2FuZGlkYXRlKTtcbiAgICByZXR1cm4gcmFkaW8/Lm5hbWUgPT09IGlucHV0Lm5hbWUgJiYgcmFkaW8uZm9ybSA9PT0gaW5wdXQuZm9ybSAmJiByYWRpby5jaGVja2VkO1xuICB9KTtcbiAgaWYgKGNoZWNrZWRSYWRpbykge1xuICAgIHJldHVybiBjaGVja2VkUmFkaW8gPT09IGlucHV0O1xuICB9XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbmQoY2FuZGlkYXRlID0+IHtcbiAgICBjb25zdCByYWRpbyA9IGdldE5hbWVkUmFkaW9JbnB1dChjYW5kaWRhdGUpO1xuICAgIHJldHVybiByYWRpbz8ubmFtZSA9PT0gaW5wdXQubmFtZSAmJiByYWRpby5mb3JtID09PSBpbnB1dC5mb3JtO1xuICB9KSA9PT0gaW5wdXQ7XG59XG5mdW5jdGlvbiBnZXRDb21wb3NlZENoaWxkcmVuKGNvbnRhaW5lcikge1xuICBpZiAoaXNIVE1MRWxlbWVudChjb250YWluZXIpICYmIGdldE5vZGVOYW1lKGNvbnRhaW5lcikgPT09ICdzbG90Jykge1xuICAgIGNvbnN0IGFzc2lnbmVkRWxlbWVudHMgPSBjb250YWluZXIuYXNzaWduZWRFbGVtZW50cyh7XG4gICAgICBmbGF0dGVuOiB0cnVlXG4gICAgfSk7XG4gICAgaWYgKGFzc2lnbmVkRWxlbWVudHMubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIGFzc2lnbmVkRWxlbWVudHM7XG4gICAgfVxuICB9XG4gIGlmIChpc0hUTUxFbGVtZW50KGNvbnRhaW5lcikgJiYgY29udGFpbmVyLnNoYWRvd1Jvb3QpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbShjb250YWluZXIuc2hhZG93Um9vdC5jaGlsZHJlbik7XG4gIH1cbiAgcmV0dXJuIEFycmF5LmZyb20oY29udGFpbmVyLmNoaWxkcmVuKTtcbn1cbmZ1bmN0aW9uIGFwcGVuZENhbmRpZGF0ZXMoY29udGFpbmVyLCBsaXN0KSB7XG4gIGdldENvbXBvc2VkQ2hpbGRyZW4oY29udGFpbmVyKS5mb3JFYWNoKGNoaWxkID0+IHtcbiAgICBpZiAoaXNGb2N1c2FibGVDYW5kaWRhdGUoY2hpbGQpKSB7XG4gICAgICBsaXN0LnB1c2goY2hpbGQpO1xuICAgIH1cbiAgICBhcHBlbmRDYW5kaWRhdGVzKGNoaWxkLCBsaXN0KTtcbiAgfSk7XG59XG5mdW5jdGlvbiBhcHBlbmRNYXRjaGluZ0VsZW1lbnRzKGNvbnRhaW5lciwgc2VsZWN0b3IsIGxpc3QpIHtcbiAgZ2V0Q29tcG9zZWRDaGlsZHJlbihjb250YWluZXIpLmZvckVhY2goY2hpbGQgPT4ge1xuICAgIGlmIChpc0hUTUxFbGVtZW50KGNoaWxkKSAmJiBjaGlsZC5tYXRjaGVzKHNlbGVjdG9yKSkge1xuICAgICAgbGlzdC5wdXNoKGNoaWxkKTtcbiAgICB9XG4gICAgYXBwZW5kTWF0Y2hpbmdFbGVtZW50cyhjaGlsZCwgc2VsZWN0b3IsIGxpc3QpO1xuICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1RhYmJhYmxlKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzRm9jdXNhYmxlRWxlbWVudChlbGVtZW50KSAmJiBnZXRUYWJJbmRleChlbGVtZW50KSA+PSAwO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZvY3VzYWJsZShjb250YWluZXIpIHtcbiAgY29uc3QgY2FuZGlkYXRlcyA9IFtdO1xuICBhcHBlbmRDYW5kaWRhdGVzKGNvbnRhaW5lciwgY2FuZGlkYXRlcyk7XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbHRlcihpc0ZvY3VzYWJsZUVsZW1lbnQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHRhYmJhYmxlKGNvbnRhaW5lcikge1xuICBjb25zdCBjYW5kaWRhdGVzID0gZm9jdXNhYmxlKGNvbnRhaW5lcik7XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbHRlcihlbGVtZW50ID0+IGdldFRhYkluZGV4KGVsZW1lbnQpID49IDAgJiYgaXNUYWJiYWJsZVJhZGlvKGVsZW1lbnQsIGNhbmRpZGF0ZXMpKTtcbn1cbmZ1bmN0aW9uIGdldFRhYmJhYmxlSW4oY29udGFpbmVyLCBkaXIpIHtcbiAgY29uc3QgbGlzdCA9IHRhYmJhYmxlKGNvbnRhaW5lcik7XG4gIGNvbnN0IGxlbiA9IGxpc3QubGVuZ3RoO1xuICBpZiAobGVuID09PSAwKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBjb25zdCBhY3RpdmUgPSBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoY29udGFpbmVyKSk7XG4gIGNvbnN0IGluZGV4ID0gbGlzdC5pbmRleE9mKGFjdGl2ZSk7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXN0ZWQtdGVybmFyeVxuICBjb25zdCBuZXh0SW5kZXggPSBpbmRleCA9PT0gLTEgPyBkaXIgPT09IDEgPyAwIDogbGVuIC0gMSA6IGluZGV4ICsgZGlyO1xuICByZXR1cm4gbGlzdFtuZXh0SW5kZXhdO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldE5leHRUYWJiYWJsZShyZWZlcmVuY2VFbGVtZW50KSB7XG4gIHJldHVybiBnZXRUYWJiYWJsZUluKG93bmVyRG9jdW1lbnQocmVmZXJlbmNlRWxlbWVudCkuYm9keSwgMSkgfHwgcmVmZXJlbmNlRWxlbWVudDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRQcmV2aW91c1RhYmJhYmxlKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgcmV0dXJuIGdldFRhYmJhYmxlSW4ob3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KS5ib2R5LCAtMSkgfHwgcmVmZXJlbmNlRWxlbWVudDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRUYWJiYWJsZU5lYXJFbGVtZW50KHJlZmVyZW5jZUVsZW1lbnQsIGRpcmVjdGlvbiwgZXhjbHVkZSkge1xuICBpZiAoIXJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8vIEtlZXAgdGhlIGFuY2hvcidzIGNvbXBvc2VkLXRyZWUgcG9zaXRpb24gc2VwYXJhdGUgZnJvbSB0aGUgZm9jdXNhYmxlIHJhZGlvIGNhbmRpZGF0ZXMuXG4gIGNvbnN0IGxpc3QgPSBbXTtcbiAgYXBwZW5kQ2FuZGlkYXRlcyhvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpLmJvZHksIGxpc3QpO1xuICBjb25zdCBpbmRleCA9IGxpc3QuaW5kZXhPZihyZWZlcmVuY2VFbGVtZW50KTtcbiAgaWYgKGluZGV4ID09PSAtMSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IGNhbmRpZGF0ZXMgPSBsaXN0LmZpbHRlcihpc0ZvY3VzYWJsZUVsZW1lbnQpO1xuICBmb3IgKGxldCBvZmZzZXQgPSAxOyBvZmZzZXQgPCBsaXN0Lmxlbmd0aDsgb2Zmc2V0ICs9IDEpIHtcbiAgICBjb25zdCBlbGVtZW50ID0gbGlzdFsoaW5kZXggKyBkaXJlY3Rpb24gKiBvZmZzZXQgKyBsaXN0Lmxlbmd0aCkgJSBsaXN0Lmxlbmd0aF07XG4gICAgaWYgKCFjb250YWlucyhleGNsdWRlLCBlbGVtZW50KSAmJiBpc1RhYmJhYmxlKGVsZW1lbnQpICYmIGlzVGFiYmFibGVSYWRpbyhlbGVtZW50LCBjYW5kaWRhdGVzKSkge1xuICAgICAgcmV0dXJuIGVsZW1lbnQ7XG4gICAgfVxuICB9XG4gIHJldHVybiBsaXN0W2luZGV4XTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc091dHNpZGVFdmVudChldmVudCwgY29udGFpbmVyKSB7XG4gIGNvbnN0IGNvbnRhaW5lckVsZW1lbnQgPSBjb250YWluZXIgfHwgZXZlbnQuY3VycmVudFRhcmdldDtcbiAgY29uc3QgcmVsYXRlZFRhcmdldCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gIHJldHVybiAhcmVsYXRlZFRhcmdldCB8fCAhY29udGFpbnMoY29udGFpbmVyRWxlbWVudCwgcmVsYXRlZFRhcmdldCk7XG59XG5leHBvcnQgZnVuY3Rpb24gZGlzYWJsZUZvY3VzSW5zaWRlKGNvbnRhaW5lcikge1xuICBjb25zdCB0YWJiYWJsZUVsZW1lbnRzID0gdGFiYmFibGUoY29udGFpbmVyKTtcbiAgdGFiYmFibGVFbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xuICAgIGVsZW1lbnQuZGF0YXNldC50YWJpbmRleCA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKCd0YWJpbmRleCcpIHx8ICcnO1xuICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICctMScpO1xuICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlbmFibGVGb2N1c0luc2lkZShjb250YWluZXIpIHtcbiAgY29uc3QgZWxlbWVudHMgPSBbXTtcbiAgYXBwZW5kTWF0Y2hpbmdFbGVtZW50cyhjb250YWluZXIsICdbZGF0YS10YWJpbmRleF0nLCBlbGVtZW50cyk7XG4gIGVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgY29uc3QgdGFiaW5kZXggPSBlbGVtZW50LmRhdGFzZXQudGFiaW5kZXg7XG4gICAgZGVsZXRlIGVsZW1lbnQuZGF0YXNldC50YWJpbmRleDtcbiAgICBpZiAodGFiaW5kZXgpIHtcbiAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsIHRhYmluZGV4KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoJ3RhYmluZGV4Jyk7XG4gICAgfVxuICB9KTtcbn0iLCIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tbG9vcC1mdW5jICovXG5cbmV4cG9ydCBmdW5jdGlvbiBnZXROb2RlQ2hpbGRyZW4obm9kZXMsIGlkLCBvbmx5T3BlbkNoaWxkcmVuID0gdHJ1ZSkge1xuICBjb25zdCBkaXJlY3RDaGlsZHJlbiA9IG5vZGVzLmZpbHRlcihub2RlID0+IG5vZGUucGFyZW50SWQgPT09IGlkKTtcbiAgcmV0dXJuIGRpcmVjdENoaWxkcmVuLmZsYXRNYXAoY2hpbGQgPT4gWy4uLighb25seU9wZW5DaGlsZHJlbiB8fCBjaGlsZC5jb250ZXh0Py5vcGVuID8gW2NoaWxkXSA6IFtdKSwgLi4uZ2V0Tm9kZUNoaWxkcmVuKG5vZGVzLCBjaGlsZC5pZCwgb25seU9wZW5DaGlsZHJlbildKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXROb2RlQW5jZXN0b3JzKG5vZGVzLCBpZCkge1xuICBsZXQgYWxsQW5jZXN0b3JzID0gW107XG4gIGxldCBjdXJyZW50UGFyZW50SWQgPSBub2Rlcy5maW5kKG5vZGUgPT4gbm9kZS5pZCA9PT0gaWQpPy5wYXJlbnRJZDtcbiAgd2hpbGUgKGN1cnJlbnRQYXJlbnRJZCkge1xuICAgIGNvbnN0IGN1cnJlbnROb2RlID0gbm9kZXMuZmluZChub2RlID0+IG5vZGUuaWQgPT09IGN1cnJlbnRQYXJlbnRJZCk7XG4gICAgY3VycmVudFBhcmVudElkID0gY3VycmVudE5vZGU/LnBhcmVudElkO1xuICAgIGlmIChjdXJyZW50Tm9kZSkge1xuICAgICAgYWxsQW5jZXN0b3JzID0gYWxsQW5jZXN0b3JzLmNvbmNhdChjdXJyZW50Tm9kZSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBhbGxBbmNlc3RvcnM7XG59IiwiZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUF0dHJpYnV0ZShuYW1lKSB7XG4gIHJldHVybiBgZGF0YS1iYXNlLXVpLSR7bmFtZX1gO1xufSIsImltcG9ydCB7IE5PT1AgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5sZXQgcmFmSWQgPSAwO1xuZXhwb3J0IGZ1bmN0aW9uIGVucXVldWVGb2N1cyhlbCwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBwcmV2ZW50U2Nyb2xsID0gZmFsc2UsXG4gICAgc3luYyA9IGZhbHNlLFxuICAgIHNob3VsZEZvY3VzXG4gIH0gPSBvcHRpb25zO1xuICBjYW5jZWxBbmltYXRpb25GcmFtZShyYWZJZCk7XG4gIGZ1bmN0aW9uIGV4ZWMoKSB7XG4gICAgaWYgKHNob3VsZEZvY3VzICYmICFzaG91bGRGb2N1cygpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGVsPy5mb2N1cyh7XG4gICAgICBwcmV2ZW50U2Nyb2xsXG4gICAgfSk7XG4gIH1cbiAgaWYgKHN5bmMpIHtcbiAgICBleGVjKCk7XG4gICAgcmV0dXJuIE5PT1A7XG4gIH1cbiAgY29uc3QgY3VycmVudFJhZklkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGV4ZWMpO1xuICByYWZJZCA9IGN1cnJlbnRSYWZJZDtcbiAgcmV0dXJuICgpID0+IHtcbiAgICBpZiAocmFmSWQgPT09IGN1cnJlbnRSYWZJZCkge1xuICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUoY3VycmVudFJhZklkKTtcbiAgICAgIHJhZklkID0gMDtcbiAgICB9XG4gIH07XG59IiwiLy8gTW9kaWZpZWQgdG8gYWRkIGNvbmRpdGlvbmFsIGBhcmlhLWhpZGRlbmAgc3VwcG9ydDpcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS90aGVLYXNoZXkvYXJpYS1oaWRkZW4vYmxvYi85MjIwYzhmNGE0ZmQzNWY2M2JlZTU1MTBhOWY0MWEzNzI2NDM4MmQ0L3NyYy9pbmRleC50c1xuaW1wb3J0IHsgZ2V0Tm9kZU5hbWUsIGlzU2hhZG93Um9vdCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmNvbnN0IG1hcmtlck5hbWUgPSAnZGF0YS1iYXNlLXVpLWluZXJ0JztcbmxldCBhcmlhSGlkZGVuQ291bnRlck1hcCA9IG5ldyBXZWFrTWFwKCk7XG5sZXQgdW5jb250cm9sbGVkRWxlbWVudHNTZXQgPSBuZXcgV2Vha1NldCgpO1xubGV0IG1hcmtlckNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xubGV0IGxvY2tDb3VudCA9IDA7XG5mdW5jdGlvbiB1bndyYXBIb3N0KG5vZGUpIHtcbiAgaWYgKCFub2RlKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgcmV0dXJuIGlzU2hhZG93Um9vdChub2RlKSA/IG5vZGUuaG9zdCA6IHVud3JhcEhvc3Qobm9kZS5wYXJlbnROb2RlKTtcbn1cbmNvbnN0IGNvcnJlY3RFbGVtZW50cyA9IChwYXJlbnQsIHRhcmdldHMpID0+IHRhcmdldHMubWFwKHRhcmdldCA9PiB7XG4gIGlmIChwYXJlbnQuY29udGFpbnModGFyZ2V0KSkge1xuICAgIHJldHVybiB0YXJnZXQ7XG4gIH1cbiAgY29uc3QgY29ycmVjdGVkVGFyZ2V0ID0gdW53cmFwSG9zdCh0YXJnZXQpO1xuICBpZiAocGFyZW50LmNvbnRhaW5zKGNvcnJlY3RlZFRhcmdldCkpIHtcbiAgICByZXR1cm4gY29ycmVjdGVkVGFyZ2V0O1xuICB9XG4gIHJldHVybiBudWxsO1xufSkuZmlsdGVyKHggPT4geCAhPSBudWxsKTtcbmNvbnN0IGJ1aWxkS2VlcFNldCA9IHRhcmdldHMgPT4ge1xuICBjb25zdCBrZWVwID0gbmV3IFNldCgpO1xuICB0YXJnZXRzLmZvckVhY2godGFyZ2V0ID0+IHtcbiAgICBsZXQgbm9kZSA9IHRhcmdldDtcbiAgICB3aGlsZSAobm9kZSAmJiAha2VlcC5oYXMobm9kZSkpIHtcbiAgICAgIGtlZXAuYWRkKG5vZGUpO1xuICAgICAgbm9kZSA9IG5vZGUucGFyZW50Tm9kZTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4ga2VlcDtcbn07XG5jb25zdCBjb2xsZWN0T3V0c2lkZUVsZW1lbnRzID0gKHJvb3QsIGtlZXBFbGVtZW50cywgc3RvcEVsZW1lbnRzKSA9PiB7XG4gIGNvbnN0IG91dHNpZGUgPSBbXTtcbiAgY29uc3Qgd2FsayA9IHBhcmVudCA9PiB7XG4gICAgaWYgKCFwYXJlbnQgfHwgc3RvcEVsZW1lbnRzLmhhcyhwYXJlbnQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIEFycmF5LmZyb20ocGFyZW50LmNoaWxkcmVuKS5mb3JFYWNoKG5vZGUgPT4ge1xuICAgICAgaWYgKGdldE5vZGVOYW1lKG5vZGUpID09PSAnc2NyaXB0Jykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoa2VlcEVsZW1lbnRzLmhhcyhub2RlKSkge1xuICAgICAgICB3YWxrKG5vZGUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3V0c2lkZS5wdXNoKG5vZGUpO1xuICAgICAgfVxuICAgIH0pO1xuICB9O1xuICB3YWxrKHJvb3QpO1xuICByZXR1cm4gb3V0c2lkZTtcbn07XG5mdW5jdGlvbiBhcHBseUF0dHJpYnV0ZVRvT3RoZXJzKHVuY29ycmVjdGVkQXZvaWRFbGVtZW50cywgYm9keSwgYXJpYUhpZGRlbiwge1xuICBtYXJrID0gdHJ1ZVxufSkge1xuICBjb25zdCBhdm9pZEVsZW1lbnRzID0gY29ycmVjdEVsZW1lbnRzKGJvZHksIHVuY29ycmVjdGVkQXZvaWRFbGVtZW50cyk7XG4gIGNvbnN0IG1hcmtlclRhcmdldHMgPSBtYXJrID8gY29sbGVjdE91dHNpZGVFbGVtZW50cyhib2R5LCBidWlsZEtlZXBTZXQoYXZvaWRFbGVtZW50cyksIG5ldyBTZXQoYXZvaWRFbGVtZW50cykpIDogW107XG4gIGNvbnN0IGhpZGRlbkVsZW1lbnRzID0gW107XG4gIGNvbnN0IG1hcmtlZEVsZW1lbnRzID0gW107XG4gIGlmIChhcmlhSGlkZGVuKSB7XG4gICAgY29uc3QgYXJpYUxpdmVFbGVtZW50cyA9IGNvcnJlY3RFbGVtZW50cyhib2R5LCBBcnJheS5mcm9tKGJvZHkucXVlcnlTZWxlY3RvckFsbCgnW2FyaWEtbGl2ZV0nKSkpO1xuICAgIGNvbnN0IGNvbnRyb2xFbGVtZW50cyA9IGF2b2lkRWxlbWVudHMuY29uY2F0KGFyaWFMaXZlRWxlbWVudHMpO1xuICAgIGNvbnN0IGNvbnRyb2xUYXJnZXRzID0gY29sbGVjdE91dHNpZGVFbGVtZW50cyhib2R5LCBidWlsZEtlZXBTZXQoY29udHJvbEVsZW1lbnRzKSwgbmV3IFNldChjb250cm9sRWxlbWVudHMpKTtcbiAgICBjb250cm9sVGFyZ2V0cy5mb3JFYWNoKG5vZGUgPT4ge1xuICAgICAgY29uc3QgYXR0ciA9IG5vZGUuZ2V0QXR0cmlidXRlKCdhcmlhLWhpZGRlbicpO1xuICAgICAgY29uc3QgYWxyZWFkeUhpZGRlbiA9IGF0dHIgIT09IG51bGwgJiYgYXR0ciAhPT0gJ2ZhbHNlJztcbiAgICAgIGNvbnN0IGNvdW50ZXJWYWx1ZSA9IChhcmlhSGlkZGVuQ291bnRlck1hcC5nZXQobm9kZSkgfHwgMCkgKyAxO1xuICAgICAgYXJpYUhpZGRlbkNvdW50ZXJNYXAuc2V0KG5vZGUsIGNvdW50ZXJWYWx1ZSk7XG4gICAgICBoaWRkZW5FbGVtZW50cy5wdXNoKG5vZGUpO1xuICAgICAgaWYgKGNvdW50ZXJWYWx1ZSA9PT0gMSAmJiBhbHJlYWR5SGlkZGVuKSB7XG4gICAgICAgIHVuY29udHJvbGxlZEVsZW1lbnRzU2V0LmFkZChub2RlKTtcbiAgICAgIH1cbiAgICAgIGlmICghYWxyZWFkeUhpZGRlbikge1xuICAgICAgICBub2RlLnNldEF0dHJpYnV0ZSgnYXJpYS1oaWRkZW4nLCAndHJ1ZScpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIGlmIChtYXJrKSB7XG4gICAgbWFya2VyVGFyZ2V0cy5mb3JFYWNoKG5vZGUgPT4ge1xuICAgICAgY29uc3QgbWFya2VyVmFsdWUgPSAobWFya2VyQ291bnRlck1hcC5nZXQobm9kZSkgfHwgMCkgKyAxO1xuICAgICAgbWFya2VyQ291bnRlck1hcC5zZXQobm9kZSwgbWFya2VyVmFsdWUpO1xuICAgICAgbWFya2VkRWxlbWVudHMucHVzaChub2RlKTtcbiAgICAgIGlmIChtYXJrZXJWYWx1ZSA9PT0gMSkge1xuICAgICAgICBub2RlLnNldEF0dHJpYnV0ZShtYXJrZXJOYW1lLCAnJyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgbG9ja0NvdW50ICs9IDE7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgaGlkZGVuRWxlbWVudHMuZm9yRWFjaChlbGVtZW50ID0+IHtcbiAgICAgIGNvbnN0IGNvdW50ZXJWYWx1ZSA9IChhcmlhSGlkZGVuQ291bnRlck1hcC5nZXQoZWxlbWVudCkgfHwgMCkgLSAxO1xuICAgICAgYXJpYUhpZGRlbkNvdW50ZXJNYXAuc2V0KGVsZW1lbnQsIGNvdW50ZXJWYWx1ZSk7XG4gICAgICBpZiAoIWNvdW50ZXJWYWx1ZSkge1xuICAgICAgICBpZiAoIXVuY29udHJvbGxlZEVsZW1lbnRzU2V0LmhhcyhlbGVtZW50KSkge1xuICAgICAgICAgIGVsZW1lbnQucmVtb3ZlQXR0cmlidXRlKCdhcmlhLWhpZGRlbicpO1xuICAgICAgICB9XG4gICAgICAgIHVuY29udHJvbGxlZEVsZW1lbnRzU2V0LmRlbGV0ZShlbGVtZW50KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBpZiAobWFyaykge1xuICAgICAgbWFya2VkRWxlbWVudHMuZm9yRWFjaChlbGVtZW50ID0+IHtcbiAgICAgICAgY29uc3QgbWFya2VyVmFsdWUgPSAobWFya2VyQ291bnRlck1hcC5nZXQoZWxlbWVudCkgfHwgMCkgLSAxO1xuICAgICAgICBtYXJrZXJDb3VudGVyTWFwLnNldChlbGVtZW50LCBtYXJrZXJWYWx1ZSk7XG4gICAgICAgIGlmICghbWFya2VyVmFsdWUpIHtcbiAgICAgICAgICBlbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShtYXJrZXJOYW1lKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGxvY2tDb3VudCAtPSAxO1xuICAgIGlmICghbG9ja0NvdW50KSB7XG4gICAgICBhcmlhSGlkZGVuQ291bnRlck1hcCA9IG5ldyBXZWFrTWFwKCk7XG4gICAgICB1bmNvbnRyb2xsZWRFbGVtZW50c1NldCA9IG5ldyBXZWFrU2V0KCk7XG4gICAgICBtYXJrZXJDb3VudGVyTWFwID0gbmV3IFdlYWtNYXAoKTtcbiAgICB9XG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gbWFya090aGVycyhhdm9pZEVsZW1lbnRzLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGFyaWFIaWRkZW4gPSBmYWxzZSxcbiAgICBtYXJrID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgYm9keSA9IG93bmVyRG9jdW1lbnQoYXZvaWRFbGVtZW50c1swXSkuYm9keTtcbiAgcmV0dXJuIGFwcGx5QXR0cmlidXRlVG9PdGhlcnMoYXZvaWRFbGVtZW50cywgYm9keSwgYXJpYUhpZGRlbiwge1xuICAgIG1hcmtcbiAgfSk7XG59IiwiZXhwb3J0IGNvbnN0IFRZUEVBSEVBRF9SRVNFVF9NUyA9IDUwMDtcbmV4cG9ydCBjb25zdCBQQVRJRU5UX0NMSUNLX1RIUkVTSE9MRCA9IDUwMDtcbmV4cG9ydCBjb25zdCBESVNBQkxFRF9UUkFOU0lUSU9OU19TVFlMRSA9IHtcbiAgc3R5bGU6IHtcbiAgICB0cmFuc2l0aW9uOiAnbm9uZSdcbiAgfVxufTtcbmV4cG9ydCBjb25zdCBDTElDS19UUklHR0VSX0lERU5USUZJRVIgPSAnZGF0YS1iYXNlLXVpLWNsaWNrLXRyaWdnZXInO1xuZXhwb3J0IGNvbnN0IEJBU0VfVUlfU1dJUEVfSUdOT1JFX0FUVFJJQlVURSA9ICdkYXRhLWJhc2UtdWktc3dpcGUtaWdub3JlJztcbmV4cG9ydCBjb25zdCBMRUdBQ1lfU1dJUEVfSUdOT1JFX0FUVFJJQlVURSA9ICdkYXRhLXN3aXBlLWlnbm9yZSc7XG5leHBvcnQgY29uc3QgQkFTRV9VSV9TV0lQRV9JR05PUkVfU0VMRUNUT1IgPSBgWyR7QkFTRV9VSV9TV0lQRV9JR05PUkVfQVRUUklCVVRFfV1gO1xuZXhwb3J0IGNvbnN0IExFR0FDWV9TV0lQRV9JR05PUkVfU0VMRUNUT1IgPSBgWyR7TEVHQUNZX1NXSVBFX0lHTk9SRV9BVFRSSUJVVEV9XWA7XG5cbi8qKlxuICogVXNlZCBmb3IgZHJvcGRvd25zIHRoYXQgdXN1YWxseSBzdHJpY3RseSBwcmVmZXIgdG9wL2JvdHRvbSBwbGFjZW1lbnRzIGFuZFxuICogdXNlIGB2YXIoLS1hdmFpbGFibGUtaGVpZ2h0KWAgdG8gbGltaXQgdGhlaXIgaGVpZ2h0LlxuICovXG5leHBvcnQgY29uc3QgRFJPUERPV05fQ09MTElTSU9OX0FWT0lEQU5DRSA9IHtcbiAgZmFsbGJhY2tBeGlzU2lkZTogJ25vbmUnXG59O1xuXG4vKipcbiAqIFVzZWQgYnkgcmVndWxhciBwb3B1cHMgdGhhdCB1c3VhbGx5IGFyZW4ndCBzY3JvbGxhYmxlIGFuZCBhcmUgYWxsb3dlZCB0b1xuICogZnJlZWx5IGZsaXAgdG8gYW55IGF4aXMgb2YgcGxhY2VtZW50LlxuICovXG5leHBvcnQgY29uc3QgUE9QVVBfQ09MTElTSU9OX0FWT0lEQU5DRSA9IHtcbiAgZmFsbGJhY2tBeGlzU2lkZTogJ2VuZCdcbn07XG5cbi8qKlxuICogU3BlY2lhbCB2aXN1YWxseSBoaWRkZW4gc3R5bGVzIGZvciB0aGUgYXJpYS1vd25zIG93bmVyIGVsZW1lbnQgdG8gZW5zdXJlIG93bmVkIGVsZW1lbnRcbiAqIGFjY2Vzc2liaWxpdHkgaW4gaU9TL1NhZmFyaS9Wb2ljZUNvbnRyb2wuXG4gKiBUaGUgb3duZXIgZWxlbWVudCBpcyBhbiBlbXB0eSBzcGFuLCBzbyBtb3N0IG9mIHRoZSBjb21tb24gdmlzdWFsbHkgaGlkZGVuIHN0eWxlcyBhcmUgbm90IG5lZWRlZC5cbiAqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8zNDAzXG4gKi9cbmV4cG9ydCBjb25zdCBvd25lclZpc3VhbGx5SGlkZGVuID0ge1xuICBjbGlwUGF0aDogJ2luc2V0KDUwJSknLFxuICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgdG9wOiAwLFxuICBsZWZ0OiAwXG59OyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IGlzTm9kZSB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgYWRkRXZlbnRMaXN0ZW5lciB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2FkZEV2ZW50TGlzdGVuZXInO1xuaW1wb3J0IHsgbWVyZ2VDbGVhbnVwcyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL21lcmdlQ2xlYW51cHMnO1xuaW1wb3J0IHsgdXNlSWQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJZCc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBGb2N1c0d1YXJkIH0gZnJvbSBcIi4uLy4uL3V0aWxzL0ZvY3VzR3VhcmQubWpzXCI7XG5pbXBvcnQgeyBlbmFibGVGb2N1c0luc2lkZSwgZGlzYWJsZUZvY3VzSW5zaWRlLCBnZXRQcmV2aW91c1RhYmJhYmxlLCBnZXROZXh0VGFiYmFibGUsIGlzT3V0c2lkZUV2ZW50IH0gZnJvbSBcIi4uL3V0aWxzL3RhYmJhYmxlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQXR0cmlidXRlIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUF0dHJpYnV0ZS5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBvd25lclZpc3VhbGx5SGlkZGVuIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCwganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuY29uc3QgUG9ydGFsQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgUG9ydGFsQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiUG9ydGFsQ29udGV4dFwiO1xuZXhwb3J0IGNvbnN0IHVzZVBvcnRhbENvbnRleHQgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KFBvcnRhbENvbnRleHQpO1xuY29uc3QgYXR0ciA9IGNyZWF0ZUF0dHJpYnV0ZSgncG9ydGFsJyk7XG5leHBvcnQgZnVuY3Rpb24gdXNlRmxvYXRpbmdQb3J0YWxOb2RlKHByb3BzID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHJlZixcbiAgICBjb250YWluZXI6IGNvbnRhaW5lclByb3AsXG4gICAgY29tcG9uZW50UHJvcHMgPSBFTVBUWV9PQkpFQ1QsXG4gICAgZWxlbWVudFByb3BzXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgdW5pcXVlSWQgPSB1c2VJZCgpO1xuICBjb25zdCBwb3J0YWxDb250ZXh0ID0gdXNlUG9ydGFsQ29udGV4dCgpO1xuICBjb25zdCBwYXJlbnRQb3J0YWxOb2RlID0gcG9ydGFsQ29udGV4dD8ucG9ydGFsTm9kZTtcbiAgY29uc3QgW2NvbnRhaW5lckVsZW1lbnQsIHNldENvbnRhaW5lckVsZW1lbnRdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtwb3J0YWxOb2RlLCBzZXRQb3J0YWxOb2RlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBzZXRQb3J0YWxOb2RlUmVmID0gdXNlU3RhYmxlQ2FsbGJhY2sobm9kZSA9PiB7XG4gICAgaWYgKG5vZGUgIT09IG51bGwpIHtcbiAgICAgIC8vIHRoZSB1c2VJc29MYXlvdXRFZmZlY3QgYmVsb3cgd2F0Y2hpbmcgY29udGFpbmVyUHJvcCAvIHBhcmVudFBvcnRhbE5vZGVcbiAgICAgIC8vIHNldHMgc2V0UG9ydGFsTm9kZShudWxsKSB3aGVuIHRoZSBjb250YWluZXIgYmVjb21lcyBudWxsIG9yIGNoYW5nZXMuXG4gICAgICAvLyBTbyBldmVuIHRob3VnaCB0aGUgcmVmIGNhbGxiYWNrIG5vdyBpZ25vcmVzIG51bGwsIHRoZSBwb3J0YWwgbm9kZSBzdGlsbCBnZXRzIGNsZWFyZWQuXG4gICAgICBzZXRQb3J0YWxOb2RlKG5vZGUpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGNvbnRhaW5lclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAvLyBXYWl0IGZvciB0aGUgY29udGFpbmVyIHRvIGJlIHJlc29sdmVkIGlmIGV4cGxpY2l0bHkgYG51bGxgLlxuICAgIGlmIChjb250YWluZXJQcm9wID09PSBudWxsKSB7XG4gICAgICBpZiAoY29udGFpbmVyUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29udGFpbmVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBzZXRQb3J0YWxOb2RlKG51bGwpO1xuICAgICAgICBzZXRDb250YWluZXJFbGVtZW50KG51bGwpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCByZXNvbHZlZENvbnRhaW5lciA9IChjb250YWluZXJQcm9wICYmIChpc05vZGUoY29udGFpbmVyUHJvcCkgPyBjb250YWluZXJQcm9wIDogY29udGFpbmVyUHJvcC5jdXJyZW50KSkgPz8gcGFyZW50UG9ydGFsTm9kZSA/PyBkb2N1bWVudC5ib2R5O1xuICAgIGlmIChyZXNvbHZlZENvbnRhaW5lciA9PSBudWxsKSB7XG4gICAgICBpZiAoY29udGFpbmVyUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29udGFpbmVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBzZXRQb3J0YWxOb2RlKG51bGwpO1xuICAgICAgICBzZXRDb250YWluZXJFbGVtZW50KG51bGwpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY29udGFpbmVyUmVmLmN1cnJlbnQgIT09IHJlc29sdmVkQ29udGFpbmVyKSB7XG4gICAgICBjb250YWluZXJSZWYuY3VycmVudCA9IHJlc29sdmVkQ29udGFpbmVyO1xuICAgICAgc2V0UG9ydGFsTm9kZShudWxsKTtcbiAgICAgIHNldENvbnRhaW5lckVsZW1lbnQocmVzb2x2ZWRDb250YWluZXIpO1xuICAgIH1cbiAgfSwgW2NvbnRhaW5lclByb3AsIHBhcmVudFBvcnRhbE5vZGVdKTtcbiAgY29uc3QgcG9ydGFsRWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbcmVmLCBzZXRQb3J0YWxOb2RlUmVmXSxcbiAgICBwcm9wczogW3tcbiAgICAgIGlkOiB1bmlxdWVJZCxcbiAgICAgIFthdHRyXTogJydcbiAgICB9LCBlbGVtZW50UHJvcHNdXG4gIH0pO1xuXG4gIC8vIFRoaXMgYGNyZWF0ZVBvcnRhbGAgY2FsbCBpbmplY3RzIGBwb3J0YWxFbGVtZW50YCBpbnRvIHRoZSBgY29udGFpbmVyYC5cbiAgLy8gQW5vdGhlciBjYWxsIGluc2lkZSBgRmxvYXRpbmdQb3J0YWxgL2BGbG9hdGluZ1BvcnRhbExpdGVgIHRoZW4gaW5qZWN0cyB0aGUgY2hpbGRyZW4gaW50byBgcG9ydGFsRWxlbWVudGAuXG4gIGNvbnN0IHBvcnRhbFN1YnRyZWUgPSBjb250YWluZXJFbGVtZW50ICYmIHBvcnRhbEVsZW1lbnQgPyAvKiNfX1BVUkVfXyovUmVhY3RET00uY3JlYXRlUG9ydGFsKHBvcnRhbEVsZW1lbnQsIGNvbnRhaW5lckVsZW1lbnQpIDogbnVsbDtcbiAgcmV0dXJuIHtcbiAgICBub2RlOiBwb3J0YWxOb2RlLFxuICAgIC8vIGBpZGAgYW5kIGByZW5kZXJgIHByb3BzIGNhbiBvdmVycmlkZSBvciByZW1vdmUgdGhlIGdlbmVyYXRlZCBJRC4gVXNlIHRoZSBleGFjdFxuICAgIC8vIHJlbmRlcmVkIHZhbHVlIHNvIGBhcmlhLW93bnNgIG5ldmVyIHBvaW50cyBhdCBhbiBJRCBhYnNlbnQgZnJvbSB0aGUgRE9NLlxuICAgIG5vZGVJZDogLyojX19QVVJFX18qL1JlYWN0LmlzVmFsaWRFbGVtZW50KHBvcnRhbEVsZW1lbnQpID8gcG9ydGFsRWxlbWVudC5wcm9wcy5pZCA6IHVuZGVmaW5lZCxcbiAgICBzdWJ0cmVlOiBwb3J0YWxTdWJ0cmVlXG4gIH07XG59XG5cbi8qKlxuICogUG9ydGFscyB0aGUgZmxvYXRpbmcgZWxlbWVudCBpbnRvIGEgZ2l2ZW4gY29udGFpbmVyIGVsZW1lbnQg4oCUIGJ5IGRlZmF1bHQsXG4gKiBvdXRzaWRlIG9mIHRoZSBhcHAgcm9vdCBhbmQgaW50byB0aGUgYm9keS5cbiAqIFRoaXMgaXMgbmVjZXNzYXJ5IHRvIGVuc3VyZSB0aGUgZmxvYXRpbmcgZWxlbWVudCBjYW4gYXBwZWFyIG91dHNpZGUgYW55XG4gKiBwb3RlbnRpYWwgcGFyZW50IGNvbnRhaW5lcnMgdGhhdCBjYXVzZSBjbGlwcGluZyAoc3VjaCBhcyBgb3ZlcmZsb3c6IGhpZGRlbmApLFxuICogd2hpbGUgcmV0YWluaW5nIGl0cyBsb2NhdGlvbiBpbiB0aGUgUmVhY3QgdHJlZS5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ1BvcnRhbFxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjb25zdCBGbG9hdGluZ1BvcnRhbCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZsb2F0aW5nUG9ydGFsKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgY2hpbGRyZW4sXG4gICAgY29udGFpbmVyLFxuICAgIHBvcnRhbE93bmVyUm9sZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCB7XG4gICAgbm9kZTogcG9ydGFsTm9kZSxcbiAgICBub2RlSWQ6IHBvcnRhbE5vZGVJZCxcbiAgICBzdWJ0cmVlOiBwb3J0YWxTdWJ0cmVlXG4gIH0gPSB1c2VGbG9hdGluZ1BvcnRhbE5vZGUoe1xuICAgIGNvbnRhaW5lcixcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBjb21wb25lbnRQcm9wcyxcbiAgICBlbGVtZW50UHJvcHNcbiAgfSk7XG4gIGNvbnN0IGJlZm9yZU91dHNpZGVSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGFmdGVyT3V0c2lkZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgYmVmb3JlSW5zaWRlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBhZnRlckluc2lkZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgW2ZvY3VzTWFuYWdlclN0YXRlLCBzZXRGb2N1c01hbmFnZXJTdGF0ZV0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgZm9jdXNJbnNpZGVEaXNhYmxlZFJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IG1vZGFsID0gZm9jdXNNYW5hZ2VyU3RhdGU/Lm1vZGFsO1xuICBjb25zdCBvcGVuID0gZm9jdXNNYW5hZ2VyU3RhdGU/Lm9wZW47XG4gIGNvbnN0IHNob3VsZFJlbmRlckd1YXJkcyA9ICEhZm9jdXNNYW5hZ2VyU3RhdGUgJiYgIWZvY3VzTWFuYWdlclN0YXRlLm1vZGFsICYmIGZvY3VzTWFuYWdlclN0YXRlLm9wZW4gJiYgISFwb3J0YWxOb2RlO1xuXG4gIC8vIGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy90YWJiYWJsZS1wb3J0YWwtZjR0bmc/ZmlsZT0vc3JjL1RhYmJhYmxlUG9ydGFsLnRzeFxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcG9ydGFsTm9kZSB8fCBtb2RhbCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICAvLyBNYWtlIHN1cmUgZWxlbWVudHMgaW5zaWRlIHRoZSBwb3J0YWwgZWxlbWVudCBhcmUgdGFiYmFibGUgb25seSB3aGVuIHRoZVxuICAgIC8vIHBvcnRhbCBoYXMgYWxyZWFkeSBiZWVuIGZvY3VzZWQsIGVpdGhlciBieSB0YWJiaW5nIGludG8gYSBmb2N1cyB0cmFwXG4gICAgLy8gZWxlbWVudCBvdXRzaWRlIG9yIHVzaW5nIHRoZSBtb3VzZS5cbiAgICBmdW5jdGlvbiBvbkZvY3VzKGV2ZW50KSB7XG4gICAgICBpZiAocG9ydGFsTm9kZSAmJiBldmVudC5yZWxhdGVkVGFyZ2V0ICYmIGlzT3V0c2lkZUV2ZW50KGV2ZW50KSkge1xuICAgICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ2ZvY3VzaW4nKSB7XG4gICAgICAgICAgaWYgKGZvY3VzSW5zaWRlRGlzYWJsZWRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgZW5hYmxlRm9jdXNJbnNpZGUocG9ydGFsTm9kZSk7XG4gICAgICAgICAgICBmb2N1c0luc2lkZURpc2FibGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGlzYWJsZUZvY3VzSW5zaWRlKHBvcnRhbE5vZGUpO1xuICAgICAgICAgIGZvY3VzSW5zaWRlRGlzYWJsZWRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBMaXN0ZW4gdG8gdGhlIGV2ZW50IG9uIHRoZSBjYXB0dXJlIHBoYXNlIHNvIHRoZXkgcnVuIGJlZm9yZSB0aGUgZm9jdXNcbiAgICAvLyB0cmFwIGVsZW1lbnRzIG9uRm9jdXMgcHJvcCBpcyBjYWxsZWQuXG4gICAgcmV0dXJuIG1lcmdlQ2xlYW51cHMoYWRkRXZlbnRMaXN0ZW5lcihwb3J0YWxOb2RlLCAnZm9jdXNpbicsIG9uRm9jdXMsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKHBvcnRhbE5vZGUsICdmb2N1c291dCcsIG9uRm9jdXMsIHRydWUpKTtcbiAgfSwgW3BvcnRhbE5vZGUsIG1vZGFsXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwb3J0YWxOb2RlIHx8IG9wZW4gIT09IHRydWUgfHwgIWZvY3VzSW5zaWRlRGlzYWJsZWRSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFJlc3RvcmUgdGFiYmFiaWxpdHkgYmVmb3JlIHRoZSBmb2N1cyBtYW5hZ2VyJ3MgcXVldWVkIGZvY3VzLW9uLW9wZW4gc3RlcCBydW5zLlxuICAgIGVuYWJsZUZvY3VzSW5zaWRlKHBvcnRhbE5vZGUpO1xuICAgIGZvY3VzSW5zaWRlRGlzYWJsZWRSZWYuY3VycmVudCA9IGZhbHNlO1xuICB9LCBbb3BlbiwgcG9ydGFsTm9kZV0pO1xuICBjb25zdCBwb3J0YWxDb250ZXh0VmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgYmVmb3JlT3V0c2lkZVJlZixcbiAgICBhZnRlck91dHNpZGVSZWYsXG4gICAgYmVmb3JlSW5zaWRlUmVmLFxuICAgIGFmdGVySW5zaWRlUmVmLFxuICAgIHBvcnRhbE5vZGUsXG4gICAgc2V0Rm9jdXNNYW5hZ2VyU3RhdGVcbiAgfSksIFtwb3J0YWxOb2RlXSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeHMoUmVhY3QuRnJhZ21lbnQsIHtcbiAgICBjaGlsZHJlbjogW3BvcnRhbFN1YnRyZWUsIC8qI19fUFVSRV9fKi9fanN4cyhQb3J0YWxDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgICB2YWx1ZTogcG9ydGFsQ29udGV4dFZhbHVlLFxuICAgICAgY2hpbGRyZW46IFtzaG91bGRSZW5kZXJHdWFyZHMgJiYgcG9ydGFsTm9kZSAmJiAvKiNfX1BVUkVfXyovX2pzeChGb2N1c0d1YXJkLCB7XG4gICAgICAgIFwiZGF0YS10eXBlXCI6IFwib3V0c2lkZVwiLFxuICAgICAgICByZWY6IGJlZm9yZU91dHNpZGVSZWYsXG4gICAgICAgIG9uRm9jdXM6IGV2ZW50ID0+IHtcbiAgICAgICAgICBpZiAoaXNPdXRzaWRlRXZlbnQoZXZlbnQsIHBvcnRhbE5vZGUpKSB7XG4gICAgICAgICAgICBiZWZvcmVJbnNpZGVSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZG9tUmVmZXJlbmNlID0gZm9jdXNNYW5hZ2VyU3RhdGUgPyBmb2N1c01hbmFnZXJTdGF0ZS5kb21SZWZlcmVuY2UgOiBudWxsO1xuICAgICAgICAgICAgY29uc3QgcHJldlRhYmJhYmxlID0gZ2V0UHJldmlvdXNUYWJiYWJsZShkb21SZWZlcmVuY2UpO1xuICAgICAgICAgICAgcHJldlRhYmJhYmxlPy5mb2N1cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSksIHNob3VsZFJlbmRlckd1YXJkcyAmJiBwb3J0YWxOb2RlICYmIC8qI19fUFVSRV9fKi9fanN4KFwic3BhblwiLCB7XG4gICAgICAgIHJvbGU6IHBvcnRhbE93bmVyUm9sZSxcbiAgICAgICAgXCJhcmlhLW93bnNcIjogcG9ydGFsTm9kZUlkLFxuICAgICAgICBzdHlsZTogb3duZXJWaXN1YWxseUhpZGRlblxuICAgICAgfSksIHBvcnRhbE5vZGUgJiYgLyojX19QVVJFX18qL1JlYWN0RE9NLmNyZWF0ZVBvcnRhbChjaGlsZHJlbiwgcG9ydGFsTm9kZSksIHNob3VsZFJlbmRlckd1YXJkcyAmJiBwb3J0YWxOb2RlICYmIC8qI19fUFVSRV9fKi9fanN4KEZvY3VzR3VhcmQsIHtcbiAgICAgICAgXCJkYXRhLXR5cGVcIjogXCJvdXRzaWRlXCIsXG4gICAgICAgIHJlZjogYWZ0ZXJPdXRzaWRlUmVmLFxuICAgICAgICBvbkZvY3VzOiBldmVudCA9PiB7XG4gICAgICAgICAgaWYgKGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3J0YWxOb2RlKSkge1xuICAgICAgICAgICAgYWZ0ZXJJbnNpZGVSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZG9tUmVmZXJlbmNlID0gZm9jdXNNYW5hZ2VyU3RhdGUgPyBmb2N1c01hbmFnZXJTdGF0ZS5kb21SZWZlcmVuY2UgOiBudWxsO1xuICAgICAgICAgICAgY29uc3QgbmV4dFRhYmJhYmxlID0gZ2V0TmV4dFRhYmJhYmxlKGRvbVJlZmVyZW5jZSk7XG4gICAgICAgICAgICBuZXh0VGFiYmFibGU/LmZvY3VzKCk7XG4gICAgICAgICAgICBpZiAoZm9jdXNNYW5hZ2VyU3RhdGU/LmNsb3NlT25Gb2N1c091dCkge1xuICAgICAgICAgICAgICBmb2N1c01hbmFnZXJTdGF0ZT8ub25PcGVuQ2hhbmdlKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5mb2N1c091dCwgZXZlbnQubmF0aXZlRXZlbnQpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pXVxuICAgIH0pXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmxvYXRpbmdQb3J0YWwuZGlzcGxheU5hbWUgPSBcIkZsb2F0aW5nUG9ydGFsXCI7IiwiZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUV2ZW50RW1pdHRlcigpIHtcbiAgY29uc3QgbWFwID0gbmV3IE1hcCgpO1xuICByZXR1cm4ge1xuICAgIGVtaXQoZXZlbnQsIGRhdGEpIHtcbiAgICAgIG1hcC5nZXQoZXZlbnQpPy5mb3JFYWNoKGxpc3RlbmVyID0+IGxpc3RlbmVyKGRhdGEpKTtcbiAgICB9LFxuICAgIG9uKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgICAgaWYgKCFtYXAuaGFzKGV2ZW50KSkge1xuICAgICAgICBtYXAuc2V0KGV2ZW50LCBuZXcgU2V0KCkpO1xuICAgICAgfVxuICAgICAgbWFwLmdldChldmVudCkuYWRkKGxpc3RlbmVyKTtcbiAgICB9LFxuICAgIG9mZihldmVudCwgbGlzdGVuZXIpIHtcbiAgICAgIG1hcC5nZXQoZXZlbnQpPy5kZWxldGUobGlzdGVuZXIpO1xuICAgIH1cbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSWQnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlUmVmV2l0aEluaXQnO1xuaW1wb3J0IHsgRmxvYXRpbmdUcmVlU3RvcmUgfSBmcm9tIFwiLi9GbG9hdGluZ1RyZWVTdG9yZS5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBGbG9hdGluZ05vZGVDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGbG9hdGluZ05vZGVDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJGbG9hdGluZ05vZGVDb250ZXh0XCI7XG5jb25zdCBGbG9hdGluZ1RyZWVDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5cbi8qKlxuICogUmV0dXJucyB0aGUgcGFyZW50IG5vZGUgaWQgZm9yIG5lc3RlZCBmbG9hdGluZyBlbGVtZW50cywgaWYgYXZhaWxhYmxlLlxuICogUmV0dXJucyBgbnVsbGAgZm9yIHRvcC1sZXZlbCBmbG9hdGluZyBlbGVtZW50cy5cbiAqL1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmxvYXRpbmdUcmVlQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRmxvYXRpbmdUcmVlQ29udGV4dFwiO1xuZXhwb3J0IGNvbnN0IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChGbG9hdGluZ05vZGVDb250ZXh0KT8uaWQgfHwgbnVsbDtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBuZWFyZXN0IGZsb2F0aW5nIHRyZWUgY29udGV4dCwgaWYgYXZhaWxhYmxlLlxuICovXG5leHBvcnQgY29uc3QgdXNlRmxvYXRpbmdUcmVlID0gZXh0ZXJuYWxUcmVlID0+IHtcbiAgY29uc3QgY29udGV4dFRyZWUgPSBSZWFjdC51c2VDb250ZXh0KEZsb2F0aW5nVHJlZUNvbnRleHQpO1xuICByZXR1cm4gZXh0ZXJuYWxUcmVlID8/IGNvbnRleHRUcmVlO1xufTtcblxuLyoqXG4gKiBSZWdpc3RlcnMgYSBub2RlIGludG8gdGhlIGBGbG9hdGluZ1RyZWVgLCByZXR1cm5pbmcgaXRzIGlkLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nVHJlZVxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRmxvYXRpbmdOb2RlSWQoZXh0ZXJuYWxUcmVlKSB7XG4gIGNvbnN0IGlkID0gdXNlSWQoKTtcbiAgY29uc3QgdHJlZSA9IHVzZUZsb2F0aW5nVHJlZShleHRlcm5hbFRyZWUpO1xuICBjb25zdCBwYXJlbnRJZCA9IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkKCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFpZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3Qgbm9kZSA9IHtcbiAgICAgIGlkLFxuICAgICAgcGFyZW50SWRcbiAgICB9O1xuICAgIHRyZWU/LmFkZE5vZGUobm9kZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRyZWU/LnJlbW92ZU5vZGUobm9kZSk7XG4gICAgfTtcbiAgfSwgW3RyZWUsIGlkLCBwYXJlbnRJZF0pO1xuICByZXR1cm4gaWQ7XG59XG4vKipcbiAqIFByb3ZpZGVzIHBhcmVudCBub2RlIGNvbnRleHQgZm9yIG5lc3RlZCBmbG9hdGluZyBlbGVtZW50cy5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ1RyZWVcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gRmxvYXRpbmdOb2RlKHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbixcbiAgICBpZFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHBhcmVudElkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nTm9kZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgaWQsXG4gICAgICBwYXJlbnRJZFxuICAgIH0pLCBbaWQsIHBhcmVudElkXSksXG4gICAgY2hpbGRyZW46IGNoaWxkcmVuXG4gIH0pO1xufVxuLyoqXG4gKiBQcm92aWRlcyBjb250ZXh0IGZvciBuZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMgd2hlbiB0aGV5IGFyZSBub3QgY2hpbGRyZW4gb2ZcbiAqIGVhY2ggb3RoZXIgb24gdGhlIERPTS5cbiAqIFRoaXMgaXMgbm90IG5lY2Vzc2FyeSBpbiBhbGwgY2FzZXMsIGV4Y2VwdCB3aGVuIHRoZXJlIG11c3QgYmUgZXhwbGljaXQgY29tbXVuaWNhdGlvbiBiZXR3ZWVuIHBhcmVudCBhbmQgY2hpbGQgZmxvYXRpbmcgZWxlbWVudHMuIEl0IGlzIG5lY2Vzc2FyeSBmb3I6XG4gKiAtIFRoZSBgYnViYmxlc2Agb3B0aW9uIGluIHRoZSBgdXNlRGlzbWlzcygpYCBIb29rXG4gKiAtIE5lc3RlZCB2aXJ0dWFsIGxpc3QgbmF2aWdhdGlvblxuICogLSBOZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMgdGhhdCBlYWNoIG9wZW4gb24gaG92ZXJcbiAqIC0gQ3VzdG9tIGNvbW11bmljYXRpb24gYmV0d2VlbiBwYXJlbnQgYW5kIGNoaWxkIGZsb2F0aW5nIGVsZW1lbnRzXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdUcmVlXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZsb2F0aW5nVHJlZShwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgZXh0ZXJuYWxUcmVlXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgdHJlZSA9IHVzZVJlZldpdGhJbml0KCgpID0+IGV4dGVybmFsVHJlZSA/PyBuZXcgRmxvYXRpbmdUcmVlU3RvcmUoKSkuY3VycmVudDtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nVHJlZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdHJlZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW5cbiAgfSk7XG59IiwiLyoqXG4gKiBJZiB0aGUgcHJvdmlkZWQgYXJndW1lbnQgaXMgYSByZWYgb2JqZWN0LCByZXR1cm5zIGl0cyBgY3VycmVudGAgdmFsdWUuXG4gKiBPdGhlcndpc2UsIHJldHVybnMgdGhlIGFyZ3VtZW50IGl0c2VsZi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVSZWYobWF5YmVSZWYpIHtcbiAgaWYgKG1heWJlUmVmID09IG51bGwpIHtcbiAgICByZXR1cm4gbWF5YmVSZWY7XG4gIH1cbiAgcmV0dXJuICdjdXJyZW50JyBpbiBtYXliZVJlZiA/IG1heWJlUmVmLmN1cnJlbnQgOiBtYXliZVJlZjtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGdldE5vZGVOYW1lLCBpc0hUTUxFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyBtZXJnZUNsZWFudXBzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvbWVyZ2VDbGVhbnVwcyc7XG5pbXBvcnQgeyB1c2VNZXJnZWRSZWZzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlTWVyZ2VkUmVmcyc7XG5pbXBvcnQgeyB1c2VWYWx1ZUFzUmVmIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVmFsdWVBc1JlZic7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VUaW1lb3V0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVGltZW91dCc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IHVzZUFuaW1hdGlvbkZyYW1lIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlQW5pbWF0aW9uRnJhbWUnO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCwgb3duZXJXaW5kb3cgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyBGb2N1c0d1YXJkIH0gZnJvbSBcIi4uLy4uL3V0aWxzL0ZvY3VzR3VhcmQubWpzXCI7XG5pbXBvcnQgeyBhY3RpdmVFbGVtZW50LCBjbG9zZXN0LCBjb250YWlucywgZ2V0VGFyZ2V0LCBpc1R5cGVhYmxlQ29tYm9ib3gsIGdldEZsb2F0aW5nRm9jdXNFbGVtZW50LCBpc1R5cGVhYmxlRWxlbWVudCB9IGZyb20gXCIuLi91dGlscy9lbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgaXNWaXJ0dWFsQ2xpY2ssIGlzVmlydHVhbFBvaW50ZXJFdmVudCwgc3RvcEV2ZW50IH0gZnJvbSBcIi4uL3V0aWxzL2V2ZW50Lm1qc1wiO1xuaW1wb3J0IHsgdGFiYmFibGUsIGZvY3VzYWJsZSwgaXNPdXRzaWRlRXZlbnQsIGlzVGFiYmFibGUsIGdldE5leHRUYWJiYWJsZSwgZ2V0UHJldmlvdXNUYWJiYWJsZSB9IGZyb20gXCIuLi91dGlscy90YWJiYWJsZS5tanNcIjtcbmltcG9ydCB7IGdldE5vZGVBbmNlc3RvcnMsIGdldE5vZGVDaGlsZHJlbiB9IGZyb20gXCIuLi91dGlscy9ub2Rlcy5tanNcIjtcbmltcG9ydCB7IGlzRWxlbWVudFZpc2libGUgfSBmcm9tIFwiLi4vdXRpbHMvY29tcG9zaXRlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQXR0cmlidXRlIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUF0dHJpYnV0ZS5tanNcIjtcbmltcG9ydCB7IGVucXVldWVGb2N1cyB9IGZyb20gXCIuLi91dGlscy9lbnF1ZXVlRm9jdXMubWpzXCI7XG5pbXBvcnQgeyBtYXJrT3RoZXJzIH0gZnJvbSBcIi4uL3V0aWxzL21hcmtPdGhlcnMubWpzXCI7XG5pbXBvcnQgeyB1c2VQb3J0YWxDb250ZXh0IH0gZnJvbSBcIi4vRmxvYXRpbmdQb3J0YWwubWpzXCI7XG5pbXBvcnQgeyB1c2VGbG9hdGluZ1RyZWUgfSBmcm9tIFwiLi9GbG9hdGluZ1RyZWUubWpzXCI7XG5pbXBvcnQgeyBDTElDS19UUklHR0VSX0lERU5USUZJRVIgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IHJlc29sdmVSZWYgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcmVzb2x2ZVJlZi5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5mdW5jdGlvbiBnZXRFdmVudFR5cGUoZXZlbnQsIGxhc3RJbnRlcmFjdGlvblR5cGUpIHtcbiAgY29uc3Qgd2luID0gb3duZXJXaW5kb3coZ2V0VGFyZ2V0KGV2ZW50KSk7XG4gIGlmIChldmVudCBpbnN0YW5jZW9mIHdpbi5LZXlib2FyZEV2ZW50KSB7XG4gICAgcmV0dXJuICdrZXlib2FyZCc7XG4gIH1cbiAgaWYgKGV2ZW50IGluc3RhbmNlb2Ygd2luLkZvY3VzRXZlbnQpIHtcbiAgICAvLyBGb2N1cyBldmVudHMgY2FuIGJlIGNhdXNlZCBieSBhIHByZWNlZGluZyBwb2ludGVyIGludGVyYWN0aW9uIChlLmcuLCBmb2N1c291dCBvbiBvdXRzaWRlIHByZXNzKS5cbiAgICAvLyBQcmVmZXIgdGhlIGxhc3Qga25vd24gcG9pbnRlciB0eXBlIGlmIHByb3ZpZGVkLCBlbHNlIHRyZWF0IGFzIGtleWJvYXJkLlxuICAgIHJldHVybiBsYXN0SW50ZXJhY3Rpb25UeXBlIHx8ICdrZXlib2FyZCc7XG4gIH1cbiAgaWYgKCdwb2ludGVyVHlwZScgaW4gZXZlbnQpIHtcbiAgICAvLyBBIHRydXN0ZWQgY2xpY2sgd2l0aG91dCBhIHBvaW50ZXJUeXBlIGlzIGtleWJvYXJkL0FUOyBvbmx5IHN5bnRoZXNpemVkXG4gICAgLy8gY2xpY2tzIChlLmcuIGEgdGVzdCBoYXJuZXNzKSBwYWlyIGFuIGVtcHR5IHBvaW50ZXJUeXBlIHdpdGggYSBjbGljayBjb3VudC5cbiAgICByZXR1cm4gZXZlbnQucG9pbnRlclR5cGUgfHwgKGlzVmlydHVhbENsaWNrKGV2ZW50KSA/ICdrZXlib2FyZCcgOiBsYXN0SW50ZXJhY3Rpb25UeXBlIHx8ICdtb3VzZScpO1xuICB9XG4gIGlmICgndG91Y2hlcycgaW4gZXZlbnQpIHtcbiAgICByZXR1cm4gJ3RvdWNoJztcbiAgfVxuICBpZiAoZXZlbnQgaW5zdGFuY2VvZiB3aW4uTW91c2VFdmVudCkge1xuICAgIC8vIG9uQ2xpY2sgZXZlbnRzIG1heSBub3QgY29udGFpbiBwb2ludGVyIGV2ZW50cywgYW5kIHdpbGwgZmFsbCB0aHJvdWdoIHRvIGhlcmVcbiAgICByZXR1cm4gbGFzdEludGVyYWN0aW9uVHlwZSB8fCAoZXZlbnQuZGV0YWlsID09PSAwID8gJ2tleWJvYXJkJyA6ICdtb3VzZScpO1xuICB9XG4gIHJldHVybiAnJztcbn1cbmNvbnN0IExJU1RfTElNSVQgPSAyMDtcbmxldCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzID0gW107XG5mdW5jdGlvbiBjbGVhckRpc2Nvbm5lY3RlZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMoKSB7XG4gIHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMgPSBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLmZpbHRlcihlbnRyeSA9PiB7XG4gICAgcmV0dXJuIGVudHJ5LmRlcmVmKCk/LmlzQ29ubmVjdGVkO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGFkZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudChlbGVtZW50KSB7XG4gIGNsZWFyRGlzY29ubmVjdGVkUHJldmlvdXNseUZvY3VzZWRFbGVtZW50cygpO1xuICBpZiAoZWxlbWVudCAmJiBnZXROb2RlTmFtZShlbGVtZW50KSAhPT0gJ2JvZHknKSB7XG4gICAgcHJldmlvdXNseUZvY3VzZWRFbGVtZW50cy5wdXNoKG5ldyBXZWFrUmVmKGVsZW1lbnQpKTtcbiAgICBpZiAocHJldmlvdXNseUZvY3VzZWRFbGVtZW50cy5sZW5ndGggPiBMSVNUX0xJTUlUKSB7XG4gICAgICBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzID0gcHJldmlvdXNseUZvY3VzZWRFbGVtZW50cy5zbGljZSgtTElTVF9MSU1JVCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBnZXRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQoKSB7XG4gIGNsZWFyRGlzY29ubmVjdGVkUHJldmlvdXNseUZvY3VzZWRFbGVtZW50cygpO1xuICByZXR1cm4gcHJldmlvdXNseUZvY3VzZWRFbGVtZW50c1twcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLmxlbmd0aCAtIDFdPy5kZXJlZigpO1xufVxuZnVuY3Rpb24gZ2V0Rmlyc3RUYWJiYWJsZUVsZW1lbnQoY29udGFpbmVyKSB7XG4gIGlmICghY29udGFpbmVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKGlzVGFiYmFibGUoY29udGFpbmVyKSkge1xuICAgIHJldHVybiBjb250YWluZXI7XG4gIH1cbiAgcmV0dXJuIHRhYmJhYmxlKGNvbnRhaW5lcilbMF0gfHwgY29udGFpbmVyO1xufVxuZnVuY3Rpb24gaGFuZGxlVGFiSW5kZXgoZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHtcbiAgaWYgKGZsb2F0aW5nRm9jdXNFbGVtZW50Lmhhc0F0dHJpYnV0ZSgndGFiaW5kZXgnKSAmJiAhZmxvYXRpbmdGb2N1c0VsZW1lbnQuaGFzQXR0cmlidXRlKCdkYXRhLXRhYmluZGV4JykpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCFmbG9hdGluZ0ZvY3VzRWxlbWVudC5nZXRBdHRyaWJ1dGUoJ3JvbGUnKT8uaW5jbHVkZXMoJ2RpYWxvZycpKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGZvY3VzYWJsZUVsZW1lbnRzID0gZm9jdXNhYmxlKGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgY29uc3QgdGFiYmFibGVDb250ZW50ID0gZm9jdXNhYmxlRWxlbWVudHMuZmlsdGVyKGVsZW1lbnQgPT4ge1xuICAgIGNvbnN0IGRhdGFUYWJJbmRleCA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKCdkYXRhLXRhYmluZGV4JykgfHwgJyc7XG4gICAgcmV0dXJuIGlzVGFiYmFibGUoZWxlbWVudCkgfHwgZWxlbWVudC5oYXNBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnKSAmJiAhZGF0YVRhYkluZGV4LnN0YXJ0c1dpdGgoJy0nKTtcbiAgfSk7XG4gIGNvbnN0IHRhYkluZGV4ID0gZmxvYXRpbmdGb2N1c0VsZW1lbnQuZ2V0QXR0cmlidXRlKCd0YWJpbmRleCcpO1xuICBpZiAodGFiYmFibGVDb250ZW50Lmxlbmd0aCA9PT0gMCkge1xuICAgIGlmICh0YWJJbmRleCAhPT0gJzAnKSB7XG4gICAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudC5zZXRBdHRyaWJ1dGUoJ3RhYmluZGV4JywgJzAnKTtcbiAgICAgIC8vIE1hcmsgb3VyIG93biB3cml0ZSBzbyB0aGUgZXh0ZXJuYWxseS1tYW5hZ2VkIGVhcmx5LXJldHVybiBhYm92ZSBkb2Vzbid0XG4gICAgICAvLyBtaXN0YWtlIGl0IGZvciBhIHVzZXItYXV0aG9yZWQgYHRhYmluZGV4YCBhbmQgZnJlZXplIG1hbmFnZW1lbnQuXG4gICAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnLCAnMCcpO1xuICAgIH1cbiAgfSBlbHNlIGlmICh0YWJJbmRleCAhPT0gJy0xJyB8fCBmbG9hdGluZ0ZvY3VzRWxlbWVudC5oYXNBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnKSAmJiBmbG9hdGluZ0ZvY3VzRWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnKSAhPT0gJy0xJykge1xuICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LnNldEF0dHJpYnV0ZSgndGFiaW5kZXgnLCAnLTEnKTtcbiAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnLCAnLTEnKTtcbiAgfVxufVxuLyoqXG4gKiBQcm92aWRlcyBmb2N1cyBtYW5hZ2VtZW50IGZvciB0aGUgZmxvYXRpbmcgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ0ZvY3VzTWFuYWdlclxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBGbG9hdGluZ0ZvY3VzTWFuYWdlcihwcm9wcykge1xuICBjb25zdCB7XG4gICAgY29udGV4dDogc3RvcmUsXG4gICAgY2hpbGRyZW4sXG4gICAgZGlzYWJsZWQgPSBmYWxzZSxcbiAgICBpbml0aWFsRm9jdXMgPSB0cnVlLFxuICAgIHJldHVybkZvY3VzID0gdHJ1ZSxcbiAgICBleHBsaWNpdFJldHVybkZvY3VzLFxuICAgIHJlc3RvcmVGb2N1cyA9IGZhbHNlLFxuICAgIG1vZGFsID0gdHJ1ZSxcbiAgICBjbG9zZU9uRm9jdXNPdXQgPSB0cnVlLFxuICAgIG9wZW5JbnRlcmFjdGlvblR5cGUgPSAnJyxcbiAgICBuZXh0Rm9jdXNhYmxlRWxlbWVudCxcbiAgICBwcmV2aW91c0ZvY3VzYWJsZUVsZW1lbnQsXG4gICAgYmVmb3JlQ29udGVudEZvY3VzR3VhcmRSZWYsXG4gICAgZXh0ZXJuYWxUcmVlLFxuICAgIGdldEluc2lkZUVsZW1lbnRzXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IGRvbVJlZmVyZW5jZSA9IHN0b3JlLnVzZVN0YXRlKCdkb21SZWZlcmVuY2VFbGVtZW50Jyk7XG4gIGNvbnN0IGZsb2F0aW5nID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nRWxlbWVudCcpO1xuICBjb25zdCB7XG4gICAgZXZlbnRzLFxuICAgIGRhdGFSZWZcbiAgfSA9IHN0b3JlLmNvbnRleHQ7XG4gIGNvbnN0IGdldE5vZGVJZCA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IGRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQ/Lm5vZGVJZCk7XG4gIGNvbnN0IGlnbm9yZUluaXRpYWxGb2N1cyA9IGluaXRpYWxGb2N1cyA9PT0gZmFsc2U7XG4gIC8vIEEgdHlwZWFibGUgY29tYm9ib3ggcmVmZXJlbmNlIChlLmcuIGlucHV0L3RleHRhcmVhKSB3aXRoIGBpbml0aWFsRm9jdXM9e2ZhbHNlfWBcbiAgLy8gaGFzIGRpZmZlcmVudCBmb2N1cyBzZW1hbnRpY3M6IGZvY3VzIGlzIG5vdCB0cmFwcGVkIGluc2lkZSB0aGUgZmxvYXRpbmcgZWxlbWVudCxcbiAgLy8gc28gaW4gdGhlIG1vZGFsIGNhc2UgdGhlIGd1YXJkcyBhcmUgbm90IHJlbmRlcmVkLCBidXQgYGFyaWEtaGlkZGVuYCBpcyBzdGlsbFxuICAvLyBhcHBsaWVkIHRvIHRoZSBvdXRzaWRlIG5vZGVzLlxuICBjb25zdCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3ggPSBpc1R5cGVhYmxlQ29tYm9ib3goZG9tUmVmZXJlbmNlKSAmJiBpZ25vcmVJbml0aWFsRm9jdXM7XG4gIGNvbnN0IGluaXRpYWxGb2N1c1JlZiA9IHVzZVZhbHVlQXNSZWYoaW5pdGlhbEZvY3VzKTtcbiAgY29uc3QgcmV0dXJuRm9jdXNSZWYgPSB1c2VWYWx1ZUFzUmVmKHJldHVybkZvY3VzKTtcbiAgLy8gUmVhZCB0aHJvdWdoIGEgcmVmIHNvIGEgbWlkLW9wZW4gY2hhbmdlIGNhbid0IHJlLXJ1biB0aGUgcmV0dXJuLWZvY3VzIGVmZmVjdCwgd2hvc2UgY2xlYW51cFxuICAvLyB3b3VsZCBtb3ZlIGZvY3VzIHdoaWxlIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIHN0aWxsIG9wZW4uXG4gIGNvbnN0IGV4cGxpY2l0UmV0dXJuRm9jdXNSZWYgPSB1c2VWYWx1ZUFzUmVmKGV4cGxpY2l0UmV0dXJuRm9jdXMpO1xuICBjb25zdCBvcGVuSW50ZXJhY3Rpb25UeXBlUmVmID0gdXNlVmFsdWVBc1JlZihvcGVuSW50ZXJhY3Rpb25UeXBlKTtcbiAgY29uc3Qgb3BlblJlZiA9IHVzZVZhbHVlQXNSZWYob3Blbik7XG4gIGNvbnN0IHRyZWUgPSB1c2VGbG9hdGluZ1RyZWUoZXh0ZXJuYWxUcmVlKTtcbiAgY29uc3QgcG9ydGFsQ29udGV4dCA9IHVzZVBvcnRhbENvbnRleHQoKTtcbiAgY29uc3QgcHJldmVudFJldHVybkZvY3VzUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgaXNQb2ludGVyRG93blJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHBvaW50ZXJEb3duT3V0c2lkZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGxhc3RGb2N1c2VkVGFiYmFibGVSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGNsb3NlVHlwZVJlZiA9IFJlYWN0LnVzZVJlZignJyk7XG4gIGNvbnN0IGxhc3RJbnRlcmFjdGlvblR5cGVSZWYgPSBSZWFjdC51c2VSZWYoJycpO1xuICBjb25zdCBiZWZvcmVHdWFyZFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgYWZ0ZXJHdWFyZFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgbWVyZ2VkQmVmb3JlR3VhcmRSZWYgPSB1c2VNZXJnZWRSZWZzKGJlZm9yZUd1YXJkUmVmLCBiZWZvcmVDb250ZW50Rm9jdXNHdWFyZFJlZiwgcG9ydGFsQ29udGV4dD8uYmVmb3JlSW5zaWRlUmVmKTtcbiAgY29uc3QgbWVyZ2VkQWZ0ZXJHdWFyZFJlZiA9IHVzZU1lcmdlZFJlZnMoYWZ0ZXJHdWFyZFJlZiwgcG9ydGFsQ29udGV4dD8uYWZ0ZXJJbnNpZGVSZWYpO1xuICBjb25zdCBibHVyVGltZW91dCA9IHVzZVRpbWVvdXQoKTtcbiAgY29uc3QgcG9pbnRlckRvd25UaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCByZXN0b3JlRm9jdXNGcmFtZSA9IHVzZUFuaW1hdGlvbkZyYW1lKCk7XG4gIGNvbnN0IGlzSW5zaWRlUG9ydGFsID0gcG9ydGFsQ29udGV4dCAhPSBudWxsO1xuICBjb25zdCBmbG9hdGluZ0ZvY3VzRWxlbWVudCA9IGdldEZsb2F0aW5nRm9jdXNFbGVtZW50KGZsb2F0aW5nKTtcbiAgY29uc3QgZ2V0VGFiYmFibGVDb250ZW50ID0gdXNlU3RhYmxlQ2FsbGJhY2soKGNvbnRhaW5lciA9IGZsb2F0aW5nRm9jdXNFbGVtZW50KSA9PiB7XG4gICAgcmV0dXJuIGNvbnRhaW5lciA/IHRhYmJhYmxlKGNvbnRhaW5lcikgOiBbXTtcbiAgfSk7XG4gIGNvbnN0IGdldFJlc29sdmVkSW5zaWRlRWxlbWVudHMgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiBnZXRJbnNpZGVFbGVtZW50cz8uKCkuZmlsdGVyKGVsZW1lbnQgPT4gZWxlbWVudCAhPSBudWxsKSA/PyBbXSk7XG5cbiAgLy8gUHJldmVudCBUYWIgZnJvbSBlc2NhcGluZyB0aGUgbW9kYWwgd2hlbiB0aGVyZSBhcmUgbm8gdGFiYmFibGUgZWxlbWVudHMuXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkIHx8ICFtb2RhbCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZnVuY3Rpb24gb25LZXlEb3duKGV2ZW50KSB7XG4gICAgICBpZiAoZXZlbnQua2V5ID09PSAnVGFiJykge1xuICAgICAgICAvLyBUaGUgZm9jdXMgZ3VhcmRzIGhhdmUgbm90aGluZyB0byBmb2N1cywgc28gd2UgbmVlZCB0byBzdG9wIHRoZSBldmVudC5cbiAgICAgICAgaWYgKGNvbnRhaW5zKGZsb2F0aW5nRm9jdXNFbGVtZW50LCBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpKSkgJiYgZ2V0VGFiYmFibGVDb250ZW50KCkubGVuZ3RoID09PSAwICYmICFpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3gpIHtcbiAgICAgICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIHJldHVybiBhZGRFdmVudExpc3RlbmVyKGRvYywgJ2tleWRvd24nLCBvbktleURvd24pO1xuICB9LCBbZGlzYWJsZWQsIGZsb2F0aW5nRm9jdXNFbGVtZW50LCBtb2RhbCwgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94LCBnZXRUYWJiYWJsZUNvbnRlbnRdKTtcblxuICAvLyBUcmFjayBwb2ludGVyL2tleWJvYXJkIGludGVyYWN0aW9ucyB0byBkaXNhbWJpZ3VhdGUgZm9jdXMgYW5kIG91dHNpZGUgcHJlc3Nlcy5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQgfHwgIW9wZW4pIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIGZ1bmN0aW9uIGNsZWFyUG9pbnRlckRvd25PdXRzaWRlKCkge1xuICAgICAgcG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gb25Qb2ludGVyRG93bihldmVudCkge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGNvbnN0IGluc2lkZUVsZW1lbnRzID0gZ2V0UmVzb2x2ZWRJbnNpZGVFbGVtZW50cygpO1xuICAgICAgY29uc3QgcG9pbnRlclRhcmdldEluc2lkZSA9IGNvbnRhaW5zKGZsb2F0aW5nLCB0YXJnZXQpIHx8IGNvbnRhaW5zKGRvbVJlZmVyZW5jZSwgdGFyZ2V0KSB8fCBjb250YWlucyhwb3J0YWxDb250ZXh0Py5wb3J0YWxOb2RlLCB0YXJnZXQpIHx8IGluc2lkZUVsZW1lbnRzLnNvbWUoZWxlbWVudCA9PiBlbGVtZW50ID09PSB0YXJnZXQgfHwgY29udGFpbnMoZWxlbWVudCwgdGFyZ2V0KSk7XG4gICAgICBwb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCA9ICFwb2ludGVyVGFyZ2V0SW5zaWRlO1xuICAgICAgbGFzdEludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50ID0gZXZlbnQucG9pbnRlclR5cGUgfHwgJ2tleWJvYXJkJztcbiAgICAgIGlmIChjbG9zZXN0KHRhcmdldCwgYFske0NMSUNLX1RSSUdHRVJfSURFTlRJRklFUn1dYCkpIHtcbiAgICAgICAgaXNQb2ludGVyRG93blJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgLy8gUmVzZXQgb24gdGhlIG5leHQgdGljayBzbyBhIHNpbmdsZSBjbGljayBvbiBhIGNsaWNrLXRyaWdnZXIgZG9lc24ndFxuICAgICAgICAvLyBwZXJtYW5lbnRseSBzdXBwcmVzcyBmb2N1cy1vdXQgY2xvc2luZyBmb3IgdGhlIGxpZmV0aW1lIG9mIHRoZSBpbnN0YW5jZS5cbiAgICAgICAgcG9pbnRlckRvd25UaW1lb3V0LnN0YXJ0KDAsICgpID0+IHtcbiAgICAgICAgICBpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIG9uS2V5RG93bigpIHtcbiAgICAgIGxhc3RJbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCA9ICdrZXlib2FyZCc7XG4gICAgfVxuICAgIHJldHVybiBtZXJnZUNsZWFudXBzKGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAncG9pbnRlcmRvd24nLCBvblBvaW50ZXJEb3duLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVydXAnLCBjbGVhclBvaW50ZXJEb3duT3V0c2lkZSwgdHJ1ZSksIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAncG9pbnRlcmNhbmNlbCcsIGNsZWFyUG9pbnRlckRvd25PdXRzaWRlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdrZXlkb3duJywgb25LZXlEb3duLCB0cnVlKSxcbiAgICAvLyBBdm9pZCBhIHN0YWxlIGB0cnVlYCBsZWFraW5nIGludG8gdGhlIG5leHQgb3BlbiAoZS5nLiBrZWVwLW1vdW50ZWQgcG9wdXBzKVxuICAgIC8vIGlmIHRoZSBwb3B1cCBkaXNtaXNzZWQgYmV0d2VlbiBwb2ludGVyZG93biBhbmQgcG9pbnRlcnVwLlxuICAgIGNsZWFyUG9pbnRlckRvd25PdXRzaWRlKTtcbiAgfSwgW2Rpc2FibGVkLCBmbG9hdGluZywgZG9tUmVmZXJlbmNlLCBmbG9hdGluZ0ZvY3VzRWxlbWVudCwgb3BlbiwgcG9ydGFsQ29udGV4dCwgcG9pbnRlckRvd25UaW1lb3V0LCBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzXSk7XG5cbiAgLy8gQ2xvc2Ugb24gZm9jdXMgb3V0IGFuZCByZXN0b3JlIGZvY3VzIHdpdGhpbiB0aGUgZmxvYXRpbmcgdHJlZSB3aGVuIG5lZWRlZC5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQgfHwgIWNsb3NlT25Gb2N1c091dCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG5cbiAgICAvLyBJbiBTYWZhcmksIGJ1dHRvbnMgbG9zZSBmb2N1cyB3aGVuIHByZXNzaW5nIHRoZW0uXG4gICAgZnVuY3Rpb24gaGFuZGxlUG9pbnRlckRvd24oKSB7XG4gICAgICBpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgcG9pbnRlckRvd25UaW1lb3V0LnN0YXJ0KDAsICgpID0+IHtcbiAgICAgICAgaXNQb2ludGVyRG93blJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlRm9jdXNJbihldmVudCkge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGlmIChpc1RhYmJhYmxlKHRhcmdldCkpIHtcbiAgICAgICAgbGFzdEZvY3VzZWRUYWJiYWJsZVJlZi5jdXJyZW50ID0gdGFyZ2V0O1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVGb2N1c091dHNpZGUoZXZlbnQpIHtcbiAgICAgIGNvbnN0IHJlbGF0ZWRUYXJnZXQgPSBldmVudC5yZWxhdGVkVGFyZ2V0O1xuICAgICAgY29uc3QgY3VycmVudFRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuXG4gICAgICAvLyBXaGVuIGZvY3VzIGlzIGxvc3QgdG8gdGhlIGJvZHkgKGUuZy4gb24gYSBiYWNrZHJvcCBwcmVzcyksIHJlY29yZCB0aGUgZWxlbWVudCB0aGF0XG4gICAgICAvLyBoYWQgZm9jdXMgc28gYSBjb25maXJtYXRpb24gZGlhbG9nIG9wZW5lZCB3aGlsZSB0aGUgYm9keSBpcyBmb2N1c2VkIGNhbiByZXR1cm4gZm9jdXNcbiAgICAgIC8vIHRvIGl0LiBTY29wZWQgdG8gYG1vZGFsYCB0byBhdm9pZCBub24tbW9kYWwgcG9wdXBzIHBvbGx1dGluZyB0aGUgc2hhcmVkIHN0YWNrLlxuICAgICAgaWYgKG1vZGFsICYmIHJlbGF0ZWRUYXJnZXQgPT0gbnVsbCAmJiB0YXJnZXQgIT0gbnVsbCAmJiBjb250YWlucyhmbG9hdGluZywgdGFyZ2V0KSkge1xuICAgICAgICBhZGRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQodGFyZ2V0KTtcbiAgICAgIH1cbiAgICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgICAgY29uc3Qgbm9kZUlkID0gZ2V0Tm9kZUlkKCk7XG4gICAgICAgIGNvbnN0IHRyaWdnZXJzID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHM7XG4gICAgICAgIGNvbnN0IGluc2lkZUVsZW1lbnRzID0gZ2V0UmVzb2x2ZWRJbnNpZGVFbGVtZW50cygpO1xuICAgICAgICBjb25zdCBpc1JlbGF0ZWRGb2N1c0d1YXJkID0gcmVsYXRlZFRhcmdldD8uaGFzQXR0cmlidXRlKGNyZWF0ZUF0dHJpYnV0ZSgnZm9jdXMtZ3VhcmQnKSkgJiYgW2JlZm9yZUd1YXJkUmVmLmN1cnJlbnQsIGFmdGVyR3VhcmRSZWYuY3VycmVudCwgcG9ydGFsQ29udGV4dD8uYmVmb3JlSW5zaWRlUmVmLmN1cnJlbnQsIHBvcnRhbENvbnRleHQ/LmFmdGVySW5zaWRlUmVmLmN1cnJlbnQsIHBvcnRhbENvbnRleHQ/LmJlZm9yZU91dHNpZGVSZWYuY3VycmVudCwgcG9ydGFsQ29udGV4dD8uYWZ0ZXJPdXRzaWRlUmVmLmN1cnJlbnQsIHJlc29sdmVSZWYocHJldmlvdXNGb2N1c2FibGVFbGVtZW50KSwgcmVzb2x2ZVJlZihuZXh0Rm9jdXNhYmxlRWxlbWVudCldLmluY2x1ZGVzKHJlbGF0ZWRUYXJnZXQpO1xuICAgICAgICBjb25zdCBtb3ZlZFRvVW5yZWxhdGVkTm9kZSA9ICEoY29udGFpbnMoZG9tUmVmZXJlbmNlLCByZWxhdGVkVGFyZ2V0KSB8fCBjb250YWlucyhmbG9hdGluZywgcmVsYXRlZFRhcmdldCkgfHwgY29udGFpbnMocmVsYXRlZFRhcmdldCwgZmxvYXRpbmcpIHx8IGNvbnRhaW5zKHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGUsIHJlbGF0ZWRUYXJnZXQpIHx8IGluc2lkZUVsZW1lbnRzLnNvbWUoZWxlbWVudCA9PiBlbGVtZW50ID09PSByZWxhdGVkVGFyZ2V0IHx8IGNvbnRhaW5zKGVsZW1lbnQsIHJlbGF0ZWRUYXJnZXQpKSB8fCB0cmlnZ2Vycy5oYXNNYXRjaGluZ0VsZW1lbnQodHJpZ2dlciA9PiBjb250YWlucyh0cmlnZ2VyLCByZWxhdGVkVGFyZ2V0KSkgfHwgaXNSZWxhdGVkRm9jdXNHdWFyZCB8fCB0cmVlICYmIChnZXROb2RlQ2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBub2RlSWQpLmZpbmQobm9kZSA9PiBjb250YWlucyhub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmZsb2F0aW5nLCByZWxhdGVkVGFyZ2V0KSB8fCBjb250YWlucyhub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmRvbVJlZmVyZW5jZSwgcmVsYXRlZFRhcmdldCkpIHx8IGdldE5vZGVBbmNlc3RvcnModHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBub2RlSWQpLmZpbmQobm9kZSA9PiBbbm9kZS5jb250ZXh0Py5lbGVtZW50cy5mbG9hdGluZywgZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQobm9kZS5jb250ZXh0Py5lbGVtZW50cy5mbG9hdGluZyldLmluY2x1ZGVzKHJlbGF0ZWRUYXJnZXQpIHx8IG5vZGUuY29udGV4dD8uZWxlbWVudHMuZG9tUmVmZXJlbmNlID09PSByZWxhdGVkVGFyZ2V0KSkpO1xuICAgICAgICBpZiAoY3VycmVudFRhcmdldCA9PT0gZG9tUmVmZXJlbmNlICYmIGZsb2F0aW5nRm9jdXNFbGVtZW50KSB7XG4gICAgICAgICAgaGFuZGxlVGFiSW5kZXgoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUmVzdG9yZSBmb2N1cyB0byB0aGUgcHJldmlvdXNseSBmb2N1c2VkIHRhYmJhYmxlIGVsZW1lbnQgdG8gcHJldmVudFxuICAgICAgICAvLyBmb2N1cyBmcm9tIGJlaW5nIGxvc3Qgb3V0c2lkZSB0aGUgZmxvYXRpbmcgdHJlZS5cbiAgICAgICAgaWYgKHJlc3RvcmVGb2N1cyAmJiBjdXJyZW50VGFyZ2V0ICE9PSBkb21SZWZlcmVuY2UgJiYgIWlzRWxlbWVudFZpc2libGUodGFyZ2V0KSAmJiBhY3RpdmVFbGVtZW50KGRvYykgPT09IGRvYy5ib2R5KSB7XG4gICAgICAgICAgLy8gTGV0IGBGbG9hdGluZ1BvcnRhbGAgZWZmZWN0IGtub3dzIHRoYXQgZm9jdXMgaXMgc3RpbGwgaW5zaWRlIHRoZVxuICAgICAgICAgIC8vIGZsb2F0aW5nIHRyZWUuXG4gICAgICAgICAgaWYgKGlzSFRNTEVsZW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpKSB7XG4gICAgICAgICAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudC5mb2N1cygpO1xuICAgICAgICAgICAgLy8gSWYgZXhwbGljaXRseSByZXF1ZXN0ZWQgdG8gcmVzdG9yZSBmb2N1cyB0byB0aGUgcG9wdXAgY29udGFpbmVyLCBkbyBub3Qgc2VhcmNoXG4gICAgICAgICAgICAvLyBmb3IgdGhlIG5leHQvcHJldmlvdXMgdGFiYmFibGUgZWxlbWVudC5cbiAgICAgICAgICAgIGlmIChyZXN0b3JlRm9jdXMgPT09ICdwb3B1cCcpIHtcbiAgICAgICAgICAgICAgLy8gSWYgdGhlIGZvY3VzZWQgZWxlbWVudCBpcyByZW1vdmVkIG9uIHBvaW50ZXJkb3duLCB0aGUgYnJvd3NlclxuICAgICAgICAgICAgICAvLyB0cmllcyB0byBtb3ZlIGZvY3VzIHRvIGl0IHJpZ2h0IGFmdGVyIHRoZSBgLmZvY3VzKClgIGNhbGwgYWJvdmUsXG4gICAgICAgICAgICAgIC8vIGJ1dCBiZWNhdXNlIGl0J3MgcmVtb3ZlZCBpbiB0aGUgc2FtZSB0aWNrLCBmb2N1cyBpcyBsb3N0IGluc3RlYWQuXG4gICAgICAgICAgICAgIC8vIFJlLWZvY3VzaW5nIGFzeW5jaHJvbm91c2x5IChuZXh0IGZyYW1lKSB3aW5zIHRoYXQgcmFjZS5cbiAgICAgICAgICAgICAgcmVzdG9yZUZvY3VzRnJhbWUucmVxdWVzdCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgZmxvYXRpbmdGb2N1c0VsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgdGFiYmFibGVDb250ZW50ID0gZ2V0VGFiYmFibGVDb250ZW50KCk7XG4gICAgICAgICAgY29uc3QgcHJldlRhYmJhYmxlID0gbGFzdEZvY3VzZWRUYWJiYWJsZVJlZi5jdXJyZW50O1xuICAgICAgICAgIGNvbnN0IG5vZGVUb0ZvY3VzID0gKHByZXZUYWJiYWJsZSAmJiB0YWJiYWJsZUNvbnRlbnQuaW5jbHVkZXMocHJldlRhYmJhYmxlKSA/IHByZXZUYWJiYWJsZSA6IG51bGwpIHx8IHRhYmJhYmxlQ29udGVudFt0YWJiYWJsZUNvbnRlbnQubGVuZ3RoIC0gMV0gfHwgZmxvYXRpbmdGb2N1c0VsZW1lbnQ7XG4gICAgICAgICAgaWYgKGlzSFRNTEVsZW1lbnQobm9kZVRvRm9jdXMpKSB7XG4gICAgICAgICAgICBub2RlVG9Gb2N1cy5mb2N1cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMzA2MFxuICAgICAgICBpZiAoZGF0YVJlZi5jdXJyZW50Lmluc2lkZVJlYWN0VHJlZSkge1xuICAgICAgICAgIGRhdGFSZWYuY3VycmVudC5pbnNpZGVSZWFjdFRyZWUgPSBmYWxzZTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGb2N1cyBkaWQgbm90IG1vdmUgaW5zaWRlIHRoZSBmbG9hdGluZyB0cmVlLCBhbmQgdGhlcmUgYXJlIG5vIHRhYmJhYmxlXG4gICAgICAgIC8vIHBvcnRhbCBndWFyZHMgdG8gaGFuZGxlIGNsb3NpbmcuXG4gICAgICAgIGlmICgoaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94ID8gdHJ1ZSA6ICFtb2RhbCkgJiYgcmVsYXRlZFRhcmdldCAmJiBtb3ZlZFRvVW5yZWxhdGVkTm9kZSAmJiAhaXNQb2ludGVyRG93blJlZi5jdXJyZW50ICYmIChcbiAgICAgICAgLy8gRml4IFJlYWN0IDE4IFN0cmljdCBNb2RlIHJldHVybkZvY3VzIGR1ZSB0byBkb3VibGUgcmVuZGVyaW5nLlxuICAgICAgICAvLyBGb3IgYW4gXCJ1bnRyYXBwZWRcIiB0eXBlYWJsZSBjb21ib2JveCAoaW5wdXQgcm9sZT1jb21ib2JveCB3aXRoXG4gICAgICAgIC8vIGluaXRpYWxGb2N1cz1mYWxzZSksIHJlLW9wZW5pbmcgdGhlIHBvcHVwIGFuZCB0YWJiaW5nIG91dCBzaG91bGQgc3RpbGwgY2xvc2UgaXQgZXZlblxuICAgICAgICAvLyB3aGVuIHRoZSBwcmV2aW91c2x5IGZvY3VzZWQgZWxlbWVudCAoZS5nLiB0aGUgbmV4dCB0YWJiYWJsZSBvdXRzaWRlIHRoZSBwb3B1cCkgaXNcbiAgICAgICAgLy8gZm9jdXNlZCBhZ2Fpbi4gT3RoZXJ3aXNlLCB0aGUgcG9wdXAgcmVtYWlucyBvcGVuIG9uIHRoZSBzZWNvbmQgVGFiIHNlcXVlbmNlOlxuICAgICAgICAvLyBjbGljayBpbnB1dCAtPiBUYWIgKGNsb3NlcykgLT4gY2xpY2sgaW5wdXQgLT4gVGFiLlxuICAgICAgICAvLyBBbGxvdyBjbG9zaW5nIHdoZW4gYGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveGAgcmVnYXJkbGVzcyBvZiB0aGUgcHJldmlvdXNseSBmb2N1c2VkIGVsZW1lbnQuXG4gICAgICAgIGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCB8fCByZWxhdGVkVGFyZ2V0ICE9PSBnZXRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQoKSkpIHtcbiAgICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuZm9jdXNPdXQsIGV2ZW50KSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBtYXJrSW5zaWRlUmVhY3RUcmVlKCkge1xuICAgICAgaWYgKHBvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGRhdGFSZWYuY3VycmVudC5pbnNpZGVSZWFjdFRyZWUgPSB0cnVlO1xuICAgICAgYmx1clRpbWVvdXQuc3RhcnQoMCwgKCkgPT4ge1xuICAgICAgICBkYXRhUmVmLmN1cnJlbnQuaW5zaWRlUmVhY3RUcmVlID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgZG9tUmVmZXJlbmNlRWxlbWVudCA9IGlzSFRNTEVsZW1lbnQoZG9tUmVmZXJlbmNlKSA/IGRvbVJlZmVyZW5jZSA6IG51bGw7XG4gICAgaWYgKCFmbG9hdGluZyAmJiAhZG9tUmVmZXJlbmNlRWxlbWVudCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIG1lcmdlQ2xlYW51cHMoZG9tUmVmZXJlbmNlRWxlbWVudCAmJiBhZGRFdmVudExpc3RlbmVyKGRvbVJlZmVyZW5jZUVsZW1lbnQsICdmb2N1c291dCcsIGhhbmRsZUZvY3VzT3V0c2lkZSksIGRvbVJlZmVyZW5jZUVsZW1lbnQgJiYgYWRkRXZlbnRMaXN0ZW5lcihkb21SZWZlcmVuY2VFbGVtZW50LCAncG9pbnRlcmRvd24nLCBoYW5kbGVQb2ludGVyRG93biksIGZsb2F0aW5nICYmIGFkZEV2ZW50TGlzdGVuZXIoZmxvYXRpbmcsICdmb2N1c2luJywgaGFuZGxlRm9jdXNJbiksIGZsb2F0aW5nICYmIGFkZEV2ZW50TGlzdGVuZXIoZmxvYXRpbmcsICdmb2N1c291dCcsIGhhbmRsZUZvY3VzT3V0c2lkZSksIGZsb2F0aW5nICYmIHBvcnRhbENvbnRleHQgJiYgYWRkRXZlbnRMaXN0ZW5lcihmbG9hdGluZywgJ2ZvY3Vzb3V0JywgbWFya0luc2lkZVJlYWN0VHJlZSwgdHJ1ZSkpO1xuICB9LCBbZGlzYWJsZWQsIGRvbVJlZmVyZW5jZSwgZmxvYXRpbmcsIGZsb2F0aW5nRm9jdXNFbGVtZW50LCBtb2RhbCwgdHJlZSwgcG9ydGFsQ29udGV4dCwgc3RvcmUsIGNsb3NlT25Gb2N1c091dCwgcmVzdG9yZUZvY3VzLCBnZXRUYWJiYWJsZUNvbnRlbnQsIGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCwgZ2V0Tm9kZUlkLCBkYXRhUmVmLCBibHVyVGltZW91dCwgcG9pbnRlckRvd25UaW1lb3V0LCByZXN0b3JlRm9jdXNGcmFtZSwgbmV4dEZvY3VzYWJsZUVsZW1lbnQsIHByZXZpb3VzRm9jdXNhYmxlRWxlbWVudCwgZ2V0UmVzb2x2ZWRJbnNpZGVFbGVtZW50c10pO1xuXG4gIC8vIEhpZGUgZXZlcnl0aGluZyBvdXRzaWRlIHRoZSBmbG9hdGluZyB0cmVlIGZyb20gYXNzaXN0aXZlIHRlY2ggd2hpbGUgb3Blbi5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQgfHwgIWZsb2F0aW5nIHx8ICFvcGVuKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8vIERvbid0IGhpZGUgcG9ydGFscyBuZXN0ZWQgd2l0aGluIHRoZSBwYXJlbnQgcG9ydGFsLlxuICAgIGNvbnN0IHBvcnRhbE5vZGVzID0gQXJyYXkuZnJvbShwb3J0YWxDb250ZXh0Py5wb3J0YWxOb2RlPy5xdWVyeVNlbGVjdG9yQWxsKGBbJHtjcmVhdGVBdHRyaWJ1dGUoJ3BvcnRhbCcpfV1gKSB8fCBbXSk7XG4gICAgY29uc3QgYW5jZXN0b3JzID0gdHJlZSA/IGdldE5vZGVBbmNlc3RvcnModHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBnZXROb2RlSWQoKSkgOiBbXTtcbiAgICBjb25zdCByb290QW5jZXN0b3JDb21ib2JveERvbVJlZmVyZW5jZSA9IGFuY2VzdG9ycy5maW5kKG5vZGUgPT4gaXNUeXBlYWJsZUNvbWJvYm94KG5vZGUuY29udGV4dD8uZWxlbWVudHMuZG9tUmVmZXJlbmNlIHx8IG51bGwpKT8uY29udGV4dD8uZWxlbWVudHMuZG9tUmVmZXJlbmNlO1xuICAgIGNvbnN0IGNvbnRyb2xJbnNpZGVFbGVtZW50cyA9IFtmbG9hdGluZywgLi4ucG9ydGFsTm9kZXMsIGJlZm9yZUd1YXJkUmVmLmN1cnJlbnQsIGFmdGVyR3VhcmRSZWYuY3VycmVudCwgcG9ydGFsQ29udGV4dD8uYmVmb3JlT3V0c2lkZVJlZi5jdXJyZW50LCBwb3J0YWxDb250ZXh0Py5hZnRlck91dHNpZGVSZWYuY3VycmVudCwgLi4uZ2V0UmVzb2x2ZWRJbnNpZGVFbGVtZW50cygpXTtcbiAgICBjb25zdCBpbnNpZGVFbGVtZW50cyA9IFsuLi5jb250cm9sSW5zaWRlRWxlbWVudHMsIHJvb3RBbmNlc3RvckNvbWJvYm94RG9tUmVmZXJlbmNlLCByZXNvbHZlUmVmKHByZXZpb3VzRm9jdXNhYmxlRWxlbWVudCksIHJlc29sdmVSZWYobmV4dEZvY3VzYWJsZUVsZW1lbnQpLCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3ggPyBkb21SZWZlcmVuY2UgOiBudWxsXS5maWx0ZXIoeCA9PiB4ICE9IG51bGwpO1xuICAgIGNvbnN0IGFyaWFIaWRkZW5DbGVhbnVwID0gbWFya090aGVycyhpbnNpZGVFbGVtZW50cywge1xuICAgICAgYXJpYUhpZGRlbjogbW9kYWwgfHwgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94LFxuICAgICAgbWFyazogZmFsc2VcbiAgICB9KTtcbiAgICBjb25zdCBtYXJrZXJJbnNpZGVFbGVtZW50cyA9IFtmbG9hdGluZywgLi4ucG9ydGFsTm9kZXNdLmZpbHRlcih4ID0+IHggIT0gbnVsbCk7XG4gICAgY29uc3QgbWFya2VyQ2xlYW51cCA9IG1hcmtPdGhlcnMobWFya2VySW5zaWRlRWxlbWVudHMpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBtYXJrZXJDbGVhbnVwKCk7XG4gICAgICBhcmlhSGlkZGVuQ2xlYW51cCgpO1xuICAgIH07XG4gIH0sIFtvcGVuLCBkaXNhYmxlZCwgZG9tUmVmZXJlbmNlLCBmbG9hdGluZywgbW9kYWwsIHBvcnRhbENvbnRleHQsIGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCwgdHJlZSwgZ2V0Tm9kZUlkLCBuZXh0Rm9jdXNhYmxlRWxlbWVudCwgcHJldmlvdXNGb2N1c2FibGVFbGVtZW50LCBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzXSk7XG5cbiAgLy8gRm9jdXMgdGhlIGluaXRpYWwgZWxlbWVudCB3aGVuIHRoZSBmbG9hdGluZyBlbGVtZW50IG9wZW5zLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiB8fCBkaXNhYmxlZCB8fCAhaXNIVE1MRWxlbWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY2xvc2VUeXBlUmVmLmN1cnJlbnQgPSAnJztcbiAgICBsYXN0SW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgPSAnJztcbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgICBjb25zdCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQgPSBhY3RpdmVFbGVtZW50KGRvYyk7XG5cbiAgICAvLyBXYWl0IGZvciBhbnkgbGF5b3V0IGVmZmVjdCBzdGF0ZSBzZXR0ZXJzIHRvIGV4ZWN1dGUgdG8gc2V0IGB0YWJJbmRleGAuXG4gICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgY29uc3QgaW5pdGlhbEZvY3VzVmFsdWVPckZuID0gaW5pdGlhbEZvY3VzUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCByZXNvbHZlZEluaXRpYWxGb2N1cyA9IHR5cGVvZiBpbml0aWFsRm9jdXNWYWx1ZU9yRm4gPT09ICdmdW5jdGlvbicgPyBpbml0aWFsRm9jdXNWYWx1ZU9yRm4ob3BlbkludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50IHx8ICcnKSA6IGluaXRpYWxGb2N1c1ZhbHVlT3JGbjtcblxuICAgICAgLy8gYG51bGxgIHNob3VsZCBmYWxsYmFjayB0byBkZWZhdWx0IGJlaGF2aW9yIGluIGNhc2Ugb2YgYW4gZW1wdHkgcmVmLlxuICAgICAgaWYgKHJlc29sdmVkSW5pdGlhbEZvY3VzID09PSB1bmRlZmluZWQgfHwgcmVzb2x2ZWRJbml0aWFsRm9jdXMgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZvY3VzQWxyZWFkeUluc2lkZUZsb2F0aW5nRWwgPSBjb250YWlucyhmbG9hdGluZ0ZvY3VzRWxlbWVudCwgcHJldmlvdXNseUZvY3VzZWRFbGVtZW50KTtcbiAgICAgIGlmIChmb2N1c0FscmVhZHlJbnNpZGVGbG9hdGluZ0VsKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGxldCBmb2N1c2FibGVFbGVtZW50cyA9IG51bGw7XG4gICAgICBjb25zdCBnZXREZWZhdWx0Rm9jdXNFbGVtZW50ID0gKCkgPT4ge1xuICAgICAgICBpZiAoZm9jdXNhYmxlRWxlbWVudHMgPT0gbnVsbCkge1xuICAgICAgICAgIGZvY3VzYWJsZUVsZW1lbnRzID0gZ2V0VGFiYmFibGVDb250ZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZm9jdXNhYmxlRWxlbWVudHNbMF0gfHwgZmxvYXRpbmdGb2N1c0VsZW1lbnQ7XG4gICAgICB9O1xuICAgICAgbGV0IGVsVG9Gb2N1cztcbiAgICAgIGlmIChyZXNvbHZlZEluaXRpYWxGb2N1cyA9PT0gdHJ1ZSB8fCByZXNvbHZlZEluaXRpYWxGb2N1cyA9PT0gbnVsbCkge1xuICAgICAgICBlbFRvRm9jdXMgPSBnZXREZWZhdWx0Rm9jdXNFbGVtZW50KCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlbFRvRm9jdXMgPSByZXNvbHZlUmVmKHJlc29sdmVkSW5pdGlhbEZvY3VzKTtcbiAgICAgIH1cbiAgICAgIGVsVG9Gb2N1cyA9IGVsVG9Gb2N1cyB8fCBnZXREZWZhdWx0Rm9jdXNFbGVtZW50KCk7XG4gICAgICBjb25zdCBoYWRGb2N1c0luc2lkZSA9IGNvbnRhaW5zKGZsb2F0aW5nRm9jdXNFbGVtZW50LCBhY3RpdmVFbGVtZW50KGRvYykpO1xuXG4gICAgICAvLyBTY3JlZW4gcmVhZGVycyByZS1zeW5jIGZvY3VzIHRvIHRoZWlyIGN1cnNvciByaWdodCBhZnRlciBhIHN5bnRoZXNpemVkIHByZXNzLiBBIGZvY3VzXG4gICAgICAvLyB0aGF0IGxhbmRzIGEgZnJhbWUgbGF0ZXIgcmVhZHMgYXMgYSBzdHJheSBtb3ZlIGFuZCBnZXRzIHB1bGxlZCBiYWNrIHRvIHRoZSByZWZlcmVuY2UuXG4gICAgICBjb25zdCBvcGVuRXZlbnQgPSBkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50O1xuICAgICAgY29uc3Qgb3BlbmVkQnlWaXJ0dWFsUHJlc3MgPSBvcGVuRXZlbnQ/LnR5cGUgPT09ICdtb3VzZWRvd24nICYmIGlzVmlydHVhbENsaWNrKG9wZW5FdmVudCk7XG5cbiAgICAgIC8vIGVucXVldWVGb2N1cyByZXR1cm5zIGEgckFGLWNhbmNlbCBmdW5jdGlvbjsgd2UgaW50ZW50aW9uYWxseSBkb24ndCBjYW5jZWwgdGhpcyBmb2N1cy5cbiAgICAgIHZvaWQgZW5xdWV1ZUZvY3VzKGVsVG9Gb2N1cywge1xuICAgICAgICBzeW5jOiBvcGVuZWRCeVZpcnR1YWxQcmVzcyxcbiAgICAgICAgcHJldmVudFNjcm9sbDogZWxUb0ZvY3VzID09PSBmbG9hdGluZ0ZvY3VzRWxlbWVudCxcbiAgICAgICAgc2hvdWxkRm9jdXMoKSB7XG4gICAgICAgICAgLy8gSWYgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaGFzIGNsb3NlZCBiZWZvcmUgdGhpcyBydW5zIOKAlCBlLmcuIHRhYmJpbmcgb3V0IG9mIGFcbiAgICAgICAgICAvLyBrZXB0LW1vdW50ZWQgcG9wdXAg4oCUIGRvbid0IHB1bGwgZm9jdXMgYmFjayBvbnRvIHRoZSBpbml0aWFsIGVsZW1lbnQgYWZ0ZXIgaXQgaGFzXG4gICAgICAgICAgLy8gbGVnaXRpbWF0ZWx5IG1vdmVkIGVsc2V3aGVyZS5cbiAgICAgICAgICBpZiAoIW9wZW5SZWYuY3VycmVudCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoaGFkRm9jdXNJbnNpZGUpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBjdXJyZW50QWN0aXZlRWxlbWVudCA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcbiAgICAgICAgICBjb25zdCBmb2N1c01vdmVkSW5zaWRlID0gY3VycmVudEFjdGl2ZUVsZW1lbnQgIT09IGVsVG9Gb2N1cyAmJiBjb250YWlucyhmbG9hdGluZ0ZvY3VzRWxlbWVudCwgY3VycmVudEFjdGl2ZUVsZW1lbnQpO1xuICAgICAgICAgIHJldHVybiAhZm9jdXNNb3ZlZEluc2lkZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sIFtkaXNhYmxlZCwgb3BlbiwgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIGdldFRhYmJhYmxlQ29udGVudCwgaW5pdGlhbEZvY3VzUmVmLCBvcGVuSW50ZXJhY3Rpb25UeXBlUmVmLCBvcGVuUmVmLCBkYXRhUmVmXSk7XG5cbiAgLy8gQSByZXR1cm4tZm9jdXMgcXVldWVkIGJ5IHRoZSBlZmZlY3QgY2xlYW51cC4gSWYgdGhlIGVmZmVjdCByZS1hcm1zIGluIHRoZSBzYW1lIGNvbW1pdCwgYVxuICAvLyBkZXBlbmRlbmN5IGNoYW5nZWQgd2hpbGUgdGhlIHBvcHVwIHN0YXllZCBvcGVuLCBzbyB0aGUgY2xlYW51cCB3YXMgbm90IGEgY2xvc2UuXG4gIGNvbnN0IHBlbmRpbmdSZXR1cm5Gb2N1c1JlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcblxuICAvLyBUcmFjayByZXR1cm4gZm9jdXMgdGFyZ2V0cyBhbmQgcmVzdG9yZSBmb2N1cyBvbiB1bm1vdW50L2Nsb3NlLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHtcbiAgICAgIHBlbmRpbmdSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmIChwZW5kaW5nUmV0dXJuRm9jdXNSZWYuY3VycmVudCkge1xuICAgICAgcGVuZGluZ1JldHVybkZvY3VzUmVmLmN1cnJlbnQuY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICAgIHBlbmRpbmdSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG4gICAgY29uc3QgZWxlbWVudEZvY3VzZWRCZWZvcmVPcGVuID0gYWN0aXZlRWxlbWVudChkb2MpO1xuICAgIC8vIE9ubHkgYW4gZXhwbGljaXQgYG51bGxgIGludGVyYWN0aW9uIHR5cGUgcmVwcmVzZW50cyBhIHByb2dyYW1tYXRpYyBvcGVuLlxuICAgIC8vIGB1bmRlZmluZWRgIGlzIG5vcm1hbGl6ZWQgdG8gYCcnYCBieSB0aGUgcHJvcCBkZWZhdWx0LCBzbyBpdCBuZXZlciByZWFjaGVzXG4gICAgLy8gaGVyZSBhcyBudWxsaXNoIGFuZCBpcyBpbnRlbnRpb25hbGx5IG5vdCB0cmVhdGVkIGFzIHByb2dyYW1tYXRpYy5cbiAgICBjb25zdCBwcmVmZXJQcmV2aW91c0ZvY3VzID0gb3BlbkludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50ID09IG51bGw7XG4gICAgYWRkUHJldmlvdXNseUZvY3VzZWRFbGVtZW50KGVsZW1lbnRGb2N1c2VkQmVmb3JlT3Blbik7XG4gICAgZnVuY3Rpb24gb25PcGVuQ2hhbmdlTG9jYWwoZGV0YWlscykge1xuICAgICAgaWYgKCFkZXRhaWxzLm9wZW4pIHtcbiAgICAgICAgY2xvc2VUeXBlUmVmLmN1cnJlbnQgPSBnZXRFdmVudFR5cGUoZGV0YWlscy5uYXRpdmVFdmVudCwgbGFzdEludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50KTtcbiAgICAgIH1cblxuICAgICAgLy8gRm9jdXMgZ3VhcmRzIHRyYW5zZmVyIGZvY3VzIHRoZW1zZWx2ZXM7IG90aGVyIGNsb3NlIGhhbmRsZXJzIG1heSBzdGlsbCBuZWVkIHJldHVybiBmb2N1cy5cbiAgICAgIGlmIChkZXRhaWxzLnJlYXNvbiA9PT0gUkVBU09OUy5mb2N1c091dCAmJiBkZXRhaWxzLnRyaWdnZXJFbGVtZW50Py5oYXNBdHRyaWJ1dGUoY3JlYXRlQXR0cmlidXRlKCdmb2N1cy1ndWFyZCcpKSB8fCBkZXRhaWxzLnJlYXNvbiA9PT0gUkVBU09OUy50cmlnZ2VySG92ZXIgJiYgZGV0YWlscy5uYXRpdmVFdmVudC50eXBlID09PSAnbW91c2VsZWF2ZScpIHtcbiAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKGRldGFpbHMucmVhc29uICE9PSBSRUFTT05TLm91dHNpZGVQcmVzcykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZGV0YWlscy5uZXN0ZWQpIHtcbiAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSBpZiAoaXNWaXJ0dWFsQ2xpY2soZGV0YWlscy5uYXRpdmVFdmVudCkgfHwgaXNWaXJ0dWFsUG9pbnRlckV2ZW50KGRldGFpbHMubmF0aXZlRXZlbnQpKSB7XG4gICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBPbiBvdXRzaWRlIHByZXNzLCBvbmx5IHJldHVybiBmb2N1cyB0byB0aGUgcmVmZXJlbmNlIHdoZW4gdGhlIGJyb3dzZXIgc3VwcG9ydHMgdGhlXG4gICAgICAgIC8vIGBmb2N1cyh7IHByZXZlbnRTY3JvbGwgfSlgIG9wdGlvbjsgd2l0aG91dCBpdCwgcmVzdG9yaW5nIGZvY3VzIHNjcm9sbHMgdGhlIHBhZ2UuXG4gICAgICAgIC8vIENocm9tZSBvbiBBbmRyb2lkIGFuZCBTYW1zdW5nIEludGVybmV0IHN0aWxsIGRvbid0IHN1cHBvcnQgYHByZXZlbnRTY3JvbGxgXG4gICAgICAgIC8vIChodHRwczovL2lzc3Vlcy5jaHJvbWl1bS5vcmcvaXNzdWVzLzQxNDUzMTIyKSwgc28gdGhlIHJ1bnRpbWUgY2hlY2sga2VlcHMgcmV0dXJuXG4gICAgICAgIC8vIGZvY3VzIGRpc2FibGVkIHRoZXJlIHRvIGF2b2lkIHRoZSBzY3JvbGwganVtcC5cbiAgICAgICAgbGV0IGlzUHJldmVudFNjcm9sbFN1cHBvcnRlZCA9IGZhbHNlO1xuICAgICAgICBvd25lckRvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KS5jcmVhdGVFbGVtZW50KCdkaXYnKS5mb2N1cyh7XG4gICAgICAgICAgZ2V0IHByZXZlbnRTY3JvbGwoKSB7XG4gICAgICAgICAgICBpc1ByZXZlbnRTY3JvbGxTdXBwb3J0ZWQgPSB0cnVlO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChpc1ByZXZlbnRTY3JvbGxTdXBwb3J0ZWQpIHtcbiAgICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBldmVudHMub24oJ29wZW5jaGFuZ2UnLCBvbk9wZW5DaGFuZ2VMb2NhbCk7XG4gICAgZnVuY3Rpb24gZ2V0UmV0dXJuRWxlbWVudChjbG9zZVR5cGUpIHtcbiAgICAgIGNvbnN0IHJldHVybkZvY3VzVmFsdWVPckZuID0gcmV0dXJuRm9jdXNSZWYuY3VycmVudDtcbiAgICAgIGxldCByZXNvbHZlZFJldHVybkZvY3VzVmFsdWUgPSB0eXBlb2YgcmV0dXJuRm9jdXNWYWx1ZU9yRm4gPT09ICdmdW5jdGlvbicgPyByZXR1cm5Gb2N1c1ZhbHVlT3JGbihjbG9zZVR5cGUpIDogcmV0dXJuRm9jdXNWYWx1ZU9yRm47XG5cbiAgICAgIC8vIGBudWxsYCBzaG91bGQgZmFsbGJhY2sgdG8gZGVmYXVsdCBiZWhhdmlvciBpbiBjYXNlIG9mIGFuIGVtcHR5IHJlZi5cbiAgICAgIGlmIChyZXNvbHZlZFJldHVybkZvY3VzVmFsdWUgPT09IHVuZGVmaW5lZCB8fCByZXNvbHZlZFJldHVybkZvY3VzVmFsdWUgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKHJlc29sdmVkUmV0dXJuRm9jdXNWYWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXNvbHZlZFJldHVybkZvY3VzVmFsdWUgPSB0cnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgcmVmZXJlbmNlUmV0dXJuRWxlbWVudCA9IGRvbVJlZmVyZW5jZT8uaXNDb25uZWN0ZWQgPyBkb21SZWZlcmVuY2UgOiBudWxsO1xuICAgICAgY29uc3QgcHJldmlvdXNSZXR1cm5FbGVtZW50ID0gZWxlbWVudEZvY3VzZWRCZWZvcmVPcGVuPy5pc0Nvbm5lY3RlZCAmJiBnZXROb2RlTmFtZShlbGVtZW50Rm9jdXNlZEJlZm9yZU9wZW4pICE9PSAnYm9keScgPyBlbGVtZW50Rm9jdXNlZEJlZm9yZU9wZW4gOiBudWxsO1xuICAgICAgbGV0IGRlZmF1bHRSZXR1cm5FbGVtZW50ID0gcHJlZmVyUHJldmlvdXNGb2N1cyA/IHByZXZpb3VzUmV0dXJuRWxlbWVudCB8fCByZWZlcmVuY2VSZXR1cm5FbGVtZW50IDogcmVmZXJlbmNlUmV0dXJuRWxlbWVudCB8fCBwcmV2aW91c1JldHVybkVsZW1lbnQ7XG4gICAgICBpZiAoIWRlZmF1bHRSZXR1cm5FbGVtZW50KSB7XG4gICAgICAgIGRlZmF1bHRSZXR1cm5FbGVtZW50ID0gZ2V0UHJldmlvdXNseUZvY3VzZWRFbGVtZW50KCkgfHwgbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgcmVzb2x2ZWRSZXR1cm5Gb2N1c1ZhbHVlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRSZXR1cm5FbGVtZW50O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc29sdmVSZWYocmVzb2x2ZWRSZXR1cm5Gb2N1c1ZhbHVlKSB8fCBkZWZhdWx0UmV0dXJuRWxlbWVudCB8fCBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZXZlbnRzLm9mZignb3BlbmNoYW5nZScsIG9uT3BlbkNoYW5nZUxvY2FsKTtcbiAgICAgIGNvbnN0IGFjdGl2ZUVsID0gYWN0aXZlRWxlbWVudChkb2MpO1xuICAgICAgY29uc3QgaW5zaWRlRWxlbWVudHMgPSBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzKCk7XG4gICAgICBjb25zdCBpc0ZvY3VzSW5zaWRlRmxvYXRpbmdUcmVlID0gY29udGFpbnMoZmxvYXRpbmcsIGFjdGl2ZUVsKSB8fCBpbnNpZGVFbGVtZW50cy5zb21lKGVsZW1lbnQgPT4gZWxlbWVudCA9PT0gYWN0aXZlRWwgfHwgY29udGFpbnMoZWxlbWVudCwgYWN0aXZlRWwpKSB8fCB0cmVlICYmIGdldE5vZGVDaGlsZHJlbih0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIGdldE5vZGVJZCgpLCBmYWxzZSkuc29tZShub2RlID0+IGNvbnRhaW5zKG5vZGUuY29udGV4dD8uZWxlbWVudHMuZmxvYXRpbmcsIGFjdGl2ZUVsKSk7XG5cbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgICAgIGNvbnN0IHJldHVybkZvY3VzVmFsdWVPckZuID0gcmV0dXJuRm9jdXNSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IGNsb3NlVHlwZSA9IGNsb3NlVHlwZVJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgcmV0dXJuRWxlbWVudCA9IGdldFJldHVybkVsZW1lbnQoY2xvc2VUeXBlKTtcbiAgICAgIGNvbnN0IGpvYiA9IHtcbiAgICAgICAgY2FuY2VsbGVkOiBmYWxzZVxuICAgICAgfTtcbiAgICAgIHBlbmRpbmdSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gam9iO1xuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICBpZiAocGVuZGluZ1JldHVybkZvY3VzUmVmLmN1cnJlbnQgPT09IGpvYikge1xuICAgICAgICAgIHBlbmRpbmdSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICAvLyBgcmV0dXJuRWxlbWVudGAgaWYgaXQgaXMgdGFiYmFibGUsIG90aGVyd2lzZSBpdHMgZmlyc3QgdGFiYmFibGUgY2hpbGQsXG4gICAgICAgIC8vIG90aGVyd2lzZSBgcmV0dXJuRWxlbWVudGAgaXRzZWxmICh3aGljaCBtYXkgbm90IGJlIHRhYmJhYmxlIGF0IGFsbCkuXG4gICAgICAgIGNvbnN0IHRhYmJhYmxlUmV0dXJuRWxlbWVudCA9IGdldEZpcnN0VGFiYmFibGVFbGVtZW50KHJldHVybkVsZW1lbnQpO1xuICAgICAgICAvLyBSZWFkIGluIHRoZSBjbGVhbnVwIG9uIHB1cnBvc2U6IHRoZSBsYXRlc3QgYGV4cGxpY2l0UmV0dXJuRm9jdXNgIGRlY2lkZXMuXG4gICAgICAgIGNvbnN0IGhhc0V4cGxpY2l0UmV0dXJuRm9jdXMgPVxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgICAgIGV4cGxpY2l0UmV0dXJuRm9jdXNSZWYuY3VycmVudCA/PyB0eXBlb2YgcmV0dXJuRm9jdXNWYWx1ZU9yRm4gIT09ICdib29sZWFuJztcbiAgICAgICAgaWYgKCFqb2IuY2FuY2VsbGVkICYmIHJldHVybkZvY3VzVmFsdWVPckZuICYmICFwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCAmJiBpc0hUTUxFbGVtZW50KHRhYmJhYmxlUmV0dXJuRWxlbWVudCkgJiYgKFxuICAgICAgICAvLyBJZiB0aGUgZm9jdXMgbW92ZWQgc29tZXdoZXJlIGVsc2UgYWZ0ZXIgbW91bnQsIGF2b2lkIHJldHVybmluZyBmb2N1c1xuICAgICAgICAvLyBzaW5jZSBpdCBsaWtlbHkgZW50ZXJlZCBhIGRpZmZlcmVudCBlbGVtZW50IHdoaWNoIHNob3VsZCBiZVxuICAgICAgICAvLyByZXNwZWN0ZWQ6IGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMjYwN1xuICAgICAgICAhaGFzRXhwbGljaXRSZXR1cm5Gb2N1cyAmJiB0YWJiYWJsZVJldHVybkVsZW1lbnQgIT09IGFjdGl2ZUVsICYmIGFjdGl2ZUVsICE9PSBkb2MuYm9keSA/IGlzRm9jdXNJbnNpZGVGbG9hdGluZ1RyZWUgOiB0cnVlKSkge1xuICAgICAgICAgIGNvbnN0IGZvY3VzT3B0aW9ucyA9IHtcbiAgICAgICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgICAgICB9O1xuICAgICAgICAgIGlmIChjbG9zZVR5cGUgPT09ICdrZXlib2FyZCcpIHtcbiAgICAgICAgICAgIGZvY3VzT3B0aW9ucy5mb2N1c1Zpc2libGUgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0YWJiYWJsZVJldHVybkVsZW1lbnQuZm9jdXMoZm9jdXNPcHRpb25zKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEEgY2FuY2VsbGVkIHJldHVybiBtdXN0IGFsc28gY2xlYXIgc3VwcHJlc3Npb24gYmVmb3JlIHRoZSBuZXh0IGNsb3NlLlxuICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfSk7XG4gICAgfTtcbiAgfSwgW2Rpc2FibGVkLCBmbG9hdGluZywgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIHJldHVybkZvY3VzUmVmLCBleHBsaWNpdFJldHVybkZvY3VzUmVmLCBvcGVuSW50ZXJhY3Rpb25UeXBlUmVmLCBldmVudHMsIHRyZWUsIGRvbVJlZmVyZW5jZSwgZ2V0Tm9kZUlkLCBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzXSk7XG5cbiAgLy8gU2FmYXJpIG1heSByYW5kb21seSBzY3JvbGwgdG8gdGhlIGJvdHRvbSBvZiB0aGUgcGFnZSBpZiBhbiBpbnB1dCBpbnNpZGUgYSBwb3B1cCBoYXMgZm9jdXNcbiAgLy8gd2hlbiB0aGUgcG9wdXAgdW5tb3VudHMgZnJvbSB0aGUgRE9NLlxuICAvLyBCeSBibHVycmluZyBpdCBiZWZvcmUgdGhlIHBvcHVwIHVubW91bnRzLCB3ZSBjYW4gcHJldmVudCB0aGlzIGJlaGF2aW9yLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcGxhdGZvcm0uZW5naW5lLndlYmtpdCB8fCBvcGVuIHx8ICFmbG9hdGluZykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBhY3RpdmVFbCA9IGFjdGl2ZUVsZW1lbnQob3duZXJEb2N1bWVudChmbG9hdGluZykpO1xuICAgIGlmICghaXNIVE1MRWxlbWVudChhY3RpdmVFbCkgfHwgIWlzVHlwZWFibGVFbGVtZW50KGFjdGl2ZUVsKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY29udGFpbnMoZmxvYXRpbmcsIGFjdGl2ZUVsKSkge1xuICAgICAgYWN0aXZlRWwuYmx1cigpO1xuICAgIH1cbiAgfSwgW29wZW4sIGZsb2F0aW5nXSk7XG5cbiAgLy8gU3luY2hyb25pemUgdGhlIGZvY3VzIG1hbmFnZXIgc3RhdGUgKG1vZGFsLCBjbG9zZU9uRm9jdXNPdXQsIG9wZW4sIGV0Yy4pIHRvIHRoZVxuICAvLyBGbG9hdGluZ1BvcnRhbCBjb250ZXh0LCB3aGljaCB1c2VzIGl0IHRvIGRlY2lkZSB3aGV0aGVyIHRvIHJlbmRlciBpdHMgb3duIGd1YXJkcy5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQgfHwgIXBvcnRhbENvbnRleHQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHBvcnRhbENvbnRleHQuc2V0Rm9jdXNNYW5hZ2VyU3RhdGUoe1xuICAgICAgbW9kYWwsXG4gICAgICBjbG9zZU9uRm9jdXNPdXQsXG4gICAgICBvcGVuLFxuICAgICAgb25PcGVuQ2hhbmdlOiBzdG9yZS5zZXRPcGVuLFxuICAgICAgZG9tUmVmZXJlbmNlXG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHBvcnRhbENvbnRleHQuc2V0Rm9jdXNNYW5hZ2VyU3RhdGUobnVsbCk7XG4gICAgfTtcbiAgfSwgW2Rpc2FibGVkLCBwb3J0YWxDb250ZXh0LCBtb2RhbCwgb3Blbiwgc3RvcmUsIGNsb3NlT25Gb2N1c091dCwgZG9tUmVmZXJlbmNlXSk7XG5cbiAgLy8gS2VlcCB0aGUgZmxvYXRpbmcgZWxlbWVudCB0YWJJbmRleCBpbiBzeW5jIGFuZCBjbGVhciBzdGFsZSBmb2N1cyByZWNvcmRzLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGhhbmRsZVRhYkluZGV4KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgcXVldWVNaWNyb3Rhc2soY2xlYXJEaXNjb25uZWN0ZWRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzKTtcbiAgICB9O1xuICB9LCBbZGlzYWJsZWQsIGZsb2F0aW5nRm9jdXNFbGVtZW50XSk7XG4gIGNvbnN0IHNob3VsZFJlbmRlckd1YXJkcyA9ICFkaXNhYmxlZCAmJiAobW9kYWwgPyAhaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94IDogdHJ1ZSkgJiYgKGlzSW5zaWRlUG9ydGFsIHx8IG1vZGFsKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhSZWFjdC5GcmFnbWVudCwge1xuICAgIGNoaWxkcmVuOiBbc2hvdWxkUmVuZGVyR3VhcmRzICYmIC8qI19fUFVSRV9fKi9fanN4KEZvY3VzR3VhcmQsIHtcbiAgICAgIFwiZGF0YS10eXBlXCI6IFwiaW5zaWRlXCIsXG4gICAgICByZWY6IG1lcmdlZEJlZm9yZUd1YXJkUmVmLFxuICAgICAgb25Gb2N1czogZXZlbnQgPT4ge1xuICAgICAgICBpZiAobW9kYWwpIHtcbiAgICAgICAgICBjb25zdCBlbHMgPSBnZXRUYWJiYWJsZUNvbnRlbnQoKTtcbiAgICAgICAgICAvLyBlbnF1ZXVlRm9jdXMgcmV0dXJucyBhIHJBRi1jYW5jZWwgZnVuY3Rpb24gd2UgZG9uJ3QgbmVlZCBoZXJlLlxuICAgICAgICAgIHZvaWQgZW5xdWV1ZUZvY3VzKGVsc1tlbHMubGVuZ3RoIC0gMV0pO1xuICAgICAgICB9IGVsc2UgaWYgKHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGUpIHtcbiAgICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgIGlmIChpc091dHNpZGVFdmVudChldmVudCwgcG9ydGFsQ29udGV4dC5wb3J0YWxOb2RlKSkge1xuICAgICAgICAgICAgY29uc3QgbmV4dFRhYmJhYmxlID0gZ2V0TmV4dFRhYmJhYmxlKGRvbVJlZmVyZW5jZSk7XG4gICAgICAgICAgICBuZXh0VGFiYmFibGU/LmZvY3VzKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc29sdmVSZWYocHJldmlvdXNGb2N1c2FibGVFbGVtZW50ID8/IHBvcnRhbENvbnRleHQuYmVmb3JlT3V0c2lkZVJlZik/LmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSksIGNoaWxkcmVuLCBzaG91bGRSZW5kZXJHdWFyZHMgJiYgLyojX19QVVJFX18qL19qc3goRm9jdXNHdWFyZCwge1xuICAgICAgXCJkYXRhLXR5cGVcIjogXCJpbnNpZGVcIixcbiAgICAgIHJlZjogbWVyZ2VkQWZ0ZXJHdWFyZFJlZixcbiAgICAgIG9uRm9jdXM6IGV2ZW50ID0+IHtcbiAgICAgICAgaWYgKG1vZGFsKSB7XG4gICAgICAgICAgLy8gZW5xdWV1ZUZvY3VzIHJldHVybnMgYSByQUYtY2FuY2VsIGZ1bmN0aW9uIHdlIGRvbid0IG5lZWQgaGVyZS5cbiAgICAgICAgICB2b2lkIGVucXVldWVGb2N1cyhnZXRUYWJiYWJsZUNvbnRlbnQoKVswXSk7XG4gICAgICAgIH0gZWxzZSBpZiAocG9ydGFsQ29udGV4dD8ucG9ydGFsTm9kZSkge1xuICAgICAgICAgIGlmIChjbG9zZU9uRm9jdXNPdXQpIHtcbiAgICAgICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3J0YWxDb250ZXh0LnBvcnRhbE5vZGUpKSB7XG4gICAgICAgICAgICBjb25zdCBwcmV2VGFiYmFibGUgPSBnZXRQcmV2aW91c1RhYmJhYmxlKGRvbVJlZmVyZW5jZSk7XG4gICAgICAgICAgICBwcmV2VGFiYmFibGU/LmZvY3VzKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc29sdmVSZWYobmV4dEZvY3VzYWJsZUVsZW1lbnQgPz8gcG9ydGFsQ29udGV4dC5hZnRlck91dHNpZGVSZWYpPy5mb2N1cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXVxuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUFuaW1hdGlvbkZyYW1lIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlQW5pbWF0aW9uRnJhbWUnO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgZ2V0VGFyZ2V0LCBpc1R5cGVhYmxlRWxlbWVudCB9IGZyb20gXCIuLi91dGlscy9lbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgaXNNb3VzZUxpa2VQb2ludGVyVHlwZSwgaXNWaXJ0dWFsUG9pbnRlckV2ZW50IH0gZnJvbSBcIi4uL3V0aWxzL2V2ZW50Lm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuLyoqXG4gKiBPcGVucyBvciBjbG9zZXMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2hlbiBjbGlja2luZyB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlQ2xpY2tcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNsaWNrKHN0b3JlLCBwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICBldmVudDogZXZlbnRPcHRpb24gPSAnY2xpY2snLFxuICAgIHRvZ2dsZSA9IHRydWUsXG4gICAgaWdub3JlTW91c2UgPSBmYWxzZSxcbiAgICBzdGlja0lmT3BlbiA9IHRydWUsXG4gICAgdG91Y2hPcGVuRGVsYXkgPSAwLFxuICAgIHJlYXNvbiA9IFJFQVNPTlMudHJpZ2dlclByZXNzXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgZGF0YVJlZiA9IHN0b3JlLmNvbnRleHQuZGF0YVJlZjtcbiAgY29uc3QgcG9pbnRlclR5cGVSZWYgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgY29uc3QgZnJhbWUgPSB1c2VBbmltYXRpb25GcmFtZSgpO1xuICBjb25zdCB0b3VjaE9wZW5UaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCByZWZlcmVuY2UgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBmdW5jdGlvbiBzZXRPcGVuV2l0aFRvdWNoRGVsYXkobmV4dE9wZW4sIG5hdGl2ZUV2ZW50LCB0YXJnZXQsIHBvaW50ZXJUeXBlKSB7XG4gICAgICBjb25zdCBkZXRhaWxzID0gY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKHJlYXNvbiwgbmF0aXZlRXZlbnQsIHRhcmdldCk7XG4gICAgICBpZiAobmV4dE9wZW4gJiYgcG9pbnRlclR5cGUgPT09ICd0b3VjaCcgJiYgdG91Y2hPcGVuRGVsYXkgPiAwKSB7XG4gICAgICAgIHRvdWNoT3BlblRpbWVvdXQuc3RhcnQodG91Y2hPcGVuRGVsYXksICgpID0+IHtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKHRydWUsIGRldGFpbHMpO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0b3JlLnNldE9wZW4obmV4dE9wZW4sIGRldGFpbHMpO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBnZXROZXh0T3BlbihvcGVuLCBjdXJyZW50VGFyZ2V0LCBpc0NsaWNrTGlrZU9wZW5FdmVudCkge1xuICAgICAgY29uc3Qgb3BlbkV2ZW50ID0gZGF0YVJlZi5jdXJyZW50Lm9wZW5FdmVudDtcbiAgICAgIGNvbnN0IGhhc0NsaWNrZWRPbkluYWN0aXZlVHJpZ2dlciA9IHN0b3JlLnNlbGVjdCgnZG9tUmVmZXJlbmNlRWxlbWVudCcpICE9PSBjdXJyZW50VGFyZ2V0O1xuICAgICAgaWYgKG9wZW4gJiYgaGFzQ2xpY2tlZE9uSW5hY3RpdmVUcmlnZ2VyKSB7XG4gICAgICAgIC8vIE1vdmluZyBiZXR3ZWVuIHRyaWdnZXJzIHNob3VsZCBhbHdheXMgb3BlbiB0aGUgbmV3bHkgYWN0aXZlIG9uZS5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoIW9wZW4pIHtcbiAgICAgICAgLy8gQSBjbG9zZWQgcG9wdXAgc2hvdWxkIG9wZW4gb24gdGhlIG5leHQgcHJlc3MuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKCF0b2dnbGUpIHtcbiAgICAgICAgLy8gTm9uLXRvZ2dsZSBtb2RlIG5ldmVyIGNsb3NlcyBvbiBhIHJlcGVhdGVkIHRyaWdnZXIgcHJlc3MuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKG9wZW5FdmVudCAmJiAodHlwZW9mIHN0aWNrSWZPcGVuID09PSAnZnVuY3Rpb24nID8gc3RpY2tJZk9wZW4oKSA6IHN0aWNrSWZPcGVuKSkge1xuICAgICAgICAvLyBQcmVzZXJ2ZSBob3Zlci9mb2N1cy1vcGVuZWQgcG9wdXBzIHVudGlsIHRoZSBtYXRjaGluZyBjbGljay1saWtlIGV2ZW50IGNsb3NlcyB0aGVtLlxuICAgICAgICByZXR1cm4gIWlzQ2xpY2tMaWtlT3BlbkV2ZW50KG9wZW5FdmVudC50eXBlKTtcbiAgICAgIH1cblxuICAgICAgLy8gT3RoZXJ3aXNlLCBhIHJlcGVhdGVkIGNsaWNrIHRvZ2dsZXMgdGhlIHBvcHVwIGNsb3NlZC5cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIG9uUG9pbnRlckRvd24oZXZlbnQpIHtcbiAgICAgICAgLy8gU2NyZWVuIHJlYWRlciBhY3RpdmF0aW9ucyAoQW5kcm9pZCBUYWxrQmFjaywgZGVza3RvcCBzY3JlZW4gcmVhZGVycykgcmVwb3J0IGFcbiAgICAgICAgLy8gbW91c2UtbGlrZSBgcG9pbnRlclR5cGVgLCBidXQgYGlnbm9yZU1vdXNlYCBtdXN0IG5vdCBkcm9wIHRoZW06IGhvdmVyIGxvZ2ljIGNhbm5vdFxuICAgICAgICAvLyBvcGVuIGZvciBhIHZpcnR1YWwgcHJlc3Mgc2luY2UgdGhlcmUgaXMgbm8gcmVhbCBwb2ludGVyIG1vdmVtZW50IHRvIHdhaXQgZm9yLlxuICAgICAgICAvLyBWaXJ0dWFsIGB0b3VjaGAgcHJlc3NlcyAoaU9TIFZvaWNlT3Zlcikga2VlcCB0aGVpciB0eXBlIHNvIGB0b3VjaE9wZW5EZWxheWAgYXBwbGllcy5cbiAgICAgICAgcG9pbnRlclR5cGVSZWYuY3VycmVudCA9IGlzTW91c2VMaWtlUG9pbnRlclR5cGUoZXZlbnQucG9pbnRlclR5cGUsIHRydWUpICYmIGlzVmlydHVhbFBvaW50ZXJFdmVudChldmVudC5uYXRpdmVFdmVudCkgPyAndmlydHVhbCcgOiBldmVudC5wb2ludGVyVHlwZTtcbiAgICAgIH0sXG4gICAgICBvbk1vdXNlRG93bihldmVudCkge1xuICAgICAgICBjb25zdCBwb2ludGVyVHlwZSA9IHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQ7XG4gICAgICAgIGNvbnN0IG5hdGl2ZUV2ZW50ID0gZXZlbnQubmF0aXZlRXZlbnQ7XG4gICAgICAgIGNvbnN0IG9wZW4gPSBzdG9yZS5zZWxlY3QoJ29wZW4nKTtcblxuICAgICAgICAvLyBJZ25vcmUgYWxsIGJ1dHRvbnMgZXhjZXB0IGZvciB0aGUgXCJtYWluXCIgYnV0dG9uLlxuICAgICAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvTW91c2VFdmVudC9idXR0b25cbiAgICAgICAgaWYgKGV2ZW50LmJ1dHRvbiAhPT0gMCB8fCBldmVudE9wdGlvbiA9PT0gJ2NsaWNrJyB8fCBpc01vdXNlTGlrZVBvaW50ZXJUeXBlKHBvaW50ZXJUeXBlLCB0cnVlKSAmJiBpZ25vcmVNb3VzZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuZXh0T3BlbiA9IGdldE5leHRPcGVuKG9wZW4sIGV2ZW50LmN1cnJlbnRUYXJnZXQsIG9wZW5FdmVudFR5cGUgPT4gb3BlbkV2ZW50VHlwZSA9PT0gJ2NsaWNrJyB8fCBvcGVuRXZlbnRUeXBlID09PSAnbW91c2Vkb3duJyk7XG5cbiAgICAgICAgLy8gQW5pbWF0aW9ucyBzb21ldGltZXMgd29uJ3QgcnVuIG9uIGEgdHlwZWFibGUgZWxlbWVudCBpZiB1c2luZyBhIHJBRi5cbiAgICAgICAgLy8gRm9jdXMgaXMgYWx3YXlzIHNldCBvbiB0aGVzZSBlbGVtZW50cy4gRm9yIHRvdWNoLCB3ZSBtYXkgZGVsYXkgb3BlbmluZy5cbiAgICAgICAgLy8gQSBzY3JlZW4gcmVhZGVyIHByZXNzIG9wZW5zIHN5bmNocm9ub3VzbHksIHNvIHRoZSBwb3B1cCdzIGZvY3VzIGxhbmRzIGJlZm9yZSB0aGUgcmVhZGVyXG4gICAgICAgIC8vIHJlLXN5bmNzIGZvY3VzIHRvIGl0cyBjdXJzb3IsIHdoaWNoIHdvdWxkIG90aGVyd2lzZSByZWFkIGFzIGEgc3RyYXkgbW92ZS5cbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KG5hdGl2ZUV2ZW50KTtcbiAgICAgICAgY29uc3QgaXNUeXBlYWJsZSA9IGlzVHlwZWFibGVFbGVtZW50KHRhcmdldCk7XG4gICAgICAgIGlmIChpc1R5cGVhYmxlIHx8IHBvaW50ZXJUeXBlID09PSAndmlydHVhbCcpIHtcbiAgICAgICAgICAvLyBBIHZpcnR1YWwgcHJlc3MgbWF5IHRhcmdldCBhIGRlc2NlbmRhbnQgb2YgdGhlIHRyaWdnZXI7IHRoZSB0cmlnZ2VyIGlzIHdoYXQgb3BlbmVkLlxuICAgICAgICAgIHNldE9wZW5XaXRoVG91Y2hEZWxheShuZXh0T3BlbiwgbmF0aXZlRXZlbnQsIGlzVHlwZWFibGUgPyB0YXJnZXQgOiBldmVudC5jdXJyZW50VGFyZ2V0LCBwb2ludGVyVHlwZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQ2FwdHVyZSB0aGUgY3VycmVudFRhcmdldCBiZWZvcmUgdGhlIHJBRi5cbiAgICAgICAgLy8gYXMgUmVhY3Qgc2V0cyBpdCB0byBudWxsIGFmdGVyIHRoZSBldmVudCBoYW5kbGVyIGNvbXBsZXRlcy5cbiAgICAgICAgY29uc3QgZXZlbnRDdXJyZW50VGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcblxuICAgICAgICAvLyBXYWl0IHVudGlsIGZvY3VzIGlzIHNldCBvbiB0aGUgZWxlbWVudC4gVGhpcyBpcyBhbiBhbHRlcm5hdGl2ZSB0b1xuICAgICAgICAvLyBgZXZlbnQucHJldmVudERlZmF1bHQoKWAgdG8gYXZvaWQgOmZvY3VzLXZpc2libGUgZnJvbSBhcHBlYXJpbmcgd2hlbiB1c2luZyBhIHBvaW50ZXIuXG4gICAgICAgIGZyYW1lLnJlcXVlc3QoKCkgPT4ge1xuICAgICAgICAgIHNldE9wZW5XaXRoVG91Y2hEZWxheShuZXh0T3BlbiwgbmF0aXZlRXZlbnQsIGV2ZW50Q3VycmVudFRhcmdldCwgcG9pbnRlclR5cGUpO1xuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICBvbkNsaWNrKGV2ZW50KSB7XG4gICAgICAgIGlmIChldmVudE9wdGlvbiA9PT0gJ21vdXNlZG93bi1vbmx5Jykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwb2ludGVyVHlwZSA9IHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmIChldmVudE9wdGlvbiA9PT0gJ21vdXNlZG93bicgJiYgcG9pbnRlclR5cGUpIHtcbiAgICAgICAgICBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gdW5kZWZpbmVkO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZSwgdHJ1ZSkgJiYgaWdub3JlTW91c2UpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb3BlbiA9IHN0b3JlLnNlbGVjdCgnb3BlbicpO1xuICAgICAgICBjb25zdCBuZXh0T3BlbiA9IGdldE5leHRPcGVuKG9wZW4sIGV2ZW50LmN1cnJlbnRUYXJnZXQsIG9wZW5FdmVudFR5cGUgPT4gb3BlbkV2ZW50VHlwZSA9PT0gJ2NsaWNrJyB8fCBvcGVuRXZlbnRUeXBlID09PSAnbW91c2Vkb3duJyB8fCBvcGVuRXZlbnRUeXBlID09PSAna2V5ZG93bicgfHwgb3BlbkV2ZW50VHlwZSA9PT0gJ2tleXVwJyk7XG4gICAgICAgIHNldE9wZW5XaXRoVG91Y2hEZWxheShuZXh0T3BlbiwgZXZlbnQubmF0aXZlRXZlbnQsIGV2ZW50LmN1cnJlbnRUYXJnZXQsIHBvaW50ZXJUeXBlKTtcbiAgICAgIH0sXG4gICAgICBvbktleURvd24oKSB7XG4gICAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2RhdGFSZWYsIGV2ZW50T3B0aW9uLCBpZ25vcmVNb3VzZSwgcmVhc29uLCBzdG9yZSwgc3RpY2tJZk9wZW4sIHRvZ2dsZSwgZnJhbWUsIHRvdWNoT3BlblRpbWVvdXQsIHRvdWNoT3BlbkRlbGF5XSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgcmVmZXJlbmNlXG4gIH0gOiBFTVBUWV9PQkpFQ1QsIFtlbmFibGVkLCByZWZlcmVuY2VdKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbi8qIGVzbGludC1kaXNhYmxlIG5vLXVuZGVyc2NvcmUtZGFuZ2xlICovXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyBtZXJnZUNsZWFudXBzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvbWVyZ2VDbGVhbnVwcyc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyBUaW1lb3V0LCB1c2VUaW1lb3V0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVGltZW91dCc7XG5pbXBvcnQgeyBnZXRDb21wdXRlZFN0eWxlLCBnZXRQYXJlbnROb2RlLCBpc0VsZW1lbnQsIGlzSFRNTEVsZW1lbnQsIGlzTGFzdFRyYXZlcnNhYmxlTm9kZSwgaXNTaGFkb3dSb290IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IHVzZUZsb2F0aW5nVHJlZSB9IGZyb20gXCIuLi9jb21wb25lbnRzL0Zsb2F0aW5nVHJlZS5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUF0dHJpYnV0ZSB9IGZyb20gXCIuLi91dGlscy9jcmVhdGVBdHRyaWJ1dGUubWpzXCI7XG5pbXBvcnQgeyBjb250YWlucywgZ2V0VGFyZ2V0LCBpc0V2ZW50VGFyZ2V0V2l0aGluLCBpc1Jvb3RFbGVtZW50IH0gZnJvbSBcIi4uL3V0aWxzL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc1JlYWN0RXZlbnQsIGlzVmlydHVhbENsaWNrIH0gZnJvbSBcIi4uL3V0aWxzL2V2ZW50Lm1qc1wiO1xuaW1wb3J0IHsgZ2V0Tm9kZUNoaWxkcmVuIH0gZnJvbSBcIi4uL3V0aWxzL25vZGVzLm1qc1wiO1xuZnVuY3Rpb24gYWx3YXlzRmFsc2UoKSB7XG4gIHJldHVybiBmYWxzZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVQcm9wKG5vcm1hbGl6YWJsZSkge1xuICByZXR1cm4ge1xuICAgIGVzY2FwZUtleTogdHlwZW9mIG5vcm1hbGl6YWJsZSA9PT0gJ2Jvb2xlYW4nID8gbm9ybWFsaXphYmxlIDogbm9ybWFsaXphYmxlPy5lc2NhcGVLZXkgPz8gZmFsc2UsXG4gICAgb3V0c2lkZVByZXNzOiB0eXBlb2Ygbm9ybWFsaXphYmxlID09PSAnYm9vbGVhbicgPyBub3JtYWxpemFibGUgOiBub3JtYWxpemFibGU/Lm91dHNpZGVQcmVzcyA/PyB0cnVlXG4gIH07XG59XG4vKipcbiAqIENsb3NlcyB0aGUgZmxvYXRpbmcgZWxlbWVudCB3aGVuIGEgZGlzbWlzc2FsIGlzIHJlcXVlc3RlZCDigJQgYnkgZGVmYXVsdCwgd2hlblxuICogdGhlIHVzZXIgcHJlc3NlcyB0aGUgYGVzY2FwZWAga2V5IG9yIG91dHNpZGUgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlRGlzbWlzc1xuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRGlzbWlzcyhzdG9yZSwgcHJvcHMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZW5hYmxlZCA9IHRydWUsXG4gICAgZXNjYXBlS2V5ID0gdHJ1ZSxcbiAgICBvdXRzaWRlUHJlc3M6IG91dHNpZGVQcmVzc1Byb3AgPSB0cnVlLFxuICAgIG91dHNpZGVQcmVzc0V2ZW50ID0gJ3Nsb3BweScsXG4gICAgcmVmZXJlbmNlUHJlc3MgPSBhbHdheXNGYWxzZSxcbiAgICBidWJibGVzLFxuICAgIGV4dGVybmFsVHJlZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBmbG9hdGluZ0VsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdFbGVtZW50Jyk7XG4gIGNvbnN0IHtcbiAgICBkYXRhUmVmLFxuICAgIGV2ZW50c1xuICB9ID0gc3RvcmUuY29udGV4dDtcbiAgY29uc3QgdHJlZSA9IHVzZUZsb2F0aW5nVHJlZShleHRlcm5hbFRyZWUpO1xuICBjb25zdCBvdXRzaWRlUHJlc3NGbiA9IHVzZVN0YWJsZUNhbGxiYWNrKHR5cGVvZiBvdXRzaWRlUHJlc3NQcm9wID09PSAnZnVuY3Rpb24nID8gb3V0c2lkZVByZXNzUHJvcCA6ICgpID0+IGZhbHNlKTtcbiAgY29uc3Qgb3V0c2lkZVByZXNzID0gdHlwZW9mIG91dHNpZGVQcmVzc1Byb3AgPT09ICdmdW5jdGlvbicgPyBvdXRzaWRlUHJlc3NGbiA6IG91dHNpZGVQcmVzc1Byb3A7XG4gIGNvbnN0IG91dHNpZGVQcmVzc0VuYWJsZWQgPSBvdXRzaWRlUHJlc3MgIT09IGZhbHNlO1xuICBjb25zdCBnZXRPdXRzaWRlUHJlc3NFdmVudFByb3AgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiBvdXRzaWRlUHJlc3NFdmVudCk7XG4gIGNvbnN0IHtcbiAgICBlc2NhcGVLZXk6IGVzY2FwZUtleUJ1YmJsZXMsXG4gICAgb3V0c2lkZVByZXNzOiBvdXRzaWRlUHJlc3NCdWJibGVzXG4gIH0gPSBub3JtYWxpemVQcm9wKGJ1YmJsZXMpO1xuICBjb25zdCBwcmVzc1N0YXJ0ZWRJbnNpZGVSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBwcmVzc1N0YXJ0UHJldmVudGVkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgLy8gSWdub3JlIG9ubHkgdGhlIHZlcnkgbmV4dCBvdXRzaWRlIGNsaWNrIGFmdGVyIGRyYWdnaW5nIGZyb20gaW5zaWRlIHRvIG91dHNpZGUuXG4gIGNvbnN0IHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIC8vIEEgY2xpY2sgd2hvc2UgcHJlc3MgYmVnYW4gYmVmb3JlIHRoZSBmbG9hdGluZyBlbGVtZW50IG9wZW5lZCBpcyB0aGUgdGFpbCBvZiB0aGF0XG4gIC8vIGdlc3R1cmUgKGUuZy4gdGhlIGRyYWctcmVsZWFzZSB0aGF0IG9wZW5lZCBpdCksIG5vdCBhIG5ldyBvdXRzaWRlIHByZXNzLlxuICBjb25zdCBzYXdQcmVzc1doaWxlT3BlblJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGlzQ29tcG9zaW5nUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgY3VycmVudFBvaW50ZXJUeXBlUmVmID0gUmVhY3QudXNlUmVmKCcnKTtcbiAgY29uc3QgdG91Y2hTdGF0ZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgY2FuY2VsRGlzbWlzc09uRW5kVGltZW91dCA9IHVzZVRpbWVvdXQoKTtcbiAgY29uc3QgY2xlYXJJbnNpZGVSZWFjdFRyZWVUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICAvLyBPdXRsaXZlcyBlZmZlY3QgcmUtcnVucyBzbyBhIHBlbmRpbmcgcmVzZXQgY2FuJ3QgbGVhdmUgYGlzQ29tcG9zaW5nUmVmYCBzdHVjay5cbiAgY29uc3QgY29tcG9zaXRpb25UaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBjbGVhckluc2lkZVJlYWN0VHJlZSA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjbGVhckluc2lkZVJlYWN0VHJlZVRpbWVvdXQuY2xlYXIoKTtcbiAgICBkYXRhUmVmLmN1cnJlbnQuaW5zaWRlUmVhY3RUcmVlID0gZmFsc2U7XG4gIH0pO1xuICBjb25zdCBoYXNCbG9ja2luZ0NoaWxkID0gdXNlU3RhYmxlQ2FsbGJhY2soYnViYmxlS2V5ID0+IHtcbiAgICBjb25zdCBub2RlSWQgPSBkYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0Py5ub2RlSWQ7XG4gICAgY29uc3QgY2hpbGRyZW4gPSB0cmVlID8gZ2V0Tm9kZUNoaWxkcmVuKHRyZWUubm9kZXNSZWYuY3VycmVudCwgbm9kZUlkKSA6IFtdO1xuICAgIHJldHVybiBjaGlsZHJlbi5zb21lKGNoaWxkID0+IGNoaWxkLmNvbnRleHQ/Lm9wZW4gJiYgIWNoaWxkLmNvbnRleHQuZGF0YVJlZi5jdXJyZW50W2J1YmJsZUtleV0pO1xuICB9KTtcbiAgY29uc3QgaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzID0gdXNlU3RhYmxlQ2FsbGJhY2soZXZlbnQgPT4ge1xuICAgIHJldHVybiBpc0V2ZW50VGFyZ2V0V2l0aGluKGV2ZW50LCBzdG9yZS5zZWxlY3QoJ2Zsb2F0aW5nRWxlbWVudCcpKSB8fCBpc0V2ZW50VGFyZ2V0V2l0aGluKGV2ZW50LCBzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKSk7XG4gIH0pO1xuICBjb25zdCBjbG9zZU9uUmVmZXJlbmNlUHJlc3MgPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKCFyZWZlcmVuY2VQcmVzcygpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJQcmVzcywgZXZlbnQubmF0aXZlRXZlbnQpKTtcbiAgfSk7XG4gIGNvbnN0IGNsb3NlT25Fc2NhcGVLZXlEb3duID0gdXNlU3RhYmxlQ2FsbGJhY2soZXZlbnQgPT4ge1xuICAgIGlmICghb3BlbiB8fCAhZW5hYmxlZCB8fCAhZXNjYXBlS2V5IHx8IGV2ZW50LmtleSAhPT0gJ0VzY2FwZScpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbmF0aXZlID0gaXNSZWFjdEV2ZW50KGV2ZW50KSA/IGV2ZW50Lm5hdGl2ZUV2ZW50IDogZXZlbnQ7XG5cbiAgICAvLyBXYWl0IHVudGlsIElNRSBpcyBzZXR0bGVkLiBQcmVzc2luZyBgRXNjYXBlYCB3aGlsZSBjb21wb3Npbmcgc2hvdWxkXG4gICAgLy8gY2xvc2UgdGhlIGNvbXBvc2UgbWVudSwgYnV0IG5vdCB0aGUgZmxvYXRpbmcgZWxlbWVudC4gVGhlIHJlZiBjb3ZlcnMgU2FmYXJpLCB3aGljaCBmaXJlc1xuICAgIC8vIGBjb21wb3NpdGlvbmVuZGAgYmVmb3JlIGBrZXlkb3duYDsgYGlzQ29tcG9zaW5nYCBjb3ZlcnMgY29tcG9zaXRpb25zIHRoYXQgYmVnYW4gd2hpbGUgY2xvc2VkLlxuICAgIGlmIChpc0NvbXBvc2luZ1JlZi5jdXJyZW50IHx8IG5hdGl2ZS5pc0NvbXBvc2luZykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIWVzY2FwZUtleUJ1YmJsZXMgJiYgaGFzQmxvY2tpbmdDaGlsZCgnX19lc2NhcGVLZXlCdWJibGVzJykpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZXZlbnREZXRhaWxzID0gY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuZXNjYXBlS2V5LCBuYXRpdmUpO1xuICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGV2ZW50RGV0YWlscyk7XG4gICAgaWYgKCFldmVudERldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICB9XG4gICAgaWYgKCFlc2NhcGVLZXlCdWJibGVzICYmICFldmVudERldGFpbHMuaXNQcm9wYWdhdGlvbkFsbG93ZWQpIHtcbiAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IG1hcmtJbnNpZGVSZWFjdFRyZWUgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgZGF0YVJlZi5jdXJyZW50Lmluc2lkZVJlYWN0VHJlZSA9IHRydWU7XG4gICAgY2xlYXJJbnNpZGVSZWFjdFRyZWVUaW1lb3V0LnN0YXJ0KDAsIGNsZWFySW5zaWRlUmVhY3RUcmVlKTtcbiAgfSk7XG4gIGNvbnN0IG1hcmtQcmVzc1N0YXJ0ZWRJbnNpZGVSZWFjdFRyZWUgPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVkIHx8IGV2ZW50LmJ1dHRvbiAhPT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQubmF0aXZlRXZlbnQpO1xuXG4gICAgLy8gT25seSB0cmVhdCBwcmVzc2VzIHRoYXQgc3RhcnQgd2l0aGluIHRoZSBmbG9hdGluZyBET00gc3VidHJlZSBhcyBpbnNpZGUuXG4gICAgLy8gVGhpcyBhdm9pZHMgc3VwcHJlc3NpbmcgcGFyZW50IGRpc21pc3NhbCB3aGVuIGludGVyYWN0aW5nIHdpdGggbmVzdGVkIHBvcnRhbHMuXG4gICAgaWYgKCFjb250YWlucyhzdG9yZS5zZWxlY3QoJ2Zsb2F0aW5nRWxlbWVudCcpLCB0YXJnZXQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghcHJlc3NTdGFydGVkSW5zaWRlUmVmLmN1cnJlbnQpIHtcbiAgICAgIHByZXNzU3RhcnRlZEluc2lkZVJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHByZXNzU3RhcnRQcmV2ZW50ZWRSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IG1hcmtJbnNpZGVQcmVzc1N0YXJ0UHJldmVudGVkID0gdXNlU3RhYmxlQ2FsbGJhY2soZXZlbnQgPT4ge1xuICAgIGlmICghb3BlbiB8fCAhZW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIShldmVudC5kZWZhdWx0UHJldmVudGVkIHx8IGV2ZW50Lm5hdGl2ZUV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChwcmVzc1N0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCkge1xuICAgICAgcHJlc3NTdGFydFByZXZlbnRlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEEgc2FtZS1iYXRjaCBjbG9zZStyZW9wZW4gbmV2ZXIgcmVuZGVycyBgb3BlbiA9PT0gZmFsc2VgLCBzbyBvbmx5IGBvcGVuY2hhbmdlYCBjYW5cbiAgLy8gb2JzZXJ2ZSB0aGF0IHNlc3Npb24gYm91bmRhcnkuIFRoZSBlZmZlY3QgYmVsb3cgY292ZXJzIGNvbnRyb2xsZWQgZmxpcHMuXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZnVuY3Rpb24gaGFuZGxlT3BlbkNoYW5nZShkZXRhaWxzKSB7XG4gICAgICAvLyBPbmx5IHRoZSBjbG9zaW5nIGhhbGYgZW5kcyB0aGUgc2Vzc2lvbjogYHNldE9wZW4odHJ1ZSlgIG9uIGFuIGFscmVhZHktb3BlblxuICAgICAgLy8gZWxlbWVudCAoaG92ZXJpbmcgYW4gaW5hY3RpdmUgdHJpZ2dlcikgbXVzdCBub3QgZHJvcCBhIHByZXNzIG1pZC1nZXN0dXJlLlxuICAgICAgaWYgKCFkZXRhaWxzLm9wZW4pIHtcbiAgICAgICAgc2F3UHJlc3NXaGlsZU9wZW5SZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICBldmVudHMub24oJ29wZW5jaGFuZ2UnLCBoYW5kbGVPcGVuQ2hhbmdlKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZXZlbnRzLm9mZignb3BlbmNoYW5nZScsIGhhbmRsZU9wZW5DaGFuZ2UpO1xuICAgIH07XG4gIH0sIFtldmVudHNdKTtcblxuICAvLyBOb3QgY2xlYXJlZCBpbiB0aGUgbGlzdGVuZXIgZWZmZWN0J3MgY2xlYW51cCwgd2hpY2ggY2FuIHJ1biBtaWQtcHJlc3Mgd2hlbiBhIGRlcGVuZGVuY3lcbiAgLy8gY2hhbmdlcy4gSW4gYSBjbG9zZWQgc2hhZG93IHJvb3QsIHRoZSBtYXJrZXIgaXMgdGhlIG9ubHkgaW5zaWRlLXByZXNzIHNpZ25hbC5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IGNsZWFySW5zaWRlUmVhY3RUcmVlLCBbY2xlYXJJbnNpZGVSZWFjdFRyZWVdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4gfHwgIWVuYWJsZWQpIHtcbiAgICAgIC8vIFJlc2V0IGluIHRoZSBlZmZlY3QgYm9keSwgbm90IHRoZSBjbGVhbnVwLCB3aGljaCBhbHNvIHJ1bnMgd2hlbiBhIGRlcGVuZGVuY3lcbiAgICAgIC8vIGNoYW5nZXMgbWlkLWdlc3R1cmUuXG4gICAgICBpZiAoIW9wZW4pIHtcbiAgICAgICAgc2F3UHJlc3NXaGlsZU9wZW5SZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBpc0NvbXBvc2luZ1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIGN1cnJlbnRQb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gJyc7XG4gICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICByZXR1cm4gY2xlYXJJbnNpZGVSZWFjdFRyZWU7XG4gICAgfVxuICAgIGRhdGFSZWYuY3VycmVudC5fX2VzY2FwZUtleUJ1YmJsZXMgPSBlc2NhcGVLZXlCdWJibGVzO1xuICAgIGRhdGFSZWYuY3VycmVudC5fX291dHNpZGVQcmVzc0J1YmJsZXMgPSBvdXRzaWRlUHJlc3NCdWJibGVzO1xuICAgIGNvbnN0IHByZXZlbnRlZFByZXNzU3VwcHJlc3Npb25UaW1lb3V0ID0gbmV3IFRpbWVvdXQoKTtcbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KGZsb2F0aW5nRWxlbWVudCk7XG4gICAgZnVuY3Rpb24gaGFuZGxlQ29tcG9zaXRpb25TdGFydCgpIHtcbiAgICAgIGNvbXBvc2l0aW9uVGltZW91dC5jbGVhcigpO1xuICAgICAgaXNDb21wb3NpbmdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZUNvbXBvc2l0aW9uRW5kKCkge1xuICAgICAgLy8gU2FmYXJpIGZpcmVzIGBjb21wb3NpdGlvbmVuZGAgYmVmb3JlIGBrZXlkb3duYCwgc28gd2UgbmVlZCB0byB3YWl0XG4gICAgICAvLyB1bnRpbCB0aGUgbmV4dCB0aWNrIHRvIHNldCBgaXNDb21wb3NpbmdgIHRvIGBmYWxzZWAuIFNldCBpdCBoZXJlIHRvbywgc2luY2UgY2xvc2luZ1xuICAgICAgLy8gcmVzZXRzIGl0IHdoaWxlIGEgY29tcG9zaXRpb24gY2FuIGNvbnRpbnVlIGludG8gdGhlIG5leHQgb3BlbiBzZXNzaW9uLlxuICAgICAgLy8gaHR0cHM6Ly9idWdzLndlYmtpdC5vcmcvc2hvd19idWcuY2dpP2lkPTE2NTAwNFxuICAgICAgaXNDb21wb3NpbmdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICBjb21wb3NpdGlvblRpbWVvdXQuc3RhcnQoXG4gICAgICAvLyAwbXMgb3IgMW1zIGRvbid0IHdvcmsgaW4gU2FmYXJpLiA1bXMgYXBwZWFycyB0byBjb25zaXN0ZW50bHkgd29yay5cbiAgICAgIC8vIE9ubHkgYXBwbHkgdG8gV2ViS2l0IGZvciB0aGUgdGVzdCB0byByZW1haW4gMG1zLlxuICAgICAgcGxhdGZvcm0uZW5naW5lLndlYmtpdCA/IDUgOiAwLCAoKSA9PiB7XG4gICAgICAgIGlzQ29tcG9zaW5nUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBzdXBwcmVzc0ltbWVkaWF0ZU91dHNpZGVDbGlja0FmdGVyUHJldmVudGVkU3RhcnQoKSB7XG4gICAgICBzdXBwcmVzc05leHRPdXRzaWRlQ2xpY2tSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAvLyBGaXJlZm94IGNhbiBlbWl0IHRoZSBzeW50aGV0aWMgb3V0c2lkZSBjbGljayBpbiBhIGxhdGVyIHRhc2sgYWZ0ZXJcbiAgICAgIC8vIHBvaW50ZXIgbG9jayBleGl0LCBzbyBtaWNyb3Rhc2sgY2xlYXJpbmcgaXMgdG9vIGVhcmx5IGhlcmUuXG4gICAgICBwcmV2ZW50ZWRQcmVzc1N1cHByZXNzaW9uVGltZW91dC5zdGFydCgwLCAoKSA9PiB7XG4gICAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVzZXRQcmVzc1N0YXJ0U3RhdGUoKSB7XG4gICAgICBwcmVzc1N0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgcHJlc3NTdGFydFByZXZlbnRlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldE91dHNpZGVQcmVzc0V2ZW50KCkge1xuICAgICAgY29uc3QgdHlwZSA9IGN1cnJlbnRQb2ludGVyVHlwZVJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgY29tcHV0ZWRUeXBlID0gdHlwZSA9PT0gJ3BlbicgfHwgIXR5cGUgPyAnbW91c2UnIDogdHlwZTtcbiAgICAgIGNvbnN0IG91dHNpZGVQcmVzc0V2ZW50VmFsdWUgPSBnZXRPdXRzaWRlUHJlc3NFdmVudFByb3AoKTtcbiAgICAgIGNvbnN0IHJlc29sdmVkID0gdHlwZW9mIG91dHNpZGVQcmVzc0V2ZW50VmFsdWUgPT09ICdmdW5jdGlvbicgPyBvdXRzaWRlUHJlc3NFdmVudFZhbHVlKCkgOiBvdXRzaWRlUHJlc3NFdmVudFZhbHVlO1xuICAgICAgaWYgKHR5cGVvZiByZXNvbHZlZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgcmV0dXJuIHJlc29sdmVkO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc29sdmVkW2NvbXB1dGVkVHlwZV07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHNob3VsZElnbm9yZUV2ZW50KGV2ZW50KSB7XG4gICAgICBjb25zdCBjb21wdXRlZE91dHNpZGVQcmVzc0V2ZW50ID0gZ2V0T3V0c2lkZVByZXNzRXZlbnQoKTtcbiAgICAgIHJldHVybiBjb21wdXRlZE91dHNpZGVQcmVzc0V2ZW50ID09PSAnaW50ZW50aW9uYWwnICYmIGV2ZW50LnR5cGUgIT09ICdjbGljaycgfHwgY29tcHV0ZWRPdXRzaWRlUHJlc3NFdmVudCA9PT0gJ3Nsb3BweScgJiYgZXZlbnQudHlwZSA9PT0gJ2NsaWNrJztcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNFdmVudFdpdGhpbkZsb2F0aW5nVHJlZShldmVudCkge1xuICAgICAgY29uc3Qgbm9kZUlkID0gZGF0YVJlZi5jdXJyZW50LmZsb2F0aW5nQ29udGV4dD8ubm9kZUlkO1xuICAgICAgY29uc3QgdGFyZ2V0SXNJbnNpZGVDaGlsZHJlbiA9IHRyZWUgJiYgZ2V0Tm9kZUNoaWxkcmVuKHRyZWUubm9kZXNSZWYuY3VycmVudCwgbm9kZUlkKS5zb21lKG5vZGUgPT4gaXNFdmVudFRhcmdldFdpdGhpbihldmVudCwgbm9kZS5jb250ZXh0Py5lbGVtZW50cy5mbG9hdGluZykpO1xuICAgICAgcmV0dXJuIGlzRXZlbnRXaXRoaW5Pd25FbGVtZW50cyhldmVudCkgfHwgdGFyZ2V0SXNJbnNpZGVDaGlsZHJlbjtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2xvc2VPblByZXNzT3V0c2lkZShldmVudCkge1xuICAgICAgaWYgKHNob3VsZElnbm9yZUV2ZW50KGV2ZW50KSkge1xuICAgICAgICAvLyBBIG5ldyBwcmVzcyBiZWdhbiBvdXRzaWRlIHRoZSBmbG9hdGluZyBlbGVtZW50IGFuZCBpdHMgdHJpZ2dlci4gQ2xlYXIgYW55XG4gICAgICAgIC8vIGxlZnRvdmVyIGRyYWctb3V0IHN1cHByZXNzaW9uIHNvIHRoaXMgcHJlc3MncyBldmVudHVhbCBjbGljayBjYW4gZGlzbWlzcy5cbiAgICAgICAgaWYgKGV2ZW50LnR5cGUgIT09ICdjbGljaycgJiYgIWlzRXZlbnRXaXRoaW5Pd25FbGVtZW50cyhldmVudCkpIHtcbiAgICAgICAgICBwcmV2ZW50ZWRQcmVzc1N1cHByZXNzaW9uVGltZW91dC5jbGVhcigpO1xuICAgICAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgY2xlYXJJbnNpZGVSZWFjdFRyZWUoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGRhdGFSZWYuY3VycmVudC5pbnNpZGVSZWFjdFRyZWUpIHtcbiAgICAgICAgY2xlYXJJbnNpZGVSZWFjdFRyZWUoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGNvbnN0IGluZXJ0U2VsZWN0b3IgPSBgWyR7Y3JlYXRlQXR0cmlidXRlKCdpbmVydCcpfV1gO1xuICAgICAgY29uc3QgdGFyZ2V0Um9vdCA9IGlzRWxlbWVudCh0YXJnZXQpID8gdGFyZ2V0LmdldFJvb3ROb2RlKCkgOiBudWxsO1xuICAgICAgY29uc3QgbWFya2VycyA9IEFycmF5LmZyb20oKGlzU2hhZG93Um9vdCh0YXJnZXRSb290KSA/IHRhcmdldFJvb3QgOiBvd25lckRvY3VtZW50KHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdFbGVtZW50JykpKS5xdWVyeVNlbGVjdG9yQWxsKGluZXJ0U2VsZWN0b3IpKTtcbiAgICAgIGNvbnN0IHRyaWdnZXJzID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHM7XG5cbiAgICAgIC8vIElmIGFub3RoZXIgdHJpZ2dlciBpcyBjbGlja2VkLCBkb24ndCBjbG9zZSB0aGUgZmxvYXRpbmcgZWxlbWVudC5cbiAgICAgIGlmICh0YXJnZXQgJiYgKHRyaWdnZXJzLmhhc0VsZW1lbnQodGFyZ2V0KSB8fCB0cmlnZ2Vycy5oYXNNYXRjaGluZ0VsZW1lbnQodHJpZ2dlciA9PiBjb250YWlucyh0cmlnZ2VyLCB0YXJnZXQpKSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGV0IHRhcmdldFJvb3RBbmNlc3RvciA9IGlzRWxlbWVudCh0YXJnZXQpID8gdGFyZ2V0IDogbnVsbDtcbiAgICAgIHdoaWxlICh0YXJnZXRSb290QW5jZXN0b3IgJiYgIWlzTGFzdFRyYXZlcnNhYmxlTm9kZSh0YXJnZXRSb290QW5jZXN0b3IpKSB7XG4gICAgICAgIGNvbnN0IG5leHRQYXJlbnQgPSBnZXRQYXJlbnROb2RlKHRhcmdldFJvb3RBbmNlc3Rvcik7XG4gICAgICAgIGlmIChpc0xhc3RUcmF2ZXJzYWJsZU5vZGUobmV4dFBhcmVudCkgfHwgIWlzRWxlbWVudChuZXh0UGFyZW50KSkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHRhcmdldFJvb3RBbmNlc3RvciA9IG5leHRQYXJlbnQ7XG4gICAgICB9XG5cbiAgICAgIC8vIENoZWNrIGlmIHRoZSBjbGljayBvY2N1cnJlZCBvbiBhIHRoaXJkLXBhcnR5IGVsZW1lbnQgaW5qZWN0ZWQgYWZ0ZXIgdGhlXG4gICAgICAvLyBmbG9hdGluZyBlbGVtZW50IHJlbmRlcmVkLlxuICAgICAgaWYgKG1hcmtlcnMubGVuZ3RoICYmIGlzRWxlbWVudCh0YXJnZXQpICYmICFpc1Jvb3RFbGVtZW50KHRhcmdldCkgJiZcbiAgICAgIC8vIENsaWNrZWQgb24gYSBkaXJlY3QgYW5jZXN0b3IgKGUuZy4gRmxvYXRpbmdPdmVybGF5KS5cbiAgICAgICFjb250YWlucyh0YXJnZXQsIHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdFbGVtZW50JykpICYmXG4gICAgICAvLyBJZiB0aGUgdGFyZ2V0IHJvb3QgZWxlbWVudCBjb250YWlucyBub25lIG9mIHRoZSBtYXJrZXJzLCB0aGVuIHRoZVxuICAgICAgLy8gZWxlbWVudCB3YXMgaW5qZWN0ZWQgYWZ0ZXIgdGhlIGZsb2F0aW5nIGVsZW1lbnQgcmVuZGVyZWQuXG4gICAgICBtYXJrZXJzLmV2ZXJ5KG1hcmtlciA9PiAhY29udGFpbnModGFyZ2V0Um9vdEFuY2VzdG9yLCBtYXJrZXIpKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIENoZWNrIGlmIHRoZSBjbGljayBvY2N1cnJlZCBvbiB0aGUgc2Nyb2xsYmFyXG4gICAgICAvLyBTa2lwIGZvciB0b3VjaCBldmVudHM6IHNjcm9sbGJhcnMgZG9uJ3QgcmVjZWl2ZSB0b3VjaCBldmVudHMgb24gbW9zdCBwbGF0Zm9ybXNcbiAgICAgIGlmIChpc0hUTUxFbGVtZW50KHRhcmdldCkgJiYgISgndG91Y2hlcycgaW4gZXZlbnQpKSB7XG4gICAgICAgIGNvbnN0IGxhc3RUcmF2ZXJzYWJsZU5vZGUgPSBpc0xhc3RUcmF2ZXJzYWJsZU5vZGUodGFyZ2V0KTtcbiAgICAgICAgY29uc3Qgc3R5bGUgPSBnZXRDb21wdXRlZFN0eWxlKHRhcmdldCk7XG4gICAgICAgIGNvbnN0IHNjcm9sbFJlID0gL2F1dG98c2Nyb2xsLztcbiAgICAgICAgY29uc3QgaXNTY3JvbGxhYmxlWCA9IGxhc3RUcmF2ZXJzYWJsZU5vZGUgfHwgc2Nyb2xsUmUudGVzdChzdHlsZS5vdmVyZmxvd1gpO1xuICAgICAgICBjb25zdCBpc1Njcm9sbGFibGVZID0gbGFzdFRyYXZlcnNhYmxlTm9kZSB8fCBzY3JvbGxSZS50ZXN0KHN0eWxlLm92ZXJmbG93WSk7XG4gICAgICAgIGNvbnN0IGNhblNjcm9sbFggPSBpc1Njcm9sbGFibGVYICYmIHRhcmdldC5jbGllbnRXaWR0aCA+IDAgJiYgdGFyZ2V0LnNjcm9sbFdpZHRoID4gdGFyZ2V0LmNsaWVudFdpZHRoO1xuICAgICAgICBjb25zdCBjYW5TY3JvbGxZID0gaXNTY3JvbGxhYmxlWSAmJiB0YXJnZXQuY2xpZW50SGVpZ2h0ID4gMCAmJiB0YXJnZXQuc2Nyb2xsSGVpZ2h0ID4gdGFyZ2V0LmNsaWVudEhlaWdodDtcbiAgICAgICAgY29uc3QgaXNSVEwgPSBzdHlsZS5kaXJlY3Rpb24gPT09ICdydGwnO1xuXG4gICAgICAgIC8vIENoZWNrIGNsaWNrIHBvc2l0aW9uIHJlbGF0aXZlIHRvIHNjcm9sbGJhci5cbiAgICAgICAgLy8gSW4gc29tZSBicm93c2VycyBpdCBpcyBwb3NzaWJsZSB0byBjaGFuZ2UgdGhlIDxib2R5PiAob3Igd2luZG93KVxuICAgICAgICAvLyBzY3JvbGxiYXIgdG8gdGhlIGxlZnQgc2lkZSwgYnV0IGlzIHZlcnkgcmFyZSBhbmQgaXMgZGlmZmljdWx0IHRvXG4gICAgICAgIC8vIGNoZWNrIGZvci4gUGx1cywgZm9yIG1vZGFsIGRpYWxvZ3Mgd2l0aCBiYWNrZHJvcHMsIGl0IGlzIG1vcmVcbiAgICAgICAgLy8gaW1wb3J0YW50IHRoYXQgdGhlIGJhY2tkcm9wIGlzIGNoZWNrZWQgYnV0IG5vdCBzbyBtdWNoIHRoZSB3aW5kb3cuXG4gICAgICAgIGNvbnN0IHByZXNzZWRWZXJ0aWNhbFNjcm9sbGJhciA9IGNhblNjcm9sbFkgJiYgKGlzUlRMID8gZXZlbnQub2Zmc2V0WCA8PSB0YXJnZXQub2Zmc2V0V2lkdGggLSB0YXJnZXQuY2xpZW50V2lkdGggOiBldmVudC5vZmZzZXRYID4gdGFyZ2V0LmNsaWVudFdpZHRoKTtcbiAgICAgICAgY29uc3QgcHJlc3NlZEhvcml6b250YWxTY3JvbGxiYXIgPSBjYW5TY3JvbGxYICYmIGV2ZW50Lm9mZnNldFkgPiB0YXJnZXQuY2xpZW50SGVpZ2h0O1xuICAgICAgICBpZiAocHJlc3NlZFZlcnRpY2FsU2Nyb2xsYmFyIHx8IHByZXNzZWRIb3Jpem9udGFsU2Nyb2xsYmFyKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoaXNFdmVudFdpdGhpbkZsb2F0aW5nVHJlZShldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBPbmx5IGBjbGlja2AgZXZlbnRzIHJlYWNoIHRoaXMgcG9pbnQgaW4gaW50ZW50aW9uYWwgbW9kZS5cbiAgICAgIGlmIChnZXRPdXRzaWRlUHJlc3NFdmVudCgpID09PSAnaW50ZW50aW9uYWwnKSB7XG4gICAgICAgIC8vIFByZXNzLWxlc3MgY2xpY2tzIChrZXlib2FyZCwgYXNzaXN0aXZlIHRlY2hub2xvZ3ksIGBlbGVtZW50LmNsaWNrKClgKSByZXBvcnQgbm9cbiAgICAgICAgLy8gY2xpY2sgY291bnQ7IGBpc1ZpcnR1YWxDbGlja2AgYWxzbyBjYXRjaGVzIHRoZSBvbmVzIHRoYXQgZG8uXG4gICAgICAgIGlmIChldmVudC5kZXRhaWwgIT09IDAgJiYgIWlzVmlydHVhbENsaWNrKGV2ZW50KSAmJiAhc2F3UHJlc3NXaGlsZU9wZW5SZWYuY3VycmVudCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEEgcHJlc3MgdGhhdCBzdGFydHMgaW5zaWRlIGFuZCBlbmRzIG91dHNpZGUgZ2V0cyBvbmUgc3VwcHJlc3NlZFxuICAgICAgICAvLyBvdXRzaWRlIGNsaWNrLiBSdW4gdGhpcyBhZnRlciBpbnNpZGUtdGFyZ2V0IGNoZWNrcyBzbyBpbnNpZGUgY2xpY2tzXG4gICAgICAgIC8vIGRvbid0IGNvbnN1bWUgdGhlIG9uZS1zaG90IHN1cHByZXNzaW9uLlxuICAgICAgICBpZiAoc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICBwcmV2ZW50ZWRQcmVzc1N1cHByZXNzaW9uVGltZW91dC5jbGVhcigpO1xuICAgICAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIG91dHNpZGVQcmVzcyA9PT0gJ2Z1bmN0aW9uJyAmJiAhb3V0c2lkZVByZXNzKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoaGFzQmxvY2tpbmdDaGlsZCgnX19vdXRzaWRlUHJlc3NCdWJibGVzJykpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMub3V0c2lkZVByZXNzLCBldmVudCkpO1xuICAgICAgY2xlYXJJbnNpZGVSZWFjdFRyZWUoKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlUG9pbnRlckRvd24oZXZlbnQpIHtcbiAgICAgIGlmIChnZXRPdXRzaWRlUHJlc3NFdmVudCgpICE9PSAnc2xvcHB5JyB8fCBldmVudC5wb2ludGVyVHlwZSA9PT0gJ3RvdWNoJyB8fCAhc3RvcmUuc2VsZWN0KCdvcGVuJykgfHwgIWVuYWJsZWQgfHwgaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjbG9zZU9uUHJlc3NPdXRzaWRlKGV2ZW50KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlVG91Y2hTdGFydChldmVudCkge1xuICAgICAgaWYgKGdldE91dHNpZGVQcmVzc0V2ZW50KCkgIT09ICdzbG9wcHknIHx8ICFzdG9yZS5zZWxlY3QoJ29wZW4nKSB8fCAhZW5hYmxlZCB8fCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHRvdWNoID0gZXZlbnQudG91Y2hlc1swXTtcbiAgICAgIGlmICh0b3VjaCkge1xuICAgICAgICB0b3VjaFN0YXRlUmVmLmN1cnJlbnQgPSB7XG4gICAgICAgICAgc3RhcnRUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgICAgIHN0YXJ0WDogdG91Y2guY2xpZW50WCxcbiAgICAgICAgICBzdGFydFk6IHRvdWNoLmNsaWVudFksXG4gICAgICAgICAgZGlzbWlzc09uVG91Y2hFbmQ6IGZhbHNlLFxuICAgICAgICAgIGRpc21pc3NPbk1vdXNlRG93bjogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgICBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0LnN0YXJ0KDEwMDAsICgpID0+IHtcbiAgICAgICAgICBpZiAodG91Y2hTdGF0ZVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICB0b3VjaFN0YXRlUmVmLmN1cnJlbnQuZGlzbWlzc09uVG91Y2hFbmQgPSBmYWxzZTtcbiAgICAgICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudC5kaXNtaXNzT25Nb3VzZURvd24gPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgbGlzdGVuZXIpIHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG4gICAgICBpZiAoIXRhcmdldCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB1bnN1YnNjcmliZSA9IGFkZEV2ZW50TGlzdGVuZXIodGFyZ2V0LCBldmVudC50eXBlLCAoKSA9PiB7XG4gICAgICAgIGxpc3RlbmVyKGV2ZW50KTtcbiAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVUb3VjaFN0YXJ0Q2FwdHVyZShldmVudCkge1xuICAgICAgY3VycmVudFBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSAndG91Y2gnO1xuICAgICAgYWRkVGFyZ2V0RXZlbnRMaXN0ZW5lck9uY2UoZXZlbnQsIGhhbmRsZVRvdWNoU3RhcnQpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjbG9zZU9uUHJlc3NPdXRzaWRlQ2FwdHVyZShldmVudCkge1xuICAgICAgY2FuY2VsRGlzbWlzc09uRW5kVGltZW91dC5jbGVhcigpO1xuXG4gICAgICAvLyBPbmx5IGBwb2ludGVyZG93bmAgbWFya3MgYSBwcmVzczsgYG1vdXNlZG93bmAgaXMgaXRzIGNvbXBhdGliaWxpdHkgZXZlbnQsIGFuZFxuICAgICAgLy8gY291bnRpbmcgaXQgd291bGQgbWlzYXR0cmlidXRlIGEgZ2VzdHVyZSB0aGF0IHN0YXJ0ZWQgYmVmb3JlIG9wZW4uXG4gICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ3BvaW50ZXJkb3duJykge1xuICAgICAgICAvLyBPbmx5IGEgcHJpbWFyeSBwcmVzcyBjYW4gcHJvZHVjZSBhIGBjbGlja2AuXG4gICAgICAgIGlmIChldmVudC5idXR0b24gPT09IDApIHtcbiAgICAgICAgICBzYXdQcmVzc1doaWxlT3BlblJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjdXJyZW50UG9pbnRlclR5cGVSZWYuY3VycmVudCA9IGV2ZW50LnBvaW50ZXJUeXBlO1xuICAgICAgfVxuICAgICAgaWYgKGV2ZW50LnR5cGUgPT09ICdtb3VzZWRvd24nICYmIHRvdWNoU3RhdGVSZWYuY3VycmVudCAmJiAhdG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPbk1vdXNlRG93bikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgdGFyZ2V0RXZlbnQgPT4ge1xuICAgICAgICBpZiAodGFyZ2V0RXZlbnQudHlwZSA9PT0gJ3BvaW50ZXJkb3duJykge1xuICAgICAgICAgIGhhbmRsZVBvaW50ZXJEb3duKHRhcmdldEV2ZW50KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjbG9zZU9uUHJlc3NPdXRzaWRlKHRhcmdldEV2ZW50KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVByZXNzRW5kQ2FwdHVyZShldmVudCkge1xuICAgICAgLy8gQSBjYW5jZWxsZWQgZ2VzdHVyZSBwcm9kdWNlcyBubyBjbGljay4gTm90IGNsZWFyZWQgb24gYHBvaW50ZXJ1cGA6IHRoZSBjbGlja1xuICAgICAgLy8gZmlyZXMgYWZ0ZXIgaXQgYW5kIG11c3Qgc3RpbGwgZmluZCB0aGUgcHJlc3MuXG4gICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ3BvaW50ZXJjYW5jZWwnKSB7XG4gICAgICAgIHNhd1ByZXNzV2hpbGVPcGVuUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICghcHJlc3NTdGFydGVkSW5zaWRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgcHJlc3NTdGFydGVkSW5zaWRlRGVmYXVsdFByZXZlbnRlZCA9IHByZXNzU3RhcnRQcmV2ZW50ZWRSZWYuY3VycmVudDtcbiAgICAgIHJlc2V0UHJlc3NTdGFydFN0YXRlKCk7XG4gICAgICBpZiAoZ2V0T3V0c2lkZVByZXNzRXZlbnQoKSAhPT0gJ2ludGVudGlvbmFsJykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ3BvaW50ZXJjYW5jZWwnKSB7XG4gICAgICAgIGlmIChwcmVzc1N0YXJ0ZWRJbnNpZGVEZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgc3VwcHJlc3NJbW1lZGlhdGVPdXRzaWRlQ2xpY2tBZnRlclByZXZlbnRlZFN0YXJ0KCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGlzRXZlbnRXaXRoaW5GbG9hdGluZ1RyZWUoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gSWYgcG9pbnRlcmRvd24gd2FzIHByZXZlbnRlZCwgbm8gY2xpY2sgbWF5IGJlIGdlbmVyYXRlZCBmb3IgdGhhdFxuICAgICAgLy8gaW50ZXJhY3Rpb24uIEhvd2V2ZXIsIEZpcmVmb3ggbWF5IHN0aWxsIGVtaXQgYW4gaW1tZWRpYXRlIGNsaWNrIGFmdGVyXG4gICAgICAvLyBwb2ludGVydXAgKGUuZy4gTnVtYmVyRmllbGQgc2NydWIgd2l0aCBwb2ludGVyIGxvY2spLCBzbyBzdXBwcmVzcyBmb3JcbiAgICAgIC8vIG9uZSB0aWNrIHRvIGFic29yYiB0aGF0IHN5bnRoZXRpYyBjbGljayBvbmx5LlxuICAgICAgaWYgKHByZXNzU3RhcnRlZEluc2lkZURlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgc3VwcHJlc3NJbW1lZGlhdGVPdXRzaWRlQ2xpY2tBZnRlclByZXZlbnRlZFN0YXJ0KCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gQXZvaWQgc3VwcHJlc3Npbmcgd2hlbiBvdXRzaWRlUHJlc3MgZXhwbGljaXRseSBpZ25vcmVzIHRoaXMgdGFyZ2V0LlxuICAgICAgaWYgKHR5cGVvZiBvdXRzaWRlUHJlc3MgPT09ICdmdW5jdGlvbicgJiYgIW91dHNpZGVQcmVzcyhldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcHJldmVudGVkUHJlc3NTdXBwcmVzc2lvblRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIGNsZWFySW5zaWRlUmVhY3RUcmVlKCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVRvdWNoTW92ZShldmVudCkge1xuICAgICAgaWYgKGdldE91dHNpZGVQcmVzc0V2ZW50KCkgIT09ICdzbG9wcHknIHx8ICF0b3VjaFN0YXRlUmVmLmN1cnJlbnQgfHwgaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB0b3VjaCA9IGV2ZW50LnRvdWNoZXNbMF07XG4gICAgICBpZiAoIXRvdWNoKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRlbHRhWCA9IE1hdGguYWJzKHRvdWNoLmNsaWVudFggLSB0b3VjaFN0YXRlUmVmLmN1cnJlbnQuc3RhcnRYKTtcbiAgICAgIGNvbnN0IGRlbHRhWSA9IE1hdGguYWJzKHRvdWNoLmNsaWVudFkgLSB0b3VjaFN0YXRlUmVmLmN1cnJlbnQuc3RhcnRZKTtcbiAgICAgIGNvbnN0IGRpc3RhbmNlID0gTWF0aC5zcXJ0KGRlbHRhWCAqIGRlbHRhWCArIGRlbHRhWSAqIGRlbHRhWSk7XG4gICAgICBpZiAoZGlzdGFuY2UgPiA1KSB7XG4gICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudC5kaXNtaXNzT25Ub3VjaEVuZCA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoZGlzdGFuY2UgPiAxMCkge1xuICAgICAgICBjbG9zZU9uUHJlc3NPdXRzaWRlKGV2ZW50KTtcbiAgICAgICAgY2FuY2VsRGlzbWlzc09uRW5kVGltZW91dC5jbGVhcigpO1xuICAgICAgICB0b3VjaFN0YXRlUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVUb3VjaE1vdmVDYXB0dXJlKGV2ZW50KSB7XG4gICAgICBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgaGFuZGxlVG91Y2hNb3ZlKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlVG91Y2hFbmQoZXZlbnQpIHtcbiAgICAgIGlmIChnZXRPdXRzaWRlUHJlc3NFdmVudCgpICE9PSAnc2xvcHB5JyB8fCAhdG91Y2hTdGF0ZVJlZi5jdXJyZW50IHx8IGlzRXZlbnRXaXRoaW5Pd25FbGVtZW50cyhldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHRvdWNoU3RhdGVSZWYuY3VycmVudC5kaXNtaXNzT25Ub3VjaEVuZCkge1xuICAgICAgICBjbG9zZU9uUHJlc3NPdXRzaWRlKGV2ZW50KTtcbiAgICAgIH1cbiAgICAgIGNhbmNlbERpc21pc3NPbkVuZFRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVRvdWNoRW5kQ2FwdHVyZShldmVudCkge1xuICAgICAgYWRkVGFyZ2V0RXZlbnRMaXN0ZW5lck9uY2UoZXZlbnQsIGhhbmRsZVRvdWNoRW5kKTtcbiAgICB9XG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSBtZXJnZUNsZWFudXBzKGVzY2FwZUtleSAmJiBtZXJnZUNsZWFudXBzKGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAna2V5ZG93bicsIGNsb3NlT25Fc2NhcGVLZXlEb3duKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdjb21wb3NpdGlvbnN0YXJ0JywgaGFuZGxlQ29tcG9zaXRpb25TdGFydCksIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAnY29tcG9zaXRpb25lbmQnLCBoYW5kbGVDb21wb3NpdGlvbkVuZCkpLCBvdXRzaWRlUHJlc3NFbmFibGVkICYmIG1lcmdlQ2xlYW51cHMoYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdjbGljaycsIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVyZG93bicsIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVydXAnLCBoYW5kbGVQcmVzc0VuZENhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3BvaW50ZXJjYW5jZWwnLCBoYW5kbGVQcmVzc0VuZENhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ21vdXNlZG93bicsIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdtb3VzZXVwJywgaGFuZGxlUHJlc3NFbmRDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICd0b3VjaHN0YXJ0JywgaGFuZGxlVG91Y2hTdGFydENhcHR1cmUsIHtcbiAgICAgIGNhcHR1cmU6IHRydWUsXG4gICAgICBwYXNzaXZlOiB0cnVlXG4gICAgfSksIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAndG91Y2htb3ZlJywgaGFuZGxlVG91Y2hNb3ZlQ2FwdHVyZSwge1xuICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICAgIHBhc3NpdmU6IHRydWVcbiAgICB9KSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICd0b3VjaGVuZCcsIGhhbmRsZVRvdWNoRW5kQ2FwdHVyZSwge1xuICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICAgIHBhc3NpdmU6IHRydWVcbiAgICB9KSkpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgcHJldmVudGVkUHJlc3NTdXBwcmVzc2lvblRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIHJlc2V0UHJlc3NTdGFydFN0YXRlKCk7XG4gICAgICBzdXBwcmVzc05leHRPdXRzaWRlQ2xpY2tSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH07XG4gIH0sIFtkYXRhUmVmLCBmbG9hdGluZ0VsZW1lbnQsIGVzY2FwZUtleSwgb3V0c2lkZVByZXNzRW5hYmxlZCwgb3V0c2lkZVByZXNzLCBvcGVuLCBlbmFibGVkLCBlc2NhcGVLZXlCdWJibGVzLCBvdXRzaWRlUHJlc3NCdWJibGVzLCBjbG9zZU9uRXNjYXBlS2V5RG93biwgY2xlYXJJbnNpZGVSZWFjdFRyZWUsIGdldE91dHNpZGVQcmVzc0V2ZW50UHJvcCwgaGFzQmxvY2tpbmdDaGlsZCwgaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzLCB0cmVlLCBzdG9yZSwgY2FuY2VsRGlzbWlzc09uRW5kVGltZW91dCwgY29tcG9zaXRpb25UaW1lb3V0XSk7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBvbktleURvd246IGNsb3NlT25Fc2NhcGVLZXlEb3duLFxuICAgIG9uUG9pbnRlckRvd246IGNsb3NlT25SZWZlcmVuY2VQcmVzcyxcbiAgICBvbkNsaWNrOiBjbG9zZU9uUmVmZXJlbmNlUHJlc3NcbiAgfSksIFtjbG9zZU9uRXNjYXBlS2V5RG93biwgY2xvc2VPblJlZmVyZW5jZVByZXNzXSk7XG4gIGNvbnN0IGZsb2F0aW5nID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uS2V5RG93bjogY2xvc2VPbkVzY2FwZUtleURvd24sXG4gICAgLy8gYG9uTW91c2VEb3duYCBtYXkgYmUgYmxvY2tlZCBpZiBgZXZlbnQucHJldmVudERlZmF1bHQoKWAgaXMgY2FsbGVkIGluXG4gICAgLy8gYG9uUG9pbnRlckRvd25gLCBzdWNoIGFzIHdpdGggPE51bWJlckZpZWxkLlNjcnViQXJlYT4uXG4gICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvYmFzZS11aS9wdWxsLzMzNzlcbiAgICBvblBvaW50ZXJEb3duOiBtYXJrSW5zaWRlUHJlc3NTdGFydFByZXZlbnRlZCxcbiAgICBvbk1vdXNlRG93bjogbWFya0luc2lkZVByZXNzU3RhcnRQcmV2ZW50ZWQsXG4gICAgb25DbGlja0NhcHR1cmU6IG1hcmtJbnNpZGVSZWFjdFRyZWUsXG4gICAgb25Nb3VzZURvd25DYXB0dXJlKGV2ZW50KSB7XG4gICAgICBtYXJrSW5zaWRlUmVhY3RUcmVlKCk7XG4gICAgICBtYXJrUHJlc3NTdGFydGVkSW5zaWRlUmVhY3RUcmVlKGV2ZW50KTtcbiAgICB9LFxuICAgIG9uUG9pbnRlckRvd25DYXB0dXJlKGV2ZW50KSB7XG4gICAgICBtYXJrSW5zaWRlUmVhY3RUcmVlKCk7XG4gICAgICBtYXJrUHJlc3NTdGFydGVkSW5zaWRlUmVhY3RUcmVlKGV2ZW50KTtcbiAgICB9LFxuICAgIG9uTW91c2VVcENhcHR1cmU6IG1hcmtJbnNpZGVSZWFjdFRyZWUsXG4gICAgb25Ub3VjaEVuZENhcHR1cmU6IG1hcmtJbnNpZGVSZWFjdFRyZWUsXG4gICAgb25Ub3VjaE1vdmVDYXB0dXJlOiBtYXJrSW5zaWRlUmVhY3RUcmVlXG4gIH0pLCBbY2xvc2VPbkVzY2FwZUtleURvd24sIG1hcmtJbnNpZGVSZWFjdFRyZWUsIG1hcmtQcmVzc1N0YXJ0ZWRJbnNpZGVSZWFjdFRyZWUsIG1hcmtJbnNpZGVQcmVzc1N0YXJ0UHJldmVudGVkXSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgcmVmZXJlbmNlLFxuICAgIGZsb2F0aW5nLFxuICAgIHRyaWdnZXI6IHJlZmVyZW5jZVxuICB9IDoge30sIFtlbmFibGVkLCByZWZlcmVuY2UsIGZsb2F0aW5nXSk7XG59IiwiaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0IHsgQW5pbWF0aW9uRnJhbWUgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VBbmltYXRpb25GcmFtZSc7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5cbi8qKlxuICogTWluaW1hbCBzdG9yZSBjb250cmFjdCBleHBvc2VkIGJ5IHBvcHVwIGhhbmRsZXMgdG8gZGV0YWNoZWQgdHJpZ2dlcnMuXG4gKlxuICogRGV0YWNoZWQgdHJpZ2dlcnMgcmVhZCBgc3RvcmVgIGR1cmluZyByZW5kZXIgYW5kIHN1YnNjcmliZSB0byBiZSBub3RpZmllZCB3aGVuIHRoZSBoYW5kbGUgc3dpdGNoZXNcbiAqIGJldHdlZW4gaXRzIGZhbGxiYWNrIHN0b3JlIGFuZCBhIHJvb3QncyBsaXZlIHN0b3JlLlxuICpcbiAqIEB0ZW1wbGF0ZSBIYW5kbGVTdG9yZSBTdG9yZSBzaGFwZSBleHBvc2VkIHRvIGRldGFjaGVkIHRyaWdnZXJzLlxuICovXG5cbi8qKlxuICogU3RvcmUgc2hhcGUgaG9sZGluZyBhIHRyaWdnZXIgcmVnaXN0cnksIHJlcXVpcmVkIGJ5IGBCYXNlUG9wdXBIYW5kbGUub3BlbkJ5VHJpZ2dlcmAgdG8gcmVzb2x2ZSBhXG4gKiB0cmlnZ2VyIGVsZW1lbnQgYnkgaWQgb24gYm90aCB0aGUgYXR0YWNoZWQgcm9vdCdzIHN0b3JlIGFuZCB0aGUgZmFsbGJhY2sgc3RvcmUuXG4gKi9cblxuLyoqXG4gKiBTdG9yZSBzaGFwZSByZXF1aXJlZCBieSBgQmFzZVBvcHVwSGFuZGxlLm9wZW5CeVRyaWdnZXJgL2BjbG9zZVBvcHVwYCB0byBkcml2ZSBvcGVuL2Nsb3NlIHN0YXRlLlxuICogT25seSB0aGUgcm9vdC1vd25lZCBgU3RvcmVgIG5lZWRzIHRoaXMg4oCUIHRoZSBgSGFuZGxlU3RvcmVgIHZpZXcgZXhwb3NlZCB0byBkZXRhY2hlZCB0cmlnZ2VycyBtYXlcbiAqIG9taXQgYHNldE9wZW5gIGVudGlyZWx5IChhcyBEaWFsb2cgYW5kIFByZXZpZXdDYXJkJ3MgZG8pIHNpbmNlIGl0IGlzIG5ldmVyIGNhbGxlZCB3aGlsZSBkZXRhY2hlZC5cbiAqL1xuXG4vKipcbiAqIFNoYXJlZCBpbXBsZW1lbnRhdGlvbiBmb3IgcG9wdXAgaGFuZGxlcyB0aGF0IGNvb3JkaW5hdGUgZGV0YWNoZWQgdHJpZ2dlcnMgd2l0aCBhIG1vdW50ZWQgcm9vdC5cbiAqXG4gKiBTdWJjbGFzc2VzIHByb3ZpZGUgdGhlIGNvbXBvbmVudC1zcGVjaWZpYyBpbXBlcmF0aXZlIG1ldGhvZHMsIHdoaWxlIHRoaXMgYmFzZSBjbGFzcyBvd25zIHRoZVxuICogZmFsbGJhY2sgc3RvcmUsIHJvb3Qgc3RvcmUgYXR0YWNobWVudCBzdGFjaywgc3Vic2NyaWJlciBub3RpZmljYXRpb25zLCBhbmQgZGV2ZWxvcG1lbnQgd2FybmluZyBmb3JcbiAqIG92ZXJsYXBwaW5nIHJvb3RzLlxuICpcbiAqIEB0ZW1wbGF0ZSBIYW5kbGVTdG9yZSBTdG9yZSBzaGFwZSBleHBvc2VkIHRvIGRldGFjaGVkIHRyaWdnZXJzLlxuICogQHRlbXBsYXRlIFN0b3JlIFJvb3Qtb3duZWQgc3RvcmUgYXR0YWNoZWQgYnkgdGhlIGNvbXBvbmVudCByb290LlxuICovXG5leHBvcnQgY2xhc3MgQmFzZVBvcHVwSGFuZGxlIHtcbiAgLyoqXG4gICAqIFN0b3JlcyBvZiBldmVyeSByb290IGN1cnJlbnRseSB1c2luZyB0aGlzIGhhbmRsZSwgaW4gYXR0YWNoIG9yZGVyLiBBIGhhbmRsZSBpcyBtZWFudCB0byBiZSB1c2VkXG4gICAqIGJ5IGEgc2luZ2xlIG1vdW50ZWQgcm9vdCwgYnV0IHJvb3RzIGNhbiB0cmFuc2llbnRseSBvdmVybGFwIChlLmcuIGR1cmluZyBhbiBhbmltYXRlZCByb3V0ZVxuICAgKiB0cmFuc2l0aW9uKSwgc28gdGhpcyBzdGFjayBsZXRzIGBhdHRhY2hTdG9yZWAncyBjbGVhbnVwIHJlc3RvcmUgdGhlIHByZXZpb3VzIHJvb3QgaW5zdGVhZCBvZlxuICAgKiBsZWF2aW5nIGEgc3RpbGwtbW91bnRlZCByb290IHVuY29udHJvbGxhYmxlIHdoZW4gYSBuZXdlciBvdmVybGFwcGluZyByb290IGRldGFjaGVzIGZpcnN0LlxuICAgKi9cbiAgYXR0YWNoZWRTdG9yZXMgPSBbXTtcblxuICAvKipcbiAgICogU3RvcmUgb2YgdGhlIHJvb3QgdGhhdCBjdXJyZW50bHkgY29udHJvbHMgdGhlIGhhbmRsZTogdGhlIG1vc3QgcmVjZW50bHkgYXR0YWNoZWQgb25lIHN0aWxsXG4gICAqIG1vdW50ZWQsIG9yIGBudWxsYCB3aGVuIG5vIHJvb3QgaXMgYXR0YWNoZWQuIEltcGVyYXRpdmUgbWV0aG9kcyBhcmUgbm8tb3BzIHdoaWxlIHRoaXMgaXMgYG51bGxgLlxuICAgKi9cbiAgYXR0YWNoZWRTdG9yZVZhbHVlID0gbnVsbDtcblxuICAvKipcbiAgICogTGlzdGVuZXJzIG5vdGlmaWVkIHdoZW4gYGF0dGFjaGVkU3RvcmVgIGNoYW5nZXMsIHNvIGRldGFjaGVkIHRyaWdnZXJzIGNhbiBmb2xsb3cgdGhlIHN0b3JlIHBvaW50ZXIuXG4gICAqL1xuICBzdG9yZUxpc3RlbmVycyA9IG5ldyBTZXQoKTtcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIGhhbmRsZSBiYWNrZWQgYnkgdGhlIHN0b3JlIHVzZWQgd2hpbGUgbm8gcm9vdCBpcyBhdHRhY2hlZC5cbiAgICpcbiAgICogQHBhcmFtIGZhbGxiYWNrU3RvcmUgSW5lcnQsIGNsb3NlZCBzdG9yZSBoYW5kZWQgdG8gZGV0YWNoZWQgdHJpZ2dlcnMgd2hpbGUgbm8gcm9vdCBpcyBhdHRhY2hlZCxcbiAgICogc28gdGhleSBjYW4gcmVuZGVyIGFuZCByZWdpc3RlciB3aXRob3V0IGEgbW91bnRlZCByb290LiBUcmlnZ2VycyByZWdpc3RlciBpbnRvIHdoaWNoZXZlciBzdG9yZVxuICAgKiBgc3RvcmVgIGN1cnJlbnRseSByZXNvbHZlcyB0bywgc28gd2hpbGUgZGV0YWNoZWQgdGhleSBsaXZlIGluIHRoaXMgc3RvcmUncyB0cmlnZ2VyIG1hcCBhbmRcbiAgICogbWlncmF0ZSB0aGVtc2VsdmVzIHRvIHRoZSByb290J3Mgc3RvcmUgKGFuZCBiYWNrKSBhcyBpdCBhdHRhY2hlcy9kZXRhY2hlcy5cbiAgICogQHBhcmFtIGNvbXBvbmVudE5hbWUgQ29tcG9uZW50IG5hbWUgdXNlZCB0byBwcmVmaXggZGV2IHdhcm5pbmdzLCBlLmcuIGAnTWVudSdgIHByb2R1Y2VzXG4gICAqIGBNZW51SGFuZGxlLm9wZW4oKWAgaW4gd2FybmluZyB0ZXh0LlxuICAgKiBAcGFyYW0gdGhyb3dPbk1pc3NpbmdUcmlnZ2VyIFdoZXRoZXIgYG9wZW4odHJpZ2dlcklkKWAgdGhyb3dzIHdoZW4gbm8gdHJpZ2dlciB3aXRoIHRoYXQgaWQgaXNcbiAgICogcmVnaXN0ZXJlZC4gQW5jaG9yZWQgcG9wdXBzIChNZW51LCBQb3BvdmVyLCBUb29sdGlwLCBQcmV2aWV3Q2FyZCkgbmVlZCBhIHRyaWdnZXIgdG8gYW5jaG9yIHRvLFxuICAgKiBzbyB0aGV5IHRocm93OyBEaWFsb2cgaXMgbm90IGFuY2hvcmVkIGFuZCBpbnN0ZWFkIG9wZW5zIHVuYXNzb2NpYXRlZCB3aXRoIGEgZGV2IHdhcm5pbmcuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihmYWxsYmFja1N0b3JlLCBjb21wb25lbnROYW1lLCB0aHJvd09uTWlzc2luZ1RyaWdnZXIgPSB0cnVlKSB7XG4gICAgdGhpcy5mYWxsYmFja1N0b3JlID0gZmFsbGJhY2tTdG9yZTtcbiAgICB0aGlzLmNvbXBvbmVudE5hbWUgPSBjb21wb25lbnROYW1lO1xuICAgIHRoaXMudGhyb3dPbk1pc3NpbmdUcmlnZ2VyID0gdGhyb3dPbk1pc3NpbmdUcmlnZ2VyO1xuICB9XG4gIGdldCBhdHRhY2hlZFN0b3JlKCkge1xuICAgIHJldHVybiB0aGlzLmF0dGFjaGVkU3RvcmVWYWx1ZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdG9yZSB0aGF0IGRldGFjaGVkIHRyaWdnZXJzIHJlYWQgZnJvbTogdGhlIGF0dGFjaGVkIHJvb3QncyBzdG9yZSwgb3IgYW4gaW5lcnQgZmFsbGJhY2sgc3RvcmVcbiAgICogdXNlZCB3aGlsZSBubyByb290IGlzIGF0dGFjaGVkLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGdldCBzdG9yZSgpIHtcbiAgICByZXR1cm4gdGhpcy5hdHRhY2hlZFN0b3JlVmFsdWUgPz8gdGhpcy5mYWxsYmFja1N0b3JlO1xuICB9XG5cbiAgLyoqXG4gICAqIFN0YWJsZSBmYWxsYmFjayBzdG9yZSB1c2VkIGZvciBzZXJ2ZXIgcmVuZGVyaW5nIGFuZCBoeWRyYXRpb24uIFJvb3Qgc3RvcmVzIGNhbm5vdCBiZSByZWNvcmRlZCBvblxuICAgKiB0aGUgaGFuZGxlIGR1cmluZyByZW5kZXIgYmVjYXVzZSBhIGhhbmRsZSBjYW4gYmUgc2hhcmVkIGJ5IGNvbmN1cnJlbnQgc2VydmVyLXJlbmRlcmVkIHJlcXVlc3RzLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGdldCBzZXJ2ZXJTdG9yZSgpIHtcbiAgICByZXR1cm4gdGhpcy5mYWxsYmFja1N0b3JlO1xuICB9XG5cbiAgLyoqXG4gICAqIFN1YnNjcmliZXMgdG8gY2hhbmdlcyBvZiB0aGUgYXR0YWNoZWQgc3RvcmUgcG9pbnRlciBzbyBkZXRhY2hlZCB0cmlnZ2VycyByZS1yZW5kZXIgYW5kIHJlLWJpbmRcbiAgICogd2hlbiBhIHJvb3QgYXR0YWNoZXMgb3IgZGV0YWNoZXMuIFJldHVybnMgYSBmdW5jdGlvbiB0aGF0IHJlbW92ZXMgdGhlIGxpc3RlbmVyLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIHN1YnNjcmliZVN0b3JlKGxpc3RlbmVyKSB7XG4gICAgdGhpcy5zdG9yZUxpc3RlbmVycy5hZGQobGlzdGVuZXIpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB0aGlzLnN0b3JlTGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQb2ludHMgdGhlIGhhbmRsZSBhdCBhIHJvb3QncyBzdG9yZSBhbmQgbm90aWZpZXMgc3Vic2NyaWJlcnMgc28gZGV0YWNoZWQgdHJpZ2dlcnMgcmUtcmVuZGVyIGFuZFxuICAgKiByZS1yZWdpc3RlciBpbnRvIGl0ICh0aGVpciByZWdpc3RyYXRpb24gZWZmZWN0IG1pZ3JhdGVzIHRoZW0gd2hlbiB0aGUgc3RvcmUgcG9pbnRlciBjaGFuZ2VzKS5cbiAgICogUmV0dXJucyBhIGNsZWFudXAgZnVuY3Rpb24gdGhhdCBkZXRhY2hlcyB0aGUgc3RvcmUgYWdhaW4uXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgYXR0YWNoU3RvcmUobmV3U3RvcmUpIHtcbiAgICB0aGlzLmF0dGFjaGVkU3RvcmVzLnB1c2gobmV3U3RvcmUpO1xuICAgIHRoaXMuc2V0QWN0aXZlU3RvcmUobmV3U3RvcmUpO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBpZiAodGhpcy5hdHRhY2hlZFN0b3Jlcy5sZW5ndGggPiAxKSB7XG4gICAgICAgIC8vIE1vcmUgdGhhbiBvbmUgcm9vdCBpcyBhdHRhY2hlZCBhdCBvbmNlLiBUaGlzIGlzIHVzdWFsbHkgYSB0cmFuc2llbnQgb3ZlcmxhcCBkdXJpbmcgYW5cbiAgICAgICAgLy8gYW5pbWF0ZWQgcm91dGUgdHJhbnNpdGlvbiwgd2hlcmUgdGhlIG91dGdvaW5nIHJvb3QgdW5tb3VudHMgc2hvcnRseSBhZnRlciB0aGUgaW5jb21pbmdcbiAgICAgICAgLy8gb25lIG1vdW50cy4gRGVmZXIgdGhlIGNoZWNrIGJ5IGEgZnJhbWUgYW5kIG9ubHkgd2FybiBpZiB0aGUgb3ZlcmxhcCBpcyBzdGlsbCBwcmVzZW50IG9uY2VcbiAgICAgICAgLy8gdGhlIHRyYW5zaXRpb24gaGFzIHNldHRsZWQgKG1vcmUgdGhhbiBvbmUgcm9vdCBzdGF5ZWQgbW91bnRlZCksIHNvIGEgY2xlYW4gaGFuZG9mZiBkb2Vzbid0XG4gICAgICAgIC8vIHdhcm4gcmVnYXJkbGVzcyBvZiB0aGUgZXhhY3QgdW5tb3VudCB0aW1pbmcuXG4gICAgICAgIC8vIFRoZSB3YXJuaW5nIGZyYW1lIG9ubHkgZXhpc3RzIGluIGRldmVsb3BtZW50OyBpdCBpcyBjcmVhdGVkIGxhemlseSBzbyBpdCBuZXZlciBhcHBlYXJzIG9uXG4gICAgICAgIC8vIGluc3RhbmNlcyBpbiBwcm9kdWN0aW9uIChsaWtlIGBjb250cm9sbGVkVmFsdWVzYCBpbiBgUmVhY3RTdG9yZWApLlxuICAgICAgICBjb25zdCBkZXYgPSB0aGlzO1xuICAgICAgICAoZGV2Lm92ZXJsYXBXYXJuaW5nRnJhbWUgPz89IEFuaW1hdGlvbkZyYW1lLmNyZWF0ZSgpKS5yZXF1ZXN0KCgpID0+IHtcbiAgICAgICAgICBpZiAodGhpcy5hdHRhY2hlZFN0b3Jlcy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0Jhc2UgVUk6IEEgaGFuZGxlIGlzIGF0dGFjaGVkIHRvIG1vcmUgdGhhbiBvbmUgbW91bnRlZCByb290IGF0IHRoZSBzYW1lIHRpbWUuICcgKyAnVGhlIG1vc3QgcmVjZW50bHkgbW91bnRlZCByb290IHRha2VzIG92ZXIgYW5kIHRoZSBwcmV2aW91cyBvbmUgc3RvcHMgYmVpbmcgY29udHJvbGxlZCBieSB0aGUgaGFuZGxlLiAnICsgJ0EgaGFuZGxlIHNob3VsZCBiZSB1c2VkIGJ5IGEgc2luZ2xlIHJvb3QgdGhhdCBzdGF5cyBtb3VudGVkIGZvciB0aGUgbGlmZXRpbWUgb2YgdGhlIGhhbmRsZS4nKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY29uc3QgaW5kZXggPSB0aGlzLmF0dGFjaGVkU3RvcmVzLmxhc3RJbmRleE9mKG5ld1N0b3JlKTtcbiAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgdGhpcy5hdHRhY2hlZFN0b3Jlcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgfVxuICAgICAgLy8gUmVzdG9yZSBjb250cm9sIHRvIHRoZSBtb3N0IHJlY2VudGx5IGF0dGFjaGVkIHJvb3QgdGhhdCBpcyBzdGlsbCBtb3VudGVkIChvciBkZXRhY2ggZnVsbHkgaWZcbiAgICAgIC8vIG5vbmUgcmVtYWluKS4gQ2xlYXJpbmcgdW5jb25kaXRpb25hbGx5IHdvdWxkIGxlYXZlIGEgc3RpbGwtbW91bnRlZCBvbGRlciByb290IHVuY29udHJvbGxhYmxlXG4gICAgICAvLyB3aGVuIGEgbmV3ZXIgb3ZlcmxhcHBpbmcgcm9vdCBkZXRhY2hlcyBmaXJzdCAoZS5nLiBhIGNhbmNlbGVkIHJvdXRlIHRyYW5zaXRpb24pLlxuICAgICAgdGhpcy5zZXRBY3RpdmVTdG9yZSh0aGlzLmF0dGFjaGVkU3RvcmVzW3RoaXMuYXR0YWNoZWRTdG9yZXMubGVuZ3RoIC0gMV0gPz8gbnVsbCk7XG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBzdG9yZSB0aGF0IGN1cnJlbnRseSBjb250cm9scyB0aGUgaGFuZGxlIGFuZCBub3RpZmllcyBzdWJzY3JpYmVycyB3aGVuIGl0IGNoYW5nZXMsIHNvXG4gICAqIGRldGFjaGVkIHRyaWdnZXJzIHJlLXJlbmRlciBhbmQgbWlncmF0ZSB0aGVpciByZWdpc3RyYXRpb24gdG8gdGhlIG5ldyBzdG9yZS5cbiAgICovXG4gIHNldEFjdGl2ZVN0b3JlKHN0b3JlKSB7XG4gICAgaWYgKHRoaXMuYXR0YWNoZWRTdG9yZVZhbHVlICE9PSBzdG9yZSkge1xuICAgICAgdGhpcy5hdHRhY2hlZFN0b3JlVmFsdWUgPSBzdG9yZTtcbiAgICAgIHRoaXMuc3RvcmVMaXN0ZW5lcnMuZm9yRWFjaChsaXN0ZW5lciA9PiB7XG4gICAgICAgIGxpc3RlbmVyKCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogT3BlbnMgdGhlIGF0dGFjaGVkIHJvb3QncyBzdG9yZSBhbmQgYXNzb2NpYXRlcyBpdCB3aXRoIHRoZSB0cmlnZ2VyIHdpdGggdGhlIGdpdmVuIGlkLCBvciBhXG4gICAqIG5vLW9wICh3aXRoIGEgZGV2IHdhcm5pbmcpIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQuIFNoYXJlZCBieSBldmVyeSBjb25jcmV0ZSBoYW5kbGUncyBwdWJsaWNcbiAgICogYG9wZW4oKWAgbWV0aG9kLCB3aGljaCBvbmx5IG5hcnJvd3MgdGhlIHBhcmFtZXRlciB0eXBlLlxuICAgKlxuICAgKiBXaGVuIGEgdHJpZ2dlciBpZCBpcyBnaXZlbiBidXQgbm8gbWF0Y2hpbmcgdHJpZ2dlciBpcyByZWdpc3RlcmVkLCBhbmNob3JlZCBwb3B1cHMgdGhyb3cgKHNlZVxuICAgKiBgdGhyb3dPbk1pc3NpbmdUcmlnZ2VyYCk7IERpYWxvZyBvcGVucyB1bmFzc29jaWF0ZWQgd2l0aCBhIGRldiB3YXJuaW5nIGluc3RlYWQuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKlxuICAgKiBAcGFyYW0gdHJpZ2dlcklkIElEIG9mIHRoZSB0cmlnZ2VyIHRvIGFzc29jaWF0ZSB3aXRoIHRoZSBwb3B1cCwgb3IgYG51bGxgL2B1bmRlZmluZWRgIHRvIG9wZW5cbiAgICogd2l0aG91dCBhc3NvY2lhdGluZyBhbnkgdHJpZ2dlci5cbiAgICovXG4gIG9wZW5CeVRyaWdnZXIodHJpZ2dlcklkKSB7XG4gICAgY29uc3QgYXR0YWNoZWRTdG9yZSA9IHRoaXMuYXR0YWNoZWRTdG9yZTtcbiAgICBpZiAoYXR0YWNoZWRTdG9yZSA9PT0gbnVsbCkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgY29uc29sZS53YXJuKGBCYXNlIFVJOiAke3RoaXMuY29tcG9uZW50TmFtZX1IYW5kbGUub3BlbigpIHdhcyBjYWxsZWQgd2hpbGUgbm8gcm9vdCB1c2luZyB0aGlzIGhhbmRsZSBpcyBtb3VudGVkLiBgICsgJ1RoZSBjYWxsIHdhcyBpZ25vcmVkOyBtb3VudCBhIHJvb3Qgd2l0aCB0aGlzIGhhbmRsZSBiZWZvcmUgb3BlbmluZyBpdCBpbXBlcmF0aXZlbHkuJyk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gUmVnaXN0ZXJlZCB0cmlnZ2VycyBub3JtYWxseSBsaXZlIGluIHRoZSBhY3RpdmUgcm9vdCdzIHN0b3JlLiBEdXJpbmcgdGhlIGNvbW1pdCBpbiB3aGljaCBhXG4gICAgLy8gcm9vdCBhdHRhY2hlcywgYSBzdGlsbC1tb3VudGVkIGRldGFjaGVkIHRyaWdnZXIgaGFzIG5vdCByZS1yZWdpc3RlcmVkIGludG8gdGhhdCBzdG9yZSB5ZXQgKGl0XG4gICAgLy8gbWlncmF0ZXMgb24gaXRzIG5leHQgcmVuZGVyKTogaXQgaXMgc3RpbGwgcmVnaXN0ZXJlZCB3aGVyZXZlciBpdCBsaXZlZCBiZWZvcmUg4oCUIHRoZSBmYWxsYmFja1xuICAgIC8vIHN0b3JlIHdoZW4gdGhpcyBpcyB0aGUgZmlyc3Qgcm9vdCB0byBhdHRhY2gsIG9yIGEgcHJldmlvdXNseSBhdHRhY2hlZCByb290J3Mgc3RvcmUgZHVyaW5nIGFcbiAgICAvLyB0cmFuc2llbnQgb3ZlcmxhcCAoZS5nLiBhbiBhbmltYXRlZCByb3V0ZSB0cmFuc2l0aW9uKS4gU2VhcmNoIHRoZSB3aG9sZSBhdHRhY2htZW50IHN0YWNrXG4gICAgLy8gKG5ld2VzdCBmaXJzdCkgYW5kIHRoZSBmYWxsYmFjayBtYXAgc28gYW4gaW1wZXJhdGl2ZSBvcGVuLWJ5LWlkIGNhbGxlZCBpbiB0aGF0IGNvbW1pdCAoZS5nLlxuICAgIC8vIGZyb20gYSBsYXlvdXQgZWZmZWN0KSBzdGlsbCByZXNvbHZlcyB0aGUgdHJpZ2dlciBpbnN0ZWFkIG9mIHRyZWF0aW5nIGl0IGFzIG1pc3NpbmcuXG4gICAgbGV0IHRyaWdnZXJFbGVtZW50O1xuICAgIGlmICh0cmlnZ2VySWQpIHtcbiAgICAgIGZvciAobGV0IGkgPSB0aGlzLmF0dGFjaGVkU3RvcmVzLmxlbmd0aCAtIDE7IGkgPj0gMCAmJiAhdHJpZ2dlckVsZW1lbnQ7IGkgLT0gMSkge1xuICAgICAgICB0cmlnZ2VyRWxlbWVudCA9IHRoaXMuYXR0YWNoZWRTdG9yZXNbaV0uY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZ2V0QnlJZCh0cmlnZ2VySWQpO1xuICAgICAgfVxuICAgICAgdHJpZ2dlckVsZW1lbnQgPz89IHRoaXMuZmFsbGJhY2tTdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5nZXRCeUlkKHRyaWdnZXJJZCk7XG4gICAgfVxuICAgIGlmICh0cmlnZ2VySWQgJiYgIXRyaWdnZXJFbGVtZW50KSB7XG4gICAgICBpZiAodGhpcy50aHJvd09uTWlzc2luZ1RyaWdnZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IGBCYXNlIFVJOiAke3RoaXMuY29tcG9uZW50TmFtZX1IYW5kbGUub3BlbigpIHdhcyBjYWxsZWQgd2l0aCB0aGUgdHJpZ2dlciBpZCBcIiR7dHJpZ2dlcklkfVwiLCBgICsgJ2J1dCBubyBtYXRjaGluZyB0cmlnZ2VyIGlzIHJlZ2lzdGVyZWQgd2l0aCB0aGlzIGhhbmRsZS4gJyArICdBbiBhbmNob3JlZCBwb3B1cCBjYW5ub3Qgb3BlbiB3aXRob3V0IGEgdHJpZ2dlciB0byBhbmNob3IgdG8uICcgKyBgUGFzcyB0aGUgaWQgb2YgYSBtb3VudGVkICR7dGhpcy5jb21wb25lbnROYW1lfS5UcmlnZ2VyIHRoYXQgaGFzIHRoaXMgaGFuZGxlIHNldCBvbiBpdHMgXCJoYW5kbGVcIiBwcm9wLmAgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDk5LCB0aGlzLmNvbXBvbmVudE5hbWUsIHRyaWdnZXJJZCwgdGhpcy5jb21wb25lbnROYW1lKSk7XG4gICAgICB9XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBjb25zb2xlLndhcm4oYEJhc2UgVUk6ICR7dGhpcy5jb21wb25lbnROYW1lfUhhbmRsZS5vcGVuOiBObyB0cmlnZ2VyIGZvdW5kIHdpdGggaWQgXCIke3RyaWdnZXJJZH1cIi4gYCArICdUaGUgcG9wdXAgd2lsbCBvcGVuLCBidXQgdGhlIHRyaWdnZXIgd2lsbCBub3QgYmUgYXNzb2NpYXRlZCB3aXRoIGl0LicpO1xuICAgICAgfVxuICAgIH1cbiAgICBhdHRhY2hlZFN0b3JlLnNldE9wZW4odHJ1ZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbiwgdW5kZWZpbmVkLCB0cmlnZ2VyRWxlbWVudCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIENsb3NlcyB0aGUgcG9wdXAgYnkgc2V0dGluZyB0aGUgYXR0YWNoZWQgcm9vdCdzIHN0b3JlIHRvIGNsb3NlZCwgb3IgYSBuby1vcCAod2l0aCBhIGRldiB3YXJuaW5nKVxuICAgKiB3aGlsZSBubyByb290IGlzIGF0dGFjaGVkLiBTaGFyZWQgYnkgZXZlcnkgY29uY3JldGUgaGFuZGxlJ3MgcHVibGljIGBjbG9zZSgpYCBtZXRob2QuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKi9cbiAgY2xvc2VQb3B1cCgpIHtcbiAgICBjb25zdCBhdHRhY2hlZFN0b3JlID0gdGhpcy5hdHRhY2hlZFN0b3JlO1xuICAgIGlmIChhdHRhY2hlZFN0b3JlID09PSBudWxsKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBjb25zb2xlLndhcm4oYEJhc2UgVUk6ICR7dGhpcy5jb21wb25lbnROYW1lfUhhbmRsZS5jbG9zZSgpIHdhcyBjYWxsZWQgd2hpbGUgbm8gcm9vdCB1c2luZyB0aGlzIGhhbmRsZSBpcyBtb3VudGVkLiBgICsgJ1RoZSBjYWxsIHdhcyBpZ25vcmVkLicpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhdHRhY2hlZFN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLmltcGVyYXRpdmVBY3Rpb24pKTtcbiAgfVxufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IGlzRWxlbWVudCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuXG4vKipcbiAqIE5hcnJvd2VkIHRvIHRoZSBzdG9yZSBtZW1iZXJzIHRoaXMgaG9vayB1c2VzIHNvIGNvbnN1bWVycyBkbyBub3QgbmVlZCB0byBwcm92aWRlXG4gKiB1bnJlbGF0ZWQgc3RvcmUgY2FwYWJpbGl0aWVzLlxuICovXG5cbi8qKlxuICogS2VlcHMgdGhlIHByb3ZpZGVkIEZsb2F0aW5nUm9vdFN0b3JlIGluIHN5bmMgd2l0aCB0aGUgcHJvdmlkZWQgUG9wdXBTdG9yZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVN5bmNlZEZsb2F0aW5nUm9vdENvbnRleHQob3B0aW9ucykge1xuICBjb25zdCB7XG4gICAgcG9wdXBTdG9yZSxcbiAgICB0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgPSBmYWxzZSxcbiAgICBmbG9hdGluZ1Jvb3RDb250ZXh0OiBzdG9yZSxcbiAgICBmbG9hdGluZ0lkLFxuICAgIG5lc3RlZCxcbiAgICBvbk9wZW5DaGFuZ2VcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IG9wZW4gPSBwb3B1cFN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IHJlZmVyZW5jZUVsZW1lbnQgPSBwb3B1cFN0b3JlLnVzZVN0YXRlKCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpO1xuICBjb25zdCBmbG9hdGluZ0VsZW1lbnQgPSBwb3B1cFN0b3JlLnVzZVN0YXRlKHRyZWF0UG9wdXBBc0Zsb2F0aW5nRWxlbWVudCA/ICdwb3B1cEVsZW1lbnQnIDogJ3Bvc2l0aW9uZXJFbGVtZW50Jyk7XG4gIGNvbnN0IGhhbmRsZU9wZW5DaGFuZ2UgPSBvbk9wZW5DaGFuZ2U7XG4gIHBvcHVwU3RvcmUudXNlU3luY2VkVmFsdWUoJ2Zsb2F0aW5nSWQnLCBmbG9hdGluZ0lkKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB2YWx1ZXNUb1N5bmMgPSB7XG4gICAgICBvcGVuLFxuICAgICAgZmxvYXRpbmdJZCxcbiAgICAgIHJlZmVyZW5jZUVsZW1lbnQsXG4gICAgICBmbG9hdGluZ0VsZW1lbnRcbiAgICB9O1xuICAgIGlmIChpc0VsZW1lbnQocmVmZXJlbmNlRWxlbWVudCkpIHtcbiAgICAgIHZhbHVlc1RvU3luYy5kb21SZWZlcmVuY2VFbGVtZW50ID0gcmVmZXJlbmNlRWxlbWVudDtcbiAgICB9XG4gICAgaWYgKHN0b3JlLnN0YXRlLnBvc2l0aW9uUmVmZXJlbmNlID09PSBzdG9yZS5zdGF0ZS5yZWZlcmVuY2VFbGVtZW50KSB7XG4gICAgICB2YWx1ZXNUb1N5bmMucG9zaXRpb25SZWZlcmVuY2UgPSByZWZlcmVuY2VFbGVtZW50O1xuICAgIH1cbiAgICBzdG9yZS51cGRhdGUodmFsdWVzVG9TeW5jKTtcbiAgfSwgW29wZW4sIGZsb2F0aW5nSWQsIHJlZmVyZW5jZUVsZW1lbnQsIGZsb2F0aW5nRWxlbWVudCwgc3RvcmVdKTtcblxuICAvLyBLZWVwIG5vbi1yZWFjdGl2ZSBjb250ZXh0IHZhbHVlcyBmcmVzaCBmb3IgaW50ZXJhY3Rpb25zIHRoYXQgY2FsbCBgc3RvcmUuc2V0T3BlbmAuXG4gIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlID0gaGFuZGxlT3BlbkNoYW5nZTtcbiAgc3RvcmUuY29udGV4dC5uZXN0ZWQgPSBuZXN0ZWQ7XG4gIHJldHVybiBzdG9yZTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBBbmltYXRpb25GcmFtZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUFuaW1hdGlvbkZyYW1lJztcbi8qKlxuICogUHJvdmlkZXMgYSBzdGF0dXMgc3RyaW5nIGZvciBDU1MgYW5pbWF0aW9ucy5cbiAqIEBwYXJhbSBvcGVuIC0gYSBib29sZWFuIHRoYXQgZGV0ZXJtaW5lcyBpZiB0aGUgZWxlbWVudCBpcyBvcGVuLlxuICogQHBhcmFtIGVuYWJsZUlkbGVTdGF0ZSAtIGEgYm9vbGVhbiB0aGF0IGVuYWJsZXMgdGhlIGAnaWRsZSdgIHN0YXRlIGJldHdlZW4gYCdzdGFydGluZydgIGFuZCBgJ2VuZGluZydgXG4gKiBAcGFyYW0gZGVmZXJFbmRpbmdTdGF0ZSAtIGEgYm9vbGVhbiB0aGF0IGRlbGF5cyB0aGUgYCdlbmRpbmcnYCBzdGF0ZSBieSBhIGZyYW1lXG4gKiBAcGFyYW0gYW5pbWF0ZUluaXRpYWxPcGVuIC0gYSBib29sZWFuIHRoYXQgbWFrZXMgYW4gZWxlbWVudCB3aGljaCBtb3VudHMgYWxyZWFkeSBvcGVuIHN0aWxsIGdvXG4gKiAgIHRocm91Z2ggYCdzdGFydGluZydgLiBPZmYgYnkgZGVmYXVsdCBzbyBjb250ZW50IHRoYXQgd2FzIG9wZW4gb24gdGhlIGZpcnN0IHJlbmRlciAoYVxuICogICBgZGVmYXVsdE9wZW5gIHBvcHVwIG9uIHBhZ2UgbG9hZCwgU1NSJ2QgbWFya3VwKSBkb2Vzbid0IGFuaW1hdGUgaW4uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VUcmFuc2l0aW9uU3RhdHVzKG9wZW4sIGVuYWJsZUlkbGVTdGF0ZSA9IGZhbHNlLCBkZWZlckVuZGluZ1N0YXRlID0gZmFsc2UsIGFuaW1hdGVJbml0aWFsT3BlbiA9IGZhbHNlKSB7XG4gIGNvbnN0IFt0cmFuc2l0aW9uU3RhdHVzLCBzZXRUcmFuc2l0aW9uU3RhdHVzXSA9IFJlYWN0LnVzZVN0YXRlKG9wZW4gJiYgZW5hYmxlSWRsZVN0YXRlID8gJ2lkbGUnIDogdW5kZWZpbmVkKTtcbiAgLy8gU3RhcnRpbmcgYXQgYGZhbHNlYCB3aGlsZSBvcGVuIGxldHMgdGhlIGBvcGVuICYmICFtb3VudGVkYCBicmFuY2ggYmVsb3cgcnVuIG9uIHRoZSBmaXJzdFxuICAvLyByZW5kZXIsIHdoaWNoIGlzIHdoYXQgcHJvZHVjZXMgdGhlIGAnc3RhcnRpbmcnYCBwaGFzZS4gUmVhY3QgcmUtcmVuZGVycyBiZWZvcmUgY29tbWl0dGluZywgc29cbiAgLy8gdGhlIGVsZW1lbnQgaXMgc3RpbGwgbW91bnRlZCBpbiB0aGUgc2FtZSBwYXNzLlxuICBjb25zdCBbbW91bnRlZCwgc2V0TW91bnRlZF0gPSBSZWFjdC51c2VTdGF0ZShvcGVuICYmICFhbmltYXRlSW5pdGlhbE9wZW4pO1xuICBpZiAob3BlbiAmJiAhbW91bnRlZCkge1xuICAgIHNldE1vdW50ZWQodHJ1ZSk7XG4gICAgc2V0VHJhbnNpdGlvblN0YXR1cygnc3RhcnRpbmcnKTtcbiAgfVxuICBpZiAoIW9wZW4gJiYgbW91bnRlZCAmJiB0cmFuc2l0aW9uU3RhdHVzICE9PSAnZW5kaW5nJyAmJiAhZGVmZXJFbmRpbmdTdGF0ZSkge1xuICAgIHNldFRyYW5zaXRpb25TdGF0dXMoJ2VuZGluZycpO1xuICB9XG4gIGlmICghb3BlbiAmJiAhbW91bnRlZCAmJiB0cmFuc2l0aW9uU3RhdHVzID09PSAnZW5kaW5nJykge1xuICAgIHNldFRyYW5zaXRpb25TdGF0dXModW5kZWZpbmVkKTtcbiAgfVxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiAmJiBtb3VudGVkICYmIHRyYW5zaXRpb25TdGF0dXMgIT09ICdlbmRpbmcnICYmIGRlZmVyRW5kaW5nU3RhdGUpIHtcbiAgICAgIGNvbnN0IGZyYW1lID0gQW5pbWF0aW9uRnJhbWUucmVxdWVzdCgoKSA9PiB7XG4gICAgICAgIHNldFRyYW5zaXRpb25TdGF0dXMoJ2VuZGluZycpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBBbmltYXRpb25GcmFtZS5jYW5jZWwoZnJhbWUpO1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfSwgW29wZW4sIG1vdW50ZWQsIHRyYW5zaXRpb25TdGF0dXMsIGRlZmVyRW5kaW5nU3RhdGVdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAvLyBOb3RoaW5nIHRvIGNsZWFyIHdoZW4gdGhlIGVsZW1lbnQgbW91bnRlZCBvcGVuIG9yIHJlb3BlbmVkIGFmdGVyIGl0cyBleGl0IHNldHRsZWQuXG4gICAgaWYgKCFvcGVuIHx8IGVuYWJsZUlkbGVTdGF0ZSB8fCB0cmFuc2l0aW9uU3RhdHVzID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGZyYW1lID0gQW5pbWF0aW9uRnJhbWUucmVxdWVzdCgoKSA9PiB7XG4gICAgICAvLyBBdm9pZCBgZmx1c2hTeW5jYCBoZXJlIGR1ZSB0byBGaXJlZm94LlxuICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvYmFzZS11aS9wdWxsLzM0MjRcbiAgICAgIHNldFRyYW5zaXRpb25TdGF0dXModW5kZWZpbmVkKTtcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgQW5pbWF0aW9uRnJhbWUuY2FuY2VsKGZyYW1lKTtcbiAgICB9O1xuICB9LCBbZW5hYmxlSWRsZVN0YXRlLCBvcGVuLCB0cmFuc2l0aW9uU3RhdHVzXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVJZGxlU3RhdGUpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmIChvcGVuICYmIG1vdW50ZWQgJiYgdHJhbnNpdGlvblN0YXR1cyAhPT0gJ2lkbGUnKSB7XG4gICAgICBzZXRUcmFuc2l0aW9uU3RhdHVzKCdzdGFydGluZycpO1xuICAgIH1cbiAgICBjb25zdCBmcmFtZSA9IEFuaW1hdGlvbkZyYW1lLnJlcXVlc3QoKCkgPT4ge1xuICAgICAgc2V0VHJhbnNpdGlvblN0YXR1cygnaWRsZScpO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBBbmltYXRpb25GcmFtZS5jYW5jZWwoZnJhbWUpO1xuICAgIH07XG4gIH0sIFtlbmFibGVJZGxlU3RhdGUsIG9wZW4sIG1vdW50ZWQsIHRyYW5zaXRpb25TdGF0dXNdKTtcbiAgcmV0dXJuIHtcbiAgICBtb3VudGVkLFxuICAgIHNldE1vdW50ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1c1xuICB9O1xufSIsIi8qKlxuICogRXhjbHVkZXMgaW5maW5pdGUgYW5pbWF0aW9ucywgd2hvc2UgZmluaXNoZWQgcHJvbWlzZXMgbmV2ZXIgcmVzb2x2ZSB3aGlsZSB0aGV5IHJ1bi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZpbml0ZUFuaW1hdGlvbnMoZWxlbWVudCwgb3B0aW9ucykge1xuICByZXR1cm4gZWxlbWVudC5nZXRBbmltYXRpb25zKG9wdGlvbnMpLmZpbHRlcihhbmltYXRpb24gPT4ge1xuICAgIGNvbnN0IHRpbWluZyA9IGFuaW1hdGlvbi5lZmZlY3Q/LmdldFRpbWluZygpO1xuICAgIHJldHVybiB0aW1pbmc/LmR1cmF0aW9uICE9PSBJbmZpbml0eSAmJiB0aW1pbmc/Lml0ZXJhdGlvbnMgIT09IEluZmluaXR5O1xuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyB1c2VBbmltYXRpb25GcmFtZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUFuaW1hdGlvbkZyYW1lJztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgTk9PUCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IHJlc29sdmVSZWYgfSBmcm9tIFwiLi4vdXRpbHMvcmVzb2x2ZVJlZi5tanNcIjtcbmltcG9ydCB7IGdldEZpbml0ZUFuaW1hdGlvbnMgfSBmcm9tIFwiLi4vdXRpbHMvZ2V0RmluaXRlQW5pbWF0aW9ucy5tanNcIjtcbmltcG9ydCAqIGFzIFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcyBmcm9tIFwiLi9UcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMubWpzXCI7XG5sZXQgcGVuZGluZ0NhbGxiYWNrcyA9IG51bGw7XG5cbi8qKlxuICogUnVucyB0aGUgY2FsbGJhY2sgaW4gYSBzeW5jaHJvbm91cyBmbHVzaCBiZWZvcmUgdGhlIGJyb3dzZXIgcGFpbnRzLCBzbyB0aGF0IHRoZVxuICogYnJvd3NlciBkb2Vzbid0IHBhaW50IGFuIGludGVybWVkaWF0ZSBmcmFtZTogaHR0cHM6Ly9naXRodWIuY29tL211aS9iYXNlLXVpL2lzc3Vlcy85NzlcbiAqIENhbGxiYWNrcyB0aGF0IGJlY29tZSByZWFkeSB3aXRoaW4gdGhlIHNhbWUgbWljcm90YXNrIGNoZWNrcG9pbnQgKGUuZy4gbXVsdGlwbGUgZWxlbWVudHNcbiAqIHdob3NlIGFuaW1hdGlvbnMgZmluaXNoIHRvZ2V0aGVyKSBhcmUgYmF0Y2hlZCBpbnRvIGEgc2luZ2xlIGNvbW1pdDpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvYmFzZS11aS9pc3N1ZXMvNTQ4MVxuICovXG5mdW5jdGlvbiBmbHVzaEJlZm9yZVBhaW50KGZuKSB7XG4gIGlmICghcGVuZGluZ0NhbGxiYWNrcykge1xuICAgIGNvbnN0IGNhbGxiYWNrcyA9IFtdO1xuICAgIHBlbmRpbmdDYWxsYmFja3MgPSBjYWxsYmFja3M7XG4gICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgcGVuZGluZ0NhbGxiYWNrcyA9IG51bGw7XG4gICAgICBSZWFjdERPTS5mbHVzaFN5bmMoKCkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIGNhbGxiYWNrcykge1xuICAgICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIHBlbmRpbmdDYWxsYmFja3MucHVzaChmbik7XG59XG5cbi8qKlxuICogRXhlY3V0ZXMgYSBmdW5jdGlvbiBvbmNlIGFsbCBhbmltYXRpb25zIGhhdmUgZmluaXNoZWQgb24gdGhlIHByb3ZpZGVkIGVsZW1lbnQuXG4gKiBJZiBhbiBhbmltYXRpb24gaXMgY2FuY2VsZWQsIHdhaXRzIGZvciBhbnkgcmVwbGFjZW1lbnQgYW5pbWF0aW9ucyBiZWZvcmUgZXhlY3V0aW5nLlxuICogQHBhcmFtIGVsZW1lbnRPclJlZiAtIFRoZSBlbGVtZW50IHRvIHdhdGNoIGZvciBhbmltYXRpb25zLlxuICogQHBhcmFtIHdhaXRGb3JTdGFydGluZ1N0eWxlUmVtb3ZlZCAtIFdoZXRoZXIgdG8gd2FpdCBmb3IgW2RhdGEtc3RhcnRpbmctc3R5bGVdIHRvIGJlIHJlbW92ZWQgYmVmb3JlIGNoZWNraW5nIGZvciBhbmltYXRpb25zLlxuICogQHBhcmFtIGJhdGNoIC0gV2hldGhlciBjb21wbGV0aW9ucyByZWFkeSBpbiB0aGUgc2FtZSBtaWNyb3Rhc2sgbWF5IGJlIGNvYWxlc2NlZCBpbnRvIGEgc2luZ2xlXG4gKiBjb21taXQuIEEgYmF0Y2hlZCBjYWxsYmFjayBydW5zIGJlZm9yZSBlYXJsaWVyIGNhbGxiYWNrcycgUmVhY3QgdXBkYXRlcyBoYXZlIGNvbW1pdHRlZCwgc28gb25seVxuICogb3B0IGluIHdoZW4gdGhlIGNhbGxiYWNrIGRvZXNuJ3QgcmVhZCBzdGF0ZSB0aGF0IGFub3RoZXIgY29tcGxldGlvbiBjYW4gY2hhbmdlLlxuICogQHJldHVybnMgQSBmdW5jdGlvbiB0aGF0IHRha2VzIGEgY2FsbGJhY2sgdG8gZXhlY3V0ZSBvbmNlIGFsbCBhbmltYXRpb25zIGhhdmUgZmluaXNoZWQsIGFuZCBhbiBvcHRpb25hbCBBYm9ydFNpZ25hbCB0byBhYm9ydCB0aGUgY2FsbGJhY2tcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUFuaW1hdGlvbnNGaW5pc2hlZChlbGVtZW50T3JSZWYsIHdhaXRGb3JTdGFydGluZ1N0eWxlUmVtb3ZlZCA9IGZhbHNlLCBiYXRjaCA9IGZhbHNlKSB7XG4gIGNvbnN0IGZyYW1lID0gdXNlQW5pbWF0aW9uRnJhbWUoKTtcbiAgcmV0dXJuIHVzZVN0YWJsZUNhbGxiYWNrKChmblRvRXhlY3V0ZSxcbiAgLyoqXG4gICAqIEFuIG9wdGlvbmFsIFtBYm9ydFNpZ25hbF0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0Fib3J0U2lnbmFsKSB0aGF0XG4gICAqIGNhbiBiZSB1c2VkIHRvIGFib3J0IGBmblRvRXhlY3V0ZWAgYmVmb3JlIGFsbCB0aGUgYW5pbWF0aW9ucyBoYXZlIGZpbmlzaGVkLlxuICAgKiBAZGVmYXVsdCBudWxsXG4gICAqL1xuICBzaWduYWwgPSBudWxsKSA9PiB7XG4gICAgZnJhbWUuY2FuY2VsKCk7XG4gICAgY29uc3QgZWxlbWVudCA9IHJlc29sdmVSZWYoZWxlbWVudE9yUmVmKTtcbiAgICBpZiAoZWxlbWVudCA9PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJlc29sdmVkRWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgY29uc3QgZG9uZSA9ICgpID0+IHtcbiAgICAgIGlmICghYmF0Y2gpIHtcbiAgICAgICAgLy8gU3luY2hyb25vdXNseSBmbHVzaCB0aGUgdW5tb3VudGluZyBvZiB0aGUgY29tcG9uZW50IHNvIHRoYXQgdGhlIGJyb3dzZXIgZG9lc24ndFxuICAgICAgICAvLyBwYWludDogaHR0cHM6Ly9naXRodWIuY29tL211aS9iYXNlLXVpL2lzc3Vlcy85NzlcbiAgICAgICAgLy8gRWFjaCBjYWxsYmFjayBnZXRzIGl0cyBvd24gY29tbWl0IHNvIHRoYXQgbGF0ZXIgY29tcGxldGlvbnMgb2JzZXJ2ZSB0aGUgUmVhY3RcbiAgICAgICAgLy8gdXBkYXRlcyBjYXVzZWQgYnkgZWFybGllciBvbmVzLlxuICAgICAgICBSZWFjdERPTS5mbHVzaFN5bmMoZm5Ub0V4ZWN1dGUpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBmbHVzaEJlZm9yZVBhaW50KCgpID0+IHtcbiAgICAgICAgLy8gUmUtY2hlY2sgYXQgZmx1c2ggdGltZTogdGhlIHNpZ25hbCBtYXkgYWJvcnQgYmV0d2VlbiBxdWV1ZWluZyBhbmQgdGhlIGZsdXNoLlxuICAgICAgICBpZiAoIXNpZ25hbD8uYWJvcnRlZCkge1xuICAgICAgICAgIGZuVG9FeGVjdXRlKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgaWYgKHR5cGVvZiByZXNvbHZlZEVsZW1lbnQuZ2V0QW5pbWF0aW9ucyAhPT0gJ2Z1bmN0aW9uJyB8fCBnbG9iYWxUaGlzLkJBU0VfVUlfQU5JTUFUSU9OU19ESVNBQkxFRCkge1xuICAgICAgZm5Ub0V4ZWN1dGUoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZnVuY3Rpb24gZXhlYygpIHtcbiAgICAgIC8vIERpc2NhcmQgZnVsZmlsbGVkIEFuaW1hdGlvbiB2YWx1ZXMgc28gdW5maW5pc2hlZCBhbmltYXRpb25zIGNhbm5vdCByZXRhaW4gdGhlaXIgdGFyZ2V0cy5cbiAgICAgIFByb21pc2UuYWxsKGdldEZpbml0ZUFuaW1hdGlvbnMocmVzb2x2ZWRFbGVtZW50KS5tYXAoYW5pbWF0aW9uID0+IGFuaW1hdGlvbi5maW5pc2hlZC50aGVuKE5PT1ApKSkudGhlbigoKSA9PiB7XG4gICAgICAgIGlmICghc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICAgICAgZG9uZSgpO1xuICAgICAgICB9XG4gICAgICB9LCAoKSA9PiB7XG4gICAgICAgIGlmIChzaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY3VycmVudEFuaW1hdGlvbnMgPSBnZXRGaW5pdGVBbmltYXRpb25zKHJlc29sdmVkRWxlbWVudCk7XG4gICAgICAgIGlmIChjdXJyZW50QW5pbWF0aW9ucy5zb21lKGFuaW1hdGlvbiA9PiBhbmltYXRpb24ucGVuZGluZyB8fCBhbmltYXRpb24ucGxheVN0YXRlICE9PSAnZmluaXNoZWQnKSkge1xuICAgICAgICAgIC8vIFNvbWV0aW1lcyBhbmltYXRpb25zIGNhbiBiZSBhYm9ydGVkIGJlY2F1c2UgYSBwcm9wZXJ0eSB0aGV5IGRlcGVuZCBvbiBjaGFuZ2VzIHdoaWxlIHRoZSBhbmltYXRpb24gcGxheXMuXG4gICAgICAgICAgLy8gSW4gc3VjaCBjYXNlcywgd2UgbmVlZCB0byByZS1jaGVjayBpZiBhbnkgbmV3IGFuaW1hdGlvbnMgaGF2ZSBzdGFydGVkLlxuICAgICAgICAgIGV4ZWMoKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZG9uZSgpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmICh3YWl0Rm9yU3RhcnRpbmdTdHlsZVJlbW92ZWQpIHtcbiAgICAgIGNvbnN0IHN0YXJ0aW5nU3R5bGVBdHRyaWJ1dGUgPSBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcblxuICAgICAgLy8gSWYgYFtkYXRhLXN0YXJ0aW5nLXN0eWxlXWAgaXNuJ3QgcHJlc2VudCwgZmFsbCBiYWNrIHRvIHdhaXRpbmcgb25lIG1vcmUgZnJhbWVcbiAgICAgIC8vIHRvIGdpdmUgXCJvcGVuXCIgYW5pbWF0aW9ucyBhIGNoYW5jZSB0byBiZSByZWdpc3RlcmVkLlxuICAgICAgaWYgKCFyZXNvbHZlZEVsZW1lbnQuaGFzQXR0cmlidXRlKHN0YXJ0aW5nU3R5bGVBdHRyaWJ1dGUpKSB7XG4gICAgICAgIGZyYW1lLnJlcXVlc3QoZXhlYyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gV2FpdCBmb3IgYFtkYXRhLXN0YXJ0aW5nLXN0eWxlXWAgdG8gaGF2ZSBiZWVuIHJlbW92ZWQuXG4gICAgICBjb25zdCBhdHRyaWJ1dGVPYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcbiAgICAgICAgaWYgKCFyZXNvbHZlZEVsZW1lbnQuaGFzQXR0cmlidXRlKHN0YXJ0aW5nU3R5bGVBdHRyaWJ1dGUpKSB7XG4gICAgICAgICAgYXR0cmlidXRlT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICAgIGV4ZWMoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBhdHRyaWJ1dGVPYnNlcnZlci5vYnNlcnZlKHJlc29sdmVkRWxlbWVudCwge1xuICAgICAgICBhdHRyaWJ1dGVzOiB0cnVlLFxuICAgICAgICBhdHRyaWJ1dGVGaWx0ZXI6IFtzdGFydGluZ1N0eWxlQXR0cmlidXRlXVxuICAgICAgfSk7XG4gICAgICBzaWduYWw/LmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgKCkgPT4gYXR0cmlidXRlT2JzZXJ2ZXIuZGlzY29ubmVjdCgpLCB7XG4gICAgICAgIG9uY2U6IHRydWVcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBmcmFtZS5yZXF1ZXN0KGV4ZWMpO1xuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlQW5pbWF0aW9uc0ZpbmlzaGVkIH0gZnJvbSBcIi4vdXNlQW5pbWF0aW9uc0ZpbmlzaGVkLm1qc1wiO1xuXG4vKipcbiAqIENhbGxzIHRoZSBwcm92aWRlZCBmdW5jdGlvbiB3aGVuIHRoZSBDU1Mgb3Blbi9jbG9zZSBhbmltYXRpb24gb3IgdHJhbnNpdGlvbiBjb21wbGV0ZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VPcGVuQ2hhbmdlQ29tcGxldGUocGFyYW1ldGVycykge1xuICBjb25zdCB7XG4gICAgZW5hYmxlZCA9IHRydWUsXG4gICAgb3BlbixcbiAgICByZWYsXG4gICAgYmF0Y2ggPSBmYWxzZSxcbiAgICBvbkNvbXBsZXRlOiBvbkNvbXBsZXRlUGFyYW1cbiAgfSA9IHBhcmFtZXRlcnM7XG4gIGNvbnN0IG9uQ29tcGxldGUgPSB1c2VTdGFibGVDYWxsYmFjayhvbkNvbXBsZXRlUGFyYW0pO1xuICBjb25zdCBydW5PbmNlQW5pbWF0aW9uc0ZpbmlzaCA9IHVzZUFuaW1hdGlvbnNGaW5pc2hlZChyZWYsIG9wZW4sIGJhdGNoKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBydW5PbmNlQW5pbWF0aW9uc0ZpbmlzaChvbkNvbXBsZXRlLCBhYm9ydENvbnRyb2xsZXIuc2lnbmFsKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XG4gICAgfTtcbiAgfSwgW2VuYWJsZWQsIG9wZW4sIG9uQ29tcGxldGUsIHJ1bk9uY2VBbmltYXRpb25zRmluaXNoXSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VGb3JjZWRSZXJlbmRlcmluZyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUZvcmNlZFJlcmVuZGVyaW5nJztcbmltcG9ydCB7IHVzZVRyYW5zaXRpb25TdGF0dXMgfSBmcm9tIFwiLi91c2VUcmFuc2l0aW9uU3RhdHVzLm1qc1wiO1xuaW1wb3J0IHsgdXNlT3BlbkNoYW5nZUNvbXBsZXRlIH0gZnJvbSBcIi4vdXNlT3BlbkNoYW5nZUNvbXBsZXRlLm1qc1wiO1xuLyoqXG4gKiBLZWVwcyBhIHBvcHVwIG1vdW50ZWQgdGhyb3VnaCBpdHMgY2xvc2luZyBhbmltYXRpb24gYW5kIHVubW91bnRzIGl0IG9uY2UgdGhlIGFuaW1hdGlvblxuICogZmluaXNoZXMsIHVubGVzcyB0aGUgY2xvc2UgY3ljbGUgb3B0ZWQgb3V0IHRocm91Z2ggYHByZXZlbnRVbm1vdW50T25DbG9zZWAuXG4gKiBTdG9yZS1hZ25vc3RpYzogaG9zdHMgc3luYyBgbW91bnRlZGAgYW5kIGB0cmFuc2l0aW9uU3RhdHVzYCB3aGVyZXZlciB0aGV5IG5lZWQgdGhlbS5cbiAqXG4gKiBAcmV0dXJucyBgZm9yY2VVbm1vdW50YCB1bm1vdW50cyB0aGUgcG9wdXAgaW1tZWRpYXRlbHkuIEl0IGlzIGEgbm8tb3Agb25jZSB0aGUgcG9wdXAgaXMgYWxyZWFkeVxuICogICB1bm1vdW50ZWQsIHNvIGNhbGxpbmcgaXQgYWZ0ZXIgdGhlIGF1dG9tYXRpYyB1bm1vdW50IGRvZXNuJ3QgcmVwZWF0IHRoZSBjb21wbGV0aW9uIGNhbGxiYWNrLFxuICogICBhbmQgYSBjYWxsIHdoaWxlIHRoZSBwb3B1cCBpcyBvcGVuIG9ubHkgdGFrZXMgZWZmZWN0IGlmIGEgY2xvc2UgY29tbWl0cyBpbiB0aGUgc2FtZSBiYXRjaC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVVubW91bnRBZnRlckNsb3NlKHBhcmFtZXRlcnMpIHtcbiAgY29uc3Qge1xuICAgIG9wZW4sXG4gICAgcmVmLFxuICAgIHByZXZlbnRVbm1vdW50T25DbG9zZSxcbiAgICBzZXRQcmV2ZW50VW5tb3VudE9uQ2xvc2U6IHNldFByZXZlbnRVbm1vdW50T25DbG9zZVBhcmFtLFxuICAgIG9uVW5tb3VudCxcbiAgICBhbmltYXRlSW5pdGlhbE9wZW5cbiAgfSA9IHBhcmFtZXRlcnM7XG4gIGNvbnN0IHNldFByZXZlbnRVbm1vdW50T25DbG9zZSA9IHVzZVN0YWJsZUNhbGxiYWNrKHNldFByZXZlbnRVbm1vdW50T25DbG9zZVBhcmFtKTtcbiAgY29uc3Qge1xuICAgIG1vdW50ZWQsXG4gICAgc2V0TW91bnRlZCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH0gPSB1c2VUcmFuc2l0aW9uU3RhdHVzKG9wZW4sIGZhbHNlLCBmYWxzZSwgYW5pbWF0ZUluaXRpYWxPcGVuKTtcblxuICAvLyBPcGVuaW5nIHN0YXJ0cyBhIG5ldyBjbG9zZSBjeWNsZS4gRGVyaXZlIGR1cmluZyByZW5kZXIgc28gdGhlIGNsb3NlLWNvbXBsZXRpb24gaG9vayBiZWxvd1xuICAvLyByZWFkcyB0aGUgdmFsdWUgb24gdGhlIHNhbWUgcGFzcywgYW5kIGNsZWFyIHRoZSBzdG9yZWQgdmFsdWUgc28gaXQgZG9lc24ndCBsZWFrIGludG8gdGhlIG5leHRcbiAgLy8gY2xvc2UuIFRoZSBlZmZlY3Qgb25seSBydW5zIHdoZW4gYG9wZW5gIGNoYW5nZXMsIHNvIGFuIG9wdC1vdXQgcmVjb3JkZWQgd2hpbGUgYSBjb250cm9sbGVkXG4gIC8vIGNsb3NlIGlzIHN0aWxsIHBlbmRpbmcgKGZvciBleGFtcGxlIGluIGEgdHJhbnNpdGlvbikgaXMgbm90IGNsZWFyZWQgYnkgdGhlIHJlbmRlciB0aGF0IHN0aWxsXG4gIC8vIHNlZXMgYG9wZW5gLlxuICBjb25zdCBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UgPSBvcGVuID8gZmFsc2UgOiBwcmV2ZW50VW5tb3VudE9uQ2xvc2U7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKG9wZW4pIHtcbiAgICAgIHNldFByZXZlbnRVbm1vdW50T25DbG9zZShmYWxzZSk7XG4gICAgfVxuICB9LCBbb3Blbiwgc2V0UHJldmVudFVubW91bnRPbkNsb3NlXSk7XG5cbiAgLy8gTWlycm9ycyBgbW91bnRlZGAgc3luY2hyb25vdXNseSBzbyByZXBlYXRlZCBgZm9yY2VVbm1vdW50KClgIGNhbGxzIGluIG9uZSBiYXRjaCBjb21wbGV0ZVxuICAvLyBjbG9zaW5nIG9uY2UuIFJlc3luY2VkIG9uIGV2ZXJ5IGNvbW1pdDogYHNldE1vdW50ZWQoZmFsc2UpYCB3aGlsZSBvcGVuIHJlLW1vdW50cyBvbiB0aGUgbmV4dFxuICAvLyByZW5kZXIgd2l0aG91dCBjaGFuZ2luZyB0aGUgY29tbWl0dGVkIGBtb3VudGVkYCwgc28gYSBgW21vdW50ZWRdYCBkZXBlbmRlbmN5IHdvdWxkIGxlYXZlIHRoZVxuICAvLyBtaXJyb3Igc3RhbGUgYW5kIGJsb2NrIGV2ZXJ5IGxhdGVyIHVubW91bnQuXG4gIGNvbnN0IG1vdW50ZWRSZWYgPSBSZWFjdC51c2VSZWYobW91bnRlZCk7XG4gIGNvbnN0IHBlbmRpbmdVbm1vdW50UmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgcmVyZW5kZXIgPSB1c2VGb3JjZWRSZXJlbmRlcmluZygpO1xuICBjb25zdCB1bm1vdW50ID0gKCkgPT4ge1xuICAgIG1vdW50ZWRSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIHNldE1vdW50ZWQoZmFsc2UpO1xuICAgIG9uVW5tb3VudCgpO1xuICB9O1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIG1vdW50ZWRSZWYuY3VycmVudCA9IG1vdW50ZWQ7XG4gICAgaWYgKHBlbmRpbmdVbm1vdW50UmVmLmN1cnJlbnQpIHtcbiAgICAgIHBlbmRpbmdVbm1vdW50UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIGlmICghb3BlbiAmJiBtb3VudGVkKSB7XG4gICAgICAgIHVubW91bnQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICBjb25zdCBmb3JjZVVubW91bnQgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKCFtb3VudGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG9wZW4pIHtcbiAgICAgIC8vIFRoZSByZW5kZXJlZCBgb3BlbmAgY2FuJ3QgdGVsbCBhIHN0YWxlIGV4aXQtYW5pbWF0aW9uIGNhbGxiYWNrIGFmdGVyIGEgcXVpY2sgcmVvcGVuIGZyb20gYVxuICAgICAgLy8gY2xvc2UgYmF0Y2hlZCB3aXRoIHRoaXMgY2FsbCAoYGNsb3NlKCk7IHVubW91bnQoKWApLiBEZWNpZGUgb25jZSB0aGUgYmF0Y2ggY29tbWl0czogdW5tb3VudFxuICAgICAgLy8gaWYgdGhlIHBvcHVwIGNsb3NlZCwgb3RoZXJ3aXNlIGRyb3AgdGhlIGNhbGwgcmF0aGVyIHRoYW4gcnVuIHRoZSBob3N0J3MgdW5tb3VudCBjbGVhbnVwIGFuZFxuICAgICAgLy8gdGhlIGNsb3NlIGNvbXBsZXRpb24gYWdhaW5zdCBhIGxpdmUgcG9wdXAuXG4gICAgICBwZW5kaW5nVW5tb3VudFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHJlcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHVubW91bnQoKTtcbiAgfSk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgZW5hYmxlZDogbW91bnRlZCAmJiAhb3BlbiAmJiAhcHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICAgIG9wZW4sXG4gICAgcmVmLFxuICAgIG9uQ29tcGxldGUoKSB7XG4gICAgICBpZiAoIW9wZW4pIHtcbiAgICAgICAgZm9yY2VVbm1vdW50KCk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBtb3VudGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICAgIGZvcmNlVW5tb3VudFxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IEVNUFRZX09CSkVDVCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IHVzZUlkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSWQnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VSZWZXaXRoSW5pdCc7XG5pbXBvcnQgeyBGT0NVU0FCTEVfQVRUUklCVVRFIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2NvbXBvbmVudHMvRmxvYXRpbmdUcmVlLm1qc1wiO1xuaW1wb3J0IHsgdXNlU3luY2VkRmxvYXRpbmdSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlVW5tb3VudEFmdGVyQ2xvc2UgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVVubW91bnRBZnRlckNsb3NlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuZXhwb3J0IGNvbnN0IEZPQ1VTQUJMRV9QT1BVUF9QUk9QUyA9IHtcbiAgdGFiSW5kZXg6IC0xLFxuICBbRk9DVVNBQkxFX0FUVFJJQlVURV06ICcnXG59O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIGRlZmF1bHQgYGluaXRpYWxGb2N1c2AgcmVzb2x2ZXIgZm9yIGEgcG9wdXAuIFdoZW4gb3BlbmVkIGJ5IHRvdWNoIGl0IGZvY3VzZXMgdGhlXG4gKiBwb3B1cCBlbGVtZW50IGl0c2VsZiB0byBwcmV2ZW50IHRoZSB2aXJ0dWFsIGtleWJvYXJkIGZyb20gb3BlbmluZyAocmVxdWlyZWQgZm9yIEFuZHJvaWRcbiAqIHNwZWNpZmljYWxseTsgaU9TIGhhbmRsZXMgdGhpcyBhdXRvbWF0aWNhbGx5KS4gT3RoZXJ3aXNlIGl0IGZhbGxzIGJhY2sgdG8gdGhlIGRlZmF1bHQgYmVoYXZpb3IuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVEZWZhdWx0SW5pdGlhbEZvY3VzKHBvcHVwUmVmKSB7XG4gIHJldHVybiBpbnRlcmFjdGlvblR5cGUgPT4gaW50ZXJhY3Rpb25UeXBlID09PSAndG91Y2gnID8gcG9wdXBSZWYuY3VycmVudCA6IHRydWU7XG59XG5cbi8qKlxuICogVGhlIHN1YnNldCBvZiBhIHBvcHVwIGhhbmRsZSB0aGF0IGEgUm9vdCBuZWVkcyB0byBiaW5kIGl0cyBzdG9yZSB0by4gQm90aCB0aGUgcmVhbCBoYW5kbGUgY2xhc3Nlc1xuICogYW5kIGFueSB0ZXN0IGRvdWJsZSBzYXRpc2Z5IGl0LlxuICovXG5cbi8qKlxuICogQ3JlYXRlcyBhbmQgb3ducyBhIHBvcHVwIHN0b3JlIG9uIGJlaGFsZiBvZiBhIFJvb3QgcGFydC4gVGhlIHN0b3JlIGlzIGNyZWF0ZWQgZXhhY3RseSBvbmNlLCB3aXRoXG4gKiBjb250cm9sbGVkIHByb3BzIGFuZCByb290IHN0YXRlIHN5bmNlZCBzZXBhcmF0ZWx5IGFmdGVyIGNyZWF0aW9uLiBTZXRzIHVwIHRoZSBzeW5jZWQgZmxvYXRpbmdcbiAqIHJvb3QgY29udGV4dCBhbmQgcmV0dXJucyB0aGUgc3RvcmUuXG4gKlxuICogQHBhcmFtIGNyZWF0ZVN0b3JlIEZhY3RvcnkgdGhhdCBidWlsZHMgdGhlIHN0b3JlLiBDYWxsZWQgZXhhY3RseSBvbmNlLCByZWNlaXZpbmcgdGhlIGZsb2F0aW5nIGlkXG4gKiBhbmQgd2hldGhlciB0aGUgcG9wdXAgaXMgbmVzdGVkIGluc2lkZSBhbm90aGVyIGZsb2F0aW5nIGVsZW1lbnQsIGJvdGggcmVzb2x2ZWQgb24gdGhlIGZpcnN0IHJlbmRlci5cbiAqIEBwYXJhbSB0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgV2hldGhlciB0aGUgcG9wdXAgZWxlbWVudCBpcyBwYXNzZWQgdG8gRmxvYXRpbmcgVUkgYXMgdGhlXG4gKiBmbG9hdGluZyBlbGVtZW50IGluc3RlYWQgb2YgdGhlIGRlZmF1bHQgcG9zaXRpb25lci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVBvcHVwUm9vdFN0b3JlKGNyZWF0ZVN0b3JlLCB0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgPSBmYWxzZSkge1xuICBjb25zdCBmbG9hdGluZ0lkID0gdXNlSWQoKTtcbiAgY29uc3QgbmVzdGVkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKSAhPSBudWxsO1xuICBjb25zdCBzdG9yZSA9IHVzZVJlZldpdGhJbml0KCgpID0+IGNyZWF0ZVN0b3JlKGZsb2F0aW5nSWQsIG5lc3RlZCkpLmN1cnJlbnQ7XG4gIHVzZVN5bmNlZEZsb2F0aW5nUm9vdENvbnRleHQoe1xuICAgIHBvcHVwU3RvcmU6IHN0b3JlLFxuICAgIHRyZWF0UG9wdXBBc0Zsb2F0aW5nRWxlbWVudCxcbiAgICBmbG9hdGluZ1Jvb3RDb250ZXh0OiBzdG9yZS5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LFxuICAgIGZsb2F0aW5nSWQsXG4gICAgbmVzdGVkLFxuICAgIG9uT3BlbkNoYW5nZTogc3RvcmUuc2V0T3BlblxuICB9KTtcbiAgcmV0dXJuIHN0b3JlO1xufVxuXG4vKipcbiAqIEF0dGFjaGVzIGEgUm9vdCdzIHN0b3JlIHRvIGEgaGFuZGxlIGZvciB0aGlzIGNvbXBvbmVudCdzIGNvbW1pdHRlZCBsaWZldGltZS4gUG9wdXAgUm9vdHMgcmVuZGVyXG4gKiBpdCBiZWZvcmUgdGhlaXIgaW50ZXJhY3Rpb25zIGFuZCB1c2VyIGNoaWxkcmVuIHNvIGl0cyBsYXlvdXQgZWZmZWN0IHJ1bnMgYmVmb3JlIGRlc2NlbmRhbnQgbGF5b3V0XG4gKiBlZmZlY3RzLiBUaGlzIGxldHMgZGVzY2VuZGFudHMgY2FsbCB0aGUgaGFuZGxlIGR1cmluZyB0aGUgUm9vdCdzIGluaXRpYWwgY29tbWl0IHdpdGhvdXQgYXR0YWNoaW5nXG4gKiBkdXJpbmcgcmVuZGVyLCB3aGljaCB3b3VsZCBsZWFrIHN1c3BlbmRlZCBvciBhYmFuZG9uZWQgc3RvcmVzLiBTdG9yZSBzdWJzY3JpYmVycyBhcmUgbm90aWZpZWQgYnlcbiAqIGBhdHRhY2hTdG9yZWAgaW4gdGhpcyBvcmRpbmFyeSBsYXlvdXQgcGhhc2UsIHdoZXJlIFJlYWN0IHBlcm1pdHMgc3luY2hyb25vdXMgdXBkYXRlcy5cbiAqXG4gKiBQb3B1cCBSb290cyBtdXN0IHJlbmRlciB0aGlzIGNvbXBvbmVudCBvbmx5IHdoZW4gYSBoYW5kbGUgaXMgcHJlc2VudCBzbyBoYW5kbGUtbGVzcyBSb290cyBhdm9pZFxuICogbW91bnRpbmcgYW4gZXh0cmEgZmliZXIgYW5kIGxheW91dCBlZmZlY3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBQb3B1cEhhbmRsZUF0dGFjaG1lbnQoe1xuICBoYW5kbGUsXG4gIHN0b3JlXG59KSB7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuIGhhbmRsZS5hdHRhY2hTdG9yZShzdG9yZSk7XG4gIH0sIFtoYW5kbGUsIHN0b3JlXSk7XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gc3luY1RyaWdnZXJDb3VudChzdG9yZSkge1xuICBjb25zdCB0cmlnZ2VyQ291bnQgPSBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5zaXplO1xuICBpZiAoc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgc3RvcmUuc3RhdGUudHJpZ2dlckNvdW50ICE9PSB0cmlnZ2VyQ291bnQpIHtcbiAgICBzdG9yZS5zZXQoJ3RyaWdnZXJDb3VudCcsIHRyaWdnZXJDb3VudCk7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3RhYmxlIGNhbGxiYWNrIHJlZiB0aGF0IHJlZ2lzdGVycy91bnJlZ2lzdGVycyB0aGUgdHJpZ2dlciBlbGVtZW50IGluIHRoZSBzdG9yZS5cbiAqXG4gKiBTdGFibGUgc28gYSBkb3duc3RyZWFtIHJlZiBtZXJnZXIgdGhhdCByZXRhaW5zIHRoZSBjYWxsYmFjayBpdCB3YXMgZmlyc3QgZ2l2ZW4gc3RpbGwgcmVhY2hlcyB0aGVcbiAqIHRyaWdnZXIncyBjdXJyZW50IHN0b3JlLiBUaGUgcmVnaXN0cmF0aW9uIGlzIHRyYWNrZWQgYXMgYSBgKHN0b3JlLCBpZCwgZWxlbWVudClgIHRyaXBsZSwgc29cbiAqIHVucmVnaXN0ZXJpbmcgdGFyZ2V0cyB0aGUgc3RvcmUgdGhlIGVsZW1lbnQgd2FzIGFjdHVhbGx5IHJlZ2lzdGVyZWQgaW4uXG4gKlxuICogU2luY2UgdGhlIGNhbGxiYWNrIG5ldmVyIGNoYW5nZXMsIHRoZSBjYWxsZXIgbXVzdCByZS1ydW4gaXQgZnJvbSBhIGxheW91dCBlZmZlY3Qga2V5ZWQgb25cbiAqIGBbc3RvcmUsIGlkXWAgdG8gbWlncmF0ZSBhbiBhbHJlYWR5LXJlZ2lzdGVyZWQgZWxlbWVudC4gVGhhdCBlZmZlY3QgaXMgYWxzbyB3aGF0IHJlZ2lzdGVycyB0aGVcbiAqIGVsZW1lbnQgaW4gdGhlIGZpcnN0IHBsYWNlIHdoZW4gYGlkYCBvbmx5IHJlc29sdmVzIGFmdGVyIHRoZSBmaXJzdCBjb21taXQgKFJlYWN0IDE3J3MgYHVzZUlkYFxuICogZmFsbGJhY2spLCBiZWNhdXNlIHRoZSByZWdpc3RlciBjYWxsIG1hZGUgd2hpbGUgdGhlIGlkIGlzIHN0aWxsIGB1bmRlZmluZWRgIGRvZXMgbm90aGluZy5cbiAqXG4gKiBAcGFyYW0gaWQgSWQgb2YgdGhlIHRyaWdnZXIuXG4gKiBAcGFyYW0gc3RvcmUgVGhlIFN0b3JlIGluc3RhbmNlIHdoZXJlIHRoZSB0cmlnZ2VyIHNob3VsZCBiZSByZWdpc3RlcmVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVHJpZ2dlclJlZ2lzdHJhdGlvbihpZCwgc3RvcmUpIHtcbiAgY29uc3QgcmVnaXN0cmF0aW9uUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICByZXR1cm4gdXNlU3RhYmxlQ2FsbGJhY2soZWxlbWVudCA9PiB7XG4gICAgY29uc3QgcmVnaXN0cmF0aW9uID0gcmVnaXN0cmF0aW9uUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHJlZ2lzdHJhdGlvbiAhPT0gbnVsbCkge1xuICAgICAgaWYgKHJlZ2lzdHJhdGlvbi5lbGVtZW50ID09PSBlbGVtZW50ICYmIHJlZ2lzdHJhdGlvbi5zdG9yZSA9PT0gc3RvcmUgJiYgcmVnaXN0cmF0aW9uLmlkID09PSBpZCkge1xuICAgICAgICAvLyBBbHJlYWR5IHJlZ2lzdGVyZWQgd2hlcmUgaXQgYmVsb25ncywgc28gdGhlIGNhbGxlcidzIG1pZ3JhdGlvbiBlZmZlY3QgaXMgZnJlZSBvbiBtb3VudC5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcmVnaXN0cmF0aW9uUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgY29uc3QgcmVnaXN0ZXJlZFN0b3JlID0gcmVnaXN0cmF0aW9uLnN0b3JlO1xuICAgICAgaWYgKHJlZ2lzdGVyZWRTdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5nZXRCeUlkKHJlZ2lzdHJhdGlvbi5pZCkgPT09IHJlZ2lzdHJhdGlvbi5lbGVtZW50KSB7XG4gICAgICAgIHJlZ2lzdGVyZWRTdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5kZWxldGUocmVnaXN0cmF0aW9uLmlkKTtcbiAgICAgICAgc3luY1RyaWdnZXJDb3VudChyZWdpc3RlcmVkU3RvcmUpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZWxlbWVudCAhPT0gbnVsbCAmJiBpZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZWdpc3RyYXRpb25SZWYuY3VycmVudCA9IHtcbiAgICAgICAgc3RvcmUsXG4gICAgICAgIGlkLFxuICAgICAgICBlbGVtZW50XG4gICAgICB9O1xuICAgICAgc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuYWRkKGlkLCBlbGVtZW50KTtcbiAgICAgIHN5bmNUcmlnZ2VyQ291bnQoc3RvcmUpO1xuICAgIH1cbiAgfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUG9wdXBPcGVuU3RhdGUoc3RhdGUsIG9wZW4sIHRyaWdnZXIsIHByZXZlbnRVbm1vdW50T25DbG9zZSA9IGZhbHNlKSB7XG4gIGxldCBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UgPSBzdGF0ZS5wcmV2ZW50VW5tb3VudGluZ09uQ2xvc2U7XG4gIGlmIChvcGVuKSB7XG4gICAgLy8gT3BlbmluZyBzdGFydHMgYSBuZXcgY2xvc2UgY3ljbGUsIHNvIGNsZWFyIGFueSBwcmV2aW91cyByZXF1ZXN0IHRvIGtlZXAgdGhlIHBvcHVwIG1vdW50ZWQuXG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlID0gZmFsc2U7XG4gIH0gZWxzZSBpZiAocHJldmVudFVubW91bnRPbkNsb3NlKSB7XG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlID0gdHJ1ZTtcbiAgfVxuICBjb25zdCB0cmlnZ2VySWQgPSB0cmlnZ2VyPy5pZCA/PyBudWxsO1xuICBsZXQgYWN0aXZlVHJpZ2dlcklkID0gc3RhdGUuYWN0aXZlVHJpZ2dlcklkO1xuICBsZXQgYWN0aXZlVHJpZ2dlckVsZW1lbnQgPSBzdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudDtcblxuICAvLyBJZiBhIHBvcHVwIGlzIGNsb3NpbmcsIHRoZSBgdHJpZ2dlcmAgbWF5IGJlIHVuZGVmaW5lZC5cbiAgLy8gV2Ugd2FudCB0byBrZWVwIHRoZSBwcmV2aW91cyB2YWx1ZSBzbyB0aGF0IGV4aXQgYW5pbWF0aW9ucyBhcmUgcGxheWVkIGFuZCBmb2N1cyBpcyByZXR1cm5lZCBjb3JyZWN0bHkuXG4gIGlmICh0cmlnZ2VySWQgfHwgb3Blbikge1xuICAgIGFjdGl2ZVRyaWdnZXJJZCA9IHRyaWdnZXJJZDtcbiAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudCA9IHRyaWdnZXIgPz8gbnVsbDtcbiAgfVxuICByZXR1cm4ge1xuICAgIG9wZW4sXG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICAgIGFjdGl2ZVRyaWdnZXJJZCxcbiAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudCxcbiAgICAvLyBBbiBvcGVuIHJlcXVlc3Qgd2l0aG91dCBhIHRyaWdnZXIgKGEgaGFuZGxlJ3MgYG9wZW4obnVsbClgIG9yIGBvcGVuV2l0aFBheWxvYWQoKWApIG11c3Qgbm90XG4gICAgLy8gYmUgcmVhc3NvY2lhdGVkIHdpdGggYSBsb25lIHJlZ2lzdGVyZWQgdHJpZ2dlciBsYXRlciBvbi4gQ29udHJvbGxlZCBhbmQgZGVmYXVsdCBvcGVucyBuZXZlclxuICAgIC8vIHBhc3MgdGhyb3VnaCBoZXJlLCBzbyB0aGV5IGtlZXAgY2xhaW1pbmcgYSBsb25lIHRyaWdnZXIuIEEgY2xvc2UgcmVxdWVzdCBrZWVwcyB0aGUgZmxhZzogYVxuICAgIC8vIGNvbnRyb2xsZWQgcm9vdCBtYXkgZGVjbGluZSBpdCBhbmQgc3RheSBvcGVuLCBzbyB0aGUgUm9vdCBjbGVhcnMgdGhlIGZsYWcgb25seSBvbmNlIHRoZVxuICAgIC8vIHBvcHVwIGlzIGVmZmVjdGl2ZWx5IGNsb3NlZC5cbiAgICBvcGVuZWRXaXRob3V0VHJpZ2dlcjogb3BlbiA/IHRyaWdnZXIgPT0gbnVsbCA6IHN0YXRlLm9wZW5lZFdpdGhvdXRUcmlnZ2VyXG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlKGV2ZW50RGV0YWlscykge1xuICBsZXQgcHJldmVudFVubW91bnRPbkNsb3NlID0gZmFsc2U7XG4gIGV2ZW50RGV0YWlscy5wcmV2ZW50VW5tb3VudE9uQ2xvc2UgPSAoKSA9PiB7XG4gICAgcHJldmVudFVubW91bnRPbkNsb3NlID0gdHJ1ZTtcbiAgfTtcbiAgcmV0dXJuICgpID0+IHByZXZlbnRVbm1vdW50T25DbG9zZTtcbn1cblxuLyoqXG4gKiBSdW5zIHRoZSBzaGFyZWQgb3Blbi1jaGFuZ2Ugc2VxdWVuY2UgZm9yIGEgcG9wdXAgc3RvcmU6IG5vdGlmaWVzIGBvbk9wZW5DaGFuZ2VgLFxuICogaG9ub3JzIGNhbmNlbGxhdGlvbiwgZGlzcGF0Y2hlcyB0aGUgZmxvYXRpbmcgcm9vdCBjaGFuZ2UsIG1hcHMgdGhlIHJlYXNvbiB0byBhblxuICogYGluc3RhbnRUeXBlYCwgYW5kIGNvbW1pdHMgdGhlIHN0YXRlIHVwZGF0ZSAoc3luY2hyb25vdXNseSBmb3IgaG92ZXIgc29cbiAqIGBnZXRBbmltYXRpb25zKClgIG9ic2VydmVzIGl0KS4gU3RvcmVzIHN1cHBseSB0aGVpciBvd24gZGlmZmVyZW5jZXMgdmlhXG4gKiBgZXh0cmFTdGF0ZWAgKGUuZy4gdGhlIGxhc3QgY2hhbmdlIHJlYXNvbikgYW5kIGBvbkJlZm9yZURpc3BhdGNoYCAoZS5nLiB1cGRhdGluZ1xuICogaW5saW5lLXJlY3QgY29vcmRpbmF0ZXMpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlQb3B1cE9wZW5DaGFuZ2Uoc3RvcmUsIG5leHRPcGVuLCBldmVudERldGFpbHMsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCByZWFzb24gPSBldmVudERldGFpbHMucmVhc29uO1xuICBjb25zdCBpc0hvdmVyID0gcmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJIb3ZlcjtcbiAgY29uc3QgaXNGb2N1c09wZW4gPSBuZXh0T3BlbiAmJiByZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckZvY3VzO1xuICBjb25zdCBpc0Rpc21pc3NDbG9zZSA9ICFuZXh0T3BlbiAmJiAocmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJQcmVzcyB8fCByZWFzb24gPT09IFJFQVNPTlMuZXNjYXBlS2V5KTtcbiAgY29uc3Qgc2hvdWxkUHJldmVudFVubW91bnRPbkNsb3NlID0gYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlKGV2ZW50RGV0YWlscyk7XG4gIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlPy4obmV4dE9wZW4sIGV2ZW50RGV0YWlscyk7XG4gIGlmIChldmVudERldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgIHJldHVybjtcbiAgfVxuICBvcHRpb25zLm9uQmVmb3JlRGlzcGF0Y2g/LigpO1xuICBzdG9yZS5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LmRpc3BhdGNoT3BlbkNoYW5nZShuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgY29uc3QgY2hhbmdlU3RhdGUgPSAoKSA9PiB7XG4gICAgY29uc3QgcG9wdXBPcGVuU3RhdGUgPSBjcmVhdGVQb3B1cE9wZW5TdGF0ZShzdG9yZS5zdGF0ZSwgbmV4dE9wZW4sIGV2ZW50RGV0YWlscy50cmlnZ2VyLCBzaG91bGRQcmV2ZW50VW5tb3VudE9uQ2xvc2UoKSk7XG4gICAgY29uc3QgdXBkYXRlZFN0YXRlID0ge1xuICAgICAgLi4ub3B0aW9ucy5leHRyYVN0YXRlLFxuICAgICAgLi4ucG9wdXBPcGVuU3RhdGVcbiAgICB9O1xuICAgIGlmIChpc0ZvY3VzT3Blbikge1xuICAgICAgdXBkYXRlZFN0YXRlLmluc3RhbnRUeXBlID0gJ2ZvY3VzJztcbiAgICB9IGVsc2UgaWYgKGlzRGlzbWlzc0Nsb3NlKSB7XG4gICAgICB1cGRhdGVkU3RhdGUuaW5zdGFudFR5cGUgPSAnZGlzbWlzcyc7XG4gICAgfSBlbHNlIGlmIChpc0hvdmVyKSB7XG4gICAgICB1cGRhdGVkU3RhdGUuaW5zdGFudFR5cGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHN0b3JlLnVwZGF0ZSh1cGRhdGVkU3RhdGUpO1xuICB9O1xuICBpZiAoaXNIb3Zlcikge1xuICAgIC8vIEZsdXNoIHN5bmNocm9ub3VzbHkgZm9yIGhvdmVyIHNvIGBub2RlLmdldEFuaW1hdGlvbnMoKWAgc2VlcyB0aGUgbmV3IHN0YXRlLlxuICAgIFJlYWN0RE9NLmZsdXNoU3luYyhjaGFuZ2VTdGF0ZSk7XG4gIH0gZWxzZSB7XG4gICAgY2hhbmdlU3RhdGUoKTtcbiAgfVxufVxuXG4vKipcbiAqIFNldHMgdXAgdHJpZ2dlciBkYXRhIGZvcndhcmRpbmcgdG8gdGhlIHN0b3JlLlxuICpcbiAqIEBwYXJhbSB0cmlnZ2VySWQgSWQgb2YgdGhlIHRyaWdnZXIuXG4gKiBAcGFyYW0gdHJpZ2dlckVsZW1lbnRSZWYgUmVmIGZvciB0aGUgdHJpZ2dlciBET00gZWxlbWVudC5cbiAqIEBwYXJhbSBzdG9yZSBUaGUgU3RvcmUgaW5zdGFuY2UgbWFuYWdpbmcgdGhlIHBvcHVwIHN0YXRlLlxuICogQHBhcmFtIHN0YXRlVXBkYXRlcyBBbiBvYmplY3Qgd2l0aCBzdGF0ZSB1cGRhdGVzIHRvIGFwcGx5IHdoZW4gdGhlIHRyaWdnZXIgaXMgYWN0aXZlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVHJpZ2dlckRhdGFGb3J3YXJkaW5nKHRyaWdnZXJJZCwgdHJpZ2dlckVsZW1lbnRSZWYsIHN0b3JlLCBzdGF0ZVVwZGF0ZXMpIHtcbiAgY29uc3QgaXNNb3VudGVkQnlUaGlzVHJpZ2dlciA9IHN0b3JlLnVzZVN0YXRlKCdpc01vdW50ZWRCeVRyaWdnZXInLCB0cmlnZ2VySWQpO1xuICBjb25zdCBiYXNlUmVnaXN0ZXJUcmlnZ2VyID0gdXNlVHJpZ2dlclJlZ2lzdHJhdGlvbih0cmlnZ2VySWQsIHN0b3JlKTtcblxuICAvLyBBcHBsaWVzIHRyaWdnZXItb3duZWQgc3RhdGUgKGFjdGl2ZS10cmlnZ2VyIG93bmVyc2hpcCBhbmQgcGF5bG9hZCkgd2hlbiB0aGUgdHJpZ2dlciByZWdpc3RlcnMuXG4gIC8vIFN0YWJsZSBzbyBwYXlsb2FkL2BzdGF0ZVVwZGF0ZXNgIGNoYW5nZXMgZG8gbm90IGNoYW5nZSB0aGUgcmVmIGlkZW50aXR5ICh3aGljaCB3b3VsZCBuZWVkbGVzc2x5XG4gIC8vIGNodXJuIHJlZ2lzdHJhdGlvbik7IGl0IHJlYWRzIHRoZSBsYXRlc3QgY2xvc3VyZSB2YWx1ZXMgd2hlbiBpbnZva2VkLlxuICBjb25zdCBhcHBseVRyaWdnZXJEYXRhID0gdXNlU3RhYmxlQ2FsbGJhY2soZWxlbWVudCA9PiB7XG4gICAgY29uc3Qgb3BlbiA9IHN0b3JlLnNlbGVjdCgnb3BlbicpO1xuICAgIGNvbnN0IGFjdGl2ZVRyaWdnZXJJZCA9IHN0b3JlLnNlbGVjdCgnYWN0aXZlVHJpZ2dlcklkJyk7XG4gICAgaWYgKGFjdGl2ZVRyaWdnZXJJZCA9PT0gdHJpZ2dlcklkKSB7XG4gICAgICBjb25zdCBjaGFuZ2VzID0ge1xuICAgICAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogZWxlbWVudCxcbiAgICAgICAgLi4uKG9wZW4gPyBzdGF0ZVVwZGF0ZXMgOiBudWxsKVxuICAgICAgfTtcbiAgICAgIHN0b3JlLnVwZGF0ZShjaGFuZ2VzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGFjdGl2ZVRyaWdnZXJJZCA9PSBudWxsICYmIG9wZW4gJiYgIXN0b3JlLnN0YXRlLm9wZW5lZFdpdGhvdXRUcmlnZ2VyKSB7XG4gICAgICAvLyBJZiBhIHBvcHVwIGlzIGFscmVhZHkgb3BlbiwgYSBkZXRhY2hlZCB0cmlnZ2VyIGNhbiBtb3VudCBiZWZvcmUgYW55IGFjdGl2ZSB0cmlnZ2VyXG4gICAgICAvLyBoYXMgYmVlbiBlc3RhYmxpc2hlZC4gQ2xhaW0gdGhlIGZpcnN0IHJlZ2lzdGVyZWQgdHJpZ2dlciBzbyB0cmlnZ2VyLW93bmVkIGZvY3VzXG4gICAgICAvLyBtYW5hZ2VtZW50IGFuZCBBUklBIHJlbGF0aW9uc2hpcHMgd29yay4gQSBwb3B1cCBvcGVuZWQgZGVsaWJlcmF0ZWx5IHdpdGhvdXQgYSB0cmlnZ2VyXG4gICAgICAvLyBzdGF5cyB1bmFzc29jaWF0ZWQgc28gdGhlIHRyaWdnZXIncyBgcGF5bG9hZGAgZG9lcyBub3QgcmVwbGFjZSB0aGUgcHJvZ3JhbW1hdGljIG9uZS5cbiAgICAgIGNvbnN0IGNoYW5nZXMgPSB7XG4gICAgICAgIGFjdGl2ZVRyaWdnZXJJZDogdHJpZ2dlcklkID8/IG51bGwsXG4gICAgICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBlbGVtZW50LFxuICAgICAgICAuLi5zdGF0ZVVwZGF0ZXNcbiAgICAgIH07XG4gICAgICBzdG9yZS51cGRhdGUoY2hhbmdlcyk7XG4gICAgfVxuICB9KTtcblxuICAvLyBTdGFibGUsIHNvIHRoZSBtZXJnZWQgcmVmIG9uIHRoZSByZW5kZXJlZCBlbGVtZW50IGtlZXBzIGl0cyBpZGVudGl0eSBmb3IgdGhlIHRyaWdnZXIncyB3aG9sZVxuICAvLyBsaWZldGltZS5cbiAgY29uc3QgcmVnaXN0ZXJUcmlnZ2VyID0gdXNlU3RhYmxlQ2FsbGJhY2soZWxlbWVudCA9PiB7XG4gICAgYmFzZVJlZ2lzdGVyVHJpZ2dlcihlbGVtZW50KTtcbiAgICBpZiAoZWxlbWVudCkge1xuICAgICAgYXBwbHlUcmlnZ2VyRGF0YShlbGVtZW50KTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEEgc3RhYmxlIHJlZiBkb2VzIG5vdCByZS1maXJlIG9uIGEgc3RvcmUgb3IgaWQgY2hhbmdlLCBzbyBtaWdyYXRlIGhlcmUgaW5zdGVhZDogdW5yZWdpc3RlciBmcm9tXG4gIC8vIHRoZSBwcmV2aW91cyBzdG9yZSwgdGhlbiByZWdpc3RlciB0aGUgZWxlbWVudCB0aGUgdHJpZ2dlciBzdGlsbCByZW5kZXJzIGludG8gdGhlIGN1cnJlbnQgb25lLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHJlZ2lzdGVyVHJpZ2dlcih0cmlnZ2VyRWxlbWVudFJlZi5jdXJyZW50KTtcbiAgICByZXR1cm4gKCkgPT4gcmVnaXN0ZXJUcmlnZ2VyKG51bGwpO1xuICB9LCBbcmVnaXN0ZXJUcmlnZ2VyLCB0cmlnZ2VyRWxlbWVudFJlZiwgc3RvcmUsIHRyaWdnZXJJZF0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc01vdW50ZWRCeVRoaXNUcmlnZ2VyKSB7XG4gICAgICBjb25zdCBjaGFuZ2VzID0ge1xuICAgICAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogdHJpZ2dlckVsZW1lbnRSZWYuY3VycmVudCxcbiAgICAgICAgLi4uc3RhdGVVcGRhdGVzXG4gICAgICB9O1xuICAgICAgc3RvcmUudXBkYXRlKGNoYW5nZXMpO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtpc01vdW50ZWRCeVRoaXNUcmlnZ2VyLCBzdG9yZSwgdHJpZ2dlckVsZW1lbnRSZWYsIC4uLk9iamVjdC52YWx1ZXMoc3RhdGVVcGRhdGVzKV0pO1xuICByZXR1cm4ge1xuICAgIHJlZ2lzdGVyVHJpZ2dlcixcbiAgICBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyXG4gIH07XG59XG4vKipcbiAqIEtlZXBzIHRyaWdnZXIgcmVnaXN0cmF0aW9uIHN0YXRlIHN5bmNocm9uaXplZCB3aGlsZSB0aGUgcG9wdXAgaXMgb3Blbi5cbiAqXG4gKiBXaGVuIGEgcG9wdXAgb3BlbnMgd2l0aG91dCBhbiBleHBsaWNpdCB0cmlnZ2VyIGlkIGFuZCBleGFjdGx5IG9uZSB0cmlnZ2VyIGlzIHJlZ2lzdGVyZWQsIHRoYXRcbiAqIHRyaWdnZXIgaXMgY2xhaW1lZCBhcyB0aGUgYWN0aXZlIHRyaWdnZXIsIHVubGVzcyB0aGUgb3BlbiByZXF1ZXN0IGRlbGliZXJhdGVseSBjYXJyaWVkIG5vIHRyaWdnZXJcbiAqIChgb3BlbmVkV2l0aG91dFRyaWdnZXJgKS4gV2hlbiB0aGUgYWN0aXZlIHRyaWdnZXIgaWQgaXMgc3RpbGwgcmVnaXN0ZXJlZCBidXQgaXRzXG4gKiBlbGVtZW50IGNoYW5nZWQsIHRoZSBhY3RpdmUgZWxlbWVudCBpcyByZWZyZXNoZWQuIFdoZW4gdGhlIGFjdGl2ZSB0cmlnZ2VyIGlkIGlzIG1pc3NpbmcgZnJvbSB0aGVcbiAqIHJlZ2lzdHJ5IGJ1dCB0aGUgc2FtZSBlbGVtZW50IGlzIHN0aWxsIHJlZ2lzdGVyZWQgdW5kZXIgYSBkaWZmZXJlbnQgaWQgKGUuZy4gdGhlIHJlbmRlcmVkIHRyaWdnZXJcbiAqIGNhcnJpZXMgaXRzIG93biBET00gYGlkYCB0aGF0IGRpZmZlcnMgZnJvbSBCYXNlIFVJJ3MgaW50ZXJuYWwgdHJpZ2dlciBpZCksIHRoZSBhY3RpdmUgaWQgaXNcbiAqIHJlYXNzb2NpYXRlZCB0byB0aGUgcmVnaXN0ZXJlZCBpZCBpbnN0ZWFkIG9mIGJlaW5nIHRyZWF0ZWQgYXMgbG9zdC4gV2hlbiB0aGUgYWN0aXZlIHRyaWdnZXJcbiAqIHVucmVnaXN0ZXJzLCB0aGUgZGVmYXVsdCBwYXRoIHByZXNlcnZlcyBleGlzdGluZyBvd25lcnNoaXAgc28gbm9uLWNsb3NpbmcgcG9wdXAgZmFtaWxpZXMgZG8gbm90XG4gKiBzaWxlbnRseSBjbGFpbSBhIGRpZmZlcmVudCB0cmlnZ2VyIHdoaWxlIHN0YXlpbmcgb3Blbi5cbiAqXG4gKiBJZiBgY2xvc2VPbkFjdGl2ZVRyaWdnZXJVbm1vdW50YCBpcyBlbmFibGVkLCB1bnJlZ2lzdGVyaW5nIGEgcHJldmlvdXNseSByZXNvbHZlZCBhY3RpdmUgdHJpZ2dlclxuICogcmVxdWVzdHMgYSBjbG9zZSBhZnRlciBhIG1pY3JvdGFzayBzbyBhIHNhbWUtdGljayByZXBsYWNlbWVudCB0cmlnZ2VyIHdpdGggdGhlIHNhbWUgaWQgY2FuXG4gKiByZWdpc3RlciBmaXJzdC4gQW4gYWN0aXZlIHRyaWdnZXIgaWQgdGhhdCBoYXMgbm90IG1hdGNoZWQgYSByZWdpc3RlcmVkIHRyaWdnZXIgeWV0IGlzIHRyZWF0ZWQgYXNcbiAqIHBlbmRpbmcgYW5kIGRvZXMgbm90IHJlcXVlc3QgYSBjbG9zZS5cbiAqXG4gKiBUaGlzIHNob3VsZCBiZSBjYWxsZWQgb24gdGhlIFJvb3QgcGFydC5cbiAqXG4gKiBAcGFyYW0gc3RvcmUgVGhlIFN0b3JlIGluc3RhbmNlIG1hbmFnaW5nIHRoZSBwb3B1cCBzdGF0ZS5cbiAqIEBwYXJhbSBvcHRpb25zIE9wdGlvbnMgZm9yIGFjdGl2ZSB0cmlnZ2VyIHVubW91bnQgYmVoYXZpb3IuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VJbXBsaWNpdEFjdGl2ZVRyaWdnZXIoc3RvcmUsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgY2xvc2VPbkFjdGl2ZVRyaWdnZXJVbm1vdW50ID0gZmFsc2VcbiAgfSA9IG9wdGlvbnM7XG4gIC8vIERpc3Rpbmd1aXNoZXMgYSB0cmlnZ2VyIHRoYXQgdW5tb3VudGVkIGZyb20gYSBuZXcgYWN0aXZlIHRyaWdnZXIgdGhhdCBoYXMgbm90IGh5ZHJhdGVkIHlldC5cbiAgY29uc3QgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCByZWFjdGl2ZVRyaWdnZXJDb3VudCA9IHN0b3JlLnVzZVN0YXRlKCd0cmlnZ2VyQ291bnQnKTtcbiAgLy8gU3Vic2NyaWJlIHRvIHRoZSBhY3RpdmUgdHJpZ2dlciBpZCBzbyB0aGUgcmVjb25jaWxpYXRpb24gYmVsb3cgcmVydW5zIHdoZW4gb3duZXJzaGlwIG1vdmVzIHRvXG4gIC8vIGFub3RoZXIgdHJpZ2dlciB3aGlsZSB0aGUgcG9wdXAgc3RheXMgb3BlbiAoZS5nLiBhIGZvY3VzL2hvdmVyIGhhbmRvZmYgYmV0d2VlbiB0cmlnZ2VycykuXG4gIGNvbnN0IGFjdGl2ZVRyaWdnZXJJZCA9IHN0b3JlLnVzZVN0YXRlKCdhY3RpdmVUcmlnZ2VySWQnKTtcbiAgLy8gU3Vic2NyaWJlIHRvIHRoZSBhY3RpdmUgdHJpZ2dlciBlbGVtZW50IHNvIHRoZSByZWNvbmNpbGlhdGlvbiByZXJ1bnMgd2hlbiBhIHBlbmRpbmcgYWN0aXZlXG4gIC8vIHRyaWdnZXIgcmVnaXN0ZXJzIGluIGEgY29tbWl0IHdoZXJlIHRoZSB0cmlnZ2VyIGNvdW50IG5ldHMgb3V0IHVuY2hhbmdlZCAocmVnaXN0cmF0aW9uXG4gIC8vIGZvcndhcmRzIHRoZSBlbGVtZW50IHRvIHRoZSBzdG9yZSB3aGVuIHRoZSByZWdpc3RlcmluZyB0cmlnZ2VyIG1hdGNoZXMgdGhlIGFjdGl2ZSBpZCkuXG4gIC8vIFdpdGhvdXQgdGhpcywgdGhlIGlkIHdvdWxkIG5ldmVyIGJlIG1hcmtlZCByZXNvbHZlZCBhbmQgYSBsYXRlciBnZW51aW5lIHVubW91bnQgd291bGQgYmVcbiAgLy8gbWlzY2xhc3NpZmllZCBhcyBwZW5kaW5nLCBkaXNhYmxpbmcgYGNsb3NlT25BY3RpdmVUcmlnZ2VyVW5tb3VudGAuXG4gIGNvbnN0IHJlYWN0aXZlQWN0aXZlVHJpZ2dlckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHtcbiAgICAgIHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgaWYgKHN0b3JlLnN0YXRlLnRyaWdnZXJDb3VudCAhPT0gMCkge1xuICAgICAgICBzdG9yZS5zZXQoJ3RyaWdnZXJDb3VudCcsIDApO1xuICAgICAgfVxuICAgICAgLy8gVGhlIGZsYWcgaXMgY2xlYXJlZCBvbmx5IGhlcmUsIG9uY2UgdGhlIHBvcHVwIGlzIGVmZmVjdGl2ZWx5IGNsb3NlZDogYSBjb250cm9sbGVkIHJvb3QgbWF5XG4gICAgICAvLyBkZWNsaW5lIGEgY2xvc2UgcmVxdWVzdCBhbmQgc3RheSBvcGVuLCBhbmQgYSBjb250cm9sbGVkIGNsb3NlIG5ldmVyIHJlYWNoZXNcbiAgICAgIC8vIGBjcmVhdGVQb3B1cE9wZW5TdGF0ZWAgYXQgYWxsLlxuICAgICAgaWYgKHN0b3JlLnN0YXRlLm9wZW5lZFdpdGhvdXRUcmlnZ2VyKSB7XG4gICAgICAgIHN0b3JlLnNldCgnb3BlbmVkV2l0aG91dFRyaWdnZXInLCBmYWxzZSk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRyaWdnZXJDb3VudCA9IHN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLnNpemU7XG4gICAgY29uc3Qgc3RhdGVVcGRhdGVzID0ge307XG4gICAgaWYgKHN0b3JlLnN0YXRlLnRyaWdnZXJDb3VudCAhPT0gdHJpZ2dlckNvdW50KSB7XG4gICAgICBzdGF0ZVVwZGF0ZXMudHJpZ2dlckNvdW50ID0gdHJpZ2dlckNvdW50O1xuICAgIH1cbiAgICBjb25zdCBjdXJyZW50QWN0aXZlVHJpZ2dlcklkID0gc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VySWQnKTtcbiAgICBsZXQgbG9zdEFjdGl2ZVRyaWdnZXJJZCA9IG51bGw7XG4gICAgaWYgKGN1cnJlbnRBY3RpdmVUcmlnZ2VySWQpIHtcbiAgICAgIGNvbnN0IGFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZ2V0QnlJZChjdXJyZW50QWN0aXZlVHJpZ2dlcklkKTtcbiAgICAgIGlmICghYWN0aXZlVHJpZ2dlckVsZW1lbnQpIHtcbiAgICAgICAgZm9yIChjb25zdCBbdHJpZ2dlcklkLCB0cmlnZ2VyRWxlbWVudF0gb2Ygc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZW50cmllcygpKSB7XG4gICAgICAgICAgaWYgKHRyaWdnZXJFbGVtZW50ID09PSBzdG9yZS5zdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudCkge1xuICAgICAgICAgICAgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJJZCA9IHRyaWdnZXJJZDtcbiAgICAgICAgICAgIHN0YXRlVXBkYXRlcy5hY3RpdmVUcmlnZ2VyRWxlbWVudCA9IHRyaWdnZXJFbGVtZW50O1xuICAgICAgICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IHRyaWdnZXJJZDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgaWYgKHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPT09IGN1cnJlbnRBY3RpdmVUcmlnZ2VySWQpIHtcbiAgICAgICAgICAgIGxvc3RBY3RpdmVUcmlnZ2VySWQgPSBjdXJyZW50QWN0aXZlVHJpZ2dlcklkO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlZEFjdGl2ZVRyaWdnZXJJZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPSBjdXJyZW50QWN0aXZlVHJpZ2dlcklkO1xuICAgICAgICBpZiAoYWN0aXZlVHJpZ2dlckVsZW1lbnQgIT09IHN0b3JlLnN0YXRlLmFjdGl2ZVRyaWdnZXJFbGVtZW50KSB7XG4gICAgICAgICAgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gYWN0aXZlVHJpZ2dlckVsZW1lbnQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmICghbG9zdEFjdGl2ZVRyaWdnZXJJZCAmJiAhY3VycmVudEFjdGl2ZVRyaWdnZXJJZCAmJiAhc3RvcmUuc3RhdGUub3BlbmVkV2l0aG91dFRyaWdnZXIgJiYgdHJpZ2dlckNvdW50ID09PSAxKSB7XG4gICAgICBjb25zdCBpdGVyYXRvclJlc3VsdCA9IHN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLmVudHJpZXMoKS5uZXh0KCk7XG4gICAgICBpZiAoIWl0ZXJhdG9yUmVzdWx0LmRvbmUpIHtcbiAgICAgICAgY29uc3QgW2ltcGxpY2l0VHJpZ2dlcklkLCBpbXBsaWNpdFRyaWdnZXJFbGVtZW50XSA9IGl0ZXJhdG9yUmVzdWx0LnZhbHVlO1xuICAgICAgICBzdGF0ZVVwZGF0ZXMuYWN0aXZlVHJpZ2dlcklkID0gaW1wbGljaXRUcmlnZ2VySWQ7XG4gICAgICAgIHN0YXRlVXBkYXRlcy5hY3RpdmVUcmlnZ2VyRWxlbWVudCA9IGltcGxpY2l0VHJpZ2dlckVsZW1lbnQ7XG4gICAgICAgIHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPSBpbXBsaWNpdFRyaWdnZXJJZDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHN0YXRlVXBkYXRlcy50cmlnZ2VyQ291bnQgIT09IHVuZGVmaW5lZCB8fCBzdGF0ZVVwZGF0ZXMuYWN0aXZlVHJpZ2dlcklkICE9PSB1bmRlZmluZWQgfHwgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJFbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHN0b3JlLnVwZGF0ZShzdGF0ZVVwZGF0ZXMpO1xuICAgIH1cbiAgICBpZiAobG9zdEFjdGl2ZVRyaWdnZXJJZCkge1xuICAgICAgaWYgKGNsb3NlT25BY3RpdmVUcmlnZ2VyVW5tb3VudCkge1xuICAgICAgICAvLyBEZWZlciBzbyBhIHNhbWUtdGljayByZXBsYWNlbWVudCB0cmlnZ2VyIHdpdGggdGhlIHNhbWUgaWQgY2FuIHJlZ2lzdGVyIGZpcnN0LlxuICAgICAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICAgICAgaWYgKHN0b3JlLnNlbGVjdCgnb3BlbicpICYmIHN0b3JlLnNlbGVjdCgnYWN0aXZlVHJpZ2dlcklkJykgPT09IGxvc3RBY3RpdmVUcmlnZ2VySWQgJiYgIXN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLmdldEJ5SWQobG9zdEFjdGl2ZVRyaWdnZXJJZCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGV2ZW50RGV0YWlscyA9IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLm5vbmUpO1xuICAgICAgICAgICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgZXZlbnREZXRhaWxzKTtcbiAgICAgICAgICAgIC8vIElmIGNsb3NpbmcgaXMgY2FuY2VsZWQsIGtlZXAgdGhlIHByZXZpb3VzIGFjdGl2ZSB0cmlnZ2VyIG93bmVyc2hpcCBmb3IgdGhlXG4gICAgICAgICAgICAvLyBzdGlsbC1vcGVuIHBvcHVwIGluc3RlYWQgb2YgY2xhaW1pbmcgYW5vdGhlciB0cmlnZ2VyIGltcGxpY2l0bHkuXG4gICAgICAgICAgICBpZiAoIWV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICAgICAgICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgYWN0aXZlVHJpZ2dlcklkOiBudWxsLFxuICAgICAgICAgICAgICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBudWxsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbb3Blbiwgc3RvcmUsIHJlYWN0aXZlVHJpZ2dlckNvdW50LCBhY3RpdmVUcmlnZ2VySWQsIHJlYWN0aXZlQWN0aXZlVHJpZ2dlckVsZW1lbnQsIGNsb3NlT25BY3RpdmVUcmlnZ2VyVW5tb3VudF0pO1xufVxuXG4vKipcbiAqIE1hbmFnZXMgdGhlIG1vdW50ZWQgc3RhdGUgb2YgdGhlIHBvcHVwLlxuICogU2V0cyB1cCB0aGUgdHJhbnNpdGlvbiBzdGF0dXMgbGlzdGVuZXJzIGFuZCBoYW5kbGVzIHVubW91bnRpbmcgd2hlbiBuZWVkZWQuXG4gKiBVcGRhdGVzIHRoZSBgbW91bnRlZGAsIGB0cmFuc2l0aW9uU3RhdHVzYCwgYW5kIGBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2VgIHN0YXRlcyBpbiB0aGUgc3RvcmUuXG4gKlxuICogQHBhcmFtIG9wZW4gV2hldGhlciB0aGUgcG9wdXAgaXMgb3Blbi5cbiAqIEBwYXJhbSBzdG9yZSBUaGUgU3RvcmUgaW5zdGFuY2UgbWFuYWdpbmcgdGhlIHBvcHVwIHN0YXRlLlxuICogQHBhcmFtIG9uVW5tb3VudCBPcHRpb25hbCBjYWxsYmFjayB0byBiZSBjYWxsZWQgd2hlbiB0aGUgcG9wdXAgaXMgdW5tb3VudGVkLlxuICogQHBhcmFtIGFuaW1hdGVJbml0aWFsT3BlbiBXaGV0aGVyIGEgcG9wdXAgdGhhdCBtb3VudHMgYWxyZWFkeSBvcGVuIHNob3VsZCBzdGlsbCBwbGF5IGl0cyBlbnRlclxuICogICB0cmFuc2l0aW9uLiBEZWZhdWx0cyB0byBgZmFsc2VgLCBzbyBjb250ZW50IHRoYXQgd2FzIG9wZW4gb24gdGhlIGZpcnN0IHJlbmRlciAoYSBgZGVmYXVsdE9wZW5gXG4gKiAgIHBvcHVwIG9uIHBhZ2UgbG9hZCwgU1NSJ2QgbWFya3VwKSBhcHBlYXJzIHdpdGhvdXQgYW5pbWF0aW5nLiBPcHQgaW4gZm9yIHBvcHVwcyB3aG9zZSBzdWJ0cmVlXG4gKiAgIG9ubHkgbW91bnRzIGluIHJlc3BvbnNlIHRvIHNvbWV0aGluZyB0aGUgdXNlciBkaWQsIHN1Y2ggYXMgYSBzdWJtZW51IGluc2lkZSBhIG1lbnUgcG9wdXAuXG4gKlxuICogQHJldHVybnMgQSBmdW5jdGlvbiB0byBmb3JjaWJseSB1bm1vdW50IHRoZSBwb3B1cC4gSXQgaXMgYSBuby1vcCBvbmNlIHRoZSBwb3B1cCBpcyBhbHJlYWR5XG4gKiAgIHVubW91bnRlZCwgc28gY2FsbGluZyBpdCBhZnRlciB0aGUgYXV0b21hdGljIHVubW91bnQgZG9lc24ndCByZXBlYXQgdGhlIGNvbXBsZXRpb24gY2FsbGJhY2suXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VPcGVuU3RhdGVUcmFuc2l0aW9ucyhvcGVuLCBzdG9yZSwgb25Vbm1vdW50LCBhbmltYXRlSW5pdGlhbE9wZW4pIHtcbiAgY29uc3Qge1xuICAgIG1vdW50ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBmb3JjZVVubW91bnRcbiAgfSA9IHVzZVVubW91bnRBZnRlckNsb3NlKHtcbiAgICBvcGVuLFxuICAgIHJlZjogc3RvcmUuY29udGV4dC5wb3B1cFJlZixcbiAgICBwcmV2ZW50VW5tb3VudE9uQ2xvc2U6IHN0b3JlLnVzZVN0YXRlKCdwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UnKSxcbiAgICBzZXRQcmV2ZW50VW5tb3VudE9uQ2xvc2U6IHByZXZlbnRVbm1vdW50T25DbG9zZSA9PiBzdG9yZS5zZXQoJ3ByZXZlbnRVbm1vdW50aW5nT25DbG9zZScsIHByZXZlbnRVbm1vdW50T25DbG9zZSksXG4gICAgYW5pbWF0ZUluaXRpYWxPcGVuLFxuICAgIG9uVW5tb3VudCgpIHtcbiAgICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICAgIGFjdGl2ZVRyaWdnZXJJZDogbnVsbCxcbiAgICAgICAgYWN0aXZlVHJpZ2dlckVsZW1lbnQ6IG51bGwsXG4gICAgICAgIG1vdW50ZWQ6IGZhbHNlLFxuICAgICAgICBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2U6IGZhbHNlXG4gICAgICB9KTtcbiAgICAgIG9uVW5tb3VudD8uKCk7XG4gICAgICBzdG9yZS5jb250ZXh0Lm9uT3BlbkNoYW5nZUNvbXBsZXRlPy4oZmFsc2UpO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gU2VlZCB0aGUgUm9vdC1vd25lZCBzdG9yZSBiZWZvcmUgcGFydHMgc3Vic2NyaWJlLCBtYXRjaGluZyB0aGUgaG9vaydzIGluaXRpYWwgbW91bnRlZCBzdGF0ZS5cbiAgLy8gT3RoZXJ3aXNlLCBhbiBpbml0aWFsbHkgb3BlbiBSb290IGxvb2tzIGxpa2UgYSByZW9wZW4gdW50aWwgdGhlIGxheW91dCBlZmZlY3Qgc3luY3MgdGhlIHN0b3JlLlxuICB1c2VSZWZXaXRoSW5pdCgoKSA9PiB7XG4gICAgc3RvcmUuc2V0KCdtb3VudGVkJywgbW91bnRlZCk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH0pO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZXMoe1xuICAgIG1vdW50ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1c1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBmb3JjZVVubW91bnQsXG4gICAgdHJhbnNpdGlvblN0YXR1c1xuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVzZVBvcHVwSW50ZXJhY3Rpb25Qcm9wcyhzdG9yZSwgc3RhdGVQYXJ0KSB7XG4gIHN0b3JlLnVzZVN5bmNlZFZhbHVlcyhzdGF0ZVBhcnQpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4gKCkgPT4ge1xuICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICBhY3RpdmVUcmlnZ2VyUHJvcHM6IEVNUFRZX09CSkVDVCxcbiAgICAgIGluYWN0aXZlVHJpZ2dlclByb3BzOiBFTVBUWV9PQkpFQ1QsXG4gICAgICBwb3B1cFByb3BzOiBFTVBUWV9PQkpFQ1RcbiAgICB9KTtcbiAgfSwgW3N0b3JlXSk7XG59XG5leHBvcnQgZnVuY3Rpb24gdXNlUG9wdXBSb290U3luYyhzdG9yZSwgb3Blbikge1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiAmJiBzdG9yZS5zdGF0ZS5vcGVuTWV0aG9kICE9PSBudWxsKSB7XG4gICAgICBzdG9yZS5zZXQoJ29wZW5NZXRob2QnLCBudWxsKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBzdG9yZV0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4gKCkgPT4ge1xuICAgIGlmIChzdG9yZS5zdGF0ZS5vcGVuTWV0aG9kICE9PSBudWxsKSB7XG4gICAgICBzdG9yZS5zZXQoJ29wZW5NZXRob2QnLCBudWxsKTtcbiAgICB9XG4gIH0sIFtzdG9yZV0pO1xufSIsIi8qKlxuICogRGV2ZWxvcG1lbnQtb25seSByZXZlcnNlIGluZGV4IG9mIGVsZW1lbnQgdG8gcmVnaXN0ZXJlZCBpZCwga2V5ZWQgYnkgdGhlIG93bmluZyBtYXAuXG4gKlxuICogUmVnaXN0cmF0aW9uIHdvdWxkIG90aGVyd2lzZSBoYXZlIHRvIHNjYW4gZXZlcnkgZW50cnkgdG8gZGV0ZWN0IGFuIGVsZW1lbnQgY2xhaW1lZCBieSB0d28gaWRzLFxuICogbWFraW5nIHRoZSBtb3VudCBvZiBtYW55IHRyaWdnZXJzIHNoYXJpbmcgb25lIGhhbmRsZSBxdWFkcmF0aWMuIEtlcHQgbW9kdWxlLXNjb3BlZCwgbGF6aWx5XG4gKiBpbml0aWFsaXplZCwgYW5kIHJlYWQgb25seSBmcm9tIGBwcm9jZXNzLmVudi5OT0RFX0VOVmAgZ3VhcmRzIHNvIHByb2R1Y3Rpb24gYnVpbGRzIGRyb3AgaXQgYWxvbmdcbiAqIHdpdGggdGhlIGNoZWNrcy5cbiAqL1xubGV0IGRldkVsZW1lbnRJZHNCeU1hcDtcbmZ1bmN0aW9uIGdldERldkVsZW1lbnRJZHMobWFwKSB7XG4gIGRldkVsZW1lbnRJZHNCeU1hcCA/Pz0gbmV3IFdlYWtNYXAoKTtcbiAgbGV0IGVsZW1lbnRJZHMgPSBkZXZFbGVtZW50SWRzQnlNYXAuZ2V0KG1hcCk7XG4gIGlmICghZWxlbWVudElkcykge1xuICAgIGVsZW1lbnRJZHMgPSBuZXcgV2Vha01hcCgpO1xuICAgIGRldkVsZW1lbnRJZHNCeU1hcC5zZXQobWFwLCBlbGVtZW50SWRzKTtcbiAgfVxuICByZXR1cm4gZWxlbWVudElkcztcbn1cblxuLyoqXG4gKiBEYXRhIHN0cnVjdHVyZSB0byBrZWVwIHRyYWNrIG9mIHBvcHVwIHRyaWdnZXIgZWxlbWVudHMgYnkgdGhlaXIgSURzLlxuICpcbiAqIEVsZW1lbnQgbG9va3VwcyBpdGVyYXRlIHRoZSBpZCBtYXAgcmF0aGVyIHRoYW4gbWFpbnRhaW5pbmcgYSBwYXJhbGxlbCBTZXQuIFJlZ2lzdHJhdGlvbiBpcyBPKDEpLFxuICogd2hpbGUgYGhhc0VsZW1lbnRgIGFuZCBgaGFzTWF0Y2hpbmdFbGVtZW50YCBhcmUgbGluZWFyIGluIHRoZSBudW1iZXIgb2YgdHJpZ2dlcnMuXG4gKi9cbmV4cG9ydCBjbGFzcyBQb3B1cFRyaWdnZXJNYXAge1xuICBpZE1hcCA9IG5ldyBNYXAoKTtcblxuICAvKipcbiAgICogQWRkcyBhIHRyaWdnZXIgZWxlbWVudCB3aXRoIHRoZSBnaXZlbiBJRC5cbiAgICpcbiAgICogTm90ZTogVGhlIHByb3ZpZGVkIGVsZW1lbnQgaXMgYXNzdW1lZCB0byBub3QgYmUgcmVnaXN0ZXJlZCB1bmRlciBtdWx0aXBsZSBJRHMuXG4gICAqL1xuICBhZGQoaWQsIGVsZW1lbnQpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgZWxlbWVudElkcyA9IGdldERldkVsZW1lbnRJZHModGhpcyk7XG4gICAgICBjb25zdCBleGlzdGluZ0lkID0gZWxlbWVudElkcy5nZXQoZWxlbWVudCk7XG4gICAgICBpZiAoZXhpc3RpbmdJZCAhPT0gdW5kZWZpbmVkICYmIGV4aXN0aW5nSWQgIT09IGlkKSB7XG4gICAgICAgIC8vIFRPRE86IGZpeCBtdWkvbm8tZ3VhcmRlZC10aHJvd1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdCYXNlIFVJOiBBIHRyaWdnZXIgZWxlbWVudCBjYW5ub3QgYmUgcmVnaXN0ZXJlZCB1bmRlciBtdWx0aXBsZSBJRHMgaW4gUG9wdXBUcmlnZ2VyTWFwLicpO1xuICAgICAgfVxuXG4gICAgICAvLyBSZXVzaW5nIGFuIGlkIGZvciBhIGRpZmZlcmVudCBlbGVtZW50IGV2aWN0cyB0aGUgcHJldmlvdXMgb25lLCBzbyBpdCBtdXN0IGxvc2UgaXRzIGNsYWltXG4gICAgICAvLyBvbiB0aGUgaWQgb3IgYSBsYXRlciByZWdpc3RyYXRpb24gdW5kZXIgYSBkaWZmZXJlbnQgaWQgd291bGQgYmUgcmVwb3J0ZWQgYXMgYSBkdXBsaWNhdGUuXG4gICAgICBjb25zdCBwcmV2aW91c0VsZW1lbnQgPSB0aGlzLmlkTWFwLmdldChpZCk7XG4gICAgICBpZiAocHJldmlvdXNFbGVtZW50ICE9PSB1bmRlZmluZWQgJiYgcHJldmlvdXNFbGVtZW50ICE9PSBlbGVtZW50KSB7XG4gICAgICAgIGVsZW1lbnRJZHMuZGVsZXRlKHByZXZpb3VzRWxlbWVudCk7XG4gICAgICB9XG4gICAgICBlbGVtZW50SWRzLnNldChlbGVtZW50LCBpZCk7XG4gICAgfVxuICAgIHRoaXMuaWRNYXAuc2V0KGlkLCBlbGVtZW50KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSB0cmlnZ2VyIGVsZW1lbnQgd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAqL1xuICBkZWxldGUoaWQpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgZWxlbWVudCA9IHRoaXMuaWRNYXAuZ2V0KGlkKTtcbiAgICAgIGlmIChlbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgZGV2RWxlbWVudElkc0J5TWFwPy5nZXQodGhpcyk/LmRlbGV0ZShlbGVtZW50KTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5pZE1hcC5kZWxldGUoaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGdpdmVuIGVsZW1lbnQgaXMgcmVnaXN0ZXJlZCBhcyBhIHRyaWdnZXIuXG4gICAqL1xuICBoYXNFbGVtZW50KGVsZW1lbnQpIHtcbiAgICBmb3IgKGNvbnN0IHJlZ2lzdGVyZWQgb2YgdGhpcy5pZE1hcC52YWx1ZXMoKSkge1xuICAgICAgaWYgKHJlZ2lzdGVyZWQgPT09IGVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZXJlIGlzIGEgcmVnaXN0ZXJlZCB0cmlnZ2VyIGVsZW1lbnQgbWF0Y2hpbmcgdGhlIGdpdmVuIHByZWRpY2F0ZS5cbiAgICovXG4gIGhhc01hdGNoaW5nRWxlbWVudChwcmVkaWNhdGUpIHtcbiAgICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgdGhpcy5pZE1hcC52YWx1ZXMoKSkge1xuICAgICAgaWYgKHByZWRpY2F0ZShlbGVtZW50KSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHRyaWdnZXIgZWxlbWVudCBhc3NvY2lhdGVkIHdpdGggdGhlIGdpdmVuIElELCBvciB1bmRlZmluZWQgaWYgbm8gc3VjaCBlbGVtZW50IGV4aXN0cy5cbiAgICovXG4gIGdldEJ5SWQoaWQpIHtcbiAgICByZXR1cm4gdGhpcy5pZE1hcC5nZXQoaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gaXRlcmFibGUgb2YgYWxsIHJlZ2lzdGVyZWQgdHJpZ2dlciBlbnRyaWVzLCB3aGVyZSBlYWNoIGVudHJ5IGlzIGEgdHVwbGUgb2YgW2lkLCBlbGVtZW50XS5cbiAgICovXG4gIGVudHJpZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuaWRNYXAuZW50cmllcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gaXRlcmFibGUgb2YgYWxsIHJlZ2lzdGVyZWQgdHJpZ2dlciBlbGVtZW50cy5cbiAgICovXG4gIGVsZW1lbnRzKCkge1xuICAgIHJldHVybiB0aGlzLmlkTWFwLnZhbHVlcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIG51bWJlciBvZiByZWdpc3RlcmVkIHRyaWdnZXIgZWxlbWVudHMuXG4gICAqL1xuICBnZXQgc2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5pZE1hcC5zaXplO1xuICB9XG59IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tIFwiLi91c2VSZWZXaXRoSW5pdC5tanNcIjtcbmNvbnN0IGhvb2tzID0gW107XG5sZXQgY3VycmVudEluc3RhbmNlID0gdW5kZWZpbmVkO1xuZXhwb3J0IGZ1bmN0aW9uIGdldEluc3RhbmNlKCkge1xuICByZXR1cm4gY3VycmVudEluc3RhbmNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNldEluc3RhbmNlKGluc3RhbmNlKSB7XG4gIGN1cnJlbnRJbnN0YW5jZSA9IGluc3RhbmNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyKGhvb2spIHtcbiAgaG9va3MucHVzaChob29rKTtcbn1cblxuLyoqXG4gKiBXcmFwcyBhIGNvbXBvbmVudCBmdW5jdGlvbiB0byBlbmFibGUgcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9ucyBmb3IgaW50ZXJuYWwgaG9va3MuXG4gKlxuICogKipQZXJmb3JtYW5jZSBPcHRpbWl6YXRpb246KipcbiAqIENvbXBvbmVudHMgd3JhcHBlZCB3aXRoIGBmYXN0Q29tcG9uZW50YCBoYXZlIGFjY2VzcyB0byBhIHNoYXJlZCBcImluc3RhbmNlXCIgY29udGV4dCB0aGF0IGVuYWJsZXNcbiAqIHNwZWNpYWxpemVkIGhvb2sgaW1wbGVtZW50YXRpb25zIHRvIGJhdGNoIG9wZXJhdGlvbnMgYW5kIHJlZHVjZSBvdmVyaGVhZC4gVGhlIHdyYXBwZXIgY3JlYXRlcyBhXG4gKiBzdGFibGUgaW5zdGFuY2Ugb2JqZWN0IHRoYXQgcGVyc2lzdHMgYWNyb3NzIHJlbmRlcnMsIHNldHMgaXQgYXMgdGhlIGN1cnJlbnQgY29udGV4dCwgY2FsbHNcbiAqIHJlZ2lzdGVyZWQgaG9va3MgYmVmb3JlIGFuZCBhZnRlciByZW5kZXJpbmcsIHRoZW4gY2xlYXJzIHRoZSBjb250ZXh0LiBUaGUgcHJpbWFyeSBiZW5lZml0IGlzXG4gKiB3aXRoIGB1c2VTdG9yZWAsIHdoZXJlIG11bHRpcGxlIHN0b3JlIHN1YnNjcmlwdGlvbnMgd2l0aGluIHRoZSBzYW1lIGNvbXBvbmVudCBhcmUgY29sbGFwc2VkIGludG9cbiAqIGEgc2luZ2xlIGB1c2VTeW5jRXh0ZXJuYWxTdG9yZWAgc3Vic2NyaXB0aW9uIHBlciBzdG9yZSwgc2lnbmlmaWNhbnRseSByZWR1Y2luZyByZS1yZW5kZXIgb3ZlcmhlYWQuXG4gKiBUaGlzIG9wdGltaXphdGlvbiBpcyBvbmx5IGFjdGl2ZSBvbiBSZWFjdCAxOSs7IG9uIGVhcmxpZXIgdmVyc2lvbnMgYHVzZVN0b3JlYCBmYWxscyBiYWNrIHRvIGFcbiAqIHNlcGFyYXRlIHN1YnNjcmlwdGlvbiBwZXIgY2FsbC5cbiAqXG4gKiAqKlJlcXVpcmVtZW50czoqKlxuICogLSBUaGUgY29tcG9uZW50IGZ1bmN0aW9uIHNob3VsZCBmb2xsb3cgc3RhbmRhcmQgUmVhY3QgY29tcG9uZW50IHBhdHRlcm5zXG4gKiAtIGB1c2VTdG9yZWAgY2FsbHMgbXVzdCBrZWVwIGEgc3RhYmxlIG9yZGVyIGFuZCBjb3VudCBhY3Jvc3MgcmVuZGVycywgYXMgYmF0Y2hlZCBob29rcyBhcmVcbiAqICAgbWF0Y2hlZCBieSBjYWxsIGluZGV4XG4gKiAtIERvIG5vdCByZWx5IG9uIHRoZSBpbnN0YW5jZSBjb250ZXh0IG91dHNpZGUgb2Ygc3BlY2lhbGl6ZWQgaG9va3NcbiAqXG4gKiBAcGFyYW0gZm4gLSBUaGUgY29tcG9uZW50IGZ1bmN0aW9uIHRvIHdyYXBcbiAqIEByZXR1cm5zIEEgd3JhcHBlZCBjb21wb25lbnQgd2l0aCB0aGUgc2FtZSBzaWduYXR1cmUgYXMgdGhlIGlucHV0IGZ1bmN0aW9uXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogLy8gV3JhcHBpbmcgYSBjb21wb25lbnQgdG8gZW5hYmxlIG9wdGltaXplZCB1c2VTdG9yZSBiYXRjaGluZ1xuICogZXhwb3J0IGNvbnN0IFRvb2x0aXBSb290ID0gZmFzdENvbXBvbmVudChmdW5jdGlvbiBUb29sdGlwUm9vdChwcm9wcykge1xuICogICAvLyBUaGVzZSB1c2VTdG9yZSBjYWxscyBzaGFyZSBhIHNpbmdsZSBzdWJzY3JpcHRpb25cbiAqICAgY29uc3Qgb3BlbiA9IHVzZVN0b3JlKHN0b3JlLCAoc3RhdGUpID0+IHN0YXRlLm9wZW4pO1xuICogICBjb25zdCBkaXNhYmxlZCA9IHVzZVN0b3JlKHN0b3JlLCAoc3RhdGUpID0+IHN0YXRlLmRpc2FibGVkKTtcbiAqICAgY29uc3QgdmFsdWUgPSB1c2VTdG9yZShzdG9yZSwgKHN0YXRlKSA9PiBzdGF0ZS52YWx1ZSk7XG4gKiAgIC8vIC4uLlxuICogfSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZhc3RDb21wb25lbnQoZm4pIHtcbiAgY29uc3QgRmFzdENvbXBvbmVudCA9IChwcm9wcywgZm9yd2FyZGVkUmVmKSA9PiB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSB1c2VSZWZXaXRoSW5pdChjcmVhdGVJbnN0YW5jZSkuY3VycmVudDtcbiAgICBsZXQgcmVzdWx0O1xuICAgIHRyeSB7XG4gICAgICBjdXJyZW50SW5zdGFuY2UgPSBpbnN0YW5jZTtcbiAgICAgIGZvciAoY29uc3QgaG9vayBvZiBob29rcykge1xuICAgICAgICBob29rLmJlZm9yZShpbnN0YW5jZSk7XG4gICAgICB9XG4gICAgICByZXN1bHQgPSBmbihwcm9wcywgZm9yd2FyZGVkUmVmKTtcbiAgICAgIGZvciAoY29uc3QgaG9vayBvZiBob29rcykge1xuICAgICAgICBob29rLmFmdGVyKGluc3RhbmNlKTtcbiAgICAgIH1cbiAgICAgIGluc3RhbmNlLmRpZEluaXRpYWxpemUgPSB0cnVlO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBjdXJyZW50SW5zdGFuY2UgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG4gIEZhc3RDb21wb25lbnQuZGlzcGxheU5hbWUgPSBmbi5kaXNwbGF5TmFtZSB8fCBmbi5uYW1lO1xuICByZXR1cm4gRmFzdENvbXBvbmVudDtcbn1cblxuLyoqXG4gKiBXcmFwcyBhIGNvbXBvbmVudCBmdW5jdGlvbiB3aXRoIHJlZiBmb3J3YXJkaW5nIHRvIGVuYWJsZSBwZXJmb3JtYW5jZSBvcHRpbWl6YXRpb25zIGZvciBpbnRlcm5hbCBob29rcy5cbiAqXG4gKiBUaGlzIGlzIGEgY29udmVuaWVuY2Ugd3JhcHBlciB0aGF0IGNvbWJpbmVzIGBmYXN0Q29tcG9uZW50YCB3aXRoIGBSZWFjdC5mb3J3YXJkUmVmYCwgZW5hYmxpbmdcbiAqIGJvdGggcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9ucyBhbmQgcHJvcGVyIHJlZiBmb3J3YXJkaW5nLiBTZWUgYGZhc3RDb21wb25lbnRgIGZvciBkZXRhaWxzIG9uXG4gKiB0aGUgcGVyZm9ybWFuY2UgYmVuZWZpdHMuXG4gKlxuICogQHBhcmFtIGZuIC0gVGhlIGNvbXBvbmVudCBmdW5jdGlvbiB0aGF0IGFjY2VwdHMgcHJvcHMgYW5kIGEgZm9yd2FyZGVkIHJlZlxuICogQHJldHVybnMgQSB3cmFwcGVkIGNvbXBvbmVudCB3aXRoIHJlZiBmb3J3YXJkaW5nIGVuYWJsZWRcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiAvLyBXcmFwcGluZyBhIGNvbXBvbmVudCB3aXRoIHJlZiBmb3J3YXJkaW5nIGFuZCBvcHRpbWl6ZWQgaG9va3NcbiAqIGV4cG9ydCBjb25zdCBUb29sdGlwVHJpZ2dlciA9IGZhc3RDb21wb25lbnRSZWYoZnVuY3Rpb24gVG9vbHRpcFRyaWdnZXIoXG4gKiAgIHByb3BzLFxuICogICBmb3J3YXJkZWRSZWZcbiAqICkge1xuICogICBjb25zdCBzdG9yZSA9IHVzZUNvbnRleHQoVG9vbHRpcENvbnRleHQpO1xuICogICBjb25zdCBvcGVuID0gdXNlU3RvcmUoc3RvcmUsIChzdGF0ZSkgPT4gc3RhdGUub3Blbik7XG4gKiAgIC8vIC4uLiBjb21wb25lbnQgbG9naWMgd2l0aCByZWZcbiAqICAgcmV0dXJuIDxidXR0b24gcmVmPXtmb3J3YXJkZWRSZWZ9IHsuLi5wcm9wc30gLz47XG4gKiB9KTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZmFzdENvbXBvbmVudFJlZihmbikge1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZmFzdENvbXBvbmVudChmbikpO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5zdGFuY2UoKSB7XG4gIHJldHVybiB7XG4gICAgZGlkSW5pdGlhbGl6ZTogZmFsc2VcbiAgfTtcbn0iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG4vKiBXZSBuZWVkIHRvIGltcG9ydCB0aGUgc2hpbSBiZWNhdXNlIFJlYWN0IDE3IGRvZXMgbm90IHN1cHBvcnQgdGhlIGB1c2VTeW5jRXh0ZXJuYWxTdG9yZWAgQVBJLlxuICogTW9yZSBpbmZvOiBodHRwczovL2dpdGh1Yi5jb20vbXVpL211aS14L2lzc3Vlcy8xODMwMyNpc3N1ZWNvbW1lbnQtMjk1ODM5MjM0MSAqL1xuaW1wb3J0IHsgdXNlU3luY0V4dGVybmFsU3RvcmUgfSBmcm9tICd1c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltJztcbmltcG9ydCB7IHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yIH0gZnJvbSAndXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbS93aXRoLXNlbGVjdG9yJztcbmltcG9ydCB7IGlzUmVhY3RWZXJzaW9uQXRMZWFzdCB9IGZyb20gXCIuLi9yZWFjdFZlcnNpb24ubWpzXCI7XG5pbXBvcnQgeyByZWdpc3RlciwgZ2V0SW5zdGFuY2UgfSBmcm9tIFwiLi4vZmFzdEhvb2tzLm1qc1wiO1xuLyogU29tZSB0ZXN0cyBmYWlsIGluIFIxOCB3aXRoIHRoZSByYXcgdXNlU3luY0V4dGVybmFsU3RvcmUuIEl0IG1heSBiZSBwb3NzaWJsZSB0byBtYWtlIGl0IHdvcmtcbiAqIGJ1dCBmb3Igbm93IHdlIG9ubHkgZW5hYmxlIGl0IGZvciBSMTkrLiAqL1xuY29uc3QgY2FuVXNlUmF3VXNlU3luY0V4dGVybmFsU3RvcmUgPSBpc1JlYWN0VmVyc2lvbkF0TGVhc3QoMTkpO1xuY29uc3QgdXNlU3RvcmVJbXBsZW1lbnRhdGlvbiA9IGNhblVzZVJhd1VzZVN5bmNFeHRlcm5hbFN0b3JlID8gdXNlU3RvcmVGYXN0IDogdXNlU3RvcmVMZWdhY3k7XG5leHBvcnQgZnVuY3Rpb24gdXNlU3RvcmUoc3RvcmUsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gIHJldHVybiB1c2VTdG9yZUltcGxlbWVudGF0aW9uKHN0b3JlLCBzZWxlY3RvciwgYTEsIGEyLCBhMyk7XG59XG5mdW5jdGlvbiB1c2VTdG9yZVIxOShzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpIHtcbiAgY29uc3QgZ2V0U2VsZWN0aW9uID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4gc2VsZWN0b3Ioc3RvcmUuZ2V0U25hcHNob3QoKSwgYTEsIGEyLCBhMyksIFtzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTNdKTtcbiAgcmV0dXJuIHVzZVN5bmNFeHRlcm5hbFN0b3JlKHN0b3JlLnN1YnNjcmliZSwgZ2V0U2VsZWN0aW9uLCBnZXRTZWxlY3Rpb24pO1xufVxucmVnaXN0ZXIoe1xuICBiZWZvcmUoaW5zdGFuY2UpIHtcbiAgICBpbnN0YW5jZS5zeW5jSW5kZXggPSAwO1xuICAgIGlmICghaW5zdGFuY2UuZGlkSW5pdGlhbGl6ZSkge1xuICAgICAgaW5zdGFuY2Uuc3luY1RpY2sgPSAxO1xuICAgICAgaW5zdGFuY2Uuc3luY0hvb2tzID0gW107XG4gICAgICBpbnN0YW5jZS5kaWRDaGFuZ2VTdG9yZSA9IHRydWU7XG4gICAgICBpbnN0YW5jZS5nZXRTbmFwc2hvdCA9ICgpID0+IHtcbiAgICAgICAgbGV0IGRpZENoYW5nZSA9IGZhbHNlO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluc3RhbmNlLnN5bmNIb29rcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgIGNvbnN0IGhvb2sgPSBpbnN0YW5jZS5zeW5jSG9va3NbaV07XG4gICAgICAgICAgY29uc3QgdmFsdWUgPSBob29rLnNlbGVjdG9yKGhvb2suc3RvcmUuc3RhdGUsIGhvb2suYTEsIGhvb2suYTIsIGhvb2suYTMpO1xuICAgICAgICAgIGlmICghT2JqZWN0LmlzKGhvb2sudmFsdWUsIHZhbHVlKSkge1xuICAgICAgICAgICAgZGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICAgICAgICAgIGhvb2sudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGRpZENoYW5nZSkge1xuICAgICAgICAgIGluc3RhbmNlLnN5bmNUaWNrICs9IDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGluc3RhbmNlLnN5bmNUaWNrO1xuICAgICAgfTtcbiAgICB9XG4gIH0sXG4gIGFmdGVyKGluc3RhbmNlKSB7XG4gICAgaWYgKGluc3RhbmNlLnN5bmNIb29rcy5sZW5ndGggPiAwKSB7XG4gICAgICBpZiAoaW5zdGFuY2UuZGlkQ2hhbmdlU3RvcmUpIHtcbiAgICAgICAgaW5zdGFuY2UuZGlkQ2hhbmdlU3RvcmUgPSBmYWxzZTtcbiAgICAgICAgaW5zdGFuY2Uuc3Vic2NyaWJlID0gb25TdG9yZUNoYW5nZSA9PiB7XG4gICAgICAgICAgY29uc3Qgc3RvcmVzID0gbmV3IFNldCgpO1xuICAgICAgICAgIGZvciAoY29uc3QgaG9vayBvZiBpbnN0YW5jZS5zeW5jSG9va3MpIHtcbiAgICAgICAgICAgIHN0b3Jlcy5hZGQoaG9vay5zdG9yZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlcyA9IFtdO1xuICAgICAgICAgIGZvciAoY29uc3Qgc3RvcmUgb2Ygc3RvcmVzKSB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZXMucHVzaChzdG9yZS5zdWJzY3JpYmUob25TdG9yZUNoYW5nZSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgZm9yIChjb25zdCB1bnN1YnNjcmliZSBvZiB1bnN1YnNjcmliZXMpIHtcbiAgICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgICB1c2VTeW5jRXh0ZXJuYWxTdG9yZShpbnN0YW5jZS5zdWJzY3JpYmUsIGluc3RhbmNlLmdldFNuYXBzaG90LCBpbnN0YW5jZS5nZXRTbmFwc2hvdCk7XG4gICAgfVxuICB9XG59KTtcbmZ1bmN0aW9uIHVzZVN0b3JlRmFzdChzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpIHtcbiAgY29uc3QgaW5zdGFuY2UgPSBnZXRJbnN0YW5jZSgpO1xuICBpZiAoIWluc3RhbmNlKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgcmV0dXJuIHVzZVN0b3JlUjE5KHN0b3JlLCBzZWxlY3RvciwgYTEsIGEyLCBhMyk7XG4gIH1cbiAgY29uc3QgaW5kZXggPSBpbnN0YW5jZS5zeW5jSW5kZXg7XG4gIGluc3RhbmNlLnN5bmNJbmRleCArPSAxO1xuICBsZXQgaG9vaztcbiAgaWYgKCFpbnN0YW5jZS5kaWRJbml0aWFsaXplKSB7XG4gICAgaG9vayA9IHtcbiAgICAgIHN0b3JlLFxuICAgICAgc2VsZWN0b3IsXG4gICAgICBhMSxcbiAgICAgIGEyLFxuICAgICAgYTMsXG4gICAgICB2YWx1ZTogc2VsZWN0b3Ioc3RvcmUuZ2V0U25hcHNob3QoKSwgYTEsIGEyLCBhMylcbiAgICB9O1xuICAgIGluc3RhbmNlLnN5bmNIb29rcy5wdXNoKGhvb2spO1xuICB9IGVsc2Uge1xuICAgIGhvb2sgPSBpbnN0YW5jZS5zeW5jSG9va3NbaW5kZXhdO1xuICAgIGlmIChob29rLnN0b3JlICE9PSBzdG9yZSB8fCBob29rLnNlbGVjdG9yICE9PSBzZWxlY3RvciB8fCAhT2JqZWN0LmlzKGhvb2suYTEsIGExKSB8fCAhT2JqZWN0LmlzKGhvb2suYTIsIGEyKSB8fCAhT2JqZWN0LmlzKGhvb2suYTMsIGEzKSkge1xuICAgICAgaWYgKGhvb2suc3RvcmUgIT09IHN0b3JlKSB7XG4gICAgICAgIGluc3RhbmNlLmRpZENoYW5nZVN0b3JlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGhvb2suc3RvcmUgPSBzdG9yZTtcbiAgICAgIGhvb2suc2VsZWN0b3IgPSBzZWxlY3RvcjtcbiAgICAgIGhvb2suYTEgPSBhMTtcbiAgICAgIGhvb2suYTIgPSBhMjtcbiAgICAgIGhvb2suYTMgPSBhMztcbiAgICAgIGhvb2sudmFsdWUgPSBzZWxlY3RvcihzdG9yZS5nZXRTbmFwc2hvdCgpLCBhMSwgYTIsIGEzKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGhvb2sudmFsdWU7XG59XG5mdW5jdGlvbiB1c2VTdG9yZUxlZ2FjeShzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpIHtcbiAgcmV0dXJuIHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yKHN0b3JlLnN1YnNjcmliZSwgc3RvcmUuZ2V0U25hcHNob3QsIHN0b3JlLmdldFNuYXBzaG90LCBzdGF0ZSA9PiBzZWxlY3RvcihzdGF0ZSwgYTEsIGEyLCBhMykpO1xufSIsImltcG9ydCB7IHVzZVN0b3JlIH0gZnJvbSBcIi4vdXNlU3RvcmUubWpzXCI7XG4vKipcbiAqIEEgZGF0YSBzdG9yZSBpbXBsZW1lbnRhdGlvbiB0aGF0IGFsbG93cyBzdWJzY3JpYmluZyB0byBzdGF0ZSBjaGFuZ2VzIGFuZCB1cGRhdGluZyB0aGUgc3RhdGUuXG4gKiBJdCB1c2VzIGFuIG9ic2VydmVyIHBhdHRlcm4gdG8gbm90aWZ5IHN1YnNjcmliZXJzIHdoZW4gdGhlIHN0YXRlIGNoYW5nZXMuXG4gKi9cbmV4cG9ydCBjbGFzcyBTdG9yZSB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgc3RvcmUgd2l0aCB0aGUgZ2l2ZW4gaW5pdGlhbCBzdGF0ZSwgY29uc3RydWN0aW5nIHRoZSBjbGFzcyBpdCBpcyBjYWxsZWQgb24uXG4gICAqIENhbGxpbmcgaXQgb24gYSBnZW5lcmljIGJhc2UgY2xhc3MgKGUuZy4gYFJlYWN0U3RvcmUuY3JlYXRlKC4uLilgKSBjb25zdHJ1Y3RzIHRoYXRcbiAgICogY2xhc3MgYnV0IGRlZ3JhZGVzIHRoZSBpbmZlcnJlZCBpbnN0YW5jZSB0eXBlIHRvIGBTdG9yZWA7IHVzZSBgbmV3YCB0aGVyZSBpbnN0ZWFkLlxuICAgKi9cbiAgc3RhdGljIGNyZWF0ZShzdGF0ZSkge1xuICAgIHJldHVybiBuZXcgdGhpcyhzdGF0ZSk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIGN1cnJlbnQgc3RhdGUgb2YgdGhlIHN0b3JlLlxuICAgKiBUaGlzIHByb3BlcnR5IGlzIHVwZGF0ZWQgaW1tZWRpYXRlbHkgd2hlbiB0aGUgc3RhdGUgY2hhbmdlcyBhcyBhIHJlc3VsdCBvZiBjYWxsaW5nIHtAbGluayBzZXRTdGF0ZX0sIHtAbGluayB1cGRhdGV9LCBvciB7QGxpbmsgc2V0fS5cbiAgICogVG8gc3Vic2NyaWJlIHRvIHN0YXRlIGNoYW5nZXMsIHVzZSB0aGUge0BsaW5rIHVzZVN0YXRlfSBtZXRob2QuIFRoZSB2YWx1ZSByZXR1cm5lZCBieSB7QGxpbmsgdXNlU3RhdGV9IGlzIHVwZGF0ZWQgYWZ0ZXIgdGhlIGNvbXBvbmVudCByZW5kZXJzIChzaW1pbGFybHkgdG8gUmVhY3QncyB1c2VTdGF0ZSkuXG4gICAqIFRoZSB2YWx1ZXMgY2FuIGJlIHVzZWQgZGlyZWN0bHkgKHRvIGF2b2lkIHN1YnNjcmliaW5nIHRvIHRoZSBzdG9yZSkgaW4gZWZmZWN0cyBvciBldmVudCBoYW5kbGVycy5cbiAgICpcbiAgICogRG8gbm90IG1vZGlmeSBwcm9wZXJ0aWVzIGluIHN0YXRlIGRpcmVjdGx5LiBJbnN0ZWFkLCB1c2UgdGhlIHByb3ZpZGVkIG1ldGhvZHMgdG8gZW5zdXJlIHByb3BlciBzdGF0ZSBtYW5hZ2VtZW50IGFuZCBsaXN0ZW5lciBub3RpZmljYXRpb24uXG4gICAqL1xuXG4gIC8vIEludGVybmFsIHN0YXRlIHRvIGhhbmRsZSByZWN1cnNpdmUgYHNldFN0YXRlKClgIGNhbGxzXG5cbiAgY29uc3RydWN0b3Ioc3RhdGUpIHtcbiAgICB0aGlzLnN0YXRlID0gc3RhdGU7XG4gICAgdGhpcy5saXN0ZW5lcnMgPSBuZXcgU2V0KCk7XG4gICAgdGhpcy51cGRhdGVUaWNrID0gMDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBsaXN0ZW5lciB0aGF0IHdpbGwgYmUgY2FsbGVkIHdoZW5ldmVyIHRoZSBzdG9yZSdzIHN0YXRlIGNoYW5nZXMuXG4gICAqXG4gICAqIEBwYXJhbSBmbiBUaGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIG9uIHN0YXRlIGNoYW5nZXMuXG4gICAqIEByZXR1cm5zIEEgZnVuY3Rpb24gdG8gdW5zdWJzY3JpYmUgdGhlIGxpc3RlbmVyLlxuICAgKi9cbiAgc3Vic2NyaWJlID0gZm4gPT4ge1xuICAgIHRoaXMubGlzdGVuZXJzLmFkZChmbik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMubGlzdGVuZXJzLmRlbGV0ZShmbik7XG4gICAgfTtcbiAgfTtcblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgY3VycmVudCBzdGF0ZSBvZiB0aGUgc3RvcmUuXG4gICAqL1xuICBnZXRTbmFwc2hvdCA9ICgpID0+IHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZTtcbiAgfTtcblxuICAvKipcbiAgICogVXBkYXRlcyB0aGUgZW50aXJlIHN0b3JlJ3Mgc3RhdGUgYW5kIG5vdGlmaWVzIGFsbCByZWdpc3RlcmVkIGxpc3RlbmVycy5cbiAgICpcbiAgICogQHBhcmFtIG5ld1N0YXRlIFRoZSBuZXcgc3RhdGUgdG8gc2V0IGZvciB0aGUgc3RvcmUuXG4gICAqL1xuICBzZXRTdGF0ZShuZXdTdGF0ZSkge1xuICAgIGlmICh0aGlzLnN0YXRlID09PSBuZXdTdGF0ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnN0YXRlID0gbmV3U3RhdGU7XG4gICAgdGhpcy51cGRhdGVUaWNrICs9IDE7XG4gICAgY29uc3QgY3VycmVudFRpY2sgPSB0aGlzLnVwZGF0ZVRpY2s7XG4gICAgZm9yIChjb25zdCBsaXN0ZW5lciBvZiB0aGlzLmxpc3RlbmVycykge1xuICAgICAgaWYgKGN1cnJlbnRUaWNrICE9PSB0aGlzLnVwZGF0ZVRpY2spIHtcbiAgICAgICAgLy8gSWYgdGhlIHRpY2sgaGFzIGNoYW5nZWQsIGEgcmVjdXJzaXZlIGBzZXRTdGF0ZWAgY2FsbCBoYXMgYmVlbiBtYWRlLFxuICAgICAgICAvLyBhbmQgaXQgaGFzIGFscmVhZHkgbm90aWZpZWQgYWxsIGxpc3RlbmVycy5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGlzdGVuZXIobmV3U3RhdGUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBNZXJnZXMgdGhlIHByb3ZpZGVkIGNoYW5nZXMgaW50byB0aGUgY3VycmVudCBzdGF0ZSBhbmQgbm90aWZpZXMgbGlzdGVuZXJzIGlmIHRoZXJlIGFyZSBjaGFuZ2VzLlxuICAgKiBFYWNoIHZhbHVlIG11c3QgbWF0Y2ggaXRzIHN0YXRlIGtleS4gUGFzcyBhbiBleGFjdCBrbm93biBzdWJzZXQgcmF0aGVyIHRoYW4gYSBicm9hZFxuICAgKiBgUGFydGlhbDxTdGF0ZT5gLCB3aGljaCBtYXkgY29udGFpbiBgdW5kZWZpbmVkYCBmb3IgcmVxdWlyZWQgc3RhdGUgZmllbGRzLlxuICAgKlxuICAgKiBAcGFyYW0gY2hhbmdlcyBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgY2hhbmdlcyB0byBhcHBseSB0byB0aGUgY3VycmVudCBzdGF0ZS5cbiAgICovXG4gIHVwZGF0ZShjaGFuZ2VzKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gY2hhbmdlcykge1xuICAgICAgaWYgKCFPYmplY3QuaXModGhpcy5zdGF0ZVtrZXldLCBjaGFuZ2VzW2tleV0pKSB7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIC4uLnRoaXMuc3RhdGUsXG4gICAgICAgICAgLi4uY2hhbmdlc1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIGEgc3BlY2lmaWMga2V5IGluIHRoZSBzdG9yZSdzIHN0YXRlIHRvIGEgbmV3IHZhbHVlIGFuZCBub3RpZmllcyBsaXN0ZW5lcnMgaWYgdGhlIHZhbHVlIGhhcyBjaGFuZ2VkLlxuICAgKlxuICAgKiBAcGFyYW0ga2V5IFRoZSBrZXkgaW4gdGhlIHN0b3JlJ3Mgc3RhdGUgdG8gdXBkYXRlLlxuICAgKiBAcGFyYW0gdmFsdWUgVGhlIG5ldyB2YWx1ZSB0byBzZXQgZm9yIHRoZSBzcGVjaWZpZWQga2V5LlxuICAgKi9cbiAgc2V0KGtleSwgdmFsdWUpIHtcbiAgICBpZiAoIU9iamVjdC5pcyh0aGlzLnN0YXRlW2tleV0sIHZhbHVlKSkge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIC4uLnRoaXMuc3RhdGUsXG4gICAgICAgIFtrZXldOiB2YWx1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBzdGF0ZSBhIG5ldyByZWZlcmVuY2UgYW5kIHVwZGF0ZXMgYWxsIHJlZ2lzdGVyZWQgbGlzdGVuZXJzLlxuICAgKi9cbiAgbm90aWZ5QWxsKCkge1xuICAgIGNvbnN0IG5ld1N0YXRlID0ge1xuICAgICAgLi4udGhpcy5zdGF0ZVxuICAgIH07XG4gICAgdGhpcy5zZXRTdGF0ZShuZXdTdGF0ZSk7XG4gIH1cbiAgdXNlKHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgcmV0dXJuIHVzZVN0b3JlKHRoaXMsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKTtcbiAgfVxufSIsIi8qIEZhbHNlIHBvc2l0aXZlcyAtIEVTTGludCB0aGlua3Mgd2UncmUgY2FsbGluZyBhIGhvb2sgZnJvbSBhIGNsYXNzIGNvbXBvbmVudC4gKi9cbi8qIGVzbGludC1kaXNhYmxlIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzICovXG4ndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFN0b3JlIH0gZnJvbSBcIi4vU3RvcmUubWpzXCI7XG5pbXBvcnQgeyB1c2VTdG9yZSB9IGZyb20gXCIuL3VzZVN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tIFwiLi4vdXNlU3RhYmxlQ2FsbGJhY2subWpzXCI7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi4vdXNlSXNvTGF5b3V0RWZmZWN0Lm1qc1wiO1xuaW1wb3J0IHsgTk9PUCB9IGZyb20gXCIuLi9lbXB0eS5tanNcIjtcblxuLyoqXG4gKiBBIFN0b3JlIHRoYXQgc3VwcG9ydHMgY29udHJvbGxlZCBzdGF0ZSBrZXlzLCBub24tcmVhY3RpdmUgdmFsdWVzIGFuZCBwcm92aWRlcyB1dGlsaXR5IG1ldGhvZHMgZm9yIFJlYWN0LlxuICovXG5leHBvcnQgY2xhc3MgUmVhY3RTdG9yZSBleHRlbmRzIFN0b3JlIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgUmVhY3RTdG9yZSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHBhcmFtIHN0YXRlIEluaXRpYWwgc3RhdGUgb2YgdGhlIHN0b3JlLlxuICAgKiBAcGFyYW0gY29udGV4dCBOb24tcmVhY3RpdmUgY29udGV4dCB2YWx1ZXMuXG4gICAqIEBwYXJhbSBzZWxlY3RvcnMgT3B0aW9uYWwgc2VsZWN0b3JzIGZvciB1c2Ugd2l0aCBgdXNlU3RhdGVgLlxuICAgKi9cbiAgY29uc3RydWN0b3Ioc3RhdGUsIGNvbnRleHQgPSB7fSwgc2VsZWN0b3JzKSB7XG4gICAgc3VwZXIoc3RhdGUpO1xuICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgdGhpcy5zZWxlY3RvcnMgPSBzZWxlY3RvcnM7XG4gIH1cblxuICAvKipcbiAgICogTm9uLXJlYWN0aXZlIHZhbHVlcyBzdWNoIGFzIHJlZnMsIGNhbGxiYWNrcywgZXRjLlxuICAgKi9cblxuICAvKipcbiAgICogU3luY2hyb25pemVzIGEgc2luZ2xlIGV4dGVybmFsIHZhbHVlIGludG8gdGhlIHN0b3JlLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgdGhlIHdoaWxlIHRoZSB2YWx1ZSBpbiBgc3RhdGVgIGlzIHVwZGF0ZWQgaW1tZWRpYXRlbHksIHRoZSB2YWx1ZSByZXR1cm5lZFxuICAgKiBieSBgdXNlU3RhdGVgIGlzIHVwZGF0ZWQgYmVmb3JlIHRoZSBuZXh0IHJlbmRlciAoc2ltaWxhcmx5IHRvIFJlYWN0J3MgYHVzZVN0YXRlYCkuXG4gICAqL1xuICB1c2VTeW5jZWRWYWx1ZShrZXksIHZhbHVlKSB7XG4gICAgUmVhY3QudXNlRGVidWdWYWx1ZShrZXkpO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIGlmIChzdG9yZS5zdGF0ZVtrZXldICE9PSB2YWx1ZSkge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfSwgW3N0b3JlLCBrZXksIHZhbHVlXSk7XG4gIH1cblxuICAvKipcbiAgICogU3luY2hyb25pemVzIGEgc2luZ2xlIGV4dGVybmFsIHZhbHVlIGludG8gdGhlIHN0b3JlIGFuZFxuICAgKiBjbGVhbnMgaXQgdXAgKHNldHMgdG8gYHVuZGVmaW5lZGApIG9uIHVubW91bnQuXG4gICAqXG4gICAqIE5vdGUgdGhhdCB0aGUgd2hpbGUgdGhlIHZhbHVlIGluIGBzdGF0ZWAgaXMgdXBkYXRlZCBpbW1lZGlhdGVseSwgdGhlIHZhbHVlIHJldHVybmVkXG4gICAqIGJ5IGB1c2VTdGF0ZWAgaXMgdXBkYXRlZCBiZWZvcmUgdGhlIG5leHQgcmVuZGVyIChzaW1pbGFybHkgdG8gUmVhY3QncyBgdXNlU3RhdGVgKS5cbiAgICovXG4gIHVzZVN5bmNlZFZhbHVlV2l0aENsZWFudXAoa2V5LCB2YWx1ZSkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIGlmIChzdG9yZS5zdGF0ZVtrZXldICE9PSB2YWx1ZSkge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB1bmRlZmluZWQpO1xuICAgICAgfTtcbiAgICB9LCBbc3RvcmUsIGtleSwgdmFsdWVdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5jaHJvbml6ZXMgbXVsdGlwbGUgZXh0ZXJuYWwgdmFsdWVzIGludG8gdGhlIHN0b3JlLlxuICAgKiBFYWNoIHZhbHVlIG11c3QgbWF0Y2ggaXRzIHN0YXRlIGtleS4gUGFzcyBhbiBleGFjdCBrbm93biBzdWJzZXQgcmF0aGVyIHRoYW4gYSBicm9hZFxuICAgKiBgUGFydGlhbDxTdGF0ZT5gLCB3aGljaCBtYXkgY29udGFpbiBgdW5kZWZpbmVkYCBmb3IgcmVxdWlyZWQgc3RhdGUgZmllbGRzLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgdGhlIHdoaWxlIHRoZSB2YWx1ZXMgaW4gYHN0YXRlYCBhcmUgdXBkYXRlZCBpbW1lZGlhdGVseSwgdGhlIHZhbHVlcyByZXR1cm5lZFxuICAgKiBieSBgdXNlU3RhdGVgIGFyZSB1cGRhdGVkIGJlZm9yZSB0aGUgbmV4dCByZW5kZXIgKHNpbWlsYXJseSB0byBSZWFjdCdzIGB1c2VTdGF0ZWApLlxuICAgKlxuICAgKiBAcGFyYW0gc3RhdGVQYXJ0IEFuIGV4YWN0IHN1YnNldCBvZiBzdGF0ZSBmaWVsZHMgdG8gc3luY2hyb25pemUuIFVua25vd24ga2V5cyBhcmUgbm90IGFjY2VwdGVkLlxuICAgKi9cbiAgdXNlU3luY2VkVmFsdWVzKHN0YXRlUGFydCkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIC8vIENoZWNrIHRoYXQgYW4gb2JqZWN0IHdpdGggdGhlIHNhbWUgc2hhcGUgaXMgcGFzc2VkIG9uIGV2ZXJ5IHJlbmRlclxuICAgICAgUmVhY3QudXNlRGVidWdWYWx1ZShzdGF0ZVBhcnQsIHAgPT4gT2JqZWN0LmtleXMocCkpO1xuICAgICAgY29uc3Qga2V5cyA9IFJlYWN0LnVzZVJlZihPYmplY3Qua2V5cyhzdGF0ZVBhcnQpKS5jdXJyZW50O1xuICAgICAgY29uc3QgbmV4dEtleXMgPSBPYmplY3Qua2V5cyhzdGF0ZVBhcnQpO1xuICAgICAgaWYgKGtleXMubGVuZ3RoICE9PSBuZXh0S2V5cy5sZW5ndGggfHwga2V5cy5zb21lKChrZXksIGluZGV4KSA9PiBrZXkgIT09IG5leHRLZXlzW2luZGV4XSkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignUmVhY3RTdG9yZS51c2VTeW5jZWRWYWx1ZXMgZXhwZWN0cyB0aGUgc2FtZSBwcm9wIGtleXMgb24gZXZlcnkgcmVuZGVyLiBLZXlzIHNob3VsZCBiZSBzdGFibGUuJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGRlcGVuZGVuY2llcyA9IE9iamVjdC52YWx1ZXMoc3RhdGVQYXJ0KTtcbiAgICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgc3RvcmUudXBkYXRlKHN0YXRlUGFydCk7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgfSwgW3N0b3JlLCAuLi5kZXBlbmRlbmNpZXNdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBjb250cm9sbGFibGUgcHJvcCBwYWlyIChgY29udHJvbGxlZGAsIGBkZWZhdWx0VmFsdWVgKSBmb3IgYSBzcGVjaWZpYyBrZXkuIElmIGBjb250cm9sbGVkYFxuICAgKiBpcyBub24tdW5kZWZpbmVkLCB0aGUgc3RvcmUncyBzdGF0ZSBhdCBga2V5YCBpcyB1cGRhdGVkIHRvIG1hdGNoIGBjb250cm9sbGVkYC5cbiAgICovXG4gIHVzZUNvbnRyb2xsZWRQcm9wKGtleSwgY29udHJvbGxlZCkge1xuICAgIFJlYWN0LnVzZURlYnVnVmFsdWUoa2V5KTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC10aGlzXG4gICAgY29uc3Qgc3RvcmUgPSB0aGlzO1xuICAgIGNvbnN0IGlzQ29udHJvbGxlZCA9IGNvbnRyb2xsZWQgIT09IHVuZGVmaW5lZDtcbiAgICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKGlzQ29udHJvbGxlZCAmJiAhT2JqZWN0LmlzKHN0b3JlLnN0YXRlW2tleV0sIGNvbnRyb2xsZWQpKSB7XG4gICAgICAgIC8vIFNldCB0aGUgaW50ZXJuYWwgc3RhdGUgdG8gbWF0Y2ggdGhlIGNvbnRyb2xsZWQgdmFsdWUuXG4gICAgICAgIHN0b3JlLnNldFN0YXRlKHtcbiAgICAgICAgICAuLi5zdG9yZS5zdGF0ZSxcbiAgICAgICAgICBba2V5XTogY29udHJvbGxlZFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LCBbc3RvcmUsIGtleSwgY29udHJvbGxlZCwgaXNDb250cm9sbGVkXSk7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgY29uc3QgY2FjaGUgPSB0aGlzLmNvbnRyb2xsZWRWYWx1ZXMgPz89IG5ldyBNYXAoKTtcbiAgICAgIGlmICghY2FjaGUuaGFzKGtleSkpIHtcbiAgICAgICAgY2FjaGUuc2V0KGtleSwgaXNDb250cm9sbGVkKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHByZXZpb3VzbHlDb250cm9sbGVkID0gY2FjaGUuZ2V0KGtleSk7XG4gICAgICBpZiAocHJldmlvdXNseUNvbnRyb2xsZWQgIT09IHVuZGVmaW5lZCAmJiBwcmV2aW91c2x5Q29udHJvbGxlZCAhPT0gaXNDb250cm9sbGVkKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEEgY29tcG9uZW50IGlzIGNoYW5naW5nIHRoZSAke3ByZXZpb3VzbHlDb250cm9sbGVkID8gJycgOiAndW4nfWNvbnRyb2xsZWQgc3RhdGUgb2YgJHtrZXkudG9TdHJpbmcoKX0gdG8gYmUgJHtwcmV2aW91c2x5Q29udHJvbGxlZCA/ICd1bicgOiAnJ31jb250cm9sbGVkLiBFbGVtZW50cyBzaG91bGQgbm90IHN3aXRjaCBmcm9tIHVuY29udHJvbGxlZCB0byBjb250cm9sbGVkIChvciB2aWNlIHZlcnNhKS5gKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKiogR2V0cyB0aGUgY3VycmVudCB2YWx1ZSBmcm9tIHRoZSBzdG9yZSB1c2luZyBhIHNlbGVjdG9yIHdpdGggdGhlIHByb3ZpZGVkIGtleS5cbiAgICpcbiAgICogQHBhcmFtIGtleSBLZXkgb2YgdGhlIHNlbGVjdG9yIHRvIHVzZS5cbiAgICovXG5cbiAgc2VsZWN0KGtleSwgYTEsIGEyLCBhMykge1xuICAgIGNvbnN0IHNlbGVjdG9yID0gdGhpcy5zZWxlY3RvcnNba2V5XTtcbiAgICByZXR1cm4gc2VsZWN0b3IodGhpcy5zdGF0ZSwgYTEsIGEyLCBhMyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIHZhbHVlIGZyb20gdGhlIHN0b3JlJ3Mgc3RhdGUgdXNpbmcgYSBzZWxlY3RvciBmdW5jdGlvbi5cbiAgICogVXNlZCB0byBzdWJzY3JpYmUgdG8gc3BlY2lmaWMgcGFydHMgb2YgdGhlIHN0YXRlLlxuICAgKiBUaGlzIG1ldGhvZHMgY2F1c2VzIGEgcmVyZW5kZXIgd2hlbmV2ZXIgdGhlIHNlbGVjdGVkIHN0YXRlIGNoYW5nZXMuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBzZWxlY3RvciB0byB1c2UuXG4gICAqL1xuXG4gIHVzZVN0YXRlKGtleSwgYTEsIGEyLCBhMykge1xuICAgIFJlYWN0LnVzZURlYnVnVmFsdWUoa2V5KTtcbiAgICByZXR1cm4gdXNlU3RvcmUodGhpcywgdGhpcy5zZWxlY3RvcnNba2V5XSwgYTEsIGEyLCBhMyk7XG4gIH1cblxuICAvKipcbiAgICogV3JhcHMgYSBmdW5jdGlvbiB3aXRoIGB1c2VTdGFibGVDYWxsYmFja2AgdG8gZW5zdXJlIGl0IGhhcyBhIHN0YWJsZSByZWZlcmVuY2VcbiAgICogYW5kIGFzc2lnbnMgaXQgdG8gdGhlIGNvbnRleHQuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBldmVudCBjYWxsYmFjay4gTXVzdCBiZSBhIGZ1bmN0aW9uIGluIHRoZSBjb250ZXh0LlxuICAgKiBAcGFyYW0gZm4gRnVuY3Rpb24gdG8gYXNzaWduLlxuICAgKi9cbiAgdXNlQ29udGV4dENhbGxiYWNrKGtleSwgZm4pIHtcbiAgICBSZWFjdC51c2VEZWJ1Z1ZhbHVlKGtleSk7XG4gICAgY29uc3Qgc3RhYmxlRnVuY3Rpb24gPSB1c2VTdGFibGVDYWxsYmFjayhmbiA/PyBOT09QKTtcbiAgICB0aGlzLmNvbnRleHRba2V5XSA9IHN0YWJsZUZ1bmN0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBzdGFibGUgc2V0dGVyIGZ1bmN0aW9uIGZvciBhIHNwZWNpZmljIGtleSBpbiB0aGUgc3RvcmUncyBzdGF0ZS5cbiAgICogSXQncyBjb21tb25seSB1c2VkIHRvIHBhc3MgYXMgYSByZWYgY2FsbGJhY2sgdG8gUmVhY3QgZWxlbWVudHMuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBzdGF0ZSB0byBzZXQuXG4gICAqL1xuICB1c2VTdGF0ZVNldHRlcihrZXkpIHtcbiAgICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgICBpZiAocmVmLmN1cnJlbnQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmVmLmN1cnJlbnQgPSB2YWx1ZSA9PiB7XG4gICAgICAgIHRoaXMuc2V0KGtleSwgdmFsdWUpO1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHJlZi5jdXJyZW50O1xuICB9XG5cbiAgLyoqXG4gICAqIE9ic2VydmVzIGNoYW5nZXMgZGVyaXZlZCBmcm9tIHRoZSBzdG9yZSdzIHNlbGVjdG9ycyBhbmQgY2FsbHMgdGhlIGxpc3RlbmVyIHdoZW4gdGhlIHNlbGVjdGVkIHZhbHVlIGNoYW5nZXMuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBzZWxlY3RvciB0byBvYnNlcnZlLlxuICAgKiBAcGFyYW0gbGlzdGVuZXIgTGlzdGVuZXIgZnVuY3Rpb24gY2FsbGVkIHdoZW4gdGhlIHNlbGVjdG9yIHJlc3VsdCBjaGFuZ2VzLlxuICAgKi9cblxuICBvYnNlcnZlKHNlbGVjdG9yLCBsaXN0ZW5lcikge1xuICAgIGxldCBzZWxlY3RGbjtcbiAgICBpZiAodHlwZW9mIHNlbGVjdG9yID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBzZWxlY3RGbiA9IHNlbGVjdG9yO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZWxlY3RGbiA9IHRoaXMuc2VsZWN0b3JzW3NlbGVjdG9yXTtcbiAgICB9XG4gICAgbGV0IHByZXZWYWx1ZSA9IHNlbGVjdEZuKHRoaXMuc3RhdGUpO1xuICAgIGxpc3RlbmVyKHByZXZWYWx1ZSwgcHJldlZhbHVlLCB0aGlzKTtcbiAgICByZXR1cm4gdGhpcy5zdWJzY3JpYmUobmV4dFN0YXRlID0+IHtcbiAgICAgIGNvbnN0IG5leHRWYWx1ZSA9IHNlbGVjdEZuKG5leHRTdGF0ZSk7XG4gICAgICBpZiAoIU9iamVjdC5pcyhwcmV2VmFsdWUsIG5leHRWYWx1ZSkpIHtcbiAgICAgICAgY29uc3Qgb2xkVmFsdWUgPSBwcmV2VmFsdWU7XG4gICAgICAgIHByZXZWYWx1ZSA9IG5leHRWYWx1ZTtcbiAgICAgICAgbGlzdGVuZXIobmV4dFZhbHVlLCBvbGRWYWx1ZSwgdGhpcyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn0iLCJpbXBvcnQgeyBSZWFjdFN0b3JlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RvcmUnO1xuaW1wb3J0IHsgY3JlYXRlRXZlbnRFbWl0dGVyIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUV2ZW50RW1pdHRlci5tanNcIjtcbmltcG9ydCB7IGlzQ2xpY2tMaWtlRXZlbnQgfSBmcm9tIFwiLi4vdXRpbHMubWpzXCI7XG5jb25zdCBzZWxlY3RvcnMgPSB7XG4gIG9wZW46IHN0YXRlID0+IHN0YXRlLm9wZW4sXG4gIHRyYW5zaXRpb25TdGF0dXM6IHN0YXRlID0+IHN0YXRlLnRyYW5zaXRpb25TdGF0dXMsXG4gIGRvbVJlZmVyZW5jZUVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLmRvbVJlZmVyZW5jZUVsZW1lbnQsXG4gIHJlZmVyZW5jZUVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnBvc2l0aW9uUmVmZXJlbmNlID8/IHN0YXRlLnJlZmVyZW5jZUVsZW1lbnQsXG4gIGZsb2F0aW5nRWxlbWVudDogc3RhdGUgPT4gc3RhdGUuZmxvYXRpbmdFbGVtZW50LFxuICBmbG9hdGluZ0lkOiBzdGF0ZSA9PiBzdGF0ZS5mbG9hdGluZ0lkXG59O1xuZXhwb3J0IGNsYXNzIEZsb2F0aW5nUm9vdFN0b3JlIGV4dGVuZHMgUmVhY3RTdG9yZSB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBjb25zdCB7XG4gICAgICBzeW5jT25seSxcbiAgICAgIG5lc3RlZCxcbiAgICAgIG9uT3BlbkNoYW5nZSxcbiAgICAgIHRyaWdnZXJFbGVtZW50cyxcbiAgICAgIC4uLmluaXRpYWxTdGF0ZVxuICAgIH0gPSBvcHRpb25zO1xuICAgIHN1cGVyKHtcbiAgICAgIC4uLmluaXRpYWxTdGF0ZSxcbiAgICAgIHBvc2l0aW9uUmVmZXJlbmNlOiBpbml0aWFsU3RhdGUucmVmZXJlbmNlRWxlbWVudCxcbiAgICAgIGRvbVJlZmVyZW5jZUVsZW1lbnQ6IGluaXRpYWxTdGF0ZS5yZWZlcmVuY2VFbGVtZW50XG4gICAgfSwge1xuICAgICAgb25PcGVuQ2hhbmdlLFxuICAgICAgZGF0YVJlZjoge1xuICAgICAgICBjdXJyZW50OiB7fVxuICAgICAgfSxcbiAgICAgIGV2ZW50czogY3JlYXRlRXZlbnRFbWl0dGVyKCksXG4gICAgICBuZXN0ZWQsXG4gICAgICB0cmlnZ2VyRWxlbWVudHNcbiAgICB9LCBzZWxlY3RvcnMpO1xuICAgIHRoaXMuc3luY09ubHkgPSBzeW5jT25seTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5jcyB0aGUgZXZlbnQgdXNlZCBieSBob3ZlciBsb2dpYyB0byBkaXN0aW5ndWlzaCBob3Zlci1vcGVuIGZyb20gY2xpY2stbGlrZSBpbnRlcmFjdGlvbi5cbiAgICovXG4gIHN5bmNPcGVuRXZlbnQgPSAobmV3T3BlbiwgZXZlbnQpID0+IHtcbiAgICBpZiAoIW5ld09wZW4gfHwgIXRoaXMuc3RhdGUub3BlbiB8fFxuICAgIC8vIFByZXZlbnQgYSBwZW5kaW5nIGhvdmVyLW9wZW4gZnJvbSBvdmVyd3JpdGluZyBhIGNsaWNrLW9wZW4gZXZlbnQsIHdoaWxlIGFsbG93aW5nXG4gICAgLy8gY2xpY2sgZXZlbnRzIHRvIHVwZ3JhZGUgYSBob3Zlci1vcGVuLlxuICAgIGV2ZW50ICE9IG51bGwgJiYgaXNDbGlja0xpa2VFdmVudChldmVudCkpIHtcbiAgICAgIHRoaXMuY29udGV4dC5kYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50ID0gbmV3T3BlbiA/IGV2ZW50IDogdW5kZWZpbmVkO1xuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogUnVucyB0aGUgcm9vdC1vd25lZCBzaWRlIGVmZmVjdHMgZm9yIGFuIG9wZW4gc3RhdGUgY2hhbmdlLlxuICAgKi9cbiAgZGlzcGF0Y2hPcGVuQ2hhbmdlID0gKG5ld09wZW4sIGV2ZW50RGV0YWlscykgPT4ge1xuICAgIHRoaXMuc3luY09wZW5FdmVudChuZXdPcGVuLCBldmVudERldGFpbHMuZXZlbnQpO1xuICAgIGNvbnN0IGRldGFpbHMgPSB7XG4gICAgICBvcGVuOiBuZXdPcGVuLFxuICAgICAgcmVhc29uOiBldmVudERldGFpbHMucmVhc29uLFxuICAgICAgbmF0aXZlRXZlbnQ6IGV2ZW50RGV0YWlscy5ldmVudCxcbiAgICAgIG5lc3RlZDogdGhpcy5jb250ZXh0Lm5lc3RlZCxcbiAgICAgIHRyaWdnZXJFbGVtZW50OiBldmVudERldGFpbHMudHJpZ2dlclxuICAgIH07XG4gICAgdGhpcy5jb250ZXh0LmV2ZW50cy5lbWl0KCdvcGVuY2hhbmdlJywgZGV0YWlscyk7XG4gIH07XG5cbiAgLyoqXG4gICAqIEVtaXRzIHRoZSBgb3BlbmNoYW5nZWAgZXZlbnQgdGhyb3VnaCB0aGUgaW50ZXJuYWwgZXZlbnQgZW1pdHRlciBhbmQgY2FsbHMgdGhlIGBvbk9wZW5DaGFuZ2VgIGhhbmRsZXIgd2l0aCB0aGUgcHJvdmlkZWQgYXJndW1lbnRzLlxuICAgKlxuICAgKiBAcGFyYW0gbmV3T3BlbiBUaGUgbmV3IG9wZW4gc3RhdGUuXG4gICAqIEBwYXJhbSBldmVudERldGFpbHMgRGV0YWlscyBhYm91dCB0aGUgZXZlbnQgdGhhdCB0cmlnZ2VyZWQgdGhlIG9wZW4gc3RhdGUgY2hhbmdlLlxuICAgKi9cbiAgc2V0T3BlbiA9IChuZXdPcGVuLCBldmVudERldGFpbHMpID0+IHtcbiAgICBpZiAodGhpcy5zeW5jT25seSkge1xuICAgICAgdGhpcy5jb250ZXh0Lm9uT3BlbkNoYW5nZT8uKG5ld09wZW4sIGV2ZW50RGV0YWlscyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuZGlzcGF0Y2hPcGVuQ2hhbmdlKG5ld09wZW4sIGV2ZW50RGV0YWlscyk7XG4gICAgdGhpcy5jb250ZXh0Lm9uT3BlbkNoYW5nZT8uKG5ld09wZW4sIGV2ZW50RGV0YWlscyk7XG4gIH07XG59IiwiaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgRmxvYXRpbmdSb290U3RvcmUgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvY29tcG9uZW50cy9GbG9hdGluZ1Jvb3RTdG9yZS5tanNcIjtcblxuLyoqXG4gKiBTdGF0ZSBjb21tb24gdG8gYWxsIHBvcHVwIHN0b3Jlcy5cbiAqL1xuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSh0cmlnZ2VyRWxlbWVudHMsIGZsb2F0aW5nSWQsIG5lc3RlZCA9IGZhbHNlKSB7XG4gIHJldHVybiB7XG4gICAgb3BlbjogZmFsc2UsXG4gICAgb3BlblByb3A6IHVuZGVmaW5lZCxcbiAgICBtb3VudGVkOiBmYWxzZSxcbiAgICB0cmFuc2l0aW9uU3RhdHVzOiB1bmRlZmluZWQsXG4gICAgZmxvYXRpbmdSb290Q29udGV4dDogbmV3IEZsb2F0aW5nUm9vdFN0b3JlKHtcbiAgICAgIG9wZW46IGZhbHNlLFxuICAgICAgdHJhbnNpdGlvblN0YXR1czogdW5kZWZpbmVkLFxuICAgICAgZmxvYXRpbmdFbGVtZW50OiBudWxsLFxuICAgICAgcmVmZXJlbmNlRWxlbWVudDogbnVsbCxcbiAgICAgIHRyaWdnZXJFbGVtZW50cyxcbiAgICAgIGZsb2F0aW5nSWQsXG4gICAgICBzeW5jT25seTogdHJ1ZSxcbiAgICAgIG5lc3RlZCxcbiAgICAgIG9uT3BlbkNoYW5nZTogdW5kZWZpbmVkXG4gICAgfSksXG4gICAgZmxvYXRpbmdJZCxcbiAgICB0cmlnZ2VyQ291bnQ6IDAsXG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlOiBmYWxzZSxcbiAgICBwYXlsb2FkOiB1bmRlZmluZWQsXG4gICAgYWN0aXZlVHJpZ2dlcklkOiBudWxsLFxuICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBudWxsLFxuICAgIG9wZW5lZFdpdGhvdXRUcmlnZ2VyOiBmYWxzZSxcbiAgICB0cmlnZ2VySWRQcm9wOiB1bmRlZmluZWQsXG4gICAgcG9wdXBFbGVtZW50OiBudWxsLFxuICAgIHBvc2l0aW9uZXJFbGVtZW50OiBudWxsLFxuICAgIGFjdGl2ZVRyaWdnZXJQcm9wczogRU1QVFlfT0JKRUNULFxuICAgIGluYWN0aXZlVHJpZ2dlclByb3BzOiBFTVBUWV9PQkpFQ1QsXG4gICAgcG9wdXBQcm9wczogRU1QVFlfT0JKRUNUXG4gIH07XG59XG5jb25zdCBhY3RpdmVUcmlnZ2VySWRTZWxlY3RvciA9IHN0YXRlID0+IHN0YXRlLnRyaWdnZXJJZFByb3AgPz8gc3RhdGUuYWN0aXZlVHJpZ2dlcklkO1xuY29uc3Qgb3BlblNlbGVjdG9yID0gc3RhdGUgPT4gc3RhdGUub3BlblByb3AgPz8gc3RhdGUub3BlbjtcbmNvbnN0IHBvcHVwSWRTZWxlY3RvciA9IHN0YXRlID0+IHtcbiAgY29uc3QgcG9wdXBJZCA9IHN0YXRlLnBvcHVwRWxlbWVudD8uaWQgPz8gc3RhdGUuZmxvYXRpbmdJZDtcbiAgcmV0dXJuIHBvcHVwSWQgfHwgdW5kZWZpbmVkO1xufTtcbmZ1bmN0aW9uIHRyaWdnZXJPd25zT3BlblBvcHVwKHN0YXRlLCB0cmlnZ2VySWQpIHtcbiAgcmV0dXJuIHRyaWdnZXJJZCAhPT0gdW5kZWZpbmVkICYmIG9wZW5TZWxlY3RvcihzdGF0ZSkgJiYgYWN0aXZlVHJpZ2dlcklkU2VsZWN0b3Ioc3RhdGUpID09PSB0cmlnZ2VySWQ7XG59XG5mdW5jdGlvbiB0cmlnZ2VyT3duc09wZW5Qb3B1cE9ySXNPbmx5VHJpZ2dlcihzdGF0ZSwgdHJpZ2dlcklkKSB7XG4gIGlmICh0cmlnZ2VyT3duc09wZW5Qb3B1cChzdGF0ZSwgdHJpZ2dlcklkKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiB0cmlnZ2VySWQgIT09IHVuZGVmaW5lZCAmJiBvcGVuU2VsZWN0b3Ioc3RhdGUpICYmIGFjdGl2ZVRyaWdnZXJJZFNlbGVjdG9yKHN0YXRlKSA9PSBudWxsICYmICFzdGF0ZS5vcGVuZWRXaXRob3V0VHJpZ2dlciAmJiBzdGF0ZS50cmlnZ2VyQ291bnQgPT09IDE7XG59XG5leHBvcnQgY29uc3QgcG9wdXBTdG9yZVNlbGVjdG9ycyA9IHtcbiAgb3Blbjogb3BlblNlbGVjdG9yLFxuICBtb3VudGVkOiBzdGF0ZSA9PiBzdGF0ZS5tb3VudGVkLFxuICAvLyBgb3BlbmAgaXMgd3JpdHRlbiBzeW5jaHJvbm91c2x5IG9uIGFuIG9wZW4gY2hhbmdlOyBgbW91bnRlZGAvYHRyYW5zaXRpb25TdGF0dXNgIHN5bmMgaW4gYVxuICAvLyBsYXlvdXQgZWZmZWN0LiBNYXRjaCB1c2VUcmFuc2l0aW9uU3RhdHVzIHNvIGEgcmV0YWluZWQgcG9wdXAgZG9lcyBub3QgbWlzcyBpdHMgc3RhcnRpbmcgcGhhc2UuXG4gIHRyYW5zaXRpb25TdGF0dXM6IHN0YXRlID0+IG9wZW5TZWxlY3RvcihzdGF0ZSkgJiYgIXN0YXRlLm1vdW50ZWQgPyAnc3RhcnRpbmcnIDogc3RhdGUudHJhbnNpdGlvblN0YXR1cyxcbiAgZmxvYXRpbmdSb290Q29udGV4dDogc3RhdGUgPT4gc3RhdGUuZmxvYXRpbmdSb290Q29udGV4dCxcbiAgdHJpZ2dlckNvdW50OiBzdGF0ZSA9PiBzdGF0ZS50cmlnZ2VyQ291bnQsXG4gIHByZXZlbnRVbm1vdW50aW5nT25DbG9zZTogc3RhdGUgPT4gc3RhdGUucHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICBwYXlsb2FkOiBzdGF0ZSA9PiBzdGF0ZS5wYXlsb2FkLFxuICBhY3RpdmVUcmlnZ2VySWQ6IGFjdGl2ZVRyaWdnZXJJZFNlbGVjdG9yLFxuICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogc3RhdGUgPT4gc3RhdGUubW91bnRlZCA/IHN0YXRlLmFjdGl2ZVRyaWdnZXJFbGVtZW50IDogbnVsbCxcbiAgcG9wdXBJZDogcG9wdXBJZFNlbGVjdG9yLFxuICAvKipcbiAgICogV2hldGhlciB0aGUgdHJpZ2dlciB3aXRoIHRoZSBnaXZlbiBJRCB3YXMgdXNlZCB0byBvcGVuIHRoZSBwb3B1cC5cbiAgICovXG4gIGlzVHJpZ2dlckFjdGl2ZTogKHN0YXRlLCB0cmlnZ2VySWQpID0+IHRyaWdnZXJJZCAhPT0gdW5kZWZpbmVkICYmIGFjdGl2ZVRyaWdnZXJJZFNlbGVjdG9yKHN0YXRlKSA9PT0gdHJpZ2dlcklkLFxuICAvKipcbiAgICogV2hldGhlciB0aGUgcG9wdXAgaXMgb3BlbiBhbmQgd2FzIGFjdGl2YXRlZCBieSBhIHRyaWdnZXIgd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAqL1xuICBpc09wZW5lZEJ5VHJpZ2dlcjogKHN0YXRlLCB0cmlnZ2VySWQpID0+IHRyaWdnZXJPd25zT3BlblBvcHVwKHN0YXRlLCB0cmlnZ2VySWQpLFxuICAvKipcbiAgICogV2hldGhlciB0aGUgcG9wdXAgaXMgbW91bnRlZCBhbmQgd2FzIGFjdGl2YXRlZCBieSBhIHRyaWdnZXIgd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAqL1xuICBpc01vdW50ZWRCeVRyaWdnZXI6IChzdGF0ZSwgdHJpZ2dlcklkKSA9PiB0cmlnZ2VySWQgIT09IHVuZGVmaW5lZCAmJiBhY3RpdmVUcmlnZ2VySWRTZWxlY3RvcihzdGF0ZSkgPT09IHRyaWdnZXJJZCAmJiBzdGF0ZS5tb3VudGVkLFxuICB0cmlnZ2VyUHJvcHM6IChzdGF0ZSwgaXNBY3RpdmUpID0+IGlzQWN0aXZlID8gc3RhdGUuYWN0aXZlVHJpZ2dlclByb3BzIDogc3RhdGUuaW5hY3RpdmVUcmlnZ2VyUHJvcHMsXG4gIC8qKlxuICAgKiBQb3B1cCBpZCBmb3IgdGhlIHRyaWdnZXIgdGhhdCBjdXJyZW50bHkgb3ducyB0aGUgb3BlbiBwb3B1cC5cbiAgICovXG4gIHRyaWdnZXJQb3B1cElkOiAoc3RhdGUsIHRyaWdnZXJJZCkgPT4gdHJpZ2dlck93bnNPcGVuUG9wdXBPcklzT25seVRyaWdnZXIoc3RhdGUsIHRyaWdnZXJJZCkgPyBwb3B1cElkU2VsZWN0b3Ioc3RhdGUpIDogdW5kZWZpbmVkLFxuICBwb3B1cFByb3BzOiBzdGF0ZSA9PiBzdGF0ZS5wb3B1cFByb3BzLFxuICBwb3B1cEVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnBvcHVwRWxlbWVudCxcbiAgcG9zaXRpb25lckVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnBvc2l0aW9uZXJFbGVtZW50XG59O1xuXG4vKipcbiAqIFN0b3JlIG1lbWJlcnMgYSBkZXRhY2hlZCBoYW5kbGUtYmFja2VkIHRyaWdnZXIgcmVhZHMgb3IgaW52b2tlcyBmb3IgdHJpZ2dlciByZWdpc3RyYXRpb24gYW5kIGRhdGFcbiAqIGZvcndhcmRpbmcuIGBzZXRgL2B1cGRhdGVgIGFyZSBpbmNsdWRlZCBvbmx5IGZvciB0cmlnZ2VyLWNvdW50IGFuZCB0cmlnZ2VyLWRhdGEgYm9va2tlZXBpbmc7IG9uIGFcbiAqIGRldGFjaGVkIChpbmVydCkgc3RvcmUgdGhleSBhcmUgaW50ZW50aW9uYWxseSBuby1vcHMsIHNvIGEgd3JpdGUgdGhyb3VnaCB0aGVtIGlzIG5vdCBndWFyYW50ZWVkIHRvXG4gKiBiZSBkdXJhYmxlLiBDb21wb25lbnQgaGFuZGxlLXN0b3JlIHZpZXdzIFBpY2sgdGhlc2UgZnJvbSB0aGVpciBjb25jcmV0ZSBzdG9yZSAocHJlc2VydmluZyBpdHNcbiAqIGNvbnRleHQgYW5kIHNlbGVjdG9ycykgYW5kIGFkZCBhbnkgY29tcG9uZW50LXNwZWNpZmljIHRyaWdnZXItaW52b2tlZCBtZW1iZXJzIHN1Y2ggYXMgYHNldE9wZW5gLlxuICovXG5cbi8qKlxuICogVGhlIHN1YnNldCBvZiBhIHBvcHVwIHN0b3JlIHRoYXQgdHJpZ2dlciByZWdpc3RyYXRpb24gYW5kIGRhdGEgZm9yd2FyZGluZyByZWx5IG9uLiBOYXJyb3cgZW5vdWdoXG4gKiB0aGF0IGFuIGluZXJ0IHN0b3JlIGNhbiBiZSBwYXNzZWQgd2hpbGUgZGV0YWNoZWQuXG4gKi8iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVN5bmNFeHRlcm5hbFN0b3JlIH0gZnJvbSAndXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbSc7XG5pbXBvcnQgeyBOT09QIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuLyoqXG4gKiBSZWFkcyB0aGUgc3RvcmUgY3VycmVudGx5IGV4cG9zZWQgYnkgYSBwb3B1cCBoYW5kbGUgYW5kIHN1YnNjcmliZXMgdG8gc3RvcmUtcG9pbnRlciBjaGFuZ2VzLlxuICogRGV0YWNoZWQgdHJpZ2dlcnMgdXNlIHRoaXMgdG8gZm9sbG93IGEgaGFuZGxlIGFzIGEgcm9vdCBhdHRhY2hlcyBvciBkZXRhY2hlczogd2hpbGUgbm8gcm9vdCBpc1xuICogYXR0YWNoZWQsIHRoZSBoYW5kbGUgZXhwb3NlcyBpdHMgZmFsbGJhY2sgc3RvcmU7IG9uY2UgYSByb290IGF0dGFjaGVzLCBzdWJzY3JpYmVycyByZS1yZW5kZXIgYW5kXG4gKiByZWFkIGZyb20gdGhlIGxpdmUgcm9vdCBzdG9yZS5cbiAqXG4gKiBSZXR1cm5zIGB1bmRlZmluZWRgIHdoZW4gbm8gaGFuZGxlIGlzIHByb3ZpZGVkIHNvIGNhbGxlcnMgY2FuIGZhbGwgYmFjayB0byB0aGVpciByb290IGNvbnRleHQuXG4gKlxuICogQHBhcmFtIGhhbmRsZSBUaGUgcG9wdXAgaGFuZGxlIHRvIHJlYWQgZnJvbSwgb3IgYHVuZGVmaW5lZGAgd2hlbiB0aGUgdHJpZ2dlciBpcyBub3QgaGFuZGxlLWJvdW5kLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUG9wdXBIYW5kbGVTdG9yZShoYW5kbGUpIHtcbiAgY29uc3Qgc3Vic2NyaWJlID0gUmVhY3QudXNlQ2FsbGJhY2sobGlzdGVuZXIgPT4ge1xuICAgIGlmIChoYW5kbGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIE5PT1A7XG4gICAgfVxuICAgIHJldHVybiBoYW5kbGUuc3Vic2NyaWJlU3RvcmUobGlzdGVuZXIpO1xuICB9LCBbaGFuZGxlXSk7XG4gIGNvbnN0IGdldFNuYXBzaG90ID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJldHVybiBoYW5kbGUgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IGhhbmRsZS5zdG9yZTtcbiAgfSwgW2hhbmRsZV0pO1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3Vic2NyaWJlLCBnZXRTbmFwc2hvdCwgKCkgPT4gaGFuZGxlPy5zZXJ2ZXJTdG9yZSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgRGlhbG9nUG9ydGFsQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dQb3J0YWxDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJEaWFsb2dQb3J0YWxDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlRGlhbG9nUG9ydGFsQ29udGV4dCgpIHtcbiAgY29uc3QgdmFsdWUgPSBSZWFjdC51c2VDb250ZXh0KERpYWxvZ1BvcnRhbENvbnRleHQpO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogPERpYWxvZy5Qb3J0YWw+IGlzIG1pc3NpbmcuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMjYpKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59IiwiaW1wb3J0IHsgaXNIVE1MRWxlbWVudCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuZXhwb3J0IHsgc3RvcEV2ZW50LCBpc0luZGV4T3V0T2ZMaXN0Qm91bmRzLCBpc0xpc3RJbmRleERpc2FibGVkLCBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgsIGdldE1heExpc3RJbmRleCwgZ2V0TWluTGlzdEluZGV4IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzLm1qc1wiO1xuZXhwb3J0IGNvbnN0IEFSUk9XX1VQID0gJ0Fycm93VXAnO1xuZXhwb3J0IGNvbnN0IEFSUk9XX0RPV04gPSAnQXJyb3dEb3duJztcbmV4cG9ydCBjb25zdCBBUlJPV19MRUZUID0gJ0Fycm93TGVmdCc7XG5leHBvcnQgY29uc3QgQVJST1dfUklHSFQgPSAnQXJyb3dSaWdodCc7XG5leHBvcnQgY29uc3QgSE9NRSA9ICdIb21lJztcbmV4cG9ydCBjb25zdCBFTkQgPSAnRW5kJztcbmV4cG9ydCBjb25zdCBQQUdFX1VQID0gJ1BhZ2VVcCc7XG5leHBvcnQgY29uc3QgUEFHRV9ET1dOID0gJ1BhZ2VEb3duJztcbmV4cG9ydCBjb25zdCBDT01QT1NJVEVfS0VZUyA9IG5ldyBTZXQoW0FSUk9XX1VQLCBBUlJPV19ET1dOLCBBUlJPV19MRUZULCBBUlJPV19SSUdIVCwgSE9NRSwgRU5EXSk7XG5leHBvcnQgY29uc3QgU0hJRlQgPSAnU2hpZnQnO1xuZXhwb3J0IGNvbnN0IE1PRElGSUVSX0tFWVMgPSBbU0hJRlQsICdDb250cm9sJywgJ0FsdCcsICdNZXRhJ107XG5mdW5jdGlvbiBpc0lucHV0RWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBpc0hUTUxFbGVtZW50KGVsZW1lbnQpICYmIGVsZW1lbnQudGFnTmFtZSA9PT0gJ0lOUFVUJztcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc05hdGl2ZUlucHV0KGVsZW1lbnQpIHtcbiAgaWYgKGlzSW5wdXRFbGVtZW50KGVsZW1lbnQpICYmIGVsZW1lbnQuc2VsZWN0aW9uU3RhcnQgIT0gbnVsbCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChpc0hUTUxFbGVtZW50KGVsZW1lbnQpICYmIGVsZW1lbnQudGFnTmFtZSA9PT0gJ1RFWFRBUkVBJykge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBzY3JvbGxJbnRvVmlld0lmTmVlZGVkKHNjcm9sbENvbnRhaW5lciwgZWxlbWVudCwgZGlyZWN0aW9uLCBvcmllbnRhdGlvbikge1xuICBpZiAoIXNjcm9sbENvbnRhaW5lciB8fCAhZWxlbWVudCB8fCAhZWxlbWVudC5zY3JvbGxUbykge1xuICAgIHJldHVybjtcbiAgfVxuICBsZXQgdGFyZ2V0WCA9IHNjcm9sbENvbnRhaW5lci5zY3JvbGxMZWZ0O1xuICBsZXQgdGFyZ2V0WSA9IHNjcm9sbENvbnRhaW5lci5zY3JvbGxUb3A7XG4gIGNvbnN0IGlzT3ZlcmZsb3dpbmdYID0gc2Nyb2xsQ29udGFpbmVyLmNsaWVudFdpZHRoIDwgc2Nyb2xsQ29udGFpbmVyLnNjcm9sbFdpZHRoO1xuICBjb25zdCBpc092ZXJmbG93aW5nWSA9IHNjcm9sbENvbnRhaW5lci5jbGllbnRIZWlnaHQgPCBzY3JvbGxDb250YWluZXIuc2Nyb2xsSGVpZ2h0O1xuICBpZiAoaXNPdmVyZmxvd2luZ1ggJiYgb3JpZW50YXRpb24gIT09ICd2ZXJ0aWNhbCcpIHtcbiAgICBjb25zdCBlbGVtZW50T2Zmc2V0TGVmdCA9IGdldE9mZnNldChzY3JvbGxDb250YWluZXIsIGVsZW1lbnQsICdsZWZ0Jyk7XG4gICAgY29uc3QgY29udGFpbmVyU3R5bGVzID0gZ2V0U3R5bGVzKHNjcm9sbENvbnRhaW5lcik7XG4gICAgY29uc3QgZWxlbWVudFN0eWxlcyA9IGdldFN0eWxlcyhlbGVtZW50KTtcbiAgICBpZiAoZGlyZWN0aW9uID09PSAnbHRyJykge1xuICAgICAgaWYgKGVsZW1lbnRPZmZzZXRMZWZ0ICsgZWxlbWVudC5vZmZzZXRXaWR0aCArIGVsZW1lbnRTdHlsZXMuc2Nyb2xsTWFyZ2luUmlnaHQgPiBzY3JvbGxDb250YWluZXIuc2Nyb2xsTGVmdCArIHNjcm9sbENvbnRhaW5lci5jbGllbnRXaWR0aCAtIGNvbnRhaW5lclN0eWxlcy5zY3JvbGxQYWRkaW5nUmlnaHQpIHtcbiAgICAgICAgLy8gb3ZlcmZsb3cgdG8gdGhlIHJpZ2h0LCBzY3JvbGwgdG8gYWxpZ24gcmlnaHQgZWRnZXNcbiAgICAgICAgdGFyZ2V0WCA9IGVsZW1lbnRPZmZzZXRMZWZ0ICsgZWxlbWVudC5vZmZzZXRXaWR0aCArIGVsZW1lbnRTdHlsZXMuc2Nyb2xsTWFyZ2luUmlnaHQgLSBzY3JvbGxDb250YWluZXIuY2xpZW50V2lkdGggKyBjb250YWluZXJTdHlsZXMuc2Nyb2xsUGFkZGluZ1JpZ2h0O1xuICAgICAgfSBlbHNlIGlmIChlbGVtZW50T2Zmc2V0TGVmdCAtIGVsZW1lbnRTdHlsZXMuc2Nyb2xsTWFyZ2luTGVmdCA8IHNjcm9sbENvbnRhaW5lci5zY3JvbGxMZWZ0ICsgY29udGFpbmVyU3R5bGVzLnNjcm9sbFBhZGRpbmdMZWZ0KSB7XG4gICAgICAgIC8vIG92ZXJmbG93IHRvIHRoZSBsZWZ0LCBzY3JvbGwgdG8gYWxpZ24gbGVmdCBlZGdlc1xuICAgICAgICB0YXJnZXRYID0gZWxlbWVudE9mZnNldExlZnQgLSBlbGVtZW50U3R5bGVzLnNjcm9sbE1hcmdpbkxlZnQgLSBjb250YWluZXJTdHlsZXMuc2Nyb2xsUGFkZGluZ0xlZnQ7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChkaXJlY3Rpb24gPT09ICdydGwnKSB7XG4gICAgICBpZiAoZWxlbWVudE9mZnNldExlZnQgLSBlbGVtZW50U3R5bGVzLnNjcm9sbE1hcmdpbkxlZnQgPCBzY3JvbGxDb250YWluZXIuc2Nyb2xsTGVmdCArIGNvbnRhaW5lclN0eWxlcy5zY3JvbGxQYWRkaW5nTGVmdCkge1xuICAgICAgICAvLyBvdmVyZmxvdyB0byB0aGUgbGVmdCwgc2Nyb2xsIHRvIGFsaWduIGxlZnQgZWRnZXNcbiAgICAgICAgdGFyZ2V0WCA9IGVsZW1lbnRPZmZzZXRMZWZ0IC0gZWxlbWVudFN0eWxlcy5zY3JvbGxNYXJnaW5MZWZ0IC0gY29udGFpbmVyU3R5bGVzLnNjcm9sbFBhZGRpbmdMZWZ0O1xuICAgICAgfSBlbHNlIGlmIChlbGVtZW50T2Zmc2V0TGVmdCArIGVsZW1lbnQub2Zmc2V0V2lkdGggKyBlbGVtZW50U3R5bGVzLnNjcm9sbE1hcmdpblJpZ2h0ID4gc2Nyb2xsQ29udGFpbmVyLnNjcm9sbExlZnQgKyBzY3JvbGxDb250YWluZXIuY2xpZW50V2lkdGggLSBjb250YWluZXJTdHlsZXMuc2Nyb2xsUGFkZGluZ1JpZ2h0KSB7XG4gICAgICAgIC8vIG92ZXJmbG93IHRvIHRoZSByaWdodCwgc2Nyb2xsIHRvIGFsaWduIHJpZ2h0IGVkZ2VzXG4gICAgICAgIHRhcmdldFggPSBlbGVtZW50T2Zmc2V0TGVmdCArIGVsZW1lbnQub2Zmc2V0V2lkdGggKyBlbGVtZW50U3R5bGVzLnNjcm9sbE1hcmdpblJpZ2h0IC0gc2Nyb2xsQ29udGFpbmVyLmNsaWVudFdpZHRoICsgY29udGFpbmVyU3R5bGVzLnNjcm9sbFBhZGRpbmdSaWdodDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGlzT3ZlcmZsb3dpbmdZICYmIG9yaWVudGF0aW9uICE9PSAnaG9yaXpvbnRhbCcpIHtcbiAgICBjb25zdCBlbGVtZW50T2Zmc2V0VG9wID0gZ2V0T2Zmc2V0KHNjcm9sbENvbnRhaW5lciwgZWxlbWVudCwgJ3RvcCcpO1xuICAgIGNvbnN0IGNvbnRhaW5lclN0eWxlcyA9IGdldFN0eWxlcyhzY3JvbGxDb250YWluZXIpO1xuICAgIGNvbnN0IGVsZW1lbnRTdHlsZXMgPSBnZXRTdHlsZXMoZWxlbWVudCk7XG4gICAgaWYgKGVsZW1lbnRPZmZzZXRUb3AgLSBlbGVtZW50U3R5bGVzLnNjcm9sbE1hcmdpblRvcCA8IHNjcm9sbENvbnRhaW5lci5zY3JvbGxUb3AgKyBjb250YWluZXJTdHlsZXMuc2Nyb2xsUGFkZGluZ1RvcCkge1xuICAgICAgLy8gb3ZlcmZsb3cgdXB3YXJkcywgYWxpZ24gdG9wIGVkZ2VzXG4gICAgICB0YXJnZXRZID0gZWxlbWVudE9mZnNldFRvcCAtIGVsZW1lbnRTdHlsZXMuc2Nyb2xsTWFyZ2luVG9wIC0gY29udGFpbmVyU3R5bGVzLnNjcm9sbFBhZGRpbmdUb3A7XG4gICAgfSBlbHNlIGlmIChlbGVtZW50T2Zmc2V0VG9wICsgZWxlbWVudC5vZmZzZXRIZWlnaHQgKyBlbGVtZW50U3R5bGVzLnNjcm9sbE1hcmdpbkJvdHRvbSA+IHNjcm9sbENvbnRhaW5lci5zY3JvbGxUb3AgKyBzY3JvbGxDb250YWluZXIuY2xpZW50SGVpZ2h0IC0gY29udGFpbmVyU3R5bGVzLnNjcm9sbFBhZGRpbmdCb3R0b20pIHtcbiAgICAgIC8vIG92ZXJmbG93IGRvd253YXJkcywgYWxpZ24gYm90dG9tIGVkZ2VzXG4gICAgICB0YXJnZXRZID0gZWxlbWVudE9mZnNldFRvcCArIGVsZW1lbnQub2Zmc2V0SGVpZ2h0ICsgZWxlbWVudFN0eWxlcy5zY3JvbGxNYXJnaW5Cb3R0b20gLSBzY3JvbGxDb250YWluZXIuY2xpZW50SGVpZ2h0ICsgY29udGFpbmVyU3R5bGVzLnNjcm9sbFBhZGRpbmdCb3R0b207XG4gICAgfVxuICB9XG4gIHNjcm9sbENvbnRhaW5lci5zY3JvbGxUbyh7XG4gICAgbGVmdDogdGFyZ2V0WCxcbiAgICB0b3A6IHRhcmdldFksXG4gICAgYmVoYXZpb3I6ICdhdXRvJ1xuICB9KTtcbn1cbmZ1bmN0aW9uIGdldE9mZnNldChhbmNlc3RvciwgZWxlbWVudCwgc2lkZSkge1xuICBjb25zdCBwcm9wTmFtZSA9IHNpZGUgPT09ICdsZWZ0JyA/ICdvZmZzZXRMZWZ0JyA6ICdvZmZzZXRUb3AnO1xuICBsZXQgcmVzdWx0ID0gMDtcbiAgd2hpbGUgKGVsZW1lbnQub2Zmc2V0UGFyZW50KSB7XG4gICAgcmVzdWx0ICs9IGVsZW1lbnRbcHJvcE5hbWVdO1xuICAgIGlmIChlbGVtZW50Lm9mZnNldFBhcmVudCA9PT0gYW5jZXN0b3IpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBlbGVtZW50ID0gZWxlbWVudC5vZmZzZXRQYXJlbnQ7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGdldFN0eWxlcyhlbGVtZW50KSB7XG4gIGNvbnN0IHN0eWxlcyA9IGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gIHJldHVybiB7XG4gICAgc2Nyb2xsTWFyZ2luVG9wOiBwYXJzZUZsb2F0KHN0eWxlcy5zY3JvbGxNYXJnaW5Ub3ApIHx8IDAsXG4gICAgc2Nyb2xsTWFyZ2luUmlnaHQ6IHBhcnNlRmxvYXQoc3R5bGVzLnNjcm9sbE1hcmdpblJpZ2h0KSB8fCAwLFxuICAgIHNjcm9sbE1hcmdpbkJvdHRvbTogcGFyc2VGbG9hdChzdHlsZXMuc2Nyb2xsTWFyZ2luQm90dG9tKSB8fCAwLFxuICAgIHNjcm9sbE1hcmdpbkxlZnQ6IHBhcnNlRmxvYXQoc3R5bGVzLnNjcm9sbE1hcmdpbkxlZnQpIHx8IDAsXG4gICAgc2Nyb2xsUGFkZGluZ1RvcDogcGFyc2VGbG9hdChzdHlsZXMuc2Nyb2xsUGFkZGluZ1RvcCkgfHwgMCxcbiAgICBzY3JvbGxQYWRkaW5nUmlnaHQ6IHBhcnNlRmxvYXQoc3R5bGVzLnNjcm9sbFBhZGRpbmdSaWdodCkgfHwgMCxcbiAgICBzY3JvbGxQYWRkaW5nQm90dG9tOiBwYXJzZUZsb2F0KHN0eWxlcy5zY3JvbGxQYWRkaW5nQm90dG9tKSB8fCAwLFxuICAgIHNjcm9sbFBhZGRpbmdMZWZ0OiBwYXJzZUZsb2F0KHN0eWxlcy5zY3JvbGxQYWRkaW5nTGVmdCkgfHwgMFxuICB9O1xufSIsIi8qKlxuICogSW5kaWNhdGVzIGhvdyBtYW55IGRpYWxvZ3MgYXJlIG5lc3RlZCB3aXRoaW4uXG4gKiBAdHlwZSB7bnVtYmVyfVxuICovXG5leHBvcnQgY29uc3QgbmVzdGVkRGlhbG9ncyA9ICctLW5lc3RlZC1kaWFsb2dzJzsiLCJpbXBvcnQgeyBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBvcGVuID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgYmVnaW5zIGFuaW1hdGluZyBpbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHN0YXJ0aW5nU3R5bGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGU7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGlzIGFuaW1hdGluZyBvdXQuXG4gKi9cbmV4cG9ydCBjb25zdCBlbmRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGlzIG5lc3RlZCB3aXRoaW4gYW5vdGhlciBkaWFsb2cuXG4gKi9cbmV4cG9ydCBjb25zdCBuZXN0ZWQgPSAnZGF0YS1uZXN0ZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBoYXMgb3RoZXIgb3BlbiBkaWFsb2dzIG5lc3RlZCB3aXRoaW4gaXQuXG4gKi9cbmV4cG9ydCBjb25zdCBuZXN0ZWREaWFsb2dPcGVuID0gJ2RhdGEtbmVzdGVkLWRpYWxvZy1vcGVuJzsiLCJpbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHBvcHVwU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuaW1wb3J0ICogYXMgRGlhbG9nUG9wdXBEYXRhQXR0cmlidXRlcyBmcm9tIFwiLi4vcG9wdXAvRGlhbG9nUG9wdXBEYXRhQXR0cmlidXRlcy5tanNcIjtcblxuLyoqXG4gKiBTaGFyZWQgYnkgYERpYWxvZy5Qb3B1cGAgYW5kIGBEaWFsb2cuVmlld3BvcnRgLCB3aG9zZSBzdGF0ZXMgaGF2ZSB0aGUgc2FtZSBzaGFwZS5cbiAqIGBuZXN0ZWRgIGlzIG5vdCBtYXBwZWQ6IHVubWFwcGVkIGB0cnVlYCBib29sZWFucyBhbHJlYWR5IHJlbmRlciBhcyBgZGF0YS1uZXN0ZWRgLlxuICovXG5leHBvcnQgY29uc3QgZGlhbG9nU3RhdGVBdHRyaWJ1dGVzTWFwcGluZyA9IHtcbiAgLi4ucG9wdXBTdGF0ZU1hcHBpbmcsXG4gIC4uLnRyYW5zaXRpb25TdGF0dXNNYXBwaW5nLFxuICBuZXN0ZWREaWFsb2dPcGVuKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlID8ge1xuICAgICAgW0RpYWxvZ1BvcHVwRGF0YUF0dHJpYnV0ZXMubmVzdGVkRGlhbG9nT3Blbl06ICcnXG4gICAgfSA6IG51bGw7XG4gIH1cbn07IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBGbG9hdGluZ0ZvY3VzTWFuYWdlciB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9pbmRleC5tanNcIjtcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlhbG9nUG9ydGFsQ29udGV4dCB9IGZyb20gXCIuLi9wb3J0YWwvRGlhbG9nUG9ydGFsQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlT3BlbkNoYW5nZUNvbXBsZXRlLm1qc1wiO1xuaW1wb3J0IHsgQ09NUE9TSVRFX0tFWVMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbXBvc2l0ZS9jb21wb3NpdGUubWpzXCI7XG5pbXBvcnQgeyBGT0NVU0FCTEVfUE9QVVBfUFJPUFMsIGNyZWF0ZURlZmF1bHRJbml0aWFsRm9jdXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuaW1wb3J0ICogYXMgRGlhbG9nUG9wdXBDc3NWYXJzIGZyb20gXCIuL0RpYWxvZ1BvcHVwQ3NzVmFycy5tanNcIjtcbmltcG9ydCB7IGRpYWxvZ1N0YXRlQXR0cmlidXRlc01hcHBpbmcgfSBmcm9tIFwiLi4vdXRpbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBBIGNvbnRhaW5lciBmb3IgdGhlIGRpYWxvZyBjb250ZW50cy5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgRGlhbG9nXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvZGlhbG9nKVxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IERpYWxvZ1BvcHVwID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nUG9wdXAoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBmaW5hbEZvY3VzLFxuICAgIGluaXRpYWxGb2N1cyxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IGRlc2NyaXB0aW9uRWxlbWVudElkID0gc3RvcmUudXNlU3RhdGUoJ2Rlc2NyaXB0aW9uRWxlbWVudElkJyk7XG4gIGNvbnN0IGRpc2FibGVQb2ludGVyRGlzbWlzc2FsID0gc3RvcmUudXNlU3RhdGUoJ2Rpc2FibGVQb2ludGVyRGlzbWlzc2FsJyk7XG4gIGNvbnN0IGZsb2F0aW5nUm9vdENvbnRleHQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdSb290Q29udGV4dCcpO1xuICBjb25zdCByb290UG9wdXBQcm9wcyA9IHN0b3JlLnVzZVN0YXRlKCdwb3B1cFByb3BzJyk7XG4gIGNvbnN0IG1vZGFsID0gc3RvcmUudXNlU3RhdGUoJ21vZGFsJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBuZXN0ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbmVzdGVkJyk7XG4gIGNvbnN0IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA9IHN0b3JlLnVzZVN0YXRlKCduZXN0ZWRPcGVuRGlhbG9nQ291bnQnKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG9wZW5NZXRob2QgPSBzdG9yZS51c2VTdGF0ZSgnb3Blbk1ldGhvZCcpO1xuICBjb25zdCB0aXRsZUVsZW1lbnRJZCA9IHN0b3JlLnVzZVN0YXRlKCd0aXRsZUVsZW1lbnRJZCcpO1xuICBjb25zdCB0cmFuc2l0aW9uU3RhdHVzID0gc3RvcmUudXNlU3RhdGUoJ3RyYW5zaXRpb25TdGF0dXMnKTtcbiAgY29uc3Qgcm9sZSA9IHN0b3JlLnVzZVN0YXRlKCdyb2xlJyk7XG4gIGNvbnN0IGZsb2F0aW5nSWQgPSBmbG9hdGluZ1Jvb3RDb250ZXh0LnVzZVN0YXRlKCdmbG9hdGluZ0lkJyk7XG4gIHVzZURpYWxvZ1BvcnRhbENvbnRleHQoKTtcbiAgdXNlT3BlbkNoYW5nZUNvbXBsZXRlKHtcbiAgICBvcGVuLFxuICAgIHJlZjogc3RvcmUuY29udGV4dC5wb3B1cFJlZixcbiAgICBvbkNvbXBsZXRlKCkge1xuICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgc3RvcmUuY29udGV4dC5vbk9wZW5DaGFuZ2VDb21wbGV0ZT8uKHRydWUpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHJlc29sdmVkSW5pdGlhbEZvY3VzID0gaW5pdGlhbEZvY3VzID09PSB1bmRlZmluZWQgPyBjcmVhdGVEZWZhdWx0SW5pdGlhbEZvY3VzKHN0b3JlLmNvbnRleHQucG9wdXBSZWYpIDogaW5pdGlhbEZvY3VzO1xuICBjb25zdCBuZXN0ZWREaWFsb2dPcGVuID0gbmVzdGVkT3BlbkRpYWxvZ0NvdW50ID4gMDtcbiAgY29uc3Qgc2V0UG9wdXBFbGVtZW50ID0gc3RvcmUudXNlU3RhdGVTZXR0ZXIoJ3BvcHVwRWxlbWVudCcpO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBvcGVuLFxuICAgIG5lc3RlZCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzLFxuICAgIG5lc3RlZERpYWxvZ09wZW5cbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcHJvcHM6IFtyb290UG9wdXBQcm9wcywge1xuICAgICAgaWQ6IGZsb2F0aW5nSWQsXG4gICAgICAnYXJpYS1sYWJlbGxlZGJ5JzogdGl0bGVFbGVtZW50SWQsXG4gICAgICAnYXJpYS1kZXNjcmliZWRieSc6IGRlc2NyaXB0aW9uRWxlbWVudElkLFxuICAgICAgcm9sZSxcbiAgICAgIC4uLkZPQ1VTQUJMRV9QT1BVUF9QUk9QUyxcbiAgICAgIGhpZGRlbjogIW1vdW50ZWQsXG4gICAgICBvbktleURvd24oZXZlbnQpIHtcbiAgICAgICAgaWYgKENPTVBPU0lURV9LRVlTLmhhcyhldmVudC5rZXkpKSB7XG4gICAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBzdHlsZToge1xuICAgICAgICBbRGlhbG9nUG9wdXBDc3NWYXJzLm5lc3RlZERpYWxvZ3NdOiBuZXN0ZWRPcGVuRGlhbG9nQ291bnRcbiAgICAgIH1cbiAgICB9LCBlbGVtZW50UHJvcHNdLFxuICAgIHJlZjogW2ZvcndhcmRlZFJlZiwgc3RvcmUuY29udGV4dC5wb3B1cFJlZiwgc2V0UG9wdXBFbGVtZW50XSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBkaWFsb2dTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nXG4gIH0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goRmxvYXRpbmdGb2N1c01hbmFnZXIsIHtcbiAgICBjb250ZXh0OiBmbG9hdGluZ1Jvb3RDb250ZXh0LFxuICAgIG9wZW5JbnRlcmFjdGlvblR5cGU6IG9wZW5NZXRob2QsXG4gICAgZGlzYWJsZWQ6ICFtb3VudGVkLFxuICAgIGNsb3NlT25Gb2N1c091dDogIWRpc2FibGVQb2ludGVyRGlzbWlzc2FsLFxuICAgIGluaXRpYWxGb2N1czogcmVzb2x2ZWRJbml0aWFsRm9jdXMsXG4gICAgcmV0dXJuRm9jdXM6IGZpbmFsRm9jdXMsXG4gICAgbW9kYWw6IG1vZGFsICE9PSBmYWxzZSxcbiAgICByZXN0b3JlRm9jdXM6IFwicG9wdXBcIixcbiAgICBjaGlsZHJlbjogZWxlbWVudFxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nUG9wdXAuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1BvcHVwXCI7IiwiaW1wb3J0IHsgaXNSZWFjdFZlcnNpb25BdExlYXN0IH0gZnJvbSBcIi4vcmVhY3RWZXJzaW9uLm1qc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIGluZXJ0VmFsdWUodmFsdWUpIHtcbiAgaWYgKGlzUmVhY3RWZXJzaW9uQXRMZWFzdCgxOSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgLy8gY29tcGF0aWJpbGl0eSB3aXRoIFJlYWN0IDwgMTlcbiAgcmV0dXJuIHZhbHVlID8gJ3RydWUnIDogdW5kZWZpbmVkO1xufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBJbnRlcm5hbEJhY2tkcm9wID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gSW50ZXJuYWxCYWNrZHJvcChwcm9wcywgcmVmKSB7XG4gIGNvbnN0IHtcbiAgICBjdXRvdXQsXG4gICAgLi4ub3RoZXJQcm9wc1xuICB9ID0gcHJvcHM7XG4gIGxldCBjbGlwUGF0aDtcbiAgaWYgKGN1dG91dCkge1xuICAgIGNvbnN0IHJlY3QgPSBjdXRvdXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY2xpcFBhdGggPSBgcG9seWdvbigwJSAwJSwxMDAlIDAlLDEwMCUgMTAwJSwwJSAxMDAlLDAlIDAlLCR7cmVjdC5sZWZ0fXB4ICR7cmVjdC50b3B9cHgsJHtyZWN0LmxlZnR9cHggJHtyZWN0LmJvdHRvbX1weCwke3JlY3QucmlnaHR9cHggJHtyZWN0LmJvdHRvbX1weCwke3JlY3QucmlnaHR9cHggJHtyZWN0LnRvcH1weCwke3JlY3QubGVmdH1weCAke3JlY3QudG9wfXB4KWA7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFwiZGl2XCIsIHtcbiAgICByZWY6IHJlZixcbiAgICByb2xlOiBcInByZXNlbnRhdGlvblwiXG4gICAgLy8gRW5zdXJlcyBGbG9hdGluZyBVSSdzIG91dHNpZGUgcHJlc3MgZGV0ZWN0aW9uIHJ1bnMsIGFzIGl0IGNvbnNpZGVyc1xuICAgIC8vIGl0IGFuIGVsZW1lbnQgdGhhdCBleGlzdGVkIHdoZW4gdGhlIHBvcHVwIHJlbmRlcmVkLlxuICAgICxcbiAgICBcImRhdGEtYmFzZS11aS1pbmVydFwiOiBcIlwiLFxuICAgIC4uLm90aGVyUHJvcHMsXG4gICAgc3R5bGU6IHtcbiAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgaW5zZXQ6IDAsXG4gICAgICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICBXZWJraXRVc2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICBjbGlwUGF0aFxuICAgIH1cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEludGVybmFsQmFja2Ryb3AuZGlzcGxheU5hbWUgPSBcIkludGVybmFsQmFja2Ryb3BcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGluZXJ0VmFsdWUgfSBmcm9tICdAYmFzZS11aS91dGlscy9pbmVydFZhbHVlJztcbmltcG9ydCB7IEZsb2F0aW5nUG9ydGFsIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IERpYWxvZ1BvcnRhbENvbnRleHQgfSBmcm9tIFwiLi9EaWFsb2dQb3J0YWxDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgSW50ZXJuYWxCYWNrZHJvcCB9IGZyb20gXCIuLi8uLi91dGlscy9JbnRlcm5hbEJhY2tkcm9wLm1qc1wiO1xuXG4vKipcbiAqIEEgcG9ydGFsIGVsZW1lbnQgdGhhdCBtb3ZlcyB0aGUgcG9wdXAgdG8gYSBkaWZmZXJlbnQgcGFydCBvZiB0aGUgRE9NLlxuICogQnkgZGVmYXVsdCwgdGhlIHBvcnRhbCBlbGVtZW50IGlzIGFwcGVuZGVkIHRvIGA8Ym9keT5gLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgRGlhbG9nUG9ydGFsID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nUG9ydGFsKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGtlZXBNb3VudGVkID0gZmFsc2UsXG4gICAgLi4ucG9ydGFsUHJvcHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBtb2RhbCA9IHN0b3JlLnVzZVN0YXRlKCdtb2RhbCcpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3Qgc2hvdWxkUmVuZGVyID0gbW91bnRlZCB8fCBrZWVwTW91bnRlZDtcbiAgaWYgKCFzaG91bGRSZW5kZXIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goRGlhbG9nUG9ydGFsQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBrZWVwTW91bnRlZCxcbiAgICBjaGlsZHJlbjogLyojX19QVVJFX18qL19qc3hzKEZsb2F0aW5nUG9ydGFsLCB7XG4gICAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAgIC4uLnBvcnRhbFByb3BzLFxuICAgICAgY2hpbGRyZW46IFttb3VudGVkICYmIG1vZGFsID09PSB0cnVlICYmIC8qI19fUFVSRV9fKi9fanN4KEludGVybmFsQmFja2Ryb3AsIHtcbiAgICAgICAgcmVmOiBzdG9yZS5jb250ZXh0LmludGVybmFsQmFja2Ryb3BSZWYsXG4gICAgICAgIGluZXJ0OiBpbmVydFZhbHVlKCFvcGVuKVxuICAgICAgfSksIHByb3BzLmNoaWxkcmVuXVxuICAgIH0pXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dQb3J0YWwuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1BvcnRhbFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgaXNPdmVyZmxvd0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tIFwiLi9hZGRFdmVudExpc3RlbmVyLm1qc1wiO1xuaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tIFwiLi9wbGF0Zm9ybS9pbmRleC5tanNcIjtcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQsIG93bmVyV2luZG93IH0gZnJvbSBcIi4vb3duZXIubWpzXCI7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi91c2VJc29MYXlvdXRFZmZlY3QubWpzXCI7XG5pbXBvcnQgeyBUaW1lb3V0IH0gZnJvbSBcIi4vdXNlVGltZW91dC5tanNcIjtcbmltcG9ydCB7IEFuaW1hdGlvbkZyYW1lIH0gZnJvbSBcIi4vdXNlQW5pbWF0aW9uRnJhbWUubWpzXCI7XG5sZXQgb3JpZ2luYWxIdG1sU3R5bGVzID0ge307XG5sZXQgb3JpZ2luYWxCb2R5U3R5bGVzID0ge307XG5sZXQgb3JpZ2luYWxIdG1sU2Nyb2xsQmVoYXZpb3IgPSAnJztcblxuLy8gVGhlIHZpZXdwb3J0J3Mgb3ZlcmZsb3cgY29tZXMgZnJvbSA8aHRtbD4gd2hlbiBpdCBlc3RhYmxpc2hlcyBpdHMgb3duIHNjcm9sbCBjb250YWluZXIsIGFuZFxuLy8gcHJvcGFnYXRlcyBmcm9tIDxib2R5PiBvdGhlcndpc2UuIEFuIGBvdmVyZmxvd2Agc3R5bGUgb24gdGhlIG90aGVyIGVsZW1lbnQgZG9lc24ndCBsb2NrIHRoZSBwYWdlLlxuZnVuY3Rpb24gZ2V0Vmlld3BvcnRTY3JvbGxlcihodG1sLCBib2R5KSB7XG4gIHJldHVybiBpc092ZXJmbG93RWxlbWVudChodG1sKSA/IGh0bWwgOiBib2R5O1xufVxuZnVuY3Rpb24gaXNQYWdlU2Nyb2xsTG9ja2VkKHdpbiwgaHRtbCwgYm9keSkge1xuICByZXR1cm4gL2hpZGRlbnxjbGlwLy50ZXN0KHdpbi5nZXRDb21wdXRlZFN0eWxlKGdldFZpZXdwb3J0U2Nyb2xsZXIoaHRtbCwgYm9keSkpLm92ZXJmbG93WSk7XG59XG5mdW5jdGlvbiBoYXNJbnNldFNjcm9sbGJhcnMocmVmZXJlbmNlRWxlbWVudCkge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhkb2MpO1xuICByZXR1cm4gd2luLmlubmVyV2lkdGggLSBkb2MuZG9jdW1lbnRFbGVtZW50LmNsaWVudFdpZHRoID4gMDtcbn1cbmZ1bmN0aW9uIHN1cHBvcnRzU3RhYmxlU2Nyb2xsYmFyR3V0dGVyKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgY29uc3Qgc3VwcG9ydGVkID0gdHlwZW9mIENTUyAhPT0gJ3VuZGVmaW5lZCcgJiYgQ1NTLnN1cHBvcnRzICYmIENTUy5zdXBwb3J0cygnc2Nyb2xsYmFyLWd1dHRlcicsICdzdGFibGUnKTtcbiAgaWYgKCFzdXBwb3J0ZWQgfHwgdHlwZW9mIGRvY3VtZW50ID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICBjb25zdCBodG1sID0gZG9jLmRvY3VtZW50RWxlbWVudDtcbiAgY29uc3QgYm9keSA9IGRvYy5ib2R5O1xuICBjb25zdCBzY3JvbGxDb250YWluZXIgPSBnZXRWaWV3cG9ydFNjcm9sbGVyKGh0bWwsIGJvZHkpO1xuICBjb25zdCBvcmlnaW5hbFNjcm9sbENvbnRhaW5lck92ZXJmbG93WSA9IHNjcm9sbENvbnRhaW5lci5zdHlsZS5vdmVyZmxvd1k7XG4gIGNvbnN0IG9yaWdpbmFsSHRtbFN0eWxlR3V0dGVyID0gaHRtbC5zdHlsZS5zY3JvbGxiYXJHdXR0ZXI7XG4gIGh0bWwuc3R5bGUuc2Nyb2xsYmFyR3V0dGVyID0gJ3N0YWJsZSc7XG4gIHNjcm9sbENvbnRhaW5lci5zdHlsZS5vdmVyZmxvd1kgPSAnc2Nyb2xsJztcbiAgY29uc3QgYmVmb3JlID0gc2Nyb2xsQ29udGFpbmVyLm9mZnNldFdpZHRoO1xuICBzY3JvbGxDb250YWluZXIuc3R5bGUub3ZlcmZsb3dZID0gJ2hpZGRlbic7XG4gIGNvbnN0IGFmdGVyID0gc2Nyb2xsQ29udGFpbmVyLm9mZnNldFdpZHRoO1xuICBzY3JvbGxDb250YWluZXIuc3R5bGUub3ZlcmZsb3dZID0gb3JpZ2luYWxTY3JvbGxDb250YWluZXJPdmVyZmxvd1k7XG4gIGh0bWwuc3R5bGUuc2Nyb2xsYmFyR3V0dGVyID0gb3JpZ2luYWxIdG1sU3R5bGVHdXR0ZXI7XG4gIHJldHVybiBiZWZvcmUgPT09IGFmdGVyO1xufVxuZnVuY3Rpb24gcHJldmVudFNjcm9sbE92ZXJsYXlTY3JvbGxiYXJzKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KTtcbiAgY29uc3QgaHRtbCA9IGRvYy5kb2N1bWVudEVsZW1lbnQ7XG4gIGNvbnN0IGJvZHkgPSBkb2MuYm9keTtcblxuICAvLyBJZiBhbiBgb3ZlcmZsb3dgIHN0eWxlIGlzIHByZXNlbnQgb24gPGh0bWw+LCB3ZSBuZWVkIHRvIGxvY2sgaXQsIGJlY2F1c2UgYSBsb2NrIG9uIDxib2R5PlxuICAvLyB3b24ndCBoYXZlIGFueSBlZmZlY3QuXG4gIC8vIEJ1dCBpZiA8Ym9keT4gaGFzIGFuIGBvdmVyZmxvd2Agc3R5bGUgKGxpa2UgYG92ZXJmbG93LXg6IGhpZGRlbmApLCB3ZSBuZWVkIHRvIGxvY2sgaXRcbiAgLy8gaW5zdGVhZCwgYXMgc3RpY2t5IGVsZW1lbnRzIHNoaWZ0IG90aGVyd2lzZS5cbiAgY29uc3QgZWxlbWVudFRvTG9jayA9IGdldFZpZXdwb3J0U2Nyb2xsZXIoaHRtbCwgYm9keSk7XG4gIGNvbnN0IG9yaWdpbmFsRWxlbWVudFRvTG9ja1N0eWxlcyA9IHtcbiAgICBvdmVyZmxvd1k6IGVsZW1lbnRUb0xvY2suc3R5bGUub3ZlcmZsb3dZLFxuICAgIG92ZXJmbG93WDogZWxlbWVudFRvTG9jay5zdHlsZS5vdmVyZmxvd1hcbiAgfTtcbiAgT2JqZWN0LmFzc2lnbihlbGVtZW50VG9Mb2NrLnN0eWxlLCB7XG4gICAgb3ZlcmZsb3dZOiAnaGlkZGVuJyxcbiAgICBvdmVyZmxvd1g6ICdoaWRkZW4nXG4gIH0pO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIE9iamVjdC5hc3NpZ24oZWxlbWVudFRvTG9jay5zdHlsZSwgb3JpZ2luYWxFbGVtZW50VG9Mb2NrU3R5bGVzKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIHByZXZlbnRTY3JvbGxJbnNldFNjcm9sbGJhcnMocmVmZXJlbmNlRWxlbWVudCkge1xuICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICBjb25zdCBodG1sID0gZG9jLmRvY3VtZW50RWxlbWVudDtcbiAgY29uc3QgYm9keSA9IGRvYy5ib2R5O1xuICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhodG1sKTtcbiAgbGV0IHNjcm9sbFRvcCA9IDA7XG4gIGxldCBzY3JvbGxMZWZ0ID0gMDtcbiAgbGV0IHVwZGF0ZUd1dHRlck9ubHkgPSBmYWxzZTtcbiAgY29uc3QgcmVzaXplRnJhbWUgPSBBbmltYXRpb25GcmFtZS5jcmVhdGUoKTtcblxuICAvLyBQaW5jaC16b29tIGluIFNhZmFyaSBjYXVzZXMgYSBzaGlmdC4gSnVzdCBkb24ndCBsb2NrIHNjcm9sbCBpZiB0aGVyZSdzIGFueSBwaW5jaC16b29tLlxuICBpZiAocGxhdGZvcm0uZW5naW5lLndlYmtpdCAmJiAod2luLnZpc3VhbFZpZXdwb3J0Py5zY2FsZSA/PyAxKSAhPT0gMSkge1xuICAgIHJldHVybiAoKSA9PiB7fTtcbiAgfVxuICBmdW5jdGlvbiBsb2NrU2Nyb2xsKCkge1xuICAgIC8qIERPTSByZWFkczogKi9cblxuICAgIGNvbnN0IGh0bWxTdHlsZXMgPSB3aW4uZ2V0Q29tcHV0ZWRTdHlsZShodG1sKTtcbiAgICBjb25zdCBib2R5U3R5bGVzID0gd2luLmdldENvbXB1dGVkU3R5bGUoYm9keSk7XG4gICAgY29uc3QgaHRtbFNjcm9sbGJhckd1dHRlclZhbHVlID0gaHRtbFN0eWxlcy5zY3JvbGxiYXJHdXR0ZXIgfHwgJyc7XG4gICAgY29uc3QgaGFzQm90aEVkZ2VzID0gaHRtbFNjcm9sbGJhckd1dHRlclZhbHVlLmluY2x1ZGVzKCdib3RoLWVkZ2VzJyk7XG4gICAgY29uc3Qgc2Nyb2xsYmFyR3V0dGVyVmFsdWUgPSBoYXNCb3RoRWRnZXMgPyAnc3RhYmxlIGJvdGgtZWRnZXMnIDogJ3N0YWJsZSc7XG4gICAgc2Nyb2xsVG9wID0gaHRtbC5zY3JvbGxUb3A7XG4gICAgc2Nyb2xsTGVmdCA9IGh0bWwuc2Nyb2xsTGVmdDtcbiAgICBvcmlnaW5hbEh0bWxTdHlsZXMgPSB7XG4gICAgICBzY3JvbGxiYXJHdXR0ZXI6IGh0bWwuc3R5bGUuc2Nyb2xsYmFyR3V0dGVyLFxuICAgICAgb3ZlcmZsb3dZOiBodG1sLnN0eWxlLm92ZXJmbG93WSxcbiAgICAgIG92ZXJmbG93WDogaHRtbC5zdHlsZS5vdmVyZmxvd1hcbiAgICB9O1xuICAgIG9yaWdpbmFsSHRtbFNjcm9sbEJlaGF2aW9yID0gaHRtbC5zdHlsZS5zY3JvbGxCZWhhdmlvcjtcbiAgICBvcmlnaW5hbEJvZHlTdHlsZXMgPSB7XG4gICAgICBwb3NpdGlvbjogYm9keS5zdHlsZS5wb3NpdGlvbixcbiAgICAgIGhlaWdodDogYm9keS5zdHlsZS5oZWlnaHQsXG4gICAgICB3aWR0aDogYm9keS5zdHlsZS53aWR0aCxcbiAgICAgIGJveFNpemluZzogYm9keS5zdHlsZS5ib3hTaXppbmcsXG4gICAgICBvdmVyZmxvd1k6IGJvZHkuc3R5bGUub3ZlcmZsb3dZLFxuICAgICAgb3ZlcmZsb3dYOiBib2R5LnN0eWxlLm92ZXJmbG93WCxcbiAgICAgIHNjcm9sbEJlaGF2aW9yOiBib2R5LnN0eWxlLnNjcm9sbEJlaGF2aW9yXG4gICAgfTtcbiAgICBjb25zdCBpc1Njcm9sbGFibGVZID0gaHRtbC5zY3JvbGxIZWlnaHQgPiBodG1sLmNsaWVudEhlaWdodDtcbiAgICBjb25zdCBpc1Njcm9sbGFibGVYID0gaHRtbC5zY3JvbGxXaWR0aCA+IGh0bWwuY2xpZW50V2lkdGg7XG4gICAgY29uc3QgaGFzQ29uc3RhbnRPdmVyZmxvd1kgPSBodG1sU3R5bGVzLm92ZXJmbG93WSA9PT0gJ3Njcm9sbCcgfHwgYm9keVN0eWxlcy5vdmVyZmxvd1kgPT09ICdzY3JvbGwnO1xuICAgIGNvbnN0IGhhc0NvbnN0YW50T3ZlcmZsb3dYID0gaHRtbFN0eWxlcy5vdmVyZmxvd1ggPT09ICdzY3JvbGwnIHx8IGJvZHlTdHlsZXMub3ZlcmZsb3dYID09PSAnc2Nyb2xsJztcblxuICAgIC8vIFZhbHVlcyBjYW4gYmUgbmVnYXRpdmUgaW4gRmlyZWZveFxuICAgIGNvbnN0IHNjcm9sbGJhcldpZHRoID0gTWF0aC5tYXgoMCwgd2luLmlubmVyV2lkdGggLSBib2R5LmNsaWVudFdpZHRoKTtcbiAgICBjb25zdCBzY3JvbGxiYXJIZWlnaHQgPSBNYXRoLm1heCgwLCB3aW4uaW5uZXJIZWlnaHQgLSBib2R5LmNsaWVudEhlaWdodCk7XG5cbiAgICAvLyBBdm9pZCBzaGlmdCBkdWUgdG8gdGhlIGRlZmF1bHQgPGJvZHk+IG1hcmdpbi4gVGhpcyBkb2VzIGNhdXNlIGVsZW1lbnRzIHRvIGJlIGNsaXBwZWRcbiAgICAvLyB3aXRoIHdoaXRlc3BhY2UuIFdhcm4gaWYgPGJvZHk+IGhhcyBtYXJnaW5zP1xuICAgIGNvbnN0IG1hcmdpblkgPSBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luVG9wKSArIHBhcnNlRmxvYXQoYm9keVN0eWxlcy5tYXJnaW5Cb3R0b20pO1xuICAgIGNvbnN0IG1hcmdpblggPSBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luTGVmdCkgKyBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luUmlnaHQpO1xuICAgIGNvbnN0IGVsZW1lbnRUb0xvY2sgPSBnZXRWaWV3cG9ydFNjcm9sbGVyKGh0bWwsIGJvZHkpO1xuICAgIHVwZGF0ZUd1dHRlck9ubHkgPSBzdXBwb3J0c1N0YWJsZVNjcm9sbGJhckd1dHRlcihyZWZlcmVuY2VFbGVtZW50KTtcblxuICAgIC8qXG4gICAgICogRE9NIHdyaXRlczpcbiAgICAgKiBEbyBub3QgcmVhZCB0aGUgRE9NIHBhc3QgdGhpcyBwb2ludCFcbiAgICAgKi9cblxuICAgIGlmICh1cGRhdGVHdXR0ZXJPbmx5KSB7XG4gICAgICBodG1sLnN0eWxlLnNjcm9sbGJhckd1dHRlciA9IHNjcm9sbGJhckd1dHRlclZhbHVlO1xuICAgICAgZWxlbWVudFRvTG9jay5zdHlsZS5vdmVyZmxvd1kgPSAnaGlkZGVuJztcbiAgICAgIGVsZW1lbnRUb0xvY2suc3R5bGUub3ZlcmZsb3dYID0gJ2hpZGRlbic7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIE9iamVjdC5hc3NpZ24oaHRtbC5zdHlsZSwge1xuICAgICAgc2Nyb2xsYmFyR3V0dGVyOiBzY3JvbGxiYXJHdXR0ZXJWYWx1ZSxcbiAgICAgIG92ZXJmbG93WTogJ2hpZGRlbicsXG4gICAgICBvdmVyZmxvd1g6ICdoaWRkZW4nXG4gICAgfSk7XG4gICAgaWYgKGlzU2Nyb2xsYWJsZVkgfHwgaGFzQ29uc3RhbnRPdmVyZmxvd1kpIHtcbiAgICAgIGh0bWwuc3R5bGUub3ZlcmZsb3dZID0gJ3Njcm9sbCc7XG4gICAgfVxuICAgIGlmIChpc1Njcm9sbGFibGVYIHx8IGhhc0NvbnN0YW50T3ZlcmZsb3dYKSB7XG4gICAgICBodG1sLnN0eWxlLm92ZXJmbG93WCA9ICdzY3JvbGwnO1xuICAgIH1cbiAgICBPYmplY3QuYXNzaWduKGJvZHkuc3R5bGUsIHtcbiAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgaGVpZ2h0OiBtYXJnaW5ZIHx8IHNjcm9sbGJhckhlaWdodCA/IGBjYWxjKDEwMGR2aCAtICR7bWFyZ2luWSArIHNjcm9sbGJhckhlaWdodH1weClgIDogJzEwMGR2aCcsXG4gICAgICB3aWR0aDogbWFyZ2luWCB8fCBzY3JvbGxiYXJXaWR0aCA/IGBjYWxjKDEwMHZ3IC0gJHttYXJnaW5YICsgc2Nyb2xsYmFyV2lkdGh9cHgpYCA6ICcxMDB2dycsXG4gICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgIC8vIEFzc2lnbiB0aGUgbG9uZ2hhbmRzIHRoYXQgYGNsZWFudXBgIHJlc3RvcmVzLCBzbyBub3RoaW5nIGlzIGxlZnQgYmVoaW5kLlxuICAgICAgb3ZlcmZsb3dZOiAnaGlkZGVuJyxcbiAgICAgIG92ZXJmbG93WDogJ2hpZGRlbicsXG4gICAgICBzY3JvbGxCZWhhdmlvcjogJ3Vuc2V0J1xuICAgIH0pO1xuICAgIGJvZHkuc2Nyb2xsVG9wID0gc2Nyb2xsVG9wO1xuICAgIGJvZHkuc2Nyb2xsTGVmdCA9IHNjcm9sbExlZnQ7XG4gICAgaHRtbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtYmFzZS11aS1zY3JvbGwtbG9ja2VkJywgJycpO1xuICAgIGh0bWwuc3R5bGUuc2Nyb2xsQmVoYXZpb3IgPSAndW5zZXQnO1xuICB9XG4gIGZ1bmN0aW9uIGNsZWFudXAoKSB7XG4gICAgT2JqZWN0LmFzc2lnbihodG1sLnN0eWxlLCBvcmlnaW5hbEh0bWxTdHlsZXMpO1xuICAgIE9iamVjdC5hc3NpZ24oYm9keS5zdHlsZSwgb3JpZ2luYWxCb2R5U3R5bGVzKTtcbiAgICBpZiAoIXVwZGF0ZUd1dHRlck9ubHkpIHtcbiAgICAgIGh0bWwuc2Nyb2xsVG9wID0gc2Nyb2xsVG9wO1xuICAgICAgaHRtbC5zY3JvbGxMZWZ0ID0gc2Nyb2xsTGVmdDtcbiAgICAgIGh0bWwucmVtb3ZlQXR0cmlidXRlKCdkYXRhLWJhc2UtdWktc2Nyb2xsLWxvY2tlZCcpO1xuICAgICAgaHRtbC5zdHlsZS5zY3JvbGxCZWhhdmlvciA9IG9yaWdpbmFsSHRtbFNjcm9sbEJlaGF2aW9yO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVSZXNpemUoKSB7XG4gICAgY2xlYW51cCgpO1xuICAgIHJlc2l6ZUZyYW1lLnJlcXVlc3QobG9ja1Njcm9sbCk7XG4gIH1cbiAgbG9ja1Njcm9sbCgpO1xuICBjb25zdCB1bnN1YnNjcmliZVJlc2l6ZSA9IGFkZEV2ZW50TGlzdGVuZXIod2luLCAncmVzaXplJywgaGFuZGxlUmVzaXplKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICByZXNpemVGcmFtZS5jYW5jZWwoKTtcbiAgICBjbGVhbnVwKCk7XG4gICAgLy8gU29tZXRpbWVzIHRoaXMgY2xlYW51cCBjYW4gcnVuIGFmdGVyIHRlc3QgdGVhcmRvd24gYmVjYXVzZSBpdCBpcyBjYWxsZWRcbiAgICAvLyBpbiBhIGBzZXRUaW1lb3V0KGZuLCAwKWAuIEd1YXJkIHRoZSByZXR1cm5lZCBjbGVhbnVwIHRvIGF2b2lkIGNhbGxpbmdcbiAgICAvLyBgcmVtb3ZlRXZlbnRMaXN0ZW5lcmAgd2hlbiBpdCBpcyBubyBsb25nZXIgYXZhaWxhYmxlIGluIHRlc3RzLlxuICAgIGlmICh0eXBlb2Ygd2luLnJlbW92ZUV2ZW50TGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHVuc3Vic2NyaWJlUmVzaXplKCk7XG4gICAgfVxuICB9O1xufVxuY2xhc3MgU2Nyb2xsTG9ja2VyIHtcbiAgbG9ja0NvdW50ID0gMDtcbiAgcmVzdG9yZSA9IG51bGw7XG4gIHRpbWVvdXRMb2NrID0gVGltZW91dC5jcmVhdGUoKTtcbiAgdGltZW91dFVubG9jayA9IFRpbWVvdXQuY3JlYXRlKCk7XG4gIGFjcXVpcmUocmVmZXJlbmNlRWxlbWVudCkge1xuICAgIHRoaXMubG9ja0NvdW50ICs9IDE7XG4gICAgaWYgKHRoaXMubG9ja0NvdW50ID09PSAxICYmIHRoaXMucmVzdG9yZSA9PT0gbnVsbCkge1xuICAgICAgdGhpcy50aW1lb3V0TG9jay5zdGFydCgwLCAoKSA9PiB0aGlzLmxvY2socmVmZXJlbmNlRWxlbWVudCkpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yZWxlYXNlO1xuICB9XG4gIHJlbGVhc2UgPSAoKSA9PiB7XG4gICAgdGhpcy5sb2NrQ291bnQgLT0gMTtcbiAgICBpZiAodGhpcy5sb2NrQ291bnQgPT09IDAgJiYgdGhpcy5yZXN0b3JlKSB7XG4gICAgICB0aGlzLnRpbWVvdXRVbmxvY2suc3RhcnQoMCwgdGhpcy51bmxvY2spO1xuICAgIH1cbiAgfTtcbiAgdW5sb2NrID0gKCkgPT4ge1xuICAgIGlmICh0aGlzLmxvY2tDb3VudCA9PT0gMCAmJiB0aGlzLnJlc3RvcmUpIHtcbiAgICAgIHRoaXMucmVzdG9yZT8uKCk7XG4gICAgICB0aGlzLnJlc3RvcmUgPSBudWxsO1xuICAgIH1cbiAgfTtcbiAgbG9jayhyZWZlcmVuY2VFbGVtZW50KSB7XG4gICAgaWYgKHRoaXMubG9ja0NvdW50ID09PSAwIHx8IHRoaXMucmVzdG9yZSAhPT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICAgIGNvbnN0IGh0bWwgPSBkb2MuZG9jdW1lbnRFbGVtZW50O1xuICAgIGNvbnN0IGJvZHkgPSBkb2MuYm9keTtcbiAgICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhodG1sKTtcblxuICAgIC8vIFRoZSBwYWdlIGlzIGFscmVhZHkgbG9ja2VkLCBlaXRoZXIgYnkgdGhlIHNpdGUgYXV0aG9yIG9yIGJ5IGEgbm9uLUJhc2UgVUkgb3ZlcmxheSB0aGF0XG4gICAgLy8gaGFzbid0IGNsZWFuZWQgdXAgeWV0LiBMZWF2ZSBpdCBhbG9uZSBhbmQgd2FpdCBmb3IgdGhlIGxvY2sgdG8gY2xlYXIgYmVmb3JlIHRha2luZyBvdmVyLFxuICAgIC8vIG90aGVyd2lzZSB3ZSdkIHNuYXBzaG90IHRoZSBsb2NrZWQgc3RhdGUgYW5kIHJlc3RvcmUgaXQgYWZ0ZXIgb3VyIG93biBsb2NrIGlzIHJlbGVhc2VkLlxuICAgIGlmIChpc1BhZ2VTY3JvbGxMb2NrZWQod2luLCBodG1sLCBib2R5KSkge1xuICAgICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgd2luLk11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgICBpZiAoaXNQYWdlU2Nyb2xsTG9ja2VkKHdpbiwgaHRtbCwgYm9keSkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICB0aGlzLnJlc3RvcmUgPSBudWxsO1xuICAgICAgICB0aGlzLmxvY2socmVmZXJlbmNlRWxlbWVudCk7XG4gICAgICB9KTtcblxuICAgICAgLy8gV2F0Y2ggZXZlcnkgYXR0cmlidXRlOiBsb2NrcyBhcmUgYXBwbGllZCB0aHJvdWdoIGlubGluZSBzdHlsZXMsIGNsYXNzZXMsIG9yIGF0dHJpYnV0ZXNcbiAgICAgIC8vIHBhaXJlZCB3aXRoIGEgc3R5bGVzaGVldCAoYGRhdGEtc2Nyb2xsLWxvY2tlZGAgaW4gcmVhY3QtcmVtb3ZlLXNjcm9sbCwgZm9yIGV4YW1wbGUpLlxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgYXR0cmlidXRlczogdHJ1ZVxuICAgICAgfTtcbiAgICAgIG9ic2VydmVyLm9ic2VydmUoaHRtbCwgb3B0aW9ucyk7XG4gICAgICBvYnNlcnZlci5vYnNlcnZlKGJvZHksIG9wdGlvbnMpO1xuICAgICAgdGhpcy5yZXN0b3JlID0gKCkgPT4gb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBoYXNPdmVybGF5U2Nyb2xsYmFycyA9IHBsYXRmb3JtLm9zLmlvcyB8fCAhaGFzSW5zZXRTY3JvbGxiYXJzKHJlZmVyZW5jZUVsZW1lbnQpO1xuXG4gICAgLy8gT24gaU9TLCBzY3JvbGwgbG9ja2luZyBkb2VzIG5vdCB3b3JrIGlmIHRoZSBuYXZiYXIgaXMgY29sbGFwc2VkLiBEdWUgdG8gbnVtZXJvdXNcbiAgICAvLyBzaWRlIGVmZmVjdHMgYW5kIGJ1Z3MgdGhhdCBhcmlzZSBvbiBpT1MsIGl0IG11c3QgYmUgcmVzZWFyY2hlZCBleHRlbnNpdmVseSBiZWZvcmVcbiAgICAvLyBiZWluZyBlbmFibGVkIHRvIGVuc3VyZSBpdCBkb2Vzbid0IGNhdXNlIHRoZSBmb2xsb3dpbmcgaXNzdWVzOlxuICAgIC8vIC0gVGV4dGJveGVzIG11c3Qgc2Nyb2xsIGludG8gdmlldyB3aGVuIGZvY3VzZWQsIG5vciBjYXVzZSBhIGdsaXRjaHkgc2Nyb2xsIGFuaW1hdGlvbi5cbiAgICAvLyAtIFRoZSBuYXZiYXIgbXVzdCBub3QgZm9yY2UgaXRzZWxmIGludG8gdmlldyBhbmQgY2F1c2UgbGF5b3V0IHNoaWZ0LlxuICAgIC8vIC0gU2Nyb2xsIGNvbnRhaW5lcnMgbXVzdCBub3QgZmxpY2tlciB1cG9uIGNsb3NpbmcgYSBwb3B1cCB3aGVuIGl0IGhhcyBhbiBleGl0IGFuaW1hdGlvbi5cbiAgICB0aGlzLnJlc3RvcmUgPSBoYXNPdmVybGF5U2Nyb2xsYmFycyA/IHByZXZlbnRTY3JvbGxPdmVybGF5U2Nyb2xsYmFycyhyZWZlcmVuY2VFbGVtZW50KSA6IHByZXZlbnRTY3JvbGxJbnNldFNjcm9sbGJhcnMocmVmZXJlbmNlRWxlbWVudCk7XG4gIH1cbn1cbmNvbnN0IFNDUk9MTF9MT0NLRVIgPSBuZXcgU2Nyb2xsTG9ja2VyKCk7XG5cbi8qKlxuICogTG9ja3MgdGhlIHNjcm9sbCBvZiB0aGUgZG9jdW1lbnQgd2hlbiBlbmFibGVkLlxuICpcbiAqIEBwYXJhbSBlbmFibGVkIC0gV2hldGhlciB0byBlbmFibGUgdGhlIHNjcm9sbCBsb2NrLlxuICogQHBhcmFtIHJlZmVyZW5jZUVsZW1lbnQgLSBFbGVtZW50IHRvIHVzZSBhcyBhIHJlZmVyZW5jZSBmb3IgbG9jayBjYWxjdWxhdGlvbnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VTY3JvbGxMb2NrKGVuYWJsZWQgPSB0cnVlLCByZWZlcmVuY2VFbGVtZW50ID0gbnVsbCkge1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIFNDUk9MTF9MT0NLRVIuYWNxdWlyZShyZWZlcmVuY2VFbGVtZW50KTtcbiAgfSwgW2VuYWJsZWQsIHJlZmVyZW5jZUVsZW1lbnRdKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VTY3JvbGxMb2NrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU2Nyb2xsTG9jayc7XG5pbXBvcnQgeyB1c2VEaXNtaXNzIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgY29udGFpbnMsIGdldFRhcmdldCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC91dGlscy5tanNcIjtcbmltcG9ydCB7IHVzZVBvcHVwSW50ZXJhY3Rpb25Qcm9wcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gRGlhbG9nSW50ZXJhY3Rpb25zKHtcbiAgc3RvcmUsXG4gIHBhcmVudENvbnRleHQsXG4gIGlzRHJhd2VyXG59KSB7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBtb3VudGVkID0gc3RvcmUudXNlU3RhdGUoJ21vdW50ZWQnKTtcbiAgY29uc3QgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWwgPSBzdG9yZS51c2VTdGF0ZSgnZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWwnKTtcbiAgY29uc3QgbW9kYWwgPSBzdG9yZS51c2VTdGF0ZSgnbW9kYWwnKTtcbiAgY29uc3QgcG9wdXBFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3BvcHVwRWxlbWVudCcpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3QgW293bk5lc3RlZE9wZW5EaWFsb2dzLCBzZXRPd25OZXN0ZWRPcGVuRGlhbG9nc10gPSBSZWFjdC51c2VTdGF0ZSgwKTtcbiAgY29uc3QgW293bk5lc3RlZE9wZW5EcmF3ZXJzLCBzZXRPd25OZXN0ZWRPcGVuRHJhd2Vyc10gPSBSZWFjdC51c2VTdGF0ZSgwKTtcbiAgY29uc3QgaXNUb3Btb3N0ID0gb3duTmVzdGVkT3BlbkRpYWxvZ3MgPT09IDA7XG4gIGNvbnN0IGRpc21pc3MgPSB1c2VEaXNtaXNzKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICBvdXRzaWRlUHJlc3NFdmVudCgpIHtcbiAgICAgIGlmIChzdG9yZS5jb250ZXh0LmludGVybmFsQmFja2Ryb3BSZWYuY3VycmVudCB8fCBzdG9yZS5jb250ZXh0LmJhY2tkcm9wUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuICdpbnRlbnRpb25hbCc7XG4gICAgICB9XG4gICAgICAvLyBFbnN1cmUgYGFyaWEtaGlkZGVuYCBvbiBvdXRzaWRlIGVsZW1lbnRzIGlzIHJlbW92ZWQgaW1tZWRpYXRlbHlcbiAgICAgIC8vIG9uIG91dHNpZGUgcHJlc3Mgd2hlbiB0cmFwcGluZyBmb2N1cy5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIG1vdXNlOiBtb2RhbCA9PT0gJ3RyYXAtZm9jdXMnID8gJ3Nsb3BweScgOiAnaW50ZW50aW9uYWwnLFxuICAgICAgICB0b3VjaDogJ3Nsb3BweSdcbiAgICAgIH07XG4gICAgfSxcbiAgICBvdXRzaWRlUHJlc3MoZXZlbnQpIHtcbiAgICAgIGlmICghc3RvcmUuY29udGV4dC5vdXRzaWRlUHJlc3NFbmFibGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuXG4gICAgICAvLyBGb3IgbW91c2UgZXZlbnRzLCBvbmx5IGFjY2VwdCBsZWZ0IGJ1dHRvbiAoYnV0dG9uIDApXG4gICAgICAvLyBGb3IgdG91Y2ggZXZlbnRzLCBhIHNpbmdsZSB0b3VjaCBpcyBlcXVpdmFsZW50IHRvIGxlZnQgYnV0dG9uXG4gICAgICBpZiAoJ2J1dHRvbicgaW4gZXZlbnQgJiYgZXZlbnQuYnV0dG9uICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICgndG91Y2hlcycgaW4gZXZlbnQpIHtcbiAgICAgICAgLy8gT3V0c2lkZSBwcmVzcyBjYW4gYmUgaGFuZGxlZCBvbiBgdG91Y2hlbmRgLCB3aGVyZSB0aGUgbGlmdGVkIHBvaW50IGlzXG4gICAgICAgIC8vIHJlcG9ydGVkIGluIGBjaGFuZ2VkVG91Y2hlc2AgYW5kIGB0b3VjaGVzYCBjb250YWlucyBhbnkgcmVtYWluaW5nXG4gICAgICAgIC8vIGFjdGl2ZSBwb2ludHMuIFRyZWF0IGl0IGFzIGEgc2luZ2xlLWZpbmdlciB0YXAgb25seSB3aGVuIGV4YWN0bHkgb25lXG4gICAgICAgIC8vIHRvdWNoIGVuZGVkIGFuZCBubyBvdGhlciBmaW5nZXJzIGFyZSBzdGlsbCBkb3duLlxuICAgICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ3RvdWNoZW5kJykge1xuICAgICAgICAgIGlmIChldmVudC5jaGFuZ2VkVG91Y2hlcy5sZW5ndGggIT09IDEgfHwgZXZlbnQudG91Y2hlcy5sZW5ndGggIT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoZXZlbnQudG91Y2hlcy5sZW5ndGggIT09IDEpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG4gICAgICBpZiAoaXNUb3Btb3N0ICYmICFkaXNhYmxlUG9pbnRlckRpc21pc3NhbCkge1xuICAgICAgICAvLyBPbmx5IGNsb3NlIGlmIHRoZSBjbGljayBvY2N1cnJlZCBvbiB0aGUgZGlhbG9nJ3Mgb3duaW5nIGJhY2tkcm9wLlxuICAgICAgICAvLyBUaGlzIHN1cHBvcnRzIG11bHRpcGxlIG1vZGFsIGRpYWxvZ3MgdGhhdCBhcmVuJ3QgbmVzdGVkIGluIHRoZSBSZWFjdCB0cmVlOlxuICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vbXVpL2Jhc2UtdWkvaXNzdWVzLzEzMjBcbiAgICAgICAgaWYgKG1vZGFsKSB7XG4gICAgICAgICAgY29uc3QgaW50ZXJuYWxCYWNrZHJvcCA9IHN0b3JlLmNvbnRleHQuaW50ZXJuYWxCYWNrZHJvcFJlZi5jdXJyZW50O1xuICAgICAgICAgIGNvbnN0IGJhY2tkcm9wID0gc3RvcmUuY29udGV4dC5iYWNrZHJvcFJlZi5jdXJyZW50O1xuICAgICAgICAgIHJldHVybiBpbnRlcm5hbEJhY2tkcm9wIHx8IGJhY2tkcm9wID8gaW50ZXJuYWxCYWNrZHJvcCA9PT0gdGFyZ2V0IHx8IGJhY2tkcm9wID09PSB0YXJnZXQgfHwgY29udGFpbnModGFyZ2V0LCBwb3B1cEVsZW1lbnQpICYmICF0YXJnZXQ/Lmhhc0F0dHJpYnV0ZSgnZGF0YS1iYXNlLXVpLXBvcnRhbCcpIDogdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9LFxuICAgIGVzY2FwZUtleTogaXNUb3Btb3N0XG4gIH0pO1xuICB1c2VTY3JvbGxMb2NrKG9wZW4gJiYgbW9kYWwgPT09IHRydWUsIHBvcHVwRWxlbWVudCk7XG5cbiAgLy8gTGlzdGVuIGZvciBuZXN0ZWQgb3Blbi9jbG9zZSBldmVudHMgb24gdGhpcyBzdG9yZSB0byBtYWludGFpbiB0aGUgY291bnRzLlxuICAvLyBBIGNsb3NlIG5vdGlmaWNhdGlvbiBpcyBhbiBvcGVuIG5vdGlmaWNhdGlvbiB3aXRoIHplcm9lZCBjb3VudHMuXG4gIHN0b3JlLnVzZUNvbnRleHRDYWxsYmFjaygnb25OZXN0ZWREaWFsb2dPcGVuJywgKGRpYWxvZ0NvdW50LCBkcmF3ZXJDb3VudCkgPT4ge1xuICAgIC8vIEEgaGFuZGxlLWJhY2tlZCByb290IGtlZXBzIHRoZXNlIGludGVyYWN0aW9ucyBtb3VudGVkIHdoaWxlIGNsb3NlZC4gSWdub3JlIG5lc3RlZCByb290cyB0aGF0XG4gICAgLy8gb3BlbiBtZWFud2hpbGUgc28gdGhlaXIgY291bnRzIGRvbid0IGNhcnJ5IGludG8gdGhlIG5leHQgb3BlbiBzZXNzaW9uLlxuICAgIGlmICghc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgIXN0b3JlLnNlbGVjdCgnbW91bnRlZCcpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldE93bk5lc3RlZE9wZW5EaWFsb2dzKGRpYWxvZ0NvdW50KTtcbiAgICBzZXRPd25OZXN0ZWRPcGVuRHJhd2VycyhkcmF3ZXJDb3VudCk7XG4gIH0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiAmJiAhbW91bnRlZCkge1xuICAgICAgc2V0T3duTmVzdGVkT3BlbkRpYWxvZ3MoMCk7XG4gICAgICBzZXRPd25OZXN0ZWRPcGVuRHJhd2VycygwKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBtb3VudGVkXSk7XG5cbiAgLy8gTm90aWZ5IHBhcmVudCBvZiBvdXIgb3Blbi9jbG9zZSBzdGF0ZSB1c2luZyBwYXJlbnQgY2FsbGJhY2tzLCBpZiBhbnlcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAocGFyZW50Q29udGV4dD8ub25OZXN0ZWREaWFsb2dPcGVuKSB7XG4gICAgICBpZiAob3Blbikge1xuICAgICAgICBwYXJlbnRDb250ZXh0Lm9uTmVzdGVkRGlhbG9nT3Blbihvd25OZXN0ZWRPcGVuRGlhbG9ncyArIDEsIG93bk5lc3RlZE9wZW5EcmF3ZXJzICsgKGlzRHJhd2VyID8gMSA6IDApKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChwYXJlbnRDb250ZXh0Py5vbk5lc3RlZERpYWxvZ09wZW4gJiYgb3Blbikge1xuICAgICAgICBwYXJlbnRDb250ZXh0Lm9uTmVzdGVkRGlhbG9nT3BlbigwLCAwKTtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbaXNEcmF3ZXIsIG9wZW4sIG93bk5lc3RlZE9wZW5EaWFsb2dzLCBvd25OZXN0ZWRPcGVuRHJhd2VycywgcGFyZW50Q29udGV4dF0pO1xuICB1c2VQb3B1cEludGVyYWN0aW9uUHJvcHMoc3RvcmUsIHtcbiAgICAvLyBgZW5hYmxlZGAgaXMgbm90IHBhc3NlZCB0byBgdXNlRGlzbWlzc2AsIHNvIGl0cyBwcm9wcyBhcmUgYWx3YXlzIGRlZmluZWQsXG4gICAgLy8gYW5kIGB0cmlnZ2VyYCBpcyB0aGUgc2FtZSBvYmplY3QgYXMgYHJlZmVyZW5jZWAuXG4gICAgYWN0aXZlVHJpZ2dlclByb3BzOiBkaXNtaXNzLnJlZmVyZW5jZSxcbiAgICBpbmFjdGl2ZVRyaWdnZXJQcm9wczogZGlzbWlzcy50cmlnZ2VyLFxuICAgIC8vIERpYWxvZ1BvcHVwIGFuZCBEcmF3ZXJQb3B1cCBzcHJlYWQgYEZPQ1VTQUJMRV9QT1BVUF9QUk9QU2AgZGlyZWN0bHksIHNvXG4gICAgLy8gdGhpcyBvbmx5IG5lZWRzIHRvIGNhcnJ5IHRoZSBkaXNtaXNzIGhhbmRsZXJzLlxuICAgIHBvcHVwUHJvcHM6IGRpc21pc3MuZmxvYXRpbmcsXG4gICAgbmVzdGVkT3BlbkRpYWxvZ0NvdW50OiBvd25OZXN0ZWRPcGVuRGlhbG9ncyxcbiAgICBuZXN0ZWRPcGVuRHJhd2VyQ291bnQ6IG93bk5lc3RlZE9wZW5EcmF3ZXJzXG4gIH0pO1xuICByZXR1cm4gbnVsbDtcbn0iLCJpbXBvcnQgeyBSZWFjdFN0b3JlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RvcmUnO1xuLyoqXG4gKiBBIGBSZWFjdFN0b3JlYCB3aG9zZSBzdGF0ZSBuZXZlciBjaGFuZ2VzLlxuICpcbiAqIFVzZWZ1bCBmb3IgZmFsbGJhY2sgc3RvcmVzIHRoYXQgbmVlZCB0byBzdXBwb3J0IG5vcm1hbCBzdG9yZSByZWFkcyB3aGlsZSBkZXRhY2hlZCBmcm9tIHRoZVxuICogY29tcG9uZW50IHRoYXQgb3ducyByZWFsIHN0YXRlLiBDb250ZXh0IHZhbHVlcyBtYXkgc3RpbGwgY29udGFpbiBtdXRhYmxlIHJlZnMgb3IgbWFwcy5cbiAqL1xuZXhwb3J0IGNsYXNzIE51bGxTdG9yZSBleHRlbmRzIFJlYWN0U3RvcmUge1xuICAvLyBgdXBkYXRlYC9gc2V0YC9gbm90aWZ5QWxsYCBmdW5uZWwgdGhyb3VnaCBgc2V0U3RhdGVgIGluIHRoZSBiYXNlIGBTdG9yZWAsIHNvIG92ZXJyaWRpbmdcbiAgLy8gYHNldFN0YXRlYCBhbG9uZSB3b3VsZCBuZXV0cmFsaXplIHRoZW0gdG9kYXkuIFRoZXkgYXJlIG92ZXJyaWRkZW4gZXhwbGljaXRseSBzbyB0aGUgc3RvcmUgc3RheXNcbiAgLy8gaW5lcnQgZXZlbiBpZiBhIGZ1dHVyZSBiYXNlLWNsYXNzIGNoYW5nZSBzdG9wcyByb3V0aW5nIGEgbXV0YXRvciB0aHJvdWdoIGBzZXRTdGF0ZWAuXG4gIHNldFN0YXRlKF9uZXdTdGF0ZSkge31cbiAgdXBkYXRlKF9jaGFuZ2VzKSB7fVxuICBzZXQoX2tleSwgX3ZhbHVlKSB7fVxuICBub3RpZnlBbGwoKSB7fVxufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFJlYWN0U3RvcmUgfSBmcm9tICdAYmFzZS11aS91dGlscy9zdG9yZSc7XG5pbXBvcnQgeyBOdWxsU3RvcmUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvTnVsbFN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSwgcG9wdXBTdG9yZVNlbGVjdG9ycywgUG9wdXBUcmlnZ2VyTWFwLCBjcmVhdGVQb3B1cE9wZW5TdGF0ZSB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5jb25zdCBzZWxlY3RvcnMgPSB7XG4gIC4uLnBvcHVwU3RvcmVTZWxlY3RvcnMsXG4gIG1vZGFsOiBzdGF0ZSA9PiBzdGF0ZS5tb2RhbCxcbiAgbmVzdGVkOiBzdGF0ZSA9PiBzdGF0ZS5uZXN0ZWQsXG4gIG5lc3RlZE9wZW5EaWFsb2dDb3VudDogc3RhdGUgPT4gc3RhdGUubmVzdGVkT3BlbkRpYWxvZ0NvdW50LFxuICBuZXN0ZWRPcGVuRHJhd2VyQ291bnQ6IHN0YXRlID0+IHN0YXRlLm5lc3RlZE9wZW5EcmF3ZXJDb3VudCxcbiAgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWw6IHN0YXRlID0+IHN0YXRlLmRpc2FibGVQb2ludGVyRGlzbWlzc2FsLFxuICBvcGVuTWV0aG9kOiBzdGF0ZSA9PiBzdGF0ZS5vcGVuTWV0aG9kLFxuICBkZXNjcmlwdGlvbkVsZW1lbnRJZDogc3RhdGUgPT4gc3RhdGUuZGVzY3JpcHRpb25FbGVtZW50SWQsXG4gIHRpdGxlRWxlbWVudElkOiBzdGF0ZSA9PiBzdGF0ZS50aXRsZUVsZW1lbnRJZCxcbiAgdmlld3BvcnRFbGVtZW50OiBzdGF0ZSA9PiBzdGF0ZS52aWV3cG9ydEVsZW1lbnQsXG4gIHJvbGU6IHN0YXRlID0+IHN0YXRlLnJvbGVcbn07XG5cbi8qKlxuICogVGhlIHN1YnNldCBvZiBgRGlhbG9nU3RvcmVgIHRoYXQgZGV0YWNoZWQgaGFuZGxlLWJhY2tlZCB0cmlnZ2VycyByZWx5IG9uLiBCb3RoIHRoZSByZWFsXG4gKiBgRGlhbG9nU3RvcmVgIGFuZCB0aGUgaW5lcnQgZmFsbGJhY2sgc3RvcmUgc2F0aXNmeSBpdCwgc28gYSB0cmlnZ2VyIGNhbiByZWFkIGZyb20gd2hpY2hldmVyXG4gKiBzdG9yZSB0aGUgaGFuZGxlIGN1cnJlbnRseSBleHBvc2VzLlxuICovXG5cbmV4cG9ydCBjbGFzcyBEaWFsb2dTdG9yZSBleHRlbmRzIFJlYWN0U3RvcmUge1xuICBjb25zdHJ1Y3Rvcihpbml0aWFsU3RhdGUsIGZsb2F0aW5nSWQsIG5lc3RlZCkge1xuICAgIGNvbnN0IHRyaWdnZXJFbGVtZW50cyA9IG5ldyBQb3B1cFRyaWdnZXJNYXAoKTtcbiAgICBjb25zdCBzdGF0ZSA9IGNyZWF0ZUluaXRpYWxTdGF0ZShpbml0aWFsU3RhdGUsIHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkKTtcbiAgICBzdXBlcihzdGF0ZSwgY3JlYXRlSW5pdGlhbENvbnRleHQodHJpZ2dlckVsZW1lbnRzKSwgc2VsZWN0b3JzKTtcbiAgfVxuICBzZXRPcGVuID0gKG5leHRPcGVuLCBldmVudERldGFpbHMpID0+IHtcbiAgICBldmVudERldGFpbHMucHJldmVudFVubW91bnRPbkNsb3NlID0gKCkgPT4ge1xuICAgICAgdGhpcy5zZXQoJ3ByZXZlbnRVbm1vdW50aW5nT25DbG9zZScsIHRydWUpO1xuICAgIH07XG4gICAgaWYgKCFuZXh0T3BlbiAmJiBldmVudERldGFpbHMudHJpZ2dlciA9PSBudWxsICYmIHRoaXMuc3RhdGUuYWN0aXZlVHJpZ2dlcklkICE9IG51bGwpIHtcbiAgICAgIC8vIFdoZW4gY2xvc2luZyB0aGUgZGlhbG9nLCBwYXNzIHRoZSBvbGQgdHJpZ2dlciB0byB0aGUgb25PcGVuQ2hhbmdlIGV2ZW50XG4gICAgICAvLyBzbyBpdCdzIG5vdCByZXNldCB0b28gZWFybHkgKHBvdGVudGlhbGx5IGNhdXNpbmcgZm9jdXMgaXNzdWVzIGluIGNvbnRyb2xsZWQgc2NlbmFyaW9zKS5cbiAgICAgIGV2ZW50RGV0YWlscy50cmlnZ2VyID0gdGhpcy5zdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudCA/PyB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHRoaXMuY29udGV4dC5vbk9wZW5DaGFuZ2U/LihuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgICBpZiAoZXZlbnREZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LmRpc3BhdGNoT3BlbkNoYW5nZShuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgICB0aGlzLnVwZGF0ZShjcmVhdGVQb3B1cE9wZW5TdGF0ZSh0aGlzLnN0YXRlLCBuZXh0T3BlbiwgZXZlbnREZXRhaWxzLnRyaWdnZXIpKTtcbiAgfTtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIHRoZSBpbmVydCBmYWxsYmFjayBzdG9yZSB1c2VkIGJ5IGRldGFjaGVkIGhhbmRsZS1iYWNrZWQgdHJpZ2dlcnMgd2hpbGUgbm9cbiAqIGBEaWFsb2cuUm9vdGAgaXMgYXR0YWNoZWQuIEl0IHByZXNlcnZlcyBhIGRpYWxvZy1zcGVjaWZpYyB0cmlnZ2VyIHJlZ2lzdHJ5IGluIGNvbnRleHQgc29cbiAqIGRldGFjaGVkIHRyaWdnZXJzIGNhbiByZWdpc3RlciBiZWZvcmUgbWlncmF0aW5nIHRvIHRoZSBsaXZlIHJvb3Qgc3RvcmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVOdWxsRGlhbG9nU3RvcmUoKSB7XG4gIGNvbnN0IHRyaWdnZXJFbGVtZW50cyA9IG5ldyBQb3B1cFRyaWdnZXJNYXAoKTtcbiAgcmV0dXJuIG5ldyBOdWxsU3RvcmUoT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsU3RhdGUodW5kZWZpbmVkLCB0cmlnZ2VyRWxlbWVudHMpKSwgT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsQ29udGV4dCh0cmlnZ2VyRWxlbWVudHMpKSwgc2VsZWN0b3JzKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxTdGF0ZShpbml0aWFsU3RhdGUsIHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkID0gZmFsc2UpIHtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgLi4uY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSh0cmlnZ2VyRWxlbWVudHMsIGZsb2F0aW5nSWQsIG5lc3RlZCksXG4gICAgbW9kYWw6IHRydWUsXG4gICAgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWw6IGZhbHNlLFxuICAgIHZpZXdwb3J0RWxlbWVudDogbnVsbCxcbiAgICBkZXNjcmlwdGlvbkVsZW1lbnRJZDogdW5kZWZpbmVkLFxuICAgIHRpdGxlRWxlbWVudElkOiB1bmRlZmluZWQsXG4gICAgb3Blbk1ldGhvZDogbnVsbCxcbiAgICBuZXN0ZWQ6IGZhbHNlLFxuICAgIG5lc3RlZE9wZW5EaWFsb2dDb3VudDogMCxcbiAgICBuZXN0ZWRPcGVuRHJhd2VyQ291bnQ6IDAsXG4gICAgcm9sZTogJ2RpYWxvZycsXG4gICAgLi4uaW5pdGlhbFN0YXRlXG4gIH07XG4gIHJldHVybiBzdGF0ZTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxDb250ZXh0KHRyaWdnZXJFbGVtZW50cykge1xuICByZXR1cm4ge1xuICAgIHBvcHVwUmVmOiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlUmVmKCksXG4gICAgYmFja2Ryb3BSZWY6IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVSZWYoKSxcbiAgICBpbnRlcm5hbEJhY2tkcm9wUmVmOiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlUmVmKCksXG4gICAgb3V0c2lkZVByZXNzRW5hYmxlZFJlZjoge1xuICAgICAgY3VycmVudDogdHJ1ZVxuICAgIH0sXG4gICAgdHJpZ2dlckVsZW1lbnRzLFxuICAgIG9uT3BlbkNoYW5nZTogdW5kZWZpbmVkLFxuICAgIG9uT3BlbkNoYW5nZUNvbXBsZXRlOiB1bmRlZmluZWRcbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IERpYWxvZ0ludGVyYWN0aW9ucyB9IGZyb20gXCIuL3VzZURpYWxvZ1Jvb3QubWpzXCI7XG5pbXBvcnQgeyBEaWFsb2dSb290Q29udGV4dCwgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IERpYWxvZ1N0b3JlIH0gZnJvbSBcIi4uL3N0b3JlL0RpYWxvZ1N0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgdXNlSW1wbGljaXRBY3RpdmVUcmlnZ2VyLCB1c2VPcGVuU3RhdGVUcmFuc2l0aW9ucywgUG9wdXBIYW5kbGVBdHRhY2htZW50LCB1c2VQb3B1cFJvb3RTdG9yZSwgdXNlUG9wdXBSb290U3luYyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCwganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVJlbmRlckRpYWxvZ1Jvb3QobW9kZSwgcHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIG9wZW46IG9wZW5Qcm9wLFxuICAgIGRlZmF1bHRPcGVuID0gZmFsc2UsXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIG9uT3BlbkNoYW5nZUNvbXBsZXRlLFxuICAgIGRpc2FibGVQb2ludGVyRGlzbWlzc2FsOiBkaXNhYmxlUG9pbnRlckRpc21pc3NhbFByb3AgPSBmYWxzZSxcbiAgICBtb2RhbDogbW9kYWxQcm9wID0gdHJ1ZSxcbiAgICBhY3Rpb25zUmVmLFxuICAgIGhhbmRsZSxcbiAgICB0cmlnZ2VySWQ6IHRyaWdnZXJJZFByb3AsXG4gICAgZGVmYXVsdFRyaWdnZXJJZDogZGVmYXVsdFRyaWdnZXJJZFByb3AgPSBudWxsXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgaXNEcmF3ZXIgPSBtb2RlID09PSAnZHJhd2VyJztcbiAgY29uc3QgaXNBbGVydERpYWxvZyA9IG1vZGUgPT09ICdhbGVydC1kaWFsb2cnO1xuICBjb25zdCBtb2RhbCA9IGlzQWxlcnREaWFsb2cgPyB0cnVlIDogbW9kYWxQcm9wO1xuICBjb25zdCBkaXNhYmxlUG9pbnRlckRpc21pc3NhbCA9IGlzQWxlcnREaWFsb2cgfHwgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWxQcm9wO1xuICBjb25zdCByb2xlID0gaXNBbGVydERpYWxvZyA/ICdhbGVydGRpYWxvZycgOiAnZGlhbG9nJztcbiAgY29uc3QgcGFyZW50U3RvcmUgPSB1c2VEaWFsb2dSb290Q29udGV4dCh0cnVlKTtcbiAgY29uc3QgbmVzdGVkID0gcGFyZW50U3RvcmUgIT0gbnVsbDtcbiAgY29uc3Qgcm9vdFN0YXRlID0ge1xuICAgIG1vZGFsLFxuICAgIGRpc2FibGVQb2ludGVyRGlzbWlzc2FsLFxuICAgIG5lc3RlZCxcbiAgICByb2xlXG4gIH07XG5cbiAgLy8gVGhlIHN0b3JlIGlzIG93bmVkIGJ5IHRoaXMgUm9vdCBpbnN0YW5jZSBhbmQgY3JlYXRlZCBleGFjdGx5IG9uY2UuIEl0IGlzIG5vdCB0aWVkIHRvIHRoZSBoYW5kbGU6XG4gIC8vIHRoZSBoYW5kbGUgYXR0YWNoZXMgdG8gaXQsIHNvIHN3YXBwaW5nIHRoZSBoYW5kbGUgcmUtYXR0YWNoZXMgcmF0aGVyIHRoYW4gcmVjcmVhdGluZyBzdGF0ZS5cbiAgLy8gRGVmYXVsdCB2YWx1ZXMgYXJlIG9ubHkgaW5pdGlhbCB2YWx1ZXM7IGNvbnRyb2xsZWQgdmFsdWVzIGFuZCByb290IHN0YXRlIGFyZSBzeW5jZWQgYWZ0ZXIgY3JlYXRpb24uXG4gIC8vIERpYWxvZ3MgcGFzcyB0aGUgcG9wdXAgZWxlbWVudCB0byBGbG9hdGluZyBVSSBhcyB0aGUgZmxvYXRpbmcgZWxlbWVudCAoYHRyZWF0UG9wdXBBc0Zsb2F0aW5nRWxlbWVudGApLlxuICBjb25zdCBzdG9yZSA9IHVzZVBvcHVwUm9vdFN0b3JlKChmbG9hdGluZ0lkLCBmbG9hdGluZ05lc3RlZCkgPT4gbmV3IERpYWxvZ1N0b3JlKHtcbiAgICBvcGVuOiBkZWZhdWx0T3BlbixcbiAgICBvcGVuUHJvcCxcbiAgICBhY3RpdmVUcmlnZ2VySWQ6IGRlZmF1bHRUcmlnZ2VySWRQcm9wLFxuICAgIHRyaWdnZXJJZFByb3AsXG4gICAgLi4ucm9vdFN0YXRlXG4gIH0sIGZsb2F0aW5nSWQsIGZsb2F0aW5nTmVzdGVkKSwgdHJ1ZSk7XG4gIHN0b3JlLnVzZUNvbnRyb2xsZWRQcm9wKCdvcGVuUHJvcCcsIG9wZW5Qcm9wKTtcbiAgc3RvcmUudXNlQ29udHJvbGxlZFByb3AoJ3RyaWdnZXJJZFByb3AnLCB0cmlnZ2VySWRQcm9wKTtcbiAgc3RvcmUudXNlU3luY2VkVmFsdWVzKHJvb3RTdGF0ZSk7XG4gIHN0b3JlLnVzZUNvbnRleHRDYWxsYmFjaygnb25PcGVuQ2hhbmdlJywgb25PcGVuQ2hhbmdlKTtcbiAgc3RvcmUudXNlQ29udGV4dENhbGxiYWNrKCdvbk9wZW5DaGFuZ2VDb21wbGV0ZScsIG9uT3BlbkNoYW5nZUNvbXBsZXRlKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBwYXlsb2FkID0gc3RvcmUudXNlU3RhdGUoJ3BheWxvYWQnKTtcbiAgdXNlUG9wdXBSb290U3luYyhzdG9yZSwgb3Blbik7XG4gIHVzZUltcGxpY2l0QWN0aXZlVHJpZ2dlcihzdG9yZSk7XG4gIGNvbnN0IHtcbiAgICBmb3JjZVVubW91bnRcbiAgfSA9IHVzZU9wZW5TdGF0ZVRyYW5zaXRpb25zKG9wZW4sIHN0b3JlKTtcbiAgUmVhY3QudXNlSW1wZXJhdGl2ZUhhbmRsZShhY3Rpb25zUmVmLCAoKSA9PiAoe1xuICAgIHVubW91bnQ6IGZvcmNlVW5tb3VudCxcbiAgICBjbG9zZTogKCkgPT4gc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbikpXG4gIH0pLCBbZm9yY2VVbm1vdW50LCBzdG9yZV0pO1xuXG4gIC8vIERldGFjaGVkIHRyaWdnZXJzIHNoYXJlIHRoaXMgb25lIFJvb3QsIHNvIG1vdW50aW5nIGl0cyBpbnRlcmFjdGlvbnMgZWFnZXJseSBpcyBjaGVhcC4gVGhlXG4gIC8vIHRyaWdnZXIgcHJvcHMgdGhleSBwdWJsaXNoIHRoZW4gc3RheSBzdGFibGUsIHNvIG9wZW5pbmcgYW5kIGNsb3NpbmcgZG9lc24ndCByZS1yZW5kZXIgaW5hY3RpdmVcbiAgLy8gdHJpZ2dlcnMuXG4gIGNvbnN0IHNob3VsZFJlbmRlckludGVyYWN0aW9ucyA9IG9wZW4gfHwgbW91bnRlZCB8fCBoYW5kbGUgIT0gbnVsbDtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhEaWFsb2dSb290Q29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBzdG9yZSxcbiAgICBjaGlsZHJlbjogW2hhbmRsZSAmJiAvKiNfX1BVUkVfXyovX2pzeChQb3B1cEhhbmRsZUF0dGFjaG1lbnQsIHtcbiAgICAgIGhhbmRsZTogaGFuZGxlLFxuICAgICAgc3RvcmU6IHN0b3JlXG4gICAgfSksIHNob3VsZFJlbmRlckludGVyYWN0aW9ucyAmJiAvKiNfX1BVUkVfXyovX2pzeChEaWFsb2dJbnRlcmFjdGlvbnMsIHtcbiAgICAgIHN0b3JlOiBzdG9yZSxcbiAgICAgIHBhcmVudENvbnRleHQ6IHBhcmVudFN0b3JlPy5jb250ZXh0LFxuICAgICAgaXNEcmF3ZXI6IGlzRHJhd2VyXG4gICAgfSksIHR5cGVvZiBjaGlsZHJlbiA9PT0gJ2Z1bmN0aW9uJyA/IGNoaWxkcmVuKHtcbiAgICAgIHBheWxvYWRcbiAgICB9KSA6IGNoaWxkcmVuXVxuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IGZhc3RDb21wb25lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9mYXN0SG9va3MnO1xuaW1wb3J0IHsgdXNlUmVuZGVyRGlhbG9nUm9vdCB9IGZyb20gXCIuL3VzZVJlbmRlckRpYWxvZ1Jvb3QubWpzXCI7XG5cbi8qKlxuICogR3JvdXBzIGFsbCBwYXJ0cyBvZiB0aGUgZGlhbG9nLlxuICogRG9lc24ndCByZW5kZXIgaXRzIG93biBIVE1MIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgRGlhbG9nXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvZGlhbG9nKVxuICovXG5leHBvcnQgY29uc3QgRGlhbG9nUm9vdCA9IGZhc3RDb21wb25lbnQoZnVuY3Rpb24gRGlhbG9nUm9vdChwcm9wcykge1xuICByZXR1cm4gdXNlUmVuZGVyRGlhbG9nUm9vdCgnZGlhbG9nJywgcHJvcHMpO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dSb290LmRpc3BsYXlOYW1lID0gXCJEaWFsb2dSb290XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZURpYWxvZ1BvcnRhbENvbnRleHQgfSBmcm9tIFwiLi4vcG9ydGFsL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBkaWFsb2dTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nIH0gZnJvbSBcIi4uL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogQSBwb3NpdGlvbmluZyBjb250YWluZXIgZm9yIHRoZSBkaWFsb2cgcG9wdXAgdGhhdCBjYW4gYmUgbWFkZSBzY3JvbGxhYmxlLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dWaWV3cG9ydCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ1ZpZXdwb3J0KGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgY2hpbGRyZW4sXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qga2VlcE1vdW50ZWQgPSB1c2VEaWFsb2dQb3J0YWxDb250ZXh0KCk7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG5lc3RlZCA9IHN0b3JlLnVzZVN0YXRlKCduZXN0ZWQnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA9IHN0b3JlLnVzZVN0YXRlKCduZXN0ZWRPcGVuRGlhbG9nQ291bnQnKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHNldFZpZXdwb3J0RWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCd2aWV3cG9ydEVsZW1lbnQnKTtcbiAgY29uc3QgbmVzdGVkRGlhbG9nT3BlbiA9IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA+IDA7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIG9wZW4sXG4gICAgbmVzdGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgbmVzdGVkRGlhbG9nT3BlblxuICB9O1xuICBjb25zdCBzaG91bGRSZW5kZXIgPSBrZWVwTW91bnRlZCB8fCBtb3VudGVkO1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBlbmFibGVkOiBzaG91bGRSZW5kZXIsXG4gICAgc3RhdGUsXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBzZXRWaWV3cG9ydEVsZW1lbnRdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmc6IGRpYWxvZ1N0YXRlQXR0cmlidXRlc01hcHBpbmcsXG4gICAgcHJvcHM6IFt7XG4gICAgICByb2xlOiAncHJlc2VudGF0aW9uJyxcbiAgICAgIGhpZGRlbjogIW1vdW50ZWQsXG4gICAgICBzdHlsZToge1xuICAgICAgICBwb2ludGVyRXZlbnRzOiAhb3BlbiA/ICdub25lJyA6IHVuZGVmaW5lZFxuICAgICAgfSxcbiAgICAgIGNoaWxkcmVuXG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nVmlld3BvcnQuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1ZpZXdwb3J0XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VEaWFsb2dSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L0RpYWxvZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbi8qKlxuICogQSBoZWFkaW5nIHRoYXQgbGFiZWxzIHRoZSBkaWFsb2cuXG4gKiBSZW5kZXJzIGFuIGA8aDI+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuZXhwb3J0IGNvbnN0IERpYWxvZ1RpdGxlID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nVGl0bGUoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZVdpdGhDbGVhbnVwKCd0aXRsZUVsZW1lbnRJZCcsIGlkKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2gyJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBwcm9wczogW3tcbiAgICAgIGlkXG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nVGl0bGUuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1RpdGxlXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG4vKipcbiAqIFByb3ZpZGVzIGEgY3Jvc3MtYnJvd3NlciB3YXkgdG8gZGV0ZXJtaW5lIHRoZSB0eXBlIG9mIHRoZSBwb2ludGVyIHVzZWQgdG8gY2xpY2suXG4gKiBTYWZhcmkgYW5kIEZpcmVmb3ggZG8gbm90IHByb3ZpZGUgdGhlIFBvaW50ZXJFdmVudCB0byB0aGUgY2xpY2sgaGFuZGxlciAodGhleSB1c2UgTW91c2VFdmVudCkgeWV0LlxuICogQWRkaXRpb25hbGx5LCB0aGlzIGltcGxlbWVudGF0aW9uIGRldGVjdHMgaWYgdGhlIGNsaWNrIHdhcyB0cmlnZ2VyZWQgYnkgdGhlIGtleWJvYXJkLlxuICpcbiAqIEBwYXJhbSBoYW5kbGVyIFRoZSBmdW5jdGlvbiB0byBiZSBjYWxsZWQgd2hlbiB0aGUgYnV0dG9uIGlzIGNsaWNrZWQuIFRoZSBmaXJzdCBwYXJhbWV0ZXIgaXMgdGhlIG9yaWdpbmFsIGV2ZW50IGFuZCB0aGUgc2Vjb25kIHBhcmFtZXRlciBpcyB0aGUgcG9pbnRlciB0eXBlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRW5oYW5jZWRDbGlja0hhbmRsZXIoaGFuZGxlcikge1xuICBjb25zdCBsYXN0Q2xpY2tJbnRlcmFjdGlvblR5cGVSZWYgPSBSZWFjdC51c2VSZWYoJycpO1xuICBjb25zdCBoYW5kbGVQb2ludGVyRG93biA9IFJlYWN0LnVzZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBpZiAoZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsYXN0Q2xpY2tJbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCA9IGV2ZW50LnBvaW50ZXJUeXBlO1xuICAgIGhhbmRsZXIoZXZlbnQsIGV2ZW50LnBvaW50ZXJUeXBlKTtcbiAgfSwgW2hhbmRsZXJdKTtcbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSBSZWFjdC51c2VDYWxsYmFjayhldmVudCA9PiB7XG4gICAgLy8gZXZlbnQuZGV0YWlsIGhhcyB0aGUgbnVtYmVyIG9mIGNsaWNrcyBwZXJmb3JtZWQgb24gdGhlIGVsZW1lbnQuIDAgbWVhbnMgaXQgd2FzIHRyaWdnZXJlZCBieSB0aGUga2V5Ym9hcmQuXG4gICAgaWYgKGV2ZW50LmRldGFpbCA9PT0gMCkge1xuICAgICAgaGFuZGxlcihldmVudCwgJ2tleWJvYXJkJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICgncG9pbnRlclR5cGUnIGluIGV2ZW50KSB7XG4gICAgICAvLyBDaHJvbWUgYW5kIEVkZ2UgY29ycmVjdGx5IHVzZSBQb2ludGVyRXZlbnRcbiAgICAgIGhhbmRsZXIoZXZlbnQsIGV2ZW50LnBvaW50ZXJUeXBlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaGFuZGxlcihldmVudCwgbGFzdENsaWNrSW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQpO1xuICAgIH1cbiAgICBsYXN0Q2xpY2tJbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCA9ICcnO1xuICB9LCBbaGFuZGxlcl0pO1xuICByZXR1cm4ge1xuICAgIG9uQ2xpY2s6IGhhbmRsZUNsaWNrLFxuICAgIG9uUG9pbnRlckRvd246IGhhbmRsZVBvaW50ZXJEb3duXG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUVuaGFuY2VkQ2xpY2tIYW5kbGVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlRW5oYW5jZWRDbGlja0hhbmRsZXInO1xuaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tICdAYmFzZS11aS91dGlscy9wbGF0Zm9ybSc7XG5pbXBvcnQgeyB1c2VWYWx1ZUNoYW5nZWQgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3VzZVZhbHVlQ2hhbmdlZC5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VPcGVuTWV0aG9kVHJpZ2dlclByb3BzKG9wZW4sIHNldE9wZW5NZXRob2QpIHtcbiAgY29uc3QgaGFuZGxlVHJpZ2dlckNsaWNrID0gdXNlU3RhYmxlQ2FsbGJhY2soKF8sIGludGVyYWN0aW9uVHlwZSkgPT4ge1xuICAgIGNvbnN0IGlzT3BlbiA9IHR5cGVvZiBvcGVuID09PSAnZnVuY3Rpb24nID8gb3BlbigpIDogb3BlbjtcbiAgICBpZiAoIWlzT3Blbikge1xuICAgICAgc2V0T3Blbk1ldGhvZChpbnRlcmFjdGlvblR5cGUgfHwgKFxuICAgICAgLy8gT24gaU9TIFNhZmFyaSwgdGhlIGhpdHNsb3AgYXJvdW5kIHRvdWNoIHRhcmdldHMgbWVhbnMgdGFwcGluZyBvdXRzaWRlIGFuIGVsZW1lbnQnc1xuICAgICAgLy8gYm91bmRzIGRvZXMgbm90IGZpcmUgYHBvaW50ZXJkb3duYCBidXQgZG9lcyBmaXJlIGBtb3VzZWRvd25gLiBUaGUgYGludGVyYWN0aW9uVHlwZWBcbiAgICAgIC8vIHdpbGwgYmUgXCJcIiBpbiB0aGF0IGNhc2UuXG4gICAgICBwbGF0Zm9ybS5vcy5pb3MgPyAndG91Y2gnIDogJycpKTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCB7XG4gICAgb25DbGljayxcbiAgICBvblBvaW50ZXJEb3duXG4gIH0gPSB1c2VFbmhhbmNlZENsaWNrSGFuZGxlcihoYW5kbGVUcmlnZ2VyQ2xpY2spO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uQ2xpY2ssXG4gICAgb25Qb2ludGVyRG93blxuICB9KSwgW29uQ2xpY2ssIG9uUG9pbnRlckRvd25dKTtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBpbnRlcmFjdGlvbiB0eXBlIChrZXlib2FyZCwgbW91c2UsIHRvdWNoLCBldGMuKSB0aGF0IG9wZW5lZCB0aGUgY29tcG9uZW50LlxuICpcbiAqIEBwYXJhbSBvcGVuIFRoZSBvcGVuIHN0YXRlIG9mIHRoZSBjb21wb25lbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VPcGVuSW50ZXJhY3Rpb25UeXBlKG9wZW4pIHtcbiAgY29uc3QgW29wZW5NZXRob2QsIHNldE9wZW5NZXRob2RdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IHRyaWdnZXJQcm9wcyA9IHVzZU9wZW5NZXRob2RUcmlnZ2VyUHJvcHMob3Blbiwgc2V0T3Blbk1ldGhvZCk7XG4gIHVzZVZhbHVlQ2hhbmdlZChvcGVuLCBwcmV2aW91c09wZW4gPT4ge1xuICAgIGlmIChwcmV2aW91c09wZW4gJiYgIW9wZW4pIHtcbiAgICAgIHNldE9wZW5NZXRob2QobnVsbCk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBvcGVuTWV0aG9kLFxuICAgIHRyaWdnZXJQcm9wc1xuICB9KSwgW29wZW5NZXRob2QsIHRyaWdnZXJQcm9wc10pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZmFzdENvbXBvbmVudFJlZiB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2Zhc3RIb29rcyc7XG5pbXBvcnQgeyB1c2VEaWFsb2dSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L0RpYWxvZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQnV0dG9uIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2UtYnV0dG9uL3VzZUJ1dHRvbi5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB0cmlnZ2VyT3BlblN0YXRlTWFwcGluZyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IENMSUNLX1RSSUdHRVJfSURFTlRJRklFUiB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgdXNlUG9wdXBIYW5kbGVTdG9yZSwgdXNlVHJpZ2dlckRhdGFGb3J3YXJkaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IHVzZUNsaWNrIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlT3Blbk1ldGhvZFRyaWdnZXJQcm9wcyB9IGZyb20gXCIuLi8uLi91dGlscy91c2VPcGVuSW50ZXJhY3Rpb25UeXBlLm1qc1wiO1xuXG4vKipcbiAqIEEgYnV0dG9uIHRoYXQgb3BlbnMgdGhlIGRpYWxvZy5cbiAqIFJlbmRlcnMgYSBgPGJ1dHRvbj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgRGlhbG9nXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvZGlhbG9nKVxuICovXG5leHBvcnQgY29uc3QgRGlhbG9nVHJpZ2dlciA9IGZhc3RDb21wb25lbnRSZWYoZnVuY3Rpb24gRGlhbG9nVHJpZ2dlcihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgbmF0aXZlQnV0dG9uID0gdHJ1ZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIHBheWxvYWQsXG4gICAgaGFuZGxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IGRpYWxvZ1Jvb3RTdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KHRydWUpO1xuICBjb25zdCBoYW5kbGVTdG9yZSA9IHVzZVBvcHVwSGFuZGxlU3RvcmUoaGFuZGxlKTtcbiAgY29uc3Qgc3RvcmUgPSBoYW5kbGVTdG9yZSA/PyBkaWFsb2dSb290U3RvcmU7XG4gIGlmICghc3RvcmUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IDxEaWFsb2cuVHJpZ2dlcj4gbXVzdCBiZSB1c2VkIHdpdGhpbiA8RGlhbG9nLlJvb3Q+IG9yIHByb3ZpZGVkIHdpdGggYSBoYW5kbGUuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoNzkpKTtcbiAgfVxuICBjb25zdCB0aGlzVHJpZ2dlcklkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgY29uc3QgZmxvYXRpbmdDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3QgaXNPcGVuZWRCeVRoaXNUcmlnZ2VyID0gc3RvcmUudXNlU3RhdGUoJ2lzT3BlbmVkQnlUcmlnZ2VyJywgdGhpc1RyaWdnZXJJZCk7XG4gIGNvbnN0IHBvcHVwSWQgPSBzdG9yZS51c2VTdGF0ZSgndHJpZ2dlclBvcHVwSWQnLCB0aGlzVHJpZ2dlcklkKTtcbiAgY29uc3QgdHJpZ2dlckVsZW1lbnRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHtcbiAgICByZWdpc3RlclRyaWdnZXIsXG4gICAgaXNNb3VudGVkQnlUaGlzVHJpZ2dlclxuICB9ID0gdXNlVHJpZ2dlckRhdGFGb3J3YXJkaW5nKHRoaXNUcmlnZ2VySWQsIHRyaWdnZXJFbGVtZW50UmVmLCBzdG9yZSwge1xuICAgIHBheWxvYWRcbiAgfSk7XG4gIGNvbnN0IHtcbiAgICBnZXRCdXR0b25Qcm9wcyxcbiAgICBidXR0b25SZWZcbiAgfSA9IHVzZUJ1dHRvbih7XG4gICAgZGlzYWJsZWQsXG4gICAgbmF0aXZlOiBuYXRpdmVCdXR0b25cbiAgfSk7XG4gIGNvbnN0IGNsaWNrID0gdXNlQ2xpY2soZmxvYXRpbmdDb250ZXh0KTtcbiAgY29uc3QgaW50ZXJhY3Rpb25UeXBlUHJvcHMgPSB1c2VPcGVuTWV0aG9kVHJpZ2dlclByb3BzKCgpID0+IHN0b3JlLnNlbGVjdCgnb3BlbicpLCBpbnRlcmFjdGlvblR5cGUgPT4ge1xuICAgIHN0b3JlLnNldCgnb3Blbk1ldGhvZCcsIGludGVyYWN0aW9uVHlwZSk7XG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBkaXNhYmxlZCxcbiAgICBvcGVuOiBpc09wZW5lZEJ5VGhpc1RyaWdnZXJcbiAgfTtcbiAgY29uc3Qgcm9vdFRyaWdnZXJQcm9wcyA9IHN0b3JlLnVzZVN0YXRlKCd0cmlnZ2VyUHJvcHMnLCBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2J1dHRvbicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBbYnV0dG9uUmVmLCBmb3J3YXJkZWRSZWYsIHJlZ2lzdGVyVHJpZ2dlciwgdHJpZ2dlckVsZW1lbnRSZWZdLFxuICAgIHByb3BzOiBbY2xpY2sucmVmZXJlbmNlLCByb290VHJpZ2dlclByb3BzLCBpbnRlcmFjdGlvblR5cGVQcm9wcywge1xuICAgICAgW0NMSUNLX1RSSUdHRVJfSURFTlRJRklFUl06ICcnLFxuICAgICAgaWQ6IHRoaXNUcmlnZ2VySWQsXG4gICAgICAnYXJpYS1oYXNwb3B1cCc6ICdkaWFsb2cnLFxuICAgICAgJ2FyaWEtZXhwYW5kZWQnOiBpc09wZW5lZEJ5VGhpc1RyaWdnZXIsXG4gICAgICAnYXJpYS1jb250cm9scyc6IHBvcHVwSWRcbiAgICB9LCBlbGVtZW50UHJvcHMsIGdldEJ1dHRvblByb3BzXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiB0cmlnZ2VyT3BlblN0YXRlTWFwcGluZ1xuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nVHJpZ2dlci5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nVHJpZ2dlclwiOyIsImltcG9ydCB7IGNyZWF0ZU51bGxEaWFsb2dTdG9yZSB9IGZyb20gXCIuL0RpYWxvZ1N0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgQmFzZVBvcHVwSGFuZGxlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9wb3B1cEhhbmRsZS5tanNcIjtcblxuLyoqXG4gKiBDb250cm9scyBhIERpYWxvZyBpbXBlcmF0aXZlbHkgYW5kIGFzc29jaWF0ZXMgZGV0YWNoZWQgYERpYWxvZy5UcmlnZ2VyYCBjb21wb25lbnRzIHdpdGggYVxuICogYERpYWxvZy5Sb290YC4gQ3JlYXRlIG9uZSB3aXRoIGBEaWFsb2cuY3JlYXRlSGFuZGxlKClgIGFuZCBwYXNzIGl0IHRvIHRoZSBgaGFuZGxlYCBwcm9wIG9mIHRoZVxuICogcm9vdCBhbmQgb2YgYW55IHRyaWdnZXJzIHJlbmRlcmVkIG91dHNpZGUgb2YgaXQuXG4gKlxuICogVGhlIGltcGVyYXRpdmUgbWV0aG9kcyB0YWtlIGVmZmVjdCBvbmx5IHdoaWxlIGEgcm9vdCB1c2luZyB0aGlzIGhhbmRsZSBpcyBtb3VudGVkOyBjYWxscyBtYWRlXG4gKiBiZWZvcmUgYSByb290IGF0dGFjaGVzIChvciBhZnRlciBpdCB1bm1vdW50cykgYXJlIGlnbm9yZWQuXG4gKi9cbmV4cG9ydCBjbGFzcyBEaWFsb2dIYW5kbGUgZXh0ZW5kcyBCYXNlUG9wdXBIYW5kbGUge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcihjcmVhdGVOdWxsRGlhbG9nU3RvcmUoKSwgJ0RpYWxvZycsIGZhbHNlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyB0aGUgZGlhbG9nLCBvcHRpb25hbGx5IGFzc29jaWF0aW5nIGl0IHdpdGggYSB0cmlnZ2VyLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBzaG91bGQgb25seSBiZSBjYWxsZWQgaW4gYW4gZXZlbnQgaGFuZGxlciBvciBhbiBlZmZlY3QgKG5vdCBkdXJpbmcgcmVuZGVyaW5nKS5cbiAgICpcbiAgICogQHBhcmFtIHRyaWdnZXJJZCBJRCBvZiB0aGUgdHJpZ2dlciB0byBhc3NvY2lhdGUgd2l0aCB0aGUgZGlhbG9nLiBUaGUgdHJpZ2dlciBtdXN0IGJlIGEgbWF0Y2hpbmdcbiAgICogYERpYWxvZy5UcmlnZ2VyYCB3aXRoIHRoaXMgaGFuZGxlIHBhc3NlZCBhcyBhIHByb3AuIFBhc3MgYG51bGxgIHRvIG9wZW4gd2l0aG91dCBhc3NvY2lhdGluZyBhbnkgdHJpZ2dlci5cbiAgICovXG4gIG9wZW4odHJpZ2dlcklkKSB7XG4gICAgdGhpcy5vcGVuQnlUcmlnZ2VyKHRyaWdnZXJJZCk7XG4gIH1cblxuICAvKipcbiAgICogT3BlbnMgdGhlIGRpYWxvZyB3aXRoIHRoZSBnaXZlbiBwYXlsb2FkLCB3aXRob3V0IGFzc29jaWF0aW5nIGl0IHdpdGggYW55IHRyaWdnZXIuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKlxuICAgKiBAcGFyYW0gcGF5bG9hZCBQYXlsb2FkIHRvIHNldCB3aGVuIG9wZW5pbmcgdGhlIGRpYWxvZy4gSXQgaXMgZXhwb3NlZCB0byB0aGUgcm9vdCdzIHJlbmRlci1wcm9wIGNoaWxkcmVuLlxuICAgKi9cbiAgb3BlbldpdGhQYXlsb2FkKHBheWxvYWQpIHtcbiAgICBjb25zdCBhdHRhY2hlZFN0b3JlID0gdGhpcy5hdHRhY2hlZFN0b3JlO1xuICAgIGlmIChhdHRhY2hlZFN0b3JlID09PSBudWxsKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBjb25zb2xlLndhcm4oJ0Jhc2UgVUk6IERpYWxvZ0hhbmRsZS5vcGVuV2l0aFBheWxvYWQoKSB3YXMgY2FsbGVkIHdoaWxlIG5vIHJvb3QgdXNpbmcgdGhpcyBoYW5kbGUgaXMgbW91bnRlZC4gJyArICdUaGUgY2FsbCBhbmQgaXRzIHBheWxvYWQgd2VyZSBpZ25vcmVkOyBtb3VudCBhIHJvb3Qgd2l0aCB0aGlzIGhhbmRsZSBiZWZvcmUgb3BlbmluZyBpdCBpbXBlcmF0aXZlbHkuJyk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGF0dGFjaGVkU3RvcmUuc2V0KCdwYXlsb2FkJywgcGF5bG9hZCk7XG4gICAgYXR0YWNoZWRTdG9yZS5zZXRPcGVuKHRydWUsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLmltcGVyYXRpdmVBY3Rpb24pKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIGRpYWxvZy5cbiAgICpcbiAgICogVGhpcyBtZXRob2Qgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGluIGFuIGV2ZW50IGhhbmRsZXIgb3IgYW4gZWZmZWN0IChub3QgZHVyaW5nIHJlbmRlcmluZykuXG4gICAqL1xuICBjbG9zZSgpIHtcbiAgICB0aGlzLmNsb3NlUG9wdXAoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZSBkaWFsb2cgaXMgY3VycmVudGx5IG9wZW4uIFJldHVybnMgYGZhbHNlYCB3aGlsZSBubyByb290IGlzIGF0dGFjaGVkIHRvIHRoZSBoYW5kbGUuXG4gICAqL1xuICBnZXQgaXNPcGVuKCkge1xuICAgIHJldHVybiB0aGlzLmF0dGFjaGVkU3RvcmU/LnNlbGVjdCgnb3BlbicpID8/IGZhbHNlO1xuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIG5ldyBoYW5kbGUgdG8gY29ubmVjdCBhIERpYWxvZy5Sb290IHdpdGggZGV0YWNoZWQgRGlhbG9nLlRyaWdnZXIgY29tcG9uZW50cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZURpYWxvZ0hhbmRsZSgpIHtcbiAgcmV0dXJuIG5ldyBEaWFsb2dIYW5kbGUoKTtcbn0iLCJpbXBvcnQgeyBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBvcGVuID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgYmVnaW5zIGFuaW1hdGluZyBpbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHN0YXJ0aW5nU3R5bGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGU7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGlzIGFuaW1hdGluZyBvdXQuXG4gKi9cbmV4cG9ydCBjb25zdCBlbmRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7IiwiLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGJ1dHRvbiBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnOyIsImltcG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGlzIGNsb3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGNsb3NlZCA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaXMgbmVzdGVkIHdpdGhpbiBhbm90aGVyIGRpYWxvZy5cbiAqL1xuZXhwb3J0IGNvbnN0IG5lc3RlZCA9ICdkYXRhLW5lc3RlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGhhcyBvdGhlciBvcGVuIGRpYWxvZ3MgbmVzdGVkIHdpdGhpbiBpdC5cbiAqL1xuZXhwb3J0IGNvbnN0IG5lc3RlZERpYWxvZ09wZW4gPSAnZGF0YS1uZXN0ZWQtZGlhbG9nLW9wZW4nOyIsImltcG9ydCB7IENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHRyaWdnZXIgaXMgZGlzYWJsZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBkaXNhYmxlZCA9ICdkYXRhLWRpc2FibGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjb3JyZXNwb25kaW5nIGRpYWxvZyBpcyBvcGVuLlxuICovXG5leHBvcnQgY29uc3QgcG9wdXBPcGVuID0gQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnBvcHVwT3BlbjsiXSwiZmlsZSI6Ii93b3Jrc3BhY2UvbmZ0LW1hcmtldHBsYWNlLWpnL25vZGVfbW9kdWxlcy8udml0ZS9kZXBzL0BiYXNlLXVpX3JlYWN0X2RpYWxvZy5qcyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyLDUzLDU0LDU1LDU2LDU3LDU4LDU5LDYwLDYxLDYyLDYzLDY0LDY1LDY2LDY3LDY4LDY5LDcwLDcxLDcyLDczLDc0LDc1LDc2LDc3LDc4LDc5XX0=