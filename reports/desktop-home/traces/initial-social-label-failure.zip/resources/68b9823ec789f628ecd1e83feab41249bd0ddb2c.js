import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/auth-page.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport13_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link, useRouter, useSearch } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=22c23eb4";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=22c23eb4";
import { loginSchema, registerFormSchema } from "/src/contracts/auth.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "/src/components/ui/dialog.tsx";
import { apiErrorMessage, ApiRequestError } from "/src/lib/api.ts";
import { login, register } from "/src/features/auth/api.ts";
import { adoptSession } from "/src/features/auth/lifecycle.ts";
import { safeReturnTo } from "/src/features/auth/redirect.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/auth/auth-page.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
function useAuthDestination() {
	_s();
	const search = useSearch({ strict: false });
	const router = useRouter();
	const destination = safeReturnTo(search.redirect);
	return {
		destination,
		finish: async (result) => {
			await adoptSession(result.token, result.session);
			await router.invalidate();
			await router.navigate({
				href: destination,
				replace: true
			});
		}
	};
}
_s(useAuthDestination, "G7pzQJWXEBhy+zy5Z+tf02JC46w=", false, function() {
	return [useSearch, useRouter];
});
function FieldError({ id, message }) {
	return message ? /* @__PURE__ */ _jsxDEV("p", {
		id,
		className: "field-error",
		children: message
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 91
	}, this) : null;
}
_c = FieldError;
function LoginForm() {
	_s2();
	const { finish } = useAuthDestination();
	const form = useForm({
		resolver: zodResolver(loginSchema),
		defaultValues: {
			email: "",
			password: ""
		}
	});
	const [show, setShow] = useState(false);
	const mutation = useMutation({
		mutationFn: login,
		retry: false,
		onSuccess: finish,
		onError: (error) => {
			if (error instanceof ApiRequestError && error.fields?.email) form.setError("email", { message: error.fields.email[0] });
		}
	});
	return /* @__PURE__ */ _jsxDEV("form", {
		noValidate: true,
		onSubmit: form.handleSubmit((values) => mutation.mutate(values)),
		className: "auth-form",
		"aria-label": "Entrar na conta",
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "login-email",
				children: "E-mail"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Input, {
				id: "login-email",
				type: "email",
				autoComplete: "email",
				...form.register("email"),
				"aria-invalid": !!form.formState.errors.email,
				"aria-describedby": "login-email-error"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 48
			}, this),
			/* @__PURE__ */ _jsxDEV(FieldError, {
				id: "login-email-error",
				message: form.formState.errors.email?.message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "login-password",
				children: "Senha"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Input, {
				id: "login-password",
				type: show ? "text" : "password",
				autoComplete: "current-password",
				...form.register("password"),
				"aria-invalid": !!form.formState.errors.password,
				"aria-describedby": "login-password-error"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 50
			}, this),
			/* @__PURE__ */ _jsxDEV(FieldError, {
				id: "login-password-error",
				message: form.formState.errors.password?.message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				variant: "link",
				onClick: () => setShow(!show),
				children: show ? "Ocultar senha" : "Mostrar senha"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 5
			}, this),
			mutation.isError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: apiErrorMessage(mutation.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 26
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				type: "submit",
				disabled: mutation.isPending,
				children: mutation.isPending ? "Entrando…" : "Entrar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 10
	}, this);
}
_s2(LoginForm, "PIcjjt4XDINx52SbhFMxJD0UUwM=", false, function() {
	return [
		useAuthDestination,
		useForm,
		useMutation
	];
});
_c2 = LoginForm;
function RegisterForm() {
	_s3();
	const { finish } = useAuthDestination();
	const form = useForm({
		resolver: zodResolver(registerFormSchema),
		defaultValues: {
			name: "",
			email: "",
			password: "",
			confirmPassword: ""
		}
	});
	const mutation = useMutation({
		mutationFn: (values) => register({
			name: values.name,
			email: values.email,
			password: values.password
		}),
		retry: false,
		onSuccess: finish,
		onError: (error) => {
			if (error instanceof ApiRequestError) {
				for (const key of [
					"name",
					"email",
					"password"
				]) if (error.fields?.[key]) form.setError(key, { message: error.fields[key][0] });
			}
		}
	});
	return /* @__PURE__ */ _jsxDEV("form", {
		noValidate: true,
		onSubmit: form.handleSubmit((values) => mutation.mutate(values)),
		className: "auth-form",
		"aria-label": "Criar conta",
		children: [
			[
				"name",
				"email",
				"password",
				"confirmPassword"
			].map((key) => /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: `register-${key}`,
						children: {
							name: "Nome",
							email: "E-mail",
							password: "Senha",
							confirmPassword: "Confirmar senha"
						}[key]
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV(Input, {
						id: `register-${key}`,
						type: key === "email" ? "email" : key.includes("assword") ? "password" : "text",
						autoComplete: key.includes("assword") ? "new-password" : key === "name" ? "name" : "email",
						...form.register(key),
						"aria-invalid": !!form.formState.errors[key],
						"aria-describedby": `register-${key}-error`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV(FieldError, {
						id: `register-${key}-error`,
						message: form.formState.errors[key]?.message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 7
					}, this)
				]
			}, key, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 77
			}, this)),
			mutation.isError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: apiErrorMessage(mutation.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 26
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				type: "submit",
				disabled: mutation.isPending,
				children: mutation.isPending ? "Criando conta…" : "Criar conta"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 10
	}, this);
}
_s3(RegisterForm, "lFL2Kf78jMkmku/kSX0YzZSA2ss=", false, function() {
	return [
		useAuthDestination,
		useForm,
		useMutation
	];
});
_c3 = RegisterForm;
export function AuthPage({ mode }) {
	_s4();
	const { destination } = useAuthDestination();
	const router = useRouter();
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "py-12 text-center",
		children: /* @__PURE__ */ _jsxDEV("p", {
			className: "text-primary",
			children: "KURIO · COLECIONADORES"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 47
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 12
	}, this), /* @__PURE__ */ _jsxDEV(Dialog, {
		open: true,
		onOpenChange: (open) => {
			if (!open) void router.navigate({ to: "/" });
		},
		children: /* @__PURE__ */ _jsxDEV(DialogContent, {
			className: "kurio-theme auth-card",
			children: [
				/* @__PURE__ */ _jsxDEV(DialogTitle, { children: mode === "login" ? "Login" : "Cadastro" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					className: "flex gap-4",
					"aria-label": "Acesso à conta",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: "/login",
						search: { redirect: destination },
						children: "Entrar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 65
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: "/cadastro",
						search: { redirect: destination },
						children: "Criar conta"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 131
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(DialogDescription, { children: mode === "login" ? "Entre para gerenciar sua carteira e coleção." : "Crie seu perfil de colecionador." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this),
				mode === "login" ? /* @__PURE__ */ _jsxDEV(LoginForm, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 29
				}, this) : /* @__PURE__ */ _jsxDEV(RegisterForm, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 45
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-muted-foreground",
					children: "Login social e recuperação de senha não estão disponíveis nesta etapa."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 65,
		columnNumber: 5
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 10
	}, this);
}
_s4(AuthPage, "T5gDo5rK4n77Fx/lEAC2cwRJp0k=", false, function() {
	return [useAuthDestination, useRouter];
});
_c4 = AuthPage;
export function LoginPage() {
	return /* @__PURE__ */ _jsxDEV(AuthPage, { mode: "login" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 38
	}, this);
}
_c5 = LoginPage;
export function RegisterPage() {
	return /* @__PURE__ */ _jsxDEV(AuthPage, { mode: "register" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 77,
		columnNumber: 41
	}, this);
}
_c6 = RegisterPage;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "FieldError");
$RefreshReg$(_c2, "LoginForm");
$RefreshReg$(_c3, "RegisterForm");
$RefreshReg$(_c4, "AuthPage");
$RefreshReg$(_c5, "LoginPage");
$RefreshReg$(_c6, "RegisterPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/auth-page.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/auth/auth-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/auth/auth-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/auth/auth-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLFdBQVcsaUJBQWlCO0FBQzNDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG1CQUFtQjtBQUU1QixTQUFTLGFBQWEsMEJBQTJDO0FBQ2pFLFNBQVMsY0FBYztBQUN2QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxRQUFRLGVBQWUsYUFBYSx5QkFBeUI7QUFDdEUsU0FBUyxpQkFBaUIsdUJBQXVCO0FBQ2pELFNBQVMsT0FBTyxnQkFBZ0I7QUFDaEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7Ozs7QUFFN0IsU0FBUyxxQkFBcUI7O0NBQzVCLE1BQU0sU0FBUyxVQUFVLEVBQUUsUUFBUSxNQUFNLENBQUM7Q0FDMUMsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxjQUFjLGFBQWEsT0FBTyxRQUFRO0NBQ2hELE9BQU87RUFBRTtFQUFhLFFBQVEsT0FBTyxXQUE4QztHQUNqRixNQUFNLGFBQWEsT0FBTyxPQUFPLE9BQU8sT0FBTztHQUMvQyxNQUFNLE9BQU8sV0FBVztHQUN4QixNQUFNLE9BQU8sU0FBUztJQUFFLE1BQU07SUFBYSxTQUFTO0dBQUssQ0FBQztFQUM1RDtDQUFFO0FBQ0o7Ozs7QUFDQSxTQUFTLFdBQVcsRUFBRSxJQUFJLFdBQTZDO0NBQUUsT0FBTyxVQUFVLHdCQUFDLEtBQUQ7RUFBTztFQUFJLFdBQVU7WUFBZTtDQUFXOzs7O1lBQUk7QUFBSzs7QUFDbEosU0FBUyxZQUFZOztDQUNuQixNQUFNLEVBQUUsV0FBVyxtQkFBbUI7Q0FDdEMsTUFBTSxPQUFPLFFBQW9CO0VBQUUsVUFBVSxZQUFZLFdBQVc7RUFBRyxlQUFlO0dBQUUsT0FBTztHQUFJLFVBQVU7RUFBRztDQUFFLENBQUM7Q0FDbkgsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxXQUFXLFlBQVk7RUFBRSxZQUFZO0VBQU8sT0FBTztFQUFPLFdBQVc7RUFBUSxVQUFTLFVBQVM7R0FDbkcsSUFBSSxpQkFBaUIsbUJBQW1CLE1BQU0sUUFBUSxPQUFPLEtBQUssU0FBUyxTQUFTLEVBQUUsU0FBUyxNQUFNLE9BQU8sTUFBTSxHQUFHLENBQUM7RUFDeEg7Q0FBRSxDQUFDO0NBQ0gsT0FBTyx3QkFBQyxRQUFEO0VBQU07RUFBVyxVQUFVLEtBQUssY0FBYSxXQUFVLFNBQVMsT0FBTyxNQUFNLENBQUM7RUFBRyxXQUFVO0VBQVksY0FBVztZQUFsSDtHQUNMLHdCQUFDLFNBQUQ7SUFBTyxTQUFRO2NBQWM7R0FBYTs7Ozs7R0FBQyx3QkFBQyxPQUFEO0lBQU8sSUFBRztJQUFjLE1BQUs7SUFBUSxjQUFhO0lBQVEsR0FBSSxLQUFLLFNBQVMsT0FBTztJQUFHLGdCQUFjLENBQUMsQ0FBQyxLQUFLLFVBQVUsT0FBTztJQUFPLG9CQUFpQjtHQUFxQjs7Ozs7R0FDcE4sd0JBQUMsWUFBRDtJQUFZLElBQUc7SUFBb0IsU0FBUyxLQUFLLFVBQVUsT0FBTyxPQUFPO0dBQVU7Ozs7O0dBQ25GLHdCQUFDLFNBQUQ7SUFBTyxTQUFRO2NBQWlCO0dBQVk7Ozs7O0dBQUMsd0JBQUMsT0FBRDtJQUFPLElBQUc7SUFBaUIsTUFBTSxPQUFPLFNBQVM7SUFBWSxjQUFhO0lBQW1CLEdBQUksS0FBSyxTQUFTLFVBQVU7SUFBRyxnQkFBYyxDQUFDLENBQUMsS0FBSyxVQUFVLE9BQU87SUFBVSxvQkFBaUI7R0FBd0I7Ozs7O0dBQ2xRLHdCQUFDLFlBQUQ7SUFBWSxJQUFHO0lBQXVCLFNBQVMsS0FBSyxVQUFVLE9BQU8sVUFBVTtHQUFVOzs7OztHQUN6Rix3QkFBQyxRQUFEO0lBQVEsTUFBSztJQUFTLFNBQVE7SUFBTyxlQUFlLFFBQVEsQ0FBQyxJQUFJO2NBQUksT0FBTyxrQkFBa0I7R0FBd0I7Ozs7O0dBQ3JILFNBQVMsV0FBVyx3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFTLGdCQUFnQixTQUFTLEtBQUs7R0FBSzs7Ozs7R0FDekUsd0JBQUMsUUFBRDtJQUFRLE1BQUs7SUFBUyxVQUFVLFNBQVM7Y0FBWSxTQUFTLFlBQVksY0FBYztHQUFpQjs7Ozs7RUFDckc7Ozs7OztBQUNSOzs7Ozs7Ozs7QUFDQSxTQUFTLGVBQWU7O0NBQ3RCLE1BQU0sRUFBRSxXQUFXLG1CQUFtQjtDQUV0QyxNQUFNLE9BQU8sUUFBZ0I7RUFBRSxVQUFVLFlBQVksa0JBQWtCO0VBQUcsZUFBZTtHQUFFLE1BQU07R0FBSSxPQUFPO0dBQUksVUFBVTtHQUFJLGlCQUFpQjtFQUFHO0NBQUUsQ0FBQztDQUNySixNQUFNLFdBQVcsWUFBWTtFQUFFLGFBQWEsV0FBbUIsU0FBUztHQUFFLE1BQU0sT0FBTztHQUFNLE9BQU8sT0FBTztHQUFPLFVBQVUsT0FBTztFQUFTLENBQUM7RUFBRyxPQUFPO0VBQU8sV0FBVztFQUFRLFVBQVMsVUFBUztHQUNqTSxJQUFJLGlCQUFpQixpQkFBaUI7U0FBSyxNQUFNLE9BQU87S0FBQztLQUFRO0tBQVM7SUFBVSxHQUFZLElBQUksTUFBTSxTQUFTLE1BQU0sS0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLE1BQU0sT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDOztFQUMvSztDQUFFLENBQUM7Q0FDSCxPQUFPLHdCQUFDLFFBQUQ7RUFBTTtFQUFXLFVBQVUsS0FBSyxjQUFhLFdBQVUsU0FBUyxPQUFPLE1BQU0sQ0FBQztFQUFHLFdBQVU7RUFBWSxjQUFXO1lBQWxIO0dBQ0g7SUFBQztJQUFRO0lBQVM7SUFBWTtHQUFpQixDQUFDLENBQVcsS0FBSSxRQUFPLHdCQUFDLE9BQUQ7SUFBZSxXQUFVO2NBQXpCO0tBQ3RFLHdCQUFDLFNBQUQ7TUFBTyxTQUFTLFlBQVk7Z0JBQVE7T0FBRSxNQUFNO09BQVEsT0FBTztPQUFVLFVBQVU7T0FBUyxpQkFBaUI7TUFBa0IsRUFBRTtLQUFZOzs7OztLQUN6SSx3QkFBQyxPQUFEO01BQU8sSUFBSSxZQUFZO01BQU8sTUFBTSxRQUFRLFVBQVUsVUFBVSxJQUFJLFNBQVMsU0FBUyxJQUFJLGFBQWE7TUFBUSxjQUFjLElBQUksU0FBUyxTQUFTLElBQUksaUJBQWlCLFFBQVEsU0FBUyxTQUFTO01BQVMsR0FBSSxLQUFLLFNBQVMsR0FBRztNQUFHLGdCQUFjLENBQUMsQ0FBQyxLQUFLLFVBQVUsT0FBTztNQUFNLG9CQUFrQixZQUFZLElBQUk7S0FBVTs7Ozs7S0FDM1Qsd0JBQUMsWUFBRDtNQUFZLElBQUksWUFBWSxJQUFJO01BQVMsU0FBUyxLQUFLLFVBQVUsT0FBTyxJQUFJLEVBQUU7S0FBVTs7Ozs7SUFDckY7TUFKNkU7Ozs7VUFJN0UsQ0FBQztHQUNMLFNBQVMsV0FBVyx3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFTLGdCQUFnQixTQUFTLEtBQUs7R0FBSzs7Ozs7R0FDekUsd0JBQUMsUUFBRDtJQUFRLE1BQUs7SUFBUyxVQUFVLFNBQVM7Y0FBWSxTQUFTLFlBQVksbUJBQW1CO0dBQXNCOzs7OztFQUMvRzs7Ozs7O0FBQ1I7Ozs7Ozs7OztBQUNBLE9BQU8sU0FBUyxTQUFTLEVBQUUsUUFBd0M7O0NBQ2pFLE1BQU0sRUFBRSxnQkFBZ0IsbUJBQW1CO0NBQzNDLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE9BQU8sZ0RBQUUsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBb0Isd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBZTtFQUF5Qjs7Ozs7Q0FBTTs7OztXQUNyRyx3QkFBQyxRQUFEO0VBQVE7RUFBSyxlQUFjLFNBQVE7R0FBRSxJQUFJLENBQUMsTUFBTSxLQUFLLE9BQU8sU0FBUyxFQUFFLElBQUksSUFBSSxDQUFDO0VBQUU7WUFDaEYsd0JBQUMsZUFBRDtHQUFlLFdBQVU7YUFBekI7SUFDRSx3QkFBQyxhQUFELFlBQWMsU0FBUyxVQUFVLFVBQVUsV0FBd0I7Ozs7O0lBQ25FLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWEsY0FBVztlQUF2QyxDQUF3RCx3QkFBQyxNQUFEO01BQU0sSUFBRztNQUFTLFFBQVEsRUFBRSxVQUFVLFlBQVk7Z0JBQUc7S0FBWTs7OztlQUFDLHdCQUFDLE1BQUQ7TUFBTSxJQUFHO01BQVksUUFBUSxFQUFFLFVBQVUsWUFBWTtnQkFBRztLQUFpQjs7OzthQUFNOzs7Ozs7SUFDek0sd0JBQUMsbUJBQUQsWUFBb0IsU0FBUyxVQUFVLGlEQUFpRCxtQ0FBc0Q7Ozs7O0lBQzdJLFNBQVMsVUFBVSx3QkFBQyxXQUFELENBQVk7Ozs7ZUFBSSx3QkFBQyxjQUFELENBQWU7Ozs7O0lBQ25ELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdDO0lBQXlFOzs7OztHQUN6Rzs7Ozs7O0NBQ1Q7Ozs7U0FDUjs7Ozs7QUFDSjs7Ozs7QUFDQSxPQUFPLFNBQVMsWUFBWTtDQUFFLE9BQU8sd0JBQUMsVUFBRCxFQUFVLE1BQUssUUFBUzs7Ozs7QUFBRTs7QUFDL0QsT0FBTyxTQUFTLGVBQWU7Q0FBRSxPQUFPLHdCQUFDLFVBQUQsRUFBVSxNQUFLLFdBQVk7Ozs7O0FBQUUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXV0aC1wYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluaywgdXNlUm91dGVyLCB1c2VTZWFyY2ggfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgdXNlTXV0YXRpb24gfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCdcbmltcG9ydCB0eXBlIHsgeiB9IGZyb20gJ3pvZCdcbmltcG9ydCB7IGxvZ2luU2NoZW1hLCByZWdpc3RlckZvcm1TY2hlbWEsIHR5cGUgTG9naW5JbnB1dCB9IGZyb20gJ0AvY29udHJhY3RzL2F1dGgnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ0NvbnRlbnQsIERpYWxvZ1RpdGxlLCBEaWFsb2dEZXNjcmlwdGlvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9kaWFsb2cnXG5pbXBvcnQgeyBhcGlFcnJvck1lc3NhZ2UsIEFwaVJlcXVlc3RFcnJvciB9IGZyb20gJ0AvbGliL2FwaSdcbmltcG9ydCB7IGxvZ2luLCByZWdpc3RlciB9IGZyb20gJy4vYXBpJ1xuaW1wb3J0IHsgYWRvcHRTZXNzaW9uIH0gZnJvbSAnLi9saWZlY3ljbGUnXG5pbXBvcnQgeyBzYWZlUmV0dXJuVG8gfSBmcm9tICcuL3JlZGlyZWN0J1xuXG5mdW5jdGlvbiB1c2VBdXRoRGVzdGluYXRpb24oKSB7XG4gIGNvbnN0IHNlYXJjaCA9IHVzZVNlYXJjaCh7IHN0cmljdDogZmFsc2UgfSkgYXMgeyByZWRpcmVjdD86IHN0cmluZyB9XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IGRlc3RpbmF0aW9uID0gc2FmZVJldHVyblRvKHNlYXJjaC5yZWRpcmVjdClcbiAgcmV0dXJuIHsgZGVzdGluYXRpb24sIGZpbmlzaDogYXN5bmMgKHJlc3VsdDogQXdhaXRlZDxSZXR1cm5UeXBlPHR5cGVvZiBsb2dpbj4+KSA9PiB7XG4gICAgYXdhaXQgYWRvcHRTZXNzaW9uKHJlc3VsdC50b2tlbiwgcmVzdWx0LnNlc3Npb24pXG4gICAgYXdhaXQgcm91dGVyLmludmFsaWRhdGUoKVxuICAgIGF3YWl0IHJvdXRlci5uYXZpZ2F0ZSh7IGhyZWY6IGRlc3RpbmF0aW9uLCByZXBsYWNlOiB0cnVlIH0pXG4gIH0gfVxufVxuZnVuY3Rpb24gRmllbGRFcnJvcih7IGlkLCBtZXNzYWdlIH06IHsgaWQ6IHN0cmluZzsgbWVzc2FnZT86IHN0cmluZyB9KSB7IHJldHVybiBtZXNzYWdlID8gPHAgaWQ9e2lkfSBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPnttZXNzYWdlfTwvcD4gOiBudWxsIH1cbmZ1bmN0aW9uIExvZ2luRm9ybSgpIHtcbiAgY29uc3QgeyBmaW5pc2ggfSA9IHVzZUF1dGhEZXN0aW5hdGlvbigpXG4gIGNvbnN0IGZvcm0gPSB1c2VGb3JtPExvZ2luSW5wdXQ+KHsgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGxvZ2luU2NoZW1hKSwgZGVmYXVsdFZhbHVlczogeyBlbWFpbDogJycsIHBhc3N3b3JkOiAnJyB9IH0pXG4gIGNvbnN0IFtzaG93LCBzZXRTaG93XSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBtdXRhdGlvbiA9IHVzZU11dGF0aW9uKHsgbXV0YXRpb25GbjogbG9naW4sIHJldHJ5OiBmYWxzZSwgb25TdWNjZXNzOiBmaW5pc2gsIG9uRXJyb3I6IGVycm9yID0+IHtcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBBcGlSZXF1ZXN0RXJyb3IgJiYgZXJyb3IuZmllbGRzPy5lbWFpbCkgZm9ybS5zZXRFcnJvcignZW1haWwnLCB7IG1lc3NhZ2U6IGVycm9yLmZpZWxkcy5lbWFpbFswXSB9KVxuICB9IH0pXG4gIHJldHVybiA8Zm9ybSBub1ZhbGlkYXRlIG9uU3VibWl0PXtmb3JtLmhhbmRsZVN1Ym1pdCh2YWx1ZXMgPT4gbXV0YXRpb24ubXV0YXRlKHZhbHVlcykpfSBjbGFzc05hbWU9XCJhdXRoLWZvcm1cIiBhcmlhLWxhYmVsPVwiRW50cmFyIG5hIGNvbnRhXCI+XG4gICAgPGxhYmVsIGh0bWxGb3I9XCJsb2dpbi1lbWFpbFwiPkUtbWFpbDwvbGFiZWw+PElucHV0IGlkPVwibG9naW4tZW1haWxcIiB0eXBlPVwiZW1haWxcIiBhdXRvQ29tcGxldGU9XCJlbWFpbFwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdlbWFpbCcpfSBhcmlhLWludmFsaWQ9eyEhZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmVtYWlsfSBhcmlhLWRlc2NyaWJlZGJ5PVwibG9naW4tZW1haWwtZXJyb3JcIiAvPlxuICAgIDxGaWVsZEVycm9yIGlkPVwibG9naW4tZW1haWwtZXJyb3JcIiBtZXNzYWdlPXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuZW1haWw/Lm1lc3NhZ2V9IC8+XG4gICAgPGxhYmVsIGh0bWxGb3I9XCJsb2dpbi1wYXNzd29yZFwiPlNlbmhhPC9sYWJlbD48SW5wdXQgaWQ9XCJsb2dpbi1wYXNzd29yZFwiIHR5cGU9e3Nob3cgPyAndGV4dCcgOiAncGFzc3dvcmQnfSBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCIgey4uLmZvcm0ucmVnaXN0ZXIoJ3Bhc3N3b3JkJyl9IGFyaWEtaW52YWxpZD17ISFmb3JtLmZvcm1TdGF0ZS5lcnJvcnMucGFzc3dvcmR9IGFyaWEtZGVzY3JpYmVkYnk9XCJsb2dpbi1wYXNzd29yZC1lcnJvclwiIC8+XG4gICAgPEZpZWxkRXJyb3IgaWQ9XCJsb2dpbi1wYXNzd29yZC1lcnJvclwiIG1lc3NhZ2U9e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5wYXNzd29yZD8ubWVzc2FnZX0gLz5cbiAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwibGlua1wiIG9uQ2xpY2s9eygpID0+IHNldFNob3coIXNob3cpfT57c2hvdyA/ICdPY3VsdGFyIHNlbmhhJyA6ICdNb3N0cmFyIHNlbmhhJ308L0J1dHRvbj5cbiAgICB7bXV0YXRpb24uaXNFcnJvciAmJiA8cCByb2xlPVwiYWxlcnRcIj57YXBpRXJyb3JNZXNzYWdlKG11dGF0aW9uLmVycm9yKX08L3A+fVxuICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXttdXRhdGlvbi5pc1BlbmRpbmd9PnttdXRhdGlvbi5pc1BlbmRpbmcgPyAnRW50cmFuZG/igKYnIDogJ0VudHJhcid9PC9CdXR0b24+XG4gIDwvZm9ybT5cbn1cbmZ1bmN0aW9uIFJlZ2lzdGVyRm9ybSgpIHtcbiAgY29uc3QgeyBmaW5pc2ggfSA9IHVzZUF1dGhEZXN0aW5hdGlvbigpXG4gIHR5cGUgVmFsdWVzID0gei5pbmZlcjx0eXBlb2YgcmVnaXN0ZXJGb3JtU2NoZW1hPlxuICBjb25zdCBmb3JtID0gdXNlRm9ybTxWYWx1ZXM+KHsgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHJlZ2lzdGVyRm9ybVNjaGVtYSksIGRlZmF1bHRWYWx1ZXM6IHsgbmFtZTogJycsIGVtYWlsOiAnJywgcGFzc3dvcmQ6ICcnLCBjb25maXJtUGFzc3dvcmQ6ICcnIH0gfSlcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7IG11dGF0aW9uRm46ICh2YWx1ZXM6IFZhbHVlcykgPT4gcmVnaXN0ZXIoeyBuYW1lOiB2YWx1ZXMubmFtZSwgZW1haWw6IHZhbHVlcy5lbWFpbCwgcGFzc3dvcmQ6IHZhbHVlcy5wYXNzd29yZCB9KSwgcmV0cnk6IGZhbHNlLCBvblN1Y2Nlc3M6IGZpbmlzaCwgb25FcnJvcjogZXJyb3IgPT4ge1xuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEFwaVJlcXVlc3RFcnJvcikgZm9yIChjb25zdCBrZXkgb2YgWyduYW1lJywgJ2VtYWlsJywgJ3Bhc3N3b3JkJ10gYXMgY29uc3QpIGlmIChlcnJvci5maWVsZHM/LltrZXldKSBmb3JtLnNldEVycm9yKGtleSwgeyBtZXNzYWdlOiBlcnJvci5maWVsZHNba2V5XVswXSB9KVxuICB9IH0pXG4gIHJldHVybiA8Zm9ybSBub1ZhbGlkYXRlIG9uU3VibWl0PXtmb3JtLmhhbmRsZVN1Ym1pdCh2YWx1ZXMgPT4gbXV0YXRpb24ubXV0YXRlKHZhbHVlcykpfSBjbGFzc05hbWU9XCJhdXRoLWZvcm1cIiBhcmlhLWxhYmVsPVwiQ3JpYXIgY29udGFcIj5cbiAgICB7KFsnbmFtZScsICdlbWFpbCcsICdwYXNzd29yZCcsICdjb25maXJtUGFzc3dvcmQnXSBhcyBjb25zdCkubWFwKGtleSA9PiA8ZGl2IGtleT17a2V5fSBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgIDxsYWJlbCBodG1sRm9yPXtgcmVnaXN0ZXItJHtrZXl9YH0+e3sgbmFtZTogJ05vbWUnLCBlbWFpbDogJ0UtbWFpbCcsIHBhc3N3b3JkOiAnU2VuaGEnLCBjb25maXJtUGFzc3dvcmQ6ICdDb25maXJtYXIgc2VuaGEnIH1ba2V5XX08L2xhYmVsPlxuICAgICAgPElucHV0IGlkPXtgcmVnaXN0ZXItJHtrZXl9YH0gdHlwZT17a2V5ID09PSAnZW1haWwnID8gJ2VtYWlsJyA6IGtleS5pbmNsdWRlcygnYXNzd29yZCcpID8gJ3Bhc3N3b3JkJyA6ICd0ZXh0J30gYXV0b0NvbXBsZXRlPXtrZXkuaW5jbHVkZXMoJ2Fzc3dvcmQnKSA/ICduZXctcGFzc3dvcmQnIDoga2V5ID09PSAnbmFtZScgPyAnbmFtZScgOiAnZW1haWwnfSB7Li4uZm9ybS5yZWdpc3RlcihrZXkpfSBhcmlhLWludmFsaWQ9eyEhZm9ybS5mb3JtU3RhdGUuZXJyb3JzW2tleV19IGFyaWEtZGVzY3JpYmVkYnk9e2ByZWdpc3Rlci0ke2tleX0tZXJyb3JgfSAvPlxuICAgICAgPEZpZWxkRXJyb3IgaWQ9e2ByZWdpc3Rlci0ke2tleX0tZXJyb3JgfSBtZXNzYWdlPXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnNba2V5XT8ubWVzc2FnZX0gLz5cbiAgICA8L2Rpdj4pfVxuICAgIHttdXRhdGlvbi5pc0Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiPnthcGlFcnJvck1lc3NhZ2UobXV0YXRpb24uZXJyb3IpfTwvcD59XG4gICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e211dGF0aW9uLmlzUGVuZGluZ30+e211dGF0aW9uLmlzUGVuZGluZyA/ICdDcmlhbmRvIGNvbnRh4oCmJyA6ICdDcmlhciBjb250YSd9PC9CdXR0b24+XG4gIDwvZm9ybT5cbn1cbmV4cG9ydCBmdW5jdGlvbiBBdXRoUGFnZSh7IG1vZGUgfTogeyBtb2RlOiAnbG9naW4nIHwgJ3JlZ2lzdGVyJyB9KSB7XG4gIGNvbnN0IHsgZGVzdGluYXRpb24gfSA9IHVzZUF1dGhEZXN0aW5hdGlvbigpXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIHJldHVybiA8PjxkaXYgY2xhc3NOYW1lPVwicHktMTIgdGV4dC1jZW50ZXJcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIj5LVVJJTyDCtyBDT0xFQ0lPTkFET1JFUzwvcD48L2Rpdj5cbiAgICA8RGlhbG9nIG9wZW4gb25PcGVuQ2hhbmdlPXtvcGVuID0+IHsgaWYgKCFvcGVuKSB2b2lkIHJvdXRlci5uYXZpZ2F0ZSh7IHRvOiAnLycgfSkgfX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJrdXJpby10aGVtZSBhdXRoLWNhcmRcIj5cbiAgICAgICAgPERpYWxvZ1RpdGxlPnttb2RlID09PSAnbG9naW4nID8gJ0xvZ2luJyA6ICdDYWRhc3Rybyd9PC9EaWFsb2dUaXRsZT5cbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCIgYXJpYS1sYWJlbD1cIkFjZXNzbyDDoCBjb250YVwiPjxMaW5rIHRvPVwiL2xvZ2luXCIgc2VhcmNoPXt7IHJlZGlyZWN0OiBkZXN0aW5hdGlvbiB9fT5FbnRyYXI8L0xpbms+PExpbmsgdG89XCIvY2FkYXN0cm9cIiBzZWFyY2g9e3sgcmVkaXJlY3Q6IGRlc3RpbmF0aW9uIH19PkNyaWFyIGNvbnRhPC9MaW5rPjwvbmF2PlxuICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+e21vZGUgPT09ICdsb2dpbicgPyAnRW50cmUgcGFyYSBnZXJlbmNpYXIgc3VhIGNhcnRlaXJhIGUgY29sZcOnw6NvLicgOiAnQ3JpZSBzZXUgcGVyZmlsIGRlIGNvbGVjaW9uYWRvci4nfTwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIHttb2RlID09PSAnbG9naW4nID8gPExvZ2luRm9ybSAvPiA6IDxSZWdpc3RlckZvcm0gLz59XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+TG9naW4gc29jaWFsIGUgcmVjdXBlcmHDp8OjbyBkZSBzZW5oYSBuw6NvIGVzdMOjbyBkaXNwb27DrXZlaXMgbmVzdGEgZXRhcGEuPC9wPlxuICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgIDwvRGlhbG9nPlxuICA8Lz5cbn1cbmV4cG9ydCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7IHJldHVybiA8QXV0aFBhZ2UgbW9kZT1cImxvZ2luXCIgLz4gfVxuZXhwb3J0IGZ1bmN0aW9uIFJlZ2lzdGVyUGFnZSgpIHsgcmV0dXJuIDxBdXRoUGFnZSBtb2RlPVwicmVnaXN0ZXJcIiAvPiB9XG4iXX0=