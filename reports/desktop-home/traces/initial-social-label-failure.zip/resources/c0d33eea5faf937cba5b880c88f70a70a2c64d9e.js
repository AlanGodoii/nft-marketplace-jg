import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/button.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Button as ButtonPrimitive } from "/node_modules/.vite/deps/@base-ui_react_button.js?v=22c23eb4";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=22c23eb4";
import { cn } from "/node_modules/.vite/deps/cn.js?v=22c23eb4";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/ui/button.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
const buttonVariants = cva("group/button inline-flex shrink-0 items-center justify-center rounded-lg border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/80",
			outline: "border-border bg-background hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:border-input dark:bg-input/30 dark:hover:bg-input/50",
			secondary: "bg-secondary text-secondary-foreground hover:bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)] aria-expanded:bg-secondary aria-expanded:text-secondary-foreground",
			ghost: "hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:hover:bg-muted/50",
			destructive: "bg-destructive/10 text-destructive hover:bg-destructive/20 focus-visible:border-destructive/40 focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:hover:bg-destructive/30 dark:focus-visible:ring-destructive/40",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-8 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			xs: "h-6 gap-1 rounded-[min(var(--radius-md),10px)] px-2 text-xs in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",
			sm: "h-7 gap-1 rounded-[min(var(--radius-md),12px)] px-2.5 text-[0.8rem] in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3.5",
			lg: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
			icon: "size-8",
			"icon-xs": "size-6 rounded-[min(var(--radius-md),10px)] in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3",
			"icon-sm": "size-7 rounded-[min(var(--radius-md),12px)] in-data-[slot=button-group]:rounded-lg",
			"icon-lg": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant = "default", size = "default", ...props }) {
	return /* @__PURE__ */ _jsxDEV(ButtonPrimitive, {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 5
	}, this);
}
_c = Button;
export { Button, buttonVariants };
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/ui/button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/ui/button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/ui/button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLHVCQUF1QjtBQUMxQyxTQUFTLFdBQThCO0FBQ3ZDLFNBQVMsVUFBVTs7O0FBRW5CLE1BQU0saUJBQWlCLElBQ3JCLDhsQkFDQTtDQUNFLFVBQVU7RUFDUixTQUFTO0dBQ1AsU0FBUztHQUNULFNBQ0U7R0FDRixXQUNFO0dBQ0YsT0FDRTtHQUNGLGFBQ0U7R0FDRixNQUFNO0VBQ1I7RUFDQSxNQUFNO0dBQ0osU0FDRTtHQUNGLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLE1BQU07R0FDTixXQUNFO0dBQ0YsV0FDRTtHQUNGLFdBQVc7RUFDYjtDQUNGO0NBQ0EsaUJBQWlCO0VBQ2YsU0FBUztFQUNULE1BQU07Q0FDUjtBQUNGLENBQ0Y7QUFFQSxTQUFTLE9BQU8sRUFDZCxXQUNBLFVBQVUsV0FDVixPQUFPLFdBQ1AsR0FBRyxTQUMyRDtDQUM5RCxPQUNFLHdCQUFDLGlCQUFEO0VBQ0UsYUFBVTtFQUNWLFdBQVcsR0FBRyxlQUFlO0dBQUU7R0FBUztHQUFNO0VBQVUsQ0FBQyxDQUFDO0VBQzFELEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLFFBQVEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYnV0dG9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24gYXMgQnV0dG9uUHJpbWl0aXZlIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L2J1dHRvblwiXG5pbXBvcnQgeyBjdmEsIHR5cGUgVmFyaWFudFByb3BzIH0gZnJvbSBcImNsYXNzLXZhcmlhbmNlLWF1dGhvcml0eVwiXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJjblwiXG5cbmNvbnN0IGJ1dHRvblZhcmlhbnRzID0gY3ZhKFxuICBcImdyb3VwL2J1dHRvbiBpbmxpbmUtZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGJnLWNsaXAtcGFkZGluZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHdoaXRlc3BhY2Utbm93cmFwIHRyYW5zaXRpb24tYWxsIG91dGxpbmUtbm9uZSBzZWxlY3Qtbm9uZSBmb2N1cy12aXNpYmxlOmJvcmRlci1yaW5nIGZvY3VzLXZpc2libGU6cmluZy0zIGZvY3VzLXZpc2libGU6cmluZy1yaW5nLzUwIGFjdGl2ZTpub3QtYXJpYS1baGFzcG9wdXBdOnRyYW5zbGF0ZS15LXB4IGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGlzYWJsZWQ6b3BhY2l0eS01MCBhcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlIGFyaWEtaW52YWxpZDpyaW5nLTMgYXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvMjAgZGFyazphcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlLzUwIGRhcms6YXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvNDAgWyZfc3ZnXTpwb2ludGVyLWV2ZW50cy1ub25lIFsmX3N2Z106c2hyaW5rLTAgWyZfc3ZnOm5vdChbY2xhc3MqPSdzaXplLSddKV06c2l6ZS00XCIsXG4gIHtcbiAgICB2YXJpYW50czoge1xuICAgICAgdmFyaWFudDoge1xuICAgICAgICBkZWZhdWx0OiBcImJnLXByaW1hcnkgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgaG92ZXI6YmctcHJpbWFyeS84MFwiLFxuICAgICAgICBvdXRsaW5lOlxuICAgICAgICAgIFwiYm9yZGVyLWJvcmRlciBiZy1iYWNrZ3JvdW5kIGhvdmVyOmJnLW11dGVkIGhvdmVyOnRleHQtZm9yZWdyb3VuZCBhcmlhLWV4cGFuZGVkOmJnLW11dGVkIGFyaWEtZXhwYW5kZWQ6dGV4dC1mb3JlZ3JvdW5kIGRhcms6Ym9yZGVyLWlucHV0IGRhcms6YmctaW5wdXQvMzAgZGFyazpob3ZlcjpiZy1pbnB1dC81MFwiLFxuICAgICAgICBzZWNvbmRhcnk6XG4gICAgICAgICAgXCJiZy1zZWNvbmRhcnkgdGV4dC1zZWNvbmRhcnktZm9yZWdyb3VuZCBob3ZlcjpiZy1bY29sb3ItbWl4KGluX29rbGNoLHZhcigtLXNlY29uZGFyeSksdmFyKC0tZm9yZWdyb3VuZClfNSUpXSBhcmlhLWV4cGFuZGVkOmJnLXNlY29uZGFyeSBhcmlhLWV4cGFuZGVkOnRleHQtc2Vjb25kYXJ5LWZvcmVncm91bmRcIixcbiAgICAgICAgZ2hvc3Q6XG4gICAgICAgICAgXCJob3ZlcjpiZy1tdXRlZCBob3Zlcjp0ZXh0LWZvcmVncm91bmQgYXJpYS1leHBhbmRlZDpiZy1tdXRlZCBhcmlhLWV4cGFuZGVkOnRleHQtZm9yZWdyb3VuZCBkYXJrOmhvdmVyOmJnLW11dGVkLzUwXCIsXG4gICAgICAgIGRlc3RydWN0aXZlOlxuICAgICAgICAgIFwiYmctZGVzdHJ1Y3RpdmUvMTAgdGV4dC1kZXN0cnVjdGl2ZSBob3ZlcjpiZy1kZXN0cnVjdGl2ZS8yMCBmb2N1cy12aXNpYmxlOmJvcmRlci1kZXN0cnVjdGl2ZS80MCBmb2N1cy12aXNpYmxlOnJpbmctZGVzdHJ1Y3RpdmUvMjAgZGFyazpiZy1kZXN0cnVjdGl2ZS8yMCBkYXJrOmhvdmVyOmJnLWRlc3RydWN0aXZlLzMwIGRhcms6Zm9jdXMtdmlzaWJsZTpyaW5nLWRlc3RydWN0aXZlLzQwXCIsXG4gICAgICAgIGxpbms6IFwidGV4dC1wcmltYXJ5IHVuZGVybGluZS1vZmZzZXQtNCBob3Zlcjp1bmRlcmxpbmVcIixcbiAgICAgIH0sXG4gICAgICBzaXplOiB7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgXCJoLTggZ2FwLTEuNSBweC0yLjUgaGFzLWRhdGEtW2ljb249aW5saW5lLWVuZF06cHItMiBoYXMtZGF0YS1baWNvbj1pbmxpbmUtc3RhcnRdOnBsLTJcIixcbiAgICAgICAgeHM6IFwiaC02IGdhcC0xIHJvdW5kZWQtW21pbih2YXIoLS1yYWRpdXMtbWQpLDEwcHgpXSBweC0yIHRleHQteHMgaW4tZGF0YS1bc2xvdD1idXR0b24tZ3JvdXBdOnJvdW5kZWQtbGcgaGFzLWRhdGEtW2ljb249aW5saW5lLWVuZF06cHItMS41IGhhcy1kYXRhLVtpY29uPWlubGluZS1zdGFydF06cGwtMS41IFsmX3N2Zzpub3QoW2NsYXNzKj0nc2l6ZS0nXSldOnNpemUtM1wiLFxuICAgICAgICBzbTogXCJoLTcgZ2FwLTEgcm91bmRlZC1bbWluKHZhcigtLXJhZGl1cy1tZCksMTJweCldIHB4LTIuNSB0ZXh0LVswLjhyZW1dIGluLWRhdGEtW3Nsb3Q9YnV0dG9uLWdyb3VwXTpyb3VuZGVkLWxnIGhhcy1kYXRhLVtpY29uPWlubGluZS1lbmRdOnByLTEuNSBoYXMtZGF0YS1baWNvbj1pbmxpbmUtc3RhcnRdOnBsLTEuNSBbJl9zdmc6bm90KFtjbGFzcyo9J3NpemUtJ10pXTpzaXplLTMuNVwiLFxuICAgICAgICBsZzogXCJoLTkgZ2FwLTEuNSBweC0yLjUgaGFzLWRhdGEtW2ljb249aW5saW5lLWVuZF06cHItMiBoYXMtZGF0YS1baWNvbj1pbmxpbmUtc3RhcnRdOnBsLTJcIixcbiAgICAgICAgaWNvbjogXCJzaXplLThcIixcbiAgICAgICAgXCJpY29uLXhzXCI6XG4gICAgICAgICAgXCJzaXplLTYgcm91bmRlZC1bbWluKHZhcigtLXJhZGl1cy1tZCksMTBweCldIGluLWRhdGEtW3Nsb3Q9YnV0dG9uLWdyb3VwXTpyb3VuZGVkLWxnIFsmX3N2Zzpub3QoW2NsYXNzKj0nc2l6ZS0nXSldOnNpemUtM1wiLFxuICAgICAgICBcImljb24tc21cIjpcbiAgICAgICAgICBcInNpemUtNyByb3VuZGVkLVttaW4odmFyKC0tcmFkaXVzLW1kKSwxMnB4KV0gaW4tZGF0YS1bc2xvdD1idXR0b24tZ3JvdXBdOnJvdW5kZWQtbGdcIixcbiAgICAgICAgXCJpY29uLWxnXCI6IFwic2l6ZS05XCIsXG4gICAgICB9LFxuICAgIH0sXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiBcImRlZmF1bHRcIixcbiAgICAgIHNpemU6IFwiZGVmYXVsdFwiLFxuICAgIH0sXG4gIH1cbilcblxuZnVuY3Rpb24gQnV0dG9uKHtcbiAgY2xhc3NOYW1lLFxuICB2YXJpYW50ID0gXCJkZWZhdWx0XCIsXG4gIHNpemUgPSBcImRlZmF1bHRcIixcbiAgLi4ucHJvcHNcbn06IEJ1dHRvblByaW1pdGl2ZS5Qcm9wcyAmIFZhcmlhbnRQcm9wczx0eXBlb2YgYnV0dG9uVmFyaWFudHM+KSB7XG4gIHJldHVybiAoXG4gICAgPEJ1dHRvblByaW1pdGl2ZVxuICAgICAgZGF0YS1zbG90PVwiYnV0dG9uXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oYnV0dG9uVmFyaWFudHMoeyB2YXJpYW50LCBzaXplLCBjbGFzc05hbWUgfSkpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IHsgQnV0dG9uLCBidXR0b25WYXJpYW50cyB9XG4iXX0=