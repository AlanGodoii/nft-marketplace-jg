// node_modules/cn/dist/tables.js
var P = 48;
var U = (s, o = 0) => {
	const out = new Int32Array(s.length);
	for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) - P - o;
	return out;
};
var PS = (counts) => {
	const out = new Int32Array(counts.length + 1);
	for (let i = 0; i < counts.length; i++) out[i + 1] = out[i] + counts[i];
	return out;
};
var DZ = (s) => {
	const out = new Int32Array(s.length);
	let a = 0;
	for (let i = 0; i < s.length; i++) {
		const z = s.charCodeAt(i) - P;
		a += z >>> 1 ^ -(z & 1);
		out[i] = a;
	}
	return out;
};
var GROUP_COUNT = 384;
var customValidatorNames = [];
var edgeStart = PS(U("E0500002005282000000002000150000020021820000011200000003022202000300004200120000200420001200021200301200010400162000010000220021010:2192001200220012000220012000200200200400010200040000000000400200108200110100000022010313000162002000020020012020080213000228200000000082000000000120002000120020020040101020300130001001010"));
var labelStart = PS(U(":11111111211111119311546544411119731869:671397415686432441111111111161114151214313433415:78311132233313187211117221449443411141111151152226611131111112212518142224214215421421542142424242516171151615616347111111111197911327451111111111111111111113134714133513411111311111111111111111111112444411111342312715245411117:3"));
var labelText = "@containerabcdefghinlmoprstunderlineviawzccentlignnimatespectuto-colsrowsaglorightnessckdrop-sisbcontrastfiltergrayscalehue-rotateinvertopacityslurrightnessaturateepia-coniclinearpositionradialsizeockurrderttom-belrstxyespacing-xyaretoursorlnt-umnsendspantartainentrasteividerop-shadowurationcorationlay-xyasendillexontromlter-featuresstretchapr-xyayscaleidow-colsrowsue-rotatedentlinesetvert-beringsxyeshadoweiadingftnest-clamp-imageabein-lrstxyskx--b-coniclpositionrsizet-x-y-fromto-fromto-inearfromto-fromto-adialfromto-fromtofromtofromtofromtoblockhinlinew-screenesblockhinlinewbjectpacityrutlinederigin-offsetbelrstxyesrspective-originaceholderioghtng-offsettateundedw-xyz-belrstlreseslr-endspantartaturatecepiahizekewpace-taleroll-xyz-barmpbelrstxyesbelrstxyes-thumbrackadowrink-xyxyartrokeabextora-shadowpckingnsformitionlate-xyz-offsetill-changeoom";
var edgeTarget = (() => {
	const N = edgeStart.length - 1;
	const sizes = new Int32Array(N);
	for (let i = N - 1; i >= 0; i--) {
		let s = 1;
		let c = i + 1;
		for (let k = edgeStart[i]; k < edgeStart[i + 1]; k++) {
			s += sizes[c];
			c += sizes[c];
		}
		sizes[i] = s;
	}
	const out = new Int32Array(edgeStart[N]);
	let e = 0;
	for (let i = 0; i < N; i++) {
		let c = i + 1;
		for (let k = edgeStart[i]; k < edgeStart[i + 1]; k++) {
			out[e++] = c;
			c += sizes[c];
		}
	}
	return out;
})();
var nodeGroup = U("02000000000000900<=0?000B000F00F00ŏI0J0LNPRTVX0000]_a00000000000000000000000rst0000000zŏ00000000000ŏ0000000ŏ00000000000000000000000000000000000000000000000000000000000000Ë000000000000000000000Þ000000000000000000ð0000000ø0ùúûüýþÿĀāĂăĄąĆ000000000000000000000000000000000000000000ħ0ĨĪ00000000000000000000ļĽ00000Ŭ000000", 1);
var vlistPat = PS(U("123333359346463635126536711576"));
var vlistOps = U("93203242332583253248325D>E?F@03263243255B:032523853:0325B:8GA032542H<C=12727B:0328432553;D>E?3257D>032585:0325B:;0328B:032");
var vlistRef = U("012113445661666666789111:5;;;;;;;;444;;;:62999<1161=62>>?61:21@ABCD4446996:64E:::;:?::64:F114GHHIHHHHIHH1HH1HH1HHHHHH::EEJ4444::EE4444441691;644444114244444:;K6666555555555555555999666664444444444444444444444226?6:66644L9M?D:111::::6DE199");
var vlistGroup = DZ("020200202020020020020020020020200200200200200200200002020202001003040106000200200200200200200200200200200200200200200200200200200200200200200200200200200200020020020020020020002020200202002002002002002002002002002020002002020020200220200200200200200200200200200200020020020000200020002000200200200020020020002000200200200020020202002020202000200200020022000200200020020002002000200220002002000200W0Z00020020002002020002002000200g0j0002002000200200020020002002000200200020020002000200002000002002002002002000200020000200002002002002002002002020020020200200200200200200200200202020020020020020020020020002002002020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020020002002002002002002000200200200200200200200200200020202020002000200020002002002002000020200200");
var nodeVlist = (() => {
	const out = (/* @__PURE__ */ new Int32Array(319)).fill(-1);
	const A = DZ("02422242:222222242224222242442222222422222244442242226224222426222422442462222422622222222626222462242622422622422424242422222222422222222242422222222222222222622442224222222222222224424442262222222222222222222226224222424242422224422422422222");
	const V = DZ("02222222222222222222202222222222222222222222221422222222222222222222222222222222222Y\\222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222221422222222222222222222222222222222222222Ŀł222222222222222222");
	for (let i = 0; i < A.length; i++) out[A[i]] = V[i];
	return out;
})();
var SETS = "container |break-after- all auto avoid avoid-page column left page right|break-before- all auto avoid avoid-page column left page right|break-inside-a uto void void-column void-page|box-decoration- clone slice|box- border content| contents flow-root hidden table table-caption table-cell table-column table-column-group table-footer-group table-header-group table-row table-row-group| not-sr-only sr-only|float- end left none right start|clear- both end left none right start|isolat e ion-auto|overflow- auto clip hidden scroll visible|overflow-x- auto clip hidden scroll visible|overflow-y- auto clip hidden scroll visible|overscroll- auto contain none|overscroll-x- auto contain none|overscroll-y- auto contain none| absolute fixed relative static sticky| collapse invisible visible|justify- around baseline between center center-safe end end-safe evenly normal start stretch|justify-items- center center-safe end end-safe normal start stretch|justify-self- auto center center-safe end end-safe start stretch|items- baseline baseline-last center center-safe end end-safe start stretch|self- auto baseline baseline-last center center-safe end end-safe start stretch|place-content- around baseline between center center-safe end end-safe evenly start stretch|place-items- baseline center center-safe end end-safe start stretch|place-self- auto center center-safe end end-safe start stretch| antialiased subpixel-antialiased| italic not-italic|normal-nums |ordinal |slashed-zero | lining-nums oldstyle-nums| proportional-nums tabular-nums| diagonal-fractions stacked-fractions| no-underline overline| capitalize lowercase normal-case uppercase|truncate |whitespace- break-spaces normal nowrap pre pre-line pre-wrap|break- all keep normal words|wrap- anywhere break-word normal|hyphens- auto manual none|mix-blend- color color-burn color-dodge darken difference exclusion hard-light hue lighten luminosity multiply normal overlay plus-darker plus-lighter saturation screen soft-light|table- auto fixed|caption- bottom top|backface- hidden visible|appearance- auto none|scheme- dark light light-dark normal only-dark only-light|field-sizing- content fixed|pointer-events- auto none|resize  -none -x -y|snap- align-none center end start|snap- always normal|snap- both none x y|snap- mandatory proximity|touch- auto manipulation none|touch-pan- left right x|touch-pan- down up y|touch-pinch-zoom |select- all auto none text|forced-color-adjust- auto none| normal size| baseline bottom middle sub super text-bottom text-top top| bounce none ping pulse spin| auto square video| auto fr max min px|none | auto full px| fixed local scroll|clip- border content padding text|origin- border content padding| bottom bottom-left bottom-right center left left-bottom left-top right right-bottom right-top top top-left top-right| no-repeat repeat repeat-round repeat-space repeat-x repeat-y| auto contain cover|blend- color color-burn color-dodge darken difference exclusion hard-light hue lighten luminosity multiply normal overlay saturation screen soft-light|to- b bl br l r t tl tr| auto dvh fit full lh lvh max min px screen svh| dashed dotted double hidden none solid| collapse separate|px |auto |full | content none strict| inline-size size|layout |paint |style | around baseline between center center-safe end end-safe evenly normal start stretch| alias all-scroll auto cell col-resize context-menu copy crosshair default e-resize ew-resize grab grabbing help move n-resize ne-resize nesw-resize no-drop none not-allowed ns-resize nw-resize nwse-resize pointer progress row-resize s-resize se-resize sw-resize text vertical-text w-resize wait zoom-in zoom-out| dashed dotted double solid wavy| auto from-font|reverse |initial | in in-out initial linear out| col col-reverse row row-reverse| nowrap wrap wrap-reverse| auto initial none| black bold extrabold extralight light medium normal semibold thin| condensed expanded extra-condensed extra-expanded normal semi-condensed semi-expanded ultra-condensed ultra-expanded|flow- col col-dense dense row row-dense| none subgrid| auto dvh dvw fit full lh lvh lvw max min px screen svh svw| block flex grid table| auto dvw fit full lvw max min px screen svw| loose none normal px relaxed snug tight|through |item | inside outside| decimal disc none| auto px| clip-border clip-content clip-fill clip-padding clip-stroke clip-view no-clip| add exclude intersect subtract| alpha luminance match|origin- border content fill padding stroke view|type- alpha luminance| circle ellipse| closest-corner closest-side farthest-corner farthest-side|at- bottom bottom-left bottom-right center left left-bottom left-top right right-bottom right-top top top-left top-right| dvh fit full lh lvh max min none px screen svh| auto dvh dvw fit full lh lvh lvw max min none px screen svh svw| dvw fit full lvw max min none px screen svw| auto dvh dvw fit full lvh lvw max min none prose px svh svw| auto dvh dvw fit full lvh lvw max min none px screen svh svw| contain cover fill none scale-down| first last none| distant dramatic midrange near none normal|inset | full none|3d | auto smooth|gutter- auto both stable| auto none thin| inner none| auto dvh dvw fit full lvh lvw max min px svh svw|base | center end justify left right start| clip ellipsis| balance nowrap pretty wrap| normal tight tighter wide wider widest| cpu gpu none| 3d flat| all colors none opacity shadow transform| discrete normal| full px| auto dvh dvw fit full lvh lvw max min px screen svh svw| auto contents scroll transform".split("|").map((s) => {
	const tails = s.split(" ");
	const prefix = tails.shift();
	for (let i = 0; i < tails.length; i++) tails[i] = prefix + tails[i];
	return tails;
});
var AA = DZ("0000000000000000000000000000000000000000000000000000000000000262242:6@200000006:240B428:4422400002046044222426220026642642462026224222824220022400000000\\00N222422242222222224062242222222422226264222422222222222222442804222422222222222222222222220<4<0204260002444020204224422");
var AG = DZ("ɠ222222222222222222222222222222222222222222222222222222222222˕4222226>6ʰ22ʷʺʷʺʷ42ʴ2ʓ22>621422ɶ222ɹɼɷɺɷɺ22ɱ42222ɨ2ɧ26622ɘɓ244ƸƵ222]d24242ǖǓƚÄȫ2263ȨȥȨ2222222ǣ222222222222222222ǂƽ2ƾƵ2222222422222ƜƑ22222222222222222222144Ŧţ22Ţş222222222222222222222ĸ2ı68ĦģĦɡŰ4Ġ«®ĝ822ĔđĔ2ē2222622");
var AS = DZ("02222222222222222222222222222222222222222222222222222222222222222202021422222222CF2200GJ021042222WZ222IL0ad2c10h2222U00X202[^2w0000120zy|}22:22z22222222222G000qOVI00000{2<40000@00000G¦§000ª00000000000000021K¬«00®000000000000000000000222HGH_1¸222½2¾2222ÇÊ000­°2±");
var litAnchor = /* @__PURE__ */ new Int32Array(987);
var litGroup = /* @__PURE__ */ new Int32Array(987);
var litPool = /* @__PURE__ */ new Int32Array(987);
var poolText = "";
var poolOffsets = /* @__PURE__ */ new Int32Array(1022);
{
	const tailRef = /* @__PURE__ */ new Map();
	let nextRef = 0;
	let e = 0;
	for (let i = 0; i < AA.length; i++) for (const tail of SETS[AS[i]]) {
		let r = tailRef.get(tail);
		if (r === void 0) {
			r = nextRef++;
			tailRef.set(tail, r);
			poolOffsets[r * 2] = poolText.length;
			poolOffsets[r * 2 + 1] = tail.length;
			poolText += tail;
		}
		litAnchor[e] = AA[i];
		litGroup[e] = AG[i];
		litPool[e] = r;
		e++;
	}
}
var adjGid = DZ("0b2N:222@R>F@286¦2@H2D266226FB22B2>BD\\6N22222Z222D222p");
var adjStart = PS(U("1::24444432:442:44:44>222222:44:4421322511111311111114"));
var adjTgt = DZ("24A;33N=C@H4A;33N=C@<27;83:;8393NQ:3NQʰ222ˉºŴŽ2R2=18cƴÅŇ=cĞÛC1ƈǝȈ:ħ25=11D3A@4=<1;1DEr25;11B3?<6;:371BCn9@7=<8192>2E121@9@EHE@9>2T25511<398454131<=V25511<398454131<=ƧNž2Đå242L222290000f22500ɛ000ǘ222");
var patGid = U("ĳ");
var patTgt = U("");
var postfixLookupGroups = U("1");
var tables_generated_default = {
	GROUP_COUNT,
	customValidatorNames,
	edgeStart,
	labelStart,
	labelText,
	edgeTarget,
	nodeGroup,
	nodeVlist,
	vlistPat,
	vlistOps,
	vlistRef,
	vlistGroup,
	litAnchor,
	litGroup,
	litPool,
	poolOffsets,
	poolText,
	adjGid,
	adjStart,
	adjTgt,
	patGid,
	patTgt,
	postfixLookupGroups,
	orderSensitiveModifiers: "* ** after backdrop before details-content file first-letter first-line marker placeholder selection"
};
// node_modules/cn/dist/engine.js
var IS_JSC = "line" in /* @__PURE__ */ new Error();
var EXTERNAL = -1;
var DEAD = -1;
var fnv = (str, s, e) => {
	let h = 2166136261;
	for (let p = s; p < e; p++) h = Math.imul(h ^ str.charCodeAt(p), 16777619);
	return h;
};
var spanHash = (str, s, e) => {
	const len = e - s;
	let h = Math.imul(len, 2654435761) ^ str.charCodeAt(s);
	if (len > 3) {
		const q = len >> 2;
		const m = len >> 1;
		h = Math.imul(h ^ str.charCodeAt(s + 1) << 8 ^ str.charCodeAt(s + 2) << 16 ^ str.charCodeAt(s + q), 2246822507);
		h = Math.imul(h ^ str.charCodeAt(s + m) << 8 ^ str.charCodeAt(s + m + q) << 16 ^ str.charCodeAt(e - 3), 3266489909);
		h ^= str.charCodeAt(e - 2) << 8 ^ str.charCodeAt(e - 1) << 16;
		for (let p = s + 3, q = e - 4; p < s + 8 && p < q; p++, q--) h = Math.imul(h ^ str.charCodeAt(p) ^ str.charCodeAt(q) << 8, 16777619);
	}
	return h ^ h >>> 15 | 0;
};
var createEngine = (T, validatorImpls, options = {}) => {
	const { GROUP_COUNT, edgeStart, labelStart, labelText, edgeTarget, nodeGroup, nodeVlist, vlistPat, vlistOps, vlistRef, vlistGroup, litAnchor, litGroup, litPool, poolOffsets, poolText, adjGid, adjStart, adjTgt, patGid, patTgt, postfixLookupGroups, customValidatorNames, orderSensitiveModifiers } = T;
	const adjRow = new Int32Array(GROUP_COUNT).fill(-1);
	for (let i = 0; i < adjGid.length; i++) adjRow[adjGid[i]] = i;
	let maxAdj = 0;
	for (let r = 0; r + 1 < adjStart.length; r++) {
		const n = adjStart[r + 1] - adjStart[r];
		if (n > maxAdj) maxAdj = n;
	}
	let CLAIM_PER_TOKEN = 32;
	while (CLAIM_PER_TOKEN < 2 * (1 + maxAdj + patGid.length)) CLAIM_PER_TOKEN <<= 1;
	const vgStart = new Int32Array(vlistRef.length + 1);
	for (let l = 0; l < vlistRef.length; l++) vgStart[l + 1] = vgStart[l] + vlistPat[vlistRef[l] + 1] - vlistPat[vlistRef[l]];
	const postfixLookupSet = new Uint8Array(GROUP_COUNT);
	for (let i = 0; i < postfixLookupGroups.length; i++) postfixLookupSet[postfixLookupGroups[i]] = 1;
	const nodeCount = edgeStart.length - 1;
	const nodeHasLit = new Uint8Array(nodeCount);
	let litMaxLen = 0;
	let litNoArb = true;
	for (let i = 0; i < litAnchor.length; i++) {
		nodeHasLit[litAnchor[i]] = 1;
		const len = poolOffsets[litPool[i] * 2 + 1];
		if (len > litMaxLen) litMaxLen = len;
		const c0 = poolText.charCodeAt(poolOffsets[litPool[i] * 2]);
		if (c0 === 91 || c0 === 40) litNoArb = false;
	}
	let LIT_SIZE = 1;
	while (LIT_SIZE < litAnchor.length * 2) LIT_SIZE <<= 1;
	const litTable = new Int32Array(LIT_SIZE).fill(-1);
	for (let i = 0; i < litAnchor.length; i++) {
		const off = poolOffsets[litPool[i] * 2];
		let idx = (fnv(poolText, off, off + poolOffsets[litPool[i] * 2 + 1]) ^ Math.imul(litAnchor[i], 2654435761) | 0) & LIT_SIZE - 1;
		while (litTable[idx] !== -1) idx = idx + 1 & LIT_SIZE - 1;
		litTable[idx] = i;
	}
	const litProbe = (anchor, input, s, e) => {
		let idx = (fnv(input, s, e) ^ Math.imul(anchor, 2654435761) | 0) & LIT_SIZE - 1;
		const len = e - s;
		for (;;) {
			const entry = litTable[idx];
			if (entry === -1) return -1;
			if (litAnchor[entry] === anchor && poolOffsets[litPool[entry] * 2 + 1] === len) {
				const off = poolOffsets[litPool[entry] * 2];
				let ok = true;
				for (let k = 0; k < len; k++) if (poolText.charCodeAt(off + k) !== input.charCodeAt(s + k)) {
					ok = false;
					break;
				}
				if (ok) return litGroup[entry];
			}
			idx = idx + 1 & LIT_SIZE - 1;
		}
	};
	const cacheSize = options.cacheSize ?? 8192;
	const RAW_PREFIX = options.prefix ?? T.prefix ?? "";
	const FULL_PREFIX = RAW_PREFIX === "" ? "" : RAW_PREFIX + ":";
	const FPL = FULL_PREFIX.length;
	const vCustom = (customValidatorNames ?? []).map((name) => {
		const fn = validatorImpls && validatorImpls[name];
		if (!fn) throw new Error("cn: missing validator " + name);
		return fn;
	});
	const lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
	const colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
	const shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
	const imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
	let aKind = 0;
	let aLabelS = -1;
	let aLabelE = -1;
	let aValS = -1;
	let aValE = -1;
	const isWordCode = (c) => c >= 97 && c <= 122 || c >= 65 && c <= 90 || c >= 48 && c <= 57 || c === 95;
	const isUniWS = (c) => /\s/.test(String.fromCharCode(c));
	const analyzeArb = (input, s, e) => {
		aKind = 0;
		aLabelS = -1;
		if (e - s < 3) return;
		const c0 = input.charCodeAt(s);
		const cl = input.charCodeAt(e - 1);
		if (c0 === 91 && cl === 93) aKind = 1;
		else if (c0 === 40 && cl === 41) aKind = 2;
		else return;
		aValS = s + 1;
		aValE = e - 1;
		let p = s + 1;
		if (isWordCode(input.charCodeAt(p))) {
			p++;
			while (p < e - 1) {
				const c = input.charCodeAt(p);
				if (!isWordCode(c) && c !== 45) break;
				p++;
			}
			if (p < e - 2 && input.charCodeAt(p) === 58) {
				aLabelS = s + 1;
				aLabelE = p;
				aValS = p + 1;
			}
		}
	};
	const spanEq = (input, s, e, str) => {
		if (e - s !== str.length) return false;
		for (let i = 0; i < str.length; i++) if (input.charCodeAt(s + i) !== str.charCodeAt(i)) return false;
		return true;
	};
	const fractionRegex = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/;
	const tshirtRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
	const isNumStr = (v) => !!v && !Number.isNaN(Number(v));
	const spanIsNamedContainerQuery = (input, s, e) => {
		if (e - s < 11 || !spanEq(input, s, s + 10, "@container")) return false;
		if (input.charCodeAt(s + 10) === 47) return e - s >= 12;
		const c11 = input.charCodeAt(s + 11);
		return c11 === 115 && e - s >= 17 && spanEq(input, s + 10, s + 16, "-size/") || c11 === 110 && e - s >= 19 && spanEq(input, s + 10, s + 18, "-normal/");
	};
	const VKIND = [
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		2,
		2,
		2,
		2,
		2,
		2,
		2
	];
	const VLABELS = "length|number|number weight|family-name|position percentage|length size bg-size|image url|shadow|length|family-name|position percentage|length size bg-size|image url|shadow|number weight".split("|").map((s) => s.split(" "));
	const VFALL = [
		2,
		3,
		1,
		0,
		0,
		0,
		4,
		5,
		0,
		0,
		0,
		0,
		0,
		1,
		1
	];
	const runValidator = (op, input, s, e) => {
		if (op >= 10) {
			if (op >= 25) return vCustom[op - 25](input.slice(s, e));
			const i = op - 10;
			if (aKind !== VKIND[i]) return false;
			if (aLabelS >= 0) {
				for (const L of VLABELS[i]) if (spanEq(input, aLabelS, aLabelE, L)) return true;
				return false;
			}
			switch (VFALL[i]) {
				case 0: return false;
				case 1: return true;
				case 2: {
					const v = input.slice(aValS, aValE);
					return lengthUnitRegex.test(v) && !colorFunctionRegex.test(v);
				}
				case 3: return isNumStr(input.slice(aValS, aValE));
				case 4: return imageRegex.test(input.slice(aValS, aValE));
				default: return shadowRegex.test(input.slice(aValS, aValE));
			}
		}
		switch (op) {
			case 0: return true;
			case 1: return aKind === 0;
			case 2: return aKind === 1;
			case 3: return aKind === 2;
			case 4: return fractionRegex.test(input.slice(s, e));
			case 5: return isNumStr(input.slice(s, e));
			case 6: {
				const v = input.slice(s, e);
				return !!v && Number.isInteger(Number(v));
			}
			case 7: return e > s && input.charCodeAt(e - 1) === 37 && isNumStr(input.slice(s, e - 1));
			case 8: return tshirtRegex.test(input.slice(s, e));
			default: return spanIsNamedContainerQuery(input, s, e);
		}
	};
	const orderSensitive = new Set(typeof orderSensitiveModifiers === "string" ? orderSensitiveModifiers.split(" ") : orderSensitiveModifiers);
	const internSpan = (map, input, s, e, imp, make) => {
		const h = fnv(input, s, e) ^ (imp ? 2654435769 : 0) | 0;
		let bucket = map.get(h);
		if (bucket !== void 0) outer: for (let b = 0; b < bucket.length; b++) {
			const en = bucket[b];
			if (en.imp !== imp || en.k.length !== e - s) continue;
			for (let i = 0; i < en.k.length; i++) if (en.k.charCodeAt(i) !== input.charCodeAt(s + i)) continue outer;
			return en.id;
		}
		else map.set(h, bucket = []);
		const k = input.slice(s, e);
		const id = make(k);
		bucket.push({
			k,
			imp,
			id
		});
		return id;
	};
	let ctxByHash = /* @__PURE__ */ new Map();
	let ctxByCanon = /* @__PURE__ */ new Map();
	let nextCtxId = 2;
	const MAX_CTX = 4096;
	const canonicalizeContext = (raw, important) => {
		const mods = [];
		let dB = 0, dP = 0, start = 0;
		for (let i = 0; i < raw.length; i++) {
			const c = raw.charCodeAt(i);
			if (dB === 0 && dP === 0 && c === 58) {
				mods.push(raw.slice(start, i));
				start = i + 1;
			} else if (c === 91) dB++;
			else if (c === 93) dB--;
			else if (c === 40) dP++;
			else if (c === 41) dP--;
		}
		mods.push(raw.slice(start));
		let canonical = mods[0];
		if (mods.length > 1) {
			const result = [];
			let segment = [];
			for (const mod of mods) if (mod.charCodeAt(0) === 91 || orderSensitive.has(mod)) {
				if (segment.length) {
					result.push(...segment.sort());
					segment = [];
				}
				result.push(mod);
			} else segment.push(mod);
			if (segment.length) result.push(...segment.sort());
			canonical = result.join(":");
		}
		const key = important ? canonical + " !" : canonical;
		let id = ctxByCanon.get(key);
		if (id === void 0) ctxByCanon.set(key, id = nextCtxId++);
		return id;
	};
	let dynByHash = /* @__PURE__ */ new Map();
	let nextDynId = GROUP_COUNT;
	const MAX_DYN = GROUP_COUNT + 4096;
	const newDynId = () => nextDynId++;
	const ID_LIMIT = 2097152;
	const TOKEN_TABLE = 8192;
	const memoHash = new Int32Array(TOKEN_TABLE);
	const memoStr = new Array(TOKEN_TABLE).fill(null);
	const memoGid = new Int32Array(TOKEN_TABLE);
	const memoCtx = new Int32Array(TOKEN_TABLE);
	const memoFlags = new Uint8Array(TOKEN_TABLE);
	let memoTick = 0;
	const memoPut = (way0, input, ts, te, h, gid, ctxId, flags) => {
		let slot = way0;
		if (memoStr[way0] !== null) {
			if (memoStr[way0 | 1] === null) slot = way0 | 1;
			else if ((memoTick++ & 3) === 0) slot = way0 | memoTick >> 2 & 1;
			else return;
		}
		memoStr[slot] = input.slice(ts, te);
		memoHash[slot] = h;
		memoGid[slot] = gid;
		memoCtx[slot] = ctxId;
		memoFlags[slot] = flags;
	};
	const memoReset = () => memoStr.fill(null);
	let cap = 256;
	let tokI32 = [
		new Int32Array(cap),
		new Int32Array(cap),
		new Int32Array(cap),
		new Int32Array(cap)
	];
	let [tokStart, tokEnd, tokGid, tokCtx] = tokI32;
	let tokFlags = new Uint8Array(cap);
	let keep = new Uint8Array(cap);
	const growTokens = () => {
		cap *= 2;
		tokI32 = tokI32.map((a) => {
			const n = new Int32Array(cap);
			n.set(a);
			return n;
		});
		[tokStart, tokEnd, tokGid, tokCtx] = tokI32;
		const nf = new Uint8Array(cap);
		nf.set(tokFlags);
		tokFlags = nf;
		keep = new Uint8Array(cap);
	};
	let ckptCap = 64;
	let ckptNode = new Int32Array(ckptCap);
	let ckptTail = new Int32Array(ckptCap);
	const claim0 = new Int32Array(GROUP_COUNT);
	let CLAIM_TABLE = 2048;
	let claimShift = 21;
	let claimKeys = new Float64Array(CLAIM_TABLE);
	let claimEpochs = new Int32Array(CLAIM_TABLE);
	let epoch = 0;
	const claimTest = (ctx, gid) => {
		if (ctx === 0 && gid < GROUP_COUNT) {
			if (claim0[gid] === epoch) return 1;
			claim0[gid] = epoch;
			return 0;
		}
		const key = ctx * 2097152 + gid + 1;
		let idx = Math.imul(key, 2654435761) >>> claimShift;
		for (;;) {
			if (claimEpochs[idx] !== epoch) break;
			if (claimKeys[idx] === key) return 1;
			idx = idx + 1 & CLAIM_TABLE - 1;
		}
		claimKeys[idx] = key;
		claimEpochs[idx] = epoch;
		return 0;
	};
	const resolveAt = (input, bs, endPos, nodeAt, ckptAt) => {
		if (endPos - bs >= 2 && input.charCodeAt(bs) === 91 && input.charCodeAt(endPos - 1) === 93) {
			let colon = -1;
			for (let p = bs + 1; p < endPos - 1; p++) if (input.charCodeAt(p) === 58) {
				colon = p;
				break;
			}
			if (colon === -1 || colon === bs + 1) return EXTERNAL;
			return internSpan(dynByHash, input, bs + 1, colon, 0, newDynId);
		}
		if (nodeAt >= 0 && nodeGroup[nodeAt] >= 0) return nodeGroup[nodeAt];
		for (let k = ckptAt - 1; k >= 0; k--) {
			const tailStart = ckptTail[k];
			if (tailStart > endPos) continue;
			const nodeId = ckptNode[k];
			const tlen = endPos - tailStart;
			if (nodeHasLit[nodeId] === 1 && tlen > 0 && tlen <= litMaxLen) {
				const c0 = input.charCodeAt(tailStart);
				if (litNoArb === false || c0 !== 91 && c0 !== 40) {
					const g = litProbe(nodeId, input, tailStart, endPos);
					if (g >= 0) return g;
				}
			}
			const vl = nodeVlist[nodeId];
			if (vl < 0) continue;
			const pat = vlistRef[vl];
			const vs = vlistPat[pat];
			const ve = vlistPat[pat + 1];
			if (vs === ve) continue;
			analyzeArb(input, tailStart, endPos);
			const g0 = vgStart[vl] - vs;
			for (let v = vs; v < ve; v++) if (runValidator(vlistOps[v], input, tailStart, endPos)) return vlistGroup[g0 + v];
		}
		return EXTERNAL;
	};
	const mergeClassList = (input) => {
		const n = input.length;
		let tokenCount = 0;
		let totalTokenChars = 0;
		let sawNonSpaceWS = false;
		if (nextCtxId > MAX_CTX || ctxByHash.size > MAX_CTX) {
			ctxByHash = /* @__PURE__ */ new Map();
			ctxByCanon = /* @__PURE__ */ new Map();
			nextCtxId = 2;
			memoReset();
		}
		if (nextDynId > MAX_DYN) {
			dynByHash = /* @__PURE__ */ new Map();
			nextDynId = GROUP_COUNT;
			memoReset();
		}
		let i = 0;
		while (i < n) {
			let c = input.charCodeAt(i);
			if (c === 32 || c >= 9 && c <= 13 || c >= 160 && isUniWS(c)) {
				if (c !== 32) sawNonSpaceWS = true;
				i++;
				continue;
			}
			const ts = i;
			let th = 0;
			while (i < n) {
				c = input.charCodeAt(i);
				if (c <= 32) {
					if (c === 32) break;
					if (c >= 9 && c <= 13) {
						sawNonSpaceWS = true;
						break;
					}
				} else if (c >= 160 && isUniWS(c)) {
					sawNonSpaceWS = true;
					break;
				}
				th = Math.imul(th ^ c, 16777619);
				i++;
			}
			const te = i;
			const len = te - ts;
			if (tokenCount === cap) growTokens();
			const t = tokenCount++;
			tokStart[t] = ts;
			tokEnd[t] = te;
			totalTokenChars += len;
			th ^= Math.imul(len, 2654435761);
			const h = th ^ th >>> 15 | 0;
			const way0 = h & 8190;
			{
				let hitAt = -1;
				if (memoHash[way0] === h && memoStr[way0] !== null && memoStr[way0].length === len) hitAt = way0;
				else if (memoHash[way0 | 1] === h && memoStr[way0 | 1] !== null && memoStr[way0 | 1].length === len) hitAt = way0 | 1;
				if (hitAt >= 0) {
					const s = memoStr[hitAt];
					let ok = true;
					for (let k = 0; k < len; k++) if (s.charCodeAt(k) !== input.charCodeAt(ts + k)) {
						ok = false;
						break;
					}
					if (ok) {
						tokGid[t] = memoGid[hitAt];
						tokCtx[t] = memoCtx[hitAt];
						tokFlags[t] = memoFlags[hitAt];
						continue;
					}
				}
			}
			let pts = ts;
			if (FPL !== 0) {
				if (te - ts <= FPL || !input.startsWith(FULL_PREFIX, ts)) {
					tokGid[t] = EXTERNAL;
					memoPut(way0, input, ts, te, h, EXTERNAL, 0, 0);
					continue;
				}
				pts = ts + FPL;
			}
			let depthB = 0, depthP = 0;
			let lastColon = -1, lastSlash = -1;
			for (let p = pts; p < te; p++) {
				const pc = input.charCodeAt(p);
				if (depthB === 0 && depthP === 0) {
					if (pc === 58) {
						lastColon = p;
						continue;
					}
					if (pc === 47) {
						lastSlash = p;
						continue;
					}
				}
				if (pc === 91) depthB++;
				else if (pc === 93) depthB--;
				else if (pc === 40) depthP++;
				else if (pc === 41) depthP--;
			}
			const modStart = lastColon >= pts ? lastColon + 1 : pts;
			let bs = modStart;
			let be = te;
			let important = false;
			let prefixShift = 0;
			if (be > bs && input.charCodeAt(be - 1) === 33) {
				important = true;
				be--;
			} else if (be > bs && input.charCodeAt(bs) === 33) {
				important = true;
				bs++;
				prefixShift = 1;
			}
			let postfixEnd = -1;
			if (lastSlash > modStart) {
				postfixEnd = lastSlash + prefixShift;
				if (postfixEnd >= be) postfixEnd = -1;
			}
			let feedStart = bs;
			if (be - bs > 1 && input.charCodeAt(bs) === 45) feedStart = bs + 1;
			let node = 0;
			let lp = 0;
			let le = 0;
			let pending = -1;
			let ckptTop = 0;
			if (nodeVlist[0] >= 0 || nodeHasLit[0] === 1) {
				ckptNode[0] = 0;
				ckptTail[0] = feedStart;
				ckptTop = 1;
			}
			let slashNode = DEAD;
			let slashCkpt = 0;
			for (let p = feedStart; p < be; p++) {
				if (p === postfixEnd) {
					slashNode = lp < le ? DEAD : node;
					slashCkpt = ckptTop;
				}
				if (node !== DEAD) {
					const cc = input.charCodeAt(p);
					let arrived = -1;
					if (lp < le) {
						if (labelText.charCodeAt(lp) === cc) {
							lp++;
							if (lp === le) arrived = node = pending;
						} else node = DEAD;
					} else {
						const es = edgeStart[node];
						const ee = edgeStart[node + 1];
						let next = DEAD;
						for (let e = es; e < ee; e++) {
							const ls = labelStart[e];
							if (labelText.charCodeAt(ls) === cc) {
								if (labelStart[e + 1] - ls === 1) arrived = next = edgeTarget[e];
								else {
									lp = ls + 1;
									le = labelStart[e + 1];
									pending = edgeTarget[e];
									next = node;
								}
								break;
							}
						}
						node = next;
					}
					if (arrived >= 0 && (nodeVlist[arrived] >= 0 || nodeHasLit[arrived] === 1) && p + 1 < be && input.charCodeAt(p + 1) === 45) {
						if (ckptTop === ckptCap) {
							ckptCap *= 2;
							const nv = new Int32Array(ckptCap);
							nv.set(ckptNode);
							ckptNode = nv;
							const nt = new Int32Array(ckptCap);
							nt.set(ckptTail);
							ckptTail = nt;
						}
						ckptNode[ckptTop] = arrived;
						ckptTail[ckptTop] = p + 2;
						ckptTop++;
					}
				}
			}
			if (postfixEnd === be) {
				slashNode = lp < le ? DEAD : node;
				slashCkpt = ckptTop;
			}
			const endNode = lp < le ? DEAD : node;
			let gid;
			let hasPostfix = false;
			if (postfixEnd >= 0) {
				hasPostfix = true;
				gid = resolveAt(input, bs, postfixEnd, slashNode, slashCkpt);
				if (gid !== EXTERNAL && gid < GROUP_COUNT && postfixLookupSet[gid]) {
					const gidFull = resolveAt(input, bs, be, endNode, ckptTop);
					if (gidFull !== EXTERNAL && gidFull !== gid) {
						gid = gidFull;
						hasPostfix = false;
					}
				} else if (gid === EXTERNAL) {
					gid = resolveAt(input, bs, be, endNode, ckptTop);
					hasPostfix = false;
				}
			} else gid = resolveAt(input, bs, be, endNode, ckptTop);
			let ctxId = 0;
			let flags = 0;
			if (gid === EXTERNAL) tokGid[t] = EXTERNAL;
			else {
				flags = hasPostfix ? 1 : 0;
				ctxId = pts >= lastColon ? important ? 1 : 0 : internSpan(ctxByHash, input, pts, lastColon, important ? 1 : 0, (k) => canonicalizeContext(k, important));
				tokGid[t] = gid;
				tokFlags[t] = flags;
				tokCtx[t] = ctxId;
			}
			memoPut(way0, input, ts, te, h, gid, ctxId, flags);
		}
		if (tokenCount === 0) return "";
		if (tokenCount === 1) return tokStart[0] === 0 && tokEnd[0] === n ? input : input.slice(tokStart[0], tokEnd[0]);
		if (tokenCount * CLAIM_PER_TOKEN > CLAIM_TABLE) {
			while (tokenCount * CLAIM_PER_TOKEN > CLAIM_TABLE) {
				CLAIM_TABLE <<= 1;
				claimShift--;
			}
			claimKeys = new Float64Array(CLAIM_TABLE);
			claimEpochs = new Int32Array(CLAIM_TABLE);
		}
		if (nextCtxId >= ID_LIMIT || nextDynId >= ID_LIMIT) throw new Error("cn: too many distinct classes in one merge");
		epoch = epoch + 1 | 0;
		if (epoch === 0) {
			claim0.fill(0);
			claimEpochs.fill(0);
			epoch = 1;
		}
		let didDrop = false;
		for (let t = tokenCount - 1; t >= 0; t--) {
			const gid = tokGid[t];
			if (gid === EXTERNAL) {
				keep[t] = 1;
				continue;
			}
			const ctxId = tokCtx[t];
			if (claimTest(ctxId, gid) === 1) {
				keep[t] = 0;
				didDrop = true;
				continue;
			}
			keep[t] = 1;
			if (gid < GROUP_COUNT) {
				const r = adjRow[gid];
				if (r >= 0) for (let k = adjStart[r]; k < adjStart[r + 1]; k++) claimTest(ctxId, adjTgt[k]);
				if (tokFlags[t] & 1) {
					for (let k = 0; k < patGid.length; k++) if (patGid[k] === gid) claimTest(ctxId, patTgt[k]);
				}
			}
		}
		if (!didDrop && !sawNonSpaceWS && n === totalTokenChars + tokenCount - 1) return input;
		let out = "";
		let t = 0;
		while (t < tokenCount) {
			if (!keep[t]) {
				t++;
				continue;
			}
			const runStart = tokStart[t];
			let runEnd = tokEnd[t];
			let u = t + 1;
			while (u < tokenCount && keep[u] && tokStart[u] === runEnd + 1 && input.charCodeAt(runEnd) === 32) {
				runEnd = tokEnd[u];
				u++;
			}
			if (out.length > 0) out += " ";
			out += input.slice(runStart, runEnd);
			t = u;
		}
		return out;
	};
	const DOOR_SIZE = 16384;
	const door = new Int32Array(DOOR_SIZE * 2);
	let doorBase = 0;
	let doorEpoch = 1;
	let cache = Object.create(null);
	let prevCache = Object.create(null);
	let cacheMap = /* @__PURE__ */ new Map();
	let prevCacheMap = /* @__PURE__ */ new Map();
	let cacheCount = 0;
	let doorMarks = 0;
	const rotateDoor = () => {
		doorBase ^= DOOR_SIZE;
		doorEpoch = doorEpoch + 1 | 0;
		doorMarks = 0;
	};
	const mergeCached = (input) => {
		let merged = cache[input];
		if (merged !== void 0) return merged;
		const hash = spanHash(input, 0, input.length);
		const slot = (hash & 16383) + doorBase;
		const wasSeen = door[slot] === (hash ^ doorEpoch) || door[slot ^ DOOR_SIZE] === (hash ^ doorEpoch - 1);
		if (wasSeen) {
			merged = prevCache[input];
			if (merged !== void 0) {
				cache[input] = merged;
				return merged;
			}
		}
		merged = mergeClassList(input);
		if (wasSeen) {
			cache[input] = merged;
			if (++cacheCount > cacheSize) {
				cacheCount = 0;
				prevCache = cache;
				cache = Object.create(null);
				rotateDoor();
			}
		} else {
			door[slot] = hash ^ doorEpoch;
			if (++doorMarks > DOOR_SIZE) rotateDoor();
		}
		return merged;
	};
	const mergeCachedMap = (input) => {
		let merged = cacheMap.get(input);
		if (merged !== void 0) return merged;
		const hash = spanHash(input, 0, input.length);
		const slot = (hash & 16383) + doorBase;
		const wasSeen = door[slot] === (hash ^ doorEpoch) || door[slot ^ DOOR_SIZE] === (hash ^ doorEpoch - 1);
		if (wasSeen) {
			merged = prevCacheMap.get(input);
			if (merged !== void 0) {
				cacheMap.set(input, merged);
				return merged;
			}
		}
		merged = mergeClassList(input);
		if (wasSeen) {
			cacheMap.set(input, merged);
			if (++cacheCount > cacheSize) {
				cacheCount = 0;
				prevCacheMap = cacheMap;
				cacheMap = /* @__PURE__ */ new Map();
				rotateDoor();
			}
		} else {
			door[slot] = hash ^ doorEpoch;
			if (++doorMarks > DOOR_SIZE) rotateDoor();
		}
		return merged;
	};
	const seenBefore = (input) => {
		const hash = spanHash(input, 0, input.length);
		const slot = (hash & 16383) + doorBase;
		if (door[slot] === (hash ^ doorEpoch) || door[slot ^ DOOR_SIZE] === (hash ^ doorEpoch - 1)) return true;
		door[slot] = hash ^ doorEpoch;
		if (++doorMarks > DOOR_SIZE) rotateDoor();
		return false;
	};
	const mergeString = cacheSize === 0 ? mergeClassList : IS_JSC ? (input) => {
		const merged = cacheMap.get(input);
		return merged !== void 0 ? merged : mergeCachedMap(input);
	} : mergeCached;
	const merge = function() {
		return arguments.length === 1 && typeof arguments[0] === "string" ? mergeString(arguments[0]) : mergeString(twJoin.apply(null, arguments));
	};
	return {
		merge,
		mergeString,
		seenBefore: cacheSize === 0 ? () => false : seenBefore,
		mergeUncached: mergeClassList
	};
};
var resolveValue = (v, clsxMode) => {
	if (!v) return "";
	if (typeof v === "string") return v;
	let out = "";
	if (typeof v.length === "number" && (clsxMode ? Array.isArray(v) : true)) {
		const arr = v;
		for (let i = 0; i < arr.length; i++) {
			const item = arr[i];
			if (!item) continue;
			const r = typeof item === "string" ? item : resolveValue(item, clsxMode);
			if (r) {
				if (out) out += " ";
				out += r;
			}
		}
		return out;
	}
	if (clsxMode) {
		if (typeof v === "number") return "" + v;
		if (typeof v === "object") {
			for (const k in v) if (v[k]) {
				if (out) out += " ";
				out += k;
			}
		}
	}
	return out;
};
var joinArgs = (args, clsxMode) => {
	let s = "";
	for (let i = 0; i < args.length; i++) {
		const a = args[i];
		if (!a) continue;
		const r = typeof a === "string" ? a : resolveValue(a, clsxMode);
		if (r) {
			if (s) s += " ";
			s += r;
		}
	}
	return s;
};
/** join-only, `twJoin`-compatible (strings + nested arrays, falsy skipped) */
var twJoin = function() {
	return joinArgs(arguments, false);
};
/** join-only, `clsx`-compatible (no merging) */
var clsx = function() {
	return joinArgs(arguments, true);
};
var BUCKET_CAP = 256;
var BUCKET_MISS_CAP = 16;
var BUCKET_SKIP = 1024;
var CHURN_SIZE = 4096;
var wrapClsx = (mergeString, fresh) => {
	const seenBefore = fresh === void 0 ? () => true : fresh.seenBefore;
	const mergeUncached = fresh === void 0 ? mergeString : fresh.mergeUncached;
	let argCache = /* @__PURE__ */ new Map();
	let prevArgCache = /* @__PURE__ */ new Map();
	let argCount = 0;
	let lastHit = null;
	let churnKey = null;
	let churnOwn = [];
	let churnVal = [];
	let churnTick = 0;
	const churnLookup = (key, own, join) => {
		if (churnKey === null) {
			churnKey = new Array(CHURN_SIZE).fill("");
			churnOwn = new Array(CHURN_SIZE).fill("");
			churnVal = new Array(CHURN_SIZE).fill("");
		}
		const way0 = spanHash(key, 0, key.length) & 4094;
		if (churnKey[way0] === key && churnOwn[way0] === own) return churnVal[way0];
		if (churnKey[way0 | 1] === key && churnOwn[way0 | 1] === own) return churnVal[way0 | 1];
		const merged = mergeString(join ? own + " " + key : key);
		const slot = churnKey[way0] === "" ? way0 : way0 | (churnKey[way0 | 1] === "" ? 1 : churnTick++ & 1);
		churnKey[slot] = key;
		churnOwn[slot] = own;
		churnVal[slot] = merged;
		return merged;
	};
	const match3 = (e, v0, v1, v2) => {
		let k = 0;
		if (v0) {
			if (v0 !== e.a0) return false;
			k = 1;
		}
		if (v1) {
			if (v1 !== (k === 0 ? e.a0 : e.a1)) return false;
			k++;
		}
		if (v2) {
			if (v2 !== (k === 0 ? e.a0 : k === 1 ? e.a1 : e.a2)) return false;
			k++;
		}
		return k === e.t;
	};
	const matchN = (e, vals) => {
		const ea = e.a;
		let k = 0;
		for (let i = 0; i < vals.length; i++) {
			const v = vals[i];
			if (!v) continue;
			if (v !== ea[k]) return false;
			k++;
		}
		return k === e.t;
	};
	const resolveArgs = (vals, probed) => {
		const nArgs = vals.length;
		const pred = lastHit === null ? null : lastHit.n;
		if (!probed) {
			if (pred !== null && matchN(pred, vals)) {
				lastHit = pred;
				return pred.r;
			}
			if (lastHit !== null && lastHit !== pred && matchN(lastHit, vals)) return lastHit.r;
		}
		let first = "";
		let firstIdx = -1;
		let truthy = 0;
		let hasResolvedValue = false;
		for (let i = 0; i < nArgs; i++) {
			let v = vals[i];
			if (!v) continue;
			if (typeof v !== "string") {
				v = vals[i] = resolveValue(v, true);
				if (!v) continue;
				hasResolvedValue = true;
			}
			if (firstIdx < 0) {
				first = v;
				firstIdx = i;
			}
			truthy++;
		}
		if (truthy === 0) return "";
		if (truthy === 1) return mergeString(first);
		if (hasResolvedValue) {
			if (pred !== null && matchN(pred, vals)) {
				lastHit = pred;
				return pred.r;
			}
			if (lastHit !== null && lastHit !== pred && matchN(lastHit, vals)) return lastHit.r;
		}
		let bucket = argCache.get(first);
		if (bucket === void 0) {
			bucket = prevArgCache.get(first);
			if (bucket !== void 0) argCache.set(first, bucket);
		}
		let hit = null;
		if (bucket !== void 0) {
			if (bucket.skip > 0) {
				bucket.skip--;
				lastHit = null;
				let joined = first;
				for (let i = firstIdx + 1; i < nArgs; i++) {
					const v = vals[i];
					if (v) joined += " " + v;
				}
				return churnLookup(joined, "", false);
			}
			const entries = bucket.e;
			outer: for (let b = 0; b < entries.length; b++) {
				const e = entries[b];
				if (e.t !== truthy) continue;
				const ea = e.a;
				let k = 1;
				for (let i = firstIdx + 1; i < nArgs; i++) {
					const v = vals[i];
					if (v && v !== ea[k++]) continue outer;
				}
				hit = e;
				break;
			}
			if (hit !== null) bucket.miss = 0;
		}
		if (hit === null) {
			let joined = first;
			const a = [first];
			for (let i = firstIdx + 1; i < nArgs; i++) {
				const v = vals[i];
				if (!v) continue;
				joined += " " + v;
				a.push(v);
			}
			if (!seenBefore(joined)) return mergeUncached(joined);
			hit = {
				r: mergeString(joined),
				t: a.length,
				a0: a[0],
				a1: a[1],
				a2: a[2] ?? "",
				a,
				n: null
			};
			if (bucket === void 0) argCache.set(first, bucket = {
				e: [],
				miss: 0,
				skip: 0,
				at: 0
			});
			else if (++bucket.miss > BUCKET_MISS_CAP) {
				bucket.miss = BUCKET_MISS_CAP;
				bucket.skip = BUCKET_SKIP;
				bucket.e.length = 0;
				bucket.at = 0;
			}
			const entries = bucket.e;
			if (entries.length < BUCKET_CAP) entries.push(hit);
			else {
				entries[bucket.at] = hit;
				bucket.at = bucket.at + 1 & 255;
			}
			if (++argCount > 1e3) {
				argCount = 0;
				prevArgCache = argCache;
				argCache = /* @__PURE__ */ new Map();
			}
		}
		if (lastHit !== null && lastHit !== hit) lastHit.n = hit;
		lastHit = hit;
		return hit.r;
	};
	const mergeSingleValue = (value) => Array.isArray(value) ? resolveArgs(value.slice(), false) : mergeString(resolveValue(value, true));
	return function(v0, v1, v2) {
		const nArgs = arguments.length;
		if ((nArgs | 1) === 3) {
			const lh = lastHit;
			if (lh !== null) {
				const pred = lh.n;
				if (pred !== null && match3(pred, v0, v1, v2)) {
					lastHit = pred;
					return pred.r;
				}
				if (lh !== pred && match3(lh, v0, v1, v2)) return lh.r;
			}
			if (nArgs === 2 && typeof v1 === "string" && v1 !== "") {
				const bucket = argCache.get(v0);
				if (bucket !== void 0 && bucket.skip > 0) {
					bucket.skip--;
					lastHit = null;
					return churnLookup(v1, v0, true);
				}
			}
			return resolveArgs([
				v0,
				v1,
				v2
			], true);
		}
		if (nArgs === 1) return typeof v0 === "string" ? mergeString(v0) : mergeSingleValue(v0);
		const lh = lastHit;
		if (lh !== null) {
			const pred = lh.n;
			if (pred !== null) {
				const pa = pred.a;
				let k = 0;
				let ok = true;
				for (let i = 0; i < nArgs; i++) {
					const v = arguments[i];
					if (!v) continue;
					if (v !== pa[k]) {
						ok = false;
						break;
					}
					k++;
				}
				if (ok && k === pred.t) {
					lastHit = pred;
					return pred.r;
				}
			}
			if (lh !== pred) {
				const la = lh.a;
				let k = 0;
				let ok = true;
				for (let i = 0; i < nArgs; i++) {
					const v = arguments[i];
					if (!v) continue;
					if (v !== la[k]) {
						ok = false;
						break;
					}
					k++;
				}
				if (ok && k === lh.t) return lh.r;
			}
		}
		const vals = [];
		for (let i = 0; i < nArgs; i++) vals.push(arguments[i]);
		return resolveArgs(vals, true);
	};
};
// node_modules/cn/dist/index.js
var instance = /* @__PURE__ */ createEngine(tables_generated_default);
/**
* Merge Tailwind CSS classes with clsx-style arguments (strings, arrays,
* objects, conditionals). Drop-in replacement for `twMerge(clsx(...))`.
*/
var cn = /* @__PURE__ */ wrapClsx(instance.mergeString, instance);
/** tailwind-merge–compatible variadic merge (strings + nested arrays). */
var twMerge = instance.merge;
export { clsx, cn, createEngine, twJoin, twMerge };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY24uanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vY24vZGlzdC90YWJsZXMuanMiLCIuLi8uLi9jbi9kaXN0L2VuZ2luZS5qcyIsIi4uLy4uL2NuL2Rpc3QvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8jcmVnaW9uIHNyYy90YWJsZXMuZ2VuZXJhdGVkLnRzXG5jb25zdCBQID0gNDg7XG5jb25zdCBVID0gKHMsIG8gPSAwKSA9PiB7XG5cdGNvbnN0IG91dCA9IG5ldyBJbnQzMkFycmF5KHMubGVuZ3RoKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBzLmNoYXJDb2RlQXQoaSkgLSBQIC0gbztcblx0cmV0dXJuIG91dDtcbn07XG5jb25zdCBQUyA9IChjb3VudHMpID0+IHtcblx0Y29uc3Qgb3V0ID0gbmV3IEludDMyQXJyYXkoY291bnRzLmxlbmd0aCArIDEpO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50cy5sZW5ndGg7IGkrKykgb3V0W2kgKyAxXSA9IG91dFtpXSArIGNvdW50c1tpXTtcblx0cmV0dXJuIG91dDtcbn07XG5jb25zdCBEWiA9IChzKSA9PiB7XG5cdGNvbnN0IG91dCA9IG5ldyBJbnQzMkFycmF5KHMubGVuZ3RoKTtcblx0bGV0IGEgPSAwO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHMubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCB6ID0gcy5jaGFyQ29kZUF0KGkpIC0gUDtcblx0XHRhICs9IHogPj4+IDEgXiAtKHogJiAxKTtcblx0XHRvdXRbaV0gPSBhO1xuXHR9XG5cdHJldHVybiBvdXQ7XG59O1xuY29uc3QgR1JPVVBfQ09VTlQgPSAzODQ7XG5jb25zdCBjdXN0b21WYWxpZGF0b3JOYW1lcyA9IFtdO1xuY29uc3QgZWRnZVN0YXJ0ID0gUFMoVShcIkUwNTAwMDAyMDA1MjgyMDAwMDAwMDAyMDAwMTUwMDAwMDIwMDIxODIwMDAwMDExMjAwMDAwMDAzMDIyMjAyMDAwMzAwMDA0MjAwMTIwMDAwMjAwNDIwMDAxMjAwMDIxMjAwMzAxMjAwMDEwNDAwMTYyMDAwMDEwMDAwMjIwMDIxMDEwOjIxOTIwMDEyMDAyMjAwMTIwMDAyMjAwMTIwMDAyMDAyMDAyMDA0MDAwMTAyMDAwNDAwMDAwMDAwMDA0MDAyMDAxMDgyMDAxMTAxMDAwMDAwMjIwMTAzMTMwMDAxNjIwMDIwMDAwMjAwMjAwMTIwMjAwODAyMTMwMDAyMjgyMDAwMDAwMDAwODIwMDAwMDAwMDAxMjAwMDIwMDAxMjAwMjAwMjAwNDAxMDEwMjAzMDAxMzAwMDEwMDEwMTBcIikpO1xuY29uc3QgbGFiZWxTdGFydCA9IFBTKFUoXCI6MTExMTExMTEyMTExMTExMTkzMTE1NDY1NDQ0MTExMTk3MzE4Njk6NjcxMzk3NDE1Njg2NDMyNDQxMTExMTExMTExMTYxMTE0MTUxMjE0MzEzNDMzNDE1Ojc4MzExMTMyMjMzMzEzMTg3MjExMTE3MjIxNDQ5NDQzNDExMTQxMTExMTUxMTUyMjI2NjExMTMxMTExMTEyMjEyNTE4MTQyMjI0MjE0MjE1NDIxNDIxNTQyMTQyNDI0MjQyNTE2MTcxMTUxNjE1NjE2MzQ3MTExMTExMTExMTk3OTExMzI3NDUxMTExMTExMTExMTExMTExMTExMTEzMTM0NzE0MTMzNTEzNDExMTExMzExMTExMTExMTExMTExMTExMTExMTEyNDQ0NDExMTExMzQyMzEyNzE1MjQ1NDExMTE3OjNcIikpO1xuY29uc3QgbGFiZWxUZXh0ID0gXCJAY29udGFpbmVyYWJjZGVmZ2hpbmxtb3Byc3R1bmRlcmxpbmV2aWF3emNjZW50bGlnbm5pbWF0ZXNwZWN0dXRvLWNvbHNyb3dzYWdsb3JpZ2h0bmVzc2NrZHJvcC1zaXNiY29udHJhc3RmaWx0ZXJncmF5c2NhbGVodWUtcm90YXRlaW52ZXJ0b3BhY2l0eXNsdXJyaWdodG5lc3NhdHVyYXRlZXBpYS1jb25pY2xpbmVhcnBvc2l0aW9ucmFkaWFsc2l6ZW9ja3VycmRlcnR0b20tYmVscnN0eHllc3BhY2luZy14eWFyZXRvdXJzb3JsbnQtdW1uc2VuZHNwYW50YXJ0YWluZW50cmFzdGVpdmlkZXJvcC1zaGFkb3d1cmF0aW9uY29yYXRpb25sYXkteHlhc2VuZGlsbGV4b250cm9tbHRlci1mZWF0dXJlc3N0cmV0Y2hhcHIteHlheXNjYWxlaWRvdy1jb2xzcm93c3VlLXJvdGF0ZWRlbnRsaW5lc2V0dmVydC1iZXJpbmdzeHllc2hhZG93ZWlhZGluZ2Z0bmVzdC1jbGFtcC1pbWFnZWFiZWluLWxyc3R4eXNreC0tYi1jb25pY2xwb3NpdGlvbnJzaXpldC14LXktZnJvbXRvLWZyb210by1pbmVhcmZyb210by1mcm9tdG8tYWRpYWxmcm9tdG8tZnJvbXRvZnJvbXRvZnJvbXRvZnJvbXRvYmxvY2toaW5saW5ldy1zY3JlZW5lc2Jsb2NraGlubGluZXdiamVjdHBhY2l0eXJ1dGxpbmVkZXJpZ2luLW9mZnNldGJlbHJzdHh5ZXNyc3BlY3RpdmUtb3JpZ2luYWNlaG9sZGVyaW9naHRuZy1vZmZzZXR0YXRldW5kZWR3LXh5ei1iZWxyc3RscmVzZXNsci1lbmRzcGFudGFydGF0dXJhdGVjZXBpYWhpemVrZXdwYWNlLXRhbGVyb2xsLXh5ei1iYXJtcGJlbHJzdHh5ZXNiZWxyc3R4eWVzLXRodW1icmFja2Fkb3dyaW5rLXh5eHlhcnRyb2tlYWJleHRvcmEtc2hhZG93cGNraW5nbnNmb3JtaXRpb25sYXRlLXh5ei1vZmZzZXRpbGwtY2hhbmdlb29tXCI7XG5jb25zdCBlZGdlVGFyZ2V0ID0gKCgpID0+IHtcblx0Y29uc3QgTiA9IGVkZ2VTdGFydC5sZW5ndGggLSAxO1xuXHRjb25zdCBzaXplcyA9IG5ldyBJbnQzMkFycmF5KE4pO1xuXHRmb3IgKGxldCBpID0gTiAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0bGV0IHMgPSAxO1xuXHRcdGxldCBjID0gaSArIDE7XG5cdFx0Zm9yIChsZXQgayA9IGVkZ2VTdGFydFtpXTsgayA8IGVkZ2VTdGFydFtpICsgMV07IGsrKykge1xuXHRcdFx0cyArPSBzaXplc1tjXTtcblx0XHRcdGMgKz0gc2l6ZXNbY107XG5cdFx0fVxuXHRcdHNpemVzW2ldID0gcztcblx0fVxuXHRjb25zdCBvdXQgPSBuZXcgSW50MzJBcnJheShlZGdlU3RhcnRbTl0pO1xuXHRsZXQgZSA9IDA7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgTjsgaSsrKSB7XG5cdFx0bGV0IGMgPSBpICsgMTtcblx0XHRmb3IgKGxldCBrID0gZWRnZVN0YXJ0W2ldOyBrIDwgZWRnZVN0YXJ0W2kgKyAxXTsgaysrKSB7XG5cdFx0XHRvdXRbZSsrXSA9IGM7XG5cdFx0XHRjICs9IHNpemVzW2NdO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gb3V0O1xufSkoKTtcbmNvbnN0IG5vZGVHcm91cCA9IFUoXCIwMjAwMDAwMDAwMDAwMDkwMDw9MD8wMDBCMDAwRjAwRjAwxY9JMEowTE5QUlRWWDAwMDBdX2EwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMHJzdDAwMDAwMDB6xY8wMDAwMDAwMDAwMMKFxY8wMDDCiDAwMDDFjzAwMDAwMMKQMDAwMMKXMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMMOLMDAwMDAwMDAwMDAwMDAwMDAwMDAww54wMDAwMDAwMDAwMDAwMDAwMDDDsDAwMDAwMDDDuDDDucO6w7vDvMO9w77Dv8SAxIHEgsSDxITEhcSGMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwxKcwxKjEqjAwMDAwMDAwMDAwMDAwMDAwMDAwxLzEvTAwMDAwxawwMDAwMDBcIiwgMSk7XG5jb25zdCB2bGlzdFBhdCA9IFBTKFUoXCIxMjMzMzMzNTkzNDY0NjM2MzUxMjY1MzY3MTE1NzZcIikpO1xuY29uc3Qgdmxpc3RPcHMgPSBVKFwiOTMyMDMyNDIzMzI1ODMyNTMyNDgzMjVEPkU/RkAwMzI2MzI0MzI1NUI6MDMyNTIzODUzOjAzMjVCOjhHQTAzMjU0Mkg8Qz0xMjcyN0I6MDMyODQzMjU1MztEPkU/MzI1N0Q+MDMyNTg1OjAzMjVCOjswMzI4QjowMzJcIik7XG5jb25zdCB2bGlzdFJlZiA9IFUoXCIwMTIxMTM0NDU2NjE2NjY2NjY3ODkxMTE6NTs7Ozs7Ozs7NDQ0Ozs7OjYyOTk5PDExNjE9NjI+Pj82MToyMUBBQkNENDQ0Njk5Njo2NEU6Ojo7Oj86OjY0OkYxMTRHSEhJSEhISElISDFISDFISDFISEhISEg6OkVFSjQ0NDQ6OkVFNDQ0NDQ0MTY5MTs2NDQ0NDQxMTQyNDQ0NDQ6O0s2NjY2NTU1NTU1NTU1NTU1NTU1OTk5NjY2NjY0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0MjI2PzY6NjY2NDRMOU0/RDoxMTE6Ojo6NkRFMTk5XCIpO1xuY29uc3Qgdmxpc3RHcm91cCA9IERaKFwiMDIwMjAwMjAyMDIwMDIwMDIwMDIwMDIwMDIwMDIwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMDAyMDIwMjAyMDAxMDAzMDQwMTA2MDAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMDIwMDIwMDIwMDIwMDIwMDIwMDAyMDIwMjAwMjAyMDAyMDAyMDAyMDAyMDAyMDAyMDAyMDAyMDAyMDIwMDAyMDAyMDIwMDIwMjAwMjIwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMDIwMDIwMDIwMDAwMjAwMDIwMDAyMDAwMjAwMjAwMjAwMDIwMDIwMDIwMDAyMDAwMjAwMjAwMjAwMDIwMDIwMjAyMDAyMDIwMjAyMDAwMjAwMjAwMDIwMDIyMDAwMjAwMjAwMDIwMDIwMDAyMDAyMDAwMjAwMjIwMDAyMDAyMDAwMjAwVzBaMDAwMjAwMjAwMDIwMDIwMjAwMDIwMDIwMDAyMDBnMGowMDAyMDAyMDAwMjAwMjAwMDIwMDIwMDAyMDAyMDAwMjAwMjAwMDIwMDIwMDAyMDAwMjAwMDAyMDAwMDAyMDAyMDAyMDAyMDAyMDAwMjAwMDIwMDAwMjAwMDAyMDAyMDAyMDAyMDAyMDAyMDAyMDIwMDIwMDIwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAyMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDAyMDAyMDAyMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDIwMDAyMDAyMDAyMDAyMDAyMDAyMDAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMjAwMDIwMjAyMDIwMDAyMDAwMjAwMDIwMDAyMDAyMDAyMDAyMDAwMDIwMjAwMjAwXCIpO1xuY29uc3Qgbm9kZVZsaXN0ID0gKCgpID0+IHtcblx0Y29uc3Qgb3V0ID0gKC8qIEBfX1BVUkVfXyAqLyBuZXcgSW50MzJBcnJheSgzMTkpKS5maWxsKC0xKTtcblx0Y29uc3QgQSA9IERaKFwiMDI0MjIyNDI6MjIyMjIyMjQyMjI0MjIyMjQyNDQyMjIyMjIyNDIyMjIyMjQ0NDQyMjQyMjI2MjI0MjIyNDI2MjIyNDIyNDQyNDYyMjIyNDIyNjIyMjIyMjIyNjI2MjIyNDYyMjQyNjIyNDIyNjIyNDIyNDI0MjQyNDIyMjIyMjIyNDIyMjIyMjIyMjQyNDIyMjIyMjIyMjIyMjIyMjIyNjIyNDQyMjI0MjIyMjIyMjIyMjIyMjI0NDI0NDQyMjYyMjIyMjIyMjIyMjIyMjIyMjIyMjI2MjI0MjIyNDI0MjQyNDIyMjI0NDIyNDIyNDIyMjIyXCIpO1xuXHRjb25zdCBWID0gRFooXCIwMjIyMjIyMjIyMjIyMjIyMjIyMjIwMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMTQyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMllcXFxcMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIxNDIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyxL/FgjIyMjIyMjIyMjIyMjIyMjIyMlwiKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBBLmxlbmd0aDsgaSsrKSBvdXRbQVtpXV0gPSBWW2ldO1xuXHRyZXR1cm4gb3V0O1xufSkoKTtcbmNvbnN0IFNFVFMgPSBcImNvbnRhaW5lciB8YnJlYWstYWZ0ZXItIGFsbCBhdXRvIGF2b2lkIGF2b2lkLXBhZ2UgY29sdW1uIGxlZnQgcGFnZSByaWdodHxicmVhay1iZWZvcmUtIGFsbCBhdXRvIGF2b2lkIGF2b2lkLXBhZ2UgY29sdW1uIGxlZnQgcGFnZSByaWdodHxicmVhay1pbnNpZGUtYSB1dG8gdm9pZCB2b2lkLWNvbHVtbiB2b2lkLXBhZ2V8Ym94LWRlY29yYXRpb24tIGNsb25lIHNsaWNlfGJveC0gYm9yZGVyIGNvbnRlbnR8IGNvbnRlbnRzIGZsb3ctcm9vdCBoaWRkZW4gdGFibGUgdGFibGUtY2FwdGlvbiB0YWJsZS1jZWxsIHRhYmxlLWNvbHVtbiB0YWJsZS1jb2x1bW4tZ3JvdXAgdGFibGUtZm9vdGVyLWdyb3VwIHRhYmxlLWhlYWRlci1ncm91cCB0YWJsZS1yb3cgdGFibGUtcm93LWdyb3VwfCBub3Qtc3Itb25seSBzci1vbmx5fGZsb2F0LSBlbmQgbGVmdCBub25lIHJpZ2h0IHN0YXJ0fGNsZWFyLSBib3RoIGVuZCBsZWZ0IG5vbmUgcmlnaHQgc3RhcnR8aXNvbGF0IGUgaW9uLWF1dG98b3ZlcmZsb3ctIGF1dG8gY2xpcCBoaWRkZW4gc2Nyb2xsIHZpc2libGV8b3ZlcmZsb3cteC0gYXV0byBjbGlwIGhpZGRlbiBzY3JvbGwgdmlzaWJsZXxvdmVyZmxvdy15LSBhdXRvIGNsaXAgaGlkZGVuIHNjcm9sbCB2aXNpYmxlfG92ZXJzY3JvbGwtIGF1dG8gY29udGFpbiBub25lfG92ZXJzY3JvbGwteC0gYXV0byBjb250YWluIG5vbmV8b3ZlcnNjcm9sbC15LSBhdXRvIGNvbnRhaW4gbm9uZXwgYWJzb2x1dGUgZml4ZWQgcmVsYXRpdmUgc3RhdGljIHN0aWNreXwgY29sbGFwc2UgaW52aXNpYmxlIHZpc2libGV8anVzdGlmeS0gYXJvdW5kIGJhc2VsaW5lIGJldHdlZW4gY2VudGVyIGNlbnRlci1zYWZlIGVuZCBlbmQtc2FmZSBldmVubHkgbm9ybWFsIHN0YXJ0IHN0cmV0Y2h8anVzdGlmeS1pdGVtcy0gY2VudGVyIGNlbnRlci1zYWZlIGVuZCBlbmQtc2FmZSBub3JtYWwgc3RhcnQgc3RyZXRjaHxqdXN0aWZ5LXNlbGYtIGF1dG8gY2VudGVyIGNlbnRlci1zYWZlIGVuZCBlbmQtc2FmZSBzdGFydCBzdHJldGNofGl0ZW1zLSBiYXNlbGluZSBiYXNlbGluZS1sYXN0IGNlbnRlciBjZW50ZXItc2FmZSBlbmQgZW5kLXNhZmUgc3RhcnQgc3RyZXRjaHxzZWxmLSBhdXRvIGJhc2VsaW5lIGJhc2VsaW5lLWxhc3QgY2VudGVyIGNlbnRlci1zYWZlIGVuZCBlbmQtc2FmZSBzdGFydCBzdHJldGNofHBsYWNlLWNvbnRlbnQtIGFyb3VuZCBiYXNlbGluZSBiZXR3ZWVuIGNlbnRlciBjZW50ZXItc2FmZSBlbmQgZW5kLXNhZmUgZXZlbmx5IHN0YXJ0IHN0cmV0Y2h8cGxhY2UtaXRlbXMtIGJhc2VsaW5lIGNlbnRlciBjZW50ZXItc2FmZSBlbmQgZW5kLXNhZmUgc3RhcnQgc3RyZXRjaHxwbGFjZS1zZWxmLSBhdXRvIGNlbnRlciBjZW50ZXItc2FmZSBlbmQgZW5kLXNhZmUgc3RhcnQgc3RyZXRjaHwgYW50aWFsaWFzZWQgc3VicGl4ZWwtYW50aWFsaWFzZWR8IGl0YWxpYyBub3QtaXRhbGljfG5vcm1hbC1udW1zIHxvcmRpbmFsIHxzbGFzaGVkLXplcm8gfCBsaW5pbmctbnVtcyBvbGRzdHlsZS1udW1zfCBwcm9wb3J0aW9uYWwtbnVtcyB0YWJ1bGFyLW51bXN8IGRpYWdvbmFsLWZyYWN0aW9ucyBzdGFja2VkLWZyYWN0aW9uc3wgbm8tdW5kZXJsaW5lIG92ZXJsaW5lfCBjYXBpdGFsaXplIGxvd2VyY2FzZSBub3JtYWwtY2FzZSB1cHBlcmNhc2V8dHJ1bmNhdGUgfHdoaXRlc3BhY2UtIGJyZWFrLXNwYWNlcyBub3JtYWwgbm93cmFwIHByZSBwcmUtbGluZSBwcmUtd3JhcHxicmVhay0gYWxsIGtlZXAgbm9ybWFsIHdvcmRzfHdyYXAtIGFueXdoZXJlIGJyZWFrLXdvcmQgbm9ybWFsfGh5cGhlbnMtIGF1dG8gbWFudWFsIG5vbmV8bWl4LWJsZW5kLSBjb2xvciBjb2xvci1idXJuIGNvbG9yLWRvZGdlIGRhcmtlbiBkaWZmZXJlbmNlIGV4Y2x1c2lvbiBoYXJkLWxpZ2h0IGh1ZSBsaWdodGVuIGx1bWlub3NpdHkgbXVsdGlwbHkgbm9ybWFsIG92ZXJsYXkgcGx1cy1kYXJrZXIgcGx1cy1saWdodGVyIHNhdHVyYXRpb24gc2NyZWVuIHNvZnQtbGlnaHR8dGFibGUtIGF1dG8gZml4ZWR8Y2FwdGlvbi0gYm90dG9tIHRvcHxiYWNrZmFjZS0gaGlkZGVuIHZpc2libGV8YXBwZWFyYW5jZS0gYXV0byBub25lfHNjaGVtZS0gZGFyayBsaWdodCBsaWdodC1kYXJrIG5vcm1hbCBvbmx5LWRhcmsgb25seS1saWdodHxmaWVsZC1zaXppbmctIGNvbnRlbnQgZml4ZWR8cG9pbnRlci1ldmVudHMtIGF1dG8gbm9uZXxyZXNpemUgIC1ub25lIC14IC15fHNuYXAtIGFsaWduLW5vbmUgY2VudGVyIGVuZCBzdGFydHxzbmFwLSBhbHdheXMgbm9ybWFsfHNuYXAtIGJvdGggbm9uZSB4IHl8c25hcC0gbWFuZGF0b3J5IHByb3hpbWl0eXx0b3VjaC0gYXV0byBtYW5pcHVsYXRpb24gbm9uZXx0b3VjaC1wYW4tIGxlZnQgcmlnaHQgeHx0b3VjaC1wYW4tIGRvd24gdXAgeXx0b3VjaC1waW5jaC16b29tIHxzZWxlY3QtIGFsbCBhdXRvIG5vbmUgdGV4dHxmb3JjZWQtY29sb3ItYWRqdXN0LSBhdXRvIG5vbmV8IG5vcm1hbCBzaXplfCBiYXNlbGluZSBib3R0b20gbWlkZGxlIHN1YiBzdXBlciB0ZXh0LWJvdHRvbSB0ZXh0LXRvcCB0b3B8IGJvdW5jZSBub25lIHBpbmcgcHVsc2Ugc3BpbnwgYXV0byBzcXVhcmUgdmlkZW98IGF1dG8gZnIgbWF4IG1pbiBweHxub25lIHwgYXV0byBmdWxsIHB4fCBmaXhlZCBsb2NhbCBzY3JvbGx8Y2xpcC0gYm9yZGVyIGNvbnRlbnQgcGFkZGluZyB0ZXh0fG9yaWdpbi0gYm9yZGVyIGNvbnRlbnQgcGFkZGluZ3wgYm90dG9tIGJvdHRvbS1sZWZ0IGJvdHRvbS1yaWdodCBjZW50ZXIgbGVmdCBsZWZ0LWJvdHRvbSBsZWZ0LXRvcCByaWdodCByaWdodC1ib3R0b20gcmlnaHQtdG9wIHRvcCB0b3AtbGVmdCB0b3AtcmlnaHR8IG5vLXJlcGVhdCByZXBlYXQgcmVwZWF0LXJvdW5kIHJlcGVhdC1zcGFjZSByZXBlYXQteCByZXBlYXQteXwgYXV0byBjb250YWluIGNvdmVyfGJsZW5kLSBjb2xvciBjb2xvci1idXJuIGNvbG9yLWRvZGdlIGRhcmtlbiBkaWZmZXJlbmNlIGV4Y2x1c2lvbiBoYXJkLWxpZ2h0IGh1ZSBsaWdodGVuIGx1bWlub3NpdHkgbXVsdGlwbHkgbm9ybWFsIG92ZXJsYXkgc2F0dXJhdGlvbiBzY3JlZW4gc29mdC1saWdodHx0by0gYiBibCBiciBsIHIgdCB0bCB0cnwgYXV0byBkdmggZml0IGZ1bGwgbGggbHZoIG1heCBtaW4gcHggc2NyZWVuIHN2aHwgZGFzaGVkIGRvdHRlZCBkb3VibGUgaGlkZGVuIG5vbmUgc29saWR8IGNvbGxhcHNlIHNlcGFyYXRlfHB4IHxhdXRvIHxmdWxsIHwgY29udGVudCBub25lIHN0cmljdHwgaW5saW5lLXNpemUgc2l6ZXxsYXlvdXQgfHBhaW50IHxzdHlsZSB8IGFyb3VuZCBiYXNlbGluZSBiZXR3ZWVuIGNlbnRlciBjZW50ZXItc2FmZSBlbmQgZW5kLXNhZmUgZXZlbmx5IG5vcm1hbCBzdGFydCBzdHJldGNofCBhbGlhcyBhbGwtc2Nyb2xsIGF1dG8gY2VsbCBjb2wtcmVzaXplIGNvbnRleHQtbWVudSBjb3B5IGNyb3NzaGFpciBkZWZhdWx0IGUtcmVzaXplIGV3LXJlc2l6ZSBncmFiIGdyYWJiaW5nIGhlbHAgbW92ZSBuLXJlc2l6ZSBuZS1yZXNpemUgbmVzdy1yZXNpemUgbm8tZHJvcCBub25lIG5vdC1hbGxvd2VkIG5zLXJlc2l6ZSBudy1yZXNpemUgbndzZS1yZXNpemUgcG9pbnRlciBwcm9ncmVzcyByb3ctcmVzaXplIHMtcmVzaXplIHNlLXJlc2l6ZSBzdy1yZXNpemUgdGV4dCB2ZXJ0aWNhbC10ZXh0IHctcmVzaXplIHdhaXQgem9vbS1pbiB6b29tLW91dHwgZGFzaGVkIGRvdHRlZCBkb3VibGUgc29saWQgd2F2eXwgYXV0byBmcm9tLWZvbnR8cmV2ZXJzZSB8aW5pdGlhbCB8IGluIGluLW91dCBpbml0aWFsIGxpbmVhciBvdXR8IGNvbCBjb2wtcmV2ZXJzZSByb3cgcm93LXJldmVyc2V8IG5vd3JhcCB3cmFwIHdyYXAtcmV2ZXJzZXwgYXV0byBpbml0aWFsIG5vbmV8IGJsYWNrIGJvbGQgZXh0cmFib2xkIGV4dHJhbGlnaHQgbGlnaHQgbWVkaXVtIG5vcm1hbCBzZW1pYm9sZCB0aGlufCBjb25kZW5zZWQgZXhwYW5kZWQgZXh0cmEtY29uZGVuc2VkIGV4dHJhLWV4cGFuZGVkIG5vcm1hbCBzZW1pLWNvbmRlbnNlZCBzZW1pLWV4cGFuZGVkIHVsdHJhLWNvbmRlbnNlZCB1bHRyYS1leHBhbmRlZHxmbG93LSBjb2wgY29sLWRlbnNlIGRlbnNlIHJvdyByb3ctZGVuc2V8IG5vbmUgc3ViZ3JpZHwgYXV0byBkdmggZHZ3IGZpdCBmdWxsIGxoIGx2aCBsdncgbWF4IG1pbiBweCBzY3JlZW4gc3ZoIHN2d3wgYmxvY2sgZmxleCBncmlkIHRhYmxlfCBhdXRvIGR2dyBmaXQgZnVsbCBsdncgbWF4IG1pbiBweCBzY3JlZW4gc3Z3fCBsb29zZSBub25lIG5vcm1hbCBweCByZWxheGVkIHNudWcgdGlnaHR8dGhyb3VnaCB8aXRlbSB8IGluc2lkZSBvdXRzaWRlfCBkZWNpbWFsIGRpc2Mgbm9uZXwgYXV0byBweHwgY2xpcC1ib3JkZXIgY2xpcC1jb250ZW50IGNsaXAtZmlsbCBjbGlwLXBhZGRpbmcgY2xpcC1zdHJva2UgY2xpcC12aWV3IG5vLWNsaXB8IGFkZCBleGNsdWRlIGludGVyc2VjdCBzdWJ0cmFjdHwgYWxwaGEgbHVtaW5hbmNlIG1hdGNofG9yaWdpbi0gYm9yZGVyIGNvbnRlbnQgZmlsbCBwYWRkaW5nIHN0cm9rZSB2aWV3fHR5cGUtIGFscGhhIGx1bWluYW5jZXwgY2lyY2xlIGVsbGlwc2V8IGNsb3Nlc3QtY29ybmVyIGNsb3Nlc3Qtc2lkZSBmYXJ0aGVzdC1jb3JuZXIgZmFydGhlc3Qtc2lkZXxhdC0gYm90dG9tIGJvdHRvbS1sZWZ0IGJvdHRvbS1yaWdodCBjZW50ZXIgbGVmdCBsZWZ0LWJvdHRvbSBsZWZ0LXRvcCByaWdodCByaWdodC1ib3R0b20gcmlnaHQtdG9wIHRvcCB0b3AtbGVmdCB0b3AtcmlnaHR8IGR2aCBmaXQgZnVsbCBsaCBsdmggbWF4IG1pbiBub25lIHB4IHNjcmVlbiBzdmh8IGF1dG8gZHZoIGR2dyBmaXQgZnVsbCBsaCBsdmggbHZ3IG1heCBtaW4gbm9uZSBweCBzY3JlZW4gc3ZoIHN2d3wgZHZ3IGZpdCBmdWxsIGx2dyBtYXggbWluIG5vbmUgcHggc2NyZWVuIHN2d3wgYXV0byBkdmggZHZ3IGZpdCBmdWxsIGx2aCBsdncgbWF4IG1pbiBub25lIHByb3NlIHB4IHN2aCBzdnd8IGF1dG8gZHZoIGR2dyBmaXQgZnVsbCBsdmggbHZ3IG1heCBtaW4gbm9uZSBweCBzY3JlZW4gc3ZoIHN2d3wgY29udGFpbiBjb3ZlciBmaWxsIG5vbmUgc2NhbGUtZG93bnwgZmlyc3QgbGFzdCBub25lfCBkaXN0YW50IGRyYW1hdGljIG1pZHJhbmdlIG5lYXIgbm9uZSBub3JtYWx8aW5zZXQgfCBmdWxsIG5vbmV8M2QgfCBhdXRvIHNtb290aHxndXR0ZXItIGF1dG8gYm90aCBzdGFibGV8IGF1dG8gbm9uZSB0aGlufCBpbm5lciBub25lfCBhdXRvIGR2aCBkdncgZml0IGZ1bGwgbHZoIGx2dyBtYXggbWluIHB4IHN2aCBzdnd8YmFzZSB8IGNlbnRlciBlbmQganVzdGlmeSBsZWZ0IHJpZ2h0IHN0YXJ0fCBjbGlwIGVsbGlwc2lzfCBiYWxhbmNlIG5vd3JhcCBwcmV0dHkgd3JhcHwgbm9ybWFsIHRpZ2h0IHRpZ2h0ZXIgd2lkZSB3aWRlciB3aWRlc3R8IGNwdSBncHUgbm9uZXwgM2QgZmxhdHwgYWxsIGNvbG9ycyBub25lIG9wYWNpdHkgc2hhZG93IHRyYW5zZm9ybXwgZGlzY3JldGUgbm9ybWFsfCBmdWxsIHB4fCBhdXRvIGR2aCBkdncgZml0IGZ1bGwgbHZoIGx2dyBtYXggbWluIHB4IHNjcmVlbiBzdmggc3Z3fCBhdXRvIGNvbnRlbnRzIHNjcm9sbCB0cmFuc2Zvcm1cIi5zcGxpdChcInxcIikubWFwKChzKSA9PiB7XG5cdGNvbnN0IHRhaWxzID0gcy5zcGxpdChcIiBcIik7XG5cdGNvbnN0IHByZWZpeCA9IHRhaWxzLnNoaWZ0KCk7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgdGFpbHMubGVuZ3RoOyBpKyspIHRhaWxzW2ldID0gcHJlZml4ICsgdGFpbHNbaV07XG5cdHJldHVybiB0YWlscztcbn0pO1xuY29uc3QgQUEgPSBEWihcIjAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAyNjIyNDI6NkAyMDAwMDAwMDY6MjQwQjQyODo0NDIyNDAwMDAyMDQ2MDQ0MjIyNDI2MjIwMDI2NjQyNjQyNDYyMDI2MjI0MjIyODI0MjIwMDIyNDAwMDAwMDAwXFxcXDAwTjIyMjQyMjI0MjIyMjIyMjIyNDA2MjI0MjIyMjIyMjQyMjIyNjI2NDIyMjQyMjIyMjIyMjIyMjIyMjQ0MjgwNDIyMjQyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMDw0PDAyMDQyNjAwMDI0NDQwMjAyMDQyMjQ0MjJcIik7XG5jb25zdCBBRyA9IERaKFwiyaAyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjLLlTQyMjIyMjY+NsqwMjLKt8q6yrfKusq3NDLKtDLKkzIyPjYyMTQyMsm2MjIyybnJvMm3ybrJt8m6MjLJsTQyMjIyyagyyacyNjYyMsmYyZMyNDTGuMa1MjIyXWQyNDI0MseWx5PGmsOEyKsyMjYzyKjIpcioMjIyMjIyMsejMjIyMjIyMjIyMjIyMjIyMjIyx4LGvTLGvsa1MjIyMjIyMjQyMjIyMsacxpEyMjIyMjIyMjIyMjIyMjIyMjIyMjE0NMWmxaMyMsWixZ8yMjIyMjIyMjIyMjIyMjIyMjIyMjLEuDLEsTY4xKbEo8SmyaHFsDTEoMKrwq7EnTgyMsSUxJHElDLEkzIyMjI2MjJcIik7XG5jb25zdCBBUyA9IERaKFwiMDIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMDIwMjE0MjIyMjIyMjJDRjIyMDBHSjAyMTA0MjIyMldaMjIySUwwYWQyYzEwaDIyMjJVMDBYMjAyW14ydzAwMDAxMjB6eXx9woAyMsKDwobChToyMnoyMjIyMjIyMjIyMkcwMDBxwoZPVkkwMDAwMHvCmDLCmTw0MDAwMMKMwptAMDAwMDBHwqbCpzAwMMKqMDAwMDAwMDAwMDAwMDDCjTAyMUvCrMKrMDDCrsKTMDAwMDAwMDAwMDAwMDAwMDAwMDAwwpYyMjLCm0hHSF8xwrgyMjLCvTLCvjIyMjLDh8OKMDAwwq3CsDLCsVwiKTtcbmNvbnN0IGxpdEFuY2hvciA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgSW50MzJBcnJheSg5ODcpO1xuY29uc3QgbGl0R3JvdXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IEludDMyQXJyYXkoOTg3KTtcbmNvbnN0IGxpdFBvb2wgPSAvKiBAX19QVVJFX18gKi8gbmV3IEludDMyQXJyYXkoOTg3KTtcbmxldCBwb29sVGV4dCA9IFwiXCI7XG5jb25zdCBwb29sT2Zmc2V0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgSW50MzJBcnJheSgxMDIyKTtcbntcblx0Y29uc3QgdGFpbFJlZiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGxldCBuZXh0UmVmID0gMDtcblx0bGV0IGUgPSAwO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IEFBLmxlbmd0aDsgaSsrKSBmb3IgKGNvbnN0IHRhaWwgb2YgU0VUU1tBU1tpXV0pIHtcblx0XHRsZXQgciA9IHRhaWxSZWYuZ2V0KHRhaWwpO1xuXHRcdGlmIChyID09PSB2b2lkIDApIHtcblx0XHRcdHIgPSBuZXh0UmVmKys7XG5cdFx0XHR0YWlsUmVmLnNldCh0YWlsLCByKTtcblx0XHRcdHBvb2xPZmZzZXRzW3IgKiAyXSA9IHBvb2xUZXh0Lmxlbmd0aDtcblx0XHRcdHBvb2xPZmZzZXRzW3IgKiAyICsgMV0gPSB0YWlsLmxlbmd0aDtcblx0XHRcdHBvb2xUZXh0ICs9IHRhaWw7XG5cdFx0fVxuXHRcdGxpdEFuY2hvcltlXSA9IEFBW2ldO1xuXHRcdGxpdEdyb3VwW2VdID0gQUdbaV07XG5cdFx0bGl0UG9vbFtlXSA9IHI7XG5cdFx0ZSsrO1xuXHR9XG59XG5jb25zdCBhZGpHaWQgPSBEWihcIjBiMk46MjIyQFI+RkAyODbCpjJASDJEMjY2MjI2RkIyMkIyPkJEXFxcXDZOMjIyMjJaMjIyRDIyMnBcIik7XG5jb25zdCBhZGpTdGFydCA9IFBTKFUoXCIxOjoyNDQ0NDQzMjo0NDI6NDQ6NDQ+MjIyMjIyOjQ0OjQ0MjEzMjI1MTExMTEzMTExMTExMTRcIikpO1xuY29uc3QgYWRqVGd0ID0gRFooXCIywoo0QTszM049Q0BINEE7MzNOPUNAPDI3OzgzOjs4MzkzTlE6M05RyrAyMjLLicK6xbTFvTJSMj0xOGPGtMOFxYfCnD1jxJ7Dm0MxxojHnciIOsSnMjU9MTFEM0FAND08MTsxREVyMjU7MTFCMz88Njs6MzcxQkNuOUA3PTw4MTkyPjJFMTIxQDlARUhFQDk+MlQyNTUxMTwzOTg0NTQxMzE8PVYyNTUxMTwzOTg0NTQxMzE8PcKExqdOxb4yxJDDpTI0MkwyMjIyOTAwMDBmMjI1MDDJmzAwMMeYMjIyXCIpO1xuY29uc3QgcGF0R2lkID0gVShcIsSzXCIpO1xuY29uc3QgcGF0VGd0ID0gVShcIsKXXCIpO1xuY29uc3QgcG9zdGZpeExvb2t1cEdyb3VwcyA9IFUoXCIxXCIpO1xuY29uc3Qgb3JkZXJTZW5zaXRpdmVNb2RpZmllcnMgPSBcIiogKiogYWZ0ZXIgYmFja2Ryb3AgYmVmb3JlIGRldGFpbHMtY29udGVudCBmaWxlIGZpcnN0LWxldHRlciBmaXJzdC1saW5lIG1hcmtlciBwbGFjZWhvbGRlciBzZWxlY3Rpb25cIjtcbnZhciB0YWJsZXNfZ2VuZXJhdGVkX2RlZmF1bHQgPSB7XG5cdEdST1VQX0NPVU5ULFxuXHRjdXN0b21WYWxpZGF0b3JOYW1lcyxcblx0ZWRnZVN0YXJ0LFxuXHRsYWJlbFN0YXJ0LFxuXHRsYWJlbFRleHQsXG5cdGVkZ2VUYXJnZXQsXG5cdG5vZGVHcm91cCxcblx0bm9kZVZsaXN0LFxuXHR2bGlzdFBhdCxcblx0dmxpc3RPcHMsXG5cdHZsaXN0UmVmLFxuXHR2bGlzdEdyb3VwLFxuXHRsaXRBbmNob3IsXG5cdGxpdEdyb3VwLFxuXHRsaXRQb29sLFxuXHRwb29sT2Zmc2V0cyxcblx0cG9vbFRleHQsXG5cdGFkakdpZCxcblx0YWRqU3RhcnQsXG5cdGFkalRndCxcblx0cGF0R2lkLFxuXHRwYXRUZ3QsXG5cdHBvc3RmaXhMb29rdXBHcm91cHMsXG5cdG9yZGVyU2Vuc2l0aXZlTW9kaWZpZXJzXG59O1xuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHRhYmxlc19nZW5lcmF0ZWRfZGVmYXVsdCBhcyBkZWZhdWx0IH07IiwiLy8jcmVnaW9uIHNyYy9lbmdpbmUudHNcbmNvbnN0IElTX0pTQyA9IFwibGluZVwiIGluIC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoKTtcbmNvbnN0IEVYVEVSTkFMID0gLTE7XG5jb25zdCBERUFEID0gLTE7XG5jb25zdCBmbnYgPSAoc3RyLCBzLCBlKSA9PiB7XG5cdGxldCBoID0gMjE2NjEzNjI2MTtcblx0Zm9yIChsZXQgcCA9IHM7IHAgPCBlOyBwKyspIGggPSBNYXRoLmltdWwoaCBeIHN0ci5jaGFyQ29kZUF0KHApLCAxNjc3NzYxOSk7XG5cdHJldHVybiBoO1xufTtcbmNvbnN0IHNwYW5IYXNoID0gKHN0ciwgcywgZSkgPT4ge1xuXHRjb25zdCBsZW4gPSBlIC0gcztcblx0bGV0IGggPSBNYXRoLmltdWwobGVuLCAyNjU0NDM1NzYxKSBeIHN0ci5jaGFyQ29kZUF0KHMpO1xuXHRpZiAobGVuID4gMykge1xuXHRcdGNvbnN0IHEgPSBsZW4gPj4gMjtcblx0XHRjb25zdCBtID0gbGVuID4+IDE7XG5cdFx0aCA9IE1hdGguaW11bChoIF4gc3RyLmNoYXJDb2RlQXQocyArIDEpIDw8IDggXiBzdHIuY2hhckNvZGVBdChzICsgMikgPDwgMTYgXiBzdHIuY2hhckNvZGVBdChzICsgcSksIDIyNDY4MjI1MDcpO1xuXHRcdGggPSBNYXRoLmltdWwoaCBeIHN0ci5jaGFyQ29kZUF0KHMgKyBtKSA8PCA4IF4gc3RyLmNoYXJDb2RlQXQocyArIG0gKyBxKSA8PCAxNiBeIHN0ci5jaGFyQ29kZUF0KGUgLSAzKSwgMzI2NjQ4OTkwOSk7XG5cdFx0aCBePSBzdHIuY2hhckNvZGVBdChlIC0gMikgPDwgOCBeIHN0ci5jaGFyQ29kZUF0KGUgLSAxKSA8PCAxNjtcblx0XHRmb3IgKGxldCBwID0gcyArIDMsIHEgPSBlIC0gNDsgcCA8IHMgKyA4ICYmIHAgPCBxOyBwKyssIHEtLSkgaCA9IE1hdGguaW11bChoIF4gc3RyLmNoYXJDb2RlQXQocCkgXiBzdHIuY2hhckNvZGVBdChxKSA8PCA4LCAxNjc3NzYxOSk7XG5cdH1cblx0cmV0dXJuIGggXiBoID4+PiAxNSB8IDA7XG59O1xuY29uc3QgY3JlYXRlRW5naW5lID0gKFQsIHZhbGlkYXRvckltcGxzLCBvcHRpb25zID0ge30pID0+IHtcblx0Y29uc3QgeyBHUk9VUF9DT1VOVCwgZWRnZVN0YXJ0LCBsYWJlbFN0YXJ0LCBsYWJlbFRleHQsIGVkZ2VUYXJnZXQsIG5vZGVHcm91cCwgbm9kZVZsaXN0LCB2bGlzdFBhdCwgdmxpc3RPcHMsIHZsaXN0UmVmLCB2bGlzdEdyb3VwLCBsaXRBbmNob3IsIGxpdEdyb3VwLCBsaXRQb29sLCBwb29sT2Zmc2V0cywgcG9vbFRleHQsIGFkakdpZCwgYWRqU3RhcnQsIGFkalRndCwgcGF0R2lkLCBwYXRUZ3QsIHBvc3RmaXhMb29rdXBHcm91cHMsIGN1c3RvbVZhbGlkYXRvck5hbWVzLCBvcmRlclNlbnNpdGl2ZU1vZGlmaWVycyB9ID0gVDtcblx0Y29uc3QgYWRqUm93ID0gbmV3IEludDMyQXJyYXkoR1JPVVBfQ09VTlQpLmZpbGwoLTEpO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGFkakdpZC5sZW5ndGg7IGkrKykgYWRqUm93W2FkakdpZFtpXV0gPSBpO1xuXHRsZXQgbWF4QWRqID0gMDtcblx0Zm9yIChsZXQgciA9IDA7IHIgKyAxIDwgYWRqU3RhcnQubGVuZ3RoOyByKyspIHtcblx0XHRjb25zdCBuID0gYWRqU3RhcnRbciArIDFdIC0gYWRqU3RhcnRbcl07XG5cdFx0aWYgKG4gPiBtYXhBZGopIG1heEFkaiA9IG47XG5cdH1cblx0bGV0IENMQUlNX1BFUl9UT0tFTiA9IDMyO1xuXHR3aGlsZSAoQ0xBSU1fUEVSX1RPS0VOIDwgMiAqICgxICsgbWF4QWRqICsgcGF0R2lkLmxlbmd0aCkpIENMQUlNX1BFUl9UT0tFTiA8PD0gMTtcblx0Y29uc3QgdmdTdGFydCA9IG5ldyBJbnQzMkFycmF5KHZsaXN0UmVmLmxlbmd0aCArIDEpO1xuXHRmb3IgKGxldCBsID0gMDsgbCA8IHZsaXN0UmVmLmxlbmd0aDsgbCsrKSB2Z1N0YXJ0W2wgKyAxXSA9IHZnU3RhcnRbbF0gKyB2bGlzdFBhdFt2bGlzdFJlZltsXSArIDFdIC0gdmxpc3RQYXRbdmxpc3RSZWZbbF1dO1xuXHRjb25zdCBwb3N0Zml4TG9va3VwU2V0ID0gbmV3IFVpbnQ4QXJyYXkoR1JPVVBfQ09VTlQpO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHBvc3RmaXhMb29rdXBHcm91cHMubGVuZ3RoOyBpKyspIHBvc3RmaXhMb29rdXBTZXRbcG9zdGZpeExvb2t1cEdyb3Vwc1tpXV0gPSAxO1xuXHRjb25zdCBub2RlQ291bnQgPSBlZGdlU3RhcnQubGVuZ3RoIC0gMTtcblx0Y29uc3Qgbm9kZUhhc0xpdCA9IG5ldyBVaW50OEFycmF5KG5vZGVDb3VudCk7XG5cdGxldCBsaXRNYXhMZW4gPSAwO1xuXHRsZXQgbGl0Tm9BcmIgPSB0cnVlO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGxpdEFuY2hvci5sZW5ndGg7IGkrKykge1xuXHRcdG5vZGVIYXNMaXRbbGl0QW5jaG9yW2ldXSA9IDE7XG5cdFx0Y29uc3QgbGVuID0gcG9vbE9mZnNldHNbbGl0UG9vbFtpXSAqIDIgKyAxXTtcblx0XHRpZiAobGVuID4gbGl0TWF4TGVuKSBsaXRNYXhMZW4gPSBsZW47XG5cdFx0Y29uc3QgYzAgPSBwb29sVGV4dC5jaGFyQ29kZUF0KHBvb2xPZmZzZXRzW2xpdFBvb2xbaV0gKiAyXSk7XG5cdFx0aWYgKGMwID09PSA5MSB8fCBjMCA9PT0gNDApIGxpdE5vQXJiID0gZmFsc2U7XG5cdH1cblx0bGV0IExJVF9TSVpFID0gMTtcblx0d2hpbGUgKExJVF9TSVpFIDwgbGl0QW5jaG9yLmxlbmd0aCAqIDIpIExJVF9TSVpFIDw8PSAxO1xuXHRjb25zdCBsaXRUYWJsZSA9IG5ldyBJbnQzMkFycmF5KExJVF9TSVpFKS5maWxsKC0xKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBsaXRBbmNob3IubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBvZmYgPSBwb29sT2Zmc2V0c1tsaXRQb29sW2ldICogMl07XG5cdFx0bGV0IGlkeCA9IChmbnYocG9vbFRleHQsIG9mZiwgb2ZmICsgcG9vbE9mZnNldHNbbGl0UG9vbFtpXSAqIDIgKyAxXSkgXiBNYXRoLmltdWwobGl0QW5jaG9yW2ldLCAyNjU0NDM1NzYxKSB8IDApICYgTElUX1NJWkUgLSAxO1xuXHRcdHdoaWxlIChsaXRUYWJsZVtpZHhdICE9PSAtMSkgaWR4ID0gaWR4ICsgMSAmIExJVF9TSVpFIC0gMTtcblx0XHRsaXRUYWJsZVtpZHhdID0gaTtcblx0fVxuXHRjb25zdCBsaXRQcm9iZSA9IChhbmNob3IsIGlucHV0LCBzLCBlKSA9PiB7XG5cdFx0bGV0IGlkeCA9IChmbnYoaW5wdXQsIHMsIGUpIF4gTWF0aC5pbXVsKGFuY2hvciwgMjY1NDQzNTc2MSkgfCAwKSAmIExJVF9TSVpFIC0gMTtcblx0XHRjb25zdCBsZW4gPSBlIC0gcztcblx0XHRmb3IgKDs7KSB7XG5cdFx0XHRjb25zdCBlbnRyeSA9IGxpdFRhYmxlW2lkeF07XG5cdFx0XHRpZiAoZW50cnkgPT09IC0xKSByZXR1cm4gLTE7XG5cdFx0XHRpZiAobGl0QW5jaG9yW2VudHJ5XSA9PT0gYW5jaG9yICYmIHBvb2xPZmZzZXRzW2xpdFBvb2xbZW50cnldICogMiArIDFdID09PSBsZW4pIHtcblx0XHRcdFx0Y29uc3Qgb2ZmID0gcG9vbE9mZnNldHNbbGl0UG9vbFtlbnRyeV0gKiAyXTtcblx0XHRcdFx0bGV0IG9rID0gdHJ1ZTtcblx0XHRcdFx0Zm9yIChsZXQgayA9IDA7IGsgPCBsZW47IGsrKykgaWYgKHBvb2xUZXh0LmNoYXJDb2RlQXQob2ZmICsgaykgIT09IGlucHV0LmNoYXJDb2RlQXQocyArIGspKSB7XG5cdFx0XHRcdFx0b2sgPSBmYWxzZTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAob2spIHJldHVybiBsaXRHcm91cFtlbnRyeV07XG5cdFx0XHR9XG5cdFx0XHRpZHggPSBpZHggKyAxICYgTElUX1NJWkUgLSAxO1xuXHRcdH1cblx0fTtcblx0Y29uc3QgY2FjaGVTaXplID0gb3B0aW9ucy5jYWNoZVNpemUgPz8gODE5Mjtcblx0Y29uc3QgUkFXX1BSRUZJWCA9IG9wdGlvbnMucHJlZml4ID8/IFQucHJlZml4ID8/IFwiXCI7XG5cdGNvbnN0IEZVTExfUFJFRklYID0gUkFXX1BSRUZJWCA9PT0gXCJcIiA/IFwiXCIgOiBSQVdfUFJFRklYICsgXCI6XCI7XG5cdGNvbnN0IEZQTCA9IEZVTExfUFJFRklYLmxlbmd0aDtcblx0Y29uc3QgdkN1c3RvbSA9IChjdXN0b21WYWxpZGF0b3JOYW1lcyA/PyBbXSkubWFwKChuYW1lKSA9PiB7XG5cdFx0Y29uc3QgZm4gPSB2YWxpZGF0b3JJbXBscyAmJiB2YWxpZGF0b3JJbXBsc1tuYW1lXTtcblx0XHRpZiAoIWZuKSB0aHJvdyBuZXcgRXJyb3IoXCJjbjogbWlzc2luZyB2YWxpZGF0b3IgXCIgKyBuYW1lKTtcblx0XHRyZXR1cm4gZm47XG5cdH0pO1xuXHRjb25zdCBsZW5ndGhVbml0UmVnZXggPSAvXFxkKyglfHB4fHI/ZW18W3NkbF0/dihbaHdpYl18bWlufG1heCl8cHR8cGN8aW58Y218bW18Y2FwfGNofGV4fHI/bGh8Y3Eod3xofGl8YnxtaW58bWF4KSl8XFxiKGNhbGN8bWlufG1heHxjbGFtcClcXCguK1xcKXxeMCQvO1xuXHRjb25zdCBjb2xvckZ1bmN0aW9uUmVnZXggPSAvXihyZ2JhP3xoc2xhP3xod2J8KG9rKT8obGFifGxjaCl8Y29sb3ItbWl4KVxcKC4rXFwpJC87XG5cdGNvbnN0IHNoYWRvd1JlZ2V4ID0gL14oaW5zZXRfKT8tPygoXFxkKyk/XFwuPyhcXGQrKVthLXpdK3wwKV8tPygoXFxkKyk/XFwuPyhcXGQrKVthLXpdK3wwKS87XG5cdGNvbnN0IGltYWdlUmVnZXggPSAvXih1cmx8aW1hZ2V8aW1hZ2Utc2V0fGNyb3NzLWZhZGV8ZWxlbWVudHwocmVwZWF0aW5nLSk/KGxpbmVhcnxyYWRpYWx8Y29uaWMpLWdyYWRpZW50KVxcKC4rXFwpJC87XG5cdGxldCBhS2luZCA9IDA7XG5cdGxldCBhTGFiZWxTID0gLTE7XG5cdGxldCBhTGFiZWxFID0gLTE7XG5cdGxldCBhVmFsUyA9IC0xO1xuXHRsZXQgYVZhbEUgPSAtMTtcblx0Y29uc3QgaXNXb3JkQ29kZSA9IChjKSA9PiBjID49IDk3ICYmIGMgPD0gMTIyIHx8IGMgPj0gNjUgJiYgYyA8PSA5MCB8fCBjID49IDQ4ICYmIGMgPD0gNTcgfHwgYyA9PT0gOTU7XG5cdGNvbnN0IGlzVW5pV1MgPSAoYykgPT4gL1xccy8udGVzdChTdHJpbmcuZnJvbUNoYXJDb2RlKGMpKTtcblx0Y29uc3QgYW5hbHl6ZUFyYiA9IChpbnB1dCwgcywgZSkgPT4ge1xuXHRcdGFLaW5kID0gMDtcblx0XHRhTGFiZWxTID0gLTE7XG5cdFx0aWYgKGUgLSBzIDwgMykgcmV0dXJuO1xuXHRcdGNvbnN0IGMwID0gaW5wdXQuY2hhckNvZGVBdChzKTtcblx0XHRjb25zdCBjbCA9IGlucHV0LmNoYXJDb2RlQXQoZSAtIDEpO1xuXHRcdGlmIChjMCA9PT0gOTEgJiYgY2wgPT09IDkzKSBhS2luZCA9IDE7XG5cdFx0ZWxzZSBpZiAoYzAgPT09IDQwICYmIGNsID09PSA0MSkgYUtpbmQgPSAyO1xuXHRcdGVsc2UgcmV0dXJuO1xuXHRcdGFWYWxTID0gcyArIDE7XG5cdFx0YVZhbEUgPSBlIC0gMTtcblx0XHRsZXQgcCA9IHMgKyAxO1xuXHRcdGlmIChpc1dvcmRDb2RlKGlucHV0LmNoYXJDb2RlQXQocCkpKSB7XG5cdFx0XHRwKys7XG5cdFx0XHR3aGlsZSAocCA8IGUgLSAxKSB7XG5cdFx0XHRcdGNvbnN0IGMgPSBpbnB1dC5jaGFyQ29kZUF0KHApO1xuXHRcdFx0XHRpZiAoIWlzV29yZENvZGUoYykgJiYgYyAhPT0gNDUpIGJyZWFrO1xuXHRcdFx0XHRwKys7XG5cdFx0XHR9XG5cdFx0XHRpZiAocCA8IGUgLSAyICYmIGlucHV0LmNoYXJDb2RlQXQocCkgPT09IDU4KSB7XG5cdFx0XHRcdGFMYWJlbFMgPSBzICsgMTtcblx0XHRcdFx0YUxhYmVsRSA9IHA7XG5cdFx0XHRcdGFWYWxTID0gcCArIDE7XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBzcGFuRXEgPSAoaW5wdXQsIHMsIGUsIHN0cikgPT4ge1xuXHRcdGlmIChlIC0gcyAhPT0gc3RyLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgaSsrKSBpZiAoaW5wdXQuY2hhckNvZGVBdChzICsgaSkgIT09IHN0ci5jaGFyQ29kZUF0KGkpKSByZXR1cm4gZmFsc2U7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH07XG5cdGNvbnN0IGZyYWN0aW9uUmVnZXggPSAvXlxcZCsoPzpcXC5cXGQrKT9cXC9cXGQrKD86XFwuXFxkKyk/JC87XG5cdGNvbnN0IHRzaGlydFJlZ2V4ID0gL14oXFxkKyhcXC5cXGQrKT8pPyh4c3xzbXxtZHxsZ3x4bCkkLztcblx0Y29uc3QgaXNOdW1TdHIgPSAodikgPT4gISF2ICYmICFOdW1iZXIuaXNOYU4oTnVtYmVyKHYpKTtcblx0Y29uc3Qgc3BhbklzTmFtZWRDb250YWluZXJRdWVyeSA9IChpbnB1dCwgcywgZSkgPT4ge1xuXHRcdGlmIChlIC0gcyA8IDExIHx8ICFzcGFuRXEoaW5wdXQsIHMsIHMgKyAxMCwgXCJAY29udGFpbmVyXCIpKSByZXR1cm4gZmFsc2U7XG5cdFx0aWYgKGlucHV0LmNoYXJDb2RlQXQocyArIDEwKSA9PT0gNDcpIHJldHVybiBlIC0gcyA+PSAxMjtcblx0XHRjb25zdCBjMTEgPSBpbnB1dC5jaGFyQ29kZUF0KHMgKyAxMSk7XG5cdFx0cmV0dXJuIGMxMSA9PT0gMTE1ICYmIGUgLSBzID49IDE3ICYmIHNwYW5FcShpbnB1dCwgcyArIDEwLCBzICsgMTYsIFwiLXNpemUvXCIpIHx8IGMxMSA9PT0gMTEwICYmIGUgLSBzID49IDE5ICYmIHNwYW5FcShpbnB1dCwgcyArIDEwLCBzICsgMTgsIFwiLW5vcm1hbC9cIik7XG5cdH07XG5cdGNvbnN0IFZLSU5EID0gW1xuXHRcdDEsXG5cdFx0MSxcblx0XHQxLFxuXHRcdDEsXG5cdFx0MSxcblx0XHQxLFxuXHRcdDEsXG5cdFx0MSxcblx0XHQyLFxuXHRcdDIsXG5cdFx0Mixcblx0XHQyLFxuXHRcdDIsXG5cdFx0Mixcblx0XHQyXG5cdF07XG5cdGNvbnN0IFZMQUJFTFMgPSBcImxlbmd0aHxudW1iZXJ8bnVtYmVyIHdlaWdodHxmYW1pbHktbmFtZXxwb3NpdGlvbiBwZXJjZW50YWdlfGxlbmd0aCBzaXplIGJnLXNpemV8aW1hZ2UgdXJsfHNoYWRvd3xsZW5ndGh8ZmFtaWx5LW5hbWV8cG9zaXRpb24gcGVyY2VudGFnZXxsZW5ndGggc2l6ZSBiZy1zaXplfGltYWdlIHVybHxzaGFkb3d8bnVtYmVyIHdlaWdodFwiLnNwbGl0KFwifFwiKS5tYXAoKHMpID0+IHMuc3BsaXQoXCIgXCIpKTtcblx0Y29uc3QgVkZBTEwgPSBbXG5cdFx0Mixcblx0XHQzLFxuXHRcdDEsXG5cdFx0MCxcblx0XHQwLFxuXHRcdDAsXG5cdFx0NCxcblx0XHQ1LFxuXHRcdDAsXG5cdFx0MCxcblx0XHQwLFxuXHRcdDAsXG5cdFx0MCxcblx0XHQxLFxuXHRcdDFcblx0XTtcblx0Y29uc3QgcnVuVmFsaWRhdG9yID0gKG9wLCBpbnB1dCwgcywgZSkgPT4ge1xuXHRcdGlmIChvcCA+PSAxMCkge1xuXHRcdFx0aWYgKG9wID49IDI1KSByZXR1cm4gdkN1c3RvbVtvcCAtIDI1XShpbnB1dC5zbGljZShzLCBlKSk7XG5cdFx0XHRjb25zdCBpID0gb3AgLSAxMDtcblx0XHRcdGlmIChhS2luZCAhPT0gVktJTkRbaV0pIHJldHVybiBmYWxzZTtcblx0XHRcdGlmIChhTGFiZWxTID49IDApIHtcblx0XHRcdFx0Zm9yIChjb25zdCBMIG9mIFZMQUJFTFNbaV0pIGlmIChzcGFuRXEoaW5wdXQsIGFMYWJlbFMsIGFMYWJlbEUsIEwpKSByZXR1cm4gdHJ1ZTtcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0c3dpdGNoIChWRkFMTFtpXSkge1xuXHRcdFx0XHRjYXNlIDA6IHJldHVybiBmYWxzZTtcblx0XHRcdFx0Y2FzZSAxOiByZXR1cm4gdHJ1ZTtcblx0XHRcdFx0Y2FzZSAyOiB7XG5cdFx0XHRcdFx0Y29uc3QgdiA9IGlucHV0LnNsaWNlKGFWYWxTLCBhVmFsRSk7XG5cdFx0XHRcdFx0cmV0dXJuIGxlbmd0aFVuaXRSZWdleC50ZXN0KHYpICYmICFjb2xvckZ1bmN0aW9uUmVnZXgudGVzdCh2KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjYXNlIDM6IHJldHVybiBpc051bVN0cihpbnB1dC5zbGljZShhVmFsUywgYVZhbEUpKTtcblx0XHRcdFx0Y2FzZSA0OiByZXR1cm4gaW1hZ2VSZWdleC50ZXN0KGlucHV0LnNsaWNlKGFWYWxTLCBhVmFsRSkpO1xuXHRcdFx0XHRkZWZhdWx0OiByZXR1cm4gc2hhZG93UmVnZXgudGVzdChpbnB1dC5zbGljZShhVmFsUywgYVZhbEUpKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0c3dpdGNoIChvcCkge1xuXHRcdFx0Y2FzZSAwOiByZXR1cm4gdHJ1ZTtcblx0XHRcdGNhc2UgMTogcmV0dXJuIGFLaW5kID09PSAwO1xuXHRcdFx0Y2FzZSAyOiByZXR1cm4gYUtpbmQgPT09IDE7XG5cdFx0XHRjYXNlIDM6IHJldHVybiBhS2luZCA9PT0gMjtcblx0XHRcdGNhc2UgNDogcmV0dXJuIGZyYWN0aW9uUmVnZXgudGVzdChpbnB1dC5zbGljZShzLCBlKSk7XG5cdFx0XHRjYXNlIDU6IHJldHVybiBpc051bVN0cihpbnB1dC5zbGljZShzLCBlKSk7XG5cdFx0XHRjYXNlIDY6IHtcblx0XHRcdFx0Y29uc3QgdiA9IGlucHV0LnNsaWNlKHMsIGUpO1xuXHRcdFx0XHRyZXR1cm4gISF2ICYmIE51bWJlci5pc0ludGVnZXIoTnVtYmVyKHYpKTtcblx0XHRcdH1cblx0XHRcdGNhc2UgNzogcmV0dXJuIGUgPiBzICYmIGlucHV0LmNoYXJDb2RlQXQoZSAtIDEpID09PSAzNyAmJiBpc051bVN0cihpbnB1dC5zbGljZShzLCBlIC0gMSkpO1xuXHRcdFx0Y2FzZSA4OiByZXR1cm4gdHNoaXJ0UmVnZXgudGVzdChpbnB1dC5zbGljZShzLCBlKSk7XG5cdFx0XHRkZWZhdWx0OiByZXR1cm4gc3BhbklzTmFtZWRDb250YWluZXJRdWVyeShpbnB1dCwgcywgZSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBvcmRlclNlbnNpdGl2ZSA9IG5ldyBTZXQodHlwZW9mIG9yZGVyU2Vuc2l0aXZlTW9kaWZpZXJzID09PSBcInN0cmluZ1wiID8gb3JkZXJTZW5zaXRpdmVNb2RpZmllcnMuc3BsaXQoXCIgXCIpIDogb3JkZXJTZW5zaXRpdmVNb2RpZmllcnMpO1xuXHRjb25zdCBpbnRlcm5TcGFuID0gKG1hcCwgaW5wdXQsIHMsIGUsIGltcCwgbWFrZSkgPT4ge1xuXHRcdGNvbnN0IGggPSBmbnYoaW5wdXQsIHMsIGUpIF4gKGltcCA/IDI2NTQ0MzU3NjkgOiAwKSB8IDA7XG5cdFx0bGV0IGJ1Y2tldCA9IG1hcC5nZXQoaCk7XG5cdFx0aWYgKGJ1Y2tldCAhPT0gdm9pZCAwKSBvdXRlcjogZm9yIChsZXQgYiA9IDA7IGIgPCBidWNrZXQubGVuZ3RoOyBiKyspIHtcblx0XHRcdGNvbnN0IGVuID0gYnVja2V0W2JdO1xuXHRcdFx0aWYgKGVuLmltcCAhPT0gaW1wIHx8IGVuLmsubGVuZ3RoICE9PSBlIC0gcykgY29udGludWU7XG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGVuLmsubGVuZ3RoOyBpKyspIGlmIChlbi5rLmNoYXJDb2RlQXQoaSkgIT09IGlucHV0LmNoYXJDb2RlQXQocyArIGkpKSBjb250aW51ZSBvdXRlcjtcblx0XHRcdHJldHVybiBlbi5pZDtcblx0XHR9XG5cdFx0ZWxzZSBtYXAuc2V0KGgsIGJ1Y2tldCA9IFtdKTtcblx0XHRjb25zdCBrID0gaW5wdXQuc2xpY2UocywgZSk7XG5cdFx0Y29uc3QgaWQgPSBtYWtlKGspO1xuXHRcdGJ1Y2tldC5wdXNoKHtcblx0XHRcdGssXG5cdFx0XHRpbXAsXG5cdFx0XHRpZFxuXHRcdH0pO1xuXHRcdHJldHVybiBpZDtcblx0fTtcblx0bGV0IGN0eEJ5SGFzaCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGxldCBjdHhCeUNhbm9uID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0bGV0IG5leHRDdHhJZCA9IDI7XG5cdGNvbnN0IE1BWF9DVFggPSA0MDk2O1xuXHRjb25zdCBjYW5vbmljYWxpemVDb250ZXh0ID0gKHJhdywgaW1wb3J0YW50KSA9PiB7XG5cdFx0Y29uc3QgbW9kcyA9IFtdO1xuXHRcdGxldCBkQiA9IDAsIGRQID0gMCwgc3RhcnQgPSAwO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Lmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRjb25zdCBjID0gcmF3LmNoYXJDb2RlQXQoaSk7XG5cdFx0XHRpZiAoZEIgPT09IDAgJiYgZFAgPT09IDAgJiYgYyA9PT0gNTgpIHtcblx0XHRcdFx0bW9kcy5wdXNoKHJhdy5zbGljZShzdGFydCwgaSkpO1xuXHRcdFx0XHRzdGFydCA9IGkgKyAxO1xuXHRcdFx0fSBlbHNlIGlmIChjID09PSA5MSkgZEIrKztcblx0XHRcdGVsc2UgaWYgKGMgPT09IDkzKSBkQi0tO1xuXHRcdFx0ZWxzZSBpZiAoYyA9PT0gNDApIGRQKys7XG5cdFx0XHRlbHNlIGlmIChjID09PSA0MSkgZFAtLTtcblx0XHR9XG5cdFx0bW9kcy5wdXNoKHJhdy5zbGljZShzdGFydCkpO1xuXHRcdGxldCBjYW5vbmljYWwgPSBtb2RzWzBdO1xuXHRcdGlmIChtb2RzLmxlbmd0aCA+IDEpIHtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IFtdO1xuXHRcdFx0bGV0IHNlZ21lbnQgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgbW9kIG9mIG1vZHMpIGlmIChtb2QuY2hhckNvZGVBdCgwKSA9PT0gOTEgfHwgb3JkZXJTZW5zaXRpdmUuaGFzKG1vZCkpIHtcblx0XHRcdFx0aWYgKHNlZ21lbnQubGVuZ3RoKSB7XG5cdFx0XHRcdFx0cmVzdWx0LnB1c2goLi4uc2VnbWVudC5zb3J0KCkpO1xuXHRcdFx0XHRcdHNlZ21lbnQgPSBbXTtcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXN1bHQucHVzaChtb2QpO1xuXHRcdFx0fSBlbHNlIHNlZ21lbnQucHVzaChtb2QpO1xuXHRcdFx0aWYgKHNlZ21lbnQubGVuZ3RoKSByZXN1bHQucHVzaCguLi5zZWdtZW50LnNvcnQoKSk7XG5cdFx0XHRjYW5vbmljYWwgPSByZXN1bHQuam9pbihcIjpcIik7XG5cdFx0fVxuXHRcdGNvbnN0IGtleSA9IGltcG9ydGFudCA/IGNhbm9uaWNhbCArIFwiICFcIiA6IGNhbm9uaWNhbDtcblx0XHRsZXQgaWQgPSBjdHhCeUNhbm9uLmdldChrZXkpO1xuXHRcdGlmIChpZCA9PT0gdm9pZCAwKSBjdHhCeUNhbm9uLnNldChrZXksIGlkID0gbmV4dEN0eElkKyspO1xuXHRcdHJldHVybiBpZDtcblx0fTtcblx0bGV0IGR5bkJ5SGFzaCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGxldCBuZXh0RHluSWQgPSBHUk9VUF9DT1VOVDtcblx0Y29uc3QgTUFYX0RZTiA9IEdST1VQX0NPVU5UICsgNDA5Njtcblx0Y29uc3QgbmV3RHluSWQgPSAoKSA9PiBuZXh0RHluSWQrKztcblx0Y29uc3QgSURfTElNSVQgPSAyMDk3MTUyO1xuXHRjb25zdCBUT0tFTl9UQUJMRSA9IDgxOTI7XG5cdGNvbnN0IG1lbW9IYXNoID0gbmV3IEludDMyQXJyYXkoVE9LRU5fVEFCTEUpO1xuXHRjb25zdCBtZW1vU3RyID0gbmV3IEFycmF5KFRPS0VOX1RBQkxFKS5maWxsKG51bGwpO1xuXHRjb25zdCBtZW1vR2lkID0gbmV3IEludDMyQXJyYXkoVE9LRU5fVEFCTEUpO1xuXHRjb25zdCBtZW1vQ3R4ID0gbmV3IEludDMyQXJyYXkoVE9LRU5fVEFCTEUpO1xuXHRjb25zdCBtZW1vRmxhZ3MgPSBuZXcgVWludDhBcnJheShUT0tFTl9UQUJMRSk7XG5cdGxldCBtZW1vVGljayA9IDA7XG5cdGNvbnN0IG1lbW9QdXQgPSAod2F5MCwgaW5wdXQsIHRzLCB0ZSwgaCwgZ2lkLCBjdHhJZCwgZmxhZ3MpID0+IHtcblx0XHRsZXQgc2xvdCA9IHdheTA7XG5cdFx0aWYgKG1lbW9TdHJbd2F5MF0gIT09IG51bGwpIHtcblx0XHRcdGlmIChtZW1vU3RyW3dheTAgfCAxXSA9PT0gbnVsbCkgc2xvdCA9IHdheTAgfCAxO1xuXHRcdFx0ZWxzZSBpZiAoKG1lbW9UaWNrKysgJiAzKSA9PT0gMCkgc2xvdCA9IHdheTAgfCBtZW1vVGljayA+PiAyICYgMTtcblx0XHRcdGVsc2UgcmV0dXJuO1xuXHRcdH1cblx0XHRtZW1vU3RyW3Nsb3RdID0gaW5wdXQuc2xpY2UodHMsIHRlKTtcblx0XHRtZW1vSGFzaFtzbG90XSA9IGg7XG5cdFx0bWVtb0dpZFtzbG90XSA9IGdpZDtcblx0XHRtZW1vQ3R4W3Nsb3RdID0gY3R4SWQ7XG5cdFx0bWVtb0ZsYWdzW3Nsb3RdID0gZmxhZ3M7XG5cdH07XG5cdGNvbnN0IG1lbW9SZXNldCA9ICgpID0+IG1lbW9TdHIuZmlsbChudWxsKTtcblx0bGV0IGNhcCA9IDI1Njtcblx0bGV0IHRva0kzMiA9IFtcblx0XHRuZXcgSW50MzJBcnJheShjYXApLFxuXHRcdG5ldyBJbnQzMkFycmF5KGNhcCksXG5cdFx0bmV3IEludDMyQXJyYXkoY2FwKSxcblx0XHRuZXcgSW50MzJBcnJheShjYXApXG5cdF07XG5cdGxldCBbdG9rU3RhcnQsIHRva0VuZCwgdG9rR2lkLCB0b2tDdHhdID0gdG9rSTMyO1xuXHRsZXQgdG9rRmxhZ3MgPSBuZXcgVWludDhBcnJheShjYXApO1xuXHRsZXQga2VlcCA9IG5ldyBVaW50OEFycmF5KGNhcCk7XG5cdGNvbnN0IGdyb3dUb2tlbnMgPSAoKSA9PiB7XG5cdFx0Y2FwICo9IDI7XG5cdFx0dG9rSTMyID0gdG9rSTMyLm1hcCgoYSkgPT4ge1xuXHRcdFx0Y29uc3QgbiA9IG5ldyBJbnQzMkFycmF5KGNhcCk7XG5cdFx0XHRuLnNldChhKTtcblx0XHRcdHJldHVybiBuO1xuXHRcdH0pO1xuXHRcdFt0b2tTdGFydCwgdG9rRW5kLCB0b2tHaWQsIHRva0N0eF0gPSB0b2tJMzI7XG5cdFx0Y29uc3QgbmYgPSBuZXcgVWludDhBcnJheShjYXApO1xuXHRcdG5mLnNldCh0b2tGbGFncyk7XG5cdFx0dG9rRmxhZ3MgPSBuZjtcblx0XHRrZWVwID0gbmV3IFVpbnQ4QXJyYXkoY2FwKTtcblx0fTtcblx0bGV0IGNrcHRDYXAgPSA2NDtcblx0bGV0IGNrcHROb2RlID0gbmV3IEludDMyQXJyYXkoY2twdENhcCk7XG5cdGxldCBja3B0VGFpbCA9IG5ldyBJbnQzMkFycmF5KGNrcHRDYXApO1xuXHRjb25zdCBjbGFpbTAgPSBuZXcgSW50MzJBcnJheShHUk9VUF9DT1VOVCk7XG5cdGxldCBDTEFJTV9UQUJMRSA9IDIwNDg7XG5cdGxldCBjbGFpbVNoaWZ0ID0gMjE7XG5cdGxldCBjbGFpbUtleXMgPSBuZXcgRmxvYXQ2NEFycmF5KENMQUlNX1RBQkxFKTtcblx0bGV0IGNsYWltRXBvY2hzID0gbmV3IEludDMyQXJyYXkoQ0xBSU1fVEFCTEUpO1xuXHRsZXQgZXBvY2ggPSAwO1xuXHRjb25zdCBjbGFpbVRlc3QgPSAoY3R4LCBnaWQpID0+IHtcblx0XHRpZiAoY3R4ID09PSAwICYmIGdpZCA8IEdST1VQX0NPVU5UKSB7XG5cdFx0XHRpZiAoY2xhaW0wW2dpZF0gPT09IGVwb2NoKSByZXR1cm4gMTtcblx0XHRcdGNsYWltMFtnaWRdID0gZXBvY2g7XG5cdFx0XHRyZXR1cm4gMDtcblx0XHR9XG5cdFx0Y29uc3Qga2V5ID0gY3R4ICogMjA5NzE1MiArIGdpZCArIDE7XG5cdFx0bGV0IGlkeCA9IE1hdGguaW11bChrZXksIDI2NTQ0MzU3NjEpID4+PiBjbGFpbVNoaWZ0O1xuXHRcdGZvciAoOzspIHtcblx0XHRcdGlmIChjbGFpbUVwb2Noc1tpZHhdICE9PSBlcG9jaCkgYnJlYWs7XG5cdFx0XHRpZiAoY2xhaW1LZXlzW2lkeF0gPT09IGtleSkgcmV0dXJuIDE7XG5cdFx0XHRpZHggPSBpZHggKyAxICYgQ0xBSU1fVEFCTEUgLSAxO1xuXHRcdH1cblx0XHRjbGFpbUtleXNbaWR4XSA9IGtleTtcblx0XHRjbGFpbUVwb2Noc1tpZHhdID0gZXBvY2g7XG5cdFx0cmV0dXJuIDA7XG5cdH07XG5cdGNvbnN0IHJlc29sdmVBdCA9IChpbnB1dCwgYnMsIGVuZFBvcywgbm9kZUF0LCBja3B0QXQpID0+IHtcblx0XHRpZiAoZW5kUG9zIC0gYnMgPj0gMiAmJiBpbnB1dC5jaGFyQ29kZUF0KGJzKSA9PT0gOTEgJiYgaW5wdXQuY2hhckNvZGVBdChlbmRQb3MgLSAxKSA9PT0gOTMpIHtcblx0XHRcdGxldCBjb2xvbiA9IC0xO1xuXHRcdFx0Zm9yIChsZXQgcCA9IGJzICsgMTsgcCA8IGVuZFBvcyAtIDE7IHArKykgaWYgKGlucHV0LmNoYXJDb2RlQXQocCkgPT09IDU4KSB7XG5cdFx0XHRcdGNvbG9uID0gcDtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0XHRpZiAoY29sb24gPT09IC0xIHx8IGNvbG9uID09PSBicyArIDEpIHJldHVybiBFWFRFUk5BTDtcblx0XHRcdHJldHVybiBpbnRlcm5TcGFuKGR5bkJ5SGFzaCwgaW5wdXQsIGJzICsgMSwgY29sb24sIDAsIG5ld0R5bklkKTtcblx0XHR9XG5cdFx0aWYgKG5vZGVBdCA+PSAwICYmIG5vZGVHcm91cFtub2RlQXRdID49IDApIHJldHVybiBub2RlR3JvdXBbbm9kZUF0XTtcblx0XHRmb3IgKGxldCBrID0gY2twdEF0IC0gMTsgayA+PSAwOyBrLS0pIHtcblx0XHRcdGNvbnN0IHRhaWxTdGFydCA9IGNrcHRUYWlsW2tdO1xuXHRcdFx0aWYgKHRhaWxTdGFydCA+IGVuZFBvcykgY29udGludWU7XG5cdFx0XHRjb25zdCBub2RlSWQgPSBja3B0Tm9kZVtrXTtcblx0XHRcdGNvbnN0IHRsZW4gPSBlbmRQb3MgLSB0YWlsU3RhcnQ7XG5cdFx0XHRpZiAobm9kZUhhc0xpdFtub2RlSWRdID09PSAxICYmIHRsZW4gPiAwICYmIHRsZW4gPD0gbGl0TWF4TGVuKSB7XG5cdFx0XHRcdGNvbnN0IGMwID0gaW5wdXQuY2hhckNvZGVBdCh0YWlsU3RhcnQpO1xuXHRcdFx0XHRpZiAobGl0Tm9BcmIgPT09IGZhbHNlIHx8IGMwICE9PSA5MSAmJiBjMCAhPT0gNDApIHtcblx0XHRcdFx0XHRjb25zdCBnID0gbGl0UHJvYmUobm9kZUlkLCBpbnB1dCwgdGFpbFN0YXJ0LCBlbmRQb3MpO1xuXHRcdFx0XHRcdGlmIChnID49IDApIHJldHVybiBnO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRjb25zdCB2bCA9IG5vZGVWbGlzdFtub2RlSWRdO1xuXHRcdFx0aWYgKHZsIDwgMCkgY29udGludWU7XG5cdFx0XHRjb25zdCBwYXQgPSB2bGlzdFJlZlt2bF07XG5cdFx0XHRjb25zdCB2cyA9IHZsaXN0UGF0W3BhdF07XG5cdFx0XHRjb25zdCB2ZSA9IHZsaXN0UGF0W3BhdCArIDFdO1xuXHRcdFx0aWYgKHZzID09PSB2ZSkgY29udGludWU7XG5cdFx0XHRhbmFseXplQXJiKGlucHV0LCB0YWlsU3RhcnQsIGVuZFBvcyk7XG5cdFx0XHRjb25zdCBnMCA9IHZnU3RhcnRbdmxdIC0gdnM7XG5cdFx0XHRmb3IgKGxldCB2ID0gdnM7IHYgPCB2ZTsgdisrKSBpZiAocnVuVmFsaWRhdG9yKHZsaXN0T3BzW3ZdLCBpbnB1dCwgdGFpbFN0YXJ0LCBlbmRQb3MpKSByZXR1cm4gdmxpc3RHcm91cFtnMCArIHZdO1xuXHRcdH1cblx0XHRyZXR1cm4gRVhURVJOQUw7XG5cdH07XG5cdGNvbnN0IG1lcmdlQ2xhc3NMaXN0ID0gKGlucHV0KSA9PiB7XG5cdFx0Y29uc3QgbiA9IGlucHV0Lmxlbmd0aDtcblx0XHRsZXQgdG9rZW5Db3VudCA9IDA7XG5cdFx0bGV0IHRvdGFsVG9rZW5DaGFycyA9IDA7XG5cdFx0bGV0IHNhd05vblNwYWNlV1MgPSBmYWxzZTtcblx0XHRpZiAobmV4dEN0eElkID4gTUFYX0NUWCB8fCBjdHhCeUhhc2guc2l6ZSA+IE1BWF9DVFgpIHtcblx0XHRcdGN0eEJ5SGFzaCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0XHRjdHhCeUNhbm9uID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRcdG5leHRDdHhJZCA9IDI7XG5cdFx0XHRtZW1vUmVzZXQoKTtcblx0XHR9XG5cdFx0aWYgKG5leHREeW5JZCA+IE1BWF9EWU4pIHtcblx0XHRcdGR5bkJ5SGFzaCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0XHRuZXh0RHluSWQgPSBHUk9VUF9DT1VOVDtcblx0XHRcdG1lbW9SZXNldCgpO1xuXHRcdH1cblx0XHRsZXQgaSA9IDA7XG5cdFx0d2hpbGUgKGkgPCBuKSB7XG5cdFx0XHRsZXQgYyA9IGlucHV0LmNoYXJDb2RlQXQoaSk7XG5cdFx0XHRpZiAoYyA9PT0gMzIgfHwgYyA+PSA5ICYmIGMgPD0gMTMgfHwgYyA+PSAxNjAgJiYgaXNVbmlXUyhjKSkge1xuXHRcdFx0XHRpZiAoYyAhPT0gMzIpIHNhd05vblNwYWNlV1MgPSB0cnVlO1xuXHRcdFx0XHRpKys7XG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgdHMgPSBpO1xuXHRcdFx0bGV0IHRoID0gMDtcblx0XHRcdHdoaWxlIChpIDwgbikge1xuXHRcdFx0XHRjID0gaW5wdXQuY2hhckNvZGVBdChpKTtcblx0XHRcdFx0aWYgKGMgPD0gMzIpIHtcblx0XHRcdFx0XHRpZiAoYyA9PT0gMzIpIGJyZWFrO1xuXHRcdFx0XHRcdGlmIChjID49IDkgJiYgYyA8PSAxMykge1xuXHRcdFx0XHRcdFx0c2F3Tm9uU3BhY2VXUyA9IHRydWU7XG5cdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSBpZiAoYyA+PSAxNjAgJiYgaXNVbmlXUyhjKSkge1xuXHRcdFx0XHRcdHNhd05vblNwYWNlV1MgPSB0cnVlO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRoID0gTWF0aC5pbXVsKHRoIF4gYywgMTY3Nzc2MTkpO1xuXHRcdFx0XHRpKys7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCB0ZSA9IGk7XG5cdFx0XHRjb25zdCBsZW4gPSB0ZSAtIHRzO1xuXHRcdFx0aWYgKHRva2VuQ291bnQgPT09IGNhcCkgZ3Jvd1Rva2VucygpO1xuXHRcdFx0Y29uc3QgdCA9IHRva2VuQ291bnQrKztcblx0XHRcdHRva1N0YXJ0W3RdID0gdHM7XG5cdFx0XHR0b2tFbmRbdF0gPSB0ZTtcblx0XHRcdHRvdGFsVG9rZW5DaGFycyArPSBsZW47XG5cdFx0XHR0aCBePSBNYXRoLmltdWwobGVuLCAyNjU0NDM1NzYxKTtcblx0XHRcdGNvbnN0IGggPSB0aCBeIHRoID4+PiAxNSB8IDA7XG5cdFx0XHRjb25zdCB3YXkwID0gaCAmIDgxOTA7XG5cdFx0XHR7XG5cdFx0XHRcdGxldCBoaXRBdCA9IC0xO1xuXHRcdFx0XHRpZiAobWVtb0hhc2hbd2F5MF0gPT09IGggJiYgbWVtb1N0clt3YXkwXSAhPT0gbnVsbCAmJiBtZW1vU3RyW3dheTBdLmxlbmd0aCA9PT0gbGVuKSBoaXRBdCA9IHdheTA7XG5cdFx0XHRcdGVsc2UgaWYgKG1lbW9IYXNoW3dheTAgfCAxXSA9PT0gaCAmJiBtZW1vU3RyW3dheTAgfCAxXSAhPT0gbnVsbCAmJiBtZW1vU3RyW3dheTAgfCAxXS5sZW5ndGggPT09IGxlbikgaGl0QXQgPSB3YXkwIHwgMTtcblx0XHRcdFx0aWYgKGhpdEF0ID49IDApIHtcblx0XHRcdFx0XHRjb25zdCBzID0gbWVtb1N0cltoaXRBdF07XG5cdFx0XHRcdFx0bGV0IG9rID0gdHJ1ZTtcblx0XHRcdFx0XHRmb3IgKGxldCBrID0gMDsgayA8IGxlbjsgaysrKSBpZiAocy5jaGFyQ29kZUF0KGspICE9PSBpbnB1dC5jaGFyQ29kZUF0KHRzICsgaykpIHtcblx0XHRcdFx0XHRcdG9rID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKG9rKSB7XG5cdFx0XHRcdFx0XHR0b2tHaWRbdF0gPSBtZW1vR2lkW2hpdEF0XTtcblx0XHRcdFx0XHRcdHRva0N0eFt0XSA9IG1lbW9DdHhbaGl0QXRdO1xuXHRcdFx0XHRcdFx0dG9rRmxhZ3NbdF0gPSBtZW1vRmxhZ3NbaGl0QXRdO1xuXHRcdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRsZXQgcHRzID0gdHM7XG5cdFx0XHRpZiAoRlBMICE9PSAwKSB7XG5cdFx0XHRcdGlmICh0ZSAtIHRzIDw9IEZQTCB8fCAhaW5wdXQuc3RhcnRzV2l0aChGVUxMX1BSRUZJWCwgdHMpKSB7XG5cdFx0XHRcdFx0dG9rR2lkW3RdID0gRVhURVJOQUw7XG5cdFx0XHRcdFx0bWVtb1B1dCh3YXkwLCBpbnB1dCwgdHMsIHRlLCBoLCBFWFRFUk5BTCwgMCwgMCk7XG5cdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0cHRzID0gdHMgKyBGUEw7XG5cdFx0XHR9XG5cdFx0XHRsZXQgZGVwdGhCID0gMCwgZGVwdGhQID0gMDtcblx0XHRcdGxldCBsYXN0Q29sb24gPSAtMSwgbGFzdFNsYXNoID0gLTE7XG5cdFx0XHRmb3IgKGxldCBwID0gcHRzOyBwIDwgdGU7IHArKykge1xuXHRcdFx0XHRjb25zdCBwYyA9IGlucHV0LmNoYXJDb2RlQXQocCk7XG5cdFx0XHRcdGlmIChkZXB0aEIgPT09IDAgJiYgZGVwdGhQID09PSAwKSB7XG5cdFx0XHRcdFx0aWYgKHBjID09PSA1OCkge1xuXHRcdFx0XHRcdFx0bGFzdENvbG9uID0gcDtcblx0XHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAocGMgPT09IDQ3KSB7XG5cdFx0XHRcdFx0XHRsYXN0U2xhc2ggPSBwO1xuXHRcdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChwYyA9PT0gOTEpIGRlcHRoQisrO1xuXHRcdFx0XHRlbHNlIGlmIChwYyA9PT0gOTMpIGRlcHRoQi0tO1xuXHRcdFx0XHRlbHNlIGlmIChwYyA9PT0gNDApIGRlcHRoUCsrO1xuXHRcdFx0XHRlbHNlIGlmIChwYyA9PT0gNDEpIGRlcHRoUC0tO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgbW9kU3RhcnQgPSBsYXN0Q29sb24gPj0gcHRzID8gbGFzdENvbG9uICsgMSA6IHB0cztcblx0XHRcdGxldCBicyA9IG1vZFN0YXJ0O1xuXHRcdFx0bGV0IGJlID0gdGU7XG5cdFx0XHRsZXQgaW1wb3J0YW50ID0gZmFsc2U7XG5cdFx0XHRsZXQgcHJlZml4U2hpZnQgPSAwO1xuXHRcdFx0aWYgKGJlID4gYnMgJiYgaW5wdXQuY2hhckNvZGVBdChiZSAtIDEpID09PSAzMykge1xuXHRcdFx0XHRpbXBvcnRhbnQgPSB0cnVlO1xuXHRcdFx0XHRiZS0tO1xuXHRcdFx0fSBlbHNlIGlmIChiZSA+IGJzICYmIGlucHV0LmNoYXJDb2RlQXQoYnMpID09PSAzMykge1xuXHRcdFx0XHRpbXBvcnRhbnQgPSB0cnVlO1xuXHRcdFx0XHRicysrO1xuXHRcdFx0XHRwcmVmaXhTaGlmdCA9IDE7XG5cdFx0XHR9XG5cdFx0XHRsZXQgcG9zdGZpeEVuZCA9IC0xO1xuXHRcdFx0aWYgKGxhc3RTbGFzaCA+IG1vZFN0YXJ0KSB7XG5cdFx0XHRcdHBvc3RmaXhFbmQgPSBsYXN0U2xhc2ggKyBwcmVmaXhTaGlmdDtcblx0XHRcdFx0aWYgKHBvc3RmaXhFbmQgPj0gYmUpIHBvc3RmaXhFbmQgPSAtMTtcblx0XHRcdH1cblx0XHRcdGxldCBmZWVkU3RhcnQgPSBicztcblx0XHRcdGlmIChiZSAtIGJzID4gMSAmJiBpbnB1dC5jaGFyQ29kZUF0KGJzKSA9PT0gNDUpIGZlZWRTdGFydCA9IGJzICsgMTtcblx0XHRcdGxldCBub2RlID0gMDtcblx0XHRcdGxldCBscCA9IDA7XG5cdFx0XHRsZXQgbGUgPSAwO1xuXHRcdFx0bGV0IHBlbmRpbmcgPSAtMTtcblx0XHRcdGxldCBja3B0VG9wID0gMDtcblx0XHRcdGlmIChub2RlVmxpc3RbMF0gPj0gMCB8fCBub2RlSGFzTGl0WzBdID09PSAxKSB7XG5cdFx0XHRcdGNrcHROb2RlWzBdID0gMDtcblx0XHRcdFx0Y2twdFRhaWxbMF0gPSBmZWVkU3RhcnQ7XG5cdFx0XHRcdGNrcHRUb3AgPSAxO1xuXHRcdFx0fVxuXHRcdFx0bGV0IHNsYXNoTm9kZSA9IERFQUQ7XG5cdFx0XHRsZXQgc2xhc2hDa3B0ID0gMDtcblx0XHRcdGZvciAobGV0IHAgPSBmZWVkU3RhcnQ7IHAgPCBiZTsgcCsrKSB7XG5cdFx0XHRcdGlmIChwID09PSBwb3N0Zml4RW5kKSB7XG5cdFx0XHRcdFx0c2xhc2hOb2RlID0gbHAgPCBsZSA/IERFQUQgOiBub2RlO1xuXHRcdFx0XHRcdHNsYXNoQ2twdCA9IGNrcHRUb3A7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5vZGUgIT09IERFQUQpIHtcblx0XHRcdFx0XHRjb25zdCBjYyA9IGlucHV0LmNoYXJDb2RlQXQocCk7XG5cdFx0XHRcdFx0bGV0IGFycml2ZWQgPSAtMTtcblx0XHRcdFx0XHRpZiAobHAgPCBsZSkge1xuXHRcdFx0XHRcdFx0aWYgKGxhYmVsVGV4dC5jaGFyQ29kZUF0KGxwKSA9PT0gY2MpIHtcblx0XHRcdFx0XHRcdFx0bHArKztcblx0XHRcdFx0XHRcdFx0aWYgKGxwID09PSBsZSkgYXJyaXZlZCA9IG5vZGUgPSBwZW5kaW5nO1xuXHRcdFx0XHRcdFx0fSBlbHNlIG5vZGUgPSBERUFEO1xuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRjb25zdCBlcyA9IGVkZ2VTdGFydFtub2RlXTtcblx0XHRcdFx0XHRcdGNvbnN0IGVlID0gZWRnZVN0YXJ0W25vZGUgKyAxXTtcblx0XHRcdFx0XHRcdGxldCBuZXh0ID0gREVBRDtcblx0XHRcdFx0XHRcdGZvciAobGV0IGUgPSBlczsgZSA8IGVlOyBlKyspIHtcblx0XHRcdFx0XHRcdFx0Y29uc3QgbHMgPSBsYWJlbFN0YXJ0W2VdO1xuXHRcdFx0XHRcdFx0XHRpZiAobGFiZWxUZXh0LmNoYXJDb2RlQXQobHMpID09PSBjYykge1xuXHRcdFx0XHRcdFx0XHRcdGlmIChsYWJlbFN0YXJ0W2UgKyAxXSAtIGxzID09PSAxKSBhcnJpdmVkID0gbmV4dCA9IGVkZ2VUYXJnZXRbZV07XG5cdFx0XHRcdFx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0XHRcdFx0XHRscCA9IGxzICsgMTtcblx0XHRcdFx0XHRcdFx0XHRcdGxlID0gbGFiZWxTdGFydFtlICsgMV07XG5cdFx0XHRcdFx0XHRcdFx0XHRwZW5kaW5nID0gZWRnZVRhcmdldFtlXTtcblx0XHRcdFx0XHRcdFx0XHRcdG5leHQgPSBub2RlO1xuXHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0bm9kZSA9IG5leHQ7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmIChhcnJpdmVkID49IDAgJiYgKG5vZGVWbGlzdFthcnJpdmVkXSA+PSAwIHx8IG5vZGVIYXNMaXRbYXJyaXZlZF0gPT09IDEpICYmIHAgKyAxIDwgYmUgJiYgaW5wdXQuY2hhckNvZGVBdChwICsgMSkgPT09IDQ1KSB7XG5cdFx0XHRcdFx0XHRpZiAoY2twdFRvcCA9PT0gY2twdENhcCkge1xuXHRcdFx0XHRcdFx0XHRja3B0Q2FwICo9IDI7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IG52ID0gbmV3IEludDMyQXJyYXkoY2twdENhcCk7XG5cdFx0XHRcdFx0XHRcdG52LnNldChja3B0Tm9kZSk7XG5cdFx0XHRcdFx0XHRcdGNrcHROb2RlID0gbnY7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IG50ID0gbmV3IEludDMyQXJyYXkoY2twdENhcCk7XG5cdFx0XHRcdFx0XHRcdG50LnNldChja3B0VGFpbCk7XG5cdFx0XHRcdFx0XHRcdGNrcHRUYWlsID0gbnQ7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRja3B0Tm9kZVtja3B0VG9wXSA9IGFycml2ZWQ7XG5cdFx0XHRcdFx0XHRja3B0VGFpbFtja3B0VG9wXSA9IHAgKyAyO1xuXHRcdFx0XHRcdFx0Y2twdFRvcCsrO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHBvc3RmaXhFbmQgPT09IGJlKSB7XG5cdFx0XHRcdHNsYXNoTm9kZSA9IGxwIDwgbGUgPyBERUFEIDogbm9kZTtcblx0XHRcdFx0c2xhc2hDa3B0ID0gY2twdFRvcDtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGVuZE5vZGUgPSBscCA8IGxlID8gREVBRCA6IG5vZGU7XG5cdFx0XHRsZXQgZ2lkO1xuXHRcdFx0bGV0IGhhc1Bvc3RmaXggPSBmYWxzZTtcblx0XHRcdGlmIChwb3N0Zml4RW5kID49IDApIHtcblx0XHRcdFx0aGFzUG9zdGZpeCA9IHRydWU7XG5cdFx0XHRcdGdpZCA9IHJlc29sdmVBdChpbnB1dCwgYnMsIHBvc3RmaXhFbmQsIHNsYXNoTm9kZSwgc2xhc2hDa3B0KTtcblx0XHRcdFx0aWYgKGdpZCAhPT0gRVhURVJOQUwgJiYgZ2lkIDwgR1JPVVBfQ09VTlQgJiYgcG9zdGZpeExvb2t1cFNldFtnaWRdKSB7XG5cdFx0XHRcdFx0Y29uc3QgZ2lkRnVsbCA9IHJlc29sdmVBdChpbnB1dCwgYnMsIGJlLCBlbmROb2RlLCBja3B0VG9wKTtcblx0XHRcdFx0XHRpZiAoZ2lkRnVsbCAhPT0gRVhURVJOQUwgJiYgZ2lkRnVsbCAhPT0gZ2lkKSB7XG5cdFx0XHRcdFx0XHRnaWQgPSBnaWRGdWxsO1xuXHRcdFx0XHRcdFx0aGFzUG9zdGZpeCA9IGZhbHNlO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIGlmIChnaWQgPT09IEVYVEVSTkFMKSB7XG5cdFx0XHRcdFx0Z2lkID0gcmVzb2x2ZUF0KGlucHV0LCBicywgYmUsIGVuZE5vZGUsIGNrcHRUb3ApO1xuXHRcdFx0XHRcdGhhc1Bvc3RmaXggPSBmYWxzZTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGdpZCA9IHJlc29sdmVBdChpbnB1dCwgYnMsIGJlLCBlbmROb2RlLCBja3B0VG9wKTtcblx0XHRcdGxldCBjdHhJZCA9IDA7XG5cdFx0XHRsZXQgZmxhZ3MgPSAwO1xuXHRcdFx0aWYgKGdpZCA9PT0gRVhURVJOQUwpIHRva0dpZFt0XSA9IEVYVEVSTkFMO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGZsYWdzID0gaGFzUG9zdGZpeCA/IDEgOiAwO1xuXHRcdFx0XHRjdHhJZCA9IHB0cyA+PSBsYXN0Q29sb24gPyBpbXBvcnRhbnQgPyAxIDogMCA6IGludGVyblNwYW4oY3R4QnlIYXNoLCBpbnB1dCwgcHRzLCBsYXN0Q29sb24sIGltcG9ydGFudCA/IDEgOiAwLCAoaykgPT4gY2Fub25pY2FsaXplQ29udGV4dChrLCBpbXBvcnRhbnQpKTtcblx0XHRcdFx0dG9rR2lkW3RdID0gZ2lkO1xuXHRcdFx0XHR0b2tGbGFnc1t0XSA9IGZsYWdzO1xuXHRcdFx0XHR0b2tDdHhbdF0gPSBjdHhJZDtcblx0XHRcdH1cblx0XHRcdG1lbW9QdXQod2F5MCwgaW5wdXQsIHRzLCB0ZSwgaCwgZ2lkLCBjdHhJZCwgZmxhZ3MpO1xuXHRcdH1cblx0XHRpZiAodG9rZW5Db3VudCA9PT0gMCkgcmV0dXJuIFwiXCI7XG5cdFx0aWYgKHRva2VuQ291bnQgPT09IDEpIHJldHVybiB0b2tTdGFydFswXSA9PT0gMCAmJiB0b2tFbmRbMF0gPT09IG4gPyBpbnB1dCA6IGlucHV0LnNsaWNlKHRva1N0YXJ0WzBdLCB0b2tFbmRbMF0pO1xuXHRcdGlmICh0b2tlbkNvdW50ICogQ0xBSU1fUEVSX1RPS0VOID4gQ0xBSU1fVEFCTEUpIHtcblx0XHRcdHdoaWxlICh0b2tlbkNvdW50ICogQ0xBSU1fUEVSX1RPS0VOID4gQ0xBSU1fVEFCTEUpIHtcblx0XHRcdFx0Q0xBSU1fVEFCTEUgPDw9IDE7XG5cdFx0XHRcdGNsYWltU2hpZnQtLTtcblx0XHRcdH1cblx0XHRcdGNsYWltS2V5cyA9IG5ldyBGbG9hdDY0QXJyYXkoQ0xBSU1fVEFCTEUpO1xuXHRcdFx0Y2xhaW1FcG9jaHMgPSBuZXcgSW50MzJBcnJheShDTEFJTV9UQUJMRSk7XG5cdFx0fVxuXHRcdGlmIChuZXh0Q3R4SWQgPj0gSURfTElNSVQgfHwgbmV4dER5bklkID49IElEX0xJTUlUKSB0aHJvdyBuZXcgRXJyb3IoXCJjbjogdG9vIG1hbnkgZGlzdGluY3QgY2xhc3NlcyBpbiBvbmUgbWVyZ2VcIik7XG5cdFx0ZXBvY2ggPSBlcG9jaCArIDEgfCAwO1xuXHRcdGlmIChlcG9jaCA9PT0gMCkge1xuXHRcdFx0Y2xhaW0wLmZpbGwoMCk7XG5cdFx0XHRjbGFpbUVwb2Nocy5maWxsKDApO1xuXHRcdFx0ZXBvY2ggPSAxO1xuXHRcdH1cblx0XHRsZXQgZGlkRHJvcCA9IGZhbHNlO1xuXHRcdGZvciAobGV0IHQgPSB0b2tlbkNvdW50IC0gMTsgdCA+PSAwOyB0LS0pIHtcblx0XHRcdGNvbnN0IGdpZCA9IHRva0dpZFt0XTtcblx0XHRcdGlmIChnaWQgPT09IEVYVEVSTkFMKSB7XG5cdFx0XHRcdGtlZXBbdF0gPSAxO1xuXHRcdFx0XHRjb250aW51ZTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGN0eElkID0gdG9rQ3R4W3RdO1xuXHRcdFx0aWYgKGNsYWltVGVzdChjdHhJZCwgZ2lkKSA9PT0gMSkge1xuXHRcdFx0XHRrZWVwW3RdID0gMDtcblx0XHRcdFx0ZGlkRHJvcCA9IHRydWU7XG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0a2VlcFt0XSA9IDE7XG5cdFx0XHRpZiAoZ2lkIDwgR1JPVVBfQ09VTlQpIHtcblx0XHRcdFx0Y29uc3QgciA9IGFkalJvd1tnaWRdO1xuXHRcdFx0XHRpZiAociA+PSAwKSBmb3IgKGxldCBrID0gYWRqU3RhcnRbcl07IGsgPCBhZGpTdGFydFtyICsgMV07IGsrKykgY2xhaW1UZXN0KGN0eElkLCBhZGpUZ3Rba10pO1xuXHRcdFx0XHRpZiAodG9rRmxhZ3NbdF0gJiAxKSB7XG5cdFx0XHRcdFx0Zm9yIChsZXQgayA9IDA7IGsgPCBwYXRHaWQubGVuZ3RoOyBrKyspIGlmIChwYXRHaWRba10gPT09IGdpZCkgY2xhaW1UZXN0KGN0eElkLCBwYXRUZ3Rba10pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmICghZGlkRHJvcCAmJiAhc2F3Tm9uU3BhY2VXUyAmJiBuID09PSB0b3RhbFRva2VuQ2hhcnMgKyB0b2tlbkNvdW50IC0gMSkgcmV0dXJuIGlucHV0O1xuXHRcdGxldCBvdXQgPSBcIlwiO1xuXHRcdGxldCB0ID0gMDtcblx0XHR3aGlsZSAodCA8IHRva2VuQ291bnQpIHtcblx0XHRcdGlmICgha2VlcFt0XSkge1xuXHRcdFx0XHR0Kys7XG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcnVuU3RhcnQgPSB0b2tTdGFydFt0XTtcblx0XHRcdGxldCBydW5FbmQgPSB0b2tFbmRbdF07XG5cdFx0XHRsZXQgdSA9IHQgKyAxO1xuXHRcdFx0d2hpbGUgKHUgPCB0b2tlbkNvdW50ICYmIGtlZXBbdV0gJiYgdG9rU3RhcnRbdV0gPT09IHJ1bkVuZCArIDEgJiYgaW5wdXQuY2hhckNvZGVBdChydW5FbmQpID09PSAzMikge1xuXHRcdFx0XHRydW5FbmQgPSB0b2tFbmRbdV07XG5cdFx0XHRcdHUrKztcblx0XHRcdH1cblx0XHRcdGlmIChvdXQubGVuZ3RoID4gMCkgb3V0ICs9IFwiIFwiO1xuXHRcdFx0b3V0ICs9IGlucHV0LnNsaWNlKHJ1blN0YXJ0LCBydW5FbmQpO1xuXHRcdFx0dCA9IHU7XG5cdFx0fVxuXHRcdHJldHVybiBvdXQ7XG5cdH07XG5cdGNvbnN0IERPT1JfU0laRSA9IDE2Mzg0O1xuXHRjb25zdCBkb29yID0gbmV3IEludDMyQXJyYXkoRE9PUl9TSVpFICogMik7XG5cdGxldCBkb29yQmFzZSA9IDA7XG5cdGxldCBkb29yRXBvY2ggPSAxO1xuXHRsZXQgY2FjaGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXHRsZXQgcHJldkNhY2hlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0bGV0IGNhY2hlTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0bGV0IHByZXZDYWNoZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGxldCBjYWNoZUNvdW50ID0gMDtcblx0bGV0IGRvb3JNYXJrcyA9IDA7XG5cdGNvbnN0IHJvdGF0ZURvb3IgPSAoKSA9PiB7XG5cdFx0ZG9vckJhc2UgXj0gRE9PUl9TSVpFO1xuXHRcdGRvb3JFcG9jaCA9IGRvb3JFcG9jaCArIDEgfCAwO1xuXHRcdGRvb3JNYXJrcyA9IDA7XG5cdH07XG5cdGNvbnN0IG1lcmdlQ2FjaGVkID0gKGlucHV0KSA9PiB7XG5cdFx0bGV0IG1lcmdlZCA9IGNhY2hlW2lucHV0XTtcblx0XHRpZiAobWVyZ2VkICE9PSB2b2lkIDApIHJldHVybiBtZXJnZWQ7XG5cdFx0Y29uc3QgaGFzaCA9IHNwYW5IYXNoKGlucHV0LCAwLCBpbnB1dC5sZW5ndGgpO1xuXHRcdGNvbnN0IHNsb3QgPSAoaGFzaCAmIDE2MzgzKSArIGRvb3JCYXNlO1xuXHRcdGNvbnN0IHdhc1NlZW4gPSBkb29yW3Nsb3RdID09PSAoaGFzaCBeIGRvb3JFcG9jaCkgfHwgZG9vcltzbG90IF4gRE9PUl9TSVpFXSA9PT0gKGhhc2ggXiBkb29yRXBvY2ggLSAxKTtcblx0XHRpZiAod2FzU2Vlbikge1xuXHRcdFx0bWVyZ2VkID0gcHJldkNhY2hlW2lucHV0XTtcblx0XHRcdGlmIChtZXJnZWQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRjYWNoZVtpbnB1dF0gPSBtZXJnZWQ7XG5cdFx0XHRcdHJldHVybiBtZXJnZWQ7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdG1lcmdlZCA9IG1lcmdlQ2xhc3NMaXN0KGlucHV0KTtcblx0XHRpZiAod2FzU2Vlbikge1xuXHRcdFx0Y2FjaGVbaW5wdXRdID0gbWVyZ2VkO1xuXHRcdFx0aWYgKCsrY2FjaGVDb3VudCA+IGNhY2hlU2l6ZSkge1xuXHRcdFx0XHRjYWNoZUNvdW50ID0gMDtcblx0XHRcdFx0cHJldkNhY2hlID0gY2FjaGU7XG5cdFx0XHRcdGNhY2hlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0XHRcdFx0cm90YXRlRG9vcigpO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRkb29yW3Nsb3RdID0gaGFzaCBeIGRvb3JFcG9jaDtcblx0XHRcdGlmICgrK2Rvb3JNYXJrcyA+IERPT1JfU0laRSkgcm90YXRlRG9vcigpO1xuXHRcdH1cblx0XHRyZXR1cm4gbWVyZ2VkO1xuXHR9O1xuXHRjb25zdCBtZXJnZUNhY2hlZE1hcCA9IChpbnB1dCkgPT4ge1xuXHRcdGxldCBtZXJnZWQgPSBjYWNoZU1hcC5nZXQoaW5wdXQpO1xuXHRcdGlmIChtZXJnZWQgIT09IHZvaWQgMCkgcmV0dXJuIG1lcmdlZDtcblx0XHRjb25zdCBoYXNoID0gc3Bhbkhhc2goaW5wdXQsIDAsIGlucHV0Lmxlbmd0aCk7XG5cdFx0Y29uc3Qgc2xvdCA9IChoYXNoICYgMTYzODMpICsgZG9vckJhc2U7XG5cdFx0Y29uc3Qgd2FzU2VlbiA9IGRvb3Jbc2xvdF0gPT09IChoYXNoIF4gZG9vckVwb2NoKSB8fCBkb29yW3Nsb3QgXiBET09SX1NJWkVdID09PSAoaGFzaCBeIGRvb3JFcG9jaCAtIDEpO1xuXHRcdGlmICh3YXNTZWVuKSB7XG5cdFx0XHRtZXJnZWQgPSBwcmV2Q2FjaGVNYXAuZ2V0KGlucHV0KTtcblx0XHRcdGlmIChtZXJnZWQgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRjYWNoZU1hcC5zZXQoaW5wdXQsIG1lcmdlZCk7XG5cdFx0XHRcdHJldHVybiBtZXJnZWQ7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdG1lcmdlZCA9IG1lcmdlQ2xhc3NMaXN0KGlucHV0KTtcblx0XHRpZiAod2FzU2Vlbikge1xuXHRcdFx0Y2FjaGVNYXAuc2V0KGlucHV0LCBtZXJnZWQpO1xuXHRcdFx0aWYgKCsrY2FjaGVDb3VudCA+IGNhY2hlU2l6ZSkge1xuXHRcdFx0XHRjYWNoZUNvdW50ID0gMDtcblx0XHRcdFx0cHJldkNhY2hlTWFwID0gY2FjaGVNYXA7XG5cdFx0XHRcdGNhY2hlTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRcdFx0cm90YXRlRG9vcigpO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRkb29yW3Nsb3RdID0gaGFzaCBeIGRvb3JFcG9jaDtcblx0XHRcdGlmICgrK2Rvb3JNYXJrcyA+IERPT1JfU0laRSkgcm90YXRlRG9vcigpO1xuXHRcdH1cblx0XHRyZXR1cm4gbWVyZ2VkO1xuXHR9O1xuXHRjb25zdCBzZWVuQmVmb3JlID0gKGlucHV0KSA9PiB7XG5cdFx0Y29uc3QgaGFzaCA9IHNwYW5IYXNoKGlucHV0LCAwLCBpbnB1dC5sZW5ndGgpO1xuXHRcdGNvbnN0IHNsb3QgPSAoaGFzaCAmIDE2MzgzKSArIGRvb3JCYXNlO1xuXHRcdGlmIChkb29yW3Nsb3RdID09PSAoaGFzaCBeIGRvb3JFcG9jaCkgfHwgZG9vcltzbG90IF4gRE9PUl9TSVpFXSA9PT0gKGhhc2ggXiBkb29yRXBvY2ggLSAxKSkgcmV0dXJuIHRydWU7XG5cdFx0ZG9vcltzbG90XSA9IGhhc2ggXiBkb29yRXBvY2g7XG5cdFx0aWYgKCsrZG9vck1hcmtzID4gRE9PUl9TSVpFKSByb3RhdGVEb29yKCk7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9O1xuXHRjb25zdCBtZXJnZVN0cmluZyA9IGNhY2hlU2l6ZSA9PT0gMCA/IG1lcmdlQ2xhc3NMaXN0IDogSVNfSlNDID8gKGlucHV0KSA9PiB7XG5cdFx0Y29uc3QgbWVyZ2VkID0gY2FjaGVNYXAuZ2V0KGlucHV0KTtcblx0XHRyZXR1cm4gbWVyZ2VkICE9PSB2b2lkIDAgPyBtZXJnZWQgOiBtZXJnZUNhY2hlZE1hcChpbnB1dCk7XG5cdH0gOiBtZXJnZUNhY2hlZDtcblx0Y29uc3QgbWVyZ2UgPSBmdW5jdGlvbigpIHtcblx0XHRyZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA9PT0gMSAmJiB0eXBlb2YgYXJndW1lbnRzWzBdID09PSBcInN0cmluZ1wiID8gbWVyZ2VTdHJpbmcoYXJndW1lbnRzWzBdKSA6IG1lcmdlU3RyaW5nKHR3Sm9pbi5hcHBseShudWxsLCBhcmd1bWVudHMpKTtcblx0fTtcblx0cmV0dXJuIHtcblx0XHRtZXJnZSxcblx0XHRtZXJnZVN0cmluZyxcblx0XHRzZWVuQmVmb3JlOiBjYWNoZVNpemUgPT09IDAgPyAoKSA9PiBmYWxzZSA6IHNlZW5CZWZvcmUsXG5cdFx0bWVyZ2VVbmNhY2hlZDogbWVyZ2VDbGFzc0xpc3Rcblx0fTtcbn07XG5jb25zdCByZXNvbHZlVmFsdWUgPSAodiwgY2xzeE1vZGUpID0+IHtcblx0aWYgKCF2KSByZXR1cm4gXCJcIjtcblx0aWYgKHR5cGVvZiB2ID09PSBcInN0cmluZ1wiKSByZXR1cm4gdjtcblx0bGV0IG91dCA9IFwiXCI7XG5cdGlmICh0eXBlb2Ygdi5sZW5ndGggPT09IFwibnVtYmVyXCIgJiYgKGNsc3hNb2RlID8gQXJyYXkuaXNBcnJheSh2KSA6IHRydWUpKSB7XG5cdFx0Y29uc3QgYXJyID0gdjtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGFyci5sZW5ndGg7IGkrKykge1xuXHRcdFx0Y29uc3QgaXRlbSA9IGFycltpXTtcblx0XHRcdGlmICghaXRlbSkgY29udGludWU7XG5cdFx0XHRjb25zdCByID0gdHlwZW9mIGl0ZW0gPT09IFwic3RyaW5nXCIgPyBpdGVtIDogcmVzb2x2ZVZhbHVlKGl0ZW0sIGNsc3hNb2RlKTtcblx0XHRcdGlmIChyKSB7XG5cdFx0XHRcdGlmIChvdXQpIG91dCArPSBcIiBcIjtcblx0XHRcdFx0b3V0ICs9IHI7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBvdXQ7XG5cdH1cblx0aWYgKGNsc3hNb2RlKSB7XG5cdFx0aWYgKHR5cGVvZiB2ID09PSBcIm51bWJlclwiKSByZXR1cm4gXCJcIiArIHY7XG5cdFx0aWYgKHR5cGVvZiB2ID09PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGsgaW4gdikgaWYgKHZba10pIHtcblx0XHRcdFx0aWYgKG91dCkgb3V0ICs9IFwiIFwiO1xuXHRcdFx0XHRvdXQgKz0gaztcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0cmV0dXJuIG91dDtcbn07XG5jb25zdCBqb2luQXJncyA9IChhcmdzLCBjbHN4TW9kZSkgPT4ge1xuXHRsZXQgcyA9IFwiXCI7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYXJncy5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IGEgPSBhcmdzW2ldO1xuXHRcdGlmICghYSkgY29udGludWU7XG5cdFx0Y29uc3QgciA9IHR5cGVvZiBhID09PSBcInN0cmluZ1wiID8gYSA6IHJlc29sdmVWYWx1ZShhLCBjbHN4TW9kZSk7XG5cdFx0aWYgKHIpIHtcblx0XHRcdGlmIChzKSBzICs9IFwiIFwiO1xuXHRcdFx0cyArPSByO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcztcbn07XG4vKiogam9pbi1vbmx5LCBgdHdKb2luYC1jb21wYXRpYmxlIChzdHJpbmdzICsgbmVzdGVkIGFycmF5cywgZmFsc3kgc2tpcHBlZCkgKi9cbmNvbnN0IHR3Sm9pbiA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gam9pbkFyZ3MoYXJndW1lbnRzLCBmYWxzZSk7XG59O1xuLyoqIGpvaW4tb25seSwgYGNsc3hgLWNvbXBhdGlibGUgKG5vIG1lcmdpbmcpICovXG5jb25zdCBjbHN4ID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiBqb2luQXJncyhhcmd1bWVudHMsIHRydWUpO1xufTtcbmNvbnN0IEJVQ0tFVF9DQVAgPSAyNTY7XG5jb25zdCBCVUNLRVRfTUlTU19DQVAgPSAxNjtcbmNvbnN0IEJVQ0tFVF9TS0lQID0gMTAyNDtcbmNvbnN0IENIVVJOX1NJWkUgPSA0MDk2O1xuY29uc3Qgd3JhcENsc3ggPSAobWVyZ2VTdHJpbmcsIGZyZXNoKSA9PiB7XG5cdGNvbnN0IHNlZW5CZWZvcmUgPSBmcmVzaCA9PT0gdm9pZCAwID8gKCkgPT4gdHJ1ZSA6IGZyZXNoLnNlZW5CZWZvcmU7XG5cdGNvbnN0IG1lcmdlVW5jYWNoZWQgPSBmcmVzaCA9PT0gdm9pZCAwID8gbWVyZ2VTdHJpbmcgOiBmcmVzaC5tZXJnZVVuY2FjaGVkO1xuXHRsZXQgYXJnQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRsZXQgcHJldkFyZ0NhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0bGV0IGFyZ0NvdW50ID0gMDtcblx0bGV0IGxhc3RIaXQgPSBudWxsO1xuXHRsZXQgY2h1cm5LZXkgPSBudWxsO1xuXHRsZXQgY2h1cm5Pd24gPSBbXTtcblx0bGV0IGNodXJuVmFsID0gW107XG5cdGxldCBjaHVyblRpY2sgPSAwO1xuXHRjb25zdCBjaHVybkxvb2t1cCA9IChrZXksIG93biwgam9pbikgPT4ge1xuXHRcdGlmIChjaHVybktleSA9PT0gbnVsbCkge1xuXHRcdFx0Y2h1cm5LZXkgPSBuZXcgQXJyYXkoQ0hVUk5fU0laRSkuZmlsbChcIlwiKTtcblx0XHRcdGNodXJuT3duID0gbmV3IEFycmF5KENIVVJOX1NJWkUpLmZpbGwoXCJcIik7XG5cdFx0XHRjaHVyblZhbCA9IG5ldyBBcnJheShDSFVSTl9TSVpFKS5maWxsKFwiXCIpO1xuXHRcdH1cblx0XHRjb25zdCB3YXkwID0gc3Bhbkhhc2goa2V5LCAwLCBrZXkubGVuZ3RoKSAmIDQwOTQ7XG5cdFx0aWYgKGNodXJuS2V5W3dheTBdID09PSBrZXkgJiYgY2h1cm5Pd25bd2F5MF0gPT09IG93bikgcmV0dXJuIGNodXJuVmFsW3dheTBdO1xuXHRcdGlmIChjaHVybktleVt3YXkwIHwgMV0gPT09IGtleSAmJiBjaHVybk93blt3YXkwIHwgMV0gPT09IG93bikgcmV0dXJuIGNodXJuVmFsW3dheTAgfCAxXTtcblx0XHRjb25zdCBtZXJnZWQgPSBtZXJnZVN0cmluZyhqb2luID8gb3duICsgXCIgXCIgKyBrZXkgOiBrZXkpO1xuXHRcdGNvbnN0IHNsb3QgPSBjaHVybktleVt3YXkwXSA9PT0gXCJcIiA/IHdheTAgOiB3YXkwIHwgKGNodXJuS2V5W3dheTAgfCAxXSA9PT0gXCJcIiA/IDEgOiBjaHVyblRpY2srKyAmIDEpO1xuXHRcdGNodXJuS2V5W3Nsb3RdID0ga2V5O1xuXHRcdGNodXJuT3duW3Nsb3RdID0gb3duO1xuXHRcdGNodXJuVmFsW3Nsb3RdID0gbWVyZ2VkO1xuXHRcdHJldHVybiBtZXJnZWQ7XG5cdH07XG5cdGNvbnN0IG1hdGNoMyA9IChlLCB2MCwgdjEsIHYyKSA9PiB7XG5cdFx0bGV0IGsgPSAwO1xuXHRcdGlmICh2MCkge1xuXHRcdFx0aWYgKHYwICE9PSBlLmEwKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRrID0gMTtcblx0XHR9XG5cdFx0aWYgKHYxKSB7XG5cdFx0XHRpZiAodjEgIT09IChrID09PSAwID8gZS5hMCA6IGUuYTEpKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRrKys7XG5cdFx0fVxuXHRcdGlmICh2Mikge1xuXHRcdFx0aWYgKHYyICE9PSAoayA9PT0gMCA/IGUuYTAgOiBrID09PSAxID8gZS5hMSA6IGUuYTIpKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRrKys7XG5cdFx0fVxuXHRcdHJldHVybiBrID09PSBlLnQ7XG5cdH07XG5cdGNvbnN0IG1hdGNoTiA9IChlLCB2YWxzKSA9PiB7XG5cdFx0Y29uc3QgZWEgPSBlLmE7XG5cdFx0bGV0IGsgPSAwO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgdmFscy5sZW5ndGg7IGkrKykge1xuXHRcdFx0Y29uc3QgdiA9IHZhbHNbaV07XG5cdFx0XHRpZiAoIXYpIGNvbnRpbnVlO1xuXHRcdFx0aWYgKHYgIT09IGVhW2tdKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRrKys7XG5cdFx0fVxuXHRcdHJldHVybiBrID09PSBlLnQ7XG5cdH07XG5cdGNvbnN0IHJlc29sdmVBcmdzID0gKHZhbHMsIHByb2JlZCkgPT4ge1xuXHRcdGNvbnN0IG5BcmdzID0gdmFscy5sZW5ndGg7XG5cdFx0Y29uc3QgcHJlZCA9IGxhc3RIaXQgPT09IG51bGwgPyBudWxsIDogbGFzdEhpdC5uO1xuXHRcdGlmICghcHJvYmVkKSB7XG5cdFx0XHRpZiAocHJlZCAhPT0gbnVsbCAmJiBtYXRjaE4ocHJlZCwgdmFscykpIHtcblx0XHRcdFx0bGFzdEhpdCA9IHByZWQ7XG5cdFx0XHRcdHJldHVybiBwcmVkLnI7XG5cdFx0XHR9XG5cdFx0XHRpZiAobGFzdEhpdCAhPT0gbnVsbCAmJiBsYXN0SGl0ICE9PSBwcmVkICYmIG1hdGNoTihsYXN0SGl0LCB2YWxzKSkgcmV0dXJuIGxhc3RIaXQucjtcblx0XHR9XG5cdFx0bGV0IGZpcnN0ID0gXCJcIjtcblx0XHRsZXQgZmlyc3RJZHggPSAtMTtcblx0XHRsZXQgdHJ1dGh5ID0gMDtcblx0XHRsZXQgaGFzUmVzb2x2ZWRWYWx1ZSA9IGZhbHNlO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbkFyZ3M7IGkrKykge1xuXHRcdFx0bGV0IHYgPSB2YWxzW2ldO1xuXHRcdFx0aWYgKCF2KSBjb250aW51ZTtcblx0XHRcdGlmICh0eXBlb2YgdiAhPT0gXCJzdHJpbmdcIikge1xuXHRcdFx0XHR2ID0gdmFsc1tpXSA9IHJlc29sdmVWYWx1ZSh2LCB0cnVlKTtcblx0XHRcdFx0aWYgKCF2KSBjb250aW51ZTtcblx0XHRcdFx0aGFzUmVzb2x2ZWRWYWx1ZSA9IHRydWU7XG5cdFx0XHR9XG5cdFx0XHRpZiAoZmlyc3RJZHggPCAwKSB7XG5cdFx0XHRcdGZpcnN0ID0gdjtcblx0XHRcdFx0Zmlyc3RJZHggPSBpO1xuXHRcdFx0fVxuXHRcdFx0dHJ1dGh5Kys7XG5cdFx0fVxuXHRcdGlmICh0cnV0aHkgPT09IDApIHJldHVybiBcIlwiO1xuXHRcdGlmICh0cnV0aHkgPT09IDEpIHJldHVybiBtZXJnZVN0cmluZyhmaXJzdCk7XG5cdFx0aWYgKGhhc1Jlc29sdmVkVmFsdWUpIHtcblx0XHRcdGlmIChwcmVkICE9PSBudWxsICYmIG1hdGNoTihwcmVkLCB2YWxzKSkge1xuXHRcdFx0XHRsYXN0SGl0ID0gcHJlZDtcblx0XHRcdFx0cmV0dXJuIHByZWQucjtcblx0XHRcdH1cblx0XHRcdGlmIChsYXN0SGl0ICE9PSBudWxsICYmIGxhc3RIaXQgIT09IHByZWQgJiYgbWF0Y2hOKGxhc3RIaXQsIHZhbHMpKSByZXR1cm4gbGFzdEhpdC5yO1xuXHRcdH1cblx0XHRsZXQgYnVja2V0ID0gYXJnQ2FjaGUuZ2V0KGZpcnN0KTtcblx0XHRpZiAoYnVja2V0ID09PSB2b2lkIDApIHtcblx0XHRcdGJ1Y2tldCA9IHByZXZBcmdDYWNoZS5nZXQoZmlyc3QpO1xuXHRcdFx0aWYgKGJ1Y2tldCAhPT0gdm9pZCAwKSBhcmdDYWNoZS5zZXQoZmlyc3QsIGJ1Y2tldCk7XG5cdFx0fVxuXHRcdGxldCBoaXQgPSBudWxsO1xuXHRcdGlmIChidWNrZXQgIT09IHZvaWQgMCkge1xuXHRcdFx0aWYgKGJ1Y2tldC5za2lwID4gMCkge1xuXHRcdFx0XHRidWNrZXQuc2tpcC0tO1xuXHRcdFx0XHRsYXN0SGl0ID0gbnVsbDtcblx0XHRcdFx0bGV0IGpvaW5lZCA9IGZpcnN0O1xuXHRcdFx0XHRmb3IgKGxldCBpID0gZmlyc3RJZHggKyAxOyBpIDwgbkFyZ3M7IGkrKykge1xuXHRcdFx0XHRcdGNvbnN0IHYgPSB2YWxzW2ldO1xuXHRcdFx0XHRcdGlmICh2KSBqb2luZWQgKz0gXCIgXCIgKyB2O1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBjaHVybkxvb2t1cChqb2luZWQsIFwiXCIsIGZhbHNlKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGVudHJpZXMgPSBidWNrZXQuZTtcblx0XHRcdG91dGVyOiBmb3IgKGxldCBiID0gMDsgYiA8IGVudHJpZXMubGVuZ3RoOyBiKyspIHtcblx0XHRcdFx0Y29uc3QgZSA9IGVudHJpZXNbYl07XG5cdFx0XHRcdGlmIChlLnQgIT09IHRydXRoeSkgY29udGludWU7XG5cdFx0XHRcdGNvbnN0IGVhID0gZS5hO1xuXHRcdFx0XHRsZXQgayA9IDE7XG5cdFx0XHRcdGZvciAobGV0IGkgPSBmaXJzdElkeCArIDE7IGkgPCBuQXJnczsgaSsrKSB7XG5cdFx0XHRcdFx0Y29uc3QgdiA9IHZhbHNbaV07XG5cdFx0XHRcdFx0aWYgKHYgJiYgdiAhPT0gZWFbaysrXSkgY29udGludWUgb3V0ZXI7XG5cdFx0XHRcdH1cblx0XHRcdFx0aGl0ID0gZTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0XHRpZiAoaGl0ICE9PSBudWxsKSBidWNrZXQubWlzcyA9IDA7XG5cdFx0fVxuXHRcdGlmIChoaXQgPT09IG51bGwpIHtcblx0XHRcdGxldCBqb2luZWQgPSBmaXJzdDtcblx0XHRcdGNvbnN0IGEgPSBbZmlyc3RdO1xuXHRcdFx0Zm9yIChsZXQgaSA9IGZpcnN0SWR4ICsgMTsgaSA8IG5BcmdzOyBpKyspIHtcblx0XHRcdFx0Y29uc3QgdiA9IHZhbHNbaV07XG5cdFx0XHRcdGlmICghdikgY29udGludWU7XG5cdFx0XHRcdGpvaW5lZCArPSBcIiBcIiArIHY7XG5cdFx0XHRcdGEucHVzaCh2KTtcblx0XHRcdH1cblx0XHRcdGlmICghc2VlbkJlZm9yZShqb2luZWQpKSByZXR1cm4gbWVyZ2VVbmNhY2hlZChqb2luZWQpO1xuXHRcdFx0aGl0ID0ge1xuXHRcdFx0XHRyOiBtZXJnZVN0cmluZyhqb2luZWQpLFxuXHRcdFx0XHR0OiBhLmxlbmd0aCxcblx0XHRcdFx0YTA6IGFbMF0sXG5cdFx0XHRcdGExOiBhWzFdLFxuXHRcdFx0XHRhMjogYVsyXSA/PyBcIlwiLFxuXHRcdFx0XHRhLFxuXHRcdFx0XHRuOiBudWxsXG5cdFx0XHR9O1xuXHRcdFx0aWYgKGJ1Y2tldCA9PT0gdm9pZCAwKSBhcmdDYWNoZS5zZXQoZmlyc3QsIGJ1Y2tldCA9IHtcblx0XHRcdFx0ZTogW10sXG5cdFx0XHRcdG1pc3M6IDAsXG5cdFx0XHRcdHNraXA6IDAsXG5cdFx0XHRcdGF0OiAwXG5cdFx0XHR9KTtcblx0XHRcdGVsc2UgaWYgKCsrYnVja2V0Lm1pc3MgPiBCVUNLRVRfTUlTU19DQVApIHtcblx0XHRcdFx0YnVja2V0Lm1pc3MgPSBCVUNLRVRfTUlTU19DQVA7XG5cdFx0XHRcdGJ1Y2tldC5za2lwID0gQlVDS0VUX1NLSVA7XG5cdFx0XHRcdGJ1Y2tldC5lLmxlbmd0aCA9IDA7XG5cdFx0XHRcdGJ1Y2tldC5hdCA9IDA7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBlbnRyaWVzID0gYnVja2V0LmU7XG5cdFx0XHRpZiAoZW50cmllcy5sZW5ndGggPCBCVUNLRVRfQ0FQKSBlbnRyaWVzLnB1c2goaGl0KTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRlbnRyaWVzW2J1Y2tldC5hdF0gPSBoaXQ7XG5cdFx0XHRcdGJ1Y2tldC5hdCA9IGJ1Y2tldC5hdCArIDEgJiAyNTU7XG5cdFx0XHR9XG5cdFx0XHRpZiAoKythcmdDb3VudCA+IDFlMykge1xuXHRcdFx0XHRhcmdDb3VudCA9IDA7XG5cdFx0XHRcdHByZXZBcmdDYWNoZSA9IGFyZ0NhY2hlO1xuXHRcdFx0XHRhcmdDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChsYXN0SGl0ICE9PSBudWxsICYmIGxhc3RIaXQgIT09IGhpdCkgbGFzdEhpdC5uID0gaGl0O1xuXHRcdGxhc3RIaXQgPSBoaXQ7XG5cdFx0cmV0dXJuIGhpdC5yO1xuXHR9O1xuXHRjb25zdCBtZXJnZVNpbmdsZVZhbHVlID0gKHZhbHVlKSA9PiBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHJlc29sdmVBcmdzKHZhbHVlLnNsaWNlKCksIGZhbHNlKSA6IG1lcmdlU3RyaW5nKHJlc29sdmVWYWx1ZSh2YWx1ZSwgdHJ1ZSkpO1xuXHRyZXR1cm4gZnVuY3Rpb24odjAsIHYxLCB2Mikge1xuXHRcdGNvbnN0IG5BcmdzID0gYXJndW1lbnRzLmxlbmd0aDtcblx0XHRpZiAoKG5BcmdzIHwgMSkgPT09IDMpIHtcblx0XHRcdGNvbnN0IGxoID0gbGFzdEhpdDtcblx0XHRcdGlmIChsaCAhPT0gbnVsbCkge1xuXHRcdFx0XHRjb25zdCBwcmVkID0gbGgubjtcblx0XHRcdFx0aWYgKHByZWQgIT09IG51bGwgJiYgbWF0Y2gzKHByZWQsIHYwLCB2MSwgdjIpKSB7XG5cdFx0XHRcdFx0bGFzdEhpdCA9IHByZWQ7XG5cdFx0XHRcdFx0cmV0dXJuIHByZWQucjtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAobGggIT09IHByZWQgJiYgbWF0Y2gzKGxoLCB2MCwgdjEsIHYyKSkgcmV0dXJuIGxoLnI7XG5cdFx0XHR9XG5cdFx0XHRpZiAobkFyZ3MgPT09IDIgJiYgdHlwZW9mIHYxID09PSBcInN0cmluZ1wiICYmIHYxICE9PSBcIlwiKSB7XG5cdFx0XHRcdGNvbnN0IGJ1Y2tldCA9IGFyZ0NhY2hlLmdldCh2MCk7XG5cdFx0XHRcdGlmIChidWNrZXQgIT09IHZvaWQgMCAmJiBidWNrZXQuc2tpcCA+IDApIHtcblx0XHRcdFx0XHRidWNrZXQuc2tpcC0tO1xuXHRcdFx0XHRcdGxhc3RIaXQgPSBudWxsO1xuXHRcdFx0XHRcdHJldHVybiBjaHVybkxvb2t1cCh2MSwgdjAsIHRydWUpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gcmVzb2x2ZUFyZ3MoW1xuXHRcdFx0XHR2MCxcblx0XHRcdFx0djEsXG5cdFx0XHRcdHYyXG5cdFx0XHRdLCB0cnVlKTtcblx0XHR9XG5cdFx0aWYgKG5BcmdzID09PSAxKSByZXR1cm4gdHlwZW9mIHYwID09PSBcInN0cmluZ1wiID8gbWVyZ2VTdHJpbmcodjApIDogbWVyZ2VTaW5nbGVWYWx1ZSh2MCk7XG5cdFx0Y29uc3QgbGggPSBsYXN0SGl0O1xuXHRcdGlmIChsaCAhPT0gbnVsbCkge1xuXHRcdFx0Y29uc3QgcHJlZCA9IGxoLm47XG5cdFx0XHRpZiAocHJlZCAhPT0gbnVsbCkge1xuXHRcdFx0XHRjb25zdCBwYSA9IHByZWQuYTtcblx0XHRcdFx0bGV0IGsgPSAwO1xuXHRcdFx0XHRsZXQgb2sgPSB0cnVlO1xuXHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG5BcmdzOyBpKyspIHtcblx0XHRcdFx0XHRjb25zdCB2ID0gYXJndW1lbnRzW2ldO1xuXHRcdFx0XHRcdGlmICghdikgY29udGludWU7XG5cdFx0XHRcdFx0aWYgKHYgIT09IHBhW2tdKSB7XG5cdFx0XHRcdFx0XHRvayA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGsrKztcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAob2sgJiYgayA9PT0gcHJlZC50KSB7XG5cdFx0XHRcdFx0bGFzdEhpdCA9IHByZWQ7XG5cdFx0XHRcdFx0cmV0dXJuIHByZWQucjtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGxoICE9PSBwcmVkKSB7XG5cdFx0XHRcdGNvbnN0IGxhID0gbGguYTtcblx0XHRcdFx0bGV0IGsgPSAwO1xuXHRcdFx0XHRsZXQgb2sgPSB0cnVlO1xuXHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG5BcmdzOyBpKyspIHtcblx0XHRcdFx0XHRjb25zdCB2ID0gYXJndW1lbnRzW2ldO1xuXHRcdFx0XHRcdGlmICghdikgY29udGludWU7XG5cdFx0XHRcdFx0aWYgKHYgIT09IGxhW2tdKSB7XG5cdFx0XHRcdFx0XHRvayA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGsrKztcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAob2sgJiYgayA9PT0gbGgudCkgcmV0dXJuIGxoLnI7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGNvbnN0IHZhbHMgPSBbXTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG5BcmdzOyBpKyspIHZhbHMucHVzaChhcmd1bWVudHNbaV0pO1xuXHRcdHJldHVybiByZXNvbHZlQXJncyh2YWxzLCB0cnVlKTtcblx0fTtcbn07XG4vKipcbiogQ3JlYXRlIGEgYGNuYCBmdW5jdGlvbiBib3VuZCB0byBjb21waWxlZCB0YWJsZXMg4oCUIHRoZSBlbnRyeSBwb2ludCBmb3JcbiogcHJvamVjdC1jb21waWxlZCAoYGNuIGJ1aWxkYCkgdGFibGVzOlxuKlxuKiBgYGB0c1xuKiBpbXBvcnQgdGFibGVzIGZyb20gXCIuL2NuLXRhYmxlcy5qc1wiXG4qIGltcG9ydCB7IGNyZWF0ZUNuIH0gZnJvbSBcImNuL2VuZ2luZVwiXG4qIGV4cG9ydCBjb25zdCBjbiA9IGNyZWF0ZUNuKHRhYmxlcylcbiogYGBgXG4qL1xuY29uc3QgY3JlYXRlQ24gPSAodGFibGVzLCB2YWxpZGF0b3JJbXBscywgb3B0aW9ucykgPT4ge1xuXHRjb25zdCBlbmdpbmUgPSBjcmVhdGVFbmdpbmUodGFibGVzLCB2YWxpZGF0b3JJbXBscywgb3B0aW9ucyk7XG5cdHJldHVybiB3cmFwQ2xzeChlbmdpbmUubWVyZ2VTdHJpbmcsIGVuZ2luZSk7XG59O1xuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNsc3gsIGNyZWF0ZUNuLCBjcmVhdGVFbmdpbmUsIHR3Sm9pbiwgd3JhcENsc3ggfTsiLCJpbXBvcnQgdGFibGVzX2dlbmVyYXRlZF9kZWZhdWx0IGZyb20gXCIuL3RhYmxlcy5qc1wiO1xuaW1wb3J0IHsgY2xzeCwgY3JlYXRlRW5naW5lLCB0d0pvaW4sIHdyYXBDbHN4IH0gZnJvbSBcIi4vZW5naW5lLmpzXCI7XG5cbi8vI3JlZ2lvbiBzcmMvaW5kZXgudHNcbmNvbnN0IGluc3RhbmNlID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZUVuZ2luZSh0YWJsZXNfZ2VuZXJhdGVkX2RlZmF1bHQpO1xuLyoqXG4qIE1lcmdlIFRhaWx3aW5kIENTUyBjbGFzc2VzIHdpdGggY2xzeC1zdHlsZSBhcmd1bWVudHMgKHN0cmluZ3MsIGFycmF5cyxcbiogb2JqZWN0cywgY29uZGl0aW9uYWxzKS4gRHJvcC1pbiByZXBsYWNlbWVudCBmb3IgYHR3TWVyZ2UoY2xzeCguLi4pKWAuXG4qL1xuY29uc3QgY24gPSAvKiBAX19QVVJFX18gKi8gd3JhcENsc3goaW5zdGFuY2UubWVyZ2VTdHJpbmcsIGluc3RhbmNlKTtcbi8qKiB0YWlsd2luZC1tZXJnZeKAk2NvbXBhdGlibGUgdmFyaWFkaWMgbWVyZ2UgKHN0cmluZ3MgKyBuZXN0ZWQgYXJyYXlzKS4gKi9cbmNvbnN0IHR3TWVyZ2UgPSBpbnN0YW5jZS5tZXJnZTtcblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjbHN4LCBjbiwgY3JlYXRlRW5naW5lLCB0d0pvaW4sIHR3TWVyZ2UgfTsiXSwibWFwcGluZ3MiOiI7QUFDQSxJQUFNLElBQUk7QUFDVixJQUFNLEtBQUssR0FBRyxJQUFJLE1BQU07Q0FDdkIsTUFBTSxNQUFNLElBQUksV0FBVyxFQUFFLE1BQU07Q0FDbkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksS0FBSyxFQUFFLFdBQVcsQ0FBQyxJQUFJLElBQUk7Q0FDbEUsT0FBTztBQUNSO0FBQ0EsSUFBTSxNQUFNLFdBQVc7Q0FDdEIsTUFBTSxNQUFNLElBQUksV0FBVyxPQUFPLFNBQVMsQ0FBQztDQUM1QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU87Q0FDckUsT0FBTztBQUNSO0FBQ0EsSUFBTSxNQUFNLE1BQU07Q0FDakIsTUFBTSxNQUFNLElBQUksV0FBVyxFQUFFLE1BQU07Q0FDbkMsSUFBSSxJQUFJO0NBQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0VBQ2xDLE1BQU0sSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJO0VBQzVCLEtBQUssTUFBTSxJQUFJLEVBQUUsSUFBSTtFQUNyQixJQUFJLEtBQUs7Q0FDVjtDQUNBLE9BQU87QUFDUjtBQUNBLElBQU0sY0FBYztBQUNwQixJQUFNLHVCQUF1QixDQUFDO0FBQzlCLElBQU0sWUFBWSxHQUFHLEVBQUUsaVVBQWlVLENBQUM7QUFDelYsSUFBTSxhQUFhLEdBQUcsRUFBRSxnVUFBZ1UsQ0FBQztBQUN6VixJQUFNLFlBQVk7QUFDbEIsSUFBTSxvQkFBb0I7Q0FDekIsTUFBTSxJQUFJLFVBQVUsU0FBUztDQUM3QixNQUFNLFFBQVEsSUFBSSxXQUFXLENBQUM7Q0FDOUIsS0FBSyxJQUFJLElBQUksSUFBSSxHQUFHLEtBQUssR0FBRyxLQUFLO0VBQ2hDLElBQUksSUFBSTtFQUNSLElBQUksSUFBSSxJQUFJO0VBQ1osS0FBSyxJQUFJLElBQUksVUFBVSxJQUFJLElBQUksVUFBVSxJQUFJLElBQUksS0FBSztHQUNyRCxLQUFLLE1BQU07R0FDWCxLQUFLLE1BQU07RUFDWjtFQUNBLE1BQU0sS0FBSztDQUNaO0NBQ0EsTUFBTSxNQUFNLElBQUksV0FBVyxVQUFVLEVBQUU7Q0FDdkMsSUFBSSxJQUFJO0NBQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztFQUMzQixJQUFJLElBQUksSUFBSTtFQUNaLEtBQUssSUFBSSxJQUFJLFVBQVUsSUFBSSxJQUFJLFVBQVUsSUFBSSxJQUFJLEtBQUs7R0FDckQsSUFBSSxPQUFPO0dBQ1gsS0FBSyxNQUFNO0VBQ1o7Q0FDRDtDQUNBLE9BQU87QUFDUixFQUFBLENBQUc7QUFDSCxJQUFNLFlBQVksRUFBRSxtVUFBbVUsQ0FBQztBQUN4VixJQUFNLFdBQVcsR0FBRyxFQUFFLGdDQUFnQyxDQUFDO0FBQ3ZELElBQU0sV0FBVyxFQUFFLDRIQUE0SDtBQUMvSSxJQUFNLFdBQVcsRUFBRSxnUEFBZ1A7QUFDblEsSUFBTSxhQUFhLEdBQUcsMjJCQUEyMkI7QUFDajRCLElBQU0sbUJBQW1CO0NBQ3hCLE1BQU0sdUJBQXVCLElBQUksV0FBVyxHQUFHLEVBQUEsQ0FBRyxLQUFLLEVBQUU7Q0FDekQsTUFBTSxJQUFJLEdBQUcscVBBQXFQO0NBQ2xRLE1BQU0sSUFBSSxHQUFHLHNQQUFzUDtDQUNuUSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssSUFBSSxFQUFFLE1BQU0sRUFBRTtDQUNqRCxPQUFPO0FBQ1IsRUFBQSxDQUFHO0FBQ0gsSUFBTSxPQUFPLDg0S0FBODRLLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxNQUFNO0NBQ2g3SyxNQUFNLFFBQVEsRUFBRSxNQUFNLEdBQUc7Q0FDekIsTUFBTSxTQUFTLE1BQU0sTUFBTTtDQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssTUFBTSxLQUFLLFNBQVMsTUFBTTtDQUNqRSxPQUFPO0FBQ1IsQ0FBQztBQUNELElBQU0sS0FBSyxHQUFHLHFSQUFxUjtBQUNuUyxJQUFNLEtBQUssR0FBRyxvUkFBb1I7QUFDbFMsSUFBTSxLQUFLLEdBQUcsb1JBQW9SO0FBQ2xTLElBQU0sNEJBQTRCLElBQUksV0FBVyxHQUFHO0FBQ3BELElBQU0sMkJBQTJCLElBQUksV0FBVyxHQUFHO0FBQ25ELElBQU0sMEJBQTBCLElBQUksV0FBVyxHQUFHO0FBQ2xELElBQUksV0FBVztBQUNmLElBQU0sOEJBQThCLElBQUksV0FBVyxJQUFJO0FBQ3ZEO0NBQ0MsTUFBTSwwQkFBMEIsSUFBSSxJQUFJO0NBQ3hDLElBQUksVUFBVTtDQUNkLElBQUksSUFBSTtDQUNSLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsS0FBSyxLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQUcsS0FBSztFQUNuRSxJQUFJLElBQUksUUFBUSxJQUFJLElBQUk7RUFDeEIsSUFBSSxNQUFNLEtBQUssR0FBRztHQUNqQixJQUFJO0dBQ0osUUFBUSxJQUFJLE1BQU0sQ0FBQztHQUNuQixZQUFZLElBQUksS0FBSyxTQUFTO0dBQzlCLFlBQVksSUFBSSxJQUFJLEtBQUssS0FBSztHQUM5QixZQUFZO0VBQ2I7RUFDQSxVQUFVLEtBQUssR0FBRztFQUNsQixTQUFTLEtBQUssR0FBRztFQUNqQixRQUFRLEtBQUs7RUFDYjtDQUNEO0FBQ0Q7QUFDQSxJQUFNLFNBQVMsR0FBRyx5REFBeUQ7QUFDM0UsSUFBTSxXQUFXLEdBQUcsRUFBRSx3REFBd0QsQ0FBQztBQUMvRSxJQUFNLFNBQVMsR0FBRywwTUFBME07QUFDNU4sSUFBTSxTQUFTLEVBQUUsR0FBRztBQUNwQixJQUFNLFNBQVMsRUFBRSxHQUFHO0FBQ3BCLElBQU0sc0JBQXNCLEVBQUUsR0FBRztBQUVqQyxJQUFJLDJCQUEyQjtDQUM5QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EseUJBQUE7QUFDRDs7QUM5SEEsSUFBTSxTQUFTLDBCQUEwQixJQUFJLE1BQU07QUFDbkQsSUFBTSxXQUFXO0FBQ2pCLElBQU0sT0FBTztBQUNiLElBQU0sT0FBTyxLQUFLLEdBQUcsTUFBTTtDQUMxQixJQUFJLElBQUk7Q0FDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxXQUFXLENBQUMsR0FBRyxRQUFRO0NBQ3pFLE9BQU87QUFDUjtBQUNBLElBQU0sWUFBWSxLQUFLLEdBQUcsTUFBTTtDQUMvQixNQUFNLE1BQU0sSUFBSTtDQUNoQixJQUFJLElBQUksS0FBSyxLQUFLLEtBQUssVUFBVSxJQUFJLElBQUksV0FBVyxDQUFDO0NBQ3JELElBQUksTUFBTSxHQUFHO0VBQ1osTUFBTSxJQUFJLE9BQU87RUFDakIsTUFBTSxJQUFJLE9BQU87RUFDakIsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFdBQVcsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLFdBQVcsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLFdBQVcsSUFBSSxDQUFDLEdBQUcsVUFBVTtFQUM5RyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksV0FBVyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksV0FBVyxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxXQUFXLElBQUksQ0FBQyxHQUFHLFVBQVU7RUFDbEgsS0FBSyxJQUFJLFdBQVcsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLFdBQVcsSUFBSSxDQUFDLEtBQUs7RUFDM0QsS0FBSyxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFdBQVcsQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLEtBQUssR0FBRyxRQUFRO0NBQ3BJO0NBQ0EsT0FBTyxJQUFJLE1BQU0sS0FBSztBQUN2QjtBQUNBLElBQU0sZ0JBQWdCLEdBQUcsZ0JBQWdCLFVBQVUsQ0FBQyxNQUFNO0NBQ3pELE1BQU0sRUFBRSxhQUFhLFdBQVcsWUFBWSxXQUFXLFlBQVksV0FBVyxXQUFXLFVBQVUsVUFBVSxVQUFVLFlBQVksV0FBVyxVQUFVLFNBQVMsYUFBYSxVQUFVLFFBQVEsVUFBVSxRQUFRLFFBQVEsUUFBUSxxQkFBcUIsc0JBQXNCLDRCQUE0QjtDQUN6UyxNQUFNLFNBQVMsSUFBSSxXQUFXLFdBQVcsQ0FBQyxDQUFDLEtBQUssRUFBRTtDQUNsRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUssT0FBTyxPQUFPLE1BQU07Q0FDNUQsSUFBSSxTQUFTO0NBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksU0FBUyxRQUFRLEtBQUs7RUFDN0MsTUFBTSxJQUFJLFNBQVMsSUFBSSxLQUFLLFNBQVM7RUFDckMsSUFBSSxJQUFJLFFBQVEsU0FBUztDQUMxQjtDQUNBLElBQUksa0JBQWtCO0NBQ3RCLE9BQU8sa0JBQWtCLEtBQUssSUFBSSxTQUFTLE9BQU8sU0FBUyxvQkFBb0I7Q0FDL0UsTUFBTSxVQUFVLElBQUksV0FBVyxTQUFTLFNBQVMsQ0FBQztDQUNsRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUssUUFBUSxJQUFJLEtBQUssUUFBUSxLQUFLLFNBQVMsU0FBUyxLQUFLLEtBQUssU0FBUyxTQUFTO0NBQ3RILE1BQU0sbUJBQW1CLElBQUksV0FBVyxXQUFXO0NBQ25ELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxvQkFBb0IsUUFBUSxLQUFLLGlCQUFpQixvQkFBb0IsTUFBTTtDQUNoRyxNQUFNLFlBQVksVUFBVSxTQUFTO0NBQ3JDLE1BQU0sYUFBYSxJQUFJLFdBQVcsU0FBUztDQUMzQyxJQUFJLFlBQVk7Q0FDaEIsSUFBSSxXQUFXO0NBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0VBQzFDLFdBQVcsVUFBVSxNQUFNO0VBQzNCLE1BQU0sTUFBTSxZQUFZLFFBQVEsS0FBSyxJQUFJO0VBQ3pDLElBQUksTUFBTSxXQUFXLFlBQVk7RUFDakMsTUFBTSxLQUFLLFNBQVMsV0FBVyxZQUFZLFFBQVEsS0FBSyxFQUFFO0VBQzFELElBQUksT0FBTyxNQUFNLE9BQU8sSUFBSSxXQUFXO0NBQ3hDO0NBQ0EsSUFBSSxXQUFXO0NBQ2YsT0FBTyxXQUFXLFVBQVUsU0FBUyxHQUFHLGFBQWE7Q0FDckQsTUFBTSxXQUFXLElBQUksV0FBVyxRQUFRLENBQUMsQ0FBQyxLQUFLLEVBQUU7Q0FDakQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0VBQzFDLE1BQU0sTUFBTSxZQUFZLFFBQVEsS0FBSztFQUNyQyxJQUFJLE9BQU8sSUFBSSxVQUFVLEtBQUssTUFBTSxZQUFZLFFBQVEsS0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLEtBQUssVUFBVSxJQUFJLFVBQVUsSUFBSSxLQUFLLFdBQVc7RUFDN0gsT0FBTyxTQUFTLFNBQVMsSUFBSSxNQUFNLE1BQU0sSUFBSSxXQUFXO0VBQ3hELFNBQVMsT0FBTztDQUNqQjtDQUNBLE1BQU0sWUFBWSxRQUFRLE9BQU8sR0FBRyxNQUFNO0VBQ3pDLElBQUksT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLElBQUksS0FBSyxLQUFLLFFBQVEsVUFBVSxJQUFJLEtBQUssV0FBVztFQUM5RSxNQUFNLE1BQU0sSUFBSTtFQUNoQixTQUFTO0dBQ1IsTUFBTSxRQUFRLFNBQVM7R0FDdkIsSUFBSSxVQUFVLElBQUksT0FBTztHQUN6QixJQUFJLFVBQVUsV0FBVyxVQUFVLFlBQVksUUFBUSxTQUFTLElBQUksT0FBTyxLQUFLO0lBQy9FLE1BQU0sTUFBTSxZQUFZLFFBQVEsU0FBUztJQUN6QyxJQUFJLEtBQUs7SUFDVCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLLElBQUksU0FBUyxXQUFXLE1BQU0sQ0FBQyxNQUFNLE1BQU0sV0FBVyxJQUFJLENBQUMsR0FBRztLQUMzRixLQUFLO0tBQ0w7SUFDRDtJQUNBLElBQUksSUFBSSxPQUFPLFNBQVM7R0FDekI7R0FDQSxNQUFNLE1BQU0sSUFBSSxXQUFXO0VBQzVCO0NBQ0Q7Q0FDQSxNQUFNLFlBQVksUUFBUSxhQUFhO0NBQ3ZDLE1BQU0sYUFBYSxRQUFRLFVBQVUsRUFBRSxVQUFVO0NBQ2pELE1BQU0sY0FBYyxlQUFlLEtBQUssS0FBSyxhQUFhO0NBQzFELE1BQU0sTUFBTSxZQUFZO0NBQ3hCLE1BQU0sV0FBVyx3QkFBd0IsQ0FBQyxFQUFBLENBQUcsS0FBSyxTQUFTO0VBQzFELE1BQU0sS0FBSyxrQkFBa0IsZUFBZTtFQUM1QyxJQUFJLENBQUMsSUFBSSxNQUFNLElBQUksTUFBTSwyQkFBMkIsSUFBSTtFQUN4RCxPQUFPO0NBQ1IsQ0FBQztDQUNELE1BQU0sa0JBQWtCO0NBQ3hCLE1BQU0scUJBQXFCO0NBQzNCLE1BQU0sY0FBYztDQUNwQixNQUFNLGFBQWE7Q0FDbkIsSUFBSSxRQUFRO0NBQ1osSUFBSSxVQUFVO0NBQ2QsSUFBSSxVQUFVO0NBQ2QsSUFBSSxRQUFRO0NBQ1osSUFBSSxRQUFRO0NBQ1osTUFBTSxjQUFjLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sTUFBTTtDQUNuRyxNQUFNLFdBQVcsTUFBTSxLQUFLLEtBQUssT0FBTyxhQUFhLENBQUMsQ0FBQztDQUN2RCxNQUFNLGNBQWMsT0FBTyxHQUFHLE1BQU07RUFDbkMsUUFBUTtFQUNSLFVBQVU7RUFDVixJQUFJLElBQUksSUFBSSxHQUFHO0VBQ2YsTUFBTSxLQUFLLE1BQU0sV0FBVyxDQUFDO0VBQzdCLE1BQU0sS0FBSyxNQUFNLFdBQVcsSUFBSSxDQUFDO0VBQ2pDLElBQUksT0FBTyxNQUFNLE9BQU8sSUFBSSxRQUFRO09BQy9CLElBQUksT0FBTyxNQUFNLE9BQU8sSUFBSSxRQUFRO09BQ3BDO0VBQ0wsUUFBUSxJQUFJO0VBQ1osUUFBUSxJQUFJO0VBQ1osSUFBSSxJQUFJLElBQUk7RUFDWixJQUFJLFdBQVcsTUFBTSxXQUFXLENBQUMsQ0FBQyxHQUFHO0dBQ3BDO0dBQ0EsT0FBTyxJQUFJLElBQUksR0FBRztJQUNqQixNQUFNLElBQUksTUFBTSxXQUFXLENBQUM7SUFDNUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLE1BQU0sSUFBSTtJQUNoQztHQUNEO0dBQ0EsSUFBSSxJQUFJLElBQUksS0FBSyxNQUFNLFdBQVcsQ0FBQyxNQUFNLElBQUk7SUFDNUMsVUFBVSxJQUFJO0lBQ2QsVUFBVTtJQUNWLFFBQVEsSUFBSTtHQUNiO0VBQ0Q7Q0FDRDtDQUNBLE1BQU0sVUFBVSxPQUFPLEdBQUcsR0FBRyxRQUFRO0VBQ3BDLElBQUksSUFBSSxNQUFNLElBQUksUUFBUSxPQUFPO0VBQ2pDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSyxJQUFJLE1BQU0sV0FBVyxJQUFJLENBQUMsTUFBTSxJQUFJLFdBQVcsQ0FBQyxHQUFHLE9BQU87RUFDL0YsT0FBTztDQUNSO0NBQ0EsTUFBTSxnQkFBZ0I7Q0FDdEIsTUFBTSxjQUFjO0NBQ3BCLE1BQU0sWUFBWSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxNQUFNLE9BQU8sQ0FBQyxDQUFDO0NBQ3RELE1BQU0sNkJBQTZCLE9BQU8sR0FBRyxNQUFNO0VBQ2xELElBQUksSUFBSSxJQUFJLE1BQU0sQ0FBQyxPQUFPLE9BQU8sR0FBRyxJQUFJLElBQUksWUFBWSxHQUFHLE9BQU87RUFDbEUsSUFBSSxNQUFNLFdBQVcsSUFBSSxFQUFFLE1BQU0sSUFBSSxPQUFPLElBQUksS0FBSztFQUNyRCxNQUFNLE1BQU0sTUFBTSxXQUFXLElBQUksRUFBRTtFQUNuQyxPQUFPLFFBQVEsT0FBTyxJQUFJLEtBQUssTUFBTSxPQUFPLE9BQU8sSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLEtBQUssUUFBUSxPQUFPLElBQUksS0FBSyxNQUFNLE9BQU8sT0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLFVBQVU7Q0FDdko7Q0FDQSxNQUFNLFFBQVE7RUFDYjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRDtDQUNBLE1BQU0sVUFBVSw2TEFBNkwsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsQ0FBQztDQUMvTyxNQUFNLFFBQVE7RUFDYjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRDtDQUNBLE1BQU0sZ0JBQWdCLElBQUksT0FBTyxHQUFHLE1BQU07RUFDekMsSUFBSSxNQUFNLElBQUk7R0FDYixJQUFJLE1BQU0sSUFBSSxPQUFPLFFBQVEsS0FBSyxHQUFHLENBQUMsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0dBQ3ZELE1BQU0sSUFBSSxLQUFLO0dBQ2YsSUFBSSxVQUFVLE1BQU0sSUFBSSxPQUFPO0dBQy9CLElBQUksV0FBVyxHQUFHO0lBQ2pCLEtBQUssTUFBTSxLQUFLLFFBQVEsSUFBSSxJQUFJLE9BQU8sT0FBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLE9BQU87SUFDM0UsT0FBTztHQUNSO0dBQ0EsUUFBUSxNQUFNLElBQWQ7SUFDQyxLQUFLLEdBQUcsT0FBTztJQUNmLEtBQUssR0FBRyxPQUFPO0lBQ2YsS0FBSyxHQUFHO0tBQ1AsTUFBTSxJQUFJLE1BQU0sTUFBTSxPQUFPLEtBQUs7S0FDbEMsT0FBTyxnQkFBZ0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsS0FBSyxDQUFDO0lBQzdEO0lBQ0EsS0FBSyxHQUFHLE9BQU8sU0FBUyxNQUFNLE1BQU0sT0FBTyxLQUFLLENBQUM7SUFDakQsS0FBSyxHQUFHLE9BQU8sV0FBVyxLQUFLLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQztJQUN4RCxTQUFTLE9BQU8sWUFBWSxLQUFLLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQztHQUMzRDtFQUNEO0VBQ0EsUUFBUSxJQUFSO0dBQ0MsS0FBSyxHQUFHLE9BQU87R0FDZixLQUFLLEdBQUcsT0FBTyxVQUFVO0dBQ3pCLEtBQUssR0FBRyxPQUFPLFVBQVU7R0FDekIsS0FBSyxHQUFHLE9BQU8sVUFBVTtHQUN6QixLQUFLLEdBQUcsT0FBTyxjQUFjLEtBQUssTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0dBQ25ELEtBQUssR0FBRyxPQUFPLFNBQVMsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0dBQ3pDLEtBQUssR0FBRztJQUNQLE1BQU0sSUFBSSxNQUFNLE1BQU0sR0FBRyxDQUFDO0lBQzFCLE9BQU8sQ0FBQyxDQUFDLEtBQUssT0FBTyxVQUFVLE9BQU8sQ0FBQyxDQUFDO0dBQ3pDO0dBQ0EsS0FBSyxHQUFHLE9BQU8sSUFBSSxLQUFLLE1BQU0sV0FBVyxJQUFJLENBQUMsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLENBQUM7R0FDeEYsS0FBSyxHQUFHLE9BQU8sWUFBWSxLQUFLLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQztHQUNqRCxTQUFTLE9BQU8sMEJBQTBCLE9BQU8sR0FBRyxDQUFDO0VBQ3REO0NBQ0Q7Q0FDQSxNQUFNLGlCQUFpQixJQUFJLElBQUksT0FBTyw0QkFBNEIsV0FBVyx3QkFBd0IsTUFBTSxHQUFHLElBQUksdUJBQXVCO0NBQ3pJLE1BQU0sY0FBYyxLQUFLLE9BQU8sR0FBRyxHQUFHLEtBQUssU0FBUztFQUNuRCxNQUFNLElBQUksSUFBSSxPQUFPLEdBQUcsQ0FBQyxLQUFLLE1BQU0sYUFBYSxLQUFLO0VBQ3RELElBQUksU0FBUyxJQUFJLElBQUksQ0FBQztFQUN0QixJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU8sS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLO0dBQ3JFLE1BQU0sS0FBSyxPQUFPO0dBQ2xCLElBQUksR0FBRyxRQUFRLE9BQU8sR0FBRyxFQUFFLFdBQVcsSUFBSSxHQUFHO0dBQzdDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsUUFBUSxLQUFLLElBQUksR0FBRyxFQUFFLFdBQVcsQ0FBQyxNQUFNLE1BQU0sV0FBVyxJQUFJLENBQUMsR0FBRyxTQUFTO0dBQ25HLE9BQU8sR0FBRztFQUNYO09BQ0ssSUFBSSxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUM7RUFDM0IsTUFBTSxJQUFJLE1BQU0sTUFBTSxHQUFHLENBQUM7RUFDMUIsTUFBTSxLQUFLLEtBQUssQ0FBQztFQUNqQixPQUFPLEtBQUs7R0FDWDtHQUNBO0dBQ0E7RUFDRCxDQUFDO0VBQ0QsT0FBTztDQUNSO0NBQ0EsSUFBSSw0QkFBNEIsSUFBSSxJQUFJO0NBQ3hDLElBQUksNkJBQTZCLElBQUksSUFBSTtDQUN6QyxJQUFJLFlBQVk7Q0FDaEIsTUFBTSxVQUFVO0NBQ2hCLE1BQU0sdUJBQXVCLEtBQUssY0FBYztFQUMvQyxNQUFNLE9BQU8sQ0FBQztFQUNkLElBQUksS0FBSyxHQUFHLEtBQUssR0FBRyxRQUFRO0VBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztHQUNwQyxNQUFNLElBQUksSUFBSSxXQUFXLENBQUM7R0FDMUIsSUFBSSxPQUFPLEtBQUssT0FBTyxLQUFLLE1BQU0sSUFBSTtJQUNyQyxLQUFLLEtBQUssSUFBSSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0lBQzdCLFFBQVEsSUFBSTtHQUNiLE9BQU8sSUFBSSxNQUFNLElBQUk7UUFDaEIsSUFBSSxNQUFNLElBQUk7UUFDZCxJQUFJLE1BQU0sSUFBSTtRQUNkLElBQUksTUFBTSxJQUFJO0VBQ3BCO0VBQ0EsS0FBSyxLQUFLLElBQUksTUFBTSxLQUFLLENBQUM7RUFDMUIsSUFBSSxZQUFZLEtBQUs7RUFDckIsSUFBSSxLQUFLLFNBQVMsR0FBRztHQUNwQixNQUFNLFNBQVMsQ0FBQztHQUNoQixJQUFJLFVBQVUsQ0FBQztHQUNmLEtBQUssTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJLFdBQVcsQ0FBQyxNQUFNLE1BQU0sZUFBZSxJQUFJLEdBQUcsR0FBRztJQUNoRixJQUFJLFFBQVEsUUFBUTtLQUNuQixPQUFPLEtBQUssR0FBRyxRQUFRLEtBQUssQ0FBQztLQUM3QixVQUFVLENBQUM7SUFDWjtJQUNBLE9BQU8sS0FBSyxHQUFHO0dBQ2hCLE9BQU8sUUFBUSxLQUFLLEdBQUc7R0FDdkIsSUFBSSxRQUFRLFFBQVEsT0FBTyxLQUFLLEdBQUcsUUFBUSxLQUFLLENBQUM7R0FDakQsWUFBWSxPQUFPLEtBQUssR0FBRztFQUM1QjtFQUNBLE1BQU0sTUFBTSxZQUFZLFlBQVksT0FBTztFQUMzQyxJQUFJLEtBQUssV0FBVyxJQUFJLEdBQUc7RUFDM0IsSUFBSSxPQUFPLEtBQUssR0FBRyxXQUFXLElBQUksS0FBSyxLQUFLLFdBQVc7RUFDdkQsT0FBTztDQUNSO0NBQ0EsSUFBSSw0QkFBNEIsSUFBSSxJQUFJO0NBQ3hDLElBQUksWUFBWTtDQUNoQixNQUFNLFVBQVUsY0FBYztDQUM5QixNQUFNLGlCQUFpQjtDQUN2QixNQUFNLFdBQVc7Q0FDakIsTUFBTSxjQUFjO0NBQ3BCLE1BQU0sV0FBVyxJQUFJLFdBQVcsV0FBVztDQUMzQyxNQUFNLFVBQVUsSUFBSSxNQUFNLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSTtDQUNoRCxNQUFNLFVBQVUsSUFBSSxXQUFXLFdBQVc7Q0FDMUMsTUFBTSxVQUFVLElBQUksV0FBVyxXQUFXO0NBQzFDLE1BQU0sWUFBWSxJQUFJLFdBQVcsV0FBVztDQUM1QyxJQUFJLFdBQVc7Q0FDZixNQUFNLFdBQVcsTUFBTSxPQUFPLElBQUksSUFBSSxHQUFHLEtBQUssT0FBTyxVQUFVO0VBQzlELElBQUksT0FBTztFQUNYLElBQUksUUFBUSxVQUFVLE1BQU07R0FDM0IsSUFBSSxRQUFRLE9BQU8sT0FBTyxNQUFNLE9BQU8sT0FBTztRQUN6QyxLQUFLLGFBQWEsT0FBTyxHQUFHLE9BQU8sT0FBTyxZQUFZLElBQUk7UUFDMUQ7RUFDTjtFQUNBLFFBQVEsUUFBUSxNQUFNLE1BQU0sSUFBSSxFQUFFO0VBQ2xDLFNBQVMsUUFBUTtFQUNqQixRQUFRLFFBQVE7RUFDaEIsUUFBUSxRQUFRO0VBQ2hCLFVBQVUsUUFBUTtDQUNuQjtDQUNBLE1BQU0sa0JBQWtCLFFBQVEsS0FBSyxJQUFJO0NBQ3pDLElBQUksTUFBTTtDQUNWLElBQUksU0FBUztFQUNaLElBQUksV0FBVyxHQUFHO0VBQ2xCLElBQUksV0FBVyxHQUFHO0VBQ2xCLElBQUksV0FBVyxHQUFHO0VBQ2xCLElBQUksV0FBVyxHQUFHO0NBQ25CO0NBQ0EsSUFBSSxDQUFDLFVBQVUsUUFBUSxRQUFRLFVBQVU7Q0FDekMsSUFBSSxXQUFXLElBQUksV0FBVyxHQUFHO0NBQ2pDLElBQUksT0FBTyxJQUFJLFdBQVcsR0FBRztDQUM3QixNQUFNLG1CQUFtQjtFQUN4QixPQUFPO0VBQ1AsU0FBUyxPQUFPLEtBQUssTUFBTTtHQUMxQixNQUFNLElBQUksSUFBSSxXQUFXLEdBQUc7R0FDNUIsRUFBRSxJQUFJLENBQUM7R0FDUCxPQUFPO0VBQ1IsQ0FBQztFQUNELENBQUMsVUFBVSxRQUFRLFFBQVEsVUFBVTtFQUNyQyxNQUFNLEtBQUssSUFBSSxXQUFXLEdBQUc7RUFDN0IsR0FBRyxJQUFJLFFBQVE7RUFDZixXQUFXO0VBQ1gsT0FBTyxJQUFJLFdBQVcsR0FBRztDQUMxQjtDQUNBLElBQUksVUFBVTtDQUNkLElBQUksV0FBVyxJQUFJLFdBQVcsT0FBTztDQUNyQyxJQUFJLFdBQVcsSUFBSSxXQUFXLE9BQU87Q0FDckMsTUFBTSxTQUFTLElBQUksV0FBVyxXQUFXO0NBQ3pDLElBQUksY0FBYztDQUNsQixJQUFJLGFBQWE7Q0FDakIsSUFBSSxZQUFZLElBQUksYUFBYSxXQUFXO0NBQzVDLElBQUksY0FBYyxJQUFJLFdBQVcsV0FBVztDQUM1QyxJQUFJLFFBQVE7Q0FDWixNQUFNLGFBQWEsS0FBSyxRQUFRO0VBQy9CLElBQUksUUFBUSxLQUFLLE1BQU0sYUFBYTtHQUNuQyxJQUFJLE9BQU8sU0FBUyxPQUFPLE9BQU87R0FDbEMsT0FBTyxPQUFPO0dBQ2QsT0FBTztFQUNSO0VBQ0EsTUFBTSxNQUFNLE1BQU0sVUFBVSxNQUFNO0VBQ2xDLElBQUksTUFBTSxLQUFLLEtBQUssS0FBSyxVQUFVLE1BQU07RUFDekMsU0FBUztHQUNSLElBQUksWUFBWSxTQUFTLE9BQU87R0FDaEMsSUFBSSxVQUFVLFNBQVMsS0FBSyxPQUFPO0dBQ25DLE1BQU0sTUFBTSxJQUFJLGNBQWM7RUFDL0I7RUFDQSxVQUFVLE9BQU87RUFDakIsWUFBWSxPQUFPO0VBQ25CLE9BQU87Q0FDUjtDQUNBLE1BQU0sYUFBYSxPQUFPLElBQUksUUFBUSxRQUFRLFdBQVc7RUFDeEQsSUFBSSxTQUFTLE1BQU0sS0FBSyxNQUFNLFdBQVcsRUFBRSxNQUFNLE1BQU0sTUFBTSxXQUFXLFNBQVMsQ0FBQyxNQUFNLElBQUk7R0FDM0YsSUFBSSxRQUFRO0dBQ1osS0FBSyxJQUFJLElBQUksS0FBSyxHQUFHLElBQUksU0FBUyxHQUFHLEtBQUssSUFBSSxNQUFNLFdBQVcsQ0FBQyxNQUFNLElBQUk7SUFDekUsUUFBUTtJQUNSO0dBQ0Q7R0FDQSxJQUFJLFVBQVUsTUFBTSxVQUFVLEtBQUssR0FBRyxPQUFPO0dBQzdDLE9BQU8sV0FBVyxXQUFXLE9BQU8sS0FBSyxHQUFHLE9BQU8sR0FBRyxRQUFRO0VBQy9EO0VBQ0EsSUFBSSxVQUFVLEtBQUssVUFBVSxXQUFXLEdBQUcsT0FBTyxVQUFVO0VBQzVELEtBQUssSUFBSSxJQUFJLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUNyQyxNQUFNLFlBQVksU0FBUztHQUMzQixJQUFJLFlBQVksUUFBUTtHQUN4QixNQUFNLFNBQVMsU0FBUztHQUN4QixNQUFNLE9BQU8sU0FBUztHQUN0QixJQUFJLFdBQVcsWUFBWSxLQUFLLE9BQU8sS0FBSyxRQUFRLFdBQVc7SUFDOUQsTUFBTSxLQUFLLE1BQU0sV0FBVyxTQUFTO0lBQ3JDLElBQUksYUFBYSxTQUFTLE9BQU8sTUFBTSxPQUFPLElBQUk7S0FDakQsTUFBTSxJQUFJLFNBQVMsUUFBUSxPQUFPLFdBQVcsTUFBTTtLQUNuRCxJQUFJLEtBQUssR0FBRyxPQUFPO0lBQ3BCO0dBQ0Q7R0FDQSxNQUFNLEtBQUssVUFBVTtHQUNyQixJQUFJLEtBQUssR0FBRztHQUNaLE1BQU0sTUFBTSxTQUFTO0dBQ3JCLE1BQU0sS0FBSyxTQUFTO0dBQ3BCLE1BQU0sS0FBSyxTQUFTLE1BQU07R0FDMUIsSUFBSSxPQUFPLElBQUk7R0FDZixXQUFXLE9BQU8sV0FBVyxNQUFNO0dBQ25DLE1BQU0sS0FBSyxRQUFRLE1BQU07R0FDekIsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLGFBQWEsU0FBUyxJQUFJLE9BQU8sV0FBVyxNQUFNLEdBQUcsT0FBTyxXQUFXLEtBQUs7RUFDL0c7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLGtCQUFrQixVQUFVO0VBQ2pDLE1BQU0sSUFBSSxNQUFNO0VBQ2hCLElBQUksYUFBYTtFQUNqQixJQUFJLGtCQUFrQjtFQUN0QixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksV0FBVyxVQUFVLE9BQU8sU0FBUztHQUNwRCw0QkFBNEIsSUFBSSxJQUFJO0dBQ3BDLDZCQUE2QixJQUFJLElBQUk7R0FDckMsWUFBWTtHQUNaLFVBQVU7RUFDWDtFQUNBLElBQUksWUFBWSxTQUFTO0dBQ3hCLDRCQUE0QixJQUFJLElBQUk7R0FDcEMsWUFBWTtHQUNaLFVBQVU7RUFDWDtFQUNBLElBQUksSUFBSTtFQUNSLE9BQU8sSUFBSSxHQUFHO0dBQ2IsSUFBSSxJQUFJLE1BQU0sV0FBVyxDQUFDO0dBQzFCLElBQUksTUFBTSxNQUFNLEtBQUssS0FBSyxLQUFLLE1BQU0sS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0lBQzVELElBQUksTUFBTSxJQUFJLGdCQUFnQjtJQUM5QjtJQUNBO0dBQ0Q7R0FDQSxNQUFNLEtBQUs7R0FDWCxJQUFJLEtBQUs7R0FDVCxPQUFPLElBQUksR0FBRztJQUNiLElBQUksTUFBTSxXQUFXLENBQUM7SUFDdEIsSUFBSSxLQUFLLElBQUk7S0FDWixJQUFJLE1BQU0sSUFBSTtLQUNkLElBQUksS0FBSyxLQUFLLEtBQUssSUFBSTtNQUN0QixnQkFBZ0I7TUFDaEI7S0FDRDtJQUNELE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7S0FDbEMsZ0JBQWdCO0tBQ2hCO0lBQ0Q7SUFDQSxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUcsUUFBUTtJQUMvQjtHQUNEO0dBQ0EsTUFBTSxLQUFLO0dBQ1gsTUFBTSxNQUFNLEtBQUs7R0FDakIsSUFBSSxlQUFlLEtBQUssV0FBVztHQUNuQyxNQUFNLElBQUk7R0FDVixTQUFTLEtBQUs7R0FDZCxPQUFPLEtBQUs7R0FDWixtQkFBbUI7R0FDbkIsTUFBTSxLQUFLLEtBQUssS0FBSyxVQUFVO0dBQy9CLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSztHQUMzQixNQUFNLE9BQU8sSUFBSTtHQUNqQjtJQUNDLElBQUksUUFBUTtJQUNaLElBQUksU0FBUyxVQUFVLEtBQUssUUFBUSxVQUFVLFFBQVEsUUFBUSxLQUFLLENBQUMsV0FBVyxLQUFLLFFBQVE7U0FDdkYsSUFBSSxTQUFTLE9BQU8sT0FBTyxLQUFLLFFBQVEsT0FBTyxPQUFPLFFBQVEsUUFBUSxPQUFPLEVBQUUsQ0FBQyxXQUFXLEtBQUssUUFBUSxPQUFPO0lBQ3BILElBQUksU0FBUyxHQUFHO0tBQ2YsTUFBTSxJQUFJLFFBQVE7S0FDbEIsSUFBSSxLQUFLO0tBQ1QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUUsV0FBVyxDQUFDLE1BQU0sTUFBTSxXQUFXLEtBQUssQ0FBQyxHQUFHO01BQy9FLEtBQUs7TUFDTDtLQUNEO0tBQ0EsSUFBSSxJQUFJO01BQ1AsT0FBTyxLQUFLLFFBQVE7TUFDcEIsT0FBTyxLQUFLLFFBQVE7TUFDcEIsU0FBUyxLQUFLLFVBQVU7TUFDeEI7S0FDRDtJQUNEO0dBQ0Q7R0FDQSxJQUFJLE1BQU07R0FDVixJQUFJLFFBQVEsR0FBRztJQUNkLElBQUksS0FBSyxNQUFNLE9BQU8sQ0FBQyxNQUFNLFdBQVcsYUFBYSxFQUFFLEdBQUc7S0FDekQsT0FBTyxLQUFLO0tBQ1osUUFBUSxNQUFNLE9BQU8sSUFBSSxJQUFJLEdBQUcsVUFBVSxHQUFHLENBQUM7S0FDOUM7SUFDRDtJQUNBLE1BQU0sS0FBSztHQUNaO0dBQ0EsSUFBSSxTQUFTLEdBQUcsU0FBUztHQUN6QixJQUFJLFlBQVksSUFBSSxZQUFZO0dBQ2hDLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLEtBQUs7SUFDOUIsTUFBTSxLQUFLLE1BQU0sV0FBVyxDQUFDO0lBQzdCLElBQUksV0FBVyxLQUFLLFdBQVcsR0FBRztLQUNqQyxJQUFJLE9BQU8sSUFBSTtNQUNkLFlBQVk7TUFDWjtLQUNEO0tBQ0EsSUFBSSxPQUFPLElBQUk7TUFDZCxZQUFZO01BQ1o7S0FDRDtJQUNEO0lBQ0EsSUFBSSxPQUFPLElBQUk7U0FDVixJQUFJLE9BQU8sSUFBSTtTQUNmLElBQUksT0FBTyxJQUFJO1NBQ2YsSUFBSSxPQUFPLElBQUk7R0FDckI7R0FDQSxNQUFNLFdBQVcsYUFBYSxNQUFNLFlBQVksSUFBSTtHQUNwRCxJQUFJLEtBQUs7R0FDVCxJQUFJLEtBQUs7R0FDVCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxjQUFjO0dBQ2xCLElBQUksS0FBSyxNQUFNLE1BQU0sV0FBVyxLQUFLLENBQUMsTUFBTSxJQUFJO0lBQy9DLFlBQVk7SUFDWjtHQUNELE9BQU8sSUFBSSxLQUFLLE1BQU0sTUFBTSxXQUFXLEVBQUUsTUFBTSxJQUFJO0lBQ2xELFlBQVk7SUFDWjtJQUNBLGNBQWM7R0FDZjtHQUNBLElBQUksYUFBYTtHQUNqQixJQUFJLFlBQVksVUFBVTtJQUN6QixhQUFhLFlBQVk7SUFDekIsSUFBSSxjQUFjLElBQUksYUFBYTtHQUNwQztHQUNBLElBQUksWUFBWTtHQUNoQixJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sV0FBVyxFQUFFLE1BQU0sSUFBSSxZQUFZLEtBQUs7R0FDakUsSUFBSSxPQUFPO0dBQ1gsSUFBSSxLQUFLO0dBQ1QsSUFBSSxLQUFLO0dBQ1QsSUFBSSxVQUFVO0dBQ2QsSUFBSSxVQUFVO0dBQ2QsSUFBSSxVQUFVLE1BQU0sS0FBSyxXQUFXLE9BQU8sR0FBRztJQUM3QyxTQUFTLEtBQUs7SUFDZCxTQUFTLEtBQUs7SUFDZCxVQUFVO0dBQ1g7R0FDQSxJQUFJLFlBQVk7R0FDaEIsSUFBSSxZQUFZO0dBQ2hCLEtBQUssSUFBSSxJQUFJLFdBQVcsSUFBSSxJQUFJLEtBQUs7SUFDcEMsSUFBSSxNQUFNLFlBQVk7S0FDckIsWUFBWSxLQUFLLEtBQUssT0FBTztLQUM3QixZQUFZO0lBQ2I7SUFDQSxJQUFJLFNBQVMsTUFBTTtLQUNsQixNQUFNLEtBQUssTUFBTSxXQUFXLENBQUM7S0FDN0IsSUFBSSxVQUFVO0tBQ2QsSUFBSSxLQUFLLElBQUk7TUFDWixJQUFJLFVBQVUsV0FBVyxFQUFFLE1BQU0sSUFBSTtPQUNwQztPQUNBLElBQUksT0FBTyxJQUFJLFVBQVUsT0FBTztNQUNqQyxPQUFPLE9BQU87S0FDZixPQUFPO01BQ04sTUFBTSxLQUFLLFVBQVU7TUFDckIsTUFBTSxLQUFLLFVBQVUsT0FBTztNQUM1QixJQUFJLE9BQU87TUFDWCxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLO09BQzdCLE1BQU0sS0FBSyxXQUFXO09BQ3RCLElBQUksVUFBVSxXQUFXLEVBQUUsTUFBTSxJQUFJO1FBQ3BDLElBQUksV0FBVyxJQUFJLEtBQUssT0FBTyxHQUFHLFVBQVUsT0FBTyxXQUFXO2FBQ3pEO1NBQ0osS0FBSyxLQUFLO1NBQ1YsS0FBSyxXQUFXLElBQUk7U0FDcEIsVUFBVSxXQUFXO1NBQ3JCLE9BQU87UUFDUjtRQUNBO09BQ0Q7TUFDRDtNQUNBLE9BQU87S0FDUjtLQUNBLElBQUksV0FBVyxNQUFNLFVBQVUsWUFBWSxLQUFLLFdBQVcsYUFBYSxNQUFNLElBQUksSUFBSSxNQUFNLE1BQU0sV0FBVyxJQUFJLENBQUMsTUFBTSxJQUFJO01BQzNILElBQUksWUFBWSxTQUFTO09BQ3hCLFdBQVc7T0FDWCxNQUFNLEtBQUssSUFBSSxXQUFXLE9BQU87T0FDakMsR0FBRyxJQUFJLFFBQVE7T0FDZixXQUFXO09BQ1gsTUFBTSxLQUFLLElBQUksV0FBVyxPQUFPO09BQ2pDLEdBQUcsSUFBSSxRQUFRO09BQ2YsV0FBVztNQUNaO01BQ0EsU0FBUyxXQUFXO01BQ3BCLFNBQVMsV0FBVyxJQUFJO01BQ3hCO0tBQ0Q7SUFDRDtHQUNEO0dBQ0EsSUFBSSxlQUFlLElBQUk7SUFDdEIsWUFBWSxLQUFLLEtBQUssT0FBTztJQUM3QixZQUFZO0dBQ2I7R0FDQSxNQUFNLFVBQVUsS0FBSyxLQUFLLE9BQU87R0FDakMsSUFBSTtHQUNKLElBQUksYUFBYTtHQUNqQixJQUFJLGNBQWMsR0FBRztJQUNwQixhQUFhO0lBQ2IsTUFBTSxVQUFVLE9BQU8sSUFBSSxZQUFZLFdBQVcsU0FBUztJQUMzRCxJQUFJLFFBQVEsWUFBWSxNQUFNLGVBQWUsaUJBQWlCLE1BQU07S0FDbkUsTUFBTSxVQUFVLFVBQVUsT0FBTyxJQUFJLElBQUksU0FBUyxPQUFPO0tBQ3pELElBQUksWUFBWSxZQUFZLFlBQVksS0FBSztNQUM1QyxNQUFNO01BQ04sYUFBYTtLQUNkO0lBQ0QsT0FBTyxJQUFJLFFBQVEsVUFBVTtLQUM1QixNQUFNLFVBQVUsT0FBTyxJQUFJLElBQUksU0FBUyxPQUFPO0tBQy9DLGFBQWE7SUFDZDtHQUNELE9BQU8sTUFBTSxVQUFVLE9BQU8sSUFBSSxJQUFJLFNBQVMsT0FBTztHQUN0RCxJQUFJLFFBQVE7R0FDWixJQUFJLFFBQVE7R0FDWixJQUFJLFFBQVEsVUFBVSxPQUFPLEtBQUs7UUFDN0I7SUFDSixRQUFRLGFBQWEsSUFBSTtJQUN6QixRQUFRLE9BQU8sWUFBWSxZQUFZLElBQUksSUFBSSxXQUFXLFdBQVcsT0FBTyxLQUFLLFdBQVcsWUFBWSxJQUFJLElBQUksTUFBTSxvQkFBb0IsR0FBRyxTQUFTLENBQUM7SUFDdkosT0FBTyxLQUFLO0lBQ1osU0FBUyxLQUFLO0lBQ2QsT0FBTyxLQUFLO0dBQ2I7R0FDQSxRQUFRLE1BQU0sT0FBTyxJQUFJLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSztFQUNsRDtFQUNBLElBQUksZUFBZSxHQUFHLE9BQU87RUFDN0IsSUFBSSxlQUFlLEdBQUcsT0FBTyxTQUFTLE9BQU8sS0FBSyxPQUFPLE9BQU8sSUFBSSxRQUFRLE1BQU0sTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFO0VBQzlHLElBQUksYUFBYSxrQkFBa0IsYUFBYTtHQUMvQyxPQUFPLGFBQWEsa0JBQWtCLGFBQWE7SUFDbEQsZ0JBQWdCO0lBQ2hCO0dBQ0Q7R0FDQSxZQUFZLElBQUksYUFBYSxXQUFXO0dBQ3hDLGNBQWMsSUFBSSxXQUFXLFdBQVc7RUFDekM7RUFDQSxJQUFJLGFBQWEsWUFBWSxhQUFhLFVBQVUsTUFBTSxJQUFJLE1BQU0sNENBQTRDO0VBQ2hILFFBQVEsUUFBUSxJQUFJO0VBQ3BCLElBQUksVUFBVSxHQUFHO0dBQ2hCLE9BQU8sS0FBSyxDQUFDO0dBQ2IsWUFBWSxLQUFLLENBQUM7R0FDbEIsUUFBUTtFQUNUO0VBQ0EsSUFBSSxVQUFVO0VBQ2QsS0FBSyxJQUFJLElBQUksYUFBYSxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3pDLE1BQU0sTUFBTSxPQUFPO0dBQ25CLElBQUksUUFBUSxVQUFVO0lBQ3JCLEtBQUssS0FBSztJQUNWO0dBQ0Q7R0FDQSxNQUFNLFFBQVEsT0FBTztHQUNyQixJQUFJLFVBQVUsT0FBTyxHQUFHLE1BQU0sR0FBRztJQUNoQyxLQUFLLEtBQUs7SUFDVixVQUFVO0lBQ1Y7R0FDRDtHQUNBLEtBQUssS0FBSztHQUNWLElBQUksTUFBTSxhQUFhO0lBQ3RCLE1BQU0sSUFBSSxPQUFPO0lBQ2pCLElBQUksS0FBSyxHQUFHLEtBQUssSUFBSSxJQUFJLFNBQVMsSUFBSSxJQUFJLFNBQVMsSUFBSSxJQUFJLEtBQUssVUFBVSxPQUFPLE9BQU8sRUFBRTtJQUMxRixJQUFJLFNBQVMsS0FBSyxHQUNaO1VBQUEsSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FBSyxJQUFJLE9BQU8sT0FBTyxLQUFLLFVBQVUsT0FBTyxPQUFPLEVBQUU7SUFBQTtHQUUzRjtFQUNEO0VBQ0EsSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsTUFBTSxrQkFBa0IsYUFBYSxHQUFHLE9BQU87RUFDakYsSUFBSSxNQUFNO0VBQ1YsSUFBSSxJQUFJO0VBQ1IsT0FBTyxJQUFJLFlBQVk7R0FDdEIsSUFBSSxDQUFDLEtBQUssSUFBSTtJQUNiO0lBQ0E7R0FDRDtHQUNBLE1BQU0sV0FBVyxTQUFTO0dBQzFCLElBQUksU0FBUyxPQUFPO0dBQ3BCLElBQUksSUFBSSxJQUFJO0dBQ1osT0FBTyxJQUFJLGNBQWMsS0FBSyxNQUFNLFNBQVMsT0FBTyxTQUFTLEtBQUssTUFBTSxXQUFXLE1BQU0sTUFBTSxJQUFJO0lBQ2xHLFNBQVMsT0FBTztJQUNoQjtHQUNEO0dBQ0EsSUFBSSxJQUFJLFNBQVMsR0FBRyxPQUFPO0dBQzNCLE9BQU8sTUFBTSxNQUFNLFVBQVUsTUFBTTtHQUNuQyxJQUFJO0VBQ0w7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLFlBQVk7Q0FDbEIsTUFBTSxPQUFPLElBQUksV0FBVyxZQUFZLENBQUM7Q0FDekMsSUFBSSxXQUFXO0NBQ2YsSUFBSSxZQUFZO0NBQ2hCLElBQUksUUFBUSxPQUFPLE9BQU8sSUFBSTtDQUM5QixJQUFJLFlBQVksT0FBTyxPQUFPLElBQUk7Q0FDbEMsSUFBSSwyQkFBMkIsSUFBSSxJQUFJO0NBQ3ZDLElBQUksK0JBQStCLElBQUksSUFBSTtDQUMzQyxJQUFJLGFBQWE7Q0FDakIsSUFBSSxZQUFZO0NBQ2hCLE1BQU0sbUJBQW1CO0VBQ3hCLFlBQVk7RUFDWixZQUFZLFlBQVksSUFBSTtFQUM1QixZQUFZO0NBQ2I7Q0FDQSxNQUFNLGVBQWUsVUFBVTtFQUM5QixJQUFJLFNBQVMsTUFBTTtFQUNuQixJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU87RUFDOUIsTUFBTSxPQUFPLFNBQVMsT0FBTyxHQUFHLE1BQU0sTUFBTTtFQUM1QyxNQUFNLFFBQVEsT0FBTyxTQUFTO0VBQzlCLE1BQU0sVUFBVSxLQUFLLFdBQVcsT0FBTyxjQUFjLEtBQUssT0FBTyxnQkFBZ0IsT0FBTyxZQUFZO0VBQ3BHLElBQUksU0FBUztHQUNaLFNBQVMsVUFBVTtHQUNuQixJQUFJLFdBQVcsS0FBSyxHQUFHO0lBQ3RCLE1BQU0sU0FBUztJQUNmLE9BQU87R0FDUjtFQUNEO0VBQ0EsU0FBUyxlQUFlLEtBQUs7RUFDN0IsSUFBSSxTQUFTO0dBQ1osTUFBTSxTQUFTO0dBQ2YsSUFBSSxFQUFFLGFBQWEsV0FBVztJQUM3QixhQUFhO0lBQ2IsWUFBWTtJQUNaLFFBQVEsT0FBTyxPQUFPLElBQUk7SUFDMUIsV0FBVztHQUNaO0VBQ0QsT0FBTztHQUNOLEtBQUssUUFBUSxPQUFPO0dBQ3BCLElBQUksRUFBRSxZQUFZLFdBQVcsV0FBVztFQUN6QztFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sa0JBQWtCLFVBQVU7RUFDakMsSUFBSSxTQUFTLFNBQVMsSUFBSSxLQUFLO0VBQy9CLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTztFQUM5QixNQUFNLE9BQU8sU0FBUyxPQUFPLEdBQUcsTUFBTSxNQUFNO0VBQzVDLE1BQU0sUUFBUSxPQUFPLFNBQVM7RUFDOUIsTUFBTSxVQUFVLEtBQUssV0FBVyxPQUFPLGNBQWMsS0FBSyxPQUFPLGdCQUFnQixPQUFPLFlBQVk7RUFDcEcsSUFBSSxTQUFTO0dBQ1osU0FBUyxhQUFhLElBQUksS0FBSztHQUMvQixJQUFJLFdBQVcsS0FBSyxHQUFHO0lBQ3RCLFNBQVMsSUFBSSxPQUFPLE1BQU07SUFDMUIsT0FBTztHQUNSO0VBQ0Q7RUFDQSxTQUFTLGVBQWUsS0FBSztFQUM3QixJQUFJLFNBQVM7R0FDWixTQUFTLElBQUksT0FBTyxNQUFNO0dBQzFCLElBQUksRUFBRSxhQUFhLFdBQVc7SUFDN0IsYUFBYTtJQUNiLGVBQWU7SUFDZiwyQkFBMkIsSUFBSSxJQUFJO0lBQ25DLFdBQVc7R0FDWjtFQUNELE9BQU87R0FDTixLQUFLLFFBQVEsT0FBTztHQUNwQixJQUFJLEVBQUUsWUFBWSxXQUFXLFdBQVc7RUFDekM7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLGNBQWMsVUFBVTtFQUM3QixNQUFNLE9BQU8sU0FBUyxPQUFPLEdBQUcsTUFBTSxNQUFNO0VBQzVDLE1BQU0sUUFBUSxPQUFPLFNBQVM7RUFDOUIsSUFBSSxLQUFLLFdBQVcsT0FBTyxjQUFjLEtBQUssT0FBTyxnQkFBZ0IsT0FBTyxZQUFZLElBQUksT0FBTztFQUNuRyxLQUFLLFFBQVEsT0FBTztFQUNwQixJQUFJLEVBQUUsWUFBWSxXQUFXLFdBQVc7RUFDeEMsT0FBTztDQUNSO0NBQ0EsTUFBTSxjQUFjLGNBQWMsSUFBSSxpQkFBaUIsVUFBVSxVQUFVO0VBQzFFLE1BQU0sU0FBUyxTQUFTLElBQUksS0FBSztFQUNqQyxPQUFPLFdBQVcsS0FBSyxJQUFJLFNBQVMsZUFBZSxLQUFLO0NBQ3pELElBQUk7Q0FDSixNQUFNLFFBQVEsV0FBVztFQUN4QixPQUFPLFVBQVUsV0FBVyxLQUFLLE9BQU8sVUFBVSxPQUFPLFdBQVcsWUFBWSxVQUFVLEVBQUUsSUFBSSxZQUFZLE9BQU8sTUFBTSxNQUFNLFNBQVMsQ0FBQztDQUMxSTtDQUNBLE9BQU87RUFDTjtFQUNBO0VBQ0EsWUFBWSxjQUFjLFVBQVUsUUFBUTtFQUM1QyxlQUFlO0NBQ2hCO0FBQ0Q7QUFDQSxJQUFNLGdCQUFnQixHQUFHLGFBQWE7Q0FDckMsSUFBSSxDQUFDLEdBQUcsT0FBTztDQUNmLElBQUksT0FBTyxNQUFNLFVBQVUsT0FBTztDQUNsQyxJQUFJLE1BQU07Q0FDVixJQUFJLE9BQU8sRUFBRSxXQUFXLGFBQWEsV0FBVyxNQUFNLFFBQVEsQ0FBQyxJQUFJLE9BQU87RUFDekUsTUFBTSxNQUFNO0VBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0dBQ3BDLE1BQU0sT0FBTyxJQUFJO0dBQ2pCLElBQUksQ0FBQyxNQUFNO0dBQ1gsTUFBTSxJQUFJLE9BQU8sU0FBUyxXQUFXLE9BQU8sYUFBYSxNQUFNLFFBQVE7R0FDdkUsSUFBSSxHQUFHO0lBQ04sSUFBSSxLQUFLLE9BQU87SUFDaEIsT0FBTztHQUNSO0VBQ0Q7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxJQUFJLFVBQVU7RUFDYixJQUFJLE9BQU8sTUFBTSxVQUFVLE9BQU8sS0FBSztFQUN2QyxJQUFJLE9BQU8sTUFBTSxVQUNYO1FBQUEsTUFBTSxLQUFLLEdBQUcsSUFBSSxFQUFFLElBQUk7SUFDNUIsSUFBSSxLQUFLLE9BQU87SUFDaEIsT0FBTztHQUNSOztDQUVGO0NBQ0EsT0FBTztBQUNSO0FBQ0EsSUFBTSxZQUFZLE1BQU0sYUFBYTtDQUNwQyxJQUFJLElBQUk7Q0FDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7RUFDckMsTUFBTSxJQUFJLEtBQUs7RUFDZixJQUFJLENBQUMsR0FBRztFQUNSLE1BQU0sSUFBSSxPQUFPLE1BQU0sV0FBVyxJQUFJLGFBQWEsR0FBRyxRQUFRO0VBQzlELElBQUksR0FBRztHQUNOLElBQUksR0FBRyxLQUFLO0dBQ1osS0FBSztFQUNOO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7O0FBRUEsSUFBTSxTQUFTLFdBQVc7Q0FDekIsT0FBTyxTQUFTLFdBQVcsS0FBSztBQUNqQzs7QUFFQSxJQUFNLE9BQU8sV0FBVztDQUN2QixPQUFPLFNBQVMsV0FBVyxJQUFJO0FBQ2hDO0FBQ0EsSUFBTSxhQUFhO0FBQ25CLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sY0FBYztBQUNwQixJQUFNLGFBQWE7QUFDbkIsSUFBTSxZQUFZLGFBQWEsVUFBVTtDQUN4QyxNQUFNLGFBQWEsVUFBVSxLQUFLLFVBQVUsT0FBTyxNQUFNO0NBQ3pELE1BQU0sZ0JBQWdCLFVBQVUsS0FBSyxJQUFJLGNBQWMsTUFBTTtDQUM3RCxJQUFJLDJCQUEyQixJQUFJLElBQUk7Q0FDdkMsSUFBSSwrQkFBK0IsSUFBSSxJQUFJO0NBQzNDLElBQUksV0FBVztDQUNmLElBQUksVUFBVTtDQUNkLElBQUksV0FBVztDQUNmLElBQUksV0FBVyxDQUFDO0NBQ2hCLElBQUksV0FBVyxDQUFDO0NBQ2hCLElBQUksWUFBWTtDQUNoQixNQUFNLGVBQWUsS0FBSyxLQUFLLFNBQVM7RUFDdkMsSUFBSSxhQUFhLE1BQU07R0FDdEIsV0FBVyxJQUFJLE1BQU0sVUFBVSxDQUFDLENBQUMsS0FBSyxFQUFFO0dBQ3hDLFdBQVcsSUFBSSxNQUFNLFVBQVUsQ0FBQyxDQUFDLEtBQUssRUFBRTtHQUN4QyxXQUFXLElBQUksTUFBTSxVQUFVLENBQUMsQ0FBQyxLQUFLLEVBQUU7RUFDekM7RUFDQSxNQUFNLE9BQU8sU0FBUyxLQUFLLEdBQUcsSUFBSSxNQUFNLElBQUk7RUFDNUMsSUFBSSxTQUFTLFVBQVUsT0FBTyxTQUFTLFVBQVUsS0FBSyxPQUFPLFNBQVM7RUFDdEUsSUFBSSxTQUFTLE9BQU8sT0FBTyxPQUFPLFNBQVMsT0FBTyxPQUFPLEtBQUssT0FBTyxTQUFTLE9BQU87RUFDckYsTUFBTSxTQUFTLFlBQVksT0FBTyxNQUFNLE1BQU0sTUFBTSxHQUFHO0VBQ3ZELE1BQU0sT0FBTyxTQUFTLFVBQVUsS0FBSyxPQUFPLFFBQVEsU0FBUyxPQUFPLE9BQU8sS0FBSyxJQUFJLGNBQWM7RUFDbEcsU0FBUyxRQUFRO0VBQ2pCLFNBQVMsUUFBUTtFQUNqQixTQUFTLFFBQVE7RUFDakIsT0FBTztDQUNSO0NBQ0EsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUFJLE9BQU87RUFDakMsSUFBSSxJQUFJO0VBQ1IsSUFBSSxJQUFJO0dBQ1AsSUFBSSxPQUFPLEVBQUUsSUFBSSxPQUFPO0dBQ3hCLElBQUk7RUFDTDtFQUNBLElBQUksSUFBSTtHQUNQLElBQUksUUFBUSxNQUFNLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxPQUFPO0dBQzNDO0VBQ0Q7RUFDQSxJQUFJLElBQUk7R0FDUCxJQUFJLFFBQVEsTUFBTSxJQUFJLEVBQUUsS0FBSyxNQUFNLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxPQUFPO0dBQzVEO0VBQ0Q7RUFDQSxPQUFPLE1BQU0sRUFBRTtDQUNoQjtDQUNBLE1BQU0sVUFBVSxHQUFHLFNBQVM7RUFDM0IsTUFBTSxLQUFLLEVBQUU7RUFDYixJQUFJLElBQUk7RUFDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7R0FDckMsTUFBTSxJQUFJLEtBQUs7R0FDZixJQUFJLENBQUMsR0FBRztHQUNSLElBQUksTUFBTSxHQUFHLElBQUksT0FBTztHQUN4QjtFQUNEO0VBQ0EsT0FBTyxNQUFNLEVBQUU7Q0FDaEI7Q0FDQSxNQUFNLGVBQWUsTUFBTSxXQUFXO0VBQ3JDLE1BQU0sUUFBUSxLQUFLO0VBQ25CLE1BQU0sT0FBTyxZQUFZLE9BQU8sT0FBTyxRQUFRO0VBQy9DLElBQUksQ0FBQyxRQUFRO0dBQ1osSUFBSSxTQUFTLFFBQVEsT0FBTyxNQUFNLElBQUksR0FBRztJQUN4QyxVQUFVO0lBQ1YsT0FBTyxLQUFLO0dBQ2I7R0FDQSxJQUFJLFlBQVksUUFBUSxZQUFZLFFBQVEsT0FBTyxTQUFTLElBQUksR0FBRyxPQUFPLFFBQVE7RUFDbkY7RUFDQSxJQUFJLFFBQVE7RUFDWixJQUFJLFdBQVc7RUFDZixJQUFJLFNBQVM7RUFDYixJQUFJLG1CQUFtQjtFQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0dBQy9CLElBQUksSUFBSSxLQUFLO0dBQ2IsSUFBSSxDQUFDLEdBQUc7R0FDUixJQUFJLE9BQU8sTUFBTSxVQUFVO0lBQzFCLElBQUksS0FBSyxLQUFLLGFBQWEsR0FBRyxJQUFJO0lBQ2xDLElBQUksQ0FBQyxHQUFHO0lBQ1IsbUJBQW1CO0dBQ3BCO0dBQ0EsSUFBSSxXQUFXLEdBQUc7SUFDakIsUUFBUTtJQUNSLFdBQVc7R0FDWjtHQUNBO0VBQ0Q7RUFDQSxJQUFJLFdBQVcsR0FBRyxPQUFPO0VBQ3pCLElBQUksV0FBVyxHQUFHLE9BQU8sWUFBWSxLQUFLO0VBQzFDLElBQUksa0JBQWtCO0dBQ3JCLElBQUksU0FBUyxRQUFRLE9BQU8sTUFBTSxJQUFJLEdBQUc7SUFDeEMsVUFBVTtJQUNWLE9BQU8sS0FBSztHQUNiO0dBQ0EsSUFBSSxZQUFZLFFBQVEsWUFBWSxRQUFRLE9BQU8sU0FBUyxJQUFJLEdBQUcsT0FBTyxRQUFRO0VBQ25GO0VBQ0EsSUFBSSxTQUFTLFNBQVMsSUFBSSxLQUFLO0VBQy9CLElBQUksV0FBVyxLQUFLLEdBQUc7R0FDdEIsU0FBUyxhQUFhLElBQUksS0FBSztHQUMvQixJQUFJLFdBQVcsS0FBSyxHQUFHLFNBQVMsSUFBSSxPQUFPLE1BQU07RUFDbEQ7RUFDQSxJQUFJLE1BQU07RUFDVixJQUFJLFdBQVcsS0FBSyxHQUFHO0dBQ3RCLElBQUksT0FBTyxPQUFPLEdBQUc7SUFDcEIsT0FBTztJQUNQLFVBQVU7SUFDVixJQUFJLFNBQVM7SUFDYixLQUFLLElBQUksSUFBSSxXQUFXLEdBQUcsSUFBSSxPQUFPLEtBQUs7S0FDMUMsTUFBTSxJQUFJLEtBQUs7S0FDZixJQUFJLEdBQUcsVUFBVSxNQUFNO0lBQ3hCO0lBQ0EsT0FBTyxZQUFZLFFBQVEsSUFBSSxLQUFLO0dBQ3JDO0dBQ0EsTUFBTSxVQUFVLE9BQU87R0FDdkIsT0FBTyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7SUFDL0MsTUFBTSxJQUFJLFFBQVE7SUFDbEIsSUFBSSxFQUFFLE1BQU0sUUFBUTtJQUNwQixNQUFNLEtBQUssRUFBRTtJQUNiLElBQUksSUFBSTtJQUNSLEtBQUssSUFBSSxJQUFJLFdBQVcsR0FBRyxJQUFJLE9BQU8sS0FBSztLQUMxQyxNQUFNLElBQUksS0FBSztLQUNmLElBQUksS0FBSyxNQUFNLEdBQUcsTUFBTSxTQUFTO0lBQ2xDO0lBQ0EsTUFBTTtJQUNOO0dBQ0Q7R0FDQSxJQUFJLFFBQVEsTUFBTSxPQUFPLE9BQU87RUFDakM7RUFDQSxJQUFJLFFBQVEsTUFBTTtHQUNqQixJQUFJLFNBQVM7R0FDYixNQUFNLElBQUksQ0FBQyxLQUFLO0dBQ2hCLEtBQUssSUFBSSxJQUFJLFdBQVcsR0FBRyxJQUFJLE9BQU8sS0FBSztJQUMxQyxNQUFNLElBQUksS0FBSztJQUNmLElBQUksQ0FBQyxHQUFHO0lBQ1IsVUFBVSxNQUFNO0lBQ2hCLEVBQUUsS0FBSyxDQUFDO0dBQ1Q7R0FDQSxJQUFJLENBQUMsV0FBVyxNQUFNLEdBQUcsT0FBTyxjQUFjLE1BQU07R0FDcEQsTUFBTTtJQUNMLEdBQUcsWUFBWSxNQUFNO0lBQ3JCLEdBQUcsRUFBRTtJQUNMLElBQUksRUFBRTtJQUNOLElBQUksRUFBRTtJQUNOLElBQUksRUFBRSxNQUFNO0lBQ1o7SUFDQSxHQUFHO0dBQ0o7R0FDQSxJQUFJLFdBQVcsS0FBSyxHQUFHLFNBQVMsSUFBSSxPQUFPLFNBQVM7SUFDbkQsR0FBRyxDQUFDO0lBQ0osTUFBTTtJQUNOLE1BQU07SUFDTixJQUFJO0dBQ0wsQ0FBQztRQUNJLElBQUksRUFBRSxPQUFPLE9BQU8saUJBQWlCO0lBQ3pDLE9BQU8sT0FBTztJQUNkLE9BQU8sT0FBTztJQUNkLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLE9BQU8sS0FBSztHQUNiO0dBQ0EsTUFBTSxVQUFVLE9BQU87R0FDdkIsSUFBSSxRQUFRLFNBQVMsWUFBWSxRQUFRLEtBQUssR0FBRztRQUM1QztJQUNKLFFBQVEsT0FBTyxNQUFNO0lBQ3JCLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFBSTtHQUM3QjtHQUNBLElBQUksRUFBRSxXQUFXLEtBQUs7SUFDckIsV0FBVztJQUNYLGVBQWU7SUFDZiwyQkFBMkIsSUFBSSxJQUFJO0dBQ3BDO0VBQ0Q7RUFDQSxJQUFJLFlBQVksUUFBUSxZQUFZLEtBQUssUUFBUSxJQUFJO0VBQ3JELFVBQVU7RUFDVixPQUFPLElBQUk7Q0FDWjtDQUNBLE1BQU0sb0JBQW9CLFVBQVUsTUFBTSxRQUFRLEtBQUssSUFBSSxZQUFZLE1BQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxZQUFZLGFBQWEsT0FBTyxJQUFJLENBQUM7Q0FDcEksT0FBTyxTQUFTLElBQUksSUFBSSxJQUFJO0VBQzNCLE1BQU0sUUFBUSxVQUFVO0VBQ3hCLEtBQUssUUFBUSxPQUFPLEdBQUc7R0FDdEIsTUFBTSxLQUFLO0dBQ1gsSUFBSSxPQUFPLE1BQU07SUFDaEIsTUFBTSxPQUFPLEdBQUc7SUFDaEIsSUFBSSxTQUFTLFFBQVEsT0FBTyxNQUFNLElBQUksSUFBSSxFQUFFLEdBQUc7S0FDOUMsVUFBVTtLQUNWLE9BQU8sS0FBSztJQUNiO0lBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTyxJQUFJLElBQUksSUFBSSxFQUFFLEdBQUcsT0FBTyxHQUFHO0dBQ3REO0dBQ0EsSUFBSSxVQUFVLEtBQUssT0FBTyxPQUFPLFlBQVksT0FBTyxJQUFJO0lBQ3ZELE1BQU0sU0FBUyxTQUFTLElBQUksRUFBRTtJQUM5QixJQUFJLFdBQVcsS0FBSyxLQUFLLE9BQU8sT0FBTyxHQUFHO0tBQ3pDLE9BQU87S0FDUCxVQUFVO0tBQ1YsT0FBTyxZQUFZLElBQUksSUFBSSxJQUFJO0lBQ2hDO0dBQ0Q7R0FDQSxPQUFPLFlBQVk7SUFDbEI7SUFDQTtJQUNBO0dBQ0QsR0FBRyxJQUFJO0VBQ1I7RUFDQSxJQUFJLFVBQVUsR0FBRyxPQUFPLE9BQU8sT0FBTyxXQUFXLFlBQVksRUFBRSxJQUFJLGlCQUFpQixFQUFFO0VBQ3RGLE1BQU0sS0FBSztFQUNYLElBQUksT0FBTyxNQUFNO0dBQ2hCLE1BQU0sT0FBTyxHQUFHO0dBQ2hCLElBQUksU0FBUyxNQUFNO0lBQ2xCLE1BQU0sS0FBSyxLQUFLO0lBQ2hCLElBQUksSUFBSTtJQUNSLElBQUksS0FBSztJQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLEtBQUs7S0FDL0IsTUFBTSxJQUFJLFVBQVU7S0FDcEIsSUFBSSxDQUFDLEdBQUc7S0FDUixJQUFJLE1BQU0sR0FBRyxJQUFJO01BQ2hCLEtBQUs7TUFDTDtLQUNEO0tBQ0E7SUFDRDtJQUNBLElBQUksTUFBTSxNQUFNLEtBQUssR0FBRztLQUN2QixVQUFVO0tBQ1YsT0FBTyxLQUFLO0lBQ2I7R0FDRDtHQUNBLElBQUksT0FBTyxNQUFNO0lBQ2hCLE1BQU0sS0FBSyxHQUFHO0lBQ2QsSUFBSSxJQUFJO0lBQ1IsSUFBSSxLQUFLO0lBQ1QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztLQUMvQixNQUFNLElBQUksVUFBVTtLQUNwQixJQUFJLENBQUMsR0FBRztLQUNSLElBQUksTUFBTSxHQUFHLElBQUk7TUFDaEIsS0FBSztNQUNMO0tBQ0Q7S0FDQTtJQUNEO0lBQ0EsSUFBSSxNQUFNLE1BQU0sR0FBRyxHQUFHLE9BQU8sR0FBRztHQUNqQztFQUNEO0VBQ0EsTUFBTSxPQUFPLENBQUM7RUFDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLLEtBQUssS0FBSyxVQUFVLEVBQUU7RUFDdEQsT0FBTyxZQUFZLE1BQU0sSUFBSTtDQUM5QjtBQUNEOztBQ2xnQ0EsSUFBTSxXQUEyQiw2QkFBYSx3QkFBd0I7Ozs7O0FBS3RFLElBQU0sS0FBcUIseUJBQVMsU0FBUyxhQUFhLFFBQVE7O0FBRWxFLElBQU0sVUFBVSxTQUFTIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyXX0=