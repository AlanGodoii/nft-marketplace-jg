import { n as __exportAll } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=22c23eb4";
// node_modules/axios/lib/helpers/bind.js
/**
* Create a bound version of a function with a specified `this` context
*
* @param {Function} fn - The function to bind
* @param {*} thisArg - The value to be passed as the `this` parameter
* @returns {Function} A new function that will call the original function with the specified `this` context
*/
function bind(fn, thisArg) {
	return function wrap() {
		return fn.apply(thisArg, arguments);
	};
}
// node_modules/axios/lib/utils.js
var { toString } = Object.prototype;
var { getPrototypeOf } = Object;
var { iterator, toStringTag } = Symbol;
var hasOwnProperty = (({ hasOwnProperty }) => (obj, prop) => hasOwnProperty.call(obj, prop))(Object.prototype);
var isUnsafeObjectKey = (prop) => typeof prop === "string" && (prop === "__proto__" || prop === "constructor" || prop === "prototype");
/**
* Determine whether an inherited object must be treated as a shared-prototype
* boundary. Cross-realm Object.prototype objects cannot be distinguished
* reliably from application-created null-prototype objects because their
* properties are mutable, so all inherited terminal prototypes are excluded
* as a fail-closed boundary. A null-prototype source still keeps its own
* properties, as produced by mergeConfig and other safe materialization paths.
*
* @param {*} obj The object to inspect
* @param {*} prototype The object's prototype
* @param {boolean} source Whether obj is the original traversal source
*
* @returns {boolean} True when obj is a safe prototype traversal boundary
*/
var isPrototypeBoundary = (obj, prototype, source) => obj === Object.prototype || !source && prototype === null;
/**
* Determine whether an object can retain its identity through code paths that
* add, replace, and remove config properties without bypassing unsafe-key
* filtering. Immutable objects, unsafe-key-bearing objects, and objects with
* accessor or restricted data properties must be materialized instead.
*
* @param {*} obj The object to inspect
*
* @returns {boolean} True when every own property is safe and fully mutable
*/
var isSafeAndFullyMutable = (obj) => {
	if (!Object.isExtensible(obj)) return false;
	const props = Object.getOwnPropertyNames(obj);
	if (Object.getOwnPropertySymbols) props.push(...Object.getOwnPropertySymbols(obj));
	return props.every((prop) => {
		if (isUnsafeObjectKey(prop)) return false;
		const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
		return !!descriptor && descriptor.configurable && descriptor.writable === true;
	});
};
/**
* Walk the prototype chain (excluding the source realm's Object.prototype)
* looking for an own `prop`. This distinguishes genuine own/inherited members
* — including class accessors and template prototypes — from members injected
* via Object.prototype pollution (e.g. `Object.prototype.username = '...'`),
* which live on Object.prototype itself and are therefore never matched.
*
* @param {*} thing The value whose chain to inspect
* @param {string|symbol} prop The property key to look for
*
* @returns {boolean} True when `prop` is owned below Object.prototype
*/
var hasOwnInPrototypeChain = (thing, prop) => {
	let obj = thing;
	const seen = [];
	while (obj != null) {
		if (seen.indexOf(obj) !== -1) return false;
		seen.push(obj);
		const prototype = getPrototypeOf(obj);
		if (isPrototypeBoundary(obj, prototype, obj === thing)) return false;
		if (hasOwnProperty(obj, prop)) return true;
		obj = prototype;
	}
	return false;
};
/**
* Read `obj[prop]` only when it is safe from Object.prototype pollution. Own
* properties and members inherited from a non-Object.prototype source (a class
* instance or template object) are honored; a value reachable only through a
* polluted Object.prototype is ignored and `undefined` is returned.
*
* @param {*} obj The source object
* @param {string|symbol} prop The property key to read
*
* @returns {*} The resolved value, or undefined when unsafe/absent
*/
var getSafeProp = (obj, prop) => obj != null && hasOwnInPrototypeChain(obj, prop) ? obj[prop] : void 0;
/**
* Flatten an object and its application-defined prototype chain into a
* null-prototype object. Members inherited only from the source realm's
* Object.prototype are deliberately excluded, while class/template members
* below that boundary are preserved.
*
* @param {*} thing The value to flatten
*
* @returns {*} A null-prototype copy, or the original value when it is already
* structurally safe or is not an object
*/
var toSafeFlatObject = (thing) => {
	if (thing == null || typeof thing !== "object" && typeof thing !== "function") return thing;
	const sourcePrototype = getPrototypeOf(thing);
	if (sourcePrototype === null && isSafeAndFullyMutable(thing)) return thing;
	const result = Object.create(null);
	const merged = Object.create(null);
	const seen = [];
	let current = thing;
	while (current != null) {
		if (seen.indexOf(current) !== -1) break;
		seen.push(current);
		const prototype = current === thing ? sourcePrototype : getPrototypeOf(current);
		if (isPrototypeBoundary(current, prototype, current === thing)) break;
		const props = Object.getOwnPropertyNames(current);
		if (Object.getOwnPropertySymbols) props.push(...Object.getOwnPropertySymbols(current));
		for (const prop of props) {
			if (isUnsafeObjectKey(prop)) continue;
			if (!hasOwnProperty(merged, prop)) {
				result[prop] = thing[prop];
				merged[prop] = true;
			}
		}
		current = prototype;
	}
	return result;
};
var kindOf = ((cache) => (thing) => {
	const str = toString.call(thing);
	return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
})(Object.create(null));
var kindOfTest = (type) => {
	type = type.toLowerCase();
	return (thing) => kindOf(thing) === type;
};
var typeOfTest = (type) => (thing) => typeof thing === type;
/**
* Determine if a value is a non-null object
*
* @param {Object} val The value to test
*
* @returns {boolean} True if value is an Array, otherwise false
*/
var { isArray } = Array;
/**
* Determine if a value is undefined
*
* @param {*} val The value to test
*
* @returns {boolean} True if the value is undefined, otherwise false
*/
var isUndefined = typeOfTest("undefined");
/**
* Determine if a value is a Buffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Buffer, otherwise false
*/
function isBuffer(val) {
	return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction$1(val.constructor.isBuffer) && val.constructor.isBuffer(val);
}
/**
* Determine if a value is an ArrayBuffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is an ArrayBuffer, otherwise false
*/
var isArrayBuffer = kindOfTest("ArrayBuffer");
/**
* Determine if a value is a view on an ArrayBuffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
*/
function isArrayBufferView(val) {
	let result;
	if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) result = ArrayBuffer.isView(val);
	else result = val && val.buffer && isArrayBuffer(val.buffer);
	return result;
}
/**
* Determine if a value is a String
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a String, otherwise false
*/
var isString = typeOfTest("string");
/**
* Determine if a value is a Function
*
* @param {*} val The value to test
* @returns {boolean} True if value is a Function, otherwise false
*/
var isFunction$1 = typeOfTest("function");
/**
* Determine if a value is a Number
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Number, otherwise false
*/
var isNumber = typeOfTest("number");
/**
* Determine if a value is an Object
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value is an Object, otherwise false
*/
var isObject = (thing) => thing !== null && typeof thing === "object";
/**
* Determine if a value is a Boolean
*
* @param {*} thing The value to test
* @returns {boolean} True if value is a Boolean, otherwise false
*/
var isBoolean = (thing) => thing === true || thing === false;
/**
* Determine if a value is a plain Object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a plain Object, otherwise false
*/
var isPlainObject = (val) => {
	if (!isObject(val)) return false;
	const prototype = getPrototypeOf(val);
	return (prototype === null || prototype === Object.prototype || getPrototypeOf(prototype) === null) && (isPrototypeBoundary(val, prototype, true) || !hasOwnProperty(val, toStringTag) && !hasOwnProperty(val, iterator));
};
/**
* Determine if a value is an empty object (safely handles Buffers)
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is an empty object, otherwise false
*/
var isEmptyObject = (val) => {
	if (!isObject(val) || isBuffer(val)) return false;
	try {
		return Object.keys(val).length === 0 && Object.getPrototypeOf(val) === Object.prototype;
	} catch (e) {
		return false;
	}
};
/**
* Determine if a value is a Date
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Date, otherwise false
*/
var isDate = kindOfTest("Date");
/**
* Determine if a value is a File
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a File, otherwise false
*/
var isFile = kindOfTest("File");
/**
* Determine if a value is a React Native Blob
* React Native "blob": an object with a `uri` attribute. Optionally, it can
* also have a `name` and `type` attribute to specify filename and content type
*
* @see https://github.com/facebook/react-native/blob/26684cf3adf4094eb6c405d345a75bf8c7c0bf88/Libraries/Network/FormData.js#L68-L71
*
* @param {*} value The value to test
*
* @returns {boolean} True if value is a React Native Blob, otherwise false
*/
var isReactNativeBlob = (value) => {
	return !!(value && typeof value.uri !== "undefined");
};
/**
* Determine if environment is React Native
* ReactNative `FormData` has a non-standard `getParts()` method
*
* @param {*} formData The formData to test
*
* @returns {boolean} True if environment is React Native, otherwise false
*/
var isReactNative = (formData) => formData && typeof formData.getParts !== "undefined";
/**
* Determine if a value is a Blob
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Blob, otherwise false
*/
var isBlob = kindOfTest("Blob");
/**
* Determine if a value is a FileList
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a FileList, otherwise false
*/
var isFileList = kindOfTest("FileList");
var isSet = kindOfTest("Set");
/**
* Determine if a value is a Stream
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Stream, otherwise false
*/
var isStream = (val) => isObject(val) && isFunction$1(val.pipe);
/**
* Determine if a value is a FormData
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value is an FormData, otherwise false
*/
function getGlobal() {
	if (typeof globalThis !== "undefined") return globalThis;
	if (typeof self !== "undefined") return self;
	if (typeof window !== "undefined") return window;
	if (typeof global !== "undefined") return global;
	return {};
}
var G = getGlobal();
var FormDataCtor = typeof G.FormData !== "undefined" ? G.FormData : void 0;
var isFormData = (thing) => {
	if (!thing) return false;
	if (FormDataCtor && thing instanceof FormDataCtor) return true;
	const proto = getPrototypeOf(thing);
	if (!proto || proto === Object.prototype) return false;
	if (!isFunction$1(thing.append)) return false;
	const kind = kindOf(thing);
	return kind === "formdata" || kind === "object" && isFunction$1(thing.toString) && thing.toString() === "[object FormData]";
};
/**
* Determine if a value is a URLSearchParams object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a URLSearchParams object, otherwise false
*/
var isURLSearchParams = kindOfTest("URLSearchParams");
var [isReadableStream, isRequest, isResponse, isHeaders] = [
	"ReadableStream",
	"Request",
	"Response",
	"Headers"
].map(kindOfTest);
/**
* Trim excess whitespace off the beginning and end of a string
*
* @param {String} str The String to trim
*
* @returns {String} The String freed of excess whitespace
*/
var trim = (str) => {
	return str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
};
/**
* Iterate over an Array or an Object invoking a function for each item.
*
* If `obj` is an Array callback will be called passing
* the value, index, and complete array for each item.
*
* If 'obj' is an Object callback will be called passing
* the value, key, and complete object for each property.
*
* @param {Object|Array<unknown>} obj The object to iterate
* @param {Function} fn The callback to invoke for each item
*
* @param {Object} [options]
* @param {Boolean} [options.allOwnKeys = false]
* @returns {any}
*/
function forEach(obj, fn, { allOwnKeys = false } = {}) {
	if (obj === null || typeof obj === "undefined") return;
	let i;
	let l;
	if (typeof obj !== "object") obj = [obj];
	if (isArray(obj)) for (i = 0, l = obj.length; i < l; i++) fn.call(null, obj[i], i, obj);
	else {
		if (isBuffer(obj)) return;
		const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
		const len = keys.length;
		let key;
		for (i = 0; i < len; i++) {
			key = keys[i];
			fn.call(null, obj[key], key, obj);
		}
	}
}
/**
* Finds a key in an object, case-insensitive, returning the actual key name.
* Returns null if the object is a Buffer or if no match is found.
*
* @param {Object} obj - The object to search.
* @param {string} key - The key to find (case-insensitive).
* @returns {?string} The actual key name if found, otherwise null.
*/
function findKey(obj, key) {
	if (isBuffer(obj)) return null;
	key = key.toLowerCase();
	const keys = Object.keys(obj);
	let i = keys.length;
	let _key;
	while (i-- > 0) {
		_key = keys[i];
		if (key === _key.toLowerCase()) return _key;
	}
	return null;
}
var _global = (() => {
	if (typeof globalThis !== "undefined") return globalThis;
	return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
})();
var isContextDefined = (context) => !isUndefined(context) && context !== _global;
/**
* Accepts varargs expecting each argument to be an object, then
* immutably merges the properties of each object and returns result.
*
* When multiple objects contain the same key the later object in
* the arguments list will take precedence.
*
* Example:
*
* ```js
* const result = merge({foo: 123}, {foo: 456});
* console.log(result.foo); // outputs 456
* ```
*
* @param {Object} obj1 Object to merge
*
* @returns {Object} Result of all merge properties
*/
function merge(...objs) {
	const { caseless, skipUndefined } = isContextDefined(this) && this || {};
	const result = {};
	const lowerCaseKeys = caseless ? Object.create(null) : null;
	const assignValue = (val, key) => {
		if (key === "__proto__" || key === "constructor" || key === "prototype") return;
		let targetKey = key;
		if (lowerCaseKeys && typeof key === "string") {
			const lowerKey = key.toLowerCase();
			const knownKey = lowerCaseKeys[lowerKey];
			if (knownKey !== void 0 && hasOwnProperty(result, knownKey)) targetKey = knownKey;
			else lowerCaseKeys[lowerKey] = key;
		}
		const existing = hasOwnProperty(result, targetKey) ? result[targetKey] : void 0;
		if (isPlainObject(existing) && isPlainObject(val)) result[targetKey] = merge(existing, val);
		else if (isPlainObject(val)) result[targetKey] = merge({}, val);
		else if (isArray(val)) result[targetKey] = val.slice();
		else if (!skipUndefined || !isUndefined(val)) result[targetKey] = val;
	};
	for (let i = 0, l = objs.length; i < l; i++) {
		const source = objs[i];
		if (!source || isBuffer(source)) continue;
		forEach(source, assignValue);
		if (typeof source !== "object" || isArray(source) || !Object.getOwnPropertySymbols) continue;
		const symbols = Object.getOwnPropertySymbols(source);
		for (let j = 0; j < symbols.length; j++) {
			const symbol = symbols[j];
			if (propertyIsEnumerable.call(source, symbol)) assignValue(source[symbol], symbol);
		}
	}
	return result;
}
/**
* Extends object a by mutably adding to it the properties of object b.
*
* @param {Object} a The object to be extended
* @param {Object} b The object to copy properties from
* @param {Object} thisArg The object to bind function to
*
* @param {Object} [options]
* @param {Boolean} [options.allOwnKeys]
* @returns {Object} The resulting value of object a
*/
var extend = (a, b, thisArg, { allOwnKeys } = {}) => {
	forEach(b, (val, key) => {
		if (thisArg && isFunction$1(val)) Object.defineProperty(a, key, {
			__proto__: null,
			value: bind(val, thisArg),
			writable: true,
			enumerable: true,
			configurable: true
		});
		else Object.defineProperty(a, key, {
			__proto__: null,
			value: val,
			writable: true,
			enumerable: true,
			configurable: true
		});
	}, { allOwnKeys });
	return a;
};
/**
* Remove byte order marker. This catches EF BB BF (the UTF-8 BOM)
*
* @param {string} content with BOM
*
* @returns {string} content value without BOM
*/
var stripBOM = (content) => {
	if (content.charCodeAt(0) === 65279) content = content.slice(1);
	return content;
};
/**
* Inherit the prototype methods from one constructor into another
* @param {function} constructor
* @param {function} superConstructor
* @param {object} [props]
* @param {object} [descriptors]
*
* @returns {void}
*/
var inherits = (constructor, superConstructor, props, descriptors) => {
	constructor.prototype = Object.create(superConstructor.prototype, descriptors);
	Object.defineProperty(constructor.prototype, "constructor", {
		__proto__: null,
		value: constructor,
		writable: true,
		enumerable: false,
		configurable: true
	});
	Object.defineProperty(constructor, "super", {
		__proto__: null,
		value: superConstructor.prototype
	});
	props && Object.assign(constructor.prototype, props);
};
/**
* Resolve object with deep prototype chain to a flat object
* @param {Object} sourceObj source object
* @param {Object} [destObj]
* @param {Function|Boolean} [filter]
* @param {Function} [propFilter]
*
* @returns {Object}
*/
var toFlatObject = (sourceObj, destObj, filter, propFilter) => {
	let props;
	let i;
	let prop;
	const merged = {};
	destObj = destObj || {};
	if (sourceObj == null) return destObj;
	do {
		props = Object.getOwnPropertyNames(sourceObj);
		i = props.length;
		while (i-- > 0) {
			prop = props[i];
			if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
				destObj[prop] = sourceObj[prop];
				merged[prop] = true;
			}
		}
		sourceObj = filter !== false && getPrototypeOf(sourceObj);
	} while (sourceObj && (!filter || filter(sourceObj, destObj)) && sourceObj !== Object.prototype);
	return destObj;
};
/**
* Determines whether a string ends with the characters of a specified string
*
* @param {String} str
* @param {String} searchString
* @param {Number} [position= 0]
*
* @returns {boolean}
*/
var endsWith = (str, searchString, position) => {
	str = String(str);
	if (position === void 0 || position > str.length) position = str.length;
	position -= searchString.length;
	const lastIndex = str.indexOf(searchString, position);
	return lastIndex !== -1 && lastIndex === position;
};
/**
* Returns new array from array like object or null if failed
*
* @param {*} [thing]
*
* @returns {?Array}
*/
var toArray = (thing) => {
	if (!thing) return null;
	if (isArray(thing)) return thing;
	let i = thing.length;
	if (!Number.isSafeInteger(i) || i < 0 || i > 4294967295) return null;
	const indexes = /* @__PURE__ */ new Set();
	const seen = /* @__PURE__ */ new Set();
	let source = thing;
	while (source != null && indexes.size < i) {
		if (seen.has(source)) return null;
		seen.add(source);
		const prototype = getPrototypeOf(source);
		if (isPrototypeBoundary(source, prototype, source === thing)) break;
		Object.getOwnPropertyNames(source).forEach((key) => {
			const index = +key;
			if (Number.isInteger(index) && index >= 0 && index < i && String(index) === key && hasOwnProperty(source, key)) indexes.add(index);
		});
		source = prototype;
	}
	if (indexes.size !== i) return null;
	const arr = new Array(i);
	while (i-- > 0) arr[i] = thing[i];
	return arr;
};
/**
* Checking if the Uint8Array exists and if it does, it returns a function that checks if the
* thing passed in is an instance of Uint8Array
*
* @param {TypedArray}
*
* @returns {Array}
*/
var isTypedArray = ((TypedArray) => {
	return (thing) => {
		return TypedArray && thing instanceof TypedArray;
	};
})(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
/**
* For each entry in the object, call the function with the key and value.
*
* @param {Object<any, any>} obj - The object to iterate over.
* @param {Function} fn - The function to call for each entry.
*
* @returns {void}
*/
var forEachEntry = (obj, fn) => {
	const _iterator = (obj && obj[iterator]).call(obj);
	let result;
	while ((result = _iterator.next()) && !result.done) {
		const pair = result.value;
		fn.call(obj, pair[0], pair[1]);
	}
};
/**
* It takes a regular expression and a string, and returns an array of all the matches
*
* @param {string} regExp - The regular expression to match against.
* @param {string} str - The string to search.
*
* @returns {Array<boolean>}
*/
var matchAll = (regExp, str) => {
	let matches;
	const arr = [];
	while ((matches = regExp.exec(str)) !== null) arr.push(matches);
	return arr;
};
var isHTMLForm = kindOfTest("HTMLFormElement");
var toCamelCase = (str) => {
	return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m, p1, p2) {
		return p1.toUpperCase() + p2;
	});
};
var { propertyIsEnumerable } = Object.prototype;
/**
* Determine if a value is a RegExp object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a RegExp object, otherwise false
*/
var isRegExp = kindOfTest("RegExp");
var reduceDescriptors = (obj, reducer) => {
	const descriptors = Object.getOwnPropertyDescriptors(obj);
	const reducedDescriptors = {};
	forEach(descriptors, (descriptor, name) => {
		let ret;
		if ((ret = reducer(descriptor, name, obj)) !== false) reducedDescriptors[name] = ret || descriptor;
	});
	Object.defineProperties(obj, reducedDescriptors);
};
/**
* Makes all methods read-only
* @param {Object} obj
*/
var freezeMethods = (obj) => {
	reduceDescriptors(obj, (descriptor, name) => {
		if (isFunction$1(obj) && [
			"arguments",
			"caller",
			"callee"
		].includes(name)) return false;
		const value = obj[name];
		if (!isFunction$1(value)) return;
		descriptor.enumerable = false;
		if ("writable" in descriptor) {
			descriptor.writable = false;
			return;
		}
		if (!descriptor.set) descriptor.set = () => {
			throw Error("Can not rewrite read-only method '" + name + "'");
		};
	});
};
/**
* Converts an array or a delimited string into an object set with values as keys and true as values.
* Useful for fast membership checks.
*
* @param {Array|string} arrayOrString - The array or string to convert.
* @param {string} delimiter - The delimiter to use if input is a string.
* @returns {Object} An object with keys from the array or string, values set to true.
*/
var toObjectSet = (arrayOrString, delimiter) => {
	const obj = {};
	const define = (arr) => {
		arr.forEach((value) => {
			obj[value] = true;
		});
	};
	isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
	return obj;
};
var noop = () => {};
var toFiniteNumber = (value, defaultValue) => {
	return value != null && Number.isFinite(value = +value) ? value : defaultValue;
};
/**
* If the thing is a FormData object, return true, otherwise return false.
*
* @param {unknown} thing - The thing to check.
*
* @returns {boolean}
*/
function isSpecCompliantForm(thing) {
	return !!(thing && isFunction$1(thing.append) && thing[toStringTag] === "FormData" && thing[iterator]);
}
/**
* Recursively converts an object to a JSON-compatible object, handling circular references and Buffers.
*
* @param {Object} obj - The object to convert.
* @returns {Object} The JSON-compatible object.
*/
var toJSONObject = (obj) => {
	const visited = /* @__PURE__ */ new WeakSet();
	const visit = (source) => {
		if (isObject(source)) {
			if (visited.has(source)) return;
			if (isBuffer(source)) return source;
			if (!("toJSON" in source)) {
				visited.add(source);
				let target;
				if (isSet(source)) {
					target = [];
					for (const value of source) {
						const reducedValue = visit(value);
						!isUndefined(reducedValue) && target.push(reducedValue);
					}
				} else {
					target = isArray(source) ? [] : {};
					forEach(source, (value, key) => {
						const reducedValue = visit(value);
						!isUndefined(reducedValue) && (target[key] = reducedValue);
					});
				}
				visited.delete(source);
				return target;
			}
		}
		return source;
	};
	return visit(obj);
};
/**
* Determines if a value is an async function.
*
* @param {*} thing - The value to test.
* @returns {boolean} True if value is an async function, otherwise false.
*/
var isAsyncFn = kindOfTest("AsyncFunction");
/**
* Determines if a value is thenable (has then and catch methods).
*
* @param {*} thing - The value to test.
* @returns {boolean} True if value is thenable, otherwise false.
*/
var isThenable = (thing) => thing && (isObject(thing) || isFunction$1(thing)) && isFunction$1(thing.then) && isFunction$1(thing.catch);
/**
* Provides a cross-platform setImmediate implementation.
* Uses native setImmediate if available, otherwise falls back to postMessage or setTimeout.
*
* @param {boolean} setImmediateSupported - Whether setImmediate is supported.
* @param {boolean} postMessageSupported - Whether postMessage is supported.
* @returns {Function} A function to schedule a callback asynchronously.
*/
var _setImmediate = ((setImmediateSupported, postMessageSupported) => {
	if (setImmediateSupported) return setImmediate;
	return postMessageSupported ? ((token, callbacks) => {
		_global.addEventListener("message", ({ source, data }) => {
			if (source === _global && data === token) callbacks.length && callbacks.shift()();
		}, false);
		return (cb) => {
			callbacks.push(cb);
			_global.postMessage(token, "*");
		};
	})(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
})(typeof setImmediate === "function", isFunction$1(_global.postMessage));
/**
* Schedules a microtask or asynchronous callback as soon as possible.
* Uses queueMicrotask if available, otherwise falls back to process.nextTick or _setImmediate.
*
* @type {Function}
*/
var asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
var isIterable = (thing) => thing != null && isFunction$1(thing[iterator]);
/**
* Determine if a value is iterable via an iterator that is NOT sourced solely
* from a polluted Object.prototype. Use this instead of `isIterable` whenever
* the iterable comes from untrusted input (e.g. user-supplied header sources),
* so `Object.prototype[Symbol.iterator] = ...` cannot turn an ordinary object
* into an attacker-controlled entries iterator.
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value has a non-polluted iterator
*/
var isSafeIterable = (thing) => thing != null && hasOwnInPrototypeChain(thing, iterator) && isIterable(thing);
var utils_default = {
	isArray,
	isArrayBuffer,
	isBuffer,
	isFormData,
	isArrayBufferView,
	isString,
	isNumber,
	isBoolean,
	isObject,
	isPlainObject,
	isEmptyObject,
	isReadableStream,
	isRequest,
	isResponse,
	isHeaders,
	isUndefined,
	isDate,
	isFile,
	isReactNativeBlob,
	isReactNative,
	isBlob,
	isRegExp,
	isFunction: isFunction$1,
	isStream,
	isURLSearchParams,
	isTypedArray,
	isFileList,
	forEach,
	merge,
	extend,
	trim,
	stripBOM,
	inherits,
	toFlatObject,
	kindOf,
	kindOfTest,
	endsWith,
	toArray,
	forEachEntry,
	matchAll,
	isHTMLForm,
	hasOwnProperty,
	hasOwnProp: hasOwnProperty,
	hasOwnInPrototypeChain,
	getSafeProp,
	toSafeFlatObject,
	reduceDescriptors,
	freezeMethods,
	toObjectSet,
	toCamelCase,
	noop,
	toFiniteNumber,
	findKey,
	global: _global,
	isContextDefined,
	isSpecCompliantForm,
	toJSONObject,
	isAsyncFn,
	isThenable,
	setImmediate: _setImmediate,
	asap,
	isIterable,
	isSafeIterable
};
// node_modules/axios/lib/helpers/parseHeaders.js
var ignoreDuplicateOf = utils_default.toObjectSet([
	"age",
	"authorization",
	"content-length",
	"content-type",
	"etag",
	"expires",
	"from",
	"host",
	"if-modified-since",
	"if-unmodified-since",
	"last-modified",
	"location",
	"max-forwards",
	"proxy-authorization",
	"referer",
	"retry-after",
	"user-agent"
]);
/**
* Parse headers into an object
*
* ```
* Date: Wed, 27 Aug 2014 08:58:49 GMT
* Content-Type: application/json
* Connection: keep-alive
* Transfer-Encoding: chunked
* ```
*
* @param {String} rawHeaders Headers needing to be parsed
*
* @returns {Object} Headers parsed into an object
*/
var parseHeaders_default = (rawHeaders) => {
	const parsed = Object.create(null);
	let key;
	let val;
	let i;
	rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
		i = line.indexOf(":");
		key = line.substring(0, i).trim().toLowerCase();
		val = line.substring(i + 1).trim();
		const hasKey = utils_default.hasOwnProp(parsed, key);
		if (!key || hasKey && utils_default.hasOwnProp(ignoreDuplicateOf, key)) return;
		if (key === "set-cookie") {
			if (hasKey) parsed[key].push(val);
			else parsed[key] = [val];
		} else parsed[key] = hasKey ? parsed[key] + ", " + val : val;
	});
	return parsed;
};
// node_modules/axios/lib/helpers/sanitizeHeaderValue.js
function trimSPorHTAB(str) {
	let start = 0;
	let end = str.length;
	while (start < end) {
		const code = str.charCodeAt(start);
		if (code !== 9 && code !== 32) break;
		start += 1;
	}
	while (end > start) {
		const code = str.charCodeAt(end - 1);
		if (code !== 9 && code !== 32) break;
		end -= 1;
	}
	return start === 0 && end === str.length ? str : str.slice(start, end);
}
var INVALID_UNICODE_HEADER_VALUE_CHARS = /* @__PURE__ */ new RegExp("[\\u0000-\\u0008\\u000a-\\u001f\\u007f]+", "g");
var INVALID_BYTE_STRING_HEADER_VALUE_CHARS = /* @__PURE__ */ new RegExp("[^\\u0009\\u0020-\\u007e\\u0080-\\u00ff]+", "g");
function sanitizeValue(value, invalidChars) {
	if (utils_default.isArray(value)) return value.map((item) => sanitizeValue(item, invalidChars));
	return trimSPorHTAB(String(value).replace(invalidChars, ""));
}
var sanitizeHeaderValue = (value) => sanitizeValue(value, INVALID_UNICODE_HEADER_VALUE_CHARS);
var sanitizeByteStringHeaderValue = (value) => sanitizeValue(value, INVALID_BYTE_STRING_HEADER_VALUE_CHARS);
function toByteStringHeaderObject(headers) {
	const byteStringHeaders = Object.create(null);
	utils_default.forEach(headers.toJSON(), (value, header) => {
		byteStringHeaders[header] = sanitizeByteStringHeaderValue(value);
	});
	return byteStringHeaders;
}
// node_modules/axios/lib/core/AxiosHeaders.js
var $internals$1 = Symbol("internals");
function normalizeHeader(header) {
	return header && String(header).trim().toLowerCase();
}
function normalizeValue(value) {
	if (value === false || value == null) return value;
	return utils_default.isArray(value) ? value.map(normalizeValue) : sanitizeHeaderValue(String(value));
}
function parseTokens(str) {
	const tokens = Object.create(null);
	const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
	let match;
	while (match = tokensRE.exec(str)) tokens[match[1]] = match[2];
	return tokens;
}
var parameterNameRE = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
function trimOWS(value) {
	let start = 0;
	let end = value.length;
	while (start < end) {
		const code = value.charCodeAt(start);
		if (code !== 9 && code !== 32) break;
		start += 1;
	}
	while (end > start) {
		const code = value.charCodeAt(end - 1);
		if (code !== 9 && code !== 32) break;
		end -= 1;
	}
	return start === 0 && end === value.length ? value : value.slice(start, end);
}
function decodeQuotedString(value) {
	const last = value.length - 1;
	if (last < 1 || value.charCodeAt(0) !== 34 || value.charCodeAt(last) !== 34) return value;
	let decoded = "";
	for (let i = 1; i < last; i++) {
		const code = value.charCodeAt(i);
		if (code === 34) return value;
		if (code === 92) {
			i += 1;
			if (i >= last) return value;
		}
		decoded += value[i];
	}
	return decoded;
}
function parseParameters(value) {
	const parameters = Object.create(null);
	const str = String(value);
	let start = 0;
	let quoted = false;
	let escaped = false;
	function parseParameter(end) {
		const part = trimOWS(str.slice(start, end));
		const equals = part.indexOf("=");
		if (equals < 1) return;
		const name = trimOWS(part.slice(0, equals));
		if (!parameterNameRE.test(name)) return;
		const normalizedName = name.toLowerCase();
		if (normalizedName === "__proto__" || normalizedName === "constructor" || normalizedName === "prototype") return;
		const parameterValue = trimOWS(part.slice(equals + 1));
		parameters[normalizedName] = decodeQuotedString(parameterValue);
	}
	for (let i = 0; i < str.length; i++) {
		const code = str.charCodeAt(i);
		if (quoted) {
			if (escaped) escaped = false;
			else if (code === 92) escaped = true;
			else if (code === 34) quoted = false;
		} else if (code === 34) quoted = true;
		else if (code === 44 || code === 59) {
			parseParameter(i);
			start = i + 1;
		}
	}
	parseParameter(str.length);
	return parameters;
}
var isValidHeaderName = (str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
var PROTO_HEADER_SLOT = "__Proto__";
var headerSlot = (name) => name === "__proto__" ? PROTO_HEADER_SLOT : name;
function matchHeaderValue(context, value, header, filter, isHeaderNameFilter) {
	if (utils_default.isFunction(filter)) return filter.call(context, value, header);
	if (isHeaderNameFilter) value = header;
	if (!utils_default.isString(value)) return;
	if (utils_default.isString(filter)) return value.indexOf(filter) !== -1;
	if (utils_default.isRegExp(filter)) return filter.test(value);
}
function formatHeader(header) {
	return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str) => {
		return char.toUpperCase() + str;
	});
}
function buildAccessors(obj, header) {
	const accessorName = utils_default.toCamelCase(" " + header);
	[
		"get",
		"set",
		"has"
	].forEach((methodName) => {
		Object.defineProperty(obj, methodName + accessorName, {
			__proto__: null,
			value: function(arg1, arg2, arg3) {
				return this[methodName].call(this, header, arg1, arg2, arg3);
			},
			configurable: true
		});
	});
}
var AxiosHeaders$1 = class {
	constructor(headers) {
		headers && this.set(headers);
	}
	set(header, valueOrRewrite, rewrite) {
		const self = this;
		function setHeader(_value, _header, _rewrite) {
			const lHeader = normalizeHeader(_header);
			if (!lHeader) return;
			const key = utils_default.findKey(self, lHeader);
			if (!key || self[key] === void 0 || _rewrite === true || _rewrite === void 0 && self[key] !== false) self[headerSlot(key || _header)] = normalizeValue(_value);
		}
		const setHeaders = (headers, _rewrite) => utils_default.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
		if (utils_default.isPlainObject(header) || header instanceof this.constructor) setHeaders(header, valueOrRewrite);
		else if (utils_default.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) setHeaders(parseHeaders_default(header), valueOrRewrite);
		else if (utils_default.isObject(header) && utils_default.isSafeIterable(header)) {
			let obj = Object.create(null), dest, key;
			for (const entry of header) {
				if (!utils_default.isArray(entry)) throw new TypeError("Object iterator must return a key-value pair");
				key = entry[0];
				if (utils_default.hasOwnProp(obj, key)) {
					dest = obj[key];
					obj[key] = utils_default.isArray(dest) ? [...dest, entry[1]] : [dest, entry[1]];
				} else obj[key] = entry[1];
			}
			setHeaders(obj, valueOrRewrite);
		} else header != null && setHeader(valueOrRewrite, header, rewrite);
		return this;
	}
	get(header, parser) {
		header = normalizeHeader(header);
		if (header) {
			const key = utils_default.findKey(this, header);
			if (key) {
				const value = this[key];
				if (!parser) return value;
				if (parser === true) return parseTokens(value);
				if (utils_default.isFunction(parser)) return parser.call(this, value, key);
				if (utils_default.isRegExp(parser)) return parser.exec(value);
				throw new TypeError("parser must be boolean|regexp|function");
			}
		}
	}
	has(header, matcher) {
		header = normalizeHeader(header);
		if (header) {
			const key = utils_default.findKey(this, header);
			return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
		}
		return false;
	}
	delete(header, matcher) {
		const self = this;
		let deleted = false;
		function deleteHeader(_header) {
			_header = normalizeHeader(_header);
			if (_header) {
				const key = utils_default.findKey(self, _header);
				if (key && (!matcher || matchHeaderValue(self, self[key], key, matcher))) {
					delete self[key];
					deleted = true;
				}
			}
		}
		if (utils_default.isArray(header)) header.forEach(deleteHeader);
		else deleteHeader(header);
		return deleted;
	}
	clear(matcher) {
		const keys = Object.keys(this);
		let i = keys.length;
		let deleted = false;
		while (i--) {
			const key = keys[i];
			if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
				delete this[key];
				deleted = true;
			}
		}
		return deleted;
	}
	normalize(format) {
		const self = this;
		const headers = Object.create(null);
		utils_default.forEach(this, (value, header) => {
			const key = utils_default.findKey(headers, header);
			if (key) {
				self[key] = normalizeValue(value);
				delete self[header];
				return;
			}
			const normalized = headerSlot(format ? formatHeader(header) : String(header).trim());
			if (normalized !== header) delete self[header];
			self[normalized] = normalizeValue(value);
			headers[normalized] = true;
		});
		return this;
	}
	concat(...targets) {
		return this.constructor.concat(this, ...targets);
	}
	toJSON(asStrings) {
		const obj = Object.create(null);
		utils_default.forEach(this, (value, header) => {
			value != null && value !== false && (obj[header] = asStrings && utils_default.isArray(value) ? value.join(", ") : value);
		});
		return obj;
	}
	[Symbol.iterator]() {
		return Object.entries(this.toJSON())[Symbol.iterator]();
	}
	toString() {
		return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
	}
	getSetCookie() {
		const value = this.get("set-cookie");
		return utils_default.isArray(value) ? value : value == null || value === false ? [] : [value];
	}
	get [Symbol.toStringTag]() {
		return "AxiosHeaders";
	}
	static from(thing) {
		return thing instanceof this ? thing : new this(thing);
	}
	static parseParameters(value) {
		return parseParameters(value);
	}
	static concat(first, ...targets) {
		const computed = new this(first);
		targets.forEach((target) => computed.set(target));
		return computed;
	}
	static accessor(header) {
		const accessors = (this[$internals$1] = this[$internals$1] = { accessors: {} }).accessors;
		const prototype = this.prototype;
		function defineAccessor(_header) {
			const lHeader = normalizeHeader(_header);
			if (!accessors[lHeader]) {
				buildAccessors(prototype, _header);
				accessors[lHeader] = true;
			}
		}
		utils_default.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
		return this;
	}
};
AxiosHeaders$1.accessor([
	"Content-Type",
	"Content-Length",
	"Accept",
	"Accept-Encoding",
	"User-Agent",
	"Authorization"
]);
utils_default.reduceDescriptors(AxiosHeaders$1.prototype, ({ value }, key) => {
	let mapped = key[0].toUpperCase() + key.slice(1);
	return {
		get: () => value,
		set(headerValue) {
			this[mapped] = headerValue;
		}
	};
});
utils_default.freezeMethods(AxiosHeaders$1);
// node_modules/axios/lib/core/AxiosError.js
var REDACTED = "[REDACTED ****]";
function hasOwnOrPrototypeToJSON(source) {
	if (utils_default.hasOwnProp(source, "toJSON")) return true;
	let prototype = Object.getPrototypeOf(source);
	while (prototype && prototype !== Object.prototype) {
		if (utils_default.hasOwnProp(prototype, "toJSON")) return true;
		prototype = Object.getPrototypeOf(prototype);
	}
	return false;
}
function redactConfig(config, redactKeys) {
	const lowerKeys = new Set(redactKeys.map((k) => String(k).toLowerCase()));
	const seen = [];
	const visit = (source) => {
		if (source === null || typeof source !== "object") return source;
		if (utils_default.isBuffer(source)) return source;
		if (seen.indexOf(source) !== -1) return void 0;
		if (source instanceof AxiosHeaders$1) source = source.toJSON();
		seen.push(source);
		let result;
		if (utils_default.isArray(source)) {
			result = [];
			source.forEach((v, i) => {
				const reducedValue = visit(v);
				if (!utils_default.isUndefined(reducedValue)) result[i] = reducedValue;
			});
		} else {
			if (!utils_default.isPlainObject(source) && hasOwnOrPrototypeToJSON(source)) {
				seen.pop();
				return source;
			}
			result = Object.create(null);
			for (const [key, value] of Object.entries(source)) {
				const reducedValue = lowerKeys.has(key.toLowerCase()) ? REDACTED : visit(value);
				if (!utils_default.isUndefined(reducedValue)) result[key] = reducedValue;
			}
		}
		seen.pop();
		return result;
	};
	return visit(config);
}
function stringifySafely$1(value) {
	try {
		return String(value);
	} catch (err) {
		return "";
	}
}
function aggregateErrorMessage(error) {
	return error.errors.map((entry) => {
		try {
			return entry && entry.message ? stringifySafely$1(entry.message) : stringifySafely$1(entry);
		} catch (err) {
			return "";
		}
	}).filter(Boolean).join("; ") || error.name || "AggregateError";
}
var CAUSED_BY_SEPARATOR = "\nCaused by: ";
var $causeStack = Symbol("causeStack");
function getCauseStackIndex(error, stack) {
	const causeStack = utils_default.hasOwnProp(error, $causeStack) && error[$causeStack];
	return causeStack && stack.endsWith(causeStack) ? stack.length - causeStack.length : -1;
}
/**
* Append the stack of a wrapped error to `target.stack`.
*
* `cause` already exposes the original error for tooling that walks the standard
* cause chain, but many error reporters read `stack` and nothing else. Inlining
* the wrapped stack there means those reporters surface the underlying failure
* instead of the axios frames that normalized it (see #6670).
*
* Every read is defensive: a custom `Error.prepareStackTrace` hook, a runtime
* without stack support, or a replaced `stack` property can leave the value
* missing, non-string, or read-only, and normalizing an error must not throw
* because of that.
*
* @param {Error} target The AxiosError being built.
* @param {Error} source The error being wrapped.
*
* @returns {void}
*/
function appendCauseStack(target, source) {
	try {
		const sourceStack = source && source.stack;
		if (typeof sourceStack !== "string" || !sourceStack) return;
		const targetStack = target.stack;
		if (typeof targetStack !== "string" || !targetStack) return;
		const causeStack = CAUSED_BY_SEPARATOR + sourceStack;
		target.stack = targetStack + causeStack;
		Object.defineProperty(target, $causeStack, {
			__proto__: null,
			value: causeStack
		});
	} catch (e) {}
}
var AxiosError$1 = class AxiosError$1 extends Error {
	static from(error, code, config, request, response, customProps) {
		let message = error.message;
		if (!message && utils_default.isArray(error.errors) && error.errors.length) message = aggregateErrorMessage(error);
		const axiosError = new AxiosError$1(message, code || error.code, config, request, response);
		Object.defineProperty(axiosError, "cause", {
			__proto__: null,
			value: error,
			writable: true,
			enumerable: false,
			configurable: true
		});
		axiosError.name = error.name;
		appendCauseStack(axiosError, error);
		if (error.status != null && axiosError.status == null) axiosError.status = error.status;
		customProps && Object.assign(axiosError, customProps);
		return axiosError;
	}
	/**
	* Create an Error with the specified message, config, error code, request and response.
	*
	* @param {string} message The error message.
	* @param {string} [code] The error code (for example, 'ECONNABORTED').
	* @param {Object} [config] The config.
	* @param {Object} [request] The request.
	* @param {Object} [response] The response.
	*
	* @returns {Error} The created error.
	*/
	constructor(message, code, config, request, response) {
		super(message);
		Object.defineProperty(this, "message", {
			__proto__: null,
			value: message,
			enumerable: true,
			writable: true,
			configurable: true
		});
		this.name = "AxiosError";
		this.isAxiosError = true;
		code && (this.code = code);
		config && (this.config = config);
		request && (this.request = request);
		if (response) {
			this.response = response;
			this.status = response.status;
		}
	}
	toJSON() {
		const config = this.config;
		const redactKeys = config && utils_default.hasOwnProp(config, "redact") ? config.redact : void 0;
		const serializedConfig = utils_default.isArray(redactKeys) && redactKeys.length > 0 ? redactConfig(config, redactKeys) : utils_default.toJSONObject(config);
		return {
			message: this.message,
			name: this.name,
			description: this.description,
			number: this.number,
			fileName: this.fileName,
			lineNumber: this.lineNumber,
			columnNumber: this.columnNumber,
			stack: this.stack,
			config: serializedConfig,
			code: this.code,
			status: this.status
		};
	}
};
AxiosError$1.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
AxiosError$1.ERR_BAD_OPTION = "ERR_BAD_OPTION";
AxiosError$1.ECONNABORTED = "ECONNABORTED";
AxiosError$1.ETIMEDOUT = "ETIMEDOUT";
AxiosError$1.ECONNREFUSED = "ECONNREFUSED";
AxiosError$1.ERR_NETWORK = "ERR_NETWORK";
AxiosError$1.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
AxiosError$1.ERR_DEPRECATED = "ERR_DEPRECATED";
AxiosError$1.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
AxiosError$1.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
AxiosError$1.ERR_CANCELED = "ERR_CANCELED";
AxiosError$1.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
AxiosError$1.ERR_INVALID_URL = "ERR_INVALID_URL";
AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
/**
* Determines if the given thing is a array or js object.
*
* @param {string} thing - The object or array to be visited.
*
* @returns {boolean}
*/
function isVisitable(thing) {
	return utils_default.isPlainObject(thing) || utils_default.isArray(thing);
}
/**
* It removes the brackets from the end of a string
*
* @param {string} key - The key of the parameter.
*
* @returns {string} the key without the brackets.
*/
function removeBrackets(key) {
	return utils_default.endsWith(key, "[]") ? key.slice(0, -2) : key;
}
/**
* It takes a path, a key, and a boolean, and returns a string
*
* @param {string} path - The path to the current key.
* @param {string} key - The key of the current object being iterated over.
* @param {string} dots - If true, the key will be rendered with dots instead of brackets.
*
* @returns {string} The path to the current key.
*/
function renderKey(path, key, dots) {
	if (!path) return key;
	return path.concat(key).map(function each(token, i) {
		token = removeBrackets(token);
		return !dots && i ? "[" + token + "]" : token;
	}).join(dots ? "." : "");
}
/**
* If the array is an array and none of its elements are visitable, then it's a flat array.
*
* @param {Array<any>} arr - The array to check
*
* @returns {boolean}
*/
function isFlatArray(arr) {
	return utils_default.isArray(arr) && !arr.some(isVisitable);
}
var predicates = utils_default.toFlatObject(utils_default, {}, null, function filter(prop) {
	return /^is[A-Z]/.test(prop);
});
/**
* Convert a data object to FormData
*
* @param {Object} obj
* @param {?Object} [formData]
* @param {?Object} [options]
* @param {Function} [options.visitor]
* @param {Boolean} [options.metaTokens = true]
* @param {Boolean} [options.dots = false]
* @param {?Boolean} [options.indexes = false]
*
* @returns {Object}
**/
/**
* It converts an object into a FormData object
*
* @param {Object<any, any>} obj - The object to convert to form data.
* @param {string} formData - The FormData object to append to.
* @param {Object<string, any>} options
*
* @returns
*/
function toFormData$1(obj, formData, options) {
	if (!utils_default.isObject(obj)) throw new TypeError("target must be an object");
	formData = formData || new FormData();
	const option = (name, fallback) => {
		const value = utils_default.getSafeProp(options, name);
		return utils_default.isUndefined(value) ? fallback : value;
	};
	const metaTokens = option("metaTokens", true);
	const visitor = option("visitor") || defaultVisitor;
	const dots = option("dots", false);
	const indexes = option("indexes", false);
	const _Blob = option("Blob") || typeof Blob !== "undefined" && Blob;
	const maxDepth = option("maxDepth", 100);
	const useBlob = _Blob && utils_default.isSpecCompliantForm(formData);
	const stack = [];
	if (!utils_default.isFunction(visitor)) throw new TypeError("visitor must be a function");
	function convertValue(value) {
		if (value === null) return "";
		if (utils_default.isDate(value)) return value.toISOString();
		if (utils_default.isBoolean(value)) return value.toString();
		if (!useBlob && utils_default.isBlob(value)) throw new AxiosError$1("Blob is not supported. Use a Buffer instead.");
		if (utils_default.isArrayBuffer(value) || utils_default.isTypedArray(value)) {
			if (useBlob && typeof _Blob === "function") return new _Blob([value]);
			throw new AxiosError$1("Blob is not supported. Use a Buffer instead.", AxiosError$1.ERR_NOT_SUPPORT);
		}
		return value;
	}
	function throwIfMaxDepthExceeded(depth) {
		if (depth > maxDepth) throw new AxiosError$1("Object is too deeply nested (" + depth + " levels). Max depth: " + maxDepth, AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED);
	}
	function stringifyWithDepthLimit(value, depth) {
		if (maxDepth === Infinity) return JSON.stringify(value);
		const ancestors = [];
		return JSON.stringify(value, function limitDepth(_key, currentValue) {
			if (!utils_default.isObject(currentValue)) return currentValue;
			while (ancestors.length && ancestors[ancestors.length - 1] !== this) ancestors.pop();
			ancestors.push(currentValue);
			throwIfMaxDepthExceeded(depth + ancestors.length - 1);
			return currentValue;
		});
	}
	/**
	* Default visitor.
	*
	* @param {*} value
	* @param {String|Number} key
	* @param {Array<String|Number>} path
	* @this {FormData}
	*
	* @returns {boolean} return true to visit the each prop of the value recursively
	*/
	function defaultVisitor(value, key, path) {
		let arr = value;
		if (utils_default.isReactNative(formData) && utils_default.isReactNativeBlob(value)) {
			formData.append(renderKey(path, key, dots), convertValue(value));
			return false;
		}
		if (value && !path && typeof value === "object") {
			if (utils_default.endsWith(key, "{}")) {
				key = metaTokens ? key : key.slice(0, -2);
				value = stringifyWithDepthLimit(value, 1);
			} else if (utils_default.isArray(value) && isFlatArray(value) || (utils_default.isFileList(value) || utils_default.endsWith(key, "[]")) && (arr = utils_default.toArray(value))) {
				key = removeBrackets(key);
				arr.forEach(function each(el, index) {
					!(utils_default.isUndefined(el) || el === null) && formData.append(indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]", convertValue(el));
				});
				return false;
			}
		}
		if (isVisitable(value)) return true;
		formData.append(renderKey(path, key, dots), convertValue(value));
		return false;
	}
	const exposedHelpers = Object.assign(predicates, {
		defaultVisitor,
		convertValue,
		isVisitable
	});
	function build(value, path, depth = 0) {
		if (utils_default.isUndefined(value)) return;
		throwIfMaxDepthExceeded(depth);
		if (stack.indexOf(value) !== -1) throw new Error("Circular reference detected in " + path.join("."));
		stack.push(value);
		utils_default.forEach(value, function each(el, key) {
			if ((!(utils_default.isUndefined(el) || el === null) && visitor.call(formData, el, utils_default.isString(key) ? key.trim() : key, path, exposedHelpers)) === true) build(el, path ? path.concat(key) : [key], depth + 1);
		});
		stack.pop();
	}
	if (!utils_default.isObject(obj)) throw new TypeError("data must be an object");
	build(obj);
	return formData;
}
// node_modules/axios/lib/helpers/AxiosURLSearchParams.js
/**
* It encodes a string by replacing all characters that are not in the unreserved set with
* their percent-encoded equivalents
*
* @param {string} str - The string to encode.
*
* @returns {string} The encoded string.
*/
function encode$1(str) {
	const charMap = {
		"!": "%21",
		"'": "%27",
		"(": "%28",
		")": "%29",
		"~": "%7E",
		"%20": "+"
	};
	return encodeURIComponent(str).replace(/[!'()~]|%20/g, function replacer(match) {
		return charMap[match];
	});
}
/**
* It takes a params object and converts it to a FormData object
*
* @param {Object<string, any>} params - The parameters to be converted to a FormData object.
* @param {Object<string, any>} options - The options object passed to the Axios constructor.
*
* @returns {void}
*/
function AxiosURLSearchParams(params, options) {
	this._pairs = [];
	params && toFormData$1(params, this, options);
}
var prototype = AxiosURLSearchParams.prototype;
prototype.append = function append(name, value) {
	this._pairs.push([name, value]);
};
prototype.toString = function toString(encoder) {
	const _encode = encoder ? (value) => encoder.call(this, value, encode$1) : encode$1;
	return this._pairs.map(function each(pair) {
		return _encode(pair[0]) + "=" + _encode(pair[1]);
	}, "").join("&");
};
// node_modules/axios/lib/helpers/buildURL.js
/**
* It replaces URL-encoded forms of `:`, `$`, `,`, and spaces with
* their plain counterparts (`:`, `$`, `,`, `+`).
*
* @param {string} val The value to be encoded.
*
* @returns {string} The encoded value.
*/
function encode(val) {
	return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
}
/**
* Build a URL by appending params to the end
*
* @param {string} url The base of the url (e.g., http://www.google.com)
* @param {object} [params] The params to be appended
* @param {?(object|Function)} options
*
* @returns {string} The formatted url
*/
function buildURL(url, params, options) {
	if (!params) return url;
	url = url || "";
	const _options = utils_default.isFunction(options) ? { serialize: options } : options;
	const _encode = utils_default.getSafeProp(_options, "encode") || encode;
	const serializeFn = utils_default.getSafeProp(_options, "serialize");
	let serializedParams;
	if (serializeFn) serializedParams = serializeFn(params, _options);
	else serializedParams = utils_default.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams(params, _options).toString(_encode);
	if (serializedParams) {
		const hashmarkIndex = url.indexOf("#");
		if (hashmarkIndex !== -1) url = url.slice(0, hashmarkIndex);
		url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
	}
	return url;
}
// node_modules/axios/lib/core/InterceptorManager.js
var $internals = Symbol("internals");
function countHandlers(handlers) {
	return handlers ? handlers.length : 0;
}
function trimHandlers(handlers) {
	if (!handlers) return;
	while (handlers.length && handlers[handlers.length - 1] === null) handlers.pop();
}
function normalizeHandlerId(id) {
	if (typeof id === "string" && id !== "" && String(Number(id)) === id) return Number(id);
	return id;
}
function syncHandlerEntries(manager, internals) {
	const handlers = manager.handlers;
	const length = countHandlers(handlers);
	if (handlers !== internals.handlersRef) {
		internals.handlersRef = handlers;
		internals.handlerEntries.clear();
	} else if (length !== internals.handlersLength) {
		if (!length) internals.handlerEntries.clear();
		else internals.handlerEntries.forEach(function removeStaleEntry(entry, id) {
			if (handlers[entry.index] !== entry.handler) internals.handlerEntries.delete(id);
		});
	}
	internals.handlersLength = length;
}
var InterceptorManager = class {
	constructor() {
		this.handlers = [];
		this[$internals] = {
			handlersRef: this.handlers,
			handlersLength: this.handlers.length,
			handlerEntries: /* @__PURE__ */ new Map(),
			iterationDepth: 0,
			nextId: 0
		};
	}
	/**
	* Add a new interceptor to the stack
	*
	* @param {Function} fulfilled The function to handle `then` for a `Promise`
	* @param {Function} rejected The function to handle `reject` for a `Promise`
	* @param {Object} options The options for the interceptor, synchronous and runWhen
	*
	* @return {Number} An ID used to remove interceptor later
	*/
	use(fulfilled, rejected, options) {
		const handler = {
			fulfilled,
			rejected,
			synchronous: options ? options.synchronous : false,
			runWhen: options ? options.runWhen : null
		};
		const internals = this[$internals];
		if (this.handlers == null) this.handlers = [];
		syncHandlerEntries(this, internals);
		const id = internals.nextId++;
		this.handlers.push(handler);
		internals.handlerEntries.set(id, {
			handler,
			index: this.handlers.length - 1
		});
		internals.handlersLength = this.handlers.length;
		return id;
	}
	/**
	* Remove an interceptor from the stack
	*
	* @param {Number} id The ID that was returned by `use`
	*
	* @returns {void}
	*/
	eject(id) {
		const internals = this[$internals];
		syncHandlerEntries(this, internals);
		const handlerId = normalizeHandlerId(id);
		const entry = internals.handlerEntries.get(handlerId);
		if (entry) {
			internals.handlerEntries.delete(handlerId);
			if (this.handlers[entry.index] !== entry.handler) return;
			this.handlers[entry.index] = null;
			if (!internals.iterationDepth) {
				trimHandlers(this.handlers);
				internals.handlersLength = this.handlers.length;
			}
		}
	}
	/**
	* Clear all interceptors from the stack
	*
	* @returns {void}
	*/
	clear() {
		if (this.handlers) {
			this.handlers = [];
			syncHandlerEntries(this, this[$internals]);
		}
	}
	/**
	* Iterate over all the registered interceptors
	*
	* This method is particularly useful for skipping over any
	* interceptors that may have become `null` calling `eject`.
	*
	* @param {Function} fn The function to call for each interceptor
	*
	* @returns {void}
	*/
	forEach(fn) {
		const internals = this[$internals];
		syncHandlerEntries(this, internals);
		internals.iterationDepth++;
		try {
			utils_default.forEach(this.handlers, function forEachHandler(h) {
				if (h !== null) fn(h);
			});
		} finally {
			if (!--internals.iterationDepth) {
				syncHandlerEntries(this, internals);
				trimHandlers(this.handlers);
				internals.handlersLength = countHandlers(this.handlers);
			}
		}
	}
};
// node_modules/axios/lib/defaults/transitional.js
var transitional_default = {
	silentJSONParsing: true,
	forcedJSONParsing: true,
	clarifyTimeoutError: false,
	legacyInterceptorReqResOrdering: true,
	advertiseZstdAcceptEncoding: false,
	validateStatusUndefinedResolves: true,
	encodeBasicAuthUsername: false
};
// node_modules/axios/lib/platform/browser/index.js
var browser_default = {
	isBrowser: true,
	classes: {
		URLSearchParams: typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams,
		FormData: typeof FormData !== "undefined" ? FormData : null,
		Blob: typeof Blob !== "undefined" ? Blob : null
	},
	protocols: [
		"http",
		"https",
		"file",
		"blob",
		"url",
		"data"
	]
};
// node_modules/axios/lib/platform/common/utils.js
var utils_exports = /* @__PURE__ */ __exportAll({
	hasBrowserEnv: () => hasBrowserEnv,
	hasStandardBrowserEnv: () => hasStandardBrowserEnv,
	hasStandardBrowserWebWorkerEnv: () => hasStandardBrowserWebWorkerEnv,
	navigator: () => _navigator,
	origin: () => origin
});
var hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
var _navigator = typeof navigator === "object" && navigator || void 0;
/**
* Determine if we're running in a standard browser environment
*
* This allows axios to run in a web worker, and react-native.
* Both environments support XMLHttpRequest, but not fully standard globals.
*
* web workers:
*  typeof window -> undefined
*  typeof document -> undefined
*
* react-native:
*  navigator.product -> 'ReactNative'
* nativescript
*  navigator.product -> 'NativeScript' or 'NS'
*
* @returns {boolean}
*/
var hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || [
	"ReactNative",
	"NativeScript",
	"NS"
].indexOf(_navigator.product) < 0);
/**
* Determine if we're running in a standard browser webWorker environment
*
* Although the `isStandardBrowserEnv` method indicates that
* `allows axios to run in a web worker`, the WebWorker will still be
* filtered out due to its judgment standard
* `typeof window !== 'undefined' && typeof document !== 'undefined'`.
* This leads to a problem when axios post `FormData` in webWorker
*/
var hasStandardBrowserWebWorkerEnv = (() => {
	return typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
})();
var origin = hasBrowserEnv && window.location.href || "http://localhost";
// node_modules/axios/lib/platform/index.js
var platform_default = {
	...utils_exports,
	...browser_default
};
// node_modules/axios/lib/helpers/toURLEncodedForm.js
function toURLEncodedForm(data, options) {
	return toFormData$1(data, new platform_default.classes.URLSearchParams(), {
		visitor: function(value, key, path, helpers) {
			if (platform_default.isNode && utils_default.isBuffer(value)) {
				this.append(key, value.toString("base64"));
				return false;
			}
			return helpers.defaultVisitor.apply(this, arguments);
		},
		...options
	});
}
// node_modules/axios/lib/helpers/formDataToJSON.js
var MAX_DEPTH = 100;
function throwIfDepthExceeded(index) {
	if (index > MAX_DEPTH) throw new AxiosError$1("FormData field is too deeply nested (" + index + " levels). Max depth: " + MAX_DEPTH, AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED);
}
/**
* It takes a string like `foo[x][y][z]` and returns an array like `['foo', 'x', 'y', 'z']
*
* @param {string} name - The name of the property to get.
*
* @returns An array of strings.
*/
function parsePropPath(name) {
	const path = [];
	const pattern = /[^.[\]]+|\[([^.[\]]*)]/g;
	let match;
	while ((match = pattern.exec(name)) !== null) {
		throwIfDepthExceeded(path.length);
		path.push(match[0] === "[]" ? "" : match[1] || match[0]);
	}
	return path;
}
/**
* Convert an array to an object.
*
* @param {Array<any>} arr - The array to convert to an object.
*
* @returns An object with the same keys and values as the array.
*/
function arrayToObject(arr) {
	const obj = {};
	const keys = Object.keys(arr);
	let i;
	const len = keys.length;
	let key;
	for (i = 0; i < len; i++) {
		key = keys[i];
		obj[key] = arr[key];
	}
	return obj;
}
function normalizeArray(value) {
	if (!utils_default.isArray(value)) return value;
	const keys = Object.keys(value);
	return keys.length !== value.length || keys.some((key, index) => key !== String(index)) ? arrayToObject(value) : value;
}
function normalizeArrays(obj) {
	const pending = [obj];
	while (pending.length) {
		const target = pending.pop();
		Object.keys(target).forEach((key) => {
			const value = target[key] = normalizeArray(target[key]);
			if (utils_default.isArray(value) || utils_default.isPlainObject(value)) pending.push(value);
		});
	}
	return obj;
}
/**
* It takes a FormData object and returns a JavaScript object
*
* @param {string} formData The FormData object to convert to JSON.
*
* @returns {Object<string, any> | null} The converted object.
*/
function formDataToJSON(formData) {
	function buildPath(path, value, target, index) {
		throwIfDepthExceeded(index);
		let name = path[index++];
		if (name === "__proto__") return true;
		const isNumericKey = Number.isFinite(+name);
		const isLast = index >= path.length;
		name = !name && utils_default.isArray(target) ? target.length : name;
		if (isLast) {
			if (utils_default.hasOwnProp(target, name)) {
				target[name] = normalizeArray(target[name]);
				target[name] = utils_default.isArray(target[name]) ? target[name].concat(value) : [target[name], value];
			} else target[name] = value;
			return !isNumericKey;
		}
		if (!utils_default.hasOwnProp(target, name) || !utils_default.isObject(target[name])) target[name] = [];
		if (buildPath(path, value, target[name], index) && utils_default.isArray(target[name])) target[name] = arrayToObject(target[name]);
		return !isNumericKey;
	}
	if (utils_default.isFormData(formData) && utils_default.isFunction(formData.entries)) {
		const obj = {};
		utils_default.forEachEntry(formData, (name, value) => {
			buildPath(parsePropPath(name), value, obj, 0);
		});
		return normalizeArrays(obj);
	}
	return null;
}
// node_modules/axios/lib/core/methodList.js
var methodList = Object.freeze([
	"get",
	"delete",
	"head",
	"options",
	"post",
	"put",
	"patch",
	"purge",
	"link",
	"unlink",
	"query"
]);
// node_modules/axios/lib/defaults/index.js
var own = (obj, key) => obj != null && utils_default.hasOwnProp(obj, key) ? obj[key] : void 0;
/**
* It takes a string, tries to parse it, and if it fails, it returns the stringified version
* of the input
*
* @param {any} rawValue - The value to be stringified.
* @param {Function} parser - A function that parses a string into a JavaScript object.
* @param {Function} encoder - A function that takes a value and returns a string.
*
* @returns {string} A stringified version of the rawValue.
*/
function stringifySafely(rawValue, parser, encoder) {
	if (utils_default.isString(rawValue)) try {
		(parser || JSON.parse)(rawValue);
		return utils_default.trim(rawValue);
	} catch (e) {
		if (e.name !== "SyntaxError") throw e;
	}
	return (encoder || JSON.stringify)(rawValue);
}
var defaults = {
	transitional: transitional_default,
	adapter: [
		"xhr",
		"http",
		"fetch"
	],
	transformRequest: [function transformRequest(data, headers) {
		const contentType = headers.getContentType() || "";
		const hasJSONContentType = contentType.indexOf("application/json") > -1;
		const isObjectPayload = utils_default.isObject(data);
		if (isObjectPayload && utils_default.isHTMLForm(data)) data = new FormData(data);
		if (utils_default.isFormData(data)) return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
		if (utils_default.isArrayBuffer(data) || utils_default.isBuffer(data) || utils_default.isStream(data) || utils_default.isFile(data) || utils_default.isBlob(data) || utils_default.isReadableStream(data)) return data;
		if (utils_default.isArrayBufferView(data)) return data.buffer;
		if (utils_default.isURLSearchParams(data)) {
			headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
			return data.toString();
		}
		let isFileList;
		if (isObjectPayload) {
			const formSerializer = own(this, "formSerializer");
			if (contentType.indexOf("application/x-www-form-urlencoded") > -1) return toURLEncodedForm(data, formSerializer).toString();
			if ((isFileList = utils_default.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
				const env = own(this, "env");
				const _FormData = env && env.FormData;
				return toFormData$1(isFileList ? { "files[]": data } : data, _FormData && new _FormData(), formSerializer);
			}
		}
		if (isObjectPayload || hasJSONContentType) {
			headers.setContentType("application/json", false);
			return stringifySafely(data);
		}
		return data;
	}],
	transformResponse: [function transformResponse(data) {
		const transitional = own(this, "transitional") || defaults.transitional;
		const forcedJSONParsing = transitional && transitional.forcedJSONParsing;
		const responseType = own(this, "responseType");
		const JSONRequested = responseType === "json";
		if (utils_default.isResponse(data) || utils_default.isReadableStream(data)) return data;
		if (data && utils_default.isString(data) && (forcedJSONParsing && !responseType || JSONRequested)) {
			const strictJSONParsing = !(transitional && transitional.silentJSONParsing) && JSONRequested;
			try {
				return JSON.parse(data, own(this, "parseReviver"));
			} catch (e) {
				if (strictJSONParsing) {
					if (e.name === "SyntaxError") throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_RESPONSE, this, null, own(this, "response"));
					throw e;
				}
			}
		}
		return data;
	}],
	/**
	* A timeout in milliseconds to abort a request. If set to 0 (default) a
	* timeout is not created.
	*/
	timeout: 0,
	xsrfCookieName: "XSRF-TOKEN",
	xsrfHeaderName: "X-XSRF-TOKEN",
	maxContentLength: -1,
	maxBodyLength: -1,
	env: {
		FormData: platform_default.classes.FormData,
		Blob: platform_default.classes.Blob
	},
	validateStatus: function validateStatus(status) {
		return status >= 200 && status < 300;
	},
	headers: { common: {
		Accept: "application/json, text/plain, */*",
		"Content-Type": void 0
	} }
};
utils_default.forEach(methodList, (method) => {
	defaults.headers[method] = {};
});
// node_modules/axios/lib/core/transformData.js
/**
* Transform the data for a request or a response
*
* @param {Array|Function} fns A single function or Array of functions
* @param {?Object} response The response object
*
* @returns {*} The resulting transformed data
*/
function transformData(fns, response) {
	const config = this || defaults;
	const context = response || config;
	const headers = AxiosHeaders$1.from(context.headers);
	let data = context.data;
	utils_default.forEach(fns, function transform(fn) {
		data = fn.call(config, data, headers.normalize(), response ? response.status : void 0);
	});
	headers.normalize();
	return data;
}
// node_modules/axios/lib/cancel/isCancel.js
function isCancel$1(value) {
	return !!(value && value.__CANCEL__);
}
// node_modules/axios/lib/cancel/CanceledError.js
var CanceledError$1 = class extends AxiosError$1 {
	/**
	* A `CanceledError` is an object that is thrown when an operation is canceled.
	*
	* @param {string=} message The message.
	* @param {Object=} config The config.
	* @param {Object=} request The request.
	*
	* @returns {CanceledError} The created error.
	*/
	constructor(message, config, request) {
		super(message == null ? "canceled" : message, AxiosError$1.ERR_CANCELED, config, request);
		this.name = "CanceledError";
		this.__CANCEL__ = true;
	}
};
// node_modules/axios/lib/core/settle.js
/**
* Resolve or reject a Promise based on response status.
*
* @param {Function} resolve A function that resolves the promise.
* @param {Function} reject A function that rejects the promise.
* @param {object} response The response.
*
* @returns {object} The response.
*/
function settle(resolve, reject, response) {
	const validateStatus = response.config.validateStatus;
	if (!response.status || !validateStatus || validateStatus(response.status)) resolve(response);
	else reject(new AxiosError$1("Request failed with status code " + response.status, response.status >= 400 && response.status < 500 ? AxiosError$1.ERR_BAD_REQUEST : AxiosError$1.ERR_BAD_RESPONSE, response.config, response.request, response));
}
// node_modules/axios/lib/helpers/normalizeURLForProtocolCheck.js
var urlParserControlCharacters = /[\t\n\r]/g;
/**
* Match WHATWG URL preprocessing before checking a URL's protocol.
*
* @param {string} url
*
* @returns {string}
*/
function normalizeURLForProtocolCheck(url) {
	if (typeof url !== "string") return url;
	let start = 0;
	while (start < url.length && url.charCodeAt(start) <= 32) start++;
	return url.slice(start).replace(urlParserControlCharacters, "");
}
// node_modules/axios/lib/helpers/parseProtocol.js
function parseProtocol(url) {
	const match = /^([-+\w]{1,25}):(?:\/\/)?/.exec(url);
	return match && match[1].toLowerCase() || "";
}
// node_modules/axios/lib/helpers/cookies.js
var decodeCookieValue = (value) => {
	try {
		return decodeURIComponent(value);
	} catch (e) {
		return value;
	}
};
var cookies_default = platform_default.hasStandardBrowserEnv ? {
	write(name, value, expires, path, domain, secure, sameSite) {
		if (typeof document === "undefined") return;
		const cookie = [`${name}=${encodeURIComponent(value)}`];
		if (utils_default.isNumber(expires)) cookie.push(`expires=${new Date(expires).toUTCString()}`);
		if (utils_default.isString(path)) cookie.push(`path=${path}`);
		if (utils_default.isString(domain)) cookie.push(`domain=${domain}`);
		if (secure === true) cookie.push("secure");
		if (utils_default.isString(sameSite)) cookie.push(`SameSite=${sameSite}`);
		document.cookie = cookie.join("; ");
	},
	read(name) {
		if (typeof document === "undefined") return null;
		const cookieString = document.cookie;
		if (!cookieString) return null;
		const cookies = cookieString.split(";");
		for (let i = 0; i < cookies.length; i++) {
			const cookie = cookies[i].replace(/^\s+/, "");
			const eq = cookie.indexOf("=");
			if (eq !== -1 && cookie.slice(0, eq) === name) return decodeCookieValue(cookie.slice(eq + 1));
		}
		return null;
	},
	async readAsync(name) {
		try {
			const store = typeof window !== "undefined" && window.cookieStore;
			if (store && utils_default.isFunction(store.get)) {
				const cookie = await store.get(name);
				return cookie ? decodeCookieValue(cookie.value) : null;
			}
		} catch (e) {}
		return this.read(name);
	},
	remove(name) {
		this.write(name, "", Date.now() - 864e5, "/");
	}
} : {
	write() {},
	read() {
		return null;
	},
	async readAsync() {
		return null;
	},
	remove() {}
};
// node_modules/axios/lib/helpers/speedometer.js
/**
* Calculate data maxRate
* @param {Number} [samplesCount= 10]
* @param {Number} [min= 1000]
* @returns {Function}
*/
function speedometer(samplesCount, min) {
	samplesCount = samplesCount || 10;
	const bytes = new Array(samplesCount);
	const timestamps = new Array(samplesCount);
	let head = 0;
	let tail = 0;
	let firstSampleTS;
	min = min !== void 0 ? min : 1e3;
	return function push(chunkLength) {
		const now = Date.now();
		const startedAt = timestamps[tail];
		if (!firstSampleTS) firstSampleTS = now;
		bytes[head] = chunkLength;
		timestamps[head] = now;
		let i = tail;
		let bytesCount = 0;
		while (i !== head) {
			bytesCount += bytes[i++];
			i = i % samplesCount;
		}
		head = (head + 1) % samplesCount;
		if (head === tail) tail = (tail + 1) % samplesCount;
		if (now - firstSampleTS < min) return;
		const passed = startedAt && now - startedAt;
		return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
	};
}
// node_modules/axios/lib/helpers/throttle.js
/**
* Throttle decorator
* @param {Function} fn
* @param {Number} freq
* @return {Array<Function>}
*/
function throttle(fn, freq) {
	let timestamp = 0;
	let threshold = 1e3 / freq;
	let lastArgs;
	let timer;
	const invoke = (args, now = Date.now()) => {
		timestamp = now;
		lastArgs = null;
		if (timer) {
			clearTimeout(timer);
			timer = null;
		}
		fn(...args);
	};
	const throttled = (...args) => {
		const now = Date.now();
		const passed = now - timestamp;
		if (passed >= threshold) invoke(args, now);
		else {
			lastArgs = args;
			if (!timer) timer = setTimeout(() => {
				timer = null;
				invoke(lastArgs);
			}, threshold - passed);
		}
	};
	const flush = () => lastArgs && invoke(lastArgs);
	const flushWith = (...args) => invoke(args);
	return [
		throttled,
		flush,
		flushWith
	];
}
// node_modules/axios/lib/helpers/progressEventReducer.js
var progressEventReducer = (listener, isDownloadStream, freq = 3) => {
	let bytesNotified = 0;
	const _speedometer = speedometer(50, 250);
	return throttle((e) => {
		if (!e || !utils_default.isNumber(e.loaded)) return;
		const rawLoaded = e.loaded;
		const total = e.lengthComputable ? e.total : void 0;
		const loaded = Math.max(0, total != null ? Math.min(rawLoaded, total) : rawLoaded);
		const progressBytes = Math.max(0, loaded - bytesNotified);
		const rate = _speedometer(progressBytes);
		bytesNotified = Math.max(bytesNotified, loaded);
		listener({
			loaded,
			total,
			progress: total ? loaded / total : void 0,
			bytes: progressBytes,
			rate: rate ? rate : void 0,
			estimated: rate && total ? (total - loaded) / rate : void 0,
			event: e,
			lengthComputable: total != null,
			[isDownloadStream ? "download" : "upload"]: true
		});
	}, freq);
};
var progressEventDecorator = (total, throttled) => {
	const lengthComputable = total != null;
	return [(loaded) => throttled[0]({
		lengthComputable,
		total,
		loaded
	}), throttled[1]];
};
var asyncDecorator = (fn, scheduler = utils_default.asap) => (...args) => scheduler(() => fn(...args));
// node_modules/axios/lib/helpers/isURLSameOrigin.js
var isURLSameOrigin_default = platform_default.hasStandardBrowserEnv ? ((origin) => (url) => {
	url = new URL(url, document.baseURI || platform_default.origin);
	return origin.protocol === url.protocol && origin.host === url.host && origin.port === url.port;
})(new URL(platform_default.origin)) : () => true;
// node_modules/axios/lib/helpers/isAbsoluteURL.js
/**
* Determines whether the specified URL is absolute
*
* @param {string} url The URL to test
*
* @returns {boolean} True if the specified URL is absolute, otherwise false
*/
function isAbsoluteURL(url) {
	if (typeof url !== "string") return false;
	return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
}
// node_modules/axios/lib/helpers/combineURLs.js
/**
* Creates a new URL by combining the specified URLs
*
* @param {string} baseURL The base URL
* @param {string} relativeURL The relative URL
*
* @returns {string} The combined URL
*/
function combineURLs(baseURL, relativeURL) {
	if (!relativeURL) return baseURL;
	let end = baseURL.length;
	while (end > 0 && baseURL.charCodeAt(end - 1) === 47) end--;
	return baseURL.slice(0, end) + "/" + relativeURL.replace(/^\/+/, "");
}
// node_modules/axios/lib/core/buildFullPath.js
var malformedHttpProtocol = /^https?:(?!\/\/)/i;
function redactFragment(fragment) {
	if (!fragment) return fragment;
	return fragment.replace(/(^|&)([^=&]*=)?[^&]+/g, (match, separator, parameterName = "") => {
		return `${separator}${parameterName}${REDACTED}`;
	});
}
function redactSensitiveURLParts(url) {
	const redactedURL = url.replace(/^(https?:\/{0,2})[^/?#]*@/i, `$1${REDACTED}@`);
	const fragmentIndex = redactedURL.indexOf("#");
	const redactedURLWithoutFragment = (fragmentIndex === -1 ? redactedURL : redactedURL.slice(0, fragmentIndex)).replace(/([?&][^=&#]*=)[^&#]*/g, `$1${REDACTED}`);
	if (fragmentIndex === -1) return redactedURLWithoutFragment;
	return `${redactedURLWithoutFragment}#${redactFragment(redactedURL.slice(fragmentIndex + 1))}`;
}
function assertValidHttpProtocolURL(url, config) {
	if (typeof url === "string") {
		const normalizedURL = normalizeURLForProtocolCheck(url);
		if (malformedHttpProtocol.test(normalizedURL)) throw new AxiosError$1(`Invalid URL ${JSON.stringify(redactSensitiveURLParts(normalizedURL))}: missing "//" after protocol`, AxiosError$1.ERR_INVALID_URL, config);
	}
}
/**
* Creates a new URL by combining the baseURL with the requestedURL,
* only when the requestedURL is not already an absolute URL.
* If the requestURL is absolute, this function returns the requestedURL untouched.
*
* @param {string} baseURL The base URL
* @param {string} requestedURL Absolute or relative URL to combine
*
* @returns {string} The combined full path
*/
function buildFullPath(baseURL, requestedURL, allowAbsoluteUrls, config) {
	assertValidHttpProtocolURL(requestedURL, config);
	let isRelativeUrl = !isAbsoluteURL(requestedURL);
	if (baseURL && (isRelativeUrl || allowAbsoluteUrls === false)) {
		assertValidHttpProtocolURL(baseURL, config);
		return combineURLs(baseURL, requestedURL);
	}
	return requestedURL;
}
// node_modules/axios/lib/core/assertParamsAcyclic.js
function assertParamsAcyclic(params) {
	const pending = [{ value: params }];
	const active = /* @__PURE__ */ new WeakSet();
	const visited = /* @__PURE__ */ new WeakSet();
	while (pending.length) {
		const { value, done } = pending.pop();
		if (!utils_default.isPlainObject(value) && !utils_default.isArray(value)) continue;
		if (done) {
			active.delete(value);
			continue;
		}
		if (active.has(value)) throw new AxiosError$1("Circular reference detected in params", AxiosError$1.ERR_BAD_OPTION_VALUE);
		if (visited.has(value)) continue;
		visited.add(value);
		active.add(value);
		pending.push({
			value,
			done: true
		});
		const keys = Object.keys(value);
		if (Object.getOwnPropertySymbols && Object.getOwnPropertyDescriptor) Object.getOwnPropertySymbols(value).forEach((key) => {
			const descriptor = Object.getOwnPropertyDescriptor(value, key);
			if (descriptor && descriptor.enumerable) keys.push(key);
		});
		keys.forEach((key) => {
			if (key === "__proto__" || key === "constructor" || key === "prototype") {
				const descriptor = Object.getOwnPropertyDescriptor(value, key);
				if (descriptor && utils_default.hasOwnProp(descriptor, "value")) pending.push({ value: descriptor.value });
			} else pending.push({ value: value[key] });
		});
	}
}
// node_modules/axios/lib/core/mergeConfig.js
var headersToObject = (thing) => thing instanceof AxiosHeaders$1 ? { ...thing } : thing;
var ownEnumerableKeys = (thing) => {
	if (Object.getOwnPropertySymbols && Object.getOwnPropertyDescriptor) return Object.keys(thing).concat(Object.getOwnPropertySymbols(thing).filter((symbol) => {
		const descriptor = Object.getOwnPropertyDescriptor(thing, symbol);
		return descriptor && descriptor.enumerable;
	}));
	return Object.keys(thing);
};
function mergeParams(a, b) {
	const pending = [];
	const copies = /* @__PURE__ */ new WeakMap();
	const empty = {};
	function copy(target, source) {
		if (!utils_default.isPlainObject(source)) return utils_default.isArray(source) ? source.slice() : source;
		const base = utils_default.isPlainObject(target) ? target : empty;
		let bases = copies.get(source);
		if (!bases) {
			bases = /* @__PURE__ */ new WeakMap();
			copies.set(source, bases);
		}
		if (bases.has(base)) return bases.get(base);
		const result = {};
		bases.set(base, result);
		pending.push({
			base,
			source,
			result
		});
		return result;
	}
	const result = utils_default.isUndefined(b) ? copy(void 0, a) : copy(a, b);
	while (pending.length) {
		const { base, source, result: target } = pending.pop();
		const baseKeys = new Set(ownEnumerableKeys(base));
		const sourceKeys = new Set(ownEnumerableKeys(source));
		(/* @__PURE__ */ new Set([...baseKeys, ...sourceKeys])).forEach((key) => {
			if (key === "__proto__" || key === "constructor" || key === "prototype") return;
			const hasSource = sourceKeys.has(key);
			const value = hasSource ? source[key] : void 0;
			const previous = (!hasSource || utils_default.isPlainObject(value)) && baseKeys.has(key) ? base[key] : void 0;
			target[key] = hasSource ? copy(previous, value) : copy(void 0, previous);
		});
	}
	assertParamsAcyclic(result);
	return result;
}
function getMergedValue(target, source, prop, caseless) {
	if (utils_default.isPlainObject(target) && utils_default.isPlainObject(source)) return utils_default.merge.call({ caseless }, target, source);
	else if (utils_default.isPlainObject(source)) return utils_default.merge({}, source);
	else if (utils_default.isArray(source)) return source.slice();
	return source;
}
function mergeDeepProperties(a, b, prop, caseless) {
	if (!utils_default.isUndefined(b)) return getMergedValue(a, b, prop, caseless);
	else if (!utils_default.isUndefined(a)) return getMergedValue(void 0, a, prop, caseless);
}
function valueFromConfig2(a, b) {
	if (!utils_default.isUndefined(b)) return getMergedValue(void 0, b);
}
function defaultToConfig2(a, b) {
	if (!utils_default.isUndefined(b)) return getMergedValue(void 0, b);
	else if (!utils_default.isUndefined(a)) return getMergedValue(void 0, a);
}
function getMergedTransitionalOption(config1, config2, prop) {
	const transitional2 = utils_default.hasOwnProp(config2, "transitional") ? config2.transitional : void 0;
	if (!utils_default.isUndefined(transitional2)) {
		if (utils_default.isPlainObject(transitional2)) {
			if (utils_default.hasOwnProp(transitional2, prop)) return transitional2[prop];
		} else return;
	}
	const transitional1 = utils_default.hasOwnProp(config1, "transitional") ? config1.transitional : void 0;
	if (utils_default.isPlainObject(transitional1) && utils_default.hasOwnProp(transitional1, prop)) return transitional1[prop];
}
function mergeDirectKeys(a, b, prop, config1, config2) {
	if (utils_default.hasOwnProp(config2, prop)) return getMergedValue(a, b);
	else if (utils_default.hasOwnProp(config1, prop)) return getMergedValue(void 0, a);
}
function mergeHeaders(a, b, prop) {
	return mergeDeepProperties(headersToObject(a), headersToObject(b), prop, true);
}
var hasOwnPropertyDescriptor = Object.freeze({
	__proto__: null,
	value: Object.prototype.hasOwnProperty,
	enumerable: false,
	writable: true,
	configurable: true
});
var mergeMap = {
	url: valueFromConfig2,
	method: valueFromConfig2,
	data: valueFromConfig2,
	baseURL: defaultToConfig2,
	transformRequest: defaultToConfig2,
	transformResponse: defaultToConfig2,
	params: mergeParams,
	paramsSerializer: defaultToConfig2,
	timeout: defaultToConfig2,
	timeoutErrorMessage: defaultToConfig2,
	withCredentials: defaultToConfig2,
	withXSRFToken: defaultToConfig2,
	adapter: defaultToConfig2,
	responseType: defaultToConfig2,
	xsrfCookieName: defaultToConfig2,
	xsrfHeaderName: defaultToConfig2,
	onUploadProgress: defaultToConfig2,
	onDownloadProgress: defaultToConfig2,
	decompress: defaultToConfig2,
	maxContentLength: defaultToConfig2,
	maxBodyLength: defaultToConfig2,
	beforeRedirect: defaultToConfig2,
	transport: defaultToConfig2,
	httpAgent: defaultToConfig2,
	httpsAgent: defaultToConfig2,
	cancelToken: defaultToConfig2,
	socketPath: defaultToConfig2,
	allowedSocketPaths: defaultToConfig2,
	responseEncoding: defaultToConfig2,
	validateStatus: mergeDirectKeys,
	headers: mergeHeaders
};
/**
* Config-specific merge-function which creates a new config-object
* by merging two configuration objects together.
*
* @param {Object} config1
* @param {Object} config2
*
* @returns {Object} New object resulting from merging config2 to config1
*/
function mergeConfig$1(config1, config2) {
	config1 = config1 || {};
	config2 = config2 || {};
	const config = Object.create(null);
	Object.defineProperty(config, "hasOwnProperty", hasOwnPropertyDescriptor);
	const keys = ownEnumerableKeys({
		...config1,
		...config2
	});
	for (let i = 0, len = keys.length; i < len; i++) {
		const prop = keys[i];
		if (prop === "__proto__" || prop === "constructor" || prop === "prototype") continue;
		const merge = utils_default.hasOwnProp(mergeMap, prop) ? mergeMap[prop] : mergeDeepProperties;
		const a = utils_default.hasOwnProp(config1, prop) ? config1[prop] : void 0;
		const b = utils_default.hasOwnProp(config2, prop) ? config2[prop] : void 0;
		const configValue = merge === mergeDirectKeys ? merge(a, b, prop, config1, config2) : merge(a, b, prop);
		utils_default.isUndefined(configValue) && merge !== mergeDirectKeys || (config[prop] = configValue);
	}
	if (utils_default.hasOwnProp(config2, "validateStatus") && utils_default.isUndefined(config2.validateStatus) && getMergedTransitionalOption(config1, config2, "validateStatusUndefinedResolves") === false) {
		if (utils_default.hasOwnProp(config1, "validateStatus")) config.validateStatus = getMergedValue(void 0, config1.validateStatus);
		else delete config.validateStatus;
	}
	return config;
}
// node_modules/axios/lib/core/setFormDataHeaders.js
var FORM_DATA_CONTENT_HEADERS = ["content-type", "content-length"];
/**
* Apply the headers generated by a FormData implementation to the request headers,
* honoring the `formDataHeaderPolicy` option: with 'content-only', copy only the
* content-* headers; otherwise merge all of them.
*
* @param {AxiosHeaders} headers - the request headers to mutate
* @param {Object | null | undefined} formHeaders - headers produced by the FormData implementation
* @param {String} [policy] - the resolved `formDataHeaderPolicy` config value
*
* @returns {void}
*/
function setFormDataHeaders(headers, formHeaders, policy) {
	if (policy !== "content-only") {
		headers.set(formHeaders);
		return;
	}
	Object.entries(formHeaders || {}).forEach(([key, val]) => {
		if (FORM_DATA_CONTENT_HEADERS.includes(key.toLowerCase())) headers.set(key, val);
	});
}
// node_modules/axios/lib/helpers/resolveConfig.js
/**
* Encode a UTF-8 string to a Latin-1 byte string for use with btoa().
* This is a modern replacement for the deprecated unescape(encodeURIComponent(str)) pattern.
*
* @param {string} str The string to encode
*
* @returns {string} UTF-8 bytes as a Latin-1 string
*/
var encodeUTF8$1 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
var readCookie = (name) => cookies_default.read(name);
function resolveConfig(config, readXsrfCookie = readCookie) {
	const newConfig = mergeConfig$1({}, config);
	const own = (key) => utils_default.hasOwnProp(newConfig, key) ? newConfig[key] : void 0;
	const data = own("data");
	let withXSRFToken = own("withXSRFToken");
	const xsrfHeaderName = own("xsrfHeaderName");
	const xsrfCookieName = own("xsrfCookieName");
	let headers = own("headers");
	const auth = own("auth");
	const baseURL = own("baseURL");
	const allowAbsoluteUrls = own("allowAbsoluteUrls");
	const url = own("url");
	newConfig.headers = headers = AxiosHeaders$1.from(headers);
	newConfig.url = buildURL(buildFullPath(baseURL, url, allowAbsoluteUrls, newConfig), own("params"), own("paramsSerializer"));
	if (auth) {
		const username = utils_default.getSafeProp(auth, "username") || "";
		const password = utils_default.getSafeProp(auth, "password") || "";
		const transitional = own("transitional");
		const encodeUsername = transitional && utils_default.hasOwnProp(transitional, "encodeBasicAuthUsername") && transitional.encodeBasicAuthUsername === true;
		try {
			headers.set("Authorization", "Basic " + btoa((encodeUsername ? encodeUTF8$1(username) : username) + ":" + (password ? encodeUTF8$1(password) : "")));
		} catch (e) {
			throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_OPTION_VALUE, config);
		}
	}
	if (utils_default.isFormData(data)) {
		const getHeaders = utils_default.getSafeProp(data, "getHeaders");
		if (platform_default.hasStandardBrowserEnv || platform_default.hasStandardBrowserWebWorkerEnv || utils_default.isReactNative(data)) headers.setContentType(void 0);
		else if (utils_default.isFunction(getHeaders)) setFormDataHeaders(headers, getHeaders.call(data), own("formDataHeaderPolicy"));
	}
	if (platform_default.hasStandardBrowserEnv) {
		if (utils_default.isFunction(withXSRFToken)) withXSRFToken = withXSRFToken(newConfig);
		if (withXSRFToken === true || withXSRFToken == null && isURLSameOrigin_default(newConfig.url)) {
			const xsrfValue = xsrfHeaderName && xsrfCookieName && readXsrfCookie(xsrfCookieName);
			if (xsrfValue) headers.set(xsrfHeaderName, xsrfValue);
		}
	}
	return newConfig;
}
var xhr_default = typeof XMLHttpRequest !== "undefined" && function(config) {
	return new Promise(function dispatchXhrRequest(resolve, reject) {
		let useAsyncXsrf;
		try {
			const store = platform_default.hasStandardBrowserEnv && typeof window !== "undefined" && window.cookieStore;
			useAsyncXsrf = store && utils_default.isFunction(store.get);
		} catch (e) {}
		let xsrfCookieName;
		const _config = resolveConfig(config, useAsyncXsrf ? (name) => {
			xsrfCookieName = name;
			return null;
		} : void 0);
		let requestData = _config.data;
		const requestHeaders = AxiosHeaders$1.from(_config.headers).normalize();
		let { responseType, onUploadProgress, onDownloadProgress } = _config;
		let onCanceled;
		let timeoutId;
		let uploadThrottled, downloadThrottled;
		let flushUpload, flushDownload, flushDownloadWithEvent;
		function done() {
			clearTimeout(timeoutId);
			try {
				flushUpload && flushUpload();
			} catch (err) {
				setTimeout(() => {
					throw err;
				});
			}
			try {
				flushDownload && flushDownload();
			} catch (err) {
				setTimeout(() => {
					throw err;
				});
			}
			if (request) {
				downloadThrottled && request.removeEventListener("progress", downloadThrottled);
				if (request.upload) {
					uploadThrottled && request.upload.removeEventListener("progress", uploadThrottled);
					flushUpload && request.upload.removeEventListener("loadend", flushUpload);
				}
			}
			_config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
			_config.signal && _config.signal.removeEventListener("abort", onCanceled);
		}
		let request = new XMLHttpRequest();
		request.open(_config.method.toUpperCase(), _config.url, true);
		request.timeout = _config.timeout;
		function onloadend(event) {
			if (!request) return;
			if (request.status === 0 && (parseProtocol(normalizeURLForProtocolCheck(_config.url)) || parseProtocol(platform_default.origin)) !== "file" && !(request.responseURL && request.responseURL.startsWith("file:"))) {
				reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config, request));
				done();
				request = null;
				return;
			}
			try {
				if (event) flushDownloadWithEvent && flushDownloadWithEvent(event);
				else flushDownload && flushDownload();
			} catch (err) {
				setTimeout(() => {
					throw err;
				});
			}
			if (!request) return;
			const responseHeaders = AxiosHeaders$1.from("getAllResponseHeaders" in request && request.getAllResponseHeaders());
			settle(function _resolve(value) {
				resolve(value);
				done();
			}, function _reject(err) {
				reject(err);
				done();
			}, {
				data: !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response,
				status: request.status,
				statusText: request.statusText,
				headers: responseHeaders,
				config,
				request
			});
			request = null;
		}
		if ("onloadend" in request) request.onloadend = onloadend;
		else request.onreadystatechange = function handleLoad() {
			if (!request || request.readyState !== 4) return;
			if (request.status === 0 && !(request.responseURL && request.responseURL.startsWith("file:"))) return;
			setTimeout(onloadend);
		};
		request.onabort = function handleAbort() {
			if (!request) return;
			reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config, request));
			done();
			request = null;
		};
		request.onerror = function handleError(event) {
			const err = new AxiosError$1(event && event.message ? event.message : "Network Error", AxiosError$1.ERR_NETWORK, config, request);
			err.event = event || null;
			reject(err);
			done();
			request = null;
		};
		request.ontimeout = function handleTimeout() {
			if (!request) return;
			let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
			const transitional = _config.transitional || transitional_default;
			if (_config.timeoutErrorMessage) timeoutErrorMessage = _config.timeoutErrorMessage;
			reject(new AxiosError$1(timeoutErrorMessage, transitional.clarifyTimeoutError ? AxiosError$1.ETIMEDOUT : AxiosError$1.ECONNABORTED, config, request));
			done();
			request = null;
		};
		requestData === void 0 && requestHeaders.setContentType(null);
		if (!utils_default.isUndefined(_config.withCredentials)) request.withCredentials = !!_config.withCredentials;
		if (responseType && responseType !== "json") request.responseType = _config.responseType;
		if (onDownloadProgress) {
			[downloadThrottled, flushDownload, flushDownloadWithEvent] = progressEventReducer(onDownloadProgress, true);
			request.addEventListener("progress", downloadThrottled);
		}
		if (onUploadProgress && request.upload) {
			[uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
			request.upload.addEventListener("progress", uploadThrottled);
			request.upload.addEventListener("loadend", flushUpload);
		}
		if (_config.cancelToken || _config.signal) {
			onCanceled = (cancel) => {
				if (!request) return;
				reject(!cancel || cancel.type ? new CanceledError$1(null, config, request) : cancel);
				const xhr = request;
				done();
				request = null;
				xhr.abort();
			};
			_config.cancelToken && _config.cancelToken.subscribe(onCanceled);
			if (!request) return;
			if (_config.signal) _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
		}
		if (!request) return;
		const protocol = parseProtocol(_config.url);
		if (protocol && !platform_default.protocols.includes(protocol)) {
			reject(new AxiosError$1("Unsupported protocol " + protocol + ":", AxiosError$1.ERR_BAD_REQUEST, config));
			done();
			return;
		}
		const sendRequest = () => {
			if (!request) return;
			if ("setRequestHeader" in request) utils_default.forEach(toByteStringHeaderObject(requestHeaders), function setRequestHeader(val, key) {
				request.setRequestHeader(key, val);
			});
			request.send(requestData || null);
		};
		if (xsrfCookieName) {
			const now = typeof performance !== "undefined" && utils_default.isFunction(performance.now) ? () => performance.now() : Date.now;
			const deadline = request.timeout > 0 ? now() + Number(request.timeout) : void 0;
			const abortOnTimeout = () => {
				if (!request) return;
				const xhr = request;
				xhr.ontimeout();
				xhr.abort();
			};
			if (deadline !== void 0) {
				const scheduleTimeout = () => {
					const remaining = deadline - now();
					if (remaining > 0) timeoutId = setTimeout(scheduleTimeout, Math.min(remaining, 2147483647));
					else abortOnTimeout();
				};
				scheduleTimeout();
			}
			cookies_default.readAsync(xsrfCookieName).then((value) => {
				if (!request) return;
				if (deadline !== void 0 && now() >= deadline) {
					abortOnTimeout();
					return;
				}
				if (value) {
					const headerName = utils_default.hasOwnProp(_config, "xsrfHeaderName") && _config.xsrfHeaderName;
					requestHeaders.set(headerName, value);
				}
				sendRequest();
			}).catch((error) => {
				if (!request) return;
				reject(AxiosError$1.from(error, null, config, request));
				done();
				request = null;
			});
		} else sendRequest();
	});
};
// node_modules/axios/lib/helpers/composeSignals.js
var composeSignals = (signals, timeout) => {
	signals = signals ? signals.filter(Boolean) : [];
	if (!timeout && !signals.length) return;
	const controller = new AbortController();
	let aborted = false;
	const onabort = function(reason) {
		if (!aborted) {
			aborted = true;
			unsubscribe();
			const err = reason instanceof Error ? reason : this.reason;
			controller.abort(err instanceof AxiosError$1 ? err : new CanceledError$1(err instanceof Error ? err.message : err));
		}
	};
	let timer = timeout && setTimeout(() => {
		timer = null;
		onabort(new AxiosError$1(`timeout of ${timeout}ms exceeded`, AxiosError$1.ETIMEDOUT));
	}, timeout);
	const unsubscribe = () => {
		if (!signals) return;
		timer && clearTimeout(timer);
		timer = null;
		signals.forEach((signal) => {
			const unsubscribeSignal = utils_default.getSafeProp(signal, "unsubscribe");
			utils_default.isFunction(unsubscribeSignal) ? unsubscribeSignal.call(signal, onabort) : signal.removeEventListener("abort", onabort);
		});
		signals = null;
	};
	signals.forEach((signal) => {
		if (aborted) return;
		if (signal.aborted) {
			onabort.call(signal);
			return;
		}
		signal.addEventListener("abort", onabort, { once: true });
	});
	const { signal } = controller;
	signal.unsubscribe = () => utils_default.asap(unsubscribe);
	return signal;
};
// node_modules/axios/lib/helpers/trackStream.js
var streamChunk = function* (chunk, chunkSize) {
	let len = chunk.byteLength;
	if (!chunkSize || len < chunkSize) {
		yield chunk;
		return;
	}
	let pos = 0;
	let end;
	while (pos < len) {
		end = pos + chunkSize;
		yield chunk.slice(pos, end);
		pos = end;
	}
};
var readBytes = async function* (iterable, chunkSize) {
	for await (const chunk of readStream(iterable)) yield* streamChunk(chunk, chunkSize);
};
var readStream = async function* (stream) {
	if (stream[Symbol.asyncIterator]) {
		yield* stream;
		return;
	}
	const reader = stream.getReader();
	try {
		for (;;) {
			const { done, value } = await reader.read();
			if (done) break;
			yield value;
		}
	} finally {
		await reader.cancel();
	}
};
var trackStream = (stream, chunkSize, onProgress, onFinish) => {
	const iterator = readBytes(stream, chunkSize);
	let bytes = 0;
	let done;
	let _onFinish = (e) => {
		if (!done) {
			done = true;
			onFinish && onFinish(e);
		}
	};
	return new ReadableStream({
		async pull(controller) {
			try {
				const { done, value } = await iterator.next();
				if (done) {
					_onFinish();
					controller.close();
					return;
				}
				let len = value.byteLength;
				if (onProgress) onProgress(bytes += len);
				controller.enqueue(new Uint8Array(value));
			} catch (err) {
				_onFinish(err);
				throw err;
			}
		},
		cancel(reason) {
			_onFinish(reason);
			return iterator.return();
		}
	}, { highWaterMark: 2 });
};
// node_modules/axios/lib/helpers/formDataToBlob.js
var CRLF = "\r\n";
var normalizeLines = (value) => String(value).replace(/\r\n|\r|\n/g, CRLF);
var escapeName = (value) => String(value).replace(/[\r\n"]/g, (char) => char === "\r" ? "%0D" : char === "\n" ? "%0A" : "%22");
var stringBytes = (value, normalize) => {
	let length = 0;
	for (let i = 0; i < value.length; i++) {
		const code = value.charCodeAt(i);
		if (normalize && (code === 13 || code === 10)) {
			if (code === 13 && value.charCodeAt(i + 1) === 10) i++;
			length += 2;
		} else if (code < 128) length++;
		else if (code < 2048) length += 2;
		else if (code >= 55296 && code <= 56319 && value.charCodeAt(i + 1) >= 56320 && value.charCodeAt(i + 1) <= 57343) {
			length += 4;
			i++;
		} else length += 3;
	}
	return length;
};
var FormDataError = class extends TypeError {
	constructor(message, reason) {
		super(message);
		this.name = "FormDataError";
		this.reason = reason;
	}
};
function formDataToBlob(form, Blob, limit, limitError, boundary) {
	if (!utils_default.isFunction(Blob)) throw new FormDataError("Blob is not supported", "blob");
	if (!utils_default.isString(boundary) || !/^[A-Za-z0-9'()+_,./:=? -]{1,70}$/.test(boundary) || / $/.test(boundary)) throw new FormDataError("Invalid multipart boundary", "boundary");
	const footer = "--" + boundary + "--\r\n";
	let length = footer.length;
	const parts = [];
	const checkLength = (extra) => {
		if (length + extra > limit) throw limitError();
	};
	checkLength(0);
	for (const [name, value] of form) {
		const isString = utils_default.isString(value);
		const valueLength = isString ? stringBytes(value, true) : value.size;
		if (!Number.isFinite(valueLength) || valueLength < 0) throw new FormDataError("Unsupported FormData part size", "part");
		checkLength(valueLength + stringBytes(name, true) + (!isString && value.name ? stringBytes(value.name, false) : 0) + (!isString && value.type ? stringBytes(value.type, false) : 0));
		let header = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + escapeName(normalizeLines(name)) + "\"";
		if (!isString) header += "; filename=\"" + escapeName(utils_default.isString(value.name) ? value.name : "blob") + "\"\r\nContent-Type: " + String(value.type || "application/octet-stream").replace(/[\r\n]/g, "");
		header += "\r\n\r\n";
		const partLength = stringBytes(header, false) + valueLength + 2;
		checkLength(partLength);
		length += partLength;
		parts.push({
			header,
			value,
			isString
		});
	}
	const blobParts = [];
	for (const part of parts) blobParts.push(part.header, part.isString ? normalizeLines(part.value) : part.value, CRLF);
	blobParts.push(footer);
	return new Blob(blobParts, { type: "multipart/form-data; boundary=" + boundary });
}
// node_modules/axios/lib/core/createMultipartBody.js
function createMultipartBody(form, Blob, limit, limitError, boundary) {
	if (!utils_default.isFunction(Blob)) throw new AxiosError$1("Blob is not supported", AxiosError$1.ERR_NOT_SUPPORT);
	if (boundary === void 0) {
		if (utils_default.isFunction(platform_default.generateString)) boundary = "axios-" + platform_default.generateString(36, "0123456789abcdef");
		else {
			const crypto = utils_default.global.crypto;
			if (!crypto || !utils_default.isFunction(crypto.getRandomValues)) throw new AxiosError$1("Random byte generation is not supported", AxiosError$1.ERR_NOT_SUPPORT);
			const random = /* @__PURE__ */ new Uint8Array(18);
			crypto.getRandomValues(random);
			boundary = "axios-" + Array.from(random, (value) => ("0" + value.toString(16)).slice(-2)).join("");
		}
	}
	try {
		return formDataToBlob(form, Blob, limit, limitError, boundary);
	} catch (error) {
		if (error instanceof FormDataError) {
			const code = error.reason === "boundary" ? AxiosError$1.ERR_BAD_OPTION_VALUE : AxiosError$1.ERR_BAD_REQUEST;
			throw new AxiosError$1(error.message, code);
		}
		throw error;
	}
}
// node_modules/axios/lib/helpers/estimateDataURLDecodedBytes.js
/**
* Estimate data: URL byte lengths *without* allocating large buffers.
* - Fetch percent-decodes a base64 body before decoding it.
* - Node's Buffer.from(body, 'base64') sizes its backing allocation from the
*   percent-decoded body, including ignored characters and content after padding.
* - Non-base64 data is percent-decoded and then encoded as UTF-8.
*/
var isHexDigit = (charCode) => charCode >= 48 && charCode <= 57 || charCode >= 65 && charCode <= 70 || charCode >= 97 && charCode <= 102;
var isPercentEncodedByte = (str, i, len) => i + 2 < len && isHexDigit(str.charCodeAt(i + 1)) && isHexDigit(str.charCodeAt(i + 2));
var hexValue = (charCode) => charCode <= 57 ? charCode - 48 : (charCode & 223) - 55;
var isBase64Char = (charCode) => charCode >= 65 && charCode <= 90 || charCode >= 97 && charCode <= 122 || charCode >= 48 && charCode <= 57 || charCode === 43 || charCode === 47 || charCode === 45 || charCode === 95;
var isBase64Whitespace = (charCode) => charCode === 9 || charCode === 10 || charCode === 12 || charCode === 13 || charCode === 32;
var base64Bytes = (significant) => {
	const groups = Math.floor(significant / 4);
	const remainder = significant % 4;
	return groups * 3 + (remainder === 2 ? 1 : remainder === 3 ? 2 : 0);
};
var estimateBase64BufferAllocation = (body) => {
	const len = body.length;
	let padding = 0;
	if (len > 0 && body.charCodeAt(len - 1) === 61) {
		padding++;
		if (len > 1 && body.charCodeAt(len - 2) === 61) padding++;
	}
	return Math.floor((len - padding) * 3 / 4);
};
var estimatePercentDecodedBase64Bytes = (body) => {
	const len = body.length;
	let significant = 0;
	let padding = 0;
	let invalid = false;
	for (let i = 0; i < len; i++) {
		let code = body.charCodeAt(i);
		if (code === 37 && isPercentEncodedByte(body, i, len)) {
			code = hexValue(body.charCodeAt(i + 1)) * 16 + hexValue(body.charCodeAt(i + 2));
			i += 2;
		}
		if (isBase64Whitespace(code)) continue;
		if (code === 61) {
			padding++;
			continue;
		}
		if (!isBase64Char(code) || padding > 0) {
			invalid = true;
			continue;
		}
		significant++;
	}
	if (invalid || padding > 2 || padding > 0 && (significant + padding) % 4 !== 0 || significant % 4 === 1) return estimateBase64BufferAllocation(body);
	return base64Bytes(significant);
};
var estimateDataURLBytes = (url, estimateBase64, base64Pattern) => {
	if (!url || typeof url !== "string") return 0;
	if (!/^data:/i.test(url)) return 0;
	const comma = url.indexOf(",");
	if (comma < 0) return 0;
	const meta = url.slice(5, comma);
	const body = url.slice(comma + 1);
	if (base64Pattern.test(meta)) return estimateBase64(body);
	let bytes = 0;
	for (let i = 0, len = body.length; i < len; i++) {
		const c = body.charCodeAt(i);
		if (c === 37 && isPercentEncodedByte(body, i, len)) {
			bytes += 1;
			i += 2;
		} else if (c < 128) bytes += 1;
		else if (c < 2048) bytes += 2;
		else if (c >= 55296 && c <= 56319 && i + 1 < len) {
			const next = body.charCodeAt(i + 1);
			if (next >= 56320 && next <= 57343) {
				bytes += 4;
				i++;
			} else bytes += 3;
		} else bytes += 3;
	}
	return bytes;
};
/**
* Estimate the percent-decoded payload size used by Fetch data: URLs.
*
* @param {string} url
* @returns {number}
*/
function estimateDataURLDecodedBytes(url) {
	const fragmentIndex = typeof url === "string" ? url.indexOf("#") : -1;
	return estimateDataURLBytes(fragmentIndex === -1 ? url : url.slice(0, fragmentIndex), estimatePercentDecodedBase64Bytes, /; *base64[\t\n\f\r ]*$/i);
}
// node_modules/axios/lib/env/data.js
var VERSION$1 = "1.21.0";
// node_modules/axios/lib/adapters/fetch.js
var DEFAULT_CHUNK_SIZE = 65536;
var DEFAULT_REQUEST_OPTIONS = {
	cache: "default",
	redirect: "follow",
	referrer: "about:client",
	referrerPolicy: "",
	mode: "cors",
	integrity: "",
	keepalive: false,
	priority: "auto",
	window: null
};
var { isFunction } = utils_default;
/**
* Encode a UTF-8 string to a Latin-1 byte string for use with btoa().
* This is a modern replacement for the deprecated unescape(encodeURIComponent(str)) pattern.
*
* @param {string} str The string to encode
*
* @returns {string} UTF-8 bytes as a Latin-1 string
*/
var encodeUTF8 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
var decodeURIComponentSafe = (value) => {
	if (!utils_default.isString(value)) return value;
	try {
		return decodeURIComponent(value);
	} catch (error) {
		return value;
	}
};
var test = (fn, ...args) => {
	try {
		return !!fn(...args);
	} catch (e) {
		return false;
	}
};
var maybeWithAuthCredentials = (url) => {
	const protocolIndex = url.indexOf("://");
	let urlToCheck = url;
	if (protocolIndex !== -1) urlToCheck = urlToCheck.slice(protocolIndex + 3);
	return urlToCheck.includes("@") || urlToCheck.includes(":");
};
var factory = (env) => {
	const globalObject = utils_default.global !== void 0 && utils_default.global !== null ? utils_default.global : globalThis;
	const { ReadableStream, TextEncoder } = globalObject;
	env = utils_default.merge.call({ skipUndefined: true }, {
		Request: globalObject.Request,
		Response: globalObject.Response,
		Blob: globalObject.Blob
	}, env);
	const envFetch = utils_default.hasOwnProp(env, "fetch") ? env.fetch : void 0;
	const { Request, Response, Blob } = env;
	const isFetchSupported = envFetch ? isFunction(envFetch) : typeof fetch === "function";
	const isRequestSupported = isFunction(Request);
	const isResponseSupported = isFunction(Response);
	if (!isFetchSupported) return false;
	const isReadableStreamSupported = isFetchSupported && isFunction(ReadableStream);
	const encodeText = isFetchSupported && (typeof TextEncoder === "function" ? ((encoder) => (str) => encoder.encode(str))(new TextEncoder()) : async (str) => new Uint8Array(await new Request(str).arrayBuffer()));
	const supportsRequestStream = isRequestSupported && isReadableStreamSupported && test(() => {
		let duplexAccessed = false;
		const request = new Request(platform_default.origin, {
			body: new ReadableStream(),
			method: "POST",
			get duplex() {
				duplexAccessed = true;
				return "half";
			}
		});
		const hasContentType = request.headers.has("Content-Type");
		if (request.body != null) request.body.cancel();
		return duplexAccessed && !hasContentType;
	});
	const supportsResponseStream = isResponseSupported && isReadableStreamSupported && test(() => utils_default.isReadableStream(new Response("").body));
	const requestDefaults = Object.assign(Object.create(null), DEFAULT_REQUEST_OPTIONS);
	if (isRequestSupported && !test(() => new Request(platform_default.origin, requestDefaults))) {
		delete requestDefaults.cache;
		if (!test(() => new Request(platform_default.origin, requestDefaults))) requestDefaults.cache = DEFAULT_REQUEST_OPTIONS.cache;
	}
	const resolvers = { stream: supportsResponseStream && ((res) => res.body) };
	isFetchSupported && (() => {
		[
			"text",
			"arrayBuffer",
			"blob",
			"formData",
			"stream"
		].forEach((type) => {
			!resolvers[type] && (resolvers[type] = (res, config) => {
				let method = res && res[type];
				if (method) return method.call(res);
				throw new AxiosError$1(`Response type '${type}' is not supported`, AxiosError$1.ERR_NOT_SUPPORT, config);
			});
		});
	})();
	const getBodyLength = async (body) => {
		if (body == null) return 0;
		if (utils_default.isBlob(body)) return body.size;
		if (utils_default.isArrayBufferView(body) || utils_default.isArrayBuffer(body)) return body.byteLength;
		if (utils_default.isURLSearchParams(body)) body = body + "";
		if (utils_default.isString(body)) return (await encodeText(body)).byteLength;
	};
	const resolveBodyLength = async (headers, body) => {
		const length = utils_default.toFiniteNumber(headers.getContentLength());
		return length == null ? getBodyLength(body) : length;
	};
	return async (config) => {
		let { url, method, data, signal, cancelToken, timeout, onDownloadProgress, onUploadProgress, responseType, headers, withCredentials = "same-origin", fetchOptions, maxContentLength, maxBodyLength, maxRedirects } = resolveConfig(config);
		const hasMaxContentLength = utils_default.isNumber(maxContentLength) && maxContentLength > -1;
		const hasMaxBodyLength = utils_default.isNumber(maxBodyLength) && maxBodyLength > -1;
		const own = (key) => utils_default.hasOwnProp(config, key) ? config[key] : void 0;
		let _fetch = envFetch || fetch;
		responseType = responseType ? (responseType + "").toLowerCase() : "text";
		let composedSignal = composeSignals([signal, cancelToken && cancelToken.toAbortSignal()], timeout);
		let request = null;
		const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
			composedSignal.unsubscribe();
		});
		let requestContentLength;
		let pendingBodyError = null;
		let pendingResponseError = null;
		const maxBodyLengthError = () => new AxiosError$1("Request body larger than maxBodyLength limit", AxiosError$1.ERR_BAD_REQUEST, config, request);
		try {
			let auth = void 0;
			const configAuth = own("auth");
			if (configAuth) auth = {
				username: utils_default.getSafeProp(configAuth, "username") || "",
				password: utils_default.getSafeProp(configAuth, "password") || ""
			};
			let parsedURL;
			if (maybeWithAuthCredentials(url)) {
				parsedURL = new URL(url, platform_default.origin);
				if (!auth && (parsedURL.username || parsedURL.password)) auth = {
					username: decodeURIComponentSafe(parsedURL.username),
					password: decodeURIComponentSafe(parsedURL.password)
				};
				if (parsedURL.username || parsedURL.password) {
					parsedURL.username = "";
					parsedURL.password = "";
					url = parsedURL.href;
				}
			}
			if (auth) {
				headers.delete("authorization");
				headers.set("Authorization", "Basic " + btoa(encodeUTF8((auth.username || "") + ":" + (auth.password || ""))));
			}
			if (hasMaxContentLength && parsedURL && parsedURL.protocol === "data:") {
				if (estimateDataURLDecodedBytes(parsedURL.href) > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			const formContentType = utils_default.isSpecCompliantForm(data) && AxiosHeaders$1.from(own("headers")).getContentType();
			let formBoundary;
			if (utils_default.isString(formContentType) && /^multipart\/form-data(?:\s*;|$)/i.test(formContentType.trim())) {
				const parameters = AxiosHeaders$1.parseParameters(formContentType);
				if (utils_default.hasOwnProp(parameters, "boundary")) formBoundary = parameters.boundary;
			}
			if (utils_default.isSpecCompliantForm(data) && method !== "get" && method !== "head" && (hasMaxBodyLength || onUploadProgress && supportsRequestStream || formBoundary !== void 0)) {
				data = createMultipartBody(data, Blob, hasMaxBodyLength ? maxBodyLength : Infinity, maxBodyLengthError, formBoundary);
				headers.setContentType(formBoundary === void 0 ? data.type : formContentType);
				requestContentLength = data.size;
			}
			if (hasMaxBodyLength && method !== "get" && method !== "head") {
				const outboundLength = await getBodyLength(data);
				if (typeof outboundLength === "number" && isFinite(outboundLength)) {
					requestContentLength = outboundLength;
					if (outboundLength > maxBodyLength) throw maxBodyLengthError();
				}
			}
			const mustEnforceStreamBody = hasMaxBodyLength && (utils_default.isReadableStream(data) || utils_default.isStream(data));
			const trackRequestStream = (stream, onProgress, flush) => trackStream(stream, DEFAULT_CHUNK_SIZE, (loadedBytes) => {
				if (hasMaxBodyLength && loadedBytes > maxBodyLength) throw pendingBodyError = maxBodyLengthError();
				onProgress && onProgress(loadedBytes);
			}, flush);
			if (supportsRequestStream && method !== "get" && method !== "head" && (onUploadProgress || mustEnforceStreamBody)) {
				requestContentLength = requestContentLength == null ? await resolveBodyLength(headers, data) : requestContentLength;
				if (requestContentLength !== 0 || mustEnforceStreamBody) {
					let _request = new Request(url, {
						method: "POST",
						body: data,
						duplex: "half"
					});
					let contentTypeHeader;
					if (utils_default.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) headers.setContentType(contentTypeHeader);
					if (_request.body) {
						const [onProgress, flush] = onUploadProgress && progressEventDecorator(requestContentLength, progressEventReducer(asyncDecorator(onUploadProgress))) || [];
						data = trackRequestStream(_request.body, onProgress, flush);
					}
				}
			} else if (mustEnforceStreamBody && !isRequestSupported && isReadableStreamSupported && method !== "get" && method !== "head") data = trackRequestStream(data);
			else if (mustEnforceStreamBody && isRequestSupported && !supportsRequestStream && method !== "get" && method !== "head") throw new AxiosError$1("Stream request bodies are not supported by the current fetch implementation", AxiosError$1.ERR_NOT_SUPPORT, config, request);
			if (!utils_default.isString(withCredentials)) withCredentials = withCredentials ? "include" : "omit";
			const isCredentialsSupported = isRequestSupported && "credentials" in Request.prototype;
			if (utils_default.isFormData(data)) {
				const contentType = headers.getContentType();
				if (contentType && /^multipart\/form-data/i.test(contentType) && !/boundary=/i.test(contentType)) headers.delete("content-type");
			}
			headers.set("User-Agent", "axios/" + VERSION$1, false);
			const safeFetchOptions = fetchOptions == null ? fetchOptions : Object.assign(Object.create(null), fetchOptions);
			if (safeFetchOptions) {
				delete safeFetchOptions.body;
				delete safeFetchOptions.headers;
				delete safeFetchOptions.method;
				delete safeFetchOptions.signal;
				delete safeFetchOptions.duplex;
				delete safeFetchOptions.credentials;
			}
			const resolvedOptions = Object.assign(Object.create(null), safeFetchOptions, {
				signal: composedSignal,
				method: method.toUpperCase(),
				headers: toByteStringHeaderObject(headers.normalize()),
				body: data,
				duplex: "half",
				credentials: isCredentialsSupported ? withCredentials : void 0
			});
			if (isRequestSupported) {
				utils_default.forEach(requestDefaults, (value, key) => {
					if (resolvedOptions[key] === void 0) resolvedOptions[key] = value;
				});
				if (resolvedOptions.signal === void 0) resolvedOptions.signal = null;
				if (resolvedOptions.body === void 0) resolvedOptions.body = null;
			}
			if (maxRedirects === 0) {
				resolvedOptions.redirect = "manual";
				if (safeFetchOptions) safeFetchOptions.redirect = "manual";
			}
			request = isRequestSupported && new Request(url, resolvedOptions);
			let response = await (isRequestSupported ? _fetch(request, safeFetchOptions) : _fetch(url, resolvedOptions));
			const responseHeaders = AxiosHeaders$1.from(response.headers);
			if (hasMaxContentLength) {
				const declaredLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
				if (declaredLength != null && declaredLength > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
			if (supportsResponseStream && response.body && (onDownloadProgress || hasMaxContentLength || isStreamResponse && unsubscribe)) {
				const options = {};
				[
					"status",
					"statusText",
					"headers"
				].forEach((prop) => {
					options[prop] = response[prop];
				});
				const responseContentLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
				const [onProgress, flush] = onDownloadProgress && progressEventDecorator(responseContentLength, progressEventReducer(asyncDecorator(onDownloadProgress), true)) || [];
				let bytesRead = 0;
				const onChunkProgress = (loadedBytes) => {
					if (hasMaxContentLength) {
						bytesRead = loadedBytes;
						if (bytesRead > maxContentLength) throw pendingResponseError = new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
					}
					onProgress && onProgress(loadedBytes);
				};
				response = new Response(trackStream(response.body, DEFAULT_CHUNK_SIZE, onChunkProgress, () => {
					flush && flush();
					unsubscribe && unsubscribe();
				}), options);
			}
			responseType = responseType || "text";
			let responseData = await resolvers[utils_default.findKey(resolvers, responseType) || "text"](response, config);
			if (hasMaxContentLength && !supportsResponseStream && !isStreamResponse) {
				let materializedSize;
				if (responseData != null) {
					if (typeof responseData.byteLength === "number") materializedSize = responseData.byteLength;
					else if (typeof responseData.size === "number") materializedSize = responseData.size;
					else if (typeof responseData === "string") materializedSize = typeof TextEncoder === "function" ? new TextEncoder().encode(responseData).byteLength : responseData.length;
				}
				if (typeof materializedSize === "number" && materializedSize > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			!isStreamResponse && unsubscribe && unsubscribe();
			return await new Promise((resolve, reject) => {
				settle(resolve, reject, {
					data: responseData,
					headers: AxiosHeaders$1.from(response.headers),
					status: response.status,
					statusText: response.statusText,
					config,
					request
				});
			});
		} catch (err) {
			unsubscribe && unsubscribe();
			if (composedSignal && composedSignal.aborted && composedSignal.reason instanceof AxiosError$1) {
				const canceledError = composedSignal.reason;
				canceledError.config = config;
				request && (canceledError.request = request);
				if (err !== canceledError) Object.defineProperty(canceledError, "cause", {
					__proto__: null,
					value: err,
					writable: true,
					enumerable: false,
					configurable: true
				});
				throw canceledError;
			}
			if (pendingBodyError) {
				request && !pendingBodyError.request && (pendingBodyError.request = request);
				throw pendingBodyError;
			}
			if (pendingResponseError) throw pendingResponseError;
			if (err instanceof AxiosError$1) {
				request && !err.request && (err.request = request);
				throw err;
			}
			if (err && err.name === "TypeError" && /Load failed|fetch/i.test(err.message)) {
				const networkError = new AxiosError$1("Network Error", AxiosError$1.ERR_NETWORK, config, request, err && err.response);
				Object.defineProperty(networkError, "cause", {
					__proto__: null,
					value: err.cause || err,
					writable: true,
					enumerable: false,
					configurable: true
				});
				throw networkError;
			}
			throw AxiosError$1.from(err, err && err.code, config, request, err && err.response);
		}
	};
};
var seedCache = /* @__PURE__ */ new Map();
var getFetch = (config) => {
	const env = Object.create(null);
	const configuredEnv = config && utils_default.hasOwnProp(config, "env") && config.env;
	[
		"fetch",
		"Request",
		"Response",
		"Blob"
	].forEach((key) => {
		if (configuredEnv && utils_default.hasOwnProp(configuredEnv, key)) env[key] = configuredEnv[key];
	});
	const { fetch, Request, Response, Blob } = env;
	const seeds = [
		Request,
		Response,
		fetch,
		Blob
	];
	let i = seeds.length, seed, target, map = seedCache;
	while (i--) {
		seed = seeds[i];
		target = map.get(seed);
		target === void 0 && map.set(seed, target = i ? /* @__PURE__ */ new Map() : factory(env));
		map = target;
	}
	return target;
};
getFetch();
// node_modules/axios/lib/adapters/adapters.js
/**
* Known adapters mapping.
* Provides environment-specific adapters for Axios:
* - `http` for Node.js
* - `xhr` for browsers
* - `fetch` for fetch API-based requests
*
* @type {Object<string, Function|Object>}
*/
var knownAdapters = {
	http: null,
	xhr: xhr_default,
	fetch: { get: getFetch }
};
utils_default.forEach(knownAdapters, (fn, value) => {
	if (fn) {
		try {
			Object.defineProperty(fn, "name", {
				__proto__: null,
				value
			});
		} catch (e) {}
		Object.defineProperty(fn, "adapterName", {
			__proto__: null,
			value
		});
	}
});
/**
* Render a rejection reason string for unknown or unsupported adapters
*
* @param {string} reason
* @returns {string}
*/
var renderReason = (reason) => `- ${reason}`;
/**
* Check if the adapter is resolved (function, null, or false)
*
* @param {Function|null|false} adapter
* @returns {boolean}
*/
var isResolvedHandle = (adapter) => utils_default.isFunction(adapter) || adapter === null || adapter === false;
/**
* Get the first suitable adapter from the provided list.
* Tries each adapter in order until a supported one is found.
* Throws an AxiosError if no adapter is suitable.
*
* @param {Array<string|Function>|string|Function} adapters - Adapter(s) by name or function.
* @param {Object} config - Axios request configuration
* @throws {AxiosError} If no suitable adapter is available
* @returns {Function} The resolved adapter function
*/
function getAdapter$1(adapters, config) {
	adapters = utils_default.isArray(adapters) ? adapters : [adapters];
	const { length } = adapters;
	let nameOrAdapter;
	let adapter;
	const rejectedReasons = {};
	for (let i = 0; i < length; i++) {
		nameOrAdapter = adapters[i];
		let id;
		adapter = nameOrAdapter;
		if (!isResolvedHandle(nameOrAdapter)) {
			adapter = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
			if (adapter === void 0) throw new AxiosError$1(`Unknown adapter '${id}'`);
		}
		if (adapter && (utils_default.isFunction(adapter) || (adapter = adapter.get(config)))) break;
		rejectedReasons[id || "#" + i] = adapter;
	}
	if (!adapter) {
		const reasons = Object.entries(rejectedReasons).map(([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build"));
		throw new AxiosError$1(`There is no suitable adapter to dispatch the request ` + (length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified"), AxiosError$1.ERR_NOT_SUPPORT);
	}
	return adapter;
}
/**
* Exports Axios adapters and utility to resolve an adapter
*/
var adapters_default = {
	/**
	* Resolve an adapter from a list of adapter names or functions.
	* @type {Function}
	*/
	getAdapter: getAdapter$1,
	/**
	* Exposes all known adapters
	* @type {Object<string, Function|Object>}
	*/
	adapters: knownAdapters
};
// node_modules/axios/lib/core/dispatchRequest.js
/**
* Throws a `CanceledError` if cancellation has been requested.
*
* @param {Object} config The config that is to be used for the request
*
* @returns {void}
*/
function throwIfCancellationRequested(config) {
	if (config.cancelToken) config.cancelToken.throwIfRequested();
	if (config.signal && config.signal.aborted) throw new CanceledError$1(null, config);
}
/**
* Milliseconds elapsed since `start`, floored at zero.
*
* Wall-clock, to match the rest of the codebase (speedometer, throttle,
* AxiosTransformStream). A backwards clock adjustment mid-request would
* otherwise produce a negative duration, so the result is clamped.
*
* @param {number} start Timestamp from `Date.now()`
*
* @returns {number} Non-negative elapsed milliseconds
*/
function elapsedSince(start) {
	return Math.max(0, Date.now() - start);
}
/**
* Dispatch a request to the server using the configured adapter.
*
* @param {object} config The config that is to be used for the request
*
* @returns {Promise} The Promise to be fulfilled
*/
function dispatchRequest(_config) {
	const config = utils_default.toSafeFlatObject(_config);
	throwIfCancellationRequested(config);
	config.headers = AxiosHeaders$1.from(utils_default.getSafeProp(config, "headers"));
	config.data = transformData.call(config, config.transformRequest);
	if ([
		"post",
		"put",
		"patch"
	].indexOf(config.method) !== -1) config.headers.setContentType("application/x-www-form-urlencoded", false);
	const adapter = adapters_default.getAdapter(config.adapter || defaults.adapter, config);
	const start = Date.now();
	return adapter(config).then(function onAdapterResolution(response) {
		throwIfCancellationRequested(config);
		response.duration = elapsedSince(start);
		config.response = response;
		try {
			response.data = transformData.call(config, config.transformResponse, response);
		} finally {
			delete config.response;
		}
		response.headers = AxiosHeaders$1.from(response.headers);
		return response;
	}, function onAdapterRejection(reason) {
		if (!isCancel$1(reason)) {
			throwIfCancellationRequested(config);
			if (reason && reason.response) {
				reason.response.duration = elapsedSince(start);
				config.response = reason.response;
				try {
					reason.response.data = transformData.call(config, config.transformResponse, reason.response);
				} finally {
					delete config.response;
				}
				reason.response.headers = AxiosHeaders$1.from(reason.response.headers);
			}
		}
		return Promise.reject(reason);
	});
}
// node_modules/axios/lib/helpers/validator.js
var validators$1 = {};
[
	"object",
	"boolean",
	"number",
	"function",
	"string",
	"symbol"
].forEach((type, i) => {
	validators$1[type] = function validator(thing) {
		return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
	};
});
var deprecatedWarnings = {};
/**
* Transitional option validator
*
* @param {function|boolean?} validator - set to false if the transitional option has been removed
* @param {string?} version - deprecated version / removed since version
* @param {string?} message - some message with additional info
*
* @returns {function}
*/
validators$1.transitional = function transitional(validator, version, message) {
	function formatMessage(opt, desc) {
		return "[Axios v" + VERSION$1 + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
	}
	return (value, opt, opts) => {
		if (validator === false) throw new AxiosError$1(formatMessage(opt, " has been removed" + (version ? " in " + version : "")), AxiosError$1.ERR_DEPRECATED);
		if (version && !deprecatedWarnings[opt]) {
			deprecatedWarnings[opt] = true;
			console.warn(formatMessage(opt, " has been deprecated since v" + version + " and will be removed in the near future"));
		}
		return validator ? validator(value, opt, opts) : true;
	};
};
validators$1.spelling = function spelling(correctSpelling) {
	return (value, opt) => {
		console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
		return true;
	};
};
/**
* Assert object's properties type
*
* @param {object} options
* @param {object} schema
* @param {boolean?} allowUnknown
*
* @returns {object}
*/
function assertOptions(options, schema, allowUnknown) {
	if (typeof options !== "object" || options === null) throw new AxiosError$1("options must be an object", AxiosError$1.ERR_BAD_OPTION_VALUE);
	const keys = Object.keys(options);
	let i = keys.length;
	while (i-- > 0) {
		const opt = keys[i];
		const validator = Object.prototype.hasOwnProperty.call(schema, opt) ? schema[opt] : void 0;
		if (validator) {
			const value = options[opt];
			const result = value === void 0 || validator(value, opt, options);
			if (result !== true) throw new AxiosError$1("option " + opt + " must be " + result, AxiosError$1.ERR_BAD_OPTION_VALUE);
			continue;
		}
		if (allowUnknown !== true) throw new AxiosError$1("Unknown option " + opt, AxiosError$1.ERR_BAD_OPTION);
	}
}
var validator_default = {
	assertOptions,
	validators: validators$1
};
// node_modules/axios/lib/core/Axios.js
var validators = validator_default.validators;
var isHeadersBucket = (value) => {
	if (value == null || utils_default.isPlainObject(value) || value instanceof AxiosHeaders$1) return true;
	try {
		return utils_default.isObject(value) && utils_default.getSafeProp(value, Symbol.toStringTag) === "AxiosHeaders" && [
			"toJSON",
			"set",
			"get",
			"has",
			"delete",
			"clear",
			"normalize",
			"concat",
			"toString",
			Symbol.iterator
		].every((method) => utils_default.isFunction(utils_default.getSafeProp(value, method)));
	} catch (e) {
		return false;
	}
};
/**
* Create a new instance of Axios
*
* @param {Object} instanceConfig The default config for the instance
*
* @return {Axios} A new instance of Axios
*/
var Axios$1 = class {
	constructor(instanceConfig) {
		this.defaults = instanceConfig || {};
		this.interceptors = {
			request: new InterceptorManager(),
			response: new InterceptorManager()
		};
	}
	/**
	* Dispatch a request
	*
	* @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
	* @param {?Object} config
	*
	* @returns {Promise} The Promise to be fulfilled
	*/
	async request(configOrUrl, config) {
		try {
			return await this._request(configOrUrl, config);
		} catch (err) {
			if (err instanceof Error) try {
				let dummy = {};
				Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = /* @__PURE__ */ new Error();
				const dummyStack = dummy.stack;
				let stack = "";
				if (typeof dummyStack === "string") {
					const firstNewlineIndex = dummyStack.indexOf("\n");
					stack = firstNewlineIndex === -1 ? "" : dummyStack.slice(firstNewlineIndex + 1);
				}
				if (!err.stack) err.stack = stack;
				else if (stack) {
					const firstNewlineIndex = stack.indexOf("\n");
					const secondNewlineIndex = firstNewlineIndex === -1 ? -1 : stack.indexOf("\n", firstNewlineIndex + 1);
					const duplicateCheckSuffix = secondNewlineIndex === -1 ? stack : stack.slice(secondNewlineIndex + 1);
					const currentStack = String(err.stack);
					const causeIndex = getCauseStackIndex(err, currentStack);
					const stackHead = causeIndex === -1 ? currentStack : currentStack.slice(0, causeIndex);
					const causeSection = causeIndex === -1 ? "" : currentStack.slice(causeIndex);
					if (!stackHead.endsWith(duplicateCheckSuffix)) err.stack = stackHead + "\n" + stack + causeSection;
				}
			} catch (e) {}
			throw err;
		}
	}
	_request(configOrUrl, config) {
		if (typeof configOrUrl === "string") {
			config = config || {};
			config.url = configOrUrl;
		} else config = configOrUrl || {};
		config = mergeConfig$1(this.defaults, config);
		const { transitional, paramsSerializer, headers } = config;
		if (transitional !== void 0) validator_default.assertOptions(transitional, {
			silentJSONParsing: validators.transitional(validators.boolean),
			forcedJSONParsing: validators.transitional(validators.boolean),
			clarifyTimeoutError: validators.transitional(validators.boolean),
			legacyInterceptorReqResOrdering: validators.transitional(validators.boolean),
			advertiseZstdAcceptEncoding: validators.transitional(validators.boolean),
			validateStatusUndefinedResolves: validators.transitional(validators.boolean),
			encodeBasicAuthUsername: validators.transitional(validators.boolean)
		}, false);
		if (paramsSerializer != null) {
			if (utils_default.isFunction(paramsSerializer)) config.paramsSerializer = { serialize: paramsSerializer };
			else validator_default.assertOptions(paramsSerializer, {
				encode: validators.function,
				serialize: validators.function
			}, true);
		}
		if (config.allowAbsoluteUrls !== void 0) {} else if (utils_default.hasOwnProp(this.defaults, "allowAbsoluteUrls") && this.defaults.allowAbsoluteUrls !== void 0) config.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
		else config.allowAbsoluteUrls = true;
		validator_default.assertOptions(config, {
			baseUrl: validators.spelling("baseURL"),
			withXsrfToken: validators.spelling("withXSRFToken")
		}, true);
		config.method = (utils_default.getSafeProp(config, "method") || utils_default.getSafeProp(this.defaults, "method") || "get").toLowerCase();
		const commonHeaders = utils_default.getSafeProp(headers, "common");
		const methodHeaders = utils_default.getSafeProp(headers, config.method);
		const contextHeaders = headers && utils_default.merge(isHeadersBucket(commonHeaders) ? commonHeaders : void 0, isHeadersBucket(methodHeaders) ? methodHeaders : void 0);
		headers && utils_default.forEach(methodList.concat("common"), (method) => {
			if (isHeadersBucket(utils_default.getSafeProp(headers, method))) delete headers[method];
		});
		config.headers = AxiosHeaders$1.concat(contextHeaders, headers);
		const requestInterceptorChain = [];
		let synchronousRequestInterceptors = true;
		this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
			if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) return;
			synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
			const transitional = config.transitional || transitional_default;
			if (transitional && transitional.legacyInterceptorReqResOrdering) requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
			else requestInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
		});
		const responseInterceptorChain = [];
		this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
			responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
		});
		let promise;
		let i = 0;
		let len;
		if (!synchronousRequestInterceptors) {
			const chain = [dispatchRequest.bind(this), void 0];
			chain.unshift(...requestInterceptorChain);
			chain.push(...responseInterceptorChain);
			len = chain.length;
			promise = Promise.resolve(config);
			while (i < len) promise = promise.then(chain[i++], chain[i++]);
			return promise;
		}
		len = requestInterceptorChain.length;
		let newConfig = config;
		while (i < len) {
			const onFulfilled = requestInterceptorChain[i++];
			const onRejected = requestInterceptorChain[i++];
			try {
				newConfig = onFulfilled ? onFulfilled(newConfig) : newConfig;
			} catch (error) {
				if (!onRejected) {
					promise = Promise.reject(error);
					break;
				}
				try {
					const rejectedResult = onRejected.call(this, error);
					if (utils_default.isThenable(rejectedResult)) promise = Promise.resolve(rejectedResult).then(() => dispatchRequest.call(this, newConfig));
				} catch (rejectedError) {
					promise = Promise.reject(rejectedError);
				}
				break;
			}
		}
		if (!promise) try {
			promise = dispatchRequest.call(this, newConfig);
		} catch (error) {
			promise = Promise.reject(error);
		}
		i = 0;
		len = responseInterceptorChain.length;
		while (i < len) promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
		return promise;
	}
	getUri(config) {
		config = mergeConfig$1(this.defaults, config);
		return buildURL(buildFullPath(config.baseURL, config.url, config.allowAbsoluteUrls, config), config.params, config.paramsSerializer);
	}
};
utils_default.forEach([
	"delete",
	"get",
	"head",
	"options"
], function forEachMethodNoData(method) {
	Axios$1.prototype[method] = async function(url, config) {
		return this.request(mergeConfig$1(config || {}, {
			method,
			url,
			data: config && utils_default.hasOwnProp(config, "data") ? config.data : void 0
		}));
	};
});
utils_default.forEach([
	"post",
	"put",
	"patch",
	"query"
], function forEachMethodWithData(method) {
	function generateHTTPMethod(isForm) {
		return async function httpMethod(url, data, config) {
			return this.request(mergeConfig$1(config || {}, {
				method,
				headers: isForm ? { "Content-Type": "multipart/form-data" } : {},
				url,
				data
			}));
		};
	}
	Axios$1.prototype[method] = generateHTTPMethod();
	if (method !== "query") Axios$1.prototype[method + "Form"] = generateHTTPMethod(true);
});
// node_modules/axios/lib/cancel/CancelToken.js
/**
* A `CancelToken` is an object that can be used to request cancellation of an operation.
*
* @param {Function} executor The executor function.
*
* @returns {CancelToken}
*/
var CancelToken$1 = class CancelToken$1 {
	constructor(executor) {
		if (typeof executor !== "function") throw new TypeError("executor must be a function.");
		let resolvePromise;
		this.promise = new Promise(function promiseExecutor(resolve) {
			resolvePromise = resolve;
		});
		const token = this;
		this.promise.then((cancel) => {
			if (!token._listeners) return;
			let i = token._listeners.length;
			while (i-- > 0) token._listeners[i](cancel);
			token._listeners = null;
		});
		this.promise.then = (onfulfilled) => {
			let _resolve;
			const promise = new Promise((resolve) => {
				token.subscribe(resolve);
				_resolve = resolve;
			}).then(onfulfilled);
			promise.cancel = function reject() {
				token.unsubscribe(_resolve);
			};
			return promise;
		};
		executor(function cancel(message, config, request) {
			if (token.reason) return;
			token.reason = new CanceledError$1(message, config, request);
			resolvePromise(token.reason);
		});
	}
	/**
	* Throws a `CanceledError` if cancellation has been requested.
	*/
	throwIfRequested() {
		if (this.reason) throw this.reason;
	}
	/**
	* Subscribe to the cancel signal
	*/
	subscribe(listener) {
		if (this.reason) {
			listener(this.reason);
			return;
		}
		if (this._listeners) this._listeners.push(listener);
		else this._listeners = [listener];
	}
	/**
	* Unsubscribe from the cancel signal
	*/
	unsubscribe(listener) {
		if (!this._listeners) return;
		const index = this._listeners.indexOf(listener);
		if (index !== -1) this._listeners.splice(index, 1);
	}
	toAbortSignal() {
		const controller = new AbortController();
		const abort = (err) => {
			controller.abort(err);
		};
		this.subscribe(abort);
		controller.signal.unsubscribe = () => this.unsubscribe(abort);
		return controller.signal;
	}
	/**
	* Returns an object that contains a new `CancelToken` and a function that, when called,
	* cancels the `CancelToken`.
	*/
	static source() {
		let cancel;
		return {
			token: new CancelToken$1(function executor(c) {
				cancel = c;
			}),
			cancel
		};
	}
};
// node_modules/axios/lib/helpers/spread.js
/**
* Syntactic sugar for invoking a function and expanding an array for arguments.
*
* Common use case would be to use `Function.prototype.apply`.
*
*  ```js
*  function f(x, y, z) {}
*  const args = [1, 2, 3];
*  f.apply(null, args);
*  ```
*
* With `spread` this example can be re-written.
*
*  ```js
*  spread(function(x, y, z) {})([1, 2, 3]);
*  ```
*
* @param {Function} callback
*
* @returns {Function}
*/
function spread$1(callback) {
	return function wrap(arr) {
		return callback.apply(null, arr);
	};
}
// node_modules/axios/lib/helpers/isAxiosError.js
/**
* Determines whether the payload is an error thrown by Axios
*
* @param {*} payload The value to test
*
* @returns {boolean} True if the payload is an error thrown by Axios, otherwise false
*/
function isAxiosError$1(payload) {
	return utils_default.isObject(payload) && payload.isAxiosError === true;
}
// node_modules/axios/lib/helpers/HttpStatusCode.js
var HttpStatusCode$1 = {
	Continue: 100,
	SwitchingProtocols: 101,
	Processing: 102,
	EarlyHints: 103,
	Ok: 200,
	Created: 201,
	Accepted: 202,
	NonAuthoritativeInformation: 203,
	NoContent: 204,
	ResetContent: 205,
	PartialContent: 206,
	MultiStatus: 207,
	AlreadyReported: 208,
	ImUsed: 226,
	MultipleChoices: 300,
	MovedPermanently: 301,
	Found: 302,
	SeeOther: 303,
	NotModified: 304,
	UseProxy: 305,
	Unused: 306,
	TemporaryRedirect: 307,
	PermanentRedirect: 308,
	BadRequest: 400,
	Unauthorized: 401,
	PaymentRequired: 402,
	Forbidden: 403,
	NotFound: 404,
	MethodNotAllowed: 405,
	NotAcceptable: 406,
	ProxyAuthenticationRequired: 407,
	RequestTimeout: 408,
	Conflict: 409,
	Gone: 410,
	LengthRequired: 411,
	PreconditionFailed: 412,
	/**
	* @deprecated Use `ContentTooLarge` instead.
	*/
	PayloadTooLarge: 413,
	ContentTooLarge: 413,
	UriTooLong: 414,
	UnsupportedMediaType: 415,
	RangeNotSatisfiable: 416,
	ExpectationFailed: 417,
	ImATeapot: 418,
	MisdirectedRequest: 421,
	/**
	* @deprecated Use `UnprocessableContent` instead.
	*/
	UnprocessableEntity: 422,
	UnprocessableContent: 422,
	Locked: 423,
	FailedDependency: 424,
	TooEarly: 425,
	UpgradeRequired: 426,
	PreconditionRequired: 428,
	TooManyRequests: 429,
	RequestHeaderFieldsTooLarge: 431,
	UnavailableForLegalReasons: 451,
	InternalServerError: 500,
	NotImplemented: 501,
	BadGateway: 502,
	ServiceUnavailable: 503,
	GatewayTimeout: 504,
	HttpVersionNotSupported: 505,
	VariantAlsoNegotiates: 506,
	InsufficientStorage: 507,
	LoopDetected: 508,
	NotExtended: 510,
	NetworkAuthenticationRequired: 511,
	WebServerReturnsAnUnknownError: 520,
	WebServerIsDown: 521,
	ConnectionTimedOut: 522,
	OriginIsUnreachable: 523,
	TimeoutOccurred: 524,
	SslHandshakeFailed: 525,
	InvalidSslCertificate: 526
};
Object.entries(HttpStatusCode$1).forEach(([key, value]) => {
	if (HttpStatusCode$1[value] === void 0) HttpStatusCode$1[value] = key;
});
// node_modules/axios/lib/axios.js
/**
* Create an instance of Axios
*
* @param {Object} defaultConfig The default config for the instance
*
* @returns {Axios} A new instance of Axios
*/
function createInstance(defaultConfig) {
	const context = new Axios$1(defaultConfig);
	const instance = bind(Axios$1.prototype.request, context);
	utils_default.extend(instance, Axios$1.prototype, context, { allOwnKeys: true });
	utils_default.extend(instance, context, null, { allOwnKeys: true });
	instance.create = function create(instanceConfig) {
		return createInstance(mergeConfig$1(defaultConfig, instanceConfig));
	};
	return instance;
}
var axios = createInstance(defaults);
axios.Axios = Axios$1;
axios.CanceledError = CanceledError$1;
axios.CancelToken = CancelToken$1;
axios.isCancel = isCancel$1;
axios.VERSION = VERSION$1;
axios.toFormData = toFormData$1;
axios.AxiosError = AxiosError$1;
axios.Cancel = axios.CanceledError;
axios.all = function all(promises) {
	return Promise.all(promises);
};
axios.spread = spread$1;
axios.isAxiosError = isAxiosError$1;
axios.mergeConfig = mergeConfig$1;
axios.AxiosHeaders = AxiosHeaders$1;
axios.formToJSON = (thing) => formDataToJSON(utils_default.isHTMLForm(thing) ? new FormData(thing) : thing);
axios.getAdapter = adapters_default.getAdapter;
axios.HttpStatusCode = HttpStatusCode$1;
axios.default = axios;
// node_modules/axios/index.js
var { Axios, AxiosError, CanceledError, isCancel, CancelToken, VERSION, all, Cancel, isAxiosError, spread, toFormData, AxiosHeaders, HttpStatusCode, formToJSON, getAdapter, mergeConfig, create } = axios;
export { Axios, AxiosError, AxiosHeaders, Cancel, CancelToken, CanceledError, HttpStatusCode, VERSION, all, create, axios as default, formToJSON, getAdapter, isAxiosError, isCancel, mergeConfig, spread, toFormData };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXhpb3MuanMiLCJuYW1lcyI6WyJpc0Z1bmN0aW9uIiwidXRpbHMiLCJ1dGlscyIsIiRpbnRlcm5hbHMiLCJ1dGlscyIsIkF4aW9zSGVhZGVycyIsInBhcnNlSGVhZGVycyIsInV0aWxzIiwiQXhpb3NIZWFkZXJzIiwic3RyaW5naWZ5U2FmZWx5IiwiQXhpb3NFcnJvciIsInV0aWxzIiwidG9Gb3JtRGF0YSIsIkF4aW9zRXJyb3IiLCJlbmNvZGUiLCJ0b0Zvcm1EYXRhIiwidXRpbHMiLCJ1dGlscyIsInBsYXRmb3JtIiwidG9Gb3JtRGF0YSIsInBsYXRmb3JtIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwidXRpbHMiLCJ1dGlscyIsInRyYW5zaXRpb25hbERlZmF1bHRzIiwidG9Gb3JtRGF0YSIsIkF4aW9zRXJyb3IiLCJwbGF0Zm9ybSIsIkF4aW9zSGVhZGVycyIsImlzQ2FuY2VsIiwiQ2FuY2VsZWRFcnJvciIsIkF4aW9zRXJyb3IiLCJBeGlvc0Vycm9yIiwicGxhdGZvcm0iLCJ1dGlscyIsInV0aWxzIiwicGxhdGZvcm0iLCJBeGlvc0Vycm9yIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwiQXhpb3NIZWFkZXJzIiwidXRpbHMiLCJtZXJnZUNvbmZpZyIsImVuY29kZVVURjgiLCJjb29raWVzIiwibWVyZ2VDb25maWciLCJ1dGlscyIsIkF4aW9zSGVhZGVycyIsIkF4aW9zRXJyb3IiLCJwbGF0Zm9ybSIsImlzVVJMU2FtZU9yaWdpbiIsInBsYXRmb3JtIiwidXRpbHMiLCJBeGlvc0hlYWRlcnMiLCJBeGlvc0Vycm9yIiwidHJhbnNpdGlvbmFsRGVmYXVsdHMiLCJDYW5jZWxlZEVycm9yIiwiQXhpb3NFcnJvciIsIkNhbmNlbGVkRXJyb3IiLCJ1dGlscyIsInV0aWxzIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwicGxhdGZvcm0iLCJWRVJTSU9OIiwidXRpbHMiLCJwbGF0Zm9ybSIsIkF4aW9zRXJyb3IiLCJBeGlvc0hlYWRlcnMiLCJWRVJTSU9OIiwieGhyQWRhcHRlciIsImZldGNoQWRhcHRlci5nZXRGZXRjaCIsInV0aWxzIiwiZ2V0QWRhcHRlciIsIkF4aW9zRXJyb3IiLCJDYW5jZWxlZEVycm9yIiwidXRpbHMiLCJBeGlvc0hlYWRlcnMiLCJhZGFwdGVycyIsImlzQ2FuY2VsIiwidmFsaWRhdG9ycyIsIlZFUlNJT04iLCJBeGlvc0Vycm9yIiwidmFsaWRhdG9yIiwidXRpbHMiLCJBeGlvc0hlYWRlcnMiLCJBeGlvcyIsIm1lcmdlQ29uZmlnIiwidHJhbnNpdGlvbmFsRGVmYXVsdHMiLCJDYW5jZWxUb2tlbiIsIkNhbmNlbGVkRXJyb3IiLCJzcHJlYWQiLCJpc0F4aW9zRXJyb3IiLCJ1dGlscyIsIkh0dHBTdGF0dXNDb2RlIiwiQXhpb3MiLCJtZXJnZUNvbmZpZyIsIkNhbmNlbGVkRXJyb3IiLCJDYW5jZWxUb2tlbiIsImlzQ2FuY2VsIiwiVkVSU0lPTiIsInRvRm9ybURhdGEiLCJBeGlvc0Vycm9yIiwic3ByZWFkIiwiaXNBeGlvc0Vycm9yIiwiQXhpb3NIZWFkZXJzIiwidXRpbHMiLCJhZGFwdGVycyIsIkh0dHBTdGF0dXNDb2RlIl0sInNvdXJjZXMiOlsiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvYmluZC5qcyIsIi4uLy4uL2F4aW9zL2xpYi91dGlscy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3BhcnNlSGVhZGVycy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3Nhbml0aXplSGVhZGVyVmFsdWUuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9BeGlvc0hlYWRlcnMuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9BeGlvc0Vycm9yLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvdG9Gb3JtRGF0YS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL0F4aW9zVVJMU2VhcmNoUGFyYW1zLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvYnVpbGRVUkwuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9JbnRlcmNlcHRvck1hbmFnZXIuanMiLCIuLi8uLi9heGlvcy9saWIvZGVmYXVsdHMvdHJhbnNpdGlvbmFsLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2Jyb3dzZXIvY2xhc3Nlcy9VUkxTZWFyY2hQYXJhbXMuanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9jbGFzc2VzL0Zvcm1EYXRhLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2Jyb3dzZXIvY2xhc3Nlcy9CbG9iLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2Jyb3dzZXIvaW5kZXguanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vY29tbW9uL3V0aWxzLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2luZGV4LmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvdG9VUkxFbmNvZGVkRm9ybS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2Zvcm1EYXRhVG9KU09OLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvbWV0aG9kTGlzdC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9kZWZhdWx0cy9pbmRleC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL3RyYW5zZm9ybURhdGEuanMiLCIuLi8uLi9heGlvcy9saWIvY2FuY2VsL2lzQ2FuY2VsLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NhbmNlbC9DYW5jZWxlZEVycm9yLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvc2V0dGxlLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjay5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3BhcnNlUHJvdG9jb2wuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9jb29raWVzLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvc3BlZWRvbWV0ZXIuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy90aHJvdHRsZS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3Byb2dyZXNzRXZlbnRSZWR1Y2VyLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvaXNVUkxTYW1lT3JpZ2luLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvaXNBYnNvbHV0ZVVSTC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2NvbWJpbmVVUkxzLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvYnVpbGRGdWxsUGF0aC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL2Fzc2VydFBhcmFtc0FjeWNsaWMuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9tZXJnZUNvbmZpZy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL3NldEZvcm1EYXRhSGVhZGVycy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3Jlc29sdmVDb25maWcuanMiLCIuLi8uLi9heGlvcy9saWIvYWRhcHRlcnMveGhyLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvY29tcG9zZVNpZ25hbHMuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy90cmFja1N0cmVhbS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2Zvcm1EYXRhVG9CbG9iLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvY3JlYXRlTXVsdGlwYXJ0Qm9keS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2VzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9lbnYvZGF0YS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9hZGFwdGVycy9mZXRjaC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9hZGFwdGVycy9hZGFwdGVycy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL2Rpc3BhdGNoUmVxdWVzdC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3ZhbGlkYXRvci5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL0F4aW9zLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NhbmNlbC9DYW5jZWxUb2tlbi5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3NwcmVhZC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2lzQXhpb3NFcnJvci5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL0h0dHBTdGF0dXNDb2RlLmpzIiwiLi4vLi4vYXhpb3MvbGliL2F4aW9zLmpzIiwiLi4vLi4vYXhpb3MvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnO1xuXG4vKipcbiAqIENyZWF0ZSBhIGJvdW5kIHZlcnNpb24gb2YgYSBmdW5jdGlvbiB3aXRoIGEgc3BlY2lmaWVkIGB0aGlzYCBjb250ZXh0XG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm4gLSBUaGUgZnVuY3Rpb24gdG8gYmluZFxuICogQHBhcmFtIHsqfSB0aGlzQXJnIC0gVGhlIHZhbHVlIHRvIGJlIHBhc3NlZCBhcyB0aGUgYHRoaXNgIHBhcmFtZXRlclxuICogQHJldHVybnMge0Z1bmN0aW9ufSBBIG5ldyBmdW5jdGlvbiB0aGF0IHdpbGwgY2FsbCB0aGUgb3JpZ2luYWwgZnVuY3Rpb24gd2l0aCB0aGUgc3BlY2lmaWVkIGB0aGlzYCBjb250ZXh0XG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGJpbmQoZm4sIHRoaXNBcmcpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIHdyYXAoKSB7XG4gICAgcmV0dXJuIGZuLmFwcGx5KHRoaXNBcmcsIGFyZ3VtZW50cyk7XG4gIH07XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBiaW5kIGZyb20gJy4vaGVscGVycy9iaW5kLmpzJztcblxuLy8gdXRpbHMgaXMgYSBsaWJyYXJ5IG9mIGdlbmVyaWMgaGVscGVyIGZ1bmN0aW9ucyBub24tc3BlY2lmaWMgdG8gYXhpb3NcblxuY29uc3QgeyB0b1N0cmluZyB9ID0gT2JqZWN0LnByb3RvdHlwZTtcbmNvbnN0IHsgZ2V0UHJvdG90eXBlT2YgfSA9IE9iamVjdDtcbmNvbnN0IHsgaXRlcmF0b3IsIHRvU3RyaW5nVGFnIH0gPSBTeW1ib2w7XG5cbi8qIENyZWF0aW5nIGEgZnVuY3Rpb24gdGhhdCB3aWxsIGNoZWNrIGlmIGFuIG9iamVjdCBoYXMgYSBwcm9wZXJ0eS4gKi9cbmNvbnN0IGhhc093blByb3BlcnR5ID0gKFxuICAoeyBoYXNPd25Qcm9wZXJ0eSB9KSA9PlxuICAob2JqLCBwcm9wKSA9PlxuICAgIGhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKVxuKShPYmplY3QucHJvdG90eXBlKTtcblxuY29uc3QgaXNVbnNhZmVPYmplY3RLZXkgPSAocHJvcCkgPT5cbiAgdHlwZW9mIHByb3AgPT09ICdzdHJpbmcnICYmXG4gIChwcm9wID09PSAnX19wcm90b19fJyB8fCBwcm9wID09PSAnY29uc3RydWN0b3InIHx8IHByb3AgPT09ICdwcm90b3R5cGUnKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgd2hldGhlciBhbiBpbmhlcml0ZWQgb2JqZWN0IG11c3QgYmUgdHJlYXRlZCBhcyBhIHNoYXJlZC1wcm90b3R5cGVcbiAqIGJvdW5kYXJ5LiBDcm9zcy1yZWFsbSBPYmplY3QucHJvdG90eXBlIG9iamVjdHMgY2Fubm90IGJlIGRpc3Rpbmd1aXNoZWRcbiAqIHJlbGlhYmx5IGZyb20gYXBwbGljYXRpb24tY3JlYXRlZCBudWxsLXByb3RvdHlwZSBvYmplY3RzIGJlY2F1c2UgdGhlaXJcbiAqIHByb3BlcnRpZXMgYXJlIG11dGFibGUsIHNvIGFsbCBpbmhlcml0ZWQgdGVybWluYWwgcHJvdG90eXBlcyBhcmUgZXhjbHVkZWRcbiAqIGFzIGEgZmFpbC1jbG9zZWQgYm91bmRhcnkuIEEgbnVsbC1wcm90b3R5cGUgc291cmNlIHN0aWxsIGtlZXBzIGl0cyBvd25cbiAqIHByb3BlcnRpZXMsIGFzIHByb2R1Y2VkIGJ5IG1lcmdlQ29uZmlnIGFuZCBvdGhlciBzYWZlIG1hdGVyaWFsaXphdGlvbiBwYXRocy5cbiAqXG4gKiBAcGFyYW0geyp9IG9iaiBUaGUgb2JqZWN0IHRvIGluc3BlY3RcbiAqIEBwYXJhbSB7Kn0gcHJvdG90eXBlIFRoZSBvYmplY3QncyBwcm90b3R5cGVcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gc291cmNlIFdoZXRoZXIgb2JqIGlzIHRoZSBvcmlnaW5hbCB0cmF2ZXJzYWwgc291cmNlXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgd2hlbiBvYmogaXMgYSBzYWZlIHByb3RvdHlwZSB0cmF2ZXJzYWwgYm91bmRhcnlcbiAqL1xuY29uc3QgaXNQcm90b3R5cGVCb3VuZGFyeSA9IChvYmosIHByb3RvdHlwZSwgc291cmNlKSA9PlxuICBvYmogPT09IE9iamVjdC5wcm90b3R5cGUgfHwgKCFzb3VyY2UgJiYgcHJvdG90eXBlID09PSBudWxsKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgd2hldGhlciBhbiBvYmplY3QgY2FuIHJldGFpbiBpdHMgaWRlbnRpdHkgdGhyb3VnaCBjb2RlIHBhdGhzIHRoYXRcbiAqIGFkZCwgcmVwbGFjZSwgYW5kIHJlbW92ZSBjb25maWcgcHJvcGVydGllcyB3aXRob3V0IGJ5cGFzc2luZyB1bnNhZmUta2V5XG4gKiBmaWx0ZXJpbmcuIEltbXV0YWJsZSBvYmplY3RzLCB1bnNhZmUta2V5LWJlYXJpbmcgb2JqZWN0cywgYW5kIG9iamVjdHMgd2l0aFxuICogYWNjZXNzb3Igb3IgcmVzdHJpY3RlZCBkYXRhIHByb3BlcnRpZXMgbXVzdCBiZSBtYXRlcmlhbGl6ZWQgaW5zdGVhZC5cbiAqXG4gKiBAcGFyYW0geyp9IG9iaiBUaGUgb2JqZWN0IHRvIGluc3BlY3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSB3aGVuIGV2ZXJ5IG93biBwcm9wZXJ0eSBpcyBzYWZlIGFuZCBmdWxseSBtdXRhYmxlXG4gKi9cbmNvbnN0IGlzU2FmZUFuZEZ1bGx5TXV0YWJsZSA9IChvYmopID0+IHtcbiAgaWYgKCFPYmplY3QuaXNFeHRlbnNpYmxlKG9iaikpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBjb25zdCBwcm9wcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKG9iaik7XG5cbiAgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICBwcm9wcy5wdXNoKC4uLk9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMob2JqKSk7XG4gIH1cblxuICByZXR1cm4gcHJvcHMuZXZlcnkoKHByb3ApID0+IHtcbiAgICBpZiAoaXNVbnNhZmVPYmplY3RLZXkocHJvcCkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBjb25zdCBkZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmosIHByb3ApO1xuXG4gICAgcmV0dXJuICEhZGVzY3JpcHRvciAmJiBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSAmJiBkZXNjcmlwdG9yLndyaXRhYmxlID09PSB0cnVlO1xuICB9KTtcbn07XG5cbi8qKlxuICogV2FsayB0aGUgcHJvdG90eXBlIGNoYWluIChleGNsdWRpbmcgdGhlIHNvdXJjZSByZWFsbSdzIE9iamVjdC5wcm90b3R5cGUpXG4gKiBsb29raW5nIGZvciBhbiBvd24gYHByb3BgLiBUaGlzIGRpc3Rpbmd1aXNoZXMgZ2VudWluZSBvd24vaW5oZXJpdGVkIG1lbWJlcnNcbiAqIOKAlCBpbmNsdWRpbmcgY2xhc3MgYWNjZXNzb3JzIGFuZCB0ZW1wbGF0ZSBwcm90b3R5cGVzIOKAlCBmcm9tIG1lbWJlcnMgaW5qZWN0ZWRcbiAqIHZpYSBPYmplY3QucHJvdG90eXBlIHBvbGx1dGlvbiAoZS5nLiBgT2JqZWN0LnByb3RvdHlwZS51c2VybmFtZSA9ICcuLi4nYCksXG4gKiB3aGljaCBsaXZlIG9uIE9iamVjdC5wcm90b3R5cGUgaXRzZWxmIGFuZCBhcmUgdGhlcmVmb3JlIG5ldmVyIG1hdGNoZWQuXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgd2hvc2UgY2hhaW4gdG8gaW5zcGVjdFxuICogQHBhcmFtIHtzdHJpbmd8c3ltYm9sfSBwcm9wIFRoZSBwcm9wZXJ0eSBrZXkgdG8gbG9vayBmb3JcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSB3aGVuIGBwcm9wYCBpcyBvd25lZCBiZWxvdyBPYmplY3QucHJvdG90eXBlXG4gKi9cbmNvbnN0IGhhc093bkluUHJvdG90eXBlQ2hhaW4gPSAodGhpbmcsIHByb3ApID0+IHtcbiAgbGV0IG9iaiA9IHRoaW5nO1xuICBjb25zdCBzZWVuID0gW107XG5cbiAgd2hpbGUgKG9iaiAhPSBudWxsKSB7XG4gICAgaWYgKHNlZW4uaW5kZXhPZihvYmopICE9PSAtMSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBzZWVuLnB1c2gob2JqKTtcblxuICAgIGNvbnN0IHByb3RvdHlwZSA9IGdldFByb3RvdHlwZU9mKG9iaik7XG5cbiAgICBpZiAoaXNQcm90b3R5cGVCb3VuZGFyeShvYmosIHByb3RvdHlwZSwgb2JqID09PSB0aGluZykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoaGFzT3duUHJvcGVydHkob2JqLCBwcm9wKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIG9iaiA9IHByb3RvdHlwZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59O1xuXG4vKipcbiAqIFJlYWQgYG9ialtwcm9wXWAgb25seSB3aGVuIGl0IGlzIHNhZmUgZnJvbSBPYmplY3QucHJvdG90eXBlIHBvbGx1dGlvbi4gT3duXG4gKiBwcm9wZXJ0aWVzIGFuZCBtZW1iZXJzIGluaGVyaXRlZCBmcm9tIGEgbm9uLU9iamVjdC5wcm90b3R5cGUgc291cmNlIChhIGNsYXNzXG4gKiBpbnN0YW5jZSBvciB0ZW1wbGF0ZSBvYmplY3QpIGFyZSBob25vcmVkOyBhIHZhbHVlIHJlYWNoYWJsZSBvbmx5IHRocm91Z2ggYVxuICogcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZSBpcyBpZ25vcmVkIGFuZCBgdW5kZWZpbmVkYCBpcyByZXR1cm5lZC5cbiAqXG4gKiBAcGFyYW0geyp9IG9iaiBUaGUgc291cmNlIG9iamVjdFxuICogQHBhcmFtIHtzdHJpbmd8c3ltYm9sfSBwcm9wIFRoZSBwcm9wZXJ0eSBrZXkgdG8gcmVhZFxuICpcbiAqIEByZXR1cm5zIHsqfSBUaGUgcmVzb2x2ZWQgdmFsdWUsIG9yIHVuZGVmaW5lZCB3aGVuIHVuc2FmZS9hYnNlbnRcbiAqL1xuY29uc3QgZ2V0U2FmZVByb3AgPSAob2JqLCBwcm9wKSA9PlxuICBvYmogIT0gbnVsbCAmJiBoYXNPd25JblByb3RvdHlwZUNoYWluKG9iaiwgcHJvcCkgPyBvYmpbcHJvcF0gOiB1bmRlZmluZWQ7XG5cbi8qKlxuICogRmxhdHRlbiBhbiBvYmplY3QgYW5kIGl0cyBhcHBsaWNhdGlvbi1kZWZpbmVkIHByb3RvdHlwZSBjaGFpbiBpbnRvIGFcbiAqIG51bGwtcHJvdG90eXBlIG9iamVjdC4gTWVtYmVycyBpbmhlcml0ZWQgb25seSBmcm9tIHRoZSBzb3VyY2UgcmVhbG0nc1xuICogT2JqZWN0LnByb3RvdHlwZSBhcmUgZGVsaWJlcmF0ZWx5IGV4Y2x1ZGVkLCB3aGlsZSBjbGFzcy90ZW1wbGF0ZSBtZW1iZXJzXG4gKiBiZWxvdyB0aGF0IGJvdW5kYXJ5IGFyZSBwcmVzZXJ2ZWQuXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgdG8gZmxhdHRlblxuICpcbiAqIEByZXR1cm5zIHsqfSBBIG51bGwtcHJvdG90eXBlIGNvcHksIG9yIHRoZSBvcmlnaW5hbCB2YWx1ZSB3aGVuIGl0IGlzIGFscmVhZHlcbiAqIHN0cnVjdHVyYWxseSBzYWZlIG9yIGlzIG5vdCBhbiBvYmplY3RcbiAqL1xuY29uc3QgdG9TYWZlRmxhdE9iamVjdCA9ICh0aGluZykgPT4ge1xuICBpZiAodGhpbmcgPT0gbnVsbCB8fCAodHlwZW9mIHRoaW5nICE9PSAnb2JqZWN0JyAmJiB0eXBlb2YgdGhpbmcgIT09ICdmdW5jdGlvbicpKSB7XG4gICAgcmV0dXJuIHRoaW5nO1xuICB9XG5cbiAgY29uc3Qgc291cmNlUHJvdG90eXBlID0gZ2V0UHJvdG90eXBlT2YodGhpbmcpO1xuXG4gIGlmIChzb3VyY2VQcm90b3R5cGUgPT09IG51bGwgJiYgaXNTYWZlQW5kRnVsbHlNdXRhYmxlKHRoaW5nKSkge1xuICAgIHJldHVybiB0aGluZztcbiAgfVxuXG4gIGNvbnN0IHJlc3VsdCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IG1lcmdlZCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IHNlZW4gPSBbXTtcbiAgbGV0IGN1cnJlbnQgPSB0aGluZztcblxuICB3aGlsZSAoY3VycmVudCAhPSBudWxsKSB7XG4gICAgaWYgKHNlZW4uaW5kZXhPZihjdXJyZW50KSAhPT0gLTEpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHNlZW4ucHVzaChjdXJyZW50KTtcblxuICAgIGNvbnN0IHByb3RvdHlwZSA9IGN1cnJlbnQgPT09IHRoaW5nID8gc291cmNlUHJvdG90eXBlIDogZ2V0UHJvdG90eXBlT2YoY3VycmVudCk7XG5cbiAgICBpZiAoaXNQcm90b3R5cGVCb3VuZGFyeShjdXJyZW50LCBwcm90b3R5cGUsIGN1cnJlbnQgPT09IHRoaW5nKSkge1xuICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgY29uc3QgcHJvcHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhjdXJyZW50KTtcblxuICAgIGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7XG4gICAgICBwcm9wcy5wdXNoKC4uLk9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoY3VycmVudCkpO1xuICAgIH1cblxuICAgIGZvciAoY29uc3QgcHJvcCBvZiBwcm9wcykge1xuICAgICAgaWYgKGlzVW5zYWZlT2JqZWN0S2V5KHByb3ApKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWhhc093blByb3BlcnR5KG1lcmdlZCwgcHJvcCkpIHtcbiAgICAgICAgcmVzdWx0W3Byb3BdID0gdGhpbmdbcHJvcF07XG4gICAgICAgIG1lcmdlZFtwcm9wXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY3VycmVudCA9IHByb3RvdHlwZTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59O1xuXG5jb25zdCBraW5kT2YgPSAoKGNhY2hlKSA9PiAodGhpbmcpID0+IHtcbiAgY29uc3Qgc3RyID0gdG9TdHJpbmcuY2FsbCh0aGluZyk7XG4gIHJldHVybiBjYWNoZVtzdHJdIHx8IChjYWNoZVtzdHJdID0gc3RyLnNsaWNlKDgsIC0xKS50b0xvd2VyQ2FzZSgpKTtcbn0pKE9iamVjdC5jcmVhdGUobnVsbCkpO1xuXG5jb25zdCBraW5kT2ZUZXN0ID0gKHR5cGUpID0+IHtcbiAgdHlwZSA9IHR5cGUudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuICh0aGluZykgPT4ga2luZE9mKHRoaW5nKSA9PT0gdHlwZTtcbn07XG5cbmNvbnN0IHR5cGVPZlRlc3QgPSAodHlwZSkgPT4gKHRoaW5nKSA9PiB0eXBlb2YgdGhpbmcgPT09IHR5cGU7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBub24tbnVsbCBvYmplY3RcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gQXJyYXksIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCB7IGlzQXJyYXkgfSA9IEFycmF5O1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIHVuZGVmaW5lZFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHZhbHVlIGlzIHVuZGVmaW5lZCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzVW5kZWZpbmVkID0gdHlwZU9mVGVzdCgndW5kZWZpbmVkJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCdWZmZXJcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgQnVmZmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNCdWZmZXIodmFsKSB7XG4gIHJldHVybiAoXG4gICAgdmFsICE9PSBudWxsICYmXG4gICAgIWlzVW5kZWZpbmVkKHZhbCkgJiZcbiAgICB2YWwuY29uc3RydWN0b3IgIT09IG51bGwgJiZcbiAgICAhaXNVbmRlZmluZWQodmFsLmNvbnN0cnVjdG9yKSAmJlxuICAgIGlzRnVuY3Rpb24odmFsLmNvbnN0cnVjdG9yLmlzQnVmZmVyKSAmJlxuICAgIHZhbC5jb25zdHJ1Y3Rvci5pc0J1ZmZlcih2YWwpXG4gICk7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gQXJyYXlCdWZmZXJcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGFuIEFycmF5QnVmZmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNBcnJheUJ1ZmZlciA9IGtpbmRPZlRlc3QoJ0FycmF5QnVmZmVyJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSB2aWV3IG9uIGFuIEFycmF5QnVmZmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIHZpZXcgb24gYW4gQXJyYXlCdWZmZXIsIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc0FycmF5QnVmZmVyVmlldyh2YWwpIHtcbiAgbGV0IHJlc3VsdDtcbiAgaWYgKHR5cGVvZiBBcnJheUJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcgJiYgQXJyYXlCdWZmZXIuaXNWaWV3KSB7XG4gICAgcmVzdWx0ID0gQXJyYXlCdWZmZXIuaXNWaWV3KHZhbCk7XG4gIH0gZWxzZSB7XG4gICAgcmVzdWx0ID0gdmFsICYmIHZhbC5idWZmZXIgJiYgaXNBcnJheUJ1ZmZlcih2YWwuYnVmZmVyKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgU3RyaW5nXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIFN0cmluZywgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzU3RyaW5nID0gdHlwZU9mVGVzdCgnc3RyaW5nJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGdW5jdGlvblxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEZ1bmN0aW9uLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNGdW5jdGlvbiA9IHR5cGVPZlRlc3QoJ2Z1bmN0aW9uJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBOdW1iZXJcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgTnVtYmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNOdW1iZXIgPSB0eXBlT2ZUZXN0KCdudW1iZXInKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhbiBPYmplY3RcbiAqXG4gKiBAcGFyYW0geyp9IHRoaW5nIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gT2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNPYmplY3QgPSAodGhpbmcpID0+IHRoaW5nICE9PSBudWxsICYmIHR5cGVvZiB0aGluZyA9PT0gJ29iamVjdCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCb29sZWFuXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBCb29sZWFuLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNCb29sZWFuID0gKHRoaW5nKSA9PiB0aGluZyA9PT0gdHJ1ZSB8fCB0aGluZyA9PT0gZmFsc2U7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBwbGFpbiBPYmplY3RcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgcGxhaW4gT2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNQbGFpbk9iamVjdCA9ICh2YWwpID0+IHtcbiAgaWYgKCFpc09iamVjdCh2YWwpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgY29uc3QgcHJvdG90eXBlID0gZ2V0UHJvdG90eXBlT2YodmFsKTtcbiAgcmV0dXJuIChcbiAgICAocHJvdG90eXBlID09PSBudWxsIHx8IHByb3RvdHlwZSA9PT0gT2JqZWN0LnByb3RvdHlwZSB8fCBnZXRQcm90b3R5cGVPZihwcm90b3R5cGUpID09PSBudWxsKSAmJlxuICAgIC8vIFRyZWF0IG93biBTeW1ib2wudG9TdHJpbmdUYWcgb3IgU3ltYm9sLml0ZXJhdG9yIG1lbWJlcnMgYXMgZXZpZGVuY2UgdGhlXG4gICAgLy8gdmFsdWUgaXMgdGFnZ2VkL2l0ZXJhYmxlLCBpZ25vcmluZyBtZW1iZXJzIHJlYWNoYWJsZSBvbmx5IHRocm91Z2ggc2hhcmVkXG4gICAgLy8gb3IgdGVybWluYWwgcHJvdG90eXBlIGJvdW5kYXJpZXMuIFRoaXMgaXMgZXhhY3RseSB3aGF0XG4gICAgLy8gaGFzT3duSW5Qcm90b3R5cGVDaGFpbih2YWwsIHByb3ApIGNvbXB1dGVzIGhlcmU6IGV2ZXJ5IHByb3RvdHlwZSBhZG1pdHRlZFxuICAgIC8vIGFib3ZlIChudWxsLCBPYmplY3QucHJvdG90eXBlLCBvciBhIHRlcm1pbmFsIG51bGwtcHJvdG90eXBlIHRlbXBsYXRlKSBpc1xuICAgIC8vIGEgYm91bmRhcnksIHNvIHRoZSB3YWxrIG5ldmVyIGluc3BlY3RzIGFueXRoaW5nIGJ1dCBgdmFsYCdzIG93biBtZW1iZXJzLFxuICAgIC8vIGFuZCBzdG9wcyBiZWZvcmUgZXZlbiB0aG9zZSB3aGVuIGB2YWxgIGlzIGl0c2VsZiB0aGUgYm91bmRhcnlcbiAgICAvLyBPYmplY3QucHJvdG90eXBlLiBDaGVja2luZyB0aGF0IGlubGluZSBhdm9pZHMgYWxsb2NhdGluZyB0aGUgd2Fsa2VyJ3NcbiAgICAvLyBgc2VlbmAgbGlzdCB0d2ljZSBwZXIgY2FsbCBvbiB0aGUgbWVyZ2VDb25maWcgLyBtZXJnZSBob3QgcGF0aC5cbiAgICAoaXNQcm90b3R5cGVCb3VuZGFyeSh2YWwsIHByb3RvdHlwZSwgdHJ1ZSkgfHxcbiAgICAgICghaGFzT3duUHJvcGVydHkodmFsLCB0b1N0cmluZ1RhZykgJiYgIWhhc093blByb3BlcnR5KHZhbCwgaXRlcmF0b3IpKSlcbiAgKTtcbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gZW1wdHkgb2JqZWN0IChzYWZlbHkgaGFuZGxlcyBCdWZmZXJzKVxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gZW1wdHkgb2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNFbXB0eU9iamVjdCA9ICh2YWwpID0+IHtcbiAgLy8gRWFybHkgcmV0dXJuIGZvciBub24tb2JqZWN0cyBvciBCdWZmZXJzIHRvIHByZXZlbnQgUmFuZ2VFcnJvclxuICBpZiAoIWlzT2JqZWN0KHZhbCkgfHwgaXNCdWZmZXIodmFsKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHZhbCkubGVuZ3RoID09PSAwICYmIE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWwpID09PSBPYmplY3QucHJvdG90eXBlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gRmFsbGJhY2sgZm9yIGFueSBvdGhlciBvYmplY3RzIHRoYXQgbWlnaHQgY2F1c2UgUmFuZ2VFcnJvciB3aXRoIE9iamVjdC5rZXlzKClcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBEYXRlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIERhdGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0RhdGUgPSBraW5kT2ZUZXN0KCdEYXRlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEZpbGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0ZpbGUgPSBraW5kT2ZUZXN0KCdGaWxlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBSZWFjdCBOYXRpdmUgQmxvYlxuICogUmVhY3QgTmF0aXZlIFwiYmxvYlwiOiBhbiBvYmplY3Qgd2l0aCBhIGB1cmlgIGF0dHJpYnV0ZS4gT3B0aW9uYWxseSwgaXQgY2FuXG4gKiBhbHNvIGhhdmUgYSBgbmFtZWAgYW5kIGB0eXBlYCBhdHRyaWJ1dGUgdG8gc3BlY2lmeSBmaWxlbmFtZSBhbmQgY29udGVudCB0eXBlXG4gKlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QtbmF0aXZlL2Jsb2IvMjY2ODRjZjNhZGY0MDk0ZWI2YzQwNWQzNDVhNzViZjhjN2MwYmY4OC9MaWJyYXJpZXMvTmV0d29yay9Gb3JtRGF0YS5qcyNMNjgtTDcxXG4gKlxuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgUmVhY3QgTmF0aXZlIEJsb2IsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1JlYWN0TmF0aXZlQmxvYiA9ICh2YWx1ZSkgPT4ge1xuICByZXR1cm4gISEodmFsdWUgJiYgdHlwZW9mIHZhbHVlLnVyaSAhPT0gJ3VuZGVmaW5lZCcpO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgZW52aXJvbm1lbnQgaXMgUmVhY3QgTmF0aXZlXG4gKiBSZWFjdE5hdGl2ZSBgRm9ybURhdGFgIGhhcyBhIG5vbi1zdGFuZGFyZCBgZ2V0UGFydHMoKWAgbWV0aG9kXG4gKlxuICogQHBhcmFtIHsqfSBmb3JtRGF0YSBUaGUgZm9ybURhdGEgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIGVudmlyb25tZW50IGlzIFJlYWN0IE5hdGl2ZSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzUmVhY3ROYXRpdmUgPSAoZm9ybURhdGEpID0+IGZvcm1EYXRhICYmIHR5cGVvZiBmb3JtRGF0YS5nZXRQYXJ0cyAhPT0gJ3VuZGVmaW5lZCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCbG9iXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEJsb2IsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0Jsb2IgPSBraW5kT2ZUZXN0KCdCbG9iJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlTGlzdFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBGaWxlTGlzdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzRmlsZUxpc3QgPSBraW5kT2ZUZXN0KCdGaWxlTGlzdCcpO1xuY29uc3QgaXNTZXQgPSBraW5kT2ZUZXN0KCdTZXQnKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFN0cmVhbVxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBTdHJlYW0sIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1N0cmVhbSA9ICh2YWwpID0+IGlzT2JqZWN0KHZhbCkgJiYgaXNGdW5jdGlvbih2YWwucGlwZSk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGb3JtRGF0YVxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBGb3JtRGF0YSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGdldEdsb2JhbCgpIHtcbiAgaWYgKHR5cGVvZiBnbG9iYWxUaGlzICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGdsb2JhbFRoaXM7XG4gIGlmICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiBzZWxmO1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiB3aW5kb3c7XG4gIGlmICh0eXBlb2YgZ2xvYmFsICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGdsb2JhbDtcbiAgcmV0dXJuIHt9O1xufVxuXG5jb25zdCBHID0gZ2V0R2xvYmFsKCk7XG5jb25zdCBGb3JtRGF0YUN0b3IgPSB0eXBlb2YgRy5Gb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgPyBHLkZvcm1EYXRhIDogdW5kZWZpbmVkO1xuXG5jb25zdCBpc0Zvcm1EYXRhID0gKHRoaW5nKSA9PiB7XG4gIGlmICghdGhpbmcpIHJldHVybiBmYWxzZTtcbiAgaWYgKEZvcm1EYXRhQ3RvciAmJiB0aGluZyBpbnN0YW5jZW9mIEZvcm1EYXRhQ3RvcikgcmV0dXJuIHRydWU7XG4gIC8vIFJlamVjdCBwbGFpbiBvYmplY3RzIGluaGVyaXRpbmcgZGlyZWN0bHkgZnJvbSBPYmplY3QucHJvdG90eXBlIHNvIHByb3RvdHlwZS1wb2xsdXRpb24gZ2FkZ2V0cyBjYW4ndCBzcG9vZiBGb3JtRGF0YS5cbiAgY29uc3QgcHJvdG8gPSBnZXRQcm90b3R5cGVPZih0aGluZyk7XG4gIGlmICghcHJvdG8gfHwgcHJvdG8gPT09IE9iamVjdC5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcbiAgaWYgKCFpc0Z1bmN0aW9uKHRoaW5nLmFwcGVuZCkpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qga2luZCA9IGtpbmRPZih0aGluZyk7XG4gIHJldHVybiAoXG4gICAga2luZCA9PT0gJ2Zvcm1kYXRhJyB8fFxuICAgIC8vIGRldGVjdCBmb3JtLWRhdGEgaW5zdGFuY2VcbiAgICAoa2luZCA9PT0gJ29iamVjdCcgJiYgaXNGdW5jdGlvbih0aGluZy50b1N0cmluZykgJiYgdGhpbmcudG9TdHJpbmcoKSA9PT0gJ1tvYmplY3QgRm9ybURhdGFdJylcbiAgKTtcbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBVUkxTZWFyY2hQYXJhbXMgb2JqZWN0XG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIFVSTFNlYXJjaFBhcmFtcyBvYmplY3QsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1VSTFNlYXJjaFBhcmFtcyA9IGtpbmRPZlRlc3QoJ1VSTFNlYXJjaFBhcmFtcycpO1xuXG5jb25zdCBbaXNSZWFkYWJsZVN0cmVhbSwgaXNSZXF1ZXN0LCBpc1Jlc3BvbnNlLCBpc0hlYWRlcnNdID0gW1xuICAnUmVhZGFibGVTdHJlYW0nLFxuICAnUmVxdWVzdCcsXG4gICdSZXNwb25zZScsXG4gICdIZWFkZXJzJyxcbl0ubWFwKGtpbmRPZlRlc3QpO1xuXG4vKipcbiAqIFRyaW0gZXhjZXNzIHdoaXRlc3BhY2Ugb2ZmIHRoZSBiZWdpbm5pbmcgYW5kIGVuZCBvZiBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHIgVGhlIFN0cmluZyB0byB0cmltXG4gKlxuICogQHJldHVybnMge1N0cmluZ30gVGhlIFN0cmluZyBmcmVlZCBvZiBleGNlc3Mgd2hpdGVzcGFjZVxuICovXG5jb25zdCB0cmltID0gKHN0cikgPT4ge1xuICByZXR1cm4gc3RyLnRyaW0gPyBzdHIudHJpbSgpIDogc3RyLnJlcGxhY2UoL15bXFxzXFx1RkVGRlxceEEwXSt8W1xcc1xcdUZFRkZcXHhBMF0rJC9nLCAnJyk7XG59O1xuLyoqXG4gKiBJdGVyYXRlIG92ZXIgYW4gQXJyYXkgb3IgYW4gT2JqZWN0IGludm9raW5nIGEgZnVuY3Rpb24gZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiBgb2JqYCBpcyBhbiBBcnJheSBjYWxsYmFjayB3aWxsIGJlIGNhbGxlZCBwYXNzaW5nXG4gKiB0aGUgdmFsdWUsIGluZGV4LCBhbmQgY29tcGxldGUgYXJyYXkgZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiAnb2JqJyBpcyBhbiBPYmplY3QgY2FsbGJhY2sgd2lsbCBiZSBjYWxsZWQgcGFzc2luZ1xuICogdGhlIHZhbHVlLCBrZXksIGFuZCBjb21wbGV0ZSBvYmplY3QgZm9yIGVhY2ggcHJvcGVydHkuXG4gKlxuICogQHBhcmFtIHtPYmplY3R8QXJyYXk8dW5rbm93bj59IG9iaiBUaGUgb2JqZWN0IHRvIGl0ZXJhdGVcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBjYWxsYmFjayB0byBpbnZva2UgZm9yIGVhY2ggaXRlbVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gW29wdGlvbnMuYWxsT3duS2V5cyA9IGZhbHNlXVxuICogQHJldHVybnMge2FueX1cbiAqL1xuZnVuY3Rpb24gZm9yRWFjaChvYmosIGZuLCB7IGFsbE93bktleXMgPSBmYWxzZSB9ID0ge30pIHtcbiAgLy8gRG9uJ3QgYm90aGVyIGlmIG5vIHZhbHVlIHByb3ZpZGVkXG4gIGlmIChvYmogPT09IG51bGwgfHwgdHlwZW9mIG9iaiA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBsZXQgaTtcbiAgbGV0IGw7XG5cbiAgLy8gRm9yY2UgYW4gYXJyYXkgaWYgbm90IGFscmVhZHkgc29tZXRoaW5nIGl0ZXJhYmxlXG4gIGlmICh0eXBlb2Ygb2JqICE9PSAnb2JqZWN0Jykge1xuICAgIC8qZXNsaW50IG5vLXBhcmFtLXJlYXNzaWduOjAqL1xuICAgIG9iaiA9IFtvYmpdO1xuICB9XG5cbiAgaWYgKGlzQXJyYXkob2JqKSkge1xuICAgIC8vIEl0ZXJhdGUgb3ZlciBhcnJheSB2YWx1ZXNcbiAgICBmb3IgKGkgPSAwLCBsID0gb2JqLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgZm4uY2FsbChudWxsLCBvYmpbaV0sIGksIG9iaik7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIEJ1ZmZlciBjaGVja1xuICAgIGlmIChpc0J1ZmZlcihvYmopKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gSXRlcmF0ZSBvdmVyIG9iamVjdCBrZXlzXG4gICAgY29uc3Qga2V5cyA9IGFsbE93bktleXMgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhvYmopIDogT2JqZWN0LmtleXMob2JqKTtcbiAgICBjb25zdCBsZW4gPSBrZXlzLmxlbmd0aDtcbiAgICBsZXQga2V5O1xuXG4gICAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICBrZXkgPSBrZXlzW2ldO1xuICAgICAgZm4uY2FsbChudWxsLCBvYmpba2V5XSwga2V5LCBvYmopO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIEZpbmRzIGEga2V5IGluIGFuIG9iamVjdCwgY2FzZS1pbnNlbnNpdGl2ZSwgcmV0dXJuaW5nIHRoZSBhY3R1YWwga2V5IG5hbWUuXG4gKiBSZXR1cm5zIG51bGwgaWYgdGhlIG9iamVjdCBpcyBhIEJ1ZmZlciBvciBpZiBubyBtYXRjaCBpcyBmb3VuZC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqIC0gVGhlIG9iamVjdCB0byBzZWFyY2guXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IC0gVGhlIGtleSB0byBmaW5kIChjYXNlLWluc2Vuc2l0aXZlKS5cbiAqIEByZXR1cm5zIHs/c3RyaW5nfSBUaGUgYWN0dWFsIGtleSBuYW1lIGlmIGZvdW5kLCBvdGhlcndpc2UgbnVsbC5cbiAqL1xuZnVuY3Rpb24gZmluZEtleShvYmosIGtleSkge1xuICBpZiAoaXNCdWZmZXIob2JqKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAga2V5ID0ga2V5LnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvYmopO1xuICBsZXQgaSA9IGtleXMubGVuZ3RoO1xuICBsZXQgX2tleTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBfa2V5ID0ga2V5c1tpXTtcbiAgICBpZiAoa2V5ID09PSBfa2V5LnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgIHJldHVybiBfa2V5O1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuY29uc3QgX2dsb2JhbCA9ICgoKSA9PiB7XG4gIC8qZXNsaW50IG5vLXVuZGVmOjAqL1xuICBpZiAodHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnKSByZXR1cm4gZ2xvYmFsVGhpcztcbiAgcmV0dXJuIHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdyA6IGdsb2JhbDtcbn0pKCk7XG5cbmNvbnN0IGlzQ29udGV4dERlZmluZWQgPSAoY29udGV4dCkgPT4gIWlzVW5kZWZpbmVkKGNvbnRleHQpICYmIGNvbnRleHQgIT09IF9nbG9iYWw7XG5cbi8qKlxuICogQWNjZXB0cyB2YXJhcmdzIGV4cGVjdGluZyBlYWNoIGFyZ3VtZW50IHRvIGJlIGFuIG9iamVjdCwgdGhlblxuICogaW1tdXRhYmx5IG1lcmdlcyB0aGUgcHJvcGVydGllcyBvZiBlYWNoIG9iamVjdCBhbmQgcmV0dXJucyByZXN1bHQuXG4gKlxuICogV2hlbiBtdWx0aXBsZSBvYmplY3RzIGNvbnRhaW4gdGhlIHNhbWUga2V5IHRoZSBsYXRlciBvYmplY3QgaW5cbiAqIHRoZSBhcmd1bWVudHMgbGlzdCB3aWxsIHRha2UgcHJlY2VkZW5jZS5cbiAqXG4gKiBFeGFtcGxlOlxuICpcbiAqIGBgYGpzXG4gKiBjb25zdCByZXN1bHQgPSBtZXJnZSh7Zm9vOiAxMjN9LCB7Zm9vOiA0NTZ9KTtcbiAqIGNvbnNvbGUubG9nKHJlc3VsdC5mb28pOyAvLyBvdXRwdXRzIDQ1NlxuICogYGBgXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9iajEgT2JqZWN0IHRvIG1lcmdlXG4gKlxuICogQHJldHVybnMge09iamVjdH0gUmVzdWx0IG9mIGFsbCBtZXJnZSBwcm9wZXJ0aWVzXG4gKi9cbmZ1bmN0aW9uIG1lcmdlKC4uLm9ianMpIHtcbiAgY29uc3QgeyBjYXNlbGVzcywgc2tpcFVuZGVmaW5lZCB9ID0gKGlzQ29udGV4dERlZmluZWQodGhpcykgJiYgdGhpcykgfHwge307XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAvLyBDYXNlbGVzcyBsb29rdXAgb25seSBhcHBsaWVzIHRvIHN0cmluZyBrZXlzIOKAlCBzeW1ib2wga2V5cyBhcmVcbiAgLy8gaWRlbnRpdHktbWF0Y2hlZC4gRXZlcnkgc3RyaW5nIGtleSB0aGF0IHJlYWNoZXMgYHJlc3VsdGAgcGFzc2VzIHRocm91Z2hcbiAgLy8gdGhpcyBpbmRleCBmaXJzdCwgc28gaXQgY2FuIG5ldmVyIGhvbGQgdHdvIGNhc2UgdmFyaWFudHMgb2Ygb25lIGtleSBhbmQgYVxuICAvLyBsb3dlcmNhc2UgLT4ga2V5IG1hcCBpcyBleGFjdGx5IHdoYXQgZmluZEtleShyZXN1bHQsIGtleSkgd291bGQgcmVzY2FuXG4gIC8vIE9iamVjdC5rZXlzKHJlc3VsdCkgZm9yIG9uIGVhY2ggYXNzaWdubWVudC5cbiAgY29uc3QgbG93ZXJDYXNlS2V5cyA9IGNhc2VsZXNzID8gT2JqZWN0LmNyZWF0ZShudWxsKSA6IG51bGw7XG4gIGNvbnN0IGFzc2lnblZhbHVlID0gKHZhbCwga2V5KSA9PiB7XG4gICAgLy8gU2tpcCBkYW5nZXJvdXMgcHJvcGVydHkgbmFtZXMgdG8gcHJldmVudCBwcm90b3R5cGUgcG9sbHV0aW9uXG4gICAgaWYgKGtleSA9PT0gJ19fcHJvdG9fXycgfHwga2V5ID09PSAnY29uc3RydWN0b3InIHx8IGtleSA9PT0gJ3Byb3RvdHlwZScpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBsZXQgdGFyZ2V0S2V5ID0ga2V5O1xuICAgIGlmIChsb3dlckNhc2VLZXlzICYmIHR5cGVvZiBrZXkgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCBsb3dlcktleSA9IGtleS50b0xvd2VyQ2FzZSgpO1xuICAgICAgY29uc3Qga25vd25LZXkgPSBsb3dlckNhc2VLZXlzW2xvd2VyS2V5XTtcbiAgICAgIC8vIEEga2V5IHJlY29yZGVkIGJ1dCBhYnNlbnQgZnJvbSBgcmVzdWx0YCB3YXMgc2tpcHBlZCBieSBza2lwVW5kZWZpbmVkO1xuICAgICAgLy8gdGhlIGxhdGVyIHNwZWxsaW5nIHdpbnMgdGhlbiwgYXMgaXQgZG9lcyBmb3IgZmluZEtleS5cbiAgICAgIGlmIChrbm93bktleSAhPT0gdW5kZWZpbmVkICYmIGhhc093blByb3BlcnR5KHJlc3VsdCwga25vd25LZXkpKSB7XG4gICAgICAgIHRhcmdldEtleSA9IGtub3duS2V5O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbG93ZXJDYXNlS2V5c1tsb3dlcktleV0gPSBrZXk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFJlYWQgdmlhIG93bi1wcm9wIG9ubHkg4oCUIGEgYmFyZSBgcmVzdWx0W3RhcmdldEtleV1gIHdhbGtzIHRoZSBwcm90b3R5cGVcbiAgICAvLyBjaGFpbiwgc28gYSBwb2xsdXRlZCBPYmplY3QucHJvdG90eXBlIHZhbHVlIGNvdWxkIHN1cmZhY2UgaGVyZSBhbmQgZ2V0XG4gICAgLy8gY29waWVkIGludG8gdGhlIG1lcmdlZCByZXN1bHQuXG4gICAgY29uc3QgZXhpc3RpbmcgPSBoYXNPd25Qcm9wZXJ0eShyZXN1bHQsIHRhcmdldEtleSkgPyByZXN1bHRbdGFyZ2V0S2V5XSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoaXNQbGFpbk9iamVjdChleGlzdGluZykgJiYgaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICByZXN1bHRbdGFyZ2V0S2V5XSA9IG1lcmdlKGV4aXN0aW5nLCB2YWwpO1xuICAgIH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICByZXN1bHRbdGFyZ2V0S2V5XSA9IG1lcmdlKHt9LCB2YWwpO1xuICAgIH0gZWxzZSBpZiAoaXNBcnJheSh2YWwpKSB7XG4gICAgICByZXN1bHRbdGFyZ2V0S2V5XSA9IHZhbC5zbGljZSgpO1xuICAgIH0gZWxzZSBpZiAoIXNraXBVbmRlZmluZWQgfHwgIWlzVW5kZWZpbmVkKHZhbCkpIHtcbiAgICAgIHJlc3VsdFt0YXJnZXRLZXldID0gdmFsO1xuICAgIH1cbiAgfTtcblxuICBmb3IgKGxldCBpID0gMCwgbCA9IG9ianMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgY29uc3Qgc291cmNlID0gb2Jqc1tpXTtcbiAgICBpZiAoIXNvdXJjZSB8fCBpc0J1ZmZlcihzb3VyY2UpKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBmb3JFYWNoKHNvdXJjZSwgYXNzaWduVmFsdWUpO1xuXG4gICAgaWYgKHR5cGVvZiBzb3VyY2UgIT09ICdvYmplY3QnIHx8IGlzQXJyYXkoc291cmNlKSB8fCAhT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgY29uc3Qgc3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlKTtcbiAgICBmb3IgKGxldCBqID0gMDsgaiA8IHN5bWJvbHMubGVuZ3RoOyBqKyspIHtcbiAgICAgIGNvbnN0IHN5bWJvbCA9IHN5bWJvbHNbal07XG4gICAgICBpZiAocHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzb3VyY2UsIHN5bWJvbCkpIHtcbiAgICAgICAgYXNzaWduVmFsdWUoc291cmNlW3N5bWJvbF0sIHN5bWJvbCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8qKlxuICogRXh0ZW5kcyBvYmplY3QgYSBieSBtdXRhYmx5IGFkZGluZyB0byBpdCB0aGUgcHJvcGVydGllcyBvZiBvYmplY3QgYi5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gYSBUaGUgb2JqZWN0IHRvIGJlIGV4dGVuZGVkXG4gKiBAcGFyYW0ge09iamVjdH0gYiBUaGUgb2JqZWN0IHRvIGNvcHkgcHJvcGVydGllcyBmcm9tXG4gKiBAcGFyYW0ge09iamVjdH0gdGhpc0FyZyBUaGUgb2JqZWN0IHRvIGJpbmQgZnVuY3Rpb24gdG9cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvcHRpb25zLmFsbE93bktleXNdXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBUaGUgcmVzdWx0aW5nIHZhbHVlIG9mIG9iamVjdCBhXG4gKi9cbmNvbnN0IGV4dGVuZCA9IChhLCBiLCB0aGlzQXJnLCB7IGFsbE93bktleXMgfSA9IHt9KSA9PiB7XG4gIGZvckVhY2goXG4gICAgYixcbiAgICAodmFsLCBrZXkpID0+IHtcbiAgICAgIGlmICh0aGlzQXJnICYmIGlzRnVuY3Rpb24odmFsKSkge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYSwga2V5LCB7XG4gICAgICAgICAgLy8gTnVsbC1wcm90byBkZXNjcmlwdG9yIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90XG4gICAgICAgICAgLy8gaGlqYWNrIGRlZmluZVByb3BlcnR5J3MgYWNjZXNzb3ItdnMtZGF0YSByZXNvbHV0aW9uLlxuICAgICAgICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICAgICAgICB2YWx1ZTogYmluZCh2YWwsIHRoaXNBcmcpLFxuICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShhLCBrZXksIHtcbiAgICAgICAgICBfX3Byb3RvX186IG51bGwsXG4gICAgICAgICAgdmFsdWU6IHZhbCxcbiAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICB7IGFsbE93bktleXMgfVxuICApO1xuICByZXR1cm4gYTtcbn07XG5cbi8qKlxuICogUmVtb3ZlIGJ5dGUgb3JkZXIgbWFya2VyLiBUaGlzIGNhdGNoZXMgRUYgQkIgQkYgKHRoZSBVVEYtOCBCT00pXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGNvbnRlbnQgd2l0aCBCT01cbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBjb250ZW50IHZhbHVlIHdpdGhvdXQgQk9NXG4gKi9cbmNvbnN0IHN0cmlwQk9NID0gKGNvbnRlbnQpID0+IHtcbiAgaWYgKGNvbnRlbnQuY2hhckNvZGVBdCgwKSA9PT0gMHhmZWZmKSB7XG4gICAgY29udGVudCA9IGNvbnRlbnQuc2xpY2UoMSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRlbnQ7XG59O1xuXG4vKipcbiAqIEluaGVyaXQgdGhlIHByb3RvdHlwZSBtZXRob2RzIGZyb20gb25lIGNvbnN0cnVjdG9yIGludG8gYW5vdGhlclxuICogQHBhcmFtIHtmdW5jdGlvbn0gY29uc3RydWN0b3JcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IHN1cGVyQ29uc3RydWN0b3JcbiAqIEBwYXJhbSB7b2JqZWN0fSBbcHJvcHNdXG4gKiBAcGFyYW0ge29iamVjdH0gW2Rlc2NyaXB0b3JzXVxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5jb25zdCBpbmhlcml0cyA9IChjb25zdHJ1Y3Rvciwgc3VwZXJDb25zdHJ1Y3RvciwgcHJvcHMsIGRlc2NyaXB0b3JzKSA9PiB7XG4gIGNvbnN0cnVjdG9yLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoc3VwZXJDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIGRlc2NyaXB0b3JzKTtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvbnN0cnVjdG9yLnByb3RvdHlwZSwgJ2NvbnN0cnVjdG9yJywge1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICB2YWx1ZTogY29uc3RydWN0b3IsXG4gICAgd3JpdGFibGU6IHRydWUsXG4gICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICB9KTtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvbnN0cnVjdG9yLCAnc3VwZXInLCB7XG4gICAgX19wcm90b19fOiBudWxsLFxuICAgIHZhbHVlOiBzdXBlckNvbnN0cnVjdG9yLnByb3RvdHlwZSxcbiAgfSk7XG4gIHByb3BzICYmIE9iamVjdC5hc3NpZ24oY29uc3RydWN0b3IucHJvdG90eXBlLCBwcm9wcyk7XG59O1xuXG4vKipcbiAqIFJlc29sdmUgb2JqZWN0IHdpdGggZGVlcCBwcm90b3R5cGUgY2hhaW4gdG8gYSBmbGF0IG9iamVjdFxuICogQHBhcmFtIHtPYmplY3R9IHNvdXJjZU9iaiBzb3VyY2Ugb2JqZWN0XG4gKiBAcGFyYW0ge09iamVjdH0gW2Rlc3RPYmpdXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufEJvb2xlYW59IFtmaWx0ZXJdXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBbcHJvcEZpbHRlcl1cbiAqXG4gKiBAcmV0dXJucyB7T2JqZWN0fVxuICovXG5jb25zdCB0b0ZsYXRPYmplY3QgPSAoc291cmNlT2JqLCBkZXN0T2JqLCBmaWx0ZXIsIHByb3BGaWx0ZXIpID0+IHtcbiAgbGV0IHByb3BzO1xuICBsZXQgaTtcbiAgbGV0IHByb3A7XG4gIGNvbnN0IG1lcmdlZCA9IHt9O1xuXG4gIGRlc3RPYmogPSBkZXN0T2JqIHx8IHt9O1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZXEtbnVsbCxlcWVxZXFcbiAgaWYgKHNvdXJjZU9iaiA9PSBudWxsKSByZXR1cm4gZGVzdE9iajtcblxuICBkbyB7XG4gICAgcHJvcHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhzb3VyY2VPYmopO1xuICAgIGkgPSBwcm9wcy5sZW5ndGg7XG4gICAgd2hpbGUgKGktLSA+IDApIHtcbiAgICAgIHByb3AgPSBwcm9wc1tpXTtcbiAgICAgIGlmICgoIXByb3BGaWx0ZXIgfHwgcHJvcEZpbHRlcihwcm9wLCBzb3VyY2VPYmosIGRlc3RPYmopKSAmJiAhbWVyZ2VkW3Byb3BdKSB7XG4gICAgICAgIGRlc3RPYmpbcHJvcF0gPSBzb3VyY2VPYmpbcHJvcF07XG4gICAgICAgIG1lcmdlZFtwcm9wXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHNvdXJjZU9iaiA9IGZpbHRlciAhPT0gZmFsc2UgJiYgZ2V0UHJvdG90eXBlT2Yoc291cmNlT2JqKTtcbiAgfSB3aGlsZSAoc291cmNlT2JqICYmICghZmlsdGVyIHx8IGZpbHRlcihzb3VyY2VPYmosIGRlc3RPYmopKSAmJiBzb3VyY2VPYmogIT09IE9iamVjdC5wcm90b3R5cGUpO1xuXG4gIHJldHVybiBkZXN0T2JqO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgYSBzdHJpbmcgZW5kcyB3aXRoIHRoZSBjaGFyYWN0ZXJzIG9mIGEgc3BlY2lmaWVkIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAqIEBwYXJhbSB7U3RyaW5nfSBzZWFyY2hTdHJpbmdcbiAqIEBwYXJhbSB7TnVtYmVyfSBbcG9zaXRpb249IDBdXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmNvbnN0IGVuZHNXaXRoID0gKHN0ciwgc2VhcmNoU3RyaW5nLCBwb3NpdGlvbikgPT4ge1xuICBzdHIgPSBTdHJpbmcoc3RyKTtcbiAgaWYgKHBvc2l0aW9uID09PSB1bmRlZmluZWQgfHwgcG9zaXRpb24gPiBzdHIubGVuZ3RoKSB7XG4gICAgcG9zaXRpb24gPSBzdHIubGVuZ3RoO1xuICB9XG4gIHBvc2l0aW9uIC09IHNlYXJjaFN0cmluZy5sZW5ndGg7XG4gIGNvbnN0IGxhc3RJbmRleCA9IHN0ci5pbmRleE9mKHNlYXJjaFN0cmluZywgcG9zaXRpb24pO1xuICByZXR1cm4gbGFzdEluZGV4ICE9PSAtMSAmJiBsYXN0SW5kZXggPT09IHBvc2l0aW9uO1xufTtcblxuLyoqXG4gKiBSZXR1cm5zIG5ldyBhcnJheSBmcm9tIGFycmF5IGxpa2Ugb2JqZWN0IG9yIG51bGwgaWYgZmFpbGVkXG4gKlxuICogQHBhcmFtIHsqfSBbdGhpbmddXG4gKlxuICogQHJldHVybnMgez9BcnJheX1cbiAqL1xuY29uc3QgdG9BcnJheSA9ICh0aGluZykgPT4ge1xuICBpZiAoIXRoaW5nKSByZXR1cm4gbnVsbDtcbiAgaWYgKGlzQXJyYXkodGhpbmcpKSByZXR1cm4gdGhpbmc7XG4gIGxldCBpID0gdGhpbmcubGVuZ3RoO1xuICBpZiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKGkpIHx8IGkgPCAwIHx8IGkgPiAweGZmZmZmZmZmKSByZXR1cm4gbnVsbDtcblxuICAvLyBCb3VuZCB0aGUgY29weSBieSBhY3R1YWwgaW5kZXhlZCBwcm9wZXJ0aWVzLCBpbmNsdWRpbmcgaGlkZGVuIGFuZCBpbmhlcml0ZWRcbiAgLy8gbWVtYmVycyBvZiBhcnJheS1saWtlIGNvbGxlY3Rpb25zLCByYXRoZXIgdGhhbiBieSB0aGUgZGVjbGFyZWQgbGVuZ3RoIGFsb25lLlxuICBjb25zdCBpbmRleGVzID0gbmV3IFNldCgpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldCgpO1xuICBsZXQgc291cmNlID0gdGhpbmc7XG5cbiAgd2hpbGUgKHNvdXJjZSAhPSBudWxsICYmIGluZGV4ZXMuc2l6ZSA8IGkpIHtcbiAgICBpZiAoc2Vlbi5oYXMoc291cmNlKSkgcmV0dXJuIG51bGw7XG4gICAgc2Vlbi5hZGQoc291cmNlKTtcblxuICAgIGNvbnN0IHByb3RvdHlwZSA9IGdldFByb3RvdHlwZU9mKHNvdXJjZSk7XG4gICAgaWYgKGlzUHJvdG90eXBlQm91bmRhcnkoc291cmNlLCBwcm90b3R5cGUsIHNvdXJjZSA9PT0gdGhpbmcpKSBicmVhaztcblxuICAgIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHNvdXJjZSkuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBjb25zdCBpbmRleCA9ICtrZXk7XG4gICAgICBpZiAoXG4gICAgICAgIE51bWJlci5pc0ludGVnZXIoaW5kZXgpICYmXG4gICAgICAgIGluZGV4ID49IDAgJiZcbiAgICAgICAgaW5kZXggPCBpICYmXG4gICAgICAgIFN0cmluZyhpbmRleCkgPT09IGtleSAmJlxuICAgICAgICBoYXNPd25Qcm9wZXJ0eShzb3VyY2UsIGtleSlcbiAgICAgICkge1xuICAgICAgICBpbmRleGVzLmFkZChpbmRleCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgc291cmNlID0gcHJvdG90eXBlO1xuICB9XG5cbiAgaWYgKGluZGV4ZXMuc2l6ZSAhPT0gaSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGFyciA9IG5ldyBBcnJheShpKTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBhcnJbaV0gPSB0aGluZ1tpXTtcbiAgfVxuICByZXR1cm4gYXJyO1xufTtcblxuLyoqXG4gKiBDaGVja2luZyBpZiB0aGUgVWludDhBcnJheSBleGlzdHMgYW5kIGlmIGl0IGRvZXMsIGl0IHJldHVybnMgYSBmdW5jdGlvbiB0aGF0IGNoZWNrcyBpZiB0aGVcbiAqIHRoaW5nIHBhc3NlZCBpbiBpcyBhbiBpbnN0YW5jZSBvZiBVaW50OEFycmF5XG4gKlxuICogQHBhcmFtIHtUeXBlZEFycmF5fVxuICpcbiAqIEByZXR1cm5zIHtBcnJheX1cbiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbmNvbnN0IGlzVHlwZWRBcnJheSA9ICgoVHlwZWRBcnJheSkgPT4ge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICByZXR1cm4gKHRoaW5nKSA9PiB7XG4gICAgcmV0dXJuIFR5cGVkQXJyYXkgJiYgdGhpbmcgaW5zdGFuY2VvZiBUeXBlZEFycmF5O1xuICB9O1xufSkodHlwZW9mIFVpbnQ4QXJyYXkgIT09ICd1bmRlZmluZWQnICYmIGdldFByb3RvdHlwZU9mKFVpbnQ4QXJyYXkpKTtcblxuLyoqXG4gKiBGb3IgZWFjaCBlbnRyeSBpbiB0aGUgb2JqZWN0LCBjYWxsIHRoZSBmdW5jdGlvbiB3aXRoIHRoZSBrZXkgYW5kIHZhbHVlLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PGFueSwgYW55Pn0gb2JqIC0gVGhlIG9iamVjdCB0byBpdGVyYXRlIG92ZXIuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBmbiAtIFRoZSBmdW5jdGlvbiB0byBjYWxsIGZvciBlYWNoIGVudHJ5LlxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5jb25zdCBmb3JFYWNoRW50cnkgPSAob2JqLCBmbikgPT4ge1xuICBjb25zdCBnZW5lcmF0b3IgPSBvYmogJiYgb2JqW2l0ZXJhdG9yXTtcblxuICBjb25zdCBfaXRlcmF0b3IgPSBnZW5lcmF0b3IuY2FsbChvYmopO1xuXG4gIGxldCByZXN1bHQ7XG5cbiAgd2hpbGUgKChyZXN1bHQgPSBfaXRlcmF0b3IubmV4dCgpKSAmJiAhcmVzdWx0LmRvbmUpIHtcbiAgICBjb25zdCBwYWlyID0gcmVzdWx0LnZhbHVlO1xuICAgIGZuLmNhbGwob2JqLCBwYWlyWzBdLCBwYWlyWzFdKTtcbiAgfVxufTtcblxuLyoqXG4gKiBJdCB0YWtlcyBhIHJlZ3VsYXIgZXhwcmVzc2lvbiBhbmQgYSBzdHJpbmcsIGFuZCByZXR1cm5zIGFuIGFycmF5IG9mIGFsbCB0aGUgbWF0Y2hlc1xuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSByZWdFeHAgLSBUaGUgcmVndWxhciBleHByZXNzaW9uIHRvIG1hdGNoIGFnYWluc3QuXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyIC0gVGhlIHN0cmluZyB0byBzZWFyY2guXG4gKlxuICogQHJldHVybnMge0FycmF5PGJvb2xlYW4+fVxuICovXG5jb25zdCBtYXRjaEFsbCA9IChyZWdFeHAsIHN0cikgPT4ge1xuICBsZXQgbWF0Y2hlcztcbiAgY29uc3QgYXJyID0gW107XG5cbiAgd2hpbGUgKChtYXRjaGVzID0gcmVnRXhwLmV4ZWMoc3RyKSkgIT09IG51bGwpIHtcbiAgICBhcnIucHVzaChtYXRjaGVzKTtcbiAgfVxuXG4gIHJldHVybiBhcnI7XG59O1xuXG4vKiBDaGVja2luZyBpZiB0aGUga2luZE9mVGVzdCBmdW5jdGlvbiByZXR1cm5zIHRydWUgd2hlbiBwYXNzZWQgYW4gSFRNTEZvcm1FbGVtZW50LiAqL1xuY29uc3QgaXNIVE1MRm9ybSA9IGtpbmRPZlRlc3QoJ0hUTUxGb3JtRWxlbWVudCcpO1xuXG5jb25zdCB0b0NhbWVsQ2FzZSA9IChzdHIpID0+IHtcbiAgcmV0dXJuIHN0ci50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1stX1xcc10oW2EtelxcZF0pKFxcdyopL2csIGZ1bmN0aW9uIHJlcGxhY2VyKG0sIHAxLCBwMikge1xuICAgIHJldHVybiBwMS50b1VwcGVyQ2FzZSgpICsgcDI7XG4gIH0pO1xufTtcblxuY29uc3QgeyBwcm9wZXJ0eUlzRW51bWVyYWJsZSB9ID0gT2JqZWN0LnByb3RvdHlwZTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFJlZ0V4cCBvYmplY3RcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgUmVnRXhwIG9iamVjdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzUmVnRXhwID0ga2luZE9mVGVzdCgnUmVnRXhwJyk7XG5cbmNvbnN0IHJlZHVjZURlc2NyaXB0b3JzID0gKG9iaiwgcmVkdWNlcikgPT4ge1xuICBjb25zdCBkZXNjcmlwdG9ycyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKG9iaik7XG4gIGNvbnN0IHJlZHVjZWREZXNjcmlwdG9ycyA9IHt9O1xuXG4gIGZvckVhY2goZGVzY3JpcHRvcnMsIChkZXNjcmlwdG9yLCBuYW1lKSA9PiB7XG4gICAgbGV0IHJldDtcbiAgICBpZiAoKHJldCA9IHJlZHVjZXIoZGVzY3JpcHRvciwgbmFtZSwgb2JqKSkgIT09IGZhbHNlKSB7XG4gICAgICByZWR1Y2VkRGVzY3JpcHRvcnNbbmFtZV0gPSByZXQgfHwgZGVzY3JpcHRvcjtcbiAgICB9XG4gIH0pO1xuXG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9iaiwgcmVkdWNlZERlc2NyaXB0b3JzKTtcbn07XG5cbi8qKlxuICogTWFrZXMgYWxsIG1ldGhvZHMgcmVhZC1vbmx5XG4gKiBAcGFyYW0ge09iamVjdH0gb2JqXG4gKi9cblxuY29uc3QgZnJlZXplTWV0aG9kcyA9IChvYmopID0+IHtcbiAgcmVkdWNlRGVzY3JpcHRvcnMob2JqLCAoZGVzY3JpcHRvciwgbmFtZSkgPT4ge1xuICAgIC8vIHNraXAgcmVzdHJpY3RlZCBwcm9wcyBpbiBzdHJpY3QgbW9kZVxuICAgIGlmIChpc0Z1bmN0aW9uKG9iaikgJiYgWydhcmd1bWVudHMnLCAnY2FsbGVyJywgJ2NhbGxlZSddLmluY2x1ZGVzKG5hbWUpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY29uc3QgdmFsdWUgPSBvYmpbbmFtZV07XG5cbiAgICBpZiAoIWlzRnVuY3Rpb24odmFsdWUpKSByZXR1cm47XG5cbiAgICBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBmYWxzZTtcblxuICAgIGlmICgnd3JpdGFibGUnIGluIGRlc2NyaXB0b3IpIHtcbiAgICAgIGRlc2NyaXB0b3Iud3JpdGFibGUgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIWRlc2NyaXB0b3Iuc2V0KSB7XG4gICAgICBkZXNjcmlwdG9yLnNldCA9ICgpID0+IHtcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJDYW4gbm90IHJld3JpdGUgcmVhZC1vbmx5IG1ldGhvZCAnXCIgKyBuYW1lICsgXCInXCIpO1xuICAgICAgfTtcbiAgICB9XG4gIH0pO1xufTtcblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvciBhIGRlbGltaXRlZCBzdHJpbmcgaW50byBhbiBvYmplY3Qgc2V0IHdpdGggdmFsdWVzIGFzIGtleXMgYW5kIHRydWUgYXMgdmFsdWVzLlxuICogVXNlZnVsIGZvciBmYXN0IG1lbWJlcnNoaXAgY2hlY2tzLlxuICpcbiAqIEBwYXJhbSB7QXJyYXl8c3RyaW5nfSBhcnJheU9yU3RyaW5nIC0gVGhlIGFycmF5IG9yIHN0cmluZyB0byBjb252ZXJ0LlxuICogQHBhcmFtIHtzdHJpbmd9IGRlbGltaXRlciAtIFRoZSBkZWxpbWl0ZXIgdG8gdXNlIGlmIGlucHV0IGlzIGEgc3RyaW5nLlxuICogQHJldHVybnMge09iamVjdH0gQW4gb2JqZWN0IHdpdGgga2V5cyBmcm9tIHRoZSBhcnJheSBvciBzdHJpbmcsIHZhbHVlcyBzZXQgdG8gdHJ1ZS5cbiAqL1xuY29uc3QgdG9PYmplY3RTZXQgPSAoYXJyYXlPclN0cmluZywgZGVsaW1pdGVyKSA9PiB7XG4gIGNvbnN0IG9iaiA9IHt9O1xuXG4gIGNvbnN0IGRlZmluZSA9IChhcnIpID0+IHtcbiAgICBhcnIuZm9yRWFjaCgodmFsdWUpID0+IHtcbiAgICAgIG9ialt2YWx1ZV0gPSB0cnVlO1xuICAgIH0pO1xuICB9O1xuXG4gIGlzQXJyYXkoYXJyYXlPclN0cmluZykgPyBkZWZpbmUoYXJyYXlPclN0cmluZykgOiBkZWZpbmUoU3RyaW5nKGFycmF5T3JTdHJpbmcpLnNwbGl0KGRlbGltaXRlcikpO1xuXG4gIHJldHVybiBvYmo7XG59O1xuXG5jb25zdCBub29wID0gKCkgPT4ge307XG5cbmNvbnN0IHRvRmluaXRlTnVtYmVyID0gKHZhbHVlLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgcmV0dXJuIHZhbHVlICE9IG51bGwgJiYgTnVtYmVyLmlzRmluaXRlKCh2YWx1ZSA9ICt2YWx1ZSkpID8gdmFsdWUgOiBkZWZhdWx0VmFsdWU7XG59O1xuXG4vKipcbiAqIElmIHRoZSB0aGluZyBpcyBhIEZvcm1EYXRhIG9iamVjdCwgcmV0dXJuIHRydWUsIG90aGVyd2lzZSByZXR1cm4gZmFsc2UuXG4gKlxuICogQHBhcmFtIHt1bmtub3dufSB0aGluZyAtIFRoZSB0aGluZyB0byBjaGVjay5cbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gaXNTcGVjQ29tcGxpYW50Rm9ybSh0aGluZykge1xuICByZXR1cm4gISEoXG4gICAgdGhpbmcgJiZcbiAgICBpc0Z1bmN0aW9uKHRoaW5nLmFwcGVuZCkgJiZcbiAgICB0aGluZ1t0b1N0cmluZ1RhZ10gPT09ICdGb3JtRGF0YScgJiZcbiAgICB0aGluZ1tpdGVyYXRvcl1cbiAgKTtcbn1cblxuLyoqXG4gKiBSZWN1cnNpdmVseSBjb252ZXJ0cyBhbiBvYmplY3QgdG8gYSBKU09OLWNvbXBhdGlibGUgb2JqZWN0LCBoYW5kbGluZyBjaXJjdWxhciByZWZlcmVuY2VzIGFuZCBCdWZmZXJzLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmogLSBUaGUgb2JqZWN0IHRvIGNvbnZlcnQuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBUaGUgSlNPTi1jb21wYXRpYmxlIG9iamVjdC5cbiAqL1xuY29uc3QgdG9KU09OT2JqZWN0ID0gKG9iaikgPT4ge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQoKTtcblxuICBjb25zdCB2aXNpdCA9IChzb3VyY2UpID0+IHtcbiAgICBpZiAoaXNPYmplY3Qoc291cmNlKSkge1xuICAgICAgaWYgKHZpc2l0ZWQuaGFzKHNvdXJjZSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvL0J1ZmZlciBjaGVja1xuICAgICAgaWYgKGlzQnVmZmVyKHNvdXJjZSkpIHtcbiAgICAgICAgcmV0dXJuIHNvdXJjZTtcbiAgICAgIH1cblxuICAgICAgaWYgKCEoJ3RvSlNPTicgaW4gc291cmNlKSkge1xuICAgICAgICAvLyBhZGQtb24gZGVzY2VudCAvIGRlbGV0ZS1vbi1hc2NlbnQ6IHByZXNlcnZlcyBwYXRoIHNlbWFudGljcywgc28gREFHIG5vZGVzIHNlcmlhbGlzZSBhdCBldmVyeSBvY2N1cnJlbmNlIChzZWUgIzcyMzApLlxuICAgICAgICB2aXNpdGVkLmFkZChzb3VyY2UpO1xuXG4gICAgICAgIGxldCB0YXJnZXQ7XG5cbiAgICAgICAgaWYgKGlzU2V0KHNvdXJjZSkpIHtcbiAgICAgICAgICB0YXJnZXQgPSBbXTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIHNvdXJjZSkge1xuICAgICAgICAgICAgY29uc3QgcmVkdWNlZFZhbHVlID0gdmlzaXQodmFsdWUpO1xuICAgICAgICAgICAgIWlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkgJiYgdGFyZ2V0LnB1c2gocmVkdWNlZFZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGFyZ2V0ID0gaXNBcnJheShzb3VyY2UpID8gW10gOiB7fTtcblxuICAgICAgICAgIGZvckVhY2goc291cmNlLCAodmFsdWUsIGtleSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVkdWNlZFZhbHVlID0gdmlzaXQodmFsdWUpO1xuICAgICAgICAgICAgIWlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkgJiYgKHRhcmdldFtrZXldID0gcmVkdWNlZFZhbHVlKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZpc2l0ZWQuZGVsZXRlKHNvdXJjZSk7XG5cbiAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gc291cmNlO1xuICB9O1xuXG4gIHJldHVybiB2aXNpdChvYmopO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmVzIGlmIGEgdmFsdWUgaXMgYW4gYXN5bmMgZnVuY3Rpb24uXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyAtIFRoZSB2YWx1ZSB0byB0ZXN0LlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gYXN5bmMgZnVuY3Rpb24sIG90aGVyd2lzZSBmYWxzZS5cbiAqL1xuY29uc3QgaXNBc3luY0ZuID0ga2luZE9mVGVzdCgnQXN5bmNGdW5jdGlvbicpO1xuXG4vKipcbiAqIERldGVybWluZXMgaWYgYSB2YWx1ZSBpcyB0aGVuYWJsZSAoaGFzIHRoZW4gYW5kIGNhdGNoIG1ldGhvZHMpLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgLSBUaGUgdmFsdWUgdG8gdGVzdC5cbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIHRoZW5hYmxlLCBvdGhlcndpc2UgZmFsc2UuXG4gKi9cbmNvbnN0IGlzVGhlbmFibGUgPSAodGhpbmcpID0+XG4gIHRoaW5nICYmXG4gIChpc09iamVjdCh0aGluZykgfHwgaXNGdW5jdGlvbih0aGluZykpICYmXG4gIGlzRnVuY3Rpb24odGhpbmcudGhlbikgJiZcbiAgaXNGdW5jdGlvbih0aGluZy5jYXRjaCk7XG5cbi8vIG9yaWdpbmFsIGNvZGVcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9EaWdpdGFsQnJhaW5KUy9BeGlvc1Byb21pc2UvYmxvYi8xNmRlYWIxMzcxMGVjMDk3Nzk5MjIxMzFmM2ZhNTk1NDMyMGY4M2FiL2xpYi91dGlscy5qcyNMMTEtTDM0XG5cbi8qKlxuICogUHJvdmlkZXMgYSBjcm9zcy1wbGF0Zm9ybSBzZXRJbW1lZGlhdGUgaW1wbGVtZW50YXRpb24uXG4gKiBVc2VzIG5hdGl2ZSBzZXRJbW1lZGlhdGUgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgZmFsbHMgYmFjayB0byBwb3N0TWVzc2FnZSBvciBzZXRUaW1lb3V0LlxuICpcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gc2V0SW1tZWRpYXRlU3VwcG9ydGVkIC0gV2hldGhlciBzZXRJbW1lZGlhdGUgaXMgc3VwcG9ydGVkLlxuICogQHBhcmFtIHtib29sZWFufSBwb3N0TWVzc2FnZVN1cHBvcnRlZCAtIFdoZXRoZXIgcG9zdE1lc3NhZ2UgaXMgc3VwcG9ydGVkLlxuICogQHJldHVybnMge0Z1bmN0aW9ufSBBIGZ1bmN0aW9uIHRvIHNjaGVkdWxlIGEgY2FsbGJhY2sgYXN5bmNocm9ub3VzbHkuXG4gKi9cbmNvbnN0IF9zZXRJbW1lZGlhdGUgPSAoKHNldEltbWVkaWF0ZVN1cHBvcnRlZCwgcG9zdE1lc3NhZ2VTdXBwb3J0ZWQpID0+IHtcbiAgaWYgKHNldEltbWVkaWF0ZVN1cHBvcnRlZCkge1xuICAgIHJldHVybiBzZXRJbW1lZGlhdGU7XG4gIH1cblxuICByZXR1cm4gcG9zdE1lc3NhZ2VTdXBwb3J0ZWRcbiAgICA/ICgodG9rZW4sIGNhbGxiYWNrcykgPT4ge1xuICAgICAgICBfZ2xvYmFsLmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgICAgJ21lc3NhZ2UnLFxuICAgICAgICAgICh7IHNvdXJjZSwgZGF0YSB9KSA9PiB7XG4gICAgICAgICAgICBpZiAoc291cmNlID09PSBfZ2xvYmFsICYmIGRhdGEgPT09IHRva2VuKSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrcy5sZW5ndGggJiYgY2FsbGJhY2tzLnNoaWZ0KCkoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIGZhbHNlXG4gICAgICAgICk7XG5cbiAgICAgICAgcmV0dXJuIChjYikgPT4ge1xuICAgICAgICAgIGNhbGxiYWNrcy5wdXNoKGNiKTtcbiAgICAgICAgICBfZ2xvYmFsLnBvc3RNZXNzYWdlKHRva2VuLCAnKicpO1xuICAgICAgICB9O1xuICAgICAgfSkoYGF4aW9zQCR7TWF0aC5yYW5kb20oKX1gLCBbXSlcbiAgICA6IChjYikgPT4gc2V0VGltZW91dChjYik7XG59KSh0eXBlb2Ygc2V0SW1tZWRpYXRlID09PSAnZnVuY3Rpb24nLCBpc0Z1bmN0aW9uKF9nbG9iYWwucG9zdE1lc3NhZ2UpKTtcblxuLyoqXG4gKiBTY2hlZHVsZXMgYSBtaWNyb3Rhc2sgb3IgYXN5bmNocm9ub3VzIGNhbGxiYWNrIGFzIHNvb24gYXMgcG9zc2libGUuXG4gKiBVc2VzIHF1ZXVlTWljcm90YXNrIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGZhbGxzIGJhY2sgdG8gcHJvY2Vzcy5uZXh0VGljayBvciBfc2V0SW1tZWRpYXRlLlxuICpcbiAqIEB0eXBlIHtGdW5jdGlvbn1cbiAqL1xuY29uc3QgYXNhcCA9XG4gIHR5cGVvZiBxdWV1ZU1pY3JvdGFzayAhPT0gJ3VuZGVmaW5lZCdcbiAgICA/IHF1ZXVlTWljcm90YXNrLmJpbmQoX2dsb2JhbClcbiAgICA6ICh0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgJiYgcHJvY2Vzcy5uZXh0VGljaykgfHwgX3NldEltbWVkaWF0ZTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqXG5cbmNvbnN0IGlzSXRlcmFibGUgPSAodGhpbmcpID0+IHRoaW5nICE9IG51bGwgJiYgaXNGdW5jdGlvbih0aGluZ1tpdGVyYXRvcl0pO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGl0ZXJhYmxlIHZpYSBhbiBpdGVyYXRvciB0aGF0IGlzIE5PVCBzb3VyY2VkIHNvbGVseVxuICogZnJvbSBhIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUuIFVzZSB0aGlzIGluc3RlYWQgb2YgYGlzSXRlcmFibGVgIHdoZW5ldmVyXG4gKiB0aGUgaXRlcmFibGUgY29tZXMgZnJvbSB1bnRydXN0ZWQgaW5wdXQgKGUuZy4gdXNlci1zdXBwbGllZCBoZWFkZXIgc291cmNlcyksXG4gKiBzbyBgT2JqZWN0LnByb3RvdHlwZVtTeW1ib2wuaXRlcmF0b3JdID0gLi4uYCBjYW5ub3QgdHVybiBhbiBvcmRpbmFyeSBvYmplY3RcbiAqIGludG8gYW4gYXR0YWNrZXItY29udHJvbGxlZCBlbnRyaWVzIGl0ZXJhdG9yLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBoYXMgYSBub24tcG9sbHV0ZWQgaXRlcmF0b3JcbiAqL1xuY29uc3QgaXNTYWZlSXRlcmFibGUgPSAodGhpbmcpID0+XG4gIHRoaW5nICE9IG51bGwgJiYgaGFzT3duSW5Qcm90b3R5cGVDaGFpbih0aGluZywgaXRlcmF0b3IpICYmIGlzSXRlcmFibGUodGhpbmcpO1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIGlzQXJyYXksXG4gIGlzQXJyYXlCdWZmZXIsXG4gIGlzQnVmZmVyLFxuICBpc0Zvcm1EYXRhLFxuICBpc0FycmF5QnVmZmVyVmlldyxcbiAgaXNTdHJpbmcsXG4gIGlzTnVtYmVyLFxuICBpc0Jvb2xlYW4sXG4gIGlzT2JqZWN0LFxuICBpc1BsYWluT2JqZWN0LFxuICBpc0VtcHR5T2JqZWN0LFxuICBpc1JlYWRhYmxlU3RyZWFtLFxuICBpc1JlcXVlc3QsXG4gIGlzUmVzcG9uc2UsXG4gIGlzSGVhZGVycyxcbiAgaXNVbmRlZmluZWQsXG4gIGlzRGF0ZSxcbiAgaXNGaWxlLFxuICBpc1JlYWN0TmF0aXZlQmxvYixcbiAgaXNSZWFjdE5hdGl2ZSxcbiAgaXNCbG9iLFxuICBpc1JlZ0V4cCxcbiAgaXNGdW5jdGlvbixcbiAgaXNTdHJlYW0sXG4gIGlzVVJMU2VhcmNoUGFyYW1zLFxuICBpc1R5cGVkQXJyYXksXG4gIGlzRmlsZUxpc3QsXG4gIGZvckVhY2gsXG4gIG1lcmdlLFxuICBleHRlbmQsXG4gIHRyaW0sXG4gIHN0cmlwQk9NLFxuICBpbmhlcml0cyxcbiAgdG9GbGF0T2JqZWN0LFxuICBraW5kT2YsXG4gIGtpbmRPZlRlc3QsXG4gIGVuZHNXaXRoLFxuICB0b0FycmF5LFxuICBmb3JFYWNoRW50cnksXG4gIG1hdGNoQWxsLFxuICBpc0hUTUxGb3JtLFxuICBoYXNPd25Qcm9wZXJ0eSxcbiAgaGFzT3duUHJvcDogaGFzT3duUHJvcGVydHksIC8vIGFuIGFsaWFzIHRvIGF2b2lkIEVTTGludCBuby1wcm90b3R5cGUtYnVpbHRpbnMgZGV0ZWN0aW9uXG4gIGhhc093bkluUHJvdG90eXBlQ2hhaW4sXG4gIGdldFNhZmVQcm9wLFxuICB0b1NhZmVGbGF0T2JqZWN0LFxuICByZWR1Y2VEZXNjcmlwdG9ycyxcbiAgZnJlZXplTWV0aG9kcyxcbiAgdG9PYmplY3RTZXQsXG4gIHRvQ2FtZWxDYXNlLFxuICBub29wLFxuICB0b0Zpbml0ZU51bWJlcixcbiAgZmluZEtleSxcbiAgZ2xvYmFsOiBfZ2xvYmFsLFxuICBpc0NvbnRleHREZWZpbmVkLFxuICBpc1NwZWNDb21wbGlhbnRGb3JtLFxuICB0b0pTT05PYmplY3QsXG4gIGlzQXN5bmNGbixcbiAgaXNUaGVuYWJsZSxcbiAgc2V0SW1tZWRpYXRlOiBfc2V0SW1tZWRpYXRlLFxuICBhc2FwLFxuICBpc0l0ZXJhYmxlLFxuICBpc1NhZmVJdGVyYWJsZSxcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbi8vIFJhd0F4aW9zSGVhZGVycyB3aG9zZSBkdXBsaWNhdGVzIGFyZSBpZ25vcmVkIGJ5IG5vZGVcbi8vIGMuZi4gaHR0cHM6Ly9ub2RlanMub3JnL2FwaS9odHRwLmh0bWwjaHR0cF9tZXNzYWdlX2hlYWRlcnNcbmNvbnN0IGlnbm9yZUR1cGxpY2F0ZU9mID0gdXRpbHMudG9PYmplY3RTZXQoW1xuICAnYWdlJyxcbiAgJ2F1dGhvcml6YXRpb24nLFxuICAnY29udGVudC1sZW5ndGgnLFxuICAnY29udGVudC10eXBlJyxcbiAgJ2V0YWcnLFxuICAnZXhwaXJlcycsXG4gICdmcm9tJyxcbiAgJ2hvc3QnLFxuICAnaWYtbW9kaWZpZWQtc2luY2UnLFxuICAnaWYtdW5tb2RpZmllZC1zaW5jZScsXG4gICdsYXN0LW1vZGlmaWVkJyxcbiAgJ2xvY2F0aW9uJyxcbiAgJ21heC1mb3J3YXJkcycsXG4gICdwcm94eS1hdXRob3JpemF0aW9uJyxcbiAgJ3JlZmVyZXInLFxuICAncmV0cnktYWZ0ZXInLFxuICAndXNlci1hZ2VudCcsXG5dKTtcblxuLyoqXG4gKiBQYXJzZSBoZWFkZXJzIGludG8gYW4gb2JqZWN0XG4gKlxuICogYGBgXG4gKiBEYXRlOiBXZWQsIDI3IEF1ZyAyMDE0IDA4OjU4OjQ5IEdNVFxuICogQ29udGVudC1UeXBlOiBhcHBsaWNhdGlvbi9qc29uXG4gKiBDb25uZWN0aW9uOiBrZWVwLWFsaXZlXG4gKiBUcmFuc2Zlci1FbmNvZGluZzogY2h1bmtlZFxuICogYGBgXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHJhd0hlYWRlcnMgSGVhZGVycyBuZWVkaW5nIHRvIGJlIHBhcnNlZFxuICpcbiAqIEByZXR1cm5zIHtPYmplY3R9IEhlYWRlcnMgcGFyc2VkIGludG8gYW4gb2JqZWN0XG4gKi9cbmV4cG9ydCBkZWZhdWx0IChyYXdIZWFkZXJzKSA9PiB7XG4gIC8vIEhlYWRlciBuYW1lcyBhcmUgZGF0YSwgaW5jbHVkaW5nIF9fcHJvdG9fXzsgYXZvaWQgaW5oZXJpdGVkIHNldHRlcnMuXG4gIGNvbnN0IHBhcnNlZCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGxldCBrZXk7XG4gIGxldCB2YWw7XG4gIGxldCBpO1xuXG4gIHJhd0hlYWRlcnMgJiZcbiAgICByYXdIZWFkZXJzLnNwbGl0KCdcXG4nKS5mb3JFYWNoKGZ1bmN0aW9uIHBhcnNlcihsaW5lKSB7XG4gICAgICBpID0gbGluZS5pbmRleE9mKCc6Jyk7XG4gICAgICBrZXkgPSBsaW5lLnN1YnN0cmluZygwLCBpKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgIHZhbCA9IGxpbmUuc3Vic3RyaW5nKGkgKyAxKS50cmltKCk7XG5cbiAgICAgIGNvbnN0IGhhc0tleSA9IHV0aWxzLmhhc093blByb3AocGFyc2VkLCBrZXkpO1xuXG4gICAgICBpZiAoIWtleSB8fCAoaGFzS2V5ICYmIHV0aWxzLmhhc093blByb3AoaWdub3JlRHVwbGljYXRlT2YsIGtleSkpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKGtleSA9PT0gJ3NldC1jb29raWUnKSB7XG4gICAgICAgIGlmIChoYXNLZXkpIHtcbiAgICAgICAgICBwYXJzZWRba2V5XS5wdXNoKHZhbCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcGFyc2VkW2tleV0gPSBbdmFsXTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGFyc2VkW2tleV0gPSBoYXNLZXkgPyBwYXJzZWRba2V5XSArICcsICcgKyB2YWwgOiB2YWw7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgcmV0dXJuIHBhcnNlZDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbmZ1bmN0aW9uIHRyaW1TUG9ySFRBQihzdHIpIHtcbiAgbGV0IHN0YXJ0ID0gMDtcbiAgbGV0IGVuZCA9IHN0ci5sZW5ndGg7XG5cbiAgd2hpbGUgKHN0YXJ0IDwgZW5kKSB7XG4gICAgY29uc3QgY29kZSA9IHN0ci5jaGFyQ29kZUF0KHN0YXJ0KTtcblxuICAgIGlmIChjb2RlICE9PSAweDA5ICYmIGNvZGUgIT09IDB4MjApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHN0YXJ0ICs9IDE7XG4gIH1cblxuICB3aGlsZSAoZW5kID4gc3RhcnQpIHtcbiAgICBjb25zdCBjb2RlID0gc3RyLmNoYXJDb2RlQXQoZW5kIC0gMSk7XG5cbiAgICBpZiAoY29kZSAhPT0gMHgwOSAmJiBjb2RlICE9PSAweDIwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICBlbmQgLT0gMTtcbiAgfVxuXG4gIHJldHVybiBzdGFydCA9PT0gMCAmJiBlbmQgPT09IHN0ci5sZW5ndGggPyBzdHIgOiBzdHIuc2xpY2Uoc3RhcnQsIGVuZCk7XG59XG5cbi8vIFRoZSBjb250cm9sLWNvZGUgcmFuZ2VzIGFyZSBpbnRlbnRpb25hbDogaGVhZGVyIHNhbml0aXphdGlvbiBzdHJpcHMgQzAvREVMIGJ5dGVzLlxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRyb2wtcmVnZXhcbmNvbnN0IElOVkFMSURfVU5JQ09ERV9IRUFERVJfVkFMVUVfQ0hBUlMgPSBuZXcgUmVnRXhwKCdbXFxcXHUwMDAwLVxcXFx1MDAwOFxcXFx1MDAwYS1cXFxcdTAwMWZcXFxcdTAwN2ZdKycsICdnJyk7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29udHJvbC1yZWdleFxuY29uc3QgSU5WQUxJRF9CWVRFX1NUUklOR19IRUFERVJfVkFMVUVfQ0hBUlMgPSBuZXcgUmVnRXhwKCdbXlxcXFx1MDAwOVxcXFx1MDAyMC1cXFxcdTAwN2VcXFxcdTAwODAtXFxcXHUwMGZmXSsnLCAnZycpO1xuXG5mdW5jdGlvbiBzYW5pdGl6ZVZhbHVlKHZhbHVlLCBpbnZhbGlkQ2hhcnMpIHtcbiAgaWYgKHV0aWxzLmlzQXJyYXkodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlLm1hcCgoaXRlbSkgPT4gc2FuaXRpemVWYWx1ZShpdGVtLCBpbnZhbGlkQ2hhcnMpKTtcbiAgfVxuXG4gIHJldHVybiB0cmltU1BvckhUQUIoU3RyaW5nKHZhbHVlKS5yZXBsYWNlKGludmFsaWRDaGFycywgJycpKTtcbn1cblxuZXhwb3J0IGNvbnN0IHNhbml0aXplSGVhZGVyVmFsdWUgPSAodmFsdWUpID0+XG4gIHNhbml0aXplVmFsdWUodmFsdWUsIElOVkFMSURfVU5JQ09ERV9IRUFERVJfVkFMVUVfQ0hBUlMpO1xuXG5leHBvcnQgY29uc3Qgc2FuaXRpemVCeXRlU3RyaW5nSGVhZGVyVmFsdWUgPSAodmFsdWUpID0+XG4gIHNhbml0aXplVmFsdWUodmFsdWUsIElOVkFMSURfQllURV9TVFJJTkdfSEVBREVSX1ZBTFVFX0NIQVJTKTtcblxuZXhwb3J0IGZ1bmN0aW9uIHRvQnl0ZVN0cmluZ0hlYWRlck9iamVjdChoZWFkZXJzKSB7XG4gIGNvbnN0IGJ5dGVTdHJpbmdIZWFkZXJzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICB1dGlscy5mb3JFYWNoKGhlYWRlcnMudG9KU09OKCksICh2YWx1ZSwgaGVhZGVyKSA9PiB7XG4gICAgYnl0ZVN0cmluZ0hlYWRlcnNbaGVhZGVyXSA9IHNhbml0aXplQnl0ZVN0cmluZ0hlYWRlclZhbHVlKHZhbHVlKTtcbiAgfSk7XG5cbiAgcmV0dXJuIGJ5dGVTdHJpbmdIZWFkZXJzO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IHBhcnNlSGVhZGVycyBmcm9tICcuLi9oZWxwZXJzL3BhcnNlSGVhZGVycy5qcyc7XG5pbXBvcnQgeyBzYW5pdGl6ZUhlYWRlclZhbHVlIH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgJGludGVybmFscyA9IFN5bWJvbCgnaW50ZXJuYWxzJyk7XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZUhlYWRlcihoZWFkZXIpIHtcbiAgcmV0dXJuIGhlYWRlciAmJiBTdHJpbmcoaGVhZGVyKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplVmFsdWUodmFsdWUpIHtcbiAgaWYgKHZhbHVlID09PSBmYWxzZSB8fCB2YWx1ZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgcmV0dXJuIHV0aWxzLmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKG5vcm1hbGl6ZVZhbHVlKSA6IHNhbml0aXplSGVhZGVyVmFsdWUoU3RyaW5nKHZhbHVlKSk7XG59XG5cbmZ1bmN0aW9uIHBhcnNlVG9rZW5zKHN0cikge1xuICBjb25zdCB0b2tlbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCB0b2tlbnNSRSA9IC8oW15cXHMsOz1dKylcXHMqKD86PVxccyooW14sO10rKSk/L2c7XG4gIGxldCBtYXRjaDtcblxuICB3aGlsZSAoKG1hdGNoID0gdG9rZW5zUkUuZXhlYyhzdHIpKSkge1xuICAgIHRva2Vuc1ttYXRjaFsxXV0gPSBtYXRjaFsyXTtcbiAgfVxuXG4gIHJldHVybiB0b2tlbnM7XG59XG5cbmNvbnN0IHBhcmFtZXRlck5hbWVSRSA9IC9eWyEjJCUmJyorXFwtLl5fYHx+MC05QS1aYS16XSskLztcblxuZnVuY3Rpb24gdHJpbU9XUyh2YWx1ZSkge1xuICBsZXQgc3RhcnQgPSAwO1xuICBsZXQgZW5kID0gdmFsdWUubGVuZ3RoO1xuXG4gIHdoaWxlIChzdGFydCA8IGVuZCkge1xuICAgIGNvbnN0IGNvZGUgPSB2YWx1ZS5jaGFyQ29kZUF0KHN0YXJ0KTtcblxuICAgIGlmIChjb2RlICE9PSAweDA5ICYmIGNvZGUgIT09IDB4MjApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHN0YXJ0ICs9IDE7XG4gIH1cblxuICB3aGlsZSAoZW5kID4gc3RhcnQpIHtcbiAgICBjb25zdCBjb2RlID0gdmFsdWUuY2hhckNvZGVBdChlbmQgLSAxKTtcblxuICAgIGlmIChjb2RlICE9PSAweDA5ICYmIGNvZGUgIT09IDB4MjApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGVuZCAtPSAxO1xuICB9XG5cbiAgcmV0dXJuIHN0YXJ0ID09PSAwICYmIGVuZCA9PT0gdmFsdWUubGVuZ3RoID8gdmFsdWUgOiB2YWx1ZS5zbGljZShzdGFydCwgZW5kKTtcbn1cblxuZnVuY3Rpb24gZGVjb2RlUXVvdGVkU3RyaW5nKHZhbHVlKSB7XG4gIGNvbnN0IGxhc3QgPSB2YWx1ZS5sZW5ndGggLSAxO1xuXG4gIGlmIChsYXN0IDwgMSB8fCB2YWx1ZS5jaGFyQ29kZUF0KDApICE9PSAweDIyIHx8IHZhbHVlLmNoYXJDb2RlQXQobGFzdCkgIT09IDB4MjIpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cblxuICBsZXQgZGVjb2RlZCA9ICcnO1xuXG4gIGZvciAobGV0IGkgPSAxOyBpIDwgbGFzdDsgaSsrKSB7XG4gICAgY29uc3QgY29kZSA9IHZhbHVlLmNoYXJDb2RlQXQoaSk7XG5cbiAgICBpZiAoY29kZSA9PT0gMHgyMikge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cblxuICAgIGlmIChjb2RlID09PSAweDVjKSB7XG4gICAgICBpICs9IDE7XG5cbiAgICAgIGlmIChpID49IGxhc3QpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIGRlY29kZWQgKz0gdmFsdWVbaV07XG4gIH1cblxuICByZXR1cm4gZGVjb2RlZDtcbn1cblxuZnVuY3Rpb24gcGFyc2VQYXJhbWV0ZXJzKHZhbHVlKSB7XG4gIGNvbnN0IHBhcmFtZXRlcnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzdHIgPSBTdHJpbmcodmFsdWUpO1xuICBsZXQgc3RhcnQgPSAwO1xuICBsZXQgcXVvdGVkID0gZmFsc2U7XG4gIGxldCBlc2NhcGVkID0gZmFsc2U7XG5cbiAgZnVuY3Rpb24gcGFyc2VQYXJhbWV0ZXIoZW5kKSB7XG4gICAgY29uc3QgcGFydCA9IHRyaW1PV1Moc3RyLnNsaWNlKHN0YXJ0LCBlbmQpKTtcbiAgICBjb25zdCBlcXVhbHMgPSBwYXJ0LmluZGV4T2YoJz0nKTtcblxuICAgIGlmIChlcXVhbHMgPCAxKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgbmFtZSA9IHRyaW1PV1MocGFydC5zbGljZSgwLCBlcXVhbHMpKTtcblxuICAgIGlmICghcGFyYW1ldGVyTmFtZVJFLnRlc3QobmFtZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBub3JtYWxpemVkTmFtZSA9IG5hbWUudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmIChcbiAgICAgIG5vcm1hbGl6ZWROYW1lID09PSAnX19wcm90b19fJyB8fFxuICAgICAgbm9ybWFsaXplZE5hbWUgPT09ICdjb25zdHJ1Y3RvcicgfHxcbiAgICAgIG5vcm1hbGl6ZWROYW1lID09PSAncHJvdG90eXBlJ1xuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHBhcmFtZXRlclZhbHVlID0gdHJpbU9XUyhwYXJ0LnNsaWNlKGVxdWFscyArIDEpKTtcbiAgICBwYXJhbWV0ZXJzW25vcm1hbGl6ZWROYW1lXSA9IGRlY29kZVF1b3RlZFN0cmluZyhwYXJhbWV0ZXJWYWx1ZSk7XG4gIH1cblxuICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNvZGUgPSBzdHIuY2hhckNvZGVBdChpKTtcblxuICAgIGlmIChxdW90ZWQpIHtcbiAgICAgIGlmIChlc2NhcGVkKSB7XG4gICAgICAgIGVzY2FwZWQgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSBpZiAoY29kZSA9PT0gMHg1Yykge1xuICAgICAgICBlc2NhcGVkID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSBpZiAoY29kZSA9PT0gMHgyMikge1xuICAgICAgICBxdW90ZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvZGUgPT09IDB4MjIpIHtcbiAgICAgIHF1b3RlZCA9IHRydWU7XG4gICAgfSBlbHNlIGlmIChjb2RlID09PSAweDJjIHx8IGNvZGUgPT09IDB4M2IpIHtcbiAgICAgIHBhcnNlUGFyYW1ldGVyKGkpO1xuICAgICAgc3RhcnQgPSBpICsgMTtcbiAgICB9XG4gIH1cblxuICBwYXJzZVBhcmFtZXRlcihzdHIubGVuZ3RoKTtcblxuICByZXR1cm4gcGFyYW1ldGVycztcbn1cblxuY29uc3QgaXNWYWxpZEhlYWRlck5hbWUgPSAoc3RyKSA9PiAvXlstX2EtekEtWjAtOV5gfH4sISMkJSYnKisuXSskLy50ZXN0KHN0ci50cmltKCkpO1xuXG4vLyBgX19wcm90b19fYCBpcyBhIHZhbGlkIGZpZWxkIG5hbWUsIGFuZCB0aGUgb25lIG5hbWUgdGhlIHVwcGVyY2FzZSBtYXBwaW5nIGF0XG4vLyB0aGUgYm90dG9tIG9mIHRoaXMgZmlsZSBjYW5ub3QgcmVhY2g6IGl0IGlzIGluaGVyaXRlZCBmcm9tIE9iamVjdC5wcm90b3R5cGVcbi8vIGluc3RlYWQgb2YgYmVpbmcgZGVjbGFyZWQgb24gQXhpb3NIZWFkZXJzLnByb3RvdHlwZSwgc28gYHNlbGYuX19wcm90b19fID0gdmBcbi8vIHJ1bnMgdGhlIGluaGVyaXRlZCBzZXR0ZXIuIFRoYXQgc2lsZW50bHkgZGlzY2FyZHMgdGhlIGhlYWRlciwgYW5kIGFuIGFycmF5XG4vLyB2YWx1ZSByZXBsYWNlcyB0aGUgaW5zdGFuY2UgcHJvdG90eXBlLCB0YWtpbmcgZXZlcnkgbWV0aG9kIHdpdGggaXQuXG4vLyBTdG9yZSBpdCB1bmRlciB0aGUgc2FtZSBraW5kIG9mIGNhc2UgdmFyaWFudCB0aGF0IG1hcHBpbmcgdXNlcyBmb3IgYHNldGAgYW5kXG4vLyBgY29uc3RydWN0b3JgLiBIZWFkZXIgbG9va3VwIGlzIGNhc2VsZXNzLCBzbyBpdCByZWFkcyBiYWNrIHVuZGVyIGVpdGhlclxuLy8gc3BlbGxpbmcsIGFuZCBubyBvd24gYF9fcHJvdG9fX2Agc2xvdCBpcyBldmVyIGNyZWF0ZWQgZm9yIGEgbGF0ZXJcbi8vIGBPYmplY3QuYXNzaWduYCB0byBjb3B5IG9udG8gYSBwbGFpbiBvYmplY3QgdGhyb3VnaCB0aGUgc2FtZSBzZXR0ZXIuXG5jb25zdCBQUk9UT19IRUFERVJfU0xPVCA9ICdfX1Byb3RvX18nO1xuXG5jb25zdCBoZWFkZXJTbG90ID0gKG5hbWUpID0+IChuYW1lID09PSAnX19wcm90b19fJyA/IFBST1RPX0hFQURFUl9TTE9UIDogbmFtZSk7XG5cbmZ1bmN0aW9uIG1hdGNoSGVhZGVyVmFsdWUoY29udGV4dCwgdmFsdWUsIGhlYWRlciwgZmlsdGVyLCBpc0hlYWRlck5hbWVGaWx0ZXIpIHtcbiAgaWYgKHV0aWxzLmlzRnVuY3Rpb24oZmlsdGVyKSkge1xuICAgIHJldHVybiBmaWx0ZXIuY2FsbChjb250ZXh0LCB2YWx1ZSwgaGVhZGVyKTtcbiAgfVxuXG4gIGlmIChpc0hlYWRlck5hbWVGaWx0ZXIpIHtcbiAgICB2YWx1ZSA9IGhlYWRlcjtcbiAgfVxuXG4gIGlmICghdXRpbHMuaXNTdHJpbmcodmFsdWUpKSByZXR1cm47XG5cbiAgaWYgKHV0aWxzLmlzU3RyaW5nKGZpbHRlcikpIHtcbiAgICByZXR1cm4gdmFsdWUuaW5kZXhPZihmaWx0ZXIpICE9PSAtMTtcbiAgfVxuXG4gIGlmICh1dGlscy5pc1JlZ0V4cChmaWx0ZXIpKSB7XG4gICAgcmV0dXJuIGZpbHRlci50ZXN0KHZhbHVlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBmb3JtYXRIZWFkZXIoaGVhZGVyKSB7XG4gIHJldHVybiBoZWFkZXJcbiAgICAudHJpbSgpXG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAucmVwbGFjZSgvKFthLXpcXGRdKShcXHcqKS9nLCAodywgY2hhciwgc3RyKSA9PiB7XG4gICAgICByZXR1cm4gY2hhci50b1VwcGVyQ2FzZSgpICsgc3RyO1xuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBidWlsZEFjY2Vzc29ycyhvYmosIGhlYWRlcikge1xuICBjb25zdCBhY2Nlc3Nvck5hbWUgPSB1dGlscy50b0NhbWVsQ2FzZSgnICcgKyBoZWFkZXIpO1xuXG4gIFsnZ2V0JywgJ3NldCcsICdoYXMnXS5mb3JFYWNoKChtZXRob2ROYW1lKSA9PiB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwgbWV0aG9kTmFtZSArIGFjY2Vzc29yTmFtZSwge1xuICAgICAgLy8gTnVsbC1wcm90byBkZXNjcmlwdG9yIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90IHR1cm5cbiAgICAgIC8vIHRoaXMgZGF0YSBkZXNjcmlwdG9yIGludG8gYW4gYWNjZXNzb3IgZGVzY3JpcHRvciBvbiB0aGUgd2F5IGluLlxuICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgdmFsdWU6IGZ1bmN0aW9uIChhcmcxLCBhcmcyLCBhcmczKSB7XG4gICAgICAgIHJldHVybiB0aGlzW21ldGhvZE5hbWVdLmNhbGwodGhpcywgaGVhZGVyLCBhcmcxLCBhcmcyLCBhcmczKTtcbiAgICAgIH0sXG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgfSk7XG4gIH0pO1xufVxuXG5jbGFzcyBBeGlvc0hlYWRlcnMge1xuICBjb25zdHJ1Y3RvcihoZWFkZXJzKSB7XG4gICAgaGVhZGVycyAmJiB0aGlzLnNldChoZWFkZXJzKTtcbiAgfVxuXG4gIHNldChoZWFkZXIsIHZhbHVlT3JSZXdyaXRlLCByZXdyaXRlKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBmdW5jdGlvbiBzZXRIZWFkZXIoX3ZhbHVlLCBfaGVhZGVyLCBfcmV3cml0ZSkge1xuICAgICAgY29uc3QgbEhlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihfaGVhZGVyKTtcblxuICAgICAgaWYgKCFsSGVhZGVyKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleShzZWxmLCBsSGVhZGVyKTtcblxuICAgICAgaWYgKFxuICAgICAgICAha2V5IHx8XG4gICAgICAgIHNlbGZba2V5XSA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAgIF9yZXdyaXRlID09PSB0cnVlIHx8XG4gICAgICAgIChfcmV3cml0ZSA9PT0gdW5kZWZpbmVkICYmIHNlbGZba2V5XSAhPT0gZmFsc2UpXG4gICAgICApIHtcbiAgICAgICAgc2VsZltoZWFkZXJTbG90KGtleSB8fCBfaGVhZGVyKV0gPSBub3JtYWxpemVWYWx1ZShfdmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHNldEhlYWRlcnMgPSAoaGVhZGVycywgX3Jld3JpdGUpID0+XG4gICAgICB1dGlscy5mb3JFYWNoKGhlYWRlcnMsIChfdmFsdWUsIF9oZWFkZXIpID0+IHNldEhlYWRlcihfdmFsdWUsIF9oZWFkZXIsIF9yZXdyaXRlKSk7XG5cbiAgICBpZiAodXRpbHMuaXNQbGFpbk9iamVjdChoZWFkZXIpIHx8IGhlYWRlciBpbnN0YW5jZW9mIHRoaXMuY29uc3RydWN0b3IpIHtcbiAgICAgIHNldEhlYWRlcnMoaGVhZGVyLCB2YWx1ZU9yUmV3cml0ZSk7XG4gICAgfSBlbHNlIGlmICh1dGlscy5pc1N0cmluZyhoZWFkZXIpICYmIChoZWFkZXIgPSBoZWFkZXIudHJpbSgpKSAmJiAhaXNWYWxpZEhlYWRlck5hbWUoaGVhZGVyKSkge1xuICAgICAgc2V0SGVhZGVycyhwYXJzZUhlYWRlcnMoaGVhZGVyKSwgdmFsdWVPclJld3JpdGUpO1xuICAgIH0gZWxzZSBpZiAodXRpbHMuaXNPYmplY3QoaGVhZGVyKSAmJiB1dGlscy5pc1NhZmVJdGVyYWJsZShoZWFkZXIpKSB7XG4gICAgICBsZXQgb2JqID0gT2JqZWN0LmNyZWF0ZShudWxsKSxcbiAgICAgICAgZGVzdCxcbiAgICAgICAga2V5O1xuICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBoZWFkZXIpIHtcbiAgICAgICAgaWYgKCF1dGlscy5pc0FycmF5KGVudHJ5KSkge1xuICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ09iamVjdCBpdGVyYXRvciBtdXN0IHJldHVybiBhIGtleS12YWx1ZSBwYWlyJyk7XG4gICAgICAgIH1cblxuICAgICAgICBrZXkgPSBlbnRyeVswXTtcblxuICAgICAgICBpZiAodXRpbHMuaGFzT3duUHJvcChvYmosIGtleSkpIHtcbiAgICAgICAgICBkZXN0ID0gb2JqW2tleV07XG4gICAgICAgICAgb2JqW2tleV0gPSB1dGlscy5pc0FycmF5KGRlc3QpID8gWy4uLmRlc3QsIGVudHJ5WzFdXSA6IFtkZXN0LCBlbnRyeVsxXV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb2JqW2tleV0gPSBlbnRyeVsxXTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBzZXRIZWFkZXJzKG9iaiwgdmFsdWVPclJld3JpdGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBoZWFkZXIgIT0gbnVsbCAmJiBzZXRIZWFkZXIodmFsdWVPclJld3JpdGUsIGhlYWRlciwgcmV3cml0ZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICBnZXQoaGVhZGVyLCBwYXJzZXIpIHtcbiAgICBoZWFkZXIgPSBub3JtYWxpemVIZWFkZXIoaGVhZGVyKTtcblxuICAgIGlmIChoZWFkZXIpIHtcbiAgICAgIGNvbnN0IGtleSA9IHV0aWxzLmZpbmRLZXkodGhpcywgaGVhZGVyKTtcblxuICAgICAgaWYgKGtleSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXNba2V5XTtcblxuICAgICAgICBpZiAoIXBhcnNlcikge1xuICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwYXJzZXIgPT09IHRydWUpIHtcbiAgICAgICAgICByZXR1cm4gcGFyc2VUb2tlbnModmFsdWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHV0aWxzLmlzRnVuY3Rpb24ocGFyc2VyKSkge1xuICAgICAgICAgIHJldHVybiBwYXJzZXIuY2FsbCh0aGlzLCB2YWx1ZSwga2V5KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh1dGlscy5pc1JlZ0V4cChwYXJzZXIpKSB7XG4gICAgICAgICAgcmV0dXJuIHBhcnNlci5leGVjKHZhbHVlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3BhcnNlciBtdXN0IGJlIGJvb2xlYW58cmVnZXhwfGZ1bmN0aW9uJyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaGFzKGhlYWRlciwgbWF0Y2hlcikge1xuICAgIGhlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihoZWFkZXIpO1xuXG4gICAgaWYgKGhlYWRlcikge1xuICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleSh0aGlzLCBoZWFkZXIpO1xuXG4gICAgICByZXR1cm4gISEoXG4gICAgICAgIGtleSAmJlxuICAgICAgICB0aGlzW2tleV0gIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAoIW1hdGNoZXIgfHwgbWF0Y2hIZWFkZXJWYWx1ZSh0aGlzLCB0aGlzW2tleV0sIGtleSwgbWF0Y2hlcikpXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGRlbGV0ZShoZWFkZXIsIG1hdGNoZXIpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBsZXQgZGVsZXRlZCA9IGZhbHNlO1xuXG4gICAgZnVuY3Rpb24gZGVsZXRlSGVhZGVyKF9oZWFkZXIpIHtcbiAgICAgIF9oZWFkZXIgPSBub3JtYWxpemVIZWFkZXIoX2hlYWRlcik7XG5cbiAgICAgIGlmIChfaGVhZGVyKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IHV0aWxzLmZpbmRLZXkoc2VsZiwgX2hlYWRlcik7XG5cbiAgICAgICAgaWYgKGtleSAmJiAoIW1hdGNoZXIgfHwgbWF0Y2hIZWFkZXJWYWx1ZShzZWxmLCBzZWxmW2tleV0sIGtleSwgbWF0Y2hlcikpKSB7XG4gICAgICAgICAgZGVsZXRlIHNlbGZba2V5XTtcblxuICAgICAgICAgIGRlbGV0ZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQXJyYXkoaGVhZGVyKSkge1xuICAgICAgaGVhZGVyLmZvckVhY2goZGVsZXRlSGVhZGVyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZGVsZXRlSGVhZGVyKGhlYWRlcik7XG4gICAgfVxuXG4gICAgcmV0dXJuIGRlbGV0ZWQ7XG4gIH1cblxuICBjbGVhcihtYXRjaGVyKSB7XG4gICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHRoaXMpO1xuICAgIGxldCBpID0ga2V5cy5sZW5ndGg7XG4gICAgbGV0IGRlbGV0ZWQgPSBmYWxzZTtcblxuICAgIHdoaWxlIChpLS0pIHtcbiAgICAgIGNvbnN0IGtleSA9IGtleXNbaV07XG4gICAgICBpZiAoIW1hdGNoZXIgfHwgbWF0Y2hIZWFkZXJWYWx1ZSh0aGlzLCB0aGlzW2tleV0sIGtleSwgbWF0Y2hlciwgdHJ1ZSkpIHtcbiAgICAgICAgZGVsZXRlIHRoaXNba2V5XTtcbiAgICAgICAgZGVsZXRlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGRlbGV0ZWQ7XG4gIH1cblxuICBub3JtYWxpemUoZm9ybWF0KSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3QgaGVhZGVycyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cbiAgICB1dGlscy5mb3JFYWNoKHRoaXMsICh2YWx1ZSwgaGVhZGVyKSA9PiB7XG4gICAgICBjb25zdCBrZXkgPSB1dGlscy5maW5kS2V5KGhlYWRlcnMsIGhlYWRlcik7XG5cbiAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgc2VsZltrZXldID0gbm9ybWFsaXplVmFsdWUodmFsdWUpO1xuICAgICAgICBkZWxldGUgc2VsZltoZWFkZXJdO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBoZWFkZXJTbG90KGZvcm1hdCA/IGZvcm1hdEhlYWRlcihoZWFkZXIpIDogU3RyaW5nKGhlYWRlcikudHJpbSgpKTtcblxuICAgICAgaWYgKG5vcm1hbGl6ZWQgIT09IGhlYWRlcikge1xuICAgICAgICBkZWxldGUgc2VsZltoZWFkZXJdO1xuICAgICAgfVxuXG4gICAgICBzZWxmW25vcm1hbGl6ZWRdID0gbm9ybWFsaXplVmFsdWUodmFsdWUpO1xuXG4gICAgICBoZWFkZXJzW25vcm1hbGl6ZWRdID0gdHJ1ZTtcbiAgICB9KTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgY29uY2F0KC4uLnRhcmdldHMpIHtcbiAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5jb25jYXQodGhpcywgLi4udGFyZ2V0cyk7XG4gIH1cblxuICB0b0pTT04oYXNTdHJpbmdzKSB7XG4gICAgY29uc3Qgb2JqID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICAgIHV0aWxzLmZvckVhY2godGhpcywgKHZhbHVlLCBoZWFkZXIpID0+IHtcbiAgICAgIHZhbHVlICE9IG51bGwgJiZcbiAgICAgICAgdmFsdWUgIT09IGZhbHNlICYmXG4gICAgICAgIChvYmpbaGVhZGVyXSA9IGFzU3RyaW5ncyAmJiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmpvaW4oJywgJykgOiB2YWx1ZSk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHRoaXMudG9KU09OKCkpW1N5bWJvbC5pdGVyYXRvcl0oKTtcbiAgfVxuXG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyh0aGlzLnRvSlNPTigpKVxuICAgICAgLm1hcCgoW2hlYWRlciwgdmFsdWVdKSA9PiBoZWFkZXIgKyAnOiAnICsgdmFsdWUpXG4gICAgICAuam9pbignXFxuJyk7XG4gIH1cblxuICBnZXRTZXRDb29raWUoKSB7XG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLmdldCgnc2V0LWNvb2tpZScpO1xuICAgIHJldHVybiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogdmFsdWUgPT0gbnVsbCB8fCB2YWx1ZSA9PT0gZmFsc2UgPyBbXSA6IFt2YWx1ZV07XG4gIH1cblxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuICdBeGlvc0hlYWRlcnMnO1xuICB9XG5cbiAgc3RhdGljIGZyb20odGhpbmcpIHtcbiAgICByZXR1cm4gdGhpbmcgaW5zdGFuY2VvZiB0aGlzID8gdGhpbmcgOiBuZXcgdGhpcyh0aGluZyk7XG4gIH1cblxuICBzdGF0aWMgcGFyc2VQYXJhbWV0ZXJzKHZhbHVlKSB7XG4gICAgcmV0dXJuIHBhcnNlUGFyYW1ldGVycyh2YWx1ZSk7XG4gIH1cblxuICBzdGF0aWMgY29uY2F0KGZpcnN0LCAuLi50YXJnZXRzKSB7XG4gICAgY29uc3QgY29tcHV0ZWQgPSBuZXcgdGhpcyhmaXJzdCk7XG5cbiAgICB0YXJnZXRzLmZvckVhY2goKHRhcmdldCkgPT4gY29tcHV0ZWQuc2V0KHRhcmdldCkpO1xuXG4gICAgcmV0dXJuIGNvbXB1dGVkO1xuICB9XG5cbiAgc3RhdGljIGFjY2Vzc29yKGhlYWRlcikge1xuICAgIGNvbnN0IGludGVybmFscyA9XG4gICAgICAodGhpc1skaW50ZXJuYWxzXSA9XG4gICAgICB0aGlzWyRpbnRlcm5hbHNdID1cbiAgICAgICAge1xuICAgICAgICAgIGFjY2Vzc29yczoge30sXG4gICAgICAgIH0pO1xuXG4gICAgY29uc3QgYWNjZXNzb3JzID0gaW50ZXJuYWxzLmFjY2Vzc29ycztcbiAgICBjb25zdCBwcm90b3R5cGUgPSB0aGlzLnByb3RvdHlwZTtcblxuICAgIGZ1bmN0aW9uIGRlZmluZUFjY2Vzc29yKF9oZWFkZXIpIHtcbiAgICAgIGNvbnN0IGxIZWFkZXIgPSBub3JtYWxpemVIZWFkZXIoX2hlYWRlcik7XG5cbiAgICAgIGlmICghYWNjZXNzb3JzW2xIZWFkZXJdKSB7XG4gICAgICAgIGJ1aWxkQWNjZXNzb3JzKHByb3RvdHlwZSwgX2hlYWRlcik7XG4gICAgICAgIGFjY2Vzc29yc1tsSGVhZGVyXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdXRpbHMuaXNBcnJheShoZWFkZXIpID8gaGVhZGVyLmZvckVhY2goZGVmaW5lQWNjZXNzb3IpIDogZGVmaW5lQWNjZXNzb3IoaGVhZGVyKTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9XG59XG5cbkF4aW9zSGVhZGVycy5hY2Nlc3NvcihbXG4gICdDb250ZW50LVR5cGUnLFxuICAnQ29udGVudC1MZW5ndGgnLFxuICAnQWNjZXB0JyxcbiAgJ0FjY2VwdC1FbmNvZGluZycsXG4gICdVc2VyLUFnZW50JyxcbiAgJ0F1dGhvcml6YXRpb24nLFxuXSk7XG5cbi8vIHJlc2VydmVkIG5hbWVzIGhvdGZpeFxudXRpbHMucmVkdWNlRGVzY3JpcHRvcnMoQXhpb3NIZWFkZXJzLnByb3RvdHlwZSwgKHsgdmFsdWUgfSwga2V5KSA9PiB7XG4gIGxldCBtYXBwZWQgPSBrZXlbMF0udG9VcHBlckNhc2UoKSArIGtleS5zbGljZSgxKTsgLy8gbWFwIGBzZXRgID0+IGBTZXRgXG4gIHJldHVybiB7XG4gICAgZ2V0OiAoKSA9PiB2YWx1ZSxcbiAgICBzZXQoaGVhZGVyVmFsdWUpIHtcbiAgICAgIHRoaXNbbWFwcGVkXSA9IGhlYWRlclZhbHVlO1xuICAgIH0sXG4gIH07XG59KTtcblxudXRpbHMuZnJlZXplTWV0aG9kcyhBeGlvc0hlYWRlcnMpO1xuXG5leHBvcnQgZGVmYXVsdCBBeGlvc0hlYWRlcnM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4vQXhpb3NIZWFkZXJzLmpzJztcblxuZXhwb3J0IGNvbnN0IFJFREFDVEVEID0gJ1tSRURBQ1RFRCAqKioqXSc7XG5cbmZ1bmN0aW9uIGhhc093bk9yUHJvdG90eXBlVG9KU09OKHNvdXJjZSkge1xuICBpZiAodXRpbHMuaGFzT3duUHJvcChzb3VyY2UsICd0b0pTT04nKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgbGV0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihzb3VyY2UpO1xuXG4gIHdoaWxlIChwcm90b3R5cGUgJiYgcHJvdG90eXBlICE9PSBPYmplY3QucHJvdG90eXBlKSB7XG4gICAgaWYgKHV0aWxzLmhhc093blByb3AocHJvdG90eXBlLCAndG9KU09OJykpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90b3R5cGUpO1xuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyBCdWlsZCBhIHBsYWluLW9iamVjdCBzbmFwc2hvdCBvZiBgY29uZmlnYCBhbmQgcmVwbGFjZSB0aGUgdmFsdWUgb2YgYW55IGtleVxuLy8gKGNhc2UtaW5zZW5zaXRpdmUpIGxpc3RlZCBpbiBgcmVkYWN0S2V5c2Agd2l0aCBSRURBQ1RFRC4gV2Fsa3MgdGhyb3VnaCBhcnJheXNcbi8vIGFuZCBBeGlvc0hlYWRlcnMsIGFuZCBzaG9ydC1jaXJjdWl0cyBvbiBjaXJjdWxhciByZWZlcmVuY2VzLlxuZnVuY3Rpb24gcmVkYWN0Q29uZmlnKGNvbmZpZywgcmVkYWN0S2V5cykge1xuICBjb25zdCBsb3dlcktleXMgPSBuZXcgU2V0KHJlZGFjdEtleXMubWFwKChrKSA9PiBTdHJpbmcoaykudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBzZWVuID0gW107XG5cbiAgY29uc3QgdmlzaXQgPSAoc291cmNlKSA9PiB7XG4gICAgaWYgKHNvdXJjZSA9PT0gbnVsbCB8fCB0eXBlb2Ygc291cmNlICE9PSAnb2JqZWN0JykgcmV0dXJuIHNvdXJjZTtcbiAgICBpZiAodXRpbHMuaXNCdWZmZXIoc291cmNlKSkgcmV0dXJuIHNvdXJjZTtcbiAgICBpZiAoc2Vlbi5pbmRleE9mKHNvdXJjZSkgIT09IC0xKSByZXR1cm4gdW5kZWZpbmVkO1xuXG4gICAgaWYgKHNvdXJjZSBpbnN0YW5jZW9mIEF4aW9zSGVhZGVycykge1xuICAgICAgc291cmNlID0gc291cmNlLnRvSlNPTigpO1xuICAgIH1cblxuICAgIHNlZW4ucHVzaChzb3VyY2UpO1xuXG4gICAgbGV0IHJlc3VsdDtcbiAgICBpZiAodXRpbHMuaXNBcnJheShzb3VyY2UpKSB7XG4gICAgICByZXN1bHQgPSBbXTtcbiAgICAgIHNvdXJjZS5mb3JFYWNoKCh2LCBpKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlZHVjZWRWYWx1ZSA9IHZpc2l0KHYpO1xuICAgICAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkpIHtcbiAgICAgICAgICByZXN1bHRbaV0gPSByZWR1Y2VkVmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoIXV0aWxzLmlzUGxhaW5PYmplY3Qoc291cmNlKSAmJiBoYXNPd25PclByb3RvdHlwZVRvSlNPTihzb3VyY2UpKSB7XG4gICAgICAgIHNlZW4ucG9wKCk7XG4gICAgICAgIHJldHVybiBzb3VyY2U7XG4gICAgICB9XG5cbiAgICAgIHJlc3VsdCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhzb3VyY2UpKSB7XG4gICAgICAgIGNvbnN0IHJlZHVjZWRWYWx1ZSA9IGxvd2VyS2V5cy5oYXMoa2V5LnRvTG93ZXJDYXNlKCkpID8gUkVEQUNURUQgOiB2aXNpdCh2YWx1ZSk7XG4gICAgICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQocmVkdWNlZFZhbHVlKSkge1xuICAgICAgICAgIHJlc3VsdFtrZXldID0gcmVkdWNlZFZhbHVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgc2Vlbi5wb3AoKTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9O1xuXG4gIHJldHVybiB2aXNpdChjb25maWcpO1xufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlTYWZlbHkodmFsdWUpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuICcnO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFnZ3JlZ2F0ZUVycm9yTWVzc2FnZShlcnJvcikge1xuICBjb25zdCBtZXNzYWdlID0gZXJyb3IuZXJyb3JzXG4gICAgLm1hcCgoZW50cnkpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBlbnRyeSAmJiBlbnRyeS5tZXNzYWdlID8gc3RyaW5naWZ5U2FmZWx5KGVudHJ5Lm1lc3NhZ2UpIDogc3RyaW5naWZ5U2FmZWx5KGVudHJ5KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgICB9XG4gICAgfSlcbiAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgLmpvaW4oJzsgJyk7XG5cbiAgcmV0dXJuIG1lc3NhZ2UgfHwgZXJyb3IubmFtZSB8fCAnQWdncmVnYXRlRXJyb3InO1xufVxuXG4vLyBTaGFyZWQgd2l0aCBgQXhpb3MucHJvdG90eXBlLnJlcXVlc3RgLCB3aGljaCBzcGxpY2VzIHRoZSByZWNvbnN0cnVjdGVkXG4vLyBjYWxsZXIgZnJhbWVzIGluIGFoZWFkIG9mIHRoaXMgbWFya2VyLlxuZXhwb3J0IGNvbnN0IENBVVNFRF9CWV9TRVBBUkFUT1IgPSAnXFxuQ2F1c2VkIGJ5OiAnO1xuY29uc3QgJGNhdXNlU3RhY2sgPSBTeW1ib2woJ2NhdXNlU3RhY2snKTtcblxuLy8gTWF0Y2ggdGhlIHNlY3Rpb24gd2UgYXBwZW5kZWQsIG5vdCBtYXJrZXItbGlrZSB0ZXh0IGluIGFuIGVycm9yIG1lc3NhZ2Ugb3Jcbi8vIGEgcmVwbGFjZW1lbnQgc3RhY2sgc3VwcGxpZWQgYnkgdGhlIGNhbGxlci4gRG8gbm90IHJlLXJlYWQgdGhlIGNhdXNlJ3Mgc3RhY2suXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2F1c2VTdGFja0luZGV4KGVycm9yLCBzdGFjaykge1xuICBjb25zdCBjYXVzZVN0YWNrID0gdXRpbHMuaGFzT3duUHJvcChlcnJvciwgJGNhdXNlU3RhY2spICYmIGVycm9yWyRjYXVzZVN0YWNrXTtcblxuICByZXR1cm4gY2F1c2VTdGFjayAmJiBzdGFjay5lbmRzV2l0aChjYXVzZVN0YWNrKSA/IHN0YWNrLmxlbmd0aCAtIGNhdXNlU3RhY2subGVuZ3RoIDogLTE7XG59XG5cbi8qKlxuICogQXBwZW5kIHRoZSBzdGFjayBvZiBhIHdyYXBwZWQgZXJyb3IgdG8gYHRhcmdldC5zdGFja2AuXG4gKlxuICogYGNhdXNlYCBhbHJlYWR5IGV4cG9zZXMgdGhlIG9yaWdpbmFsIGVycm9yIGZvciB0b29saW5nIHRoYXQgd2Fsa3MgdGhlIHN0YW5kYXJkXG4gKiBjYXVzZSBjaGFpbiwgYnV0IG1hbnkgZXJyb3IgcmVwb3J0ZXJzIHJlYWQgYHN0YWNrYCBhbmQgbm90aGluZyBlbHNlLiBJbmxpbmluZ1xuICogdGhlIHdyYXBwZWQgc3RhY2sgdGhlcmUgbWVhbnMgdGhvc2UgcmVwb3J0ZXJzIHN1cmZhY2UgdGhlIHVuZGVybHlpbmcgZmFpbHVyZVxuICogaW5zdGVhZCBvZiB0aGUgYXhpb3MgZnJhbWVzIHRoYXQgbm9ybWFsaXplZCBpdCAoc2VlICM2NjcwKS5cbiAqXG4gKiBFdmVyeSByZWFkIGlzIGRlZmVuc2l2ZTogYSBjdXN0b20gYEVycm9yLnByZXBhcmVTdGFja1RyYWNlYCBob29rLCBhIHJ1bnRpbWVcbiAqIHdpdGhvdXQgc3RhY2sgc3VwcG9ydCwgb3IgYSByZXBsYWNlZCBgc3RhY2tgIHByb3BlcnR5IGNhbiBsZWF2ZSB0aGUgdmFsdWVcbiAqIG1pc3NpbmcsIG5vbi1zdHJpbmcsIG9yIHJlYWQtb25seSwgYW5kIG5vcm1hbGl6aW5nIGFuIGVycm9yIG11c3Qgbm90IHRocm93XG4gKiBiZWNhdXNlIG9mIHRoYXQuXG4gKlxuICogQHBhcmFtIHtFcnJvcn0gdGFyZ2V0IFRoZSBBeGlvc0Vycm9yIGJlaW5nIGJ1aWx0LlxuICogQHBhcmFtIHtFcnJvcn0gc291cmNlIFRoZSBlcnJvciBiZWluZyB3cmFwcGVkLlxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5mdW5jdGlvbiBhcHBlbmRDYXVzZVN0YWNrKHRhcmdldCwgc291cmNlKSB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc291cmNlU3RhY2sgPSBzb3VyY2UgJiYgc291cmNlLnN0YWNrO1xuXG4gICAgaWYgKHR5cGVvZiBzb3VyY2VTdGFjayAhPT0gJ3N0cmluZycgfHwgIXNvdXJjZVN0YWNrKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdGFyZ2V0U3RhY2sgPSB0YXJnZXQuc3RhY2s7XG5cbiAgICBpZiAodHlwZW9mIHRhcmdldFN0YWNrICE9PSAnc3RyaW5nJyB8fCAhdGFyZ2V0U3RhY2spIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBFYWNoIGNhbGwgdG8gYGZyb20oKWAgY3JlYXRlcyBhIGZyZXNoIHRhcmdldC4gUmUtd3JhcHBpbmcgaW5jbHVkZXMgdGhlXG4gICAgLy8gcHJldmlvdXMgc3RhY2sgdmVyYmF0aW0sIGFkZGluZyBvbmUgY2F1c2Ugc2VjdGlvbiBwZXIgd3JhcC5cbiAgICBjb25zdCBjYXVzZVN0YWNrID0gQ0FVU0VEX0JZX1NFUEFSQVRPUiArIHNvdXJjZVN0YWNrO1xuICAgIHRhcmdldC5zdGFjayA9IHRhcmdldFN0YWNrICsgY2F1c2VTdGFjaztcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCAkY2F1c2VTdGFjaywgeyBfX3Byb3RvX186IG51bGwsIHZhbHVlOiBjYXVzZVN0YWNrIH0pO1xuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gSWdub3JlIGZhaWx1cmVzIGZyb20gY3VzdG9tIHN0YWNrIGhvb2tzIG9yIHVuLXdyaXRhYmxlIHN0YWNrIHByb3BlcnRpZXMuXG4gIH1cbn1cblxuY2xhc3MgQXhpb3NFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgc3RhdGljIGZyb20oZXJyb3IsIGNvZGUsIGNvbmZpZywgcmVxdWVzdCwgcmVzcG9uc2UsIGN1c3RvbVByb3BzKSB7XG4gICAgLy8gYEFnZ3JlZ2F0ZUVycm9yYCAodGhyb3duIGJ5IE5vZGUgb24gZHVhbC1zdGFjay9IYXBweS1FeWViYWxscyBjb25uZWN0aW9uXG4gICAgLy8gZmFpbHVyZXMpIGhhcyBhbiBlbXB0eSBgbWVzc2FnZWA7IGl0cyBkZXRhaWwgbGl2ZXMgaW4gYGVycm9yc1tdYC4gV2l0aG91dFxuICAgIC8vIHRoaXMsIHRoZSB3cmFwcGVkIGVycm9yIHN1cmZhY2VzIHdpdGggYSBibGFuayBtZXNzYWdlIChzZWUgIzY3MjEpLlxuICAgIGxldCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZTtcbiAgICBpZiAoIW1lc3NhZ2UgJiYgdXRpbHMuaXNBcnJheShlcnJvci5lcnJvcnMpICYmIGVycm9yLmVycm9ycy5sZW5ndGgpIHtcbiAgICAgIG1lc3NhZ2UgPSBhZ2dyZWdhdGVFcnJvck1lc3NhZ2UoZXJyb3IpO1xuICAgIH1cblxuICAgIGNvbnN0IGF4aW9zRXJyb3IgPSBuZXcgQXhpb3NFcnJvcihtZXNzYWdlLCBjb2RlIHx8IGVycm9yLmNvZGUsIGNvbmZpZywgcmVxdWVzdCwgcmVzcG9uc2UpO1xuICAgIC8vIE1hdGNoIG5hdGl2ZSBgRXJyb3JgIGBjYXVzZWAgc2VtYW50aWNzOiBub24tZW51bWVyYWJsZS4gVGhlIHdyYXBwZWRcbiAgICAvLyBlcnJvciBvZnRlbiBjYXJyaWVzIGNpcmN1bGFyIGludGVybmFscyAoc29ja2V0cywgcmVxdWVzdHMsIGFnZW50cyksIHNvXG4gICAgLy8gYW4gZW51bWVyYWJsZSBgY2F1c2VgIG1ha2VzIHN0cnVjdHVyZWQgbG9nZ2VycyAocGluby93aW5zdG9uKSBhbmQgYW55XG4gICAgLy8gb3duLXByb3BlcnR5IHdhbGsgdGhyb3cgXCJDb252ZXJ0aW5nIGNpcmN1bGFyIHN0cnVjdHVyZSB0byBKU09OXCIuXG4gICAgLy8gUmVncmVzc2lvbiBmcm9tICM2OTgyOyBzZWUgIzcyMDUuIGBfX3Byb3RvX186IG51bGxgIG1pcnJvcnMgdGhlXG4gICAgLy8gYG1lc3NhZ2VgIGRlc2NyaXB0b3IgYmVsb3cgKHByb3RvdHlwZS1wb2xsdXRpb24tc2FmZSBkZXNjcmlwdG9yKS5cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYXhpb3NFcnJvciwgJ2NhdXNlJywge1xuICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgdmFsdWU6IGVycm9yLFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICB9KTtcbiAgICBheGlvc0Vycm9yLm5hbWUgPSBlcnJvci5uYW1lO1xuXG4gICAgLy8gSW5saW5lIHRoZSB3cmFwcGVkIHN0YWNrIGZvciByZXBvcnRlcnMgdGhhdCByZWFkIG9ubHkgYHN0YWNrYDsgdGhlIGBjYXVzZWBcbiAgICAvLyBwcm9wZXJ0eSBhYm92ZSBhbHJlYWR5IGNvdmVycyBjYXVzZS1hd2FyZSB0b29saW5nLlxuICAgIGFwcGVuZENhdXNlU3RhY2soYXhpb3NFcnJvciwgZXJyb3IpO1xuXG4gICAgLy8gUHJlc2VydmUgc3RhdHVzIGZyb20gdGhlIG9yaWdpbmFsIGVycm9yIGlmIG5vdCBhbHJlYWR5IHNldCBmcm9tIHJlc3BvbnNlXG4gICAgaWYgKGVycm9yLnN0YXR1cyAhPSBudWxsICYmIGF4aW9zRXJyb3Iuc3RhdHVzID09IG51bGwpIHtcbiAgICAgIGF4aW9zRXJyb3Iuc3RhdHVzID0gZXJyb3Iuc3RhdHVzO1xuICAgIH1cblxuICAgIGN1c3RvbVByb3BzICYmIE9iamVjdC5hc3NpZ24oYXhpb3NFcnJvciwgY3VzdG9tUHJvcHMpO1xuICAgIHJldHVybiBheGlvc0Vycm9yO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhbiBFcnJvciB3aXRoIHRoZSBzcGVjaWZpZWQgbWVzc2FnZSwgY29uZmlnLCBlcnJvciBjb2RlLCByZXF1ZXN0IGFuZCByZXNwb25zZS5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmd9IG1lc3NhZ2UgVGhlIGVycm9yIG1lc3NhZ2UuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbY29kZV0gVGhlIGVycm9yIGNvZGUgKGZvciBleGFtcGxlLCAnRUNPTk5BQk9SVEVEJykuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbY29uZmlnXSBUaGUgY29uZmlnLlxuICAgKiBAcGFyYW0ge09iamVjdH0gW3JlcXVlc3RdIFRoZSByZXF1ZXN0LlxuICAgKiBAcGFyYW0ge09iamVjdH0gW3Jlc3BvbnNlXSBUaGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIEByZXR1cm5zIHtFcnJvcn0gVGhlIGNyZWF0ZWQgZXJyb3IuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBjb2RlLCBjb25maWcsIHJlcXVlc3QsIHJlc3BvbnNlKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG5cbiAgICAvLyBNYWtlIG1lc3NhZ2UgZW51bWVyYWJsZSB0byBtYWludGFpbiBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG4gICAgLy8gVGhlIG5hdGl2ZSBFcnJvciBjb25zdHJ1Y3RvciBzZXRzIG1lc3NhZ2UgYXMgbm9uLWVudW1lcmFibGUsXG4gICAgLy8gYnV0IGF4aW9zIDwgdjEuMTMuMyBoYWQgaXQgYXMgZW51bWVyYWJsZVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnbWVzc2FnZScsIHtcbiAgICAgIC8vIE51bGwtcHJvdG8gZGVzY3JpcHRvciBzbyBhIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUuZ2V0IGNhbm5vdCB0dXJuXG4gICAgICAvLyB0aGlzIGRhdGEgZGVzY3JpcHRvciBpbnRvIGFuIGFjY2Vzc29yIGRlc2NyaXB0b3Igb24gdGhlIHdheSBpbi5cbiAgICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICAgIHZhbHVlOiBtZXNzYWdlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIH0pO1xuXG4gICAgdGhpcy5uYW1lID0gJ0F4aW9zRXJyb3InO1xuICAgIHRoaXMuaXNBeGlvc0Vycm9yID0gdHJ1ZTtcbiAgICBjb2RlICYmICh0aGlzLmNvZGUgPSBjb2RlKTtcbiAgICBjb25maWcgJiYgKHRoaXMuY29uZmlnID0gY29uZmlnKTtcbiAgICByZXF1ZXN0ICYmICh0aGlzLnJlcXVlc3QgPSByZXF1ZXN0KTtcbiAgICBpZiAocmVzcG9uc2UpIHtcbiAgICAgIHRoaXMucmVzcG9uc2UgPSByZXNwb25zZTtcbiAgICAgIHRoaXMuc3RhdHVzID0gcmVzcG9uc2Uuc3RhdHVzO1xuICAgIH1cbiAgfVxuXG4gIHRvSlNPTigpIHtcbiAgICAvLyBPcHQtaW4gcmVkYWN0aW9uOiB3aGVuIHRoZSByZXF1ZXN0IGNvbmZpZyBjYXJyaWVzIGEgYHJlZGFjdGAgYXJyYXksIHRoZVxuICAgIC8vIHZhbHVlIG9mIGFueSBtYXRjaGluZyBrZXkgKGNhc2UtaW5zZW5zaXRpdmUsIGF0IGFueSBkZXB0aCkgaXMgcmVwbGFjZWRcbiAgICAvLyB3aXRoIFJFREFDVEVEIGluIHRoZSBzZXJpYWxpemVkIHNuYXBzaG90LiBVbmRlZmluZWQgb3IgZW1wdHkgbGVhdmVzIHRoZVxuICAgIC8vIGV4aXN0aW5nIHNlcmlhbGl6YXRpb24gYmVoYXZpb3IgdW5jaGFuZ2VkLlxuICAgIGNvbnN0IGNvbmZpZyA9IHRoaXMuY29uZmlnO1xuICAgIGNvbnN0IHJlZGFjdEtleXMgPSBjb25maWcgJiYgdXRpbHMuaGFzT3duUHJvcChjb25maWcsICdyZWRhY3QnKSA/IGNvbmZpZy5yZWRhY3QgOiB1bmRlZmluZWQ7XG4gICAgY29uc3Qgc2VyaWFsaXplZENvbmZpZyA9XG4gICAgICB1dGlscy5pc0FycmF5KHJlZGFjdEtleXMpICYmIHJlZGFjdEtleXMubGVuZ3RoID4gMFxuICAgICAgICA/IHJlZGFjdENvbmZpZyhjb25maWcsIHJlZGFjdEtleXMpXG4gICAgICAgIDogdXRpbHMudG9KU09OT2JqZWN0KGNvbmZpZyk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLy8gU3RhbmRhcmRcbiAgICAgIG1lc3NhZ2U6IHRoaXMubWVzc2FnZSxcbiAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgIC8vIE1pY3Jvc29mdFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICBudW1iZXI6IHRoaXMubnVtYmVyLFxuICAgICAgLy8gTW96aWxsYVxuICAgICAgZmlsZU5hbWU6IHRoaXMuZmlsZU5hbWUsXG4gICAgICBsaW5lTnVtYmVyOiB0aGlzLmxpbmVOdW1iZXIsXG4gICAgICBjb2x1bW5OdW1iZXI6IHRoaXMuY29sdW1uTnVtYmVyLFxuICAgICAgc3RhY2s6IHRoaXMuc3RhY2ssXG4gICAgICAvLyBBeGlvc1xuICAgICAgY29uZmlnOiBzZXJpYWxpemVkQ29uZmlnLFxuICAgICAgY29kZTogdGhpcy5jb2RlLFxuICAgICAgc3RhdHVzOiB0aGlzLnN0YXR1cyxcbiAgICB9O1xuICB9XG59XG5cbi8vIFRoaXMgY2FuIGJlIGNoYW5nZWQgdG8gc3RhdGljIHByb3BlcnRpZXMgYXMgc29vbiBhcyB0aGUgcGFyc2VyIG9wdGlvbnMgaW4gLmVzbGludC5janMgYXJlIHVwZGF0ZWQuXG5BeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OX1ZBTFVFID0gJ0VSUl9CQURfT1BUSU9OX1ZBTFVFJztcbkF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT04gPSAnRVJSX0JBRF9PUFRJT04nO1xuQXhpb3NFcnJvci5FQ09OTkFCT1JURUQgPSAnRUNPTk5BQk9SVEVEJztcbkF4aW9zRXJyb3IuRVRJTUVET1VUID0gJ0VUSU1FRE9VVCc7XG5BeGlvc0Vycm9yLkVDT05OUkVGVVNFRCA9ICdFQ09OTlJFRlVTRUQnO1xuQXhpb3NFcnJvci5FUlJfTkVUV09SSyA9ICdFUlJfTkVUV09SSyc7XG5BeGlvc0Vycm9yLkVSUl9GUl9UT09fTUFOWV9SRURJUkVDVFMgPSAnRVJSX0ZSX1RPT19NQU5ZX1JFRElSRUNUUyc7XG5BeGlvc0Vycm9yLkVSUl9ERVBSRUNBVEVEID0gJ0VSUl9ERVBSRUNBVEVEJztcbkF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSA9ICdFUlJfQkFEX1JFU1BPTlNFJztcbkF4aW9zRXJyb3IuRVJSX0JBRF9SRVFVRVNUID0gJ0VSUl9CQURfUkVRVUVTVCc7XG5BeGlvc0Vycm9yLkVSUl9DQU5DRUxFRCA9ICdFUlJfQ0FOQ0VMRUQnO1xuQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlQgPSAnRVJSX05PVF9TVVBQT1JUJztcbkF4aW9zRXJyb3IuRVJSX0lOVkFMSURfVVJMID0gJ0VSUl9JTlZBTElEX1VSTCc7XG5BeGlvc0Vycm9yLkVSUl9GT1JNX0RBVEFfREVQVEhfRVhDRUVERUQgPSAnRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRCc7XG5cbmV4cG9ydCBkZWZhdWx0IEF4aW9zRXJyb3I7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuLi9jb3JlL0F4aW9zRXJyb3IuanMnO1xuLy8gdGVtcG9yYXJ5IGhvdGZpeCB0byBhdm9pZCBjaXJjdWxhciByZWZlcmVuY2VzIHVudGlsIEF4aW9zVVJMU2VhcmNoUGFyYW1zIGlzIHJlZmFjdG9yZWRcbmltcG9ydCBQbGF0Zm9ybUZvcm1EYXRhIGZyb20gJy4uL3BsYXRmb3JtL25vZGUvY2xhc3Nlcy9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgUGxhdGZvcm1CdWZmZXIgZnJvbSAnLi4vcGxhdGZvcm0vbm9kZS9jbGFzc2VzL0J1ZmZlci5qcyc7XG5cbi8vIERlZmF1bHQgbmVzdGluZyBsaW1pdCBzaGFyZWQgd2l0aCB0aGUgaW52ZXJzZSB0cmFuc2Zvcm0gKGZvcm1EYXRhVG9KU09OKSBzb1xuLy8gdGhlIEZvcm1EYXRhIDwtPiBKU09OIHJvdW5kLXRyaXAgc3RheXMgc3ltbWV0cmljLlxuZXhwb3J0IGNvbnN0IERFRkFVTFRfRk9STV9EQVRBX01BWF9ERVBUSCA9IDEwMDtcblxuLyoqXG4gKiBEZXRlcm1pbmVzIGlmIHRoZSBnaXZlbiB0aGluZyBpcyBhIGFycmF5IG9yIGpzIG9iamVjdC5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdGhpbmcgLSBUaGUgb2JqZWN0IG9yIGFycmF5IHRvIGJlIHZpc2l0ZWQuXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIGlzVmlzaXRhYmxlKHRoaW5nKSB7XG4gIHJldHVybiB1dGlscy5pc1BsYWluT2JqZWN0KHRoaW5nKSB8fCB1dGlscy5pc0FycmF5KHRoaW5nKTtcbn1cblxuLyoqXG4gKiBJdCByZW1vdmVzIHRoZSBicmFja2V0cyBmcm9tIHRoZSBlbmQgb2YgYSBzdHJpbmdcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IC0gVGhlIGtleSBvZiB0aGUgcGFyYW1ldGVyLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IHRoZSBrZXkgd2l0aG91dCB0aGUgYnJhY2tldHMuXG4gKi9cbmZ1bmN0aW9uIHJlbW92ZUJyYWNrZXRzKGtleSkge1xuICByZXR1cm4gdXRpbHMuZW5kc1dpdGgoa2V5LCAnW10nKSA/IGtleS5zbGljZSgwLCAtMikgOiBrZXk7XG59XG5cbi8qKlxuICogSXQgdGFrZXMgYSBwYXRoLCBhIGtleSwgYW5kIGEgYm9vbGVhbiwgYW5kIHJldHVybnMgYSBzdHJpbmdcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gcGF0aCAtIFRoZSBwYXRoIHRvIHRoZSBjdXJyZW50IGtleS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkgLSBUaGUga2V5IG9mIHRoZSBjdXJyZW50IG9iamVjdCBiZWluZyBpdGVyYXRlZCBvdmVyLlxuICogQHBhcmFtIHtzdHJpbmd9IGRvdHMgLSBJZiB0cnVlLCB0aGUga2V5IHdpbGwgYmUgcmVuZGVyZWQgd2l0aCBkb3RzIGluc3RlYWQgb2YgYnJhY2tldHMuXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIHBhdGggdG8gdGhlIGN1cnJlbnQga2V5LlxuICovXG5mdW5jdGlvbiByZW5kZXJLZXkocGF0aCwga2V5LCBkb3RzKSB7XG4gIGlmICghcGF0aCkgcmV0dXJuIGtleTtcbiAgcmV0dXJuIHBhdGhcbiAgICAuY29uY2F0KGtleSlcbiAgICAubWFwKGZ1bmN0aW9uIGVhY2godG9rZW4sIGkpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgdG9rZW4gPSByZW1vdmVCcmFja2V0cyh0b2tlbik7XG4gICAgICByZXR1cm4gIWRvdHMgJiYgaSA/ICdbJyArIHRva2VuICsgJ10nIDogdG9rZW47XG4gICAgfSlcbiAgICAuam9pbihkb3RzID8gJy4nIDogJycpO1xufVxuXG4vKipcbiAqIElmIHRoZSBhcnJheSBpcyBhbiBhcnJheSBhbmQgbm9uZSBvZiBpdHMgZWxlbWVudHMgYXJlIHZpc2l0YWJsZSwgdGhlbiBpdCdzIGEgZmxhdCBhcnJheS5cbiAqXG4gKiBAcGFyYW0ge0FycmF5PGFueT59IGFyciAtIFRoZSBhcnJheSB0byBjaGVja1xuICpcbiAqIEByZXR1cm5zIHtib29sZWFufVxuICovXG5mdW5jdGlvbiBpc0ZsYXRBcnJheShhcnIpIHtcbiAgcmV0dXJuIHV0aWxzLmlzQXJyYXkoYXJyKSAmJiAhYXJyLnNvbWUoaXNWaXNpdGFibGUpO1xufVxuXG5jb25zdCBwcmVkaWNhdGVzID0gdXRpbHMudG9GbGF0T2JqZWN0KHV0aWxzLCB7fSwgbnVsbCwgZnVuY3Rpb24gZmlsdGVyKHByb3ApIHtcbiAgcmV0dXJuIC9eaXNbQS1aXS8udGVzdChwcm9wKTtcbn0pO1xuXG4vKipcbiAqIENvbnZlcnQgYSBkYXRhIG9iamVjdCB0byBGb3JtRGF0YVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmpcbiAqIEBwYXJhbSB7P09iamVjdH0gW2Zvcm1EYXRhXVxuICogQHBhcmFtIHs/T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7RnVuY3Rpb259IFtvcHRpb25zLnZpc2l0b3JdXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvcHRpb25zLm1ldGFUb2tlbnMgPSB0cnVlXVxuICogQHBhcmFtIHtCb29sZWFufSBbb3B0aW9ucy5kb3RzID0gZmFsc2VdXG4gKiBAcGFyYW0gez9Cb29sZWFufSBbb3B0aW9ucy5pbmRleGVzID0gZmFsc2VdXG4gKlxuICogQHJldHVybnMge09iamVjdH1cbiAqKi9cblxuLyoqXG4gKiBJdCBjb252ZXJ0cyBhbiBvYmplY3QgaW50byBhIEZvcm1EYXRhIG9iamVjdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PGFueSwgYW55Pn0gb2JqIC0gVGhlIG9iamVjdCB0byBjb252ZXJ0IHRvIGZvcm0gZGF0YS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBmb3JtRGF0YSAtIFRoZSBGb3JtRGF0YSBvYmplY3QgdG8gYXBwZW5kIHRvLlxuICogQHBhcmFtIHtPYmplY3Q8c3RyaW5nLCBhbnk+fSBvcHRpb25zXG4gKlxuICogQHJldHVybnNcbiAqL1xuZnVuY3Rpb24gdG9Gb3JtRGF0YShvYmosIGZvcm1EYXRhLCBvcHRpb25zKSB7XG4gIGlmICghdXRpbHMuaXNPYmplY3Qob2JqKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3RhcmdldCBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gIGZvcm1EYXRhID0gZm9ybURhdGEgfHwgbmV3IChQbGF0Zm9ybUZvcm1EYXRhIHx8IEZvcm1EYXRhKSgpO1xuXG4gIGNvbnN0IG9wdGlvbiA9IChuYW1lLCBmYWxsYmFjaykgPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gdXRpbHMuZ2V0U2FmZVByb3Aob3B0aW9ucywgbmFtZSk7XG4gICAgcmV0dXJuIHV0aWxzLmlzVW5kZWZpbmVkKHZhbHVlKSA/IGZhbGxiYWNrIDogdmFsdWU7XG4gIH07XG5cbiAgY29uc3QgbWV0YVRva2VucyA9IG9wdGlvbignbWV0YVRva2VucycsIHRydWUpO1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdXNlLWJlZm9yZS1kZWZpbmVcbiAgY29uc3QgdmlzaXRvciA9IG9wdGlvbigndmlzaXRvcicpIHx8IGRlZmF1bHRWaXNpdG9yO1xuICBjb25zdCBkb3RzID0gb3B0aW9uKCdkb3RzJywgZmFsc2UpO1xuICBjb25zdCBpbmRleGVzID0gb3B0aW9uKCdpbmRleGVzJywgZmFsc2UpO1xuICBjb25zdCBfQmxvYiA9IG9wdGlvbignQmxvYicpIHx8ICh0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgQmxvYik7XG4gIGNvbnN0IG1heERlcHRoID0gb3B0aW9uKCdtYXhEZXB0aCcsIERFRkFVTFRfRk9STV9EQVRBX01BWF9ERVBUSCk7XG4gIGNvbnN0IHVzZUJsb2IgPSBfQmxvYiAmJiB1dGlscy5pc1NwZWNDb21wbGlhbnRGb3JtKGZvcm1EYXRhKTtcbiAgY29uc3Qgc3RhY2sgPSBbXTtcblxuICBpZiAoIXV0aWxzLmlzRnVuY3Rpb24odmlzaXRvcikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd2aXNpdG9yIG11c3QgYmUgYSBmdW5jdGlvbicpO1xuICB9XG5cbiAgZnVuY3Rpb24gY29udmVydFZhbHVlKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gJyc7XG5cbiAgICBpZiAodXRpbHMuaXNEYXRlKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHZhbHVlLnRvSVNPU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQm9vbGVhbih2YWx1ZSkpIHtcbiAgICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICAgIH1cblxuICAgIGlmICghdXNlQmxvYiAmJiB1dGlscy5pc0Jsb2IodmFsdWUpKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcignQmxvYiBpcyBub3Qgc3VwcG9ydGVkLiBVc2UgYSBCdWZmZXIgaW5zdGVhZC4nKTtcbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNBcnJheUJ1ZmZlcih2YWx1ZSkgfHwgdXRpbHMuaXNUeXBlZEFycmF5KHZhbHVlKSkge1xuICAgICAgaWYgKHVzZUJsb2IgJiYgdHlwZW9mIF9CbG9iID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHJldHVybiBuZXcgX0Jsb2IoW3ZhbHVlXSk7XG4gICAgICB9XG4gICAgICBpZiAoUGxhdGZvcm1CdWZmZXIgJiYgUGxhdGZvcm1CdWZmZXIuaXNCdWZmZXJBdmFpbGFibGUoKSkge1xuICAgICAgICByZXR1cm4gUGxhdGZvcm1CdWZmZXIuZnJvbSh2YWx1ZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgJ0Jsb2IgaXMgbm90IHN1cHBvcnRlZC4gVXNlIGEgQnVmZmVyIGluc3RlYWQuJyxcbiAgICAgICAgQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlRcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgZnVuY3Rpb24gdGhyb3dJZk1heERlcHRoRXhjZWVkZWQoZGVwdGgpIHtcbiAgICBpZiAoZGVwdGggPiBtYXhEZXB0aCkge1xuICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICdPYmplY3QgaXMgdG9vIGRlZXBseSBuZXN0ZWQgKCcgKyBkZXB0aCArICcgbGV2ZWxzKS4gTWF4IGRlcHRoOiAnICsgbWF4RGVwdGgsXG4gICAgICAgIEF4aW9zRXJyb3IuRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBzdHJpbmdpZnlXaXRoRGVwdGhMaW1pdCh2YWx1ZSwgZGVwdGgpIHtcbiAgICBpZiAobWF4RGVwdGggPT09IEluZmluaXR5KSB7XG4gICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH1cblxuICAgIGNvbnN0IGFuY2VzdG9ycyA9IFtdO1xuXG4gICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHZhbHVlLCBmdW5jdGlvbiBsaW1pdERlcHRoKF9rZXksIGN1cnJlbnRWYWx1ZSkge1xuICAgICAgaWYgKCF1dGlscy5pc09iamVjdChjdXJyZW50VmFsdWUpKSB7XG4gICAgICAgIHJldHVybiBjdXJyZW50VmFsdWU7XG4gICAgICB9XG5cbiAgICAgIHdoaWxlIChhbmNlc3RvcnMubGVuZ3RoICYmIGFuY2VzdG9yc1thbmNlc3RvcnMubGVuZ3RoIC0gMV0gIT09IHRoaXMpIHtcbiAgICAgICAgYW5jZXN0b3JzLnBvcCgpO1xuICAgICAgfVxuXG4gICAgICBhbmNlc3RvcnMucHVzaChjdXJyZW50VmFsdWUpO1xuICAgICAgdGhyb3dJZk1heERlcHRoRXhjZWVkZWQoZGVwdGggKyBhbmNlc3RvcnMubGVuZ3RoIC0gMSk7XG5cbiAgICAgIHJldHVybiBjdXJyZW50VmFsdWU7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogRGVmYXVsdCB2aXNpdG9yLlxuICAgKlxuICAgKiBAcGFyYW0geyp9IHZhbHVlXG4gICAqIEBwYXJhbSB7U3RyaW5nfE51bWJlcn0ga2V5XG4gICAqIEBwYXJhbSB7QXJyYXk8U3RyaW5nfE51bWJlcj59IHBhdGhcbiAgICogQHRoaXMge0Zvcm1EYXRhfVxuICAgKlxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gcmV0dXJuIHRydWUgdG8gdmlzaXQgdGhlIGVhY2ggcHJvcCBvZiB0aGUgdmFsdWUgcmVjdXJzaXZlbHlcbiAgICovXG4gIGZ1bmN0aW9uIGRlZmF1bHRWaXNpdG9yKHZhbHVlLCBrZXksIHBhdGgpIHtcbiAgICBsZXQgYXJyID0gdmFsdWU7XG5cbiAgICBpZiAodXRpbHMuaXNSZWFjdE5hdGl2ZShmb3JtRGF0YSkgJiYgdXRpbHMuaXNSZWFjdE5hdGl2ZUJsb2IodmFsdWUpKSB7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQocmVuZGVyS2V5KHBhdGgsIGtleSwgZG90cyksIGNvbnZlcnRWYWx1ZSh2YWx1ZSkpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGlmICh2YWx1ZSAmJiAhcGF0aCAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICBpZiAodXRpbHMuZW5kc1dpdGgoa2V5LCAne30nKSkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAga2V5ID0gbWV0YVRva2VucyA/IGtleSA6IGtleS5zbGljZSgwLCAtMik7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgICB2YWx1ZSA9IHN0cmluZ2lmeVdpdGhEZXB0aExpbWl0KHZhbHVlLCAxKTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICh1dGlscy5pc0FycmF5KHZhbHVlKSAmJiBpc0ZsYXRBcnJheSh2YWx1ZSkpIHx8XG4gICAgICAgICgodXRpbHMuaXNGaWxlTGlzdCh2YWx1ZSkgfHwgdXRpbHMuZW5kc1dpdGgoa2V5LCAnW10nKSkgJiYgKGFyciA9IHV0aWxzLnRvQXJyYXkodmFsdWUpKSlcbiAgICAgICkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAga2V5ID0gcmVtb3ZlQnJhY2tldHMoa2V5KTtcblxuICAgICAgICBhcnIuZm9yRWFjaChmdW5jdGlvbiBlYWNoKGVsLCBpbmRleCkge1xuICAgICAgICAgICEodXRpbHMuaXNVbmRlZmluZWQoZWwpIHx8IGVsID09PSBudWxsKSAmJlxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKFxuICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmVzdGVkLXRlcm5hcnlcbiAgICAgICAgICAgICAgaW5kZXhlcyA9PT0gdHJ1ZVxuICAgICAgICAgICAgICAgID8gcmVuZGVyS2V5KFtrZXldLCBpbmRleCwgZG90cylcbiAgICAgICAgICAgICAgICA6IGluZGV4ZXMgPT09IG51bGxcbiAgICAgICAgICAgICAgICAgID8ga2V5XG4gICAgICAgICAgICAgICAgICA6IGtleSArICdbXScsXG4gICAgICAgICAgICAgIGNvbnZlcnRWYWx1ZShlbClcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGlzVmlzaXRhYmxlKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgZm9ybURhdGEuYXBwZW5kKHJlbmRlcktleShwYXRoLCBrZXksIGRvdHMpLCBjb252ZXJ0VmFsdWUodmFsdWUpKTtcblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGNvbnN0IGV4cG9zZWRIZWxwZXJzID0gT2JqZWN0LmFzc2lnbihwcmVkaWNhdGVzLCB7XG4gICAgZGVmYXVsdFZpc2l0b3IsXG4gICAgY29udmVydFZhbHVlLFxuICAgIGlzVmlzaXRhYmxlLFxuICB9KTtcblxuICBmdW5jdGlvbiBidWlsZCh2YWx1ZSwgcGF0aCwgZGVwdGggPSAwKSB7XG4gICAgaWYgKHV0aWxzLmlzVW5kZWZpbmVkKHZhbHVlKSkgcmV0dXJuO1xuXG4gICAgdGhyb3dJZk1heERlcHRoRXhjZWVkZWQoZGVwdGgpO1xuXG4gICAgaWYgKHN0YWNrLmluZGV4T2YodmFsdWUpICE9PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDaXJjdWxhciByZWZlcmVuY2UgZGV0ZWN0ZWQgaW4gJyArIHBhdGguam9pbignLicpKTtcbiAgICB9XG5cbiAgICBzdGFjay5wdXNoKHZhbHVlKTtcblxuICAgIHV0aWxzLmZvckVhY2godmFsdWUsIGZ1bmN0aW9uIGVhY2goZWwsIGtleSkge1xuICAgICAgY29uc3QgcmVzdWx0ID1cbiAgICAgICAgISh1dGlscy5pc1VuZGVmaW5lZChlbCkgfHwgZWwgPT09IG51bGwpICYmXG4gICAgICAgIHZpc2l0b3IuY2FsbChmb3JtRGF0YSwgZWwsIHV0aWxzLmlzU3RyaW5nKGtleSkgPyBrZXkudHJpbSgpIDoga2V5LCBwYXRoLCBleHBvc2VkSGVscGVycyk7XG5cbiAgICAgIGlmIChyZXN1bHQgPT09IHRydWUpIHtcbiAgICAgICAgYnVpbGQoZWwsIHBhdGggPyBwYXRoLmNvbmNhdChrZXkpIDogW2tleV0sIGRlcHRoICsgMSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBzdGFjay5wb3AoKTtcbiAgfVxuXG4gIGlmICghdXRpbHMuaXNPYmplY3Qob2JqKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2RhdGEgbXVzdCBiZSBhbiBvYmplY3QnKTtcbiAgfVxuXG4gIGJ1aWxkKG9iaik7XG5cbiAgcmV0dXJuIGZvcm1EYXRhO1xufVxuXG5leHBvcnQgZGVmYXVsdCB0b0Zvcm1EYXRhO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdG9Gb3JtRGF0YSBmcm9tICcuL3RvRm9ybURhdGEuanMnO1xuXG4vKipcbiAqIEl0IGVuY29kZXMgYSBzdHJpbmcgYnkgcmVwbGFjaW5nIGFsbCBjaGFyYWN0ZXJzIHRoYXQgYXJlIG5vdCBpbiB0aGUgdW5yZXNlcnZlZCBzZXQgd2l0aFxuICogdGhlaXIgcGVyY2VudC1lbmNvZGVkIGVxdWl2YWxlbnRzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHN0ciAtIFRoZSBzdHJpbmcgdG8gZW5jb2RlLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBlbmNvZGVkIHN0cmluZy5cbiAqL1xuZnVuY3Rpb24gZW5jb2RlKHN0cikge1xuICBjb25zdCBjaGFyTWFwID0ge1xuICAgICchJzogJyUyMScsXG4gICAgXCInXCI6ICclMjcnLFxuICAgICcoJzogJyUyOCcsXG4gICAgJyknOiAnJTI5JyxcbiAgICAnfic6ICclN0UnLFxuICAgICclMjAnOiAnKycsXG4gIH07XG4gIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQoc3RyKS5yZXBsYWNlKC9bIScoKX5dfCUyMC9nLCBmdW5jdGlvbiByZXBsYWNlcihtYXRjaCkge1xuICAgIHJldHVybiBjaGFyTWFwW21hdGNoXTtcbiAgfSk7XG59XG5cbi8qKlxuICogSXQgdGFrZXMgYSBwYXJhbXMgb2JqZWN0IGFuZCBjb252ZXJ0cyBpdCB0byBhIEZvcm1EYXRhIG9iamVjdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PHN0cmluZywgYW55Pn0gcGFyYW1zIC0gVGhlIHBhcmFtZXRlcnMgdG8gYmUgY29udmVydGVkIHRvIGEgRm9ybURhdGEgb2JqZWN0LlxuICogQHBhcmFtIHtPYmplY3Q8c3RyaW5nLCBhbnk+fSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgb2JqZWN0IHBhc3NlZCB0byB0aGUgQXhpb3MgY29uc3RydWN0b3IuXG4gKlxuICogQHJldHVybnMge3ZvaWR9XG4gKi9cbmZ1bmN0aW9uIEF4aW9zVVJMU2VhcmNoUGFyYW1zKHBhcmFtcywgb3B0aW9ucykge1xuICB0aGlzLl9wYWlycyA9IFtdO1xuXG4gIHBhcmFtcyAmJiB0b0Zvcm1EYXRhKHBhcmFtcywgdGhpcywgb3B0aW9ucyk7XG59XG5cbmNvbnN0IHByb3RvdHlwZSA9IEF4aW9zVVJMU2VhcmNoUGFyYW1zLnByb3RvdHlwZTtcblxucHJvdG90eXBlLmFwcGVuZCA9IGZ1bmN0aW9uIGFwcGVuZChuYW1lLCB2YWx1ZSkge1xuICB0aGlzLl9wYWlycy5wdXNoKFtuYW1lLCB2YWx1ZV0pO1xufTtcblxucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gdG9TdHJpbmcoZW5jb2Rlcikge1xuICBjb25zdCBfZW5jb2RlID0gZW5jb2RlclxuICAgID8gKHZhbHVlKSA9PiBlbmNvZGVyLmNhbGwodGhpcywgdmFsdWUsIGVuY29kZSlcbiAgICA6IGVuY29kZTtcblxuICByZXR1cm4gdGhpcy5fcGFpcnNcbiAgICAubWFwKGZ1bmN0aW9uIGVhY2gocGFpcikge1xuICAgICAgcmV0dXJuIF9lbmNvZGUocGFpclswXSkgKyAnPScgKyBfZW5jb2RlKHBhaXJbMV0pO1xuICAgIH0sICcnKVxuICAgIC5qb2luKCcmJyk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBBeGlvc1VSTFNlYXJjaFBhcmFtcztcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc1VSTFNlYXJjaFBhcmFtcyBmcm9tICcuL0F4aW9zVVJMU2VhcmNoUGFyYW1zLmpzJztcblxuLyoqXG4gKiBJdCByZXBsYWNlcyBVUkwtZW5jb2RlZCBmb3JtcyBvZiBgOmAsIGAkYCwgYCxgLCBhbmQgc3BhY2VzIHdpdGhcbiAqIHRoZWlyIHBsYWluIGNvdW50ZXJwYXJ0cyAoYDpgLCBgJGAsIGAsYCwgYCtgKS5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsIFRoZSB2YWx1ZSB0byBiZSBlbmNvZGVkLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBlbmNvZGVkIHZhbHVlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlKHZhbCkge1xuICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHZhbClcbiAgICAucmVwbGFjZSgvJTNBL2dpLCAnOicpXG4gICAgLnJlcGxhY2UoLyUyNC9nLCAnJCcpXG4gICAgLnJlcGxhY2UoLyUyQy9naSwgJywnKVxuICAgIC5yZXBsYWNlKC8lMjAvZywgJysnKTtcbn1cblxuLyoqXG4gKiBCdWlsZCBhIFVSTCBieSBhcHBlbmRpbmcgcGFyYW1zIHRvIHRoZSBlbmRcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsIFRoZSBiYXNlIG9mIHRoZSB1cmwgKGUuZy4sIGh0dHA6Ly93d3cuZ29vZ2xlLmNvbSlcbiAqIEBwYXJhbSB7b2JqZWN0fSBbcGFyYW1zXSBUaGUgcGFyYW1zIHRvIGJlIGFwcGVuZGVkXG4gKiBAcGFyYW0gez8ob2JqZWN0fEZ1bmN0aW9uKX0gb3B0aW9uc1xuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBmb3JtYXR0ZWQgdXJsXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGJ1aWxkVVJMKHVybCwgcGFyYW1zLCBvcHRpb25zKSB7XG4gIGlmICghcGFyYW1zKSB7XG4gICAgcmV0dXJuIHVybDtcbiAgfVxuICB1cmwgPSB1cmwgfHwgJyc7XG5cbiAgY29uc3QgX29wdGlvbnMgPSB1dGlscy5pc0Z1bmN0aW9uKG9wdGlvbnMpXG4gICAgPyB7XG4gICAgICAgIHNlcmlhbGl6ZTogb3B0aW9ucyxcbiAgICAgIH1cbiAgICA6IG9wdGlvbnM7XG5cbiAgLy8gUmVhZCBzZXJpYWxpemVyIG9wdGlvbnMgcG9sbHV0aW9uLXNhZmVseTogb3duIHByb3BlcnRpZXMgYW5kIG1ldGhvZHMgb24gYVxuICAvLyBjbGFzcy90ZW1wbGF0ZSBwcm90b3R5cGUgYXJlIGhvbm9yZWQsIGJ1dCB2YWx1ZXMgaW5qZWN0ZWQgb250byBhIHBvbGx1dGVkXG4gIC8vIE9iamVjdC5wcm90b3R5cGUgYXJlIGlnbm9yZWQuXG4gIGNvbnN0IF9lbmNvZGUgPSB1dGlscy5nZXRTYWZlUHJvcChfb3B0aW9ucywgJ2VuY29kZScpIHx8IGVuY29kZTtcbiAgY29uc3Qgc2VyaWFsaXplRm4gPSB1dGlscy5nZXRTYWZlUHJvcChfb3B0aW9ucywgJ3NlcmlhbGl6ZScpO1xuXG4gIGxldCBzZXJpYWxpemVkUGFyYW1zO1xuXG4gIGlmIChzZXJpYWxpemVGbikge1xuICAgIHNlcmlhbGl6ZWRQYXJhbXMgPSBzZXJpYWxpemVGbihwYXJhbXMsIF9vcHRpb25zKTtcbiAgfSBlbHNlIHtcbiAgICBzZXJpYWxpemVkUGFyYW1zID0gdXRpbHMuaXNVUkxTZWFyY2hQYXJhbXMocGFyYW1zKVxuICAgICAgPyBwYXJhbXMudG9TdHJpbmcoKVxuICAgICAgOiBuZXcgQXhpb3NVUkxTZWFyY2hQYXJhbXMocGFyYW1zLCBfb3B0aW9ucykudG9TdHJpbmcoX2VuY29kZSk7XG4gIH1cblxuICBpZiAoc2VyaWFsaXplZFBhcmFtcykge1xuICAgIGNvbnN0IGhhc2htYXJrSW5kZXggPSB1cmwuaW5kZXhPZignIycpO1xuXG4gICAgaWYgKGhhc2htYXJrSW5kZXggIT09IC0xKSB7XG4gICAgICB1cmwgPSB1cmwuc2xpY2UoMCwgaGFzaG1hcmtJbmRleCk7XG4gICAgfVxuICAgIHVybCArPSAodXJsLmluZGV4T2YoJz8nKSA9PT0gLTEgPyAnPycgOiAnJicpICsgc2VyaWFsaXplZFBhcmFtcztcbiAgfVxuXG4gIHJldHVybiB1cmw7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbmNvbnN0ICRpbnRlcm5hbHMgPSBTeW1ib2woJ2ludGVybmFscycpO1xuXG4vLyBgaGFuZGxlcnNgIGlzIHB1YmxpYyBhbmQgbWF5IGJlIHJlcGxhY2VkIHdpdGggYSBudWxsaXNoIHZhbHVlIGJ5IHVzZXIgY29kZTtcbi8vIGBjbGVhcigpYCBoYXMgYWx3YXlzIHRvbGVyYXRlZCB0aGF0LiBUcmVhdCBpdCBhcyBhbiBlbXB0eSBzdGFjayByYXRoZXIgdGhhblxuLy8gZGVyZWZlcmVuY2luZyBpdC5cbmZ1bmN0aW9uIGNvdW50SGFuZGxlcnMoaGFuZGxlcnMpIHtcbiAgcmV0dXJuIGhhbmRsZXJzID8gaGFuZGxlcnMubGVuZ3RoIDogMDtcbn1cblxuZnVuY3Rpb24gdHJpbUhhbmRsZXJzKGhhbmRsZXJzKSB7XG4gIGlmICghaGFuZGxlcnMpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICB3aGlsZSAoaGFuZGxlcnMubGVuZ3RoICYmIGhhbmRsZXJzW2hhbmRsZXJzLmxlbmd0aCAtIDFdID09PSBudWxsKSB7XG4gICAgaGFuZGxlcnMucG9wKCk7XG4gIH1cbn1cblxuLy8gUHJlc2VydmUgdGhlIGFycmF5LWtleSBjb2VyY2lvbiB1c2VkIGJlZm9yZSBJRHMgd2VyZSBzdG9yZWQgaW4gYSBNYXAsIHdpdGhvdXRcbi8vIHRyZWF0aW5nIG51bGwsIGVtcHR5IHN0cmluZ3MsIG9yIG5vbmNhbm9uaWNhbCBudW1lcmljIHN0cmluZ3MgYXMgSUQgemVyby5cbmZ1bmN0aW9uIG5vcm1hbGl6ZUhhbmRsZXJJZChpZCkge1xuICBpZiAodHlwZW9mIGlkID09PSAnc3RyaW5nJyAmJiBpZCAhPT0gJycgJiYgU3RyaW5nKE51bWJlcihpZCkpID09PSBpZCkge1xuICAgIHJldHVybiBOdW1iZXIoaWQpO1xuICB9XG5cbiAgcmV0dXJuIGlkO1xufVxuXG5mdW5jdGlvbiBzeW5jSGFuZGxlckVudHJpZXMobWFuYWdlciwgaW50ZXJuYWxzKSB7XG4gIGNvbnN0IGhhbmRsZXJzID0gbWFuYWdlci5oYW5kbGVycztcbiAgY29uc3QgbGVuZ3RoID0gY291bnRIYW5kbGVycyhoYW5kbGVycyk7XG5cbiAgaWYgKGhhbmRsZXJzICE9PSBpbnRlcm5hbHMuaGFuZGxlcnNSZWYpIHtcbiAgICBpbnRlcm5hbHMuaGFuZGxlcnNSZWYgPSBoYW5kbGVycztcbiAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuY2xlYXIoKTtcbiAgfSBlbHNlIGlmIChsZW5ndGggIT09IGludGVybmFscy5oYW5kbGVyc0xlbmd0aCkge1xuICAgIGlmICghbGVuZ3RoKSB7XG4gICAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuY2xlYXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW50ZXJuYWxzLmhhbmRsZXJFbnRyaWVzLmZvckVhY2goZnVuY3Rpb24gcmVtb3ZlU3RhbGVFbnRyeShlbnRyeSwgaWQpIHtcbiAgICAgICAgaWYgKGhhbmRsZXJzW2VudHJ5LmluZGV4XSAhPT0gZW50cnkuaGFuZGxlcikge1xuICAgICAgICAgIGludGVybmFscy5oYW5kbGVyRW50cmllcy5kZWxldGUoaWQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBpbnRlcm5hbHMuaGFuZGxlcnNMZW5ndGggPSBsZW5ndGg7XG59XG5cbmNsYXNzIEludGVyY2VwdG9yTWFuYWdlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICB0aGlzWyRpbnRlcm5hbHNdID0ge1xuICAgICAgaGFuZGxlcnNSZWY6IHRoaXMuaGFuZGxlcnMsXG4gICAgICBoYW5kbGVyc0xlbmd0aDogdGhpcy5oYW5kbGVycy5sZW5ndGgsXG4gICAgICBoYW5kbGVyRW50cmllczogbmV3IE1hcCgpLFxuICAgICAgaXRlcmF0aW9uRGVwdGg6IDAsXG4gICAgICBuZXh0SWQ6IDAsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgYSBuZXcgaW50ZXJjZXB0b3IgdG8gdGhlIHN0YWNrXG4gICAqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bGZpbGxlZCBUaGUgZnVuY3Rpb24gdG8gaGFuZGxlIGB0aGVuYCBmb3IgYSBgUHJvbWlzZWBcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gcmVqZWN0ZWQgVGhlIGZ1bmN0aW9uIHRvIGhhbmRsZSBgcmVqZWN0YCBmb3IgYSBgUHJvbWlzZWBcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgVGhlIG9wdGlvbnMgZm9yIHRoZSBpbnRlcmNlcHRvciwgc3luY2hyb25vdXMgYW5kIHJ1bldoZW5cbiAgICpcbiAgICogQHJldHVybiB7TnVtYmVyfSBBbiBJRCB1c2VkIHRvIHJlbW92ZSBpbnRlcmNlcHRvciBsYXRlclxuICAgKi9cbiAgdXNlKGZ1bGZpbGxlZCwgcmVqZWN0ZWQsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBoYW5kbGVyID0ge1xuICAgICAgZnVsZmlsbGVkLFxuICAgICAgcmVqZWN0ZWQsXG4gICAgICBzeW5jaHJvbm91czogb3B0aW9ucyA/IG9wdGlvbnMuc3luY2hyb25vdXMgOiBmYWxzZSxcbiAgICAgIHJ1bldoZW46IG9wdGlvbnMgPyBvcHRpb25zLnJ1bldoZW4gOiBudWxsLFxuICAgIH07XG4gICAgY29uc3QgaW50ZXJuYWxzID0gdGhpc1skaW50ZXJuYWxzXTtcblxuICAgIGlmICh0aGlzLmhhbmRsZXJzID09IG51bGwpIHtcbiAgICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICB9XG5cbiAgICBzeW5jSGFuZGxlckVudHJpZXModGhpcywgaW50ZXJuYWxzKTtcblxuICAgIGNvbnN0IGlkID0gaW50ZXJuYWxzLm5leHRJZCsrO1xuXG4gICAgdGhpcy5oYW5kbGVycy5wdXNoKGhhbmRsZXIpO1xuICAgIGludGVybmFscy5oYW5kbGVyRW50cmllcy5zZXQoaWQsIHtcbiAgICAgIGhhbmRsZXIsXG4gICAgICBpbmRleDogdGhpcy5oYW5kbGVycy5sZW5ndGggLSAxLFxuICAgIH0pO1xuICAgIGludGVybmFscy5oYW5kbGVyc0xlbmd0aCA9IHRoaXMuaGFuZGxlcnMubGVuZ3RoO1xuXG4gICAgcmV0dXJuIGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZSBhbiBpbnRlcmNlcHRvciBmcm9tIHRoZSBzdGFja1xuICAgKlxuICAgKiBAcGFyYW0ge051bWJlcn0gaWQgVGhlIElEIHRoYXQgd2FzIHJldHVybmVkIGJ5IGB1c2VgXG4gICAqXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgZWplY3QoaWQpIHtcbiAgICBjb25zdCBpbnRlcm5hbHMgPSB0aGlzWyRpbnRlcm5hbHNdO1xuXG4gICAgc3luY0hhbmRsZXJFbnRyaWVzKHRoaXMsIGludGVybmFscyk7XG5cbiAgICBjb25zdCBoYW5kbGVySWQgPSBub3JtYWxpemVIYW5kbGVySWQoaWQpO1xuICAgIGNvbnN0IGVudHJ5ID0gaW50ZXJuYWxzLmhhbmRsZXJFbnRyaWVzLmdldChoYW5kbGVySWQpO1xuXG4gICAgaWYgKGVudHJ5KSB7XG4gICAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuZGVsZXRlKGhhbmRsZXJJZCk7XG5cbiAgICAgIC8vIElnbm9yZSBJRHMgaW52YWxpZGF0ZWQgYnkgY2xlYXIgb3IgZGlyZWN0IHJlcGxhY2VtZW50IG9mIGhhbmRsZXJzLlxuICAgICAgaWYgKHRoaXMuaGFuZGxlcnNbZW50cnkuaW5kZXhdICE9PSBlbnRyeS5oYW5kbGVyKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgdGhpcy5oYW5kbGVyc1tlbnRyeS5pbmRleF0gPSBudWxsO1xuXG4gICAgICAvLyBEbyBub3QgcmV1c2UgYW4gaW5kZXggd2hpbGUgZm9yRWFjaCBpcyB3YWxraW5nIGl0cyBsZW5ndGggc25hcHNob3QuXG4gICAgICBpZiAoIWludGVybmFscy5pdGVyYXRpb25EZXB0aCkge1xuICAgICAgICB0cmltSGFuZGxlcnModGhpcy5oYW5kbGVycyk7XG4gICAgICAgIGludGVybmFscy5oYW5kbGVyc0xlbmd0aCA9IHRoaXMuaGFuZGxlcnMubGVuZ3RoO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDbGVhciBhbGwgaW50ZXJjZXB0b3JzIGZyb20gdGhlIHN0YWNrXG4gICAqXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgY2xlYXIoKSB7XG4gICAgaWYgKHRoaXMuaGFuZGxlcnMpIHtcbiAgICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICAgIHN5bmNIYW5kbGVyRW50cmllcyh0aGlzLCB0aGlzWyRpbnRlcm5hbHNdKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogSXRlcmF0ZSBvdmVyIGFsbCB0aGUgcmVnaXN0ZXJlZCBpbnRlcmNlcHRvcnNcbiAgICpcbiAgICogVGhpcyBtZXRob2QgaXMgcGFydGljdWxhcmx5IHVzZWZ1bCBmb3Igc2tpcHBpbmcgb3ZlciBhbnlcbiAgICogaW50ZXJjZXB0b3JzIHRoYXQgbWF5IGhhdmUgYmVjb21lIGBudWxsYCBjYWxsaW5nIGBlamVjdGAuXG4gICAqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBmdW5jdGlvbiB0byBjYWxsIGZvciBlYWNoIGludGVyY2VwdG9yXG4gICAqXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgZm9yRWFjaChmbikge1xuICAgIGNvbnN0IGludGVybmFscyA9IHRoaXNbJGludGVybmFsc107XG5cbiAgICBzeW5jSGFuZGxlckVudHJpZXModGhpcywgaW50ZXJuYWxzKTtcblxuICAgIGludGVybmFscy5pdGVyYXRpb25EZXB0aCsrO1xuXG4gICAgdHJ5IHtcbiAgICAgIHV0aWxzLmZvckVhY2godGhpcy5oYW5kbGVycywgZnVuY3Rpb24gZm9yRWFjaEhhbmRsZXIoaCkge1xuICAgICAgICBpZiAoaCAhPT0gbnVsbCkge1xuICAgICAgICAgIGZuKGgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKCEtLWludGVybmFscy5pdGVyYXRpb25EZXB0aCkge1xuICAgICAgICBzeW5jSGFuZGxlckVudHJpZXModGhpcywgaW50ZXJuYWxzKTtcbiAgICAgICAgdHJpbUhhbmRsZXJzKHRoaXMuaGFuZGxlcnMpO1xuICAgICAgICBpbnRlcm5hbHMuaGFuZGxlcnNMZW5ndGggPSBjb3VudEhhbmRsZXJzKHRoaXMuaGFuZGxlcnMpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBJbnRlcmNlcHRvck1hbmFnZXI7XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgc2lsZW50SlNPTlBhcnNpbmc6IHRydWUsXG4gIGZvcmNlZEpTT05QYXJzaW5nOiB0cnVlLFxuICBjbGFyaWZ5VGltZW91dEVycm9yOiBmYWxzZSxcbiAgbGVnYWN5SW50ZXJjZXB0b3JSZXFSZXNPcmRlcmluZzogdHJ1ZSxcbiAgYWR2ZXJ0aXNlWnN0ZEFjY2VwdEVuY29kaW5nOiBmYWxzZSxcbiAgdmFsaWRhdGVTdGF0dXNVbmRlZmluZWRSZXNvbHZlczogdHJ1ZSxcbiAgZW5jb2RlQmFzaWNBdXRoVXNlcm5hbWU6IGZhbHNlLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4uLy4uLy4uL2hlbHBlcnMvQXhpb3NVUkxTZWFyY2hQYXJhbXMuanMnO1xuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIFVSTFNlYXJjaFBhcmFtcyAhPT0gJ3VuZGVmaW5lZCcgPyBVUkxTZWFyY2hQYXJhbXMgOiBBeGlvc1VSTFNlYXJjaFBhcmFtcztcbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIEZvcm1EYXRhICE9PSAndW5kZWZpbmVkJyA/IEZvcm1EYXRhIDogbnVsbDtcbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnID8gQmxvYiA6IG51bGw7XG4iLCJpbXBvcnQgVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4vY2xhc3Nlcy9VUkxTZWFyY2hQYXJhbXMuanMnO1xuaW1wb3J0IEZvcm1EYXRhIGZyb20gJy4vY2xhc3Nlcy9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgQmxvYiBmcm9tICcuL2NsYXNzZXMvQmxvYi5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgaXNCcm93c2VyOiB0cnVlLFxuICBjbGFzc2VzOiB7XG4gICAgVVJMU2VhcmNoUGFyYW1zLFxuICAgIEZvcm1EYXRhLFxuICAgIEJsb2IsXG4gIH0sXG4gIHByb3RvY29sczogWydodHRwJywgJ2h0dHBzJywgJ2ZpbGUnLCAnYmxvYicsICd1cmwnLCAnZGF0YSddLFxufTtcbiIsImNvbnN0IGhhc0Jyb3dzZXJFbnYgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG5jb25zdCBfbmF2aWdhdG9yID0gKHR5cGVvZiBuYXZpZ2F0b3IgPT09ICdvYmplY3QnICYmIG5hdmlnYXRvcikgfHwgdW5kZWZpbmVkO1xuXG4vKipcbiAqIERldGVybWluZSBpZiB3ZSdyZSBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciBlbnZpcm9ubWVudFxuICpcbiAqIFRoaXMgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXIsIGFuZCByZWFjdC1uYXRpdmUuXG4gKiBCb3RoIGVudmlyb25tZW50cyBzdXBwb3J0IFhNTEh0dHBSZXF1ZXN0LCBidXQgbm90IGZ1bGx5IHN0YW5kYXJkIGdsb2JhbHMuXG4gKlxuICogd2ViIHdvcmtlcnM6XG4gKiAgdHlwZW9mIHdpbmRvdyAtPiB1bmRlZmluZWRcbiAqICB0eXBlb2YgZG9jdW1lbnQgLT4gdW5kZWZpbmVkXG4gKlxuICogcmVhY3QtbmF0aXZlOlxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdSZWFjdE5hdGl2ZSdcbiAqIG5hdGl2ZXNjcmlwdFxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdOYXRpdmVTY3JpcHQnIG9yICdOUydcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuY29uc3QgaGFzU3RhbmRhcmRCcm93c2VyRW52ID1cbiAgaGFzQnJvd3NlckVudiAmJlxuICAoIV9uYXZpZ2F0b3IgfHwgWydSZWFjdE5hdGl2ZScsICdOYXRpdmVTY3JpcHQnLCAnTlMnXS5pbmRleE9mKF9uYXZpZ2F0b3IucHJvZHVjdCkgPCAwKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgd2UncmUgcnVubmluZyBpbiBhIHN0YW5kYXJkIGJyb3dzZXIgd2ViV29ya2VyIGVudmlyb25tZW50XG4gKlxuICogQWx0aG91Z2ggdGhlIGBpc1N0YW5kYXJkQnJvd3NlckVudmAgbWV0aG9kIGluZGljYXRlcyB0aGF0XG4gKiBgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXJgLCB0aGUgV2ViV29ya2VyIHdpbGwgc3RpbGwgYmVcbiAqIGZpbHRlcmVkIG91dCBkdWUgdG8gaXRzIGp1ZGdtZW50IHN0YW5kYXJkXG4gKiBgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJ2AuXG4gKiBUaGlzIGxlYWRzIHRvIGEgcHJvYmxlbSB3aGVuIGF4aW9zIHBvc3QgYEZvcm1EYXRhYCBpbiB3ZWJXb3JrZXJcbiAqL1xuY29uc3QgaGFzU3RhbmRhcmRCcm93c2VyV2ViV29ya2VyRW52ID0gKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgV29ya2VyR2xvYmFsU2NvcGUgIT09ICd1bmRlZmluZWQnICYmXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG4gICAgc2VsZiBpbnN0YW5jZW9mIFdvcmtlckdsb2JhbFNjb3BlICYmXG4gICAgdHlwZW9mIHNlbGYuaW1wb3J0U2NyaXB0cyA9PT0gJ2Z1bmN0aW9uJ1xuICApO1xufSkoKTtcblxuY29uc3Qgb3JpZ2luID0gKGhhc0Jyb3dzZXJFbnYgJiYgd2luZG93LmxvY2F0aW9uLmhyZWYpIHx8ICdodHRwOi8vbG9jYWxob3N0JztcblxuZXhwb3J0IHtcbiAgaGFzQnJvd3NlckVudixcbiAgaGFzU3RhbmRhcmRCcm93c2VyV2ViV29ya2VyRW52LFxuICBoYXNTdGFuZGFyZEJyb3dzZXJFbnYsXG4gIF9uYXZpZ2F0b3IgYXMgbmF2aWdhdG9yLFxuICBvcmlnaW4sXG59O1xuIiwiaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4vbm9kZS9pbmRleC5qcyc7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tICcuL2NvbW1vbi91dGlscy5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgLi4udXRpbHMsXG4gIC4uLnBsYXRmb3JtLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCB0b0Zvcm1EYXRhIGZyb20gJy4vdG9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB0b1VSTEVuY29kZWRGb3JtKGRhdGEsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHRvRm9ybURhdGEoZGF0YSwgbmV3IHBsYXRmb3JtLmNsYXNzZXMuVVJMU2VhcmNoUGFyYW1zKCksIHtcbiAgICB2aXNpdG9yOiBmdW5jdGlvbiAodmFsdWUsIGtleSwgcGF0aCwgaGVscGVycykge1xuICAgICAgaWYgKHBsYXRmb3JtLmlzTm9kZSAmJiB1dGlscy5pc0J1ZmZlcih2YWx1ZSkpIHtcbiAgICAgICAgdGhpcy5hcHBlbmQoa2V5LCB2YWx1ZS50b1N0cmluZygnYmFzZTY0JykpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBoZWxwZXJzLmRlZmF1bHRWaXNpdG9yLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfSxcbiAgICAuLi5vcHRpb25zLFxuICB9KTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgeyBERUZBVUxUX0ZPUk1fREFUQV9NQVhfREVQVEggfSBmcm9tICcuL3RvRm9ybURhdGEuanMnO1xuXG5jb25zdCBNQVhfREVQVEggPSBERUZBVUxUX0ZPUk1fREFUQV9NQVhfREVQVEg7XG5cbmZ1bmN0aW9uIHRocm93SWZEZXB0aEV4Y2VlZGVkKGluZGV4KSB7XG4gIGlmIChpbmRleCA+IE1BWF9ERVBUSCkge1xuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgJ0Zvcm1EYXRhIGZpZWxkIGlzIHRvbyBkZWVwbHkgbmVzdGVkICgnICsgaW5kZXggKyAnIGxldmVscykuIE1heCBkZXB0aDogJyArIE1BWF9ERVBUSCxcbiAgICAgIEF4aW9zRXJyb3IuRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRFxuICAgICk7XG4gIH1cbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIHN0cmluZyBsaWtlIGBmb29beF1beV1bel1gIGFuZCByZXR1cm5zIGFuIGFycmF5IGxpa2UgYFsnZm9vJywgJ3gnLCAneScsICd6J11cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gbmFtZSAtIFRoZSBuYW1lIG9mIHRoZSBwcm9wZXJ0eSB0byBnZXQuXG4gKlxuICogQHJldHVybnMgQW4gYXJyYXkgb2Ygc3RyaW5ncy5cbiAqL1xuZnVuY3Rpb24gcGFyc2VQcm9wUGF0aChuYW1lKSB7XG4gIC8vIGZvb1t4XVt5XVt6XSAtPiBbJ2ZvbycsICd4JywgJ3knLCAneiddXG4gIC8vIGZvby54LnkueiAgICAtPiBbJ2ZvbycsICd4JywgJ3knLCAneiddXG4gIC8vIEEgcGF0aCBpcyBzcGxpdCBvbiBgLmAgYW5kIG9uIGBbLi4uXWAgZ3JvdXBzLiBBIHNlZ21lbnQg4oCUIHdoZXRoZXIgd3JpdHRlblxuICAvLyBpbiBkb3Qgbm90YXRpb24gb3IgY2FwdHVyZWQgaW5zaWRlIGJyYWNrZXRzIOKAlCBtYXkgY29udGFpbiBhbnkgY2hhcmFjdGVyXG4gIC8vIGV4Y2VwdCBgLmAsIGBbYCBhbmQgYF1gLCBzbyBhIGtleSBsaWtlIGB1c2VyLW5hbWVgIG9yIGB1c2VyIG5hbWVgIGlzIGtlcHRcbiAgLy8gbGl0ZXJhbCBpbnN0ZWFkIG9mIGJlaW5nIHNwbGl0ICgjNTQwMikuIGAuYCwgYFtgIGFuZCBgXWAga2VlcCB0aGVpciBleGlzdGluZ1xuICAvLyBtZWFuaW5nLCBlLmcuIGBmb29bYmFyLmJhel1gIC0+IFsnZm9vJywgJ2JhcicsICdiYXonXSBhbmQgYFtdYCBpcyBhbiBhcnJheSBwdXNoLlxuICAvLyBFeGNsdWRpbmcgYFtgIGZyb20gdGhlIGJyYWNrZXQgZ3JvdXAgYWxzbyBtYWtlcyB0aGUgbWF0Y2ggZmFpbCBmYXN0IGF0IHRoZVxuICAvLyBuZXh0IGBbYCwgc28gYSBtYWxmb3JtZWQgbmFtZSBjYW5ub3QgcmVzY2FuIHRvIHRoZSBlbmQgb2YgdGhlIHN0cmluZyBmcm9tXG4gIC8vIGV2ZXJ5IHVubWF0Y2hlZCBgW2Ag4oCUIHBhcnNpbmcgc3RheXMgbGluZWFyIGluIHRoZSBsZW5ndGggb2YgdGhlIG5hbWUuXG4gIGNvbnN0IHBhdGggPSBbXTtcbiAgY29uc3QgcGF0dGVybiA9IC9bXi5bXFxdXSt8XFxbKFteLltcXF1dKildL2c7XG4gIGxldCBtYXRjaDtcblxuICB3aGlsZSAoKG1hdGNoID0gcGF0dGVybi5leGVjKG5hbWUpKSAhPT0gbnVsbCkge1xuICAgIHRocm93SWZEZXB0aEV4Y2VlZGVkKHBhdGgubGVuZ3RoKTtcbiAgICBwYXRoLnB1c2gobWF0Y2hbMF0gPT09ICdbXScgPyAnJyA6IG1hdGNoWzFdIHx8IG1hdGNoWzBdKTtcbiAgfVxuXG4gIHJldHVybiBwYXRoO1xufVxuXG4vKipcbiAqIENvbnZlcnQgYW4gYXJyYXkgdG8gYW4gb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7QXJyYXk8YW55Pn0gYXJyIC0gVGhlIGFycmF5IHRvIGNvbnZlcnQgdG8gYW4gb2JqZWN0LlxuICpcbiAqIEByZXR1cm5zIEFuIG9iamVjdCB3aXRoIHRoZSBzYW1lIGtleXMgYW5kIHZhbHVlcyBhcyB0aGUgYXJyYXkuXG4gKi9cbmZ1bmN0aW9uIGFycmF5VG9PYmplY3QoYXJyKSB7XG4gIGNvbnN0IG9iaiA9IHt9O1xuICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoYXJyKTtcbiAgbGV0IGk7XG4gIGNvbnN0IGxlbiA9IGtleXMubGVuZ3RoO1xuICBsZXQga2V5O1xuICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBrZXkgPSBrZXlzW2ldO1xuICAgIG9ialtrZXldID0gYXJyW2tleV07XG4gIH1cbiAgcmV0dXJuIG9iajtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplQXJyYXkodmFsdWUpIHtcbiAgaWYgKCF1dGlscy5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuXG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyh2YWx1ZSk7XG4gIHJldHVybiBrZXlzLmxlbmd0aCAhPT0gdmFsdWUubGVuZ3RoIHx8IGtleXMuc29tZSgoa2V5LCBpbmRleCkgPT4ga2V5ICE9PSBTdHJpbmcoaW5kZXgpKVxuICAgID8gYXJyYXlUb09iamVjdCh2YWx1ZSlcbiAgICA6IHZhbHVlO1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVBcnJheXMob2JqKSB7XG4gIGNvbnN0IHBlbmRpbmcgPSBbb2JqXTtcbiAgd2hpbGUgKHBlbmRpbmcubGVuZ3RoKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gcGVuZGluZy5wb3AoKTtcbiAgICBPYmplY3Qua2V5cyh0YXJnZXQpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgY29uc3QgdmFsdWUgPSAodGFyZ2V0W2tleV0gPSBub3JtYWxpemVBcnJheSh0YXJnZXRba2V5XSkpO1xuICAgICAgaWYgKHV0aWxzLmlzQXJyYXkodmFsdWUpIHx8IHV0aWxzLmlzUGxhaW5PYmplY3QodmFsdWUpKSB7XG4gICAgICAgIHBlbmRpbmcucHVzaCh2YWx1ZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIG9iajtcbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIEZvcm1EYXRhIG9iamVjdCBhbmQgcmV0dXJucyBhIEphdmFTY3JpcHQgb2JqZWN0XG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGZvcm1EYXRhIFRoZSBGb3JtRGF0YSBvYmplY3QgdG8gY29udmVydCB0byBKU09OLlxuICpcbiAqIEByZXR1cm5zIHtPYmplY3Q8c3RyaW5nLCBhbnk+IHwgbnVsbH0gVGhlIGNvbnZlcnRlZCBvYmplY3QuXG4gKi9cbmZ1bmN0aW9uIGZvcm1EYXRhVG9KU09OKGZvcm1EYXRhKSB7XG4gIGZ1bmN0aW9uIGJ1aWxkUGF0aChwYXRoLCB2YWx1ZSwgdGFyZ2V0LCBpbmRleCkge1xuICAgIHRocm93SWZEZXB0aEV4Y2VlZGVkKGluZGV4KTtcblxuICAgIGxldCBuYW1lID0gcGF0aFtpbmRleCsrXTtcblxuICAgIGlmIChuYW1lID09PSAnX19wcm90b19fJykgcmV0dXJuIHRydWU7XG5cbiAgICBjb25zdCBpc051bWVyaWNLZXkgPSBOdW1iZXIuaXNGaW5pdGUoK25hbWUpO1xuICAgIGNvbnN0IGlzTGFzdCA9IGluZGV4ID49IHBhdGgubGVuZ3RoO1xuICAgIG5hbWUgPSAhbmFtZSAmJiB1dGlscy5pc0FycmF5KHRhcmdldCkgPyB0YXJnZXQubGVuZ3RoIDogbmFtZTtcblxuICAgIGlmIChpc0xhc3QpIHtcbiAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHRhcmdldCwgbmFtZSkpIHtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gbm9ybWFsaXplQXJyYXkodGFyZ2V0W25hbWVdKTtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gdXRpbHMuaXNBcnJheSh0YXJnZXRbbmFtZV0pXG4gICAgICAgICAgPyB0YXJnZXRbbmFtZV0uY29uY2F0KHZhbHVlKVxuICAgICAgICAgIDogW3RhcmdldFtuYW1lXSwgdmFsdWVdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gdmFsdWU7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiAhaXNOdW1lcmljS2V5O1xuICAgIH1cblxuICAgIGlmICghdXRpbHMuaGFzT3duUHJvcCh0YXJnZXQsIG5hbWUpIHx8ICF1dGlscy5pc09iamVjdCh0YXJnZXRbbmFtZV0pKSB7XG4gICAgICB0YXJnZXRbbmFtZV0gPSBbXTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBidWlsZFBhdGgocGF0aCwgdmFsdWUsIHRhcmdldFtuYW1lXSwgaW5kZXgpO1xuXG4gICAgaWYgKHJlc3VsdCAmJiB1dGlscy5pc0FycmF5KHRhcmdldFtuYW1lXSkpIHtcbiAgICAgIHRhcmdldFtuYW1lXSA9IGFycmF5VG9PYmplY3QodGFyZ2V0W25hbWVdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gIWlzTnVtZXJpY0tleTtcbiAgfVxuXG4gIGlmICh1dGlscy5pc0Zvcm1EYXRhKGZvcm1EYXRhKSAmJiB1dGlscy5pc0Z1bmN0aW9uKGZvcm1EYXRhLmVudHJpZXMpKSB7XG4gICAgY29uc3Qgb2JqID0ge307XG5cbiAgICB1dGlscy5mb3JFYWNoRW50cnkoZm9ybURhdGEsIChuYW1lLCB2YWx1ZSkgPT4ge1xuICAgICAgYnVpbGRQYXRoKHBhcnNlUHJvcFBhdGgobmFtZSksIHZhbHVlLCBvYmosIDApO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIG5vcm1hbGl6ZUFycmF5cyhvYmopO1xuICB9XG5cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZvcm1EYXRhVG9KU09OO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5jb25zdCBtZXRob2RMaXN0ID0gT2JqZWN0LmZyZWV6ZShbXG4gICdnZXQnLFxuICAnZGVsZXRlJyxcbiAgJ2hlYWQnLFxuICAnb3B0aW9ucycsXG4gICdwb3N0JyxcbiAgJ3B1dCcsXG4gICdwYXRjaCcsXG4gICdwdXJnZScsXG4gICdsaW5rJyxcbiAgJ3VubGluaycsXG4gICdxdWVyeScsXG5dKTtcblxuZXhwb3J0IGRlZmF1bHQgbWV0aG9kTGlzdDtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgdHJhbnNpdGlvbmFsRGVmYXVsdHMgZnJvbSAnLi90cmFuc2l0aW9uYWwuanMnO1xuaW1wb3J0IHRvRm9ybURhdGEgZnJvbSAnLi4vaGVscGVycy90b0Zvcm1EYXRhLmpzJztcbmltcG9ydCB0b1VSTEVuY29kZWRGb3JtIGZyb20gJy4uL2hlbHBlcnMvdG9VUkxFbmNvZGVkRm9ybS5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IGZvcm1EYXRhVG9KU09OIGZyb20gJy4uL2hlbHBlcnMvZm9ybURhdGFUb0pTT04uanMnO1xuaW1wb3J0IG1ldGhvZExpc3QgZnJvbSAnLi4vY29yZS9tZXRob2RMaXN0LmpzJztcblxuY29uc3Qgb3duID0gKG9iaiwga2V5KSA9PiAob2JqICE9IG51bGwgJiYgdXRpbHMuaGFzT3duUHJvcChvYmosIGtleSkgPyBvYmpba2V5XSA6IHVuZGVmaW5lZCk7XG5cbi8qKlxuICogSXQgdGFrZXMgYSBzdHJpbmcsIHRyaWVzIHRvIHBhcnNlIGl0LCBhbmQgaWYgaXQgZmFpbHMsIGl0IHJldHVybnMgdGhlIHN0cmluZ2lmaWVkIHZlcnNpb25cbiAqIG9mIHRoZSBpbnB1dFxuICpcbiAqIEBwYXJhbSB7YW55fSByYXdWYWx1ZSAtIFRoZSB2YWx1ZSB0byBiZSBzdHJpbmdpZmllZC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHBhcnNlciAtIEEgZnVuY3Rpb24gdGhhdCBwYXJzZXMgYSBzdHJpbmcgaW50byBhIEphdmFTY3JpcHQgb2JqZWN0LlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZW5jb2RlciAtIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHZhbHVlIGFuZCByZXR1cm5zIGEgc3RyaW5nLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEEgc3RyaW5naWZpZWQgdmVyc2lvbiBvZiB0aGUgcmF3VmFsdWUuXG4gKi9cbmZ1bmN0aW9uIHN0cmluZ2lmeVNhZmVseShyYXdWYWx1ZSwgcGFyc2VyLCBlbmNvZGVyKSB7XG4gIGlmICh1dGlscy5pc1N0cmluZyhyYXdWYWx1ZSkpIHtcbiAgICB0cnkge1xuICAgICAgKHBhcnNlciB8fCBKU09OLnBhcnNlKShyYXdWYWx1ZSk7XG4gICAgICByZXR1cm4gdXRpbHMudHJpbShyYXdWYWx1ZSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKGUubmFtZSAhPT0gJ1N5bnRheEVycm9yJykge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoZW5jb2RlciB8fCBKU09OLnN0cmluZ2lmeSkocmF3VmFsdWUpO1xufVxuXG5jb25zdCBkZWZhdWx0cyA9IHtcbiAgdHJhbnNpdGlvbmFsOiB0cmFuc2l0aW9uYWxEZWZhdWx0cyxcblxuICBhZGFwdGVyOiBbJ3hocicsICdodHRwJywgJ2ZldGNoJ10sXG5cbiAgdHJhbnNmb3JtUmVxdWVzdDogW1xuICAgIGZ1bmN0aW9uIHRyYW5zZm9ybVJlcXVlc3QoZGF0YSwgaGVhZGVycykge1xuICAgICAgY29uc3QgY29udGVudFR5cGUgPSBoZWFkZXJzLmdldENvbnRlbnRUeXBlKCkgfHwgJyc7XG4gICAgICBjb25zdCBoYXNKU09OQ29udGVudFR5cGUgPSBjb250ZW50VHlwZS5pbmRleE9mKCdhcHBsaWNhdGlvbi9qc29uJykgPiAtMTtcbiAgICAgIGNvbnN0IGlzT2JqZWN0UGF5bG9hZCA9IHV0aWxzLmlzT2JqZWN0KGRhdGEpO1xuXG4gICAgICBpZiAoaXNPYmplY3RQYXlsb2FkICYmIHV0aWxzLmlzSFRNTEZvcm0oZGF0YSkpIHtcbiAgICAgICAgZGF0YSA9IG5ldyBGb3JtRGF0YShkYXRhKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgaXNGb3JtRGF0YSA9IHV0aWxzLmlzRm9ybURhdGEoZGF0YSk7XG5cbiAgICAgIGlmIChpc0Zvcm1EYXRhKSB7XG4gICAgICAgIHJldHVybiBoYXNKU09OQ29udGVudFR5cGUgPyBKU09OLnN0cmluZ2lmeShmb3JtRGF0YVRvSlNPTihkYXRhKSkgOiBkYXRhO1xuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgIHV0aWxzLmlzQXJyYXlCdWZmZXIoZGF0YSkgfHxcbiAgICAgICAgdXRpbHMuaXNCdWZmZXIoZGF0YSkgfHxcbiAgICAgICAgdXRpbHMuaXNTdHJlYW0oZGF0YSkgfHxcbiAgICAgICAgdXRpbHMuaXNGaWxlKGRhdGEpIHx8XG4gICAgICAgIHV0aWxzLmlzQmxvYihkYXRhKSB8fFxuICAgICAgICB1dGlscy5pc1JlYWRhYmxlU3RyZWFtKGRhdGEpXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICB9XG4gICAgICBpZiAodXRpbHMuaXNBcnJheUJ1ZmZlclZpZXcoZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIGRhdGEuYnVmZmVyO1xuICAgICAgfVxuICAgICAgaWYgKHV0aWxzLmlzVVJMU2VhcmNoUGFyYW1zKGRhdGEpKSB7XG4gICAgICAgIGhlYWRlcnMuc2V0Q29udGVudFR5cGUoJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZDtjaGFyc2V0PXV0Zi04JywgZmFsc2UpO1xuICAgICAgICByZXR1cm4gZGF0YS50b1N0cmluZygpO1xuICAgICAgfVxuXG4gICAgICBsZXQgaXNGaWxlTGlzdDtcblxuICAgICAgaWYgKGlzT2JqZWN0UGF5bG9hZCkge1xuICAgICAgICBjb25zdCBmb3JtU2VyaWFsaXplciA9IG93bih0aGlzLCAnZm9ybVNlcmlhbGl6ZXInKTtcbiAgICAgICAgaWYgKGNvbnRlbnRUeXBlLmluZGV4T2YoJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcpID4gLTEpIHtcbiAgICAgICAgICByZXR1cm4gdG9VUkxFbmNvZGVkRm9ybShkYXRhLCBmb3JtU2VyaWFsaXplcikudG9TdHJpbmcoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICAoaXNGaWxlTGlzdCA9IHV0aWxzLmlzRmlsZUxpc3QoZGF0YSkpIHx8XG4gICAgICAgICAgY29udGVudFR5cGUuaW5kZXhPZignbXVsdGlwYXJ0L2Zvcm0tZGF0YScpID4gLTFcbiAgICAgICAgKSB7XG4gICAgICAgICAgY29uc3QgZW52ID0gb3duKHRoaXMsICdlbnYnKTtcbiAgICAgICAgICBjb25zdCBfRm9ybURhdGEgPSBlbnYgJiYgZW52LkZvcm1EYXRhO1xuXG4gICAgICAgICAgcmV0dXJuIHRvRm9ybURhdGEoXG4gICAgICAgICAgICBpc0ZpbGVMaXN0ID8geyAnZmlsZXNbXSc6IGRhdGEgfSA6IGRhdGEsXG4gICAgICAgICAgICBfRm9ybURhdGEgJiYgbmV3IF9Gb3JtRGF0YSgpLFxuICAgICAgICAgICAgZm9ybVNlcmlhbGl6ZXJcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChpc09iamVjdFBheWxvYWQgfHwgaGFzSlNPTkNvbnRlbnRUeXBlKSB7XG4gICAgICAgIGhlYWRlcnMuc2V0Q29udGVudFR5cGUoJ2FwcGxpY2F0aW9uL2pzb24nLCBmYWxzZSk7XG4gICAgICAgIHJldHVybiBzdHJpbmdpZnlTYWZlbHkoZGF0YSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH0sXG4gIF0sXG5cbiAgdHJhbnNmb3JtUmVzcG9uc2U6IFtcbiAgICBmdW5jdGlvbiB0cmFuc2Zvcm1SZXNwb25zZShkYXRhKSB7XG4gICAgICBjb25zdCB0cmFuc2l0aW9uYWwgPSBvd24odGhpcywgJ3RyYW5zaXRpb25hbCcpIHx8IGRlZmF1bHRzLnRyYW5zaXRpb25hbDtcbiAgICAgIGNvbnN0IGZvcmNlZEpTT05QYXJzaW5nID0gdHJhbnNpdGlvbmFsICYmIHRyYW5zaXRpb25hbC5mb3JjZWRKU09OUGFyc2luZztcbiAgICAgIGNvbnN0IHJlc3BvbnNlVHlwZSA9IG93bih0aGlzLCAncmVzcG9uc2VUeXBlJyk7XG4gICAgICBjb25zdCBKU09OUmVxdWVzdGVkID0gcmVzcG9uc2VUeXBlID09PSAnanNvbic7XG5cbiAgICAgIGlmICh1dGlscy5pc1Jlc3BvbnNlKGRhdGEpIHx8IHV0aWxzLmlzUmVhZGFibGVTdHJlYW0oZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICB9XG5cbiAgICAgIGlmIChcbiAgICAgICAgZGF0YSAmJlxuICAgICAgICB1dGlscy5pc1N0cmluZyhkYXRhKSAmJlxuICAgICAgICAoKGZvcmNlZEpTT05QYXJzaW5nICYmICFyZXNwb25zZVR5cGUpIHx8IEpTT05SZXF1ZXN0ZWQpXG4gICAgICApIHtcbiAgICAgICAgY29uc3Qgc2lsZW50SlNPTlBhcnNpbmcgPSB0cmFuc2l0aW9uYWwgJiYgdHJhbnNpdGlvbmFsLnNpbGVudEpTT05QYXJzaW5nO1xuICAgICAgICBjb25zdCBzdHJpY3RKU09OUGFyc2luZyA9ICFzaWxlbnRKU09OUGFyc2luZyAmJiBKU09OUmVxdWVzdGVkO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoZGF0YSwgb3duKHRoaXMsICdwYXJzZVJldml2ZXInKSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBpZiAoc3RyaWN0SlNPTlBhcnNpbmcpIHtcbiAgICAgICAgICAgIGlmIChlLm5hbWUgPT09ICdTeW50YXhFcnJvcicpIHtcbiAgICAgICAgICAgICAgdGhyb3cgQXhpb3NFcnJvci5mcm9tKGUsIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSwgdGhpcywgbnVsbCwgb3duKHRoaXMsICdyZXNwb25zZScpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH0sXG4gIF0sXG5cbiAgLyoqXG4gICAqIEEgdGltZW91dCBpbiBtaWxsaXNlY29uZHMgdG8gYWJvcnQgYSByZXF1ZXN0LiBJZiBzZXQgdG8gMCAoZGVmYXVsdCkgYVxuICAgKiB0aW1lb3V0IGlzIG5vdCBjcmVhdGVkLlxuICAgKi9cbiAgdGltZW91dDogMCxcblxuICB4c3JmQ29va2llTmFtZTogJ1hTUkYtVE9LRU4nLFxuICB4c3JmSGVhZGVyTmFtZTogJ1gtWFNSRi1UT0tFTicsXG5cbiAgbWF4Q29udGVudExlbmd0aDogLTEsXG4gIG1heEJvZHlMZW5ndGg6IC0xLFxuXG4gIGVudjoge1xuICAgIEZvcm1EYXRhOiBwbGF0Zm9ybS5jbGFzc2VzLkZvcm1EYXRhLFxuICAgIEJsb2I6IHBsYXRmb3JtLmNsYXNzZXMuQmxvYixcbiAgfSxcblxuICB2YWxpZGF0ZVN0YXR1czogZnVuY3Rpb24gdmFsaWRhdGVTdGF0dXMoc3RhdHVzKSB7XG4gICAgcmV0dXJuIHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDwgMzAwO1xuICB9LFxuXG4gIGhlYWRlcnM6IHtcbiAgICBjb21tb246IHtcbiAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL2pzb24sIHRleHQvcGxhaW4sICovKicsXG4gICAgICAnQ29udGVudC1UeXBlJzogdW5kZWZpbmVkLFxuICAgIH0sXG4gIH0sXG59O1xuXG51dGlscy5mb3JFYWNoKG1ldGhvZExpc3QsIChtZXRob2QpID0+IHtcbiAgZGVmYXVsdHMuaGVhZGVyc1ttZXRob2RdID0ge307XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgZGVmYXVsdHM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgZGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvaW5kZXguanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5cbi8qKlxuICogVHJhbnNmb3JtIHRoZSBkYXRhIGZvciBhIHJlcXVlc3Qgb3IgYSByZXNwb25zZVxuICpcbiAqIEBwYXJhbSB7QXJyYXl8RnVuY3Rpb259IGZucyBBIHNpbmdsZSBmdW5jdGlvbiBvciBBcnJheSBvZiBmdW5jdGlvbnNcbiAqIEBwYXJhbSB7P09iamVjdH0gcmVzcG9uc2UgVGhlIHJlc3BvbnNlIG9iamVjdFxuICpcbiAqIEByZXR1cm5zIHsqfSBUaGUgcmVzdWx0aW5nIHRyYW5zZm9ybWVkIGRhdGFcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gdHJhbnNmb3JtRGF0YShmbnMsIHJlc3BvbnNlKSB7XG4gIGNvbnN0IGNvbmZpZyA9IHRoaXMgfHwgZGVmYXVsdHM7XG4gIGNvbnN0IGNvbnRleHQgPSByZXNwb25zZSB8fCBjb25maWc7XG4gIGNvbnN0IGhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuZnJvbShjb250ZXh0LmhlYWRlcnMpO1xuICBsZXQgZGF0YSA9IGNvbnRleHQuZGF0YTtcblxuICB1dGlscy5mb3JFYWNoKGZucywgZnVuY3Rpb24gdHJhbnNmb3JtKGZuKSB7XG4gICAgZGF0YSA9IGZuLmNhbGwoY29uZmlnLCBkYXRhLCBoZWFkZXJzLm5vcm1hbGl6ZSgpLCByZXNwb25zZSA/IHJlc3BvbnNlLnN0YXR1cyA6IHVuZGVmaW5lZCk7XG4gIH0pO1xuXG4gIGhlYWRlcnMubm9ybWFsaXplKCk7XG5cbiAgcmV0dXJuIGRhdGE7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzQ2FuY2VsKHZhbHVlKSB7XG4gIHJldHVybiAhISh2YWx1ZSAmJiB2YWx1ZS5fX0NBTkNFTF9fKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcblxuY2xhc3MgQ2FuY2VsZWRFcnJvciBleHRlbmRzIEF4aW9zRXJyb3Ige1xuICAvKipcbiAgICogQSBgQ2FuY2VsZWRFcnJvcmAgaXMgYW4gb2JqZWN0IHRoYXQgaXMgdGhyb3duIHdoZW4gYW4gb3BlcmF0aW9uIGlzIGNhbmNlbGVkLlxuICAgKlxuICAgKiBAcGFyYW0ge3N0cmluZz19IG1lc3NhZ2UgVGhlIG1lc3NhZ2UuXG4gICAqIEBwYXJhbSB7T2JqZWN0PX0gY29uZmlnIFRoZSBjb25maWcuXG4gICAqIEBwYXJhbSB7T2JqZWN0PX0gcmVxdWVzdCBUaGUgcmVxdWVzdC5cbiAgICpcbiAgICogQHJldHVybnMge0NhbmNlbGVkRXJyb3J9IFRoZSBjcmVhdGVkIGVycm9yLlxuICAgKi9cbiAgY29uc3RydWN0b3IobWVzc2FnZSwgY29uZmlnLCByZXF1ZXN0KSB7XG4gICAgc3VwZXIobWVzc2FnZSA9PSBudWxsID8gJ2NhbmNlbGVkJyA6IG1lc3NhZ2UsIEF4aW9zRXJyb3IuRVJSX0NBTkNFTEVELCBjb25maWcsIHJlcXVlc3QpO1xuICAgIHRoaXMubmFtZSA9ICdDYW5jZWxlZEVycm9yJztcbiAgICB0aGlzLl9fQ0FOQ0VMX18gPSB0cnVlO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IENhbmNlbGVkRXJyb3I7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4vQXhpb3NFcnJvci5qcyc7XG5cbi8qKlxuICogUmVzb2x2ZSBvciByZWplY3QgYSBQcm9taXNlIGJhc2VkIG9uIHJlc3BvbnNlIHN0YXR1cy5cbiAqXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSByZXNvbHZlIEEgZnVuY3Rpb24gdGhhdCByZXNvbHZlcyB0aGUgcHJvbWlzZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHJlamVjdCBBIGZ1bmN0aW9uIHRoYXQgcmVqZWN0cyB0aGUgcHJvbWlzZS5cbiAqIEBwYXJhbSB7b2JqZWN0fSByZXNwb25zZSBUaGUgcmVzcG9uc2UuXG4gKlxuICogQHJldHVybnMge29iamVjdH0gVGhlIHJlc3BvbnNlLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCByZXNwb25zZSkge1xuICBjb25zdCB2YWxpZGF0ZVN0YXR1cyA9IHJlc3BvbnNlLmNvbmZpZy52YWxpZGF0ZVN0YXR1cztcbiAgaWYgKCFyZXNwb25zZS5zdGF0dXMgfHwgIXZhbGlkYXRlU3RhdHVzIHx8IHZhbGlkYXRlU3RhdHVzKHJlc3BvbnNlLnN0YXR1cykpIHtcbiAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgfSBlbHNlIHtcbiAgICByZWplY3QobmV3IEF4aW9zRXJyb3IoXG4gICAgICAnUmVxdWVzdCBmYWlsZWQgd2l0aCBzdGF0dXMgY29kZSAnICsgcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgcmVzcG9uc2Uuc3RhdHVzID49IDQwMCAmJiByZXNwb25zZS5zdGF0dXMgPCA1MDAgPyBBeGlvc0Vycm9yLkVSUl9CQURfUkVRVUVTVCA6IEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSxcbiAgICAgIHJlc3BvbnNlLmNvbmZpZyxcbiAgICAgIHJlc3BvbnNlLnJlcXVlc3QsXG4gICAgICByZXNwb25zZVxuICAgICkpO1xuICB9XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmNvbnN0IHVybFBhcnNlckNvbnRyb2xDaGFyYWN0ZXJzID0gL1tcXHRcXG5cXHJdL2c7XG5cbi8qKlxuICogTWF0Y2ggV0hBVFdHIFVSTCBwcmVwcm9jZXNzaW5nIGJlZm9yZSBjaGVja2luZyBhIFVSTCdzIHByb3RvY29sLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmxcbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrKHVybCkge1xuICBpZiAodHlwZW9mIHVybCAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gdXJsO1xuICB9XG5cbiAgbGV0IHN0YXJ0ID0gMDtcblxuICB3aGlsZSAoc3RhcnQgPCB1cmwubGVuZ3RoICYmIHVybC5jaGFyQ29kZUF0KHN0YXJ0KSA8PSAweDIwKSB7XG4gICAgc3RhcnQrKztcbiAgfVxuXG4gIHJldHVybiB1cmwuc2xpY2Uoc3RhcnQpLnJlcGxhY2UodXJsUGFyc2VyQ29udHJvbENoYXJhY3RlcnMsICcnKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gcGFyc2VQcm90b2NvbCh1cmwpIHtcbiAgY29uc3QgbWF0Y2ggPSAvXihbLStcXHddezEsMjV9KTooPzpcXC9cXC8pPy8uZXhlYyh1cmwpO1xuICByZXR1cm4gKG1hdGNoICYmIG1hdGNoWzFdLnRvTG93ZXJDYXNlKCkpIHx8ICcnO1xufVxuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5cbmNvbnN0IGRlY29kZUNvb2tpZVZhbHVlID0gKHZhbHVlKSA9PiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbn07XG5cbmV4cG9ydCBkZWZhdWx0IHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlckVudlxuICA/IC8vIFN0YW5kYXJkIGJyb3dzZXIgZW52cyBzdXBwb3J0IGRvY3VtZW50LmNvb2tpZVxuICAgIHtcbiAgICAgIHdyaXRlKG5hbWUsIHZhbHVlLCBleHBpcmVzLCBwYXRoLCBkb21haW4sIHNlY3VyZSwgc2FtZVNpdGUpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybjtcblxuICAgICAgICBjb25zdCBjb29raWUgPSBbYCR7bmFtZX09JHtlbmNvZGVVUklDb21wb25lbnQodmFsdWUpfWBdO1xuXG4gICAgICAgIGlmICh1dGlscy5pc051bWJlcihleHBpcmVzKSkge1xuICAgICAgICAgIGNvb2tpZS5wdXNoKGBleHBpcmVzPSR7bmV3IERhdGUoZXhwaXJlcykudG9VVENTdHJpbmcoKX1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodXRpbHMuaXNTdHJpbmcocGF0aCkpIHtcbiAgICAgICAgICBjb29raWUucHVzaChgcGF0aD0ke3BhdGh9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKGRvbWFpbikpIHtcbiAgICAgICAgICBjb29raWUucHVzaChgZG9tYWluPSR7ZG9tYWlufWApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZWN1cmUgPT09IHRydWUpIHtcbiAgICAgICAgICBjb29raWUucHVzaCgnc2VjdXJlJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKHNhbWVTaXRlKSkge1xuICAgICAgICAgIGNvb2tpZS5wdXNoKGBTYW1lU2l0ZT0ke3NhbWVTaXRlfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gY29va2llLmpvaW4oJzsgJyk7XG4gICAgICB9LFxuXG4gICAgICByZWFkKG5hbWUpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBjb29raWVTdHJpbmcgPSBkb2N1bWVudC5jb29raWU7XG4gICAgICAgIGlmICghY29va2llU3RyaW5nKSByZXR1cm4gbnVsbDtcbiAgICAgICAgLy8gTWF0Y2ggbmFtZT12YWx1ZSBieSBzcGxpdHRpbmcgb24gdGhlIHNlbWljb2xvbiBzZXBhcmF0b3IgaW5zdGVhZCBvZiBidWlsZGluZyBhXG4gICAgICAgIC8vIFJlZ0V4cCBmcm9tIGBuYW1lYCDigJQgaW50ZXJwb2xhdGluZyBhbiB1bmVzY2FwZWQgc3RyaW5nIGludG8gYSBSZWdFeHAgd291bGQgbGV0XG4gICAgICAgIC8vIG1ldGFjaGFyYWN0ZXJzIChlLmcuIGAuKz9gIGluIGFuIGF0dGFja2VyLWluZmx1ZW5jZWQgY29va2llIG5hbWUpIGNhdXNlIFJlRG9TIG9yXG4gICAgICAgIC8vIG1hdGNoIHRoZSB3cm9uZyBjb29raWUuIEJyb3dzZXJzIG1heSBzZXJpYWxpemUgY29va2llIHBhaXJzIGFzIGVpdGhlciBcIjtcIiBvclxuICAgICAgICAvLyBcIjsgXCIsIHNvIGlnbm9yZSBvcHRpb25hbCB3aGl0ZXNwYWNlIGJlZm9yZSBlYWNoIGNvb2tpZSBuYW1lLlxuICAgICAgICBjb25zdCBjb29raWVzID0gY29va2llU3RyaW5nLnNwbGl0KCc7Jyk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY29va2llcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGNvb2tpZSA9IGNvb2tpZXNbaV0ucmVwbGFjZSgvXlxccysvLCAnJyk7XG4gICAgICAgICAgY29uc3QgZXEgPSBjb29raWUuaW5kZXhPZignPScpO1xuICAgICAgICAgIGlmIChlcSAhPT0gLTEgJiYgY29va2llLnNsaWNlKDAsIGVxKSA9PT0gbmFtZSkge1xuICAgICAgICAgICAgcmV0dXJuIGRlY29kZUNvb2tpZVZhbHVlKGNvb2tpZS5zbGljZShlcSArIDEpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9LFxuXG4gICAgICBhc3luYyByZWFkQXN5bmMobmFtZSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHN0b3JlID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmNvb2tpZVN0b3JlO1xuICAgICAgICAgIGlmIChzdG9yZSAmJiB1dGlscy5pc0Z1bmN0aW9uKHN0b3JlLmdldCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvb2tpZSA9IGF3YWl0IHN0b3JlLmdldChuYW1lKTtcbiAgICAgICAgICAgIC8vIEJvdGggQVBJcyBleHBvc2Ugc3RvcmVkIGJ5dGVzOyBwcmVzZXJ2ZSBBeGlvcydzIGV4aXN0aW5nIFVSSSBkZWNvZGluZy5cbiAgICAgICAgICAgIHJldHVybiBjb29raWUgPyBkZWNvZGVDb29raWVWYWx1ZShjb29raWUudmFsdWUpIDogbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBSZXN0cmljdGVkIG9yIHVuYXZhaWxhYmxlIHN0b3JhZ2UgcmV0YWlucyB0aGUgc3luY2hyb25vdXMgZmFsbGJhY2suXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy5yZWFkKG5hbWUpO1xuICAgICAgfSxcblxuICAgICAgcmVtb3ZlKG5hbWUpIHtcbiAgICAgICAgdGhpcy53cml0ZShuYW1lLCAnJywgRGF0ZS5ub3coKSAtIDg2NDAwMDAwLCAnLycpO1xuICAgICAgfSxcbiAgICB9XG4gIDogLy8gTm9uLXN0YW5kYXJkIGJyb3dzZXIgZW52ICh3ZWIgd29ya2VycywgcmVhY3QtbmF0aXZlKSBsYWNrIG5lZWRlZCBzdXBwb3J0LlxuICAgIHtcbiAgICAgIHdyaXRlKCkge30sXG4gICAgICByZWFkKCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0sXG4gICAgICBhc3luYyByZWFkQXN5bmMoKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfSxcbiAgICAgIHJlbW92ZSgpIHt9LFxuICAgIH07XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogQ2FsY3VsYXRlIGRhdGEgbWF4UmF0ZVxuICogQHBhcmFtIHtOdW1iZXJ9IFtzYW1wbGVzQ291bnQ9IDEwXVxuICogQHBhcmFtIHtOdW1iZXJ9IFttaW49IDEwMDBdXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259XG4gKi9cbmZ1bmN0aW9uIHNwZWVkb21ldGVyKHNhbXBsZXNDb3VudCwgbWluKSB7XG4gIHNhbXBsZXNDb3VudCA9IHNhbXBsZXNDb3VudCB8fCAxMDtcbiAgY29uc3QgYnl0ZXMgPSBuZXcgQXJyYXkoc2FtcGxlc0NvdW50KTtcbiAgY29uc3QgdGltZXN0YW1wcyA9IG5ldyBBcnJheShzYW1wbGVzQ291bnQpO1xuICBsZXQgaGVhZCA9IDA7XG4gIGxldCB0YWlsID0gMDtcbiAgbGV0IGZpcnN0U2FtcGxlVFM7XG5cbiAgbWluID0gbWluICE9PSB1bmRlZmluZWQgPyBtaW4gOiAxMDAwO1xuXG4gIHJldHVybiBmdW5jdGlvbiBwdXNoKGNodW5rTGVuZ3RoKSB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcblxuICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IHRpbWVzdGFtcHNbdGFpbF07XG5cbiAgICBpZiAoIWZpcnN0U2FtcGxlVFMpIHtcbiAgICAgIGZpcnN0U2FtcGxlVFMgPSBub3c7XG4gICAgfVxuXG4gICAgYnl0ZXNbaGVhZF0gPSBjaHVua0xlbmd0aDtcbiAgICB0aW1lc3RhbXBzW2hlYWRdID0gbm93O1xuXG4gICAgbGV0IGkgPSB0YWlsO1xuICAgIGxldCBieXRlc0NvdW50ID0gMDtcblxuICAgIHdoaWxlIChpICE9PSBoZWFkKSB7XG4gICAgICBieXRlc0NvdW50ICs9IGJ5dGVzW2krK107XG4gICAgICBpID0gaSAlIHNhbXBsZXNDb3VudDtcbiAgICB9XG5cbiAgICBoZWFkID0gKGhlYWQgKyAxKSAlIHNhbXBsZXNDb3VudDtcblxuICAgIGlmIChoZWFkID09PSB0YWlsKSB7XG4gICAgICB0YWlsID0gKHRhaWwgKyAxKSAlIHNhbXBsZXNDb3VudDtcbiAgICB9XG5cbiAgICBpZiAobm93IC0gZmlyc3RTYW1wbGVUUyA8IG1pbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHBhc3NlZCA9IHN0YXJ0ZWRBdCAmJiBub3cgLSBzdGFydGVkQXQ7XG5cbiAgICByZXR1cm4gcGFzc2VkID8gTWF0aC5yb3VuZCgoYnl0ZXNDb3VudCAqIDEwMDApIC8gcGFzc2VkKSA6IHVuZGVmaW5lZDtcbiAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgc3BlZWRvbWV0ZXI7XG4iLCIvKipcbiAqIFRocm90dGxlIGRlY29yYXRvclxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm5cbiAqIEBwYXJhbSB7TnVtYmVyfSBmcmVxXG4gKiBAcmV0dXJuIHtBcnJheTxGdW5jdGlvbj59XG4gKi9cbmZ1bmN0aW9uIHRocm90dGxlKGZuLCBmcmVxKSB7XG4gIGxldCB0aW1lc3RhbXAgPSAwO1xuICBsZXQgdGhyZXNob2xkID0gMTAwMCAvIGZyZXE7XG4gIGxldCBsYXN0QXJncztcbiAgbGV0IHRpbWVyO1xuXG4gIGNvbnN0IGludm9rZSA9IChhcmdzLCBub3cgPSBEYXRlLm5vdygpKSA9PiB7XG4gICAgdGltZXN0YW1wID0gbm93O1xuICAgIGxhc3RBcmdzID0gbnVsbDtcbiAgICBpZiAodGltZXIpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICB0aW1lciA9IG51bGw7XG4gICAgfVxuICAgIGZuKC4uLmFyZ3MpO1xuICB9O1xuXG4gIGNvbnN0IHRocm90dGxlZCA9ICguLi5hcmdzKSA9PiB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCBwYXNzZWQgPSBub3cgLSB0aW1lc3RhbXA7XG4gICAgaWYgKHBhc3NlZCA+PSB0aHJlc2hvbGQpIHtcbiAgICAgIGludm9rZShhcmdzLCBub3cpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsYXN0QXJncyA9IGFyZ3M7XG4gICAgICBpZiAoIXRpbWVyKSB7XG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdGltZXIgPSBudWxsO1xuICAgICAgICAgIGludm9rZShsYXN0QXJncyk7XG4gICAgICAgIH0sIHRocmVzaG9sZCAtIHBhc3NlZCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGZsdXNoID0gKCkgPT4gbGFzdEFyZ3MgJiYgaW52b2tlKGxhc3RBcmdzKTtcbiAgY29uc3QgZmx1c2hXaXRoID0gKC4uLmFyZ3MpID0+IGludm9rZShhcmdzKTtcblxuICByZXR1cm4gW3Rocm90dGxlZCwgZmx1c2gsIGZsdXNoV2l0aF07XG59XG5cbmV4cG9ydCBkZWZhdWx0IHRocm90dGxlO1xuIiwiaW1wb3J0IHNwZWVkb21ldGVyIGZyb20gJy4vc3BlZWRvbWV0ZXIuanMnO1xuaW1wb3J0IHRocm90dGxlIGZyb20gJy4vdGhyb3R0bGUuanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuZXhwb3J0IGNvbnN0IHByb2dyZXNzRXZlbnRSZWR1Y2VyID0gKGxpc3RlbmVyLCBpc0Rvd25sb2FkU3RyZWFtLCBmcmVxID0gMykgPT4ge1xuICBsZXQgYnl0ZXNOb3RpZmllZCA9IDA7XG4gIGNvbnN0IF9zcGVlZG9tZXRlciA9IHNwZWVkb21ldGVyKDUwLCAyNTApO1xuXG4gIHJldHVybiB0aHJvdHRsZSgoZSkgPT4ge1xuICAgIGlmICghZSB8fCAhdXRpbHMuaXNOdW1iZXIoZS5sb2FkZWQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJhd0xvYWRlZCA9IGUubG9hZGVkO1xuICAgIGNvbnN0IHRvdGFsID0gZS5sZW5ndGhDb21wdXRhYmxlID8gZS50b3RhbCA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBsb2FkZWQgPSBNYXRoLm1heCgwLCB0b3RhbCAhPSBudWxsID8gTWF0aC5taW4ocmF3TG9hZGVkLCB0b3RhbCkgOiByYXdMb2FkZWQpO1xuICAgIGNvbnN0IHByb2dyZXNzQnl0ZXMgPSBNYXRoLm1heCgwLCBsb2FkZWQgLSBieXRlc05vdGlmaWVkKTtcbiAgICBjb25zdCByYXRlID0gX3NwZWVkb21ldGVyKHByb2dyZXNzQnl0ZXMpO1xuXG4gICAgYnl0ZXNOb3RpZmllZCA9IE1hdGgubWF4KGJ5dGVzTm90aWZpZWQsIGxvYWRlZCk7XG5cbiAgICBjb25zdCBkYXRhID0ge1xuICAgICAgbG9hZGVkLFxuICAgICAgdG90YWwsXG4gICAgICBwcm9ncmVzczogdG90YWwgPyBsb2FkZWQgLyB0b3RhbCA6IHVuZGVmaW5lZCxcbiAgICAgIGJ5dGVzOiBwcm9ncmVzc0J5dGVzLFxuICAgICAgcmF0ZTogcmF0ZSA/IHJhdGUgOiB1bmRlZmluZWQsXG4gICAgICBlc3RpbWF0ZWQ6IHJhdGUgJiYgdG90YWwgPyAodG90YWwgLSBsb2FkZWQpIC8gcmF0ZSA6IHVuZGVmaW5lZCxcbiAgICAgIGV2ZW50OiBlLFxuICAgICAgbGVuZ3RoQ29tcHV0YWJsZTogdG90YWwgIT0gbnVsbCxcbiAgICAgIFtpc0Rvd25sb2FkU3RyZWFtID8gJ2Rvd25sb2FkJyA6ICd1cGxvYWQnXTogdHJ1ZSxcbiAgICB9O1xuXG4gICAgbGlzdGVuZXIoZGF0YSk7XG4gIH0sIGZyZXEpO1xufTtcblxuZXhwb3J0IGNvbnN0IHByb2dyZXNzRXZlbnREZWNvcmF0b3IgPSAodG90YWwsIHRocm90dGxlZCkgPT4ge1xuICBjb25zdCBsZW5ndGhDb21wdXRhYmxlID0gdG90YWwgIT0gbnVsbDtcblxuICByZXR1cm4gW1xuICAgIChsb2FkZWQpID0+XG4gICAgICB0aHJvdHRsZWRbMF0oe1xuICAgICAgICBsZW5ndGhDb21wdXRhYmxlLFxuICAgICAgICB0b3RhbCxcbiAgICAgICAgbG9hZGVkLFxuICAgICAgfSksXG4gICAgdGhyb3R0bGVkWzFdLFxuICBdO1xufTtcblxuZXhwb3J0IGNvbnN0IGFzeW5jRGVjb3JhdG9yID1cbiAgKGZuLCBzY2hlZHVsZXIgPSB1dGlscy5hc2FwKSA9PlxuICAoLi4uYXJncykgPT5cbiAgICBzY2hlZHVsZXIoKCkgPT4gZm4oLi4uYXJncykpO1xuIiwiaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcblxuZXhwb3J0IGRlZmF1bHQgcGxhdGZvcm0uaGFzU3RhbmRhcmRCcm93c2VyRW52XG4gID8gKChvcmlnaW4pID0+ICh1cmwpID0+IHtcbiAgICAgIHVybCA9IG5ldyBVUkwodXJsLCBkb2N1bWVudC5iYXNlVVJJIHx8IHBsYXRmb3JtLm9yaWdpbik7XG5cbiAgICAgIHJldHVybiAoXG4gICAgICAgIG9yaWdpbi5wcm90b2NvbCA9PT0gdXJsLnByb3RvY29sICYmIG9yaWdpbi5ob3N0ID09PSB1cmwuaG9zdCAmJiBvcmlnaW4ucG9ydCA9PT0gdXJsLnBvcnRcbiAgICAgICk7XG4gICAgfSkobmV3IFVSTChwbGF0Zm9ybS5vcmlnaW4pKVxuICA6ICgpID0+IHRydWU7XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSBzcGVjaWZpZWQgVVJMIGlzIGFic29sdXRlXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHVybCBUaGUgVVJMIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgc3BlY2lmaWVkIFVSTCBpcyBhYnNvbHV0ZSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzQWJzb2x1dGVVUkwodXJsKSB7XG4gIC8vIEEgVVJMIGlzIGNvbnNpZGVyZWQgYWJzb2x1dGUgaWYgaXQgYmVnaW5zIHdpdGggXCI8c2NoZW1lPjovL1wiIG9yIFwiLy9cIiAocHJvdG9jb2wtcmVsYXRpdmUgVVJMKS5cbiAgLy8gUkZDIDM5ODYgZGVmaW5lcyBzY2hlbWUgbmFtZSBhcyBhIHNlcXVlbmNlIG9mIGNoYXJhY3RlcnMgYmVnaW5uaW5nIHdpdGggYSBsZXR0ZXIgYW5kIGZvbGxvd2VkXG4gIC8vIGJ5IGFueSBjb21iaW5hdGlvbiBvZiBsZXR0ZXJzLCBkaWdpdHMsIHBsdXMsIHBlcmlvZCwgb3IgaHlwaGVuLlxuICBpZiAodHlwZW9mIHVybCAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICByZXR1cm4gL14oW2Etel1bYS16XFxkK1xcLS5dKjopP1xcL1xcLy9pLnRlc3QodXJsKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IFVSTCBieSBjb21iaW5pbmcgdGhlIHNwZWNpZmllZCBVUkxzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkwgVGhlIGJhc2UgVVJMXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVsYXRpdmVVUkwgVGhlIHJlbGF0aXZlIFVSTFxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBjb21iaW5lZCBVUkxcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY29tYmluZVVSTHMoYmFzZVVSTCwgcmVsYXRpdmVVUkwpIHtcbiAgaWYgKCFyZWxhdGl2ZVVSTCkge1xuICAgIHJldHVybiBiYXNlVVJMO1xuICB9XG5cbiAgbGV0IGVuZCA9IGJhc2VVUkwubGVuZ3RoO1xuXG4gIHdoaWxlIChlbmQgPiAwICYmIGJhc2VVUkwuY2hhckNvZGVBdChlbmQgLSAxKSA9PT0gNDcpIHtcbiAgICBlbmQtLTtcbiAgfVxuXG4gIHJldHVybiBiYXNlVVJMLnNsaWNlKDAsIGVuZCkgKyAnLycgKyByZWxhdGl2ZVVSTC5yZXBsYWNlKC9eXFwvKy8sICcnKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zRXJyb3IsIHsgUkVEQUNURUQgfSBmcm9tICcuL0F4aW9zRXJyb3IuanMnO1xuaW1wb3J0IGlzQWJzb2x1dGVVUkwgZnJvbSAnLi4vaGVscGVycy9pc0Fic29sdXRlVVJMLmpzJztcbmltcG9ydCBjb21iaW5lVVJMcyBmcm9tICcuLi9oZWxwZXJzL2NvbWJpbmVVUkxzLmpzJztcbmltcG9ydCBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrIGZyb20gJy4uL2hlbHBlcnMvbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjay5qcyc7XG5cbmNvbnN0IG1hbGZvcm1lZEh0dHBQcm90b2NvbCA9IC9eaHR0cHM/Oig/IVxcL1xcLykvaTtcblxuLy8gUmVkYWN0IHRoZSBwYXJ0cyBvZiBhIFVSTCB0aGF0IGNhbiBjYXJyeSBzZWNyZXRzIGJlZm9yZSBpdCBpcyBlbWJlZGRlZCBpbiBhblxuLy8gZXJyb3IgbWVzc2FnZS4gQXhpb3NFcnJvci50b0pTT04oKSBzZXJpYWxpemVzIGBtZXNzYWdlYCB2ZXJiYXRpbSBhbmQgZXJyb3JzXG4vLyBhcmUgY29tbW9ubHkgbG9nZ2VkLCB3aGlsZSB0aGUgb3B0LWluIGBjb25maWcucmVkYWN0YCBtb2RlbCBvbmx5IGNsZWFuc1xuLy8gY29uZmlnIGtleXMg4oCUIGl0IGNhbm5vdCByZWFjaCB0aGUgbWVzc2FnZS4gUmVkYWN0IG9ubHkgdGhlIGdlbnVpbmVseVxuLy8gc2Vuc2l0aXZlIHN1YnN0cmluZ3Mg4oCUIHVzZXJpbmZvIChjcmVkZW50aWFscyksIHF1ZXJ5IHBhcmFtZXRlciB2YWx1ZXMgYW5kXG4vLyBmcmFnbWVudCBjb250ZW50cyDigJQgd2l0aCB0aGUgc2FtZSBSRURBQ1RFRCBtYXJrZXIgdGhlIGNvbmZpZyByZWRhY3Rpb24gdXNlcyxcbi8vIHdoaWxlIGtlZXBpbmcgdGhlIHNjaGVtZSwgaG9zdCwgcGF0aCBhbmQgcGFyYW1ldGVyIG5hbWVzIHNvIHRoZSBvZmZlbmRpbmdcbi8vIHJlcXVlc3Qgc3RheXMgYWNjdXJhdGVseSBpZGVudGlmaWFibGUuXG5mdW5jdGlvbiByZWRhY3RGcmFnbWVudChmcmFnbWVudCkge1xuICBpZiAoIWZyYWdtZW50KSB7XG4gICAgcmV0dXJuIGZyYWdtZW50O1xuICB9XG5cbiAgcmV0dXJuIGZyYWdtZW50LnJlcGxhY2UoLyhefCYpKFtePSZdKj0pP1teJl0rL2csIChtYXRjaCwgc2VwYXJhdG9yLCBwYXJhbWV0ZXJOYW1lID0gJycpID0+IHtcbiAgICByZXR1cm4gYCR7c2VwYXJhdG9yfSR7cGFyYW1ldGVyTmFtZX0ke1JFREFDVEVEfWA7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZWRhY3RTZW5zaXRpdmVVUkxQYXJ0cyh1cmwpIHtcbiAgY29uc3QgcmVkYWN0ZWRVUkwgPSB1cmwucmVwbGFjZSgvXihodHRwcz86XFwvezAsMn0pW14vPyNdKkAvaSwgYCQxJHtSRURBQ1RFRH1AYCk7XG4gIGNvbnN0IGZyYWdtZW50SW5kZXggPSByZWRhY3RlZFVSTC5pbmRleE9mKCcjJyk7XG4gIGNvbnN0IHVybFdpdGhvdXRGcmFnbWVudCA9XG4gICAgZnJhZ21lbnRJbmRleCA9PT0gLTEgPyByZWRhY3RlZFVSTCA6IHJlZGFjdGVkVVJMLnNsaWNlKDAsIGZyYWdtZW50SW5kZXgpO1xuICBjb25zdCByZWRhY3RlZFVSTFdpdGhvdXRGcmFnbWVudCA9IHVybFdpdGhvdXRGcmFnbWVudC5yZXBsYWNlKFxuICAgIC8oWz8mXVtePSYjXSo9KVteJiNdKi9nLFxuICAgIGAkMSR7UkVEQUNURUR9YFxuICApO1xuXG4gIGlmIChmcmFnbWVudEluZGV4ID09PSAtMSkge1xuICAgIHJldHVybiByZWRhY3RlZFVSTFdpdGhvdXRGcmFnbWVudDtcbiAgfVxuXG4gIHJldHVybiBgJHtyZWRhY3RlZFVSTFdpdGhvdXRGcmFnbWVudH0jJHtyZWRhY3RGcmFnbWVudChyZWRhY3RlZFVSTC5zbGljZShmcmFnbWVudEluZGV4ICsgMSkpfWA7XG59XG5cbmZ1bmN0aW9uIGFzc2VydFZhbGlkSHR0cFByb3RvY29sVVJMKHVybCwgY29uZmlnKSB7XG4gIGlmICh0eXBlb2YgdXJsID09PSAnc3RyaW5nJykge1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRVUkwgPSBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrKHVybCk7XG4gICAgaWYgKG1hbGZvcm1lZEh0dHBQcm90b2NvbC50ZXN0KG5vcm1hbGl6ZWRVUkwpKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgYEludmFsaWQgVVJMICR7SlNPTi5zdHJpbmdpZnkocmVkYWN0U2Vuc2l0aXZlVVJMUGFydHMobm9ybWFsaXplZFVSTCkpfTogbWlzc2luZyBcIi8vXCIgYWZ0ZXIgcHJvdG9jb2xgLFxuICAgICAgICBBeGlvc0Vycm9yLkVSUl9JTlZBTElEX1VSTCxcbiAgICAgICAgY29uZmlnXG4gICAgICApO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgVVJMIGJ5IGNvbWJpbmluZyB0aGUgYmFzZVVSTCB3aXRoIHRoZSByZXF1ZXN0ZWRVUkwsXG4gKiBvbmx5IHdoZW4gdGhlIHJlcXVlc3RlZFVSTCBpcyBub3QgYWxyZWFkeSBhbiBhYnNvbHV0ZSBVUkwuXG4gKiBJZiB0aGUgcmVxdWVzdFVSTCBpcyBhYnNvbHV0ZSwgdGhpcyBmdW5jdGlvbiByZXR1cm5zIHRoZSByZXF1ZXN0ZWRVUkwgdW50b3VjaGVkLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYXNlVVJMIFRoZSBiYXNlIFVSTFxuICogQHBhcmFtIHtzdHJpbmd9IHJlcXVlc3RlZFVSTCBBYnNvbHV0ZSBvciByZWxhdGl2ZSBVUkwgdG8gY29tYmluZVxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBjb21iaW5lZCBmdWxsIHBhdGhcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYnVpbGRGdWxsUGF0aChiYXNlVVJMLCByZXF1ZXN0ZWRVUkwsIGFsbG93QWJzb2x1dGVVcmxzLCBjb25maWcpIHtcbiAgYXNzZXJ0VmFsaWRIdHRwUHJvdG9jb2xVUkwocmVxdWVzdGVkVVJMLCBjb25maWcpO1xuICBsZXQgaXNSZWxhdGl2ZVVybCA9ICFpc0Fic29sdXRlVVJMKHJlcXVlc3RlZFVSTCk7XG4gIGlmIChiYXNlVVJMICYmIChpc1JlbGF0aXZlVXJsIHx8IGFsbG93QWJzb2x1dGVVcmxzID09PSBmYWxzZSkpIHtcbiAgICBhc3NlcnRWYWxpZEh0dHBQcm90b2NvbFVSTChiYXNlVVJMLCBjb25maWcpO1xuICAgIHJldHVybiBjb21iaW5lVVJMcyhiYXNlVVJMLCByZXF1ZXN0ZWRVUkwpO1xuICB9XG4gIHJldHVybiByZXF1ZXN0ZWRVUkw7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuL0F4aW9zRXJyb3IuanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBhc3NlcnRQYXJhbXNBY3ljbGljKHBhcmFtcykge1xuICBjb25zdCBwZW5kaW5nID0gW3sgdmFsdWU6IHBhcmFtcyB9XTtcbiAgY29uc3QgYWN0aXZlID0gbmV3IFdlYWtTZXQoKTtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0KCk7XG5cbiAgd2hpbGUgKHBlbmRpbmcubGVuZ3RoKSB7XG4gICAgY29uc3QgeyB2YWx1ZSwgZG9uZSB9ID0gcGVuZGluZy5wb3AoKTtcbiAgICBpZiAoIXV0aWxzLmlzUGxhaW5PYmplY3QodmFsdWUpICYmICF1dGlscy5pc0FycmF5KHZhbHVlKSkgY29udGludWU7XG4gICAgaWYgKGRvbmUpIHtcbiAgICAgIGFjdGl2ZS5kZWxldGUodmFsdWUpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChhY3RpdmUuaGFzKHZhbHVlKSkge1xuICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICdDaXJjdWxhciByZWZlcmVuY2UgZGV0ZWN0ZWQgaW4gcGFyYW1zJyxcbiAgICAgICAgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTl9WQUxVRVxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHZpc2l0ZWQuaGFzKHZhbHVlKSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQodmFsdWUpO1xuICAgIGFjdGl2ZS5hZGQodmFsdWUpO1xuICAgIHBlbmRpbmcucHVzaCh7IHZhbHVlLCBkb25lOiB0cnVlIH0pO1xuXG4gICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHZhbHVlKTtcbiAgICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyAmJiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKSB7XG4gICAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHZhbHVlKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgY29uc3QgZGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodmFsdWUsIGtleSk7XG4gICAgICAgIGlmIChkZXNjcmlwdG9yICYmIGRlc2NyaXB0b3IuZW51bWVyYWJsZSkga2V5cy5wdXNoKGtleSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gU2hhbGxvdyBhcnJheSBlbGVtZW50cyByZXRhaW4gZmllbGRzIGZpbHRlcmVkIGR1cmluZyBwbGFpbi1vYmplY3QgbWVyZ2VzLlxuICAgIC8vIEluc3BlY3QgcmVzZXJ2ZWQgZGF0YSBwcm9wZXJ0aWVzIHdpdGhvdXQgZXZhbHVhdGluZyB0aGVpciBhY2Nlc3NvcnMuXG4gICAga2V5cy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGlmIChrZXkgPT09ICdfX3Byb3RvX18nIHx8IGtleSA9PT0gJ2NvbnN0cnVjdG9yJyB8fCBrZXkgPT09ICdwcm90b3R5cGUnKSB7XG4gICAgICAgIGNvbnN0IGRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHZhbHVlLCBrZXkpO1xuICAgICAgICBpZiAoZGVzY3JpcHRvciAmJiB1dGlscy5oYXNPd25Qcm9wKGRlc2NyaXB0b3IsICd2YWx1ZScpKSB7XG4gICAgICAgICAgcGVuZGluZy5wdXNoKHsgdmFsdWU6IGRlc2NyaXB0b3IudmFsdWUgfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBlbmRpbmcucHVzaCh7IHZhbHVlOiB2YWx1ZVtrZXldIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4vQXhpb3NIZWFkZXJzLmpzJztcbmltcG9ydCBhc3NlcnRQYXJhbXNBY3ljbGljIGZyb20gJy4vYXNzZXJ0UGFyYW1zQWN5Y2xpYy5qcyc7XG5cbmNvbnN0IGhlYWRlcnNUb09iamVjdCA9ICh0aGluZykgPT4gKHRoaW5nIGluc3RhbmNlb2YgQXhpb3NIZWFkZXJzID8geyAuLi50aGluZyB9IDogdGhpbmcpO1xuXG5jb25zdCBvd25FbnVtZXJhYmxlS2V5cyA9ICh0aGluZykgPT4ge1xuICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyAmJiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHRoaW5nKS5jb25jYXQoXG4gICAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHRoaW5nKS5maWx0ZXIoKHN5bWJvbCkgPT4ge1xuICAgICAgICBjb25zdCBkZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0aGluZywgc3ltYm9sKTtcbiAgICAgICAgcmV0dXJuIGRlc2NyaXB0b3IgJiYgZGVzY3JpcHRvci5lbnVtZXJhYmxlO1xuICAgICAgfSlcbiAgICApO1xuICB9XG4gIHJldHVybiBPYmplY3Qua2V5cyh0aGluZyk7XG59O1xuXG4vLyBDb3B5IHBhcmFtcyB3aXRob3V0IHJlY3Vyc2l2ZSBtZXJnZXMgc28gdGhlIHNlcmlhbGl6ZXIgcmVtYWlucyByZXNwb25zaWJsZVxuLy8gZm9yIGl0cyBkZXB0aCBwb2xpY3kuIE9ubHkgdmlzaXQgZGVmYXVsdHMgdGhhdCBjb250cmlidXRlIHRvIHRoZSByZXN1bHQuXG5mdW5jdGlvbiBtZXJnZVBhcmFtcyhhLCBiKSB7XG4gIGNvbnN0IHBlbmRpbmcgPSBbXTtcbiAgY29uc3QgY29waWVzID0gbmV3IFdlYWtNYXAoKTtcbiAgY29uc3QgZW1wdHkgPSB7fTtcblxuICBmdW5jdGlvbiBjb3B5KHRhcmdldCwgc291cmNlKSB7XG4gICAgaWYgKCF1dGlscy5pc1BsYWluT2JqZWN0KHNvdXJjZSkpIHtcbiAgICAgIHJldHVybiB1dGlscy5pc0FycmF5KHNvdXJjZSkgPyBzb3VyY2Uuc2xpY2UoKSA6IHNvdXJjZTtcbiAgICB9XG5cbiAgICBjb25zdCBiYXNlID0gdXRpbHMuaXNQbGFpbk9iamVjdCh0YXJnZXQpID8gdGFyZ2V0IDogZW1wdHk7XG4gICAgbGV0IGJhc2VzID0gY29waWVzLmdldChzb3VyY2UpO1xuICAgIGlmICghYmFzZXMpIHtcbiAgICAgIGJhc2VzID0gbmV3IFdlYWtNYXAoKTtcbiAgICAgIGNvcGllcy5zZXQoc291cmNlLCBiYXNlcyk7XG4gICAgfVxuICAgIGlmIChiYXNlcy5oYXMoYmFzZSkpIHJldHVybiBiYXNlcy5nZXQoYmFzZSk7XG5cbiAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICBiYXNlcy5zZXQoYmFzZSwgcmVzdWx0KTtcbiAgICBwZW5kaW5nLnB1c2goeyBiYXNlLCBzb3VyY2UsIHJlc3VsdCB9KTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgY29uc3QgcmVzdWx0ID0gdXRpbHMuaXNVbmRlZmluZWQoYikgPyBjb3B5KHVuZGVmaW5lZCwgYSkgOiBjb3B5KGEsIGIpO1xuICB3aGlsZSAocGVuZGluZy5sZW5ndGgpIHtcbiAgICBjb25zdCB7IGJhc2UsIHNvdXJjZSwgcmVzdWx0OiB0YXJnZXQgfSA9IHBlbmRpbmcucG9wKCk7XG4gICAgY29uc3QgYmFzZUtleXMgPSBuZXcgU2V0KG93bkVudW1lcmFibGVLZXlzKGJhc2UpKTtcbiAgICBjb25zdCBzb3VyY2VLZXlzID0gbmV3IFNldChvd25FbnVtZXJhYmxlS2V5cyhzb3VyY2UpKTtcbiAgICBjb25zdCBrZXlzID0gbmV3IFNldChbLi4uYmFzZUtleXMsIC4uLnNvdXJjZUtleXNdKTtcblxuICAgIGtleXMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBpZiAoa2V5ID09PSAnX19wcm90b19fJyB8fCBrZXkgPT09ICdjb25zdHJ1Y3RvcicgfHwga2V5ID09PSAncHJvdG90eXBlJykgcmV0dXJuO1xuICAgICAgY29uc3QgaGFzU291cmNlID0gc291cmNlS2V5cy5oYXMoa2V5KTtcbiAgICAgIGNvbnN0IHZhbHVlID0gaGFzU291cmNlID8gc291cmNlW2tleV0gOiB1bmRlZmluZWQ7XG4gICAgICBjb25zdCBwcmV2aW91cyA9XG4gICAgICAgICghaGFzU291cmNlIHx8IHV0aWxzLmlzUGxhaW5PYmplY3QodmFsdWUpKSAmJiBiYXNlS2V5cy5oYXMoa2V5KSA/IGJhc2Vba2V5XSA6IHVuZGVmaW5lZDtcbiAgICAgIHRhcmdldFtrZXldID0gaGFzU291cmNlID8gY29weShwcmV2aW91cywgdmFsdWUpIDogY29weSh1bmRlZmluZWQsIHByZXZpb3VzKTtcbiAgICB9KTtcbiAgfVxuXG4gIGFzc2VydFBhcmFtc0FjeWNsaWMocmVzdWx0KTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gZ2V0TWVyZ2VkVmFsdWUodGFyZ2V0LCBzb3VyY2UsIHByb3AsIGNhc2VsZXNzKSB7XG4gIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHRhcmdldCkgJiYgdXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgcmV0dXJuIHV0aWxzLm1lcmdlLmNhbGwoeyBjYXNlbGVzcyB9LCB0YXJnZXQsIHNvdXJjZSk7XG4gIH0gZWxzZSBpZiAodXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgcmV0dXJuIHV0aWxzLm1lcmdlKHt9LCBzb3VyY2UpO1xuICB9IGVsc2UgaWYgKHV0aWxzLmlzQXJyYXkoc291cmNlKSkge1xuICAgIHJldHVybiBzb3VyY2Uuc2xpY2UoKTtcbiAgfVxuICByZXR1cm4gc291cmNlO1xufVxuXG5mdW5jdGlvbiBtZXJnZURlZXBQcm9wZXJ0aWVzKGEsIGIsIHByb3AsIGNhc2VsZXNzKSB7XG4gIGlmICghdXRpbHMuaXNVbmRlZmluZWQoYikpIHtcbiAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUoYSwgYiwgcHJvcCwgY2FzZWxlc3MpO1xuICB9IGVsc2UgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChhKSkge1xuICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGEsIHByb3AsIGNhc2VsZXNzKTtcbiAgfVxufVxuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbmZ1bmN0aW9uIHZhbHVlRnJvbUNvbmZpZzIoYSwgYikge1xuICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGIpKSB7XG4gICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgYik7XG4gIH1cbn1cblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG5mdW5jdGlvbiBkZWZhdWx0VG9Db25maWcyKGEsIGIpIHtcbiAgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChiKSkge1xuICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGIpO1xuICB9IGVsc2UgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChhKSkge1xuICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGEpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGdldE1lcmdlZFRyYW5zaXRpb25hbE9wdGlvbihjb25maWcxLCBjb25maWcyLCBwcm9wKSB7XG4gIGNvbnN0IHRyYW5zaXRpb25hbDIgPSB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzIsICd0cmFuc2l0aW9uYWwnKVxuICAgID8gY29uZmlnMi50cmFuc2l0aW9uYWxcbiAgICA6IHVuZGVmaW5lZDtcblxuICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKHRyYW5zaXRpb25hbDIpKSB7XG4gICAgaWYgKHV0aWxzLmlzUGxhaW5PYmplY3QodHJhbnNpdGlvbmFsMikpIHtcbiAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHRyYW5zaXRpb25hbDIsIHByb3ApKSB7XG4gICAgICAgIHJldHVybiB0cmFuc2l0aW9uYWwyW3Byb3BdO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRyYW5zaXRpb25hbDEgPSB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzEsICd0cmFuc2l0aW9uYWwnKVxuICAgID8gY29uZmlnMS50cmFuc2l0aW9uYWxcbiAgICA6IHVuZGVmaW5lZDtcblxuICBpZiAodXRpbHMuaXNQbGFpbk9iamVjdCh0cmFuc2l0aW9uYWwxKSAmJiB1dGlscy5oYXNPd25Qcm9wKHRyYW5zaXRpb25hbDEsIHByb3ApKSB7XG4gICAgcmV0dXJuIHRyYW5zaXRpb25hbDFbcHJvcF07XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbmZ1bmN0aW9uIG1lcmdlRGlyZWN0S2V5cyhhLCBiLCBwcm9wLCBjb25maWcxLCBjb25maWcyKSB7XG4gIGlmICh1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzIsIHByb3ApKSB7XG4gICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKGEsIGIpO1xuICB9IGVsc2UgaWYgKHV0aWxzLmhhc093blByb3AoY29uZmlnMSwgcHJvcCkpIHtcbiAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUodW5kZWZpbmVkLCBhKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBtZXJnZUhlYWRlcnMoYSwgYiwgcHJvcCkge1xuICByZXR1cm4gbWVyZ2VEZWVwUHJvcGVydGllcyhoZWFkZXJzVG9PYmplY3QoYSksIGhlYWRlcnNUb09iamVjdChiKSwgcHJvcCwgdHJ1ZSk7XG59XG5cbi8vIE51bGwtcHJvdG8sIGZyb3plbiBkZXNjcmlwdG9yIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90IHR1cm5cbi8vIHRoaXMgZGF0YSBkZXNjcmlwdG9yIGludG8gYW4gYWNjZXNzb3IgZGVzY3JpcHRvciBvbiB0aGUgd2F5IGluLlxuLy8gZGVmaW5lUHJvcGVydHkgb25seSByZWFkcyBpdCwgc28gb25lIHNoYXJlZCBpbnN0YW5jZSBzZXJ2ZXMgZXZlcnkgY2FsbC5cbmNvbnN0IGhhc093blByb3BlcnR5RGVzY3JpcHRvciA9IE9iamVjdC5mcmVlemUoe1xuICBfX3Byb3RvX186IG51bGwsXG4gIHZhbHVlOiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgd3JpdGFibGU6IHRydWUsXG4gIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbn0pO1xuXG4vLyBUaGUgc3RyYXRlZ3kgdGFibGUgYW5kIHRoZSBzdHJhdGVnaWVzIGFib3ZlIGFyZSBzdGF0ZWxlc3MsIHNvIHRoZXkgYXJlXG4vLyBidWlsdCBvbmNlIGF0IG1vZHVsZSBsb2FkIGluc3RlYWQgb2Ygb24gZXZlcnkgY2FsbDogbWVyZ2VDb25maWcgcnVucyBhdFxuLy8gbW9zdCB0d2ljZSBwZXIgcmVxdWVzdCAob25jZSBmcm9tIGEgbWV0aG9kIGFsaWFzLCBvbmNlIGZyb20gYF9yZXF1ZXN0YCkuXG5jb25zdCBtZXJnZU1hcCA9IHtcbiAgdXJsOiB2YWx1ZUZyb21Db25maWcyLFxuICBtZXRob2Q6IHZhbHVlRnJvbUNvbmZpZzIsXG4gIGRhdGE6IHZhbHVlRnJvbUNvbmZpZzIsXG4gIGJhc2VVUkw6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHRyYW5zZm9ybVJlcXVlc3Q6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHRyYW5zZm9ybVJlc3BvbnNlOiBkZWZhdWx0VG9Db25maWcyLFxuICBwYXJhbXM6IG1lcmdlUGFyYW1zLFxuICBwYXJhbXNTZXJpYWxpemVyOiBkZWZhdWx0VG9Db25maWcyLFxuICB0aW1lb3V0OiBkZWZhdWx0VG9Db25maWcyLFxuICB0aW1lb3V0RXJyb3JNZXNzYWdlOiBkZWZhdWx0VG9Db25maWcyLFxuICB3aXRoQ3JlZGVudGlhbHM6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHdpdGhYU1JGVG9rZW46IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGFkYXB0ZXI6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHJlc3BvbnNlVHlwZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgeHNyZkNvb2tpZU5hbWU6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHhzcmZIZWFkZXJOYW1lOiBkZWZhdWx0VG9Db25maWcyLFxuICBvblVwbG9hZFByb2dyZXNzOiBkZWZhdWx0VG9Db25maWcyLFxuICBvbkRvd25sb2FkUHJvZ3Jlc3M6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGRlY29tcHJlc3M6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIG1heENvbnRlbnRMZW5ndGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIG1heEJvZHlMZW5ndGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGJlZm9yZVJlZGlyZWN0OiBkZWZhdWx0VG9Db25maWcyLFxuICB0cmFuc3BvcnQ6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGh0dHBBZ2VudDogZGVmYXVsdFRvQ29uZmlnMixcbiAgaHR0cHNBZ2VudDogZGVmYXVsdFRvQ29uZmlnMixcbiAgY2FuY2VsVG9rZW46IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHNvY2tldFBhdGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGFsbG93ZWRTb2NrZXRQYXRoczogZGVmYXVsdFRvQ29uZmlnMixcbiAgcmVzcG9uc2VFbmNvZGluZzogZGVmYXVsdFRvQ29uZmlnMixcbiAgdmFsaWRhdGVTdGF0dXM6IG1lcmdlRGlyZWN0S2V5cyxcbiAgaGVhZGVyczogbWVyZ2VIZWFkZXJzLFxufTtcblxuLyoqXG4gKiBDb25maWctc3BlY2lmaWMgbWVyZ2UtZnVuY3Rpb24gd2hpY2ggY3JlYXRlcyBhIG5ldyBjb25maWctb2JqZWN0XG4gKiBieSBtZXJnaW5nIHR3byBjb25maWd1cmF0aW9uIG9iamVjdHMgdG9nZXRoZXIuXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZzFcbiAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWcyXG4gKlxuICogQHJldHVybnMge09iamVjdH0gTmV3IG9iamVjdCByZXN1bHRpbmcgZnJvbSBtZXJnaW5nIGNvbmZpZzIgdG8gY29uZmlnMVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBtZXJnZUNvbmZpZyhjb25maWcxLCBjb25maWcyKSB7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICBjb25maWcxID0gY29uZmlnMSB8fCB7fTtcbiAgY29uZmlnMiA9IGNvbmZpZzIgfHwge307XG5cbiAgLy8gVXNlIGEgbnVsbC1wcm90b3R5cGUgb2JqZWN0IHNvIHRoYXQgZG93bnN0cmVhbSByZWFkcyBzdWNoIGFzIGBjb25maWcuYXV0aGBcbiAgLy8gb3IgYGNvbmZpZy5iYXNlVVJMYCBjYW5ub3QgaW5oZXJpdCBwb2xsdXRlZCB2YWx1ZXMgZnJvbSBPYmplY3QucHJvdG90eXBlLlxuICAvLyBgaGFzT3duUHJvcGVydHlgIGlzIHJlc3RvcmVkIGFzIGEgbm9uLWVudW1lcmFibGUgb3duIHNsb3QgdG8gcHJlc2VydmVcbiAgLy8gZXJnb25vbWljcyBmb3IgdXNlciBjb2RlIHRoYXQgcmVsaWVzIG9uIGl0LlxuICBjb25zdCBjb25maWcgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY29uZmlnLCAnaGFzT3duUHJvcGVydHknLCBoYXNPd25Qcm9wZXJ0eURlc2NyaXB0b3IpO1xuXG4gIGNvbnN0IGtleXMgPSBvd25FbnVtZXJhYmxlS2V5cyh7IC4uLmNvbmZpZzEsIC4uLmNvbmZpZzIgfSk7XG5cbiAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGtleXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBwcm9wID0ga2V5c1tpXTtcbiAgICBpZiAocHJvcCA9PT0gJ19fcHJvdG9fXycgfHwgcHJvcCA9PT0gJ2NvbnN0cnVjdG9yJyB8fCBwcm9wID09PSAncHJvdG90eXBlJykgY29udGludWU7XG4gICAgY29uc3QgbWVyZ2UgPSB1dGlscy5oYXNPd25Qcm9wKG1lcmdlTWFwLCBwcm9wKSA/IG1lcmdlTWFwW3Byb3BdIDogbWVyZ2VEZWVwUHJvcGVydGllcztcbiAgICBjb25zdCBhID0gdXRpbHMuaGFzT3duUHJvcChjb25maWcxLCBwcm9wKSA/IGNvbmZpZzFbcHJvcF0gOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgYiA9IHV0aWxzLmhhc093blByb3AoY29uZmlnMiwgcHJvcCkgPyBjb25maWcyW3Byb3BdIDogdW5kZWZpbmVkO1xuICAgIGNvbnN0IGNvbmZpZ1ZhbHVlID1cbiAgICAgIG1lcmdlID09PSBtZXJnZURpcmVjdEtleXMgPyBtZXJnZShhLCBiLCBwcm9wLCBjb25maWcxLCBjb25maWcyKSA6IG1lcmdlKGEsIGIsIHByb3ApO1xuICAgICh1dGlscy5pc1VuZGVmaW5lZChjb25maWdWYWx1ZSkgJiYgbWVyZ2UgIT09IG1lcmdlRGlyZWN0S2V5cykgfHwgKGNvbmZpZ1twcm9wXSA9IGNvbmZpZ1ZhbHVlKTtcbiAgfVxuXG4gIGlmIChcbiAgICB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzIsICd2YWxpZGF0ZVN0YXR1cycpICYmXG4gICAgdXRpbHMuaXNVbmRlZmluZWQoY29uZmlnMi52YWxpZGF0ZVN0YXR1cykgJiZcbiAgICBnZXRNZXJnZWRUcmFuc2l0aW9uYWxPcHRpb24oY29uZmlnMSwgY29uZmlnMiwgJ3ZhbGlkYXRlU3RhdHVzVW5kZWZpbmVkUmVzb2x2ZXMnKSA9PT0gZmFsc2VcbiAgKSB7XG4gICAgaWYgKHV0aWxzLmhhc093blByb3AoY29uZmlnMSwgJ3ZhbGlkYXRlU3RhdHVzJykpIHtcbiAgICAgIGNvbmZpZy52YWxpZGF0ZVN0YXR1cyA9IGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgY29uZmlnMS52YWxpZGF0ZVN0YXR1cyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRlbGV0ZSBjb25maWcudmFsaWRhdGVTdGF0dXM7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNvbmZpZztcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuY29uc3QgRk9STV9EQVRBX0NPTlRFTlRfSEVBREVSUyA9IFsnY29udGVudC10eXBlJywgJ2NvbnRlbnQtbGVuZ3RoJ107XG5cbi8qKlxuICogQXBwbHkgdGhlIGhlYWRlcnMgZ2VuZXJhdGVkIGJ5IGEgRm9ybURhdGEgaW1wbGVtZW50YXRpb24gdG8gdGhlIHJlcXVlc3QgaGVhZGVycyxcbiAqIGhvbm9yaW5nIHRoZSBgZm9ybURhdGFIZWFkZXJQb2xpY3lgIG9wdGlvbjogd2l0aCAnY29udGVudC1vbmx5JywgY29weSBvbmx5IHRoZVxuICogY29udGVudC0qIGhlYWRlcnM7IG90aGVyd2lzZSBtZXJnZSBhbGwgb2YgdGhlbS5cbiAqXG4gKiBAcGFyYW0ge0F4aW9zSGVhZGVyc30gaGVhZGVycyAtIHRoZSByZXF1ZXN0IGhlYWRlcnMgdG8gbXV0YXRlXG4gKiBAcGFyYW0ge09iamVjdCB8IG51bGwgfCB1bmRlZmluZWR9IGZvcm1IZWFkZXJzIC0gaGVhZGVycyBwcm9kdWNlZCBieSB0aGUgRm9ybURhdGEgaW1wbGVtZW50YXRpb25cbiAqIEBwYXJhbSB7U3RyaW5nfSBbcG9saWN5XSAtIHRoZSByZXNvbHZlZCBgZm9ybURhdGFIZWFkZXJQb2xpY3lgIGNvbmZpZyB2YWx1ZVxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzZXRGb3JtRGF0YUhlYWRlcnMoaGVhZGVycywgZm9ybUhlYWRlcnMsIHBvbGljeSkge1xuICBpZiAocG9saWN5ICE9PSAnY29udGVudC1vbmx5Jykge1xuICAgIGhlYWRlcnMuc2V0KGZvcm1IZWFkZXJzKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBPYmplY3QuZW50cmllcyhmb3JtSGVhZGVycyB8fCB7fSkuZm9yRWFjaCgoW2tleSwgdmFsXSkgPT4ge1xuICAgIGlmIChGT1JNX0RBVEFfQ09OVEVOVF9IRUFERVJTLmluY2x1ZGVzKGtleS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgaGVhZGVycy5zZXQoa2V5LCB2YWwpO1xuICAgIH1cbiAgfSk7XG59XG4iLCJpbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgaXNVUkxTYW1lT3JpZ2luIGZyb20gJy4vaXNVUkxTYW1lT3JpZ2luLmpzJztcbmltcG9ydCBjb29raWVzIGZyb20gJy4vY29va2llcy5qcyc7XG5pbXBvcnQgYnVpbGRGdWxsUGF0aCBmcm9tICcuLi9jb3JlL2J1aWxkRnVsbFBhdGguanMnO1xuaW1wb3J0IG1lcmdlQ29uZmlnIGZyb20gJy4uL2NvcmUvbWVyZ2VDb25maWcuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgc2V0Rm9ybURhdGFIZWFkZXJzIGZyb20gJy4uL2NvcmUvc2V0Rm9ybURhdGFIZWFkZXJzLmpzJztcbmltcG9ydCBidWlsZFVSTCBmcm9tICcuL2J1aWxkVVJMLmpzJztcblxuLyoqXG4gKiBFbmNvZGUgYSBVVEYtOCBzdHJpbmcgdG8gYSBMYXRpbi0xIGJ5dGUgc3RyaW5nIGZvciB1c2Ugd2l0aCBidG9hKCkuXG4gKiBUaGlzIGlzIGEgbW9kZXJuIHJlcGxhY2VtZW50IGZvciB0aGUgZGVwcmVjYXRlZCB1bmVzY2FwZShlbmNvZGVVUklDb21wb25lbnQoc3RyKSkgcGF0dGVybi5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyIFRoZSBzdHJpbmcgdG8gZW5jb2RlXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVVRGLTggYnl0ZXMgYXMgYSBMYXRpbi0xIHN0cmluZ1xuICovXG5jb25zdCBlbmNvZGVVVEY4ID0gKHN0cikgPT5cbiAgZW5jb2RlVVJJQ29tcG9uZW50KHN0cikucmVwbGFjZSgvJShbMC05QS1GXXsyfSkvZ2ksIChfLCBoZXgpID0+XG4gICAgU3RyaW5nLmZyb21DaGFyQ29kZShwYXJzZUludChoZXgsIDE2KSlcbiAgKTtcblxuY29uc3QgcmVhZENvb2tpZSA9IChuYW1lKSA9PiBjb29raWVzLnJlYWQobmFtZSk7XG5cbmZ1bmN0aW9uIHJlc29sdmVDb25maWcoY29uZmlnLCByZWFkWHNyZkNvb2tpZSA9IHJlYWRDb29raWUpIHtcbiAgY29uc3QgbmV3Q29uZmlnID0gbWVyZ2VDb25maWcoe30sIGNvbmZpZyk7XG5cbiAgLy8gUmVhZCBvbmx5IG93biBwcm9wZXJ0aWVzIHRvIHByZXZlbnQgcHJvdG90eXBlIHBvbGx1dGlvbiBnYWRnZXRzXG4gIC8vIChlLmcuIE9iamVjdC5wcm90b3R5cGUuYmFzZVVSTCA9ICdodHRwczovL2V2aWwuY29tJykuXG4gIGNvbnN0IG93biA9IChrZXkpID0+ICh1dGlscy5oYXNPd25Qcm9wKG5ld0NvbmZpZywga2V5KSA/IG5ld0NvbmZpZ1trZXldIDogdW5kZWZpbmVkKTtcblxuICBjb25zdCBkYXRhID0gb3duKCdkYXRhJyk7XG4gIGxldCB3aXRoWFNSRlRva2VuID0gb3duKCd3aXRoWFNSRlRva2VuJyk7XG4gIGNvbnN0IHhzcmZIZWFkZXJOYW1lID0gb3duKCd4c3JmSGVhZGVyTmFtZScpO1xuICBjb25zdCB4c3JmQ29va2llTmFtZSA9IG93bigneHNyZkNvb2tpZU5hbWUnKTtcbiAgbGV0IGhlYWRlcnMgPSBvd24oJ2hlYWRlcnMnKTtcbiAgY29uc3QgYXV0aCA9IG93bignYXV0aCcpO1xuICBjb25zdCBiYXNlVVJMID0gb3duKCdiYXNlVVJMJyk7XG4gIGNvbnN0IGFsbG93QWJzb2x1dGVVcmxzID0gb3duKCdhbGxvd0Fic29sdXRlVXJscycpO1xuICBjb25zdCB1cmwgPSBvd24oJ3VybCcpO1xuXG4gIG5ld0NvbmZpZy5oZWFkZXJzID0gaGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKGhlYWRlcnMpO1xuXG4gIG5ld0NvbmZpZy51cmwgPSBidWlsZFVSTChcbiAgICBidWlsZEZ1bGxQYXRoKGJhc2VVUkwsIHVybCwgYWxsb3dBYnNvbHV0ZVVybHMsIG5ld0NvbmZpZyksXG4gICAgb3duKCdwYXJhbXMnKSxcbiAgICBvd24oJ3BhcmFtc1NlcmlhbGl6ZXInKVxuICApO1xuXG4gIC8vIEhUVFAgYmFzaWMgYXV0aGVudGljYXRpb25cbiAgaWYgKGF1dGgpIHtcbiAgICBjb25zdCB1c2VybmFtZSA9IHV0aWxzLmdldFNhZmVQcm9wKGF1dGgsICd1c2VybmFtZScpIHx8ICcnO1xuICAgIGNvbnN0IHBhc3N3b3JkID0gdXRpbHMuZ2V0U2FmZVByb3AoYXV0aCwgJ3Bhc3N3b3JkJykgfHwgJyc7XG4gICAgY29uc3QgdHJhbnNpdGlvbmFsID0gb3duKCd0cmFuc2l0aW9uYWwnKTtcbiAgICBjb25zdCBlbmNvZGVVc2VybmFtZSA9XG4gICAgICB0cmFuc2l0aW9uYWwgJiZcbiAgICAgIHV0aWxzLmhhc093blByb3AodHJhbnNpdGlvbmFsLCAnZW5jb2RlQmFzaWNBdXRoVXNlcm5hbWUnKSAmJlxuICAgICAgdHJhbnNpdGlvbmFsLmVuY29kZUJhc2ljQXV0aFVzZXJuYW1lID09PSB0cnVlO1xuXG4gICAgdHJ5IHtcbiAgICAgIGhlYWRlcnMuc2V0KFxuICAgICAgICAnQXV0aG9yaXphdGlvbicsXG4gICAgICAgIC8vIFByZXNlcnZlIGxlZ2FjeSB1c2VybmFtZSBieXRlcyB1bmxlc3MgdGhlIGNhbGxlciBvcHRzIGluIHRvIFVURi04LlxuICAgICAgICAnQmFzaWMgJyArXG4gICAgICAgICAgYnRvYShcbiAgICAgICAgICAgIChlbmNvZGVVc2VybmFtZSA/IGVuY29kZVVURjgodXNlcm5hbWUpIDogdXNlcm5hbWUpICtcbiAgICAgICAgICAgICAgJzonICtcbiAgICAgICAgICAgICAgKHBhc3N3b3JkID8gZW5jb2RlVVRGOChwYXNzd29yZCkgOiAnJylcbiAgICAgICAgICApXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHRocm93IEF4aW9zRXJyb3IuZnJvbShlLCBBeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OX1ZBTFVFLCBjb25maWcpO1xuICAgIH1cbiAgfVxuXG4gIGlmICh1dGlscy5pc0Zvcm1EYXRhKGRhdGEpKSB7XG4gICAgY29uc3QgZ2V0SGVhZGVycyA9IHV0aWxzLmdldFNhZmVQcm9wKGRhdGEsICdnZXRIZWFkZXJzJyk7XG5cbiAgICBpZiAoXG4gICAgICBwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYgfHxcbiAgICAgIHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlcldlYldvcmtlckVudiB8fFxuICAgICAgdXRpbHMuaXNSZWFjdE5hdGl2ZShkYXRhKVxuICAgICkge1xuICAgICAgaGVhZGVycy5zZXRDb250ZW50VHlwZSh1bmRlZmluZWQpOyAvLyBicm93c2VyL3dlYiB3b3JrZXIvUk4gaGFuZGxlcyBpdFxuICAgIH0gZWxzZSBpZiAodXRpbHMuaXNGdW5jdGlvbihnZXRIZWFkZXJzKSkge1xuICAgICAgLy8gTm9kZS5qcyBGb3JtRGF0YSAobGlrZSBmb3JtLWRhdGEgcGFja2FnZSlcbiAgICAgIHNldEZvcm1EYXRhSGVhZGVycyhoZWFkZXJzLCBnZXRIZWFkZXJzLmNhbGwoZGF0YSksIG93bignZm9ybURhdGFIZWFkZXJQb2xpY3knKSk7XG4gICAgfVxuICB9XG5cbiAgLy8gQWRkIHhzcmYgaGVhZGVyXG4gIC8vIFRoaXMgaXMgb25seSBkb25lIGlmIHJ1bm5pbmcgaW4gYSBzdGFuZGFyZCBicm93c2VyIGVudmlyb25tZW50LlxuICAvLyBTcGVjaWZpY2FsbHkgbm90IGlmIHdlJ3JlIGluIGEgd2ViIHdvcmtlciwgb3IgcmVhY3QtbmF0aXZlLlxuXG4gIGlmIChwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYpIHtcbiAgICBpZiAodXRpbHMuaXNGdW5jdGlvbih3aXRoWFNSRlRva2VuKSkge1xuICAgICAgd2l0aFhTUkZUb2tlbiA9IHdpdGhYU1JGVG9rZW4obmV3Q29uZmlnKTtcbiAgICB9XG5cbiAgICAvLyBTdHJpY3QgYm9vbGVhbiBjaGVjayDigJQgcHJldmVudHMgcHJvdG8tcG9sbHV0aW9uIGdhZGdldHMgKGUuZy4gT2JqZWN0LnByb3RvdHlwZS53aXRoWFNSRlRva2VuID0gMSlcbiAgICAvLyBhbmQgbWlzY29uZmlndXJhdGlvbnMgKGUuZy4gXCJmYWxzZVwiKSBmcm9tIHNob3J0LWNpcmN1aXRpbmcgdGhlIHNhbWUtb3JpZ2luIGNoZWNrIGFuZCBsZWFraW5nXG4gICAgLy8gdGhlIFhTUkYgdG9rZW4gY3Jvc3Mtb3JpZ2luLlxuICAgIGNvbnN0IHNob3VsZFNlbmRYU1JGID1cbiAgICAgIHdpdGhYU1JGVG9rZW4gPT09IHRydWUgfHwgKHdpdGhYU1JGVG9rZW4gPT0gbnVsbCAmJiBpc1VSTFNhbWVPcmlnaW4obmV3Q29uZmlnLnVybCkpO1xuXG4gICAgaWYgKHNob3VsZFNlbmRYU1JGKSB7XG4gICAgICBjb25zdCB4c3JmVmFsdWUgPSB4c3JmSGVhZGVyTmFtZSAmJiB4c3JmQ29va2llTmFtZSAmJiByZWFkWHNyZkNvb2tpZSh4c3JmQ29va2llTmFtZSk7XG5cbiAgICAgIGlmICh4c3JmVmFsdWUpIHtcbiAgICAgICAgaGVhZGVycy5zZXQoeHNyZkhlYWRlck5hbWUsIHhzcmZWYWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG5ld0NvbmZpZztcbn1cblxuZXhwb3J0IGRlZmF1bHQgcmVzb2x2ZUNvbmZpZztcbiIsImltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgc2V0dGxlIGZyb20gJy4uL2NvcmUvc2V0dGxlLmpzJztcbmltcG9ydCB0cmFuc2l0aW9uYWxEZWZhdWx0cyBmcm9tICcuLi9kZWZhdWx0cy90cmFuc2l0aW9uYWwuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCBDYW5jZWxlZEVycm9yIGZyb20gJy4uL2NhbmNlbC9DYW5jZWxlZEVycm9yLmpzJztcbmltcG9ydCBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrIGZyb20gJy4uL2hlbHBlcnMvbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjay5qcyc7XG5pbXBvcnQgcGFyc2VQcm90b2NvbCBmcm9tICcuLi9oZWxwZXJzL3BhcnNlUHJvdG9jb2wuanMnO1xuaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi4vY29yZS9BeGlvc0hlYWRlcnMuanMnO1xuaW1wb3J0IGNvb2tpZXMgZnJvbSAnLi4vaGVscGVycy9jb29raWVzLmpzJztcbmltcG9ydCB7IHByb2dyZXNzRXZlbnRSZWR1Y2VyIH0gZnJvbSAnLi4vaGVscGVycy9wcm9ncmVzc0V2ZW50UmVkdWNlci5qcyc7XG5pbXBvcnQgcmVzb2x2ZUNvbmZpZyBmcm9tICcuLi9oZWxwZXJzL3Jlc29sdmVDb25maWcuanMnO1xuaW1wb3J0IHsgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0IH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgaXNYSFJBZGFwdGVyU3VwcG9ydGVkID0gdHlwZW9mIFhNTEh0dHBSZXF1ZXN0ICE9PSAndW5kZWZpbmVkJztcblxuZXhwb3J0IGRlZmF1bHQgaXNYSFJBZGFwdGVyU3VwcG9ydGVkICYmXG4gIGZ1bmN0aW9uIChjb25maWcpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gZGlzcGF0Y2hYaHJSZXF1ZXN0KHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgbGV0IHVzZUFzeW5jWHNyZjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0b3JlID1cbiAgICAgICAgICBwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYgJiYgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmNvb2tpZVN0b3JlO1xuICAgICAgICB1c2VBc3luY1hzcmYgPSBzdG9yZSAmJiB1dGlscy5pc0Z1bmN0aW9uKHN0b3JlLmdldCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIEEgcmVzdHJpY3RlZCBDb29raWUgU3RvcmUgZ2V0dGVyIG11c3QgcmV0YWluIHRoZSBzeW5jaHJvbm91cyBmYWxsYmFjay5cbiAgICAgIH1cbiAgICAgIGxldCB4c3JmQ29va2llTmFtZTtcbiAgICAgIGNvbnN0IF9jb25maWcgPSByZXNvbHZlQ29uZmlnKFxuICAgICAgICBjb25maWcsXG4gICAgICAgIHVzZUFzeW5jWHNyZlxuICAgICAgICAgID8gKG5hbWUpID0+IHtcbiAgICAgICAgICAgICAgeHNyZkNvb2tpZU5hbWUgPSBuYW1lO1xuICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHVuZGVmaW5lZFxuICAgICAgKTtcbiAgICAgIGxldCByZXF1ZXN0RGF0YSA9IF9jb25maWcuZGF0YTtcbiAgICAgIGNvbnN0IHJlcXVlc3RIZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oX2NvbmZpZy5oZWFkZXJzKS5ub3JtYWxpemUoKTtcbiAgICAgIGxldCB7IHJlc3BvbnNlVHlwZSwgb25VcGxvYWRQcm9ncmVzcywgb25Eb3dubG9hZFByb2dyZXNzIH0gPSBfY29uZmlnO1xuICAgICAgbGV0IG9uQ2FuY2VsZWQ7XG4gICAgICBsZXQgdGltZW91dElkO1xuICAgICAgbGV0IHVwbG9hZFRocm90dGxlZCwgZG93bmxvYWRUaHJvdHRsZWQ7XG4gICAgICBsZXQgZmx1c2hVcGxvYWQsIGZsdXNoRG93bmxvYWQsIGZsdXNoRG93bmxvYWRXaXRoRXZlbnQ7XG5cbiAgICAgIGZ1bmN0aW9uIGRvbmUoKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgICAgICAvLyBBIGZpbmFsIHByb2dyZXNzIGNhbGxiYWNrIG11c3Qgbm90IHByZXZlbnQgdGhlIHJlbWFpbmluZyBjbGVhbnVwLlxuICAgICAgICAvLyBSZXBvcnQgZXJyb3JzIGFzeW5jaHJvbm91c2x5LCBhcyBvbmxvYWRlbmQgYW5kIHRoZSB0aHJvdHRsZSB0aW1lciBkby5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBmbHVzaFVwbG9hZCAmJiBmbHVzaFVwbG9hZCgpOyAvLyBmbHVzaCBldmVudHNcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBmbHVzaERvd25sb2FkICYmIGZsdXNoRG93bmxvYWQoKTsgLy8gZmx1c2ggZXZlbnRzXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQSBmbHVzaCBjYW4gc3luY2hyb25vdXNseSBjYW5jZWwgdGhlIHJlcXVlc3QgYW5kIHJlZW50ZXIgZG9uZSgpLlxuICAgICAgICAvLyBJbiB0aGF0IGNhc2UgdGhlIGlubmVyIGNhbGwgaGFzIGFscmVhZHkgZGV0YWNoZWQgdGhlc2UgbGlzdGVuZXJzLlxuICAgICAgICBpZiAocmVxdWVzdCkge1xuICAgICAgICAgIGRvd25sb2FkVGhyb3R0bGVkICYmIHJlcXVlc3QucmVtb3ZlRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCBkb3dubG9hZFRocm90dGxlZCk7XG4gICAgICAgICAgaWYgKHJlcXVlc3QudXBsb2FkKSB7XG4gICAgICAgICAgICB1cGxvYWRUaHJvdHRsZWQgJiYgcmVxdWVzdC51cGxvYWQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCB1cGxvYWRUaHJvdHRsZWQpO1xuICAgICAgICAgICAgZmx1c2hVcGxvYWQgJiYgcmVxdWVzdC51cGxvYWQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbG9hZGVuZCcsIGZsdXNoVXBsb2FkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBfY29uZmlnLmNhbmNlbFRva2VuICYmIF9jb25maWcuY2FuY2VsVG9rZW4udW5zdWJzY3JpYmUob25DYW5jZWxlZCk7XG5cbiAgICAgICAgX2NvbmZpZy5zaWduYWwgJiYgX2NvbmZpZy5zaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgIH1cblxuICAgICAgbGV0IHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcblxuICAgICAgcmVxdWVzdC5vcGVuKF9jb25maWcubWV0aG9kLnRvVXBwZXJDYXNlKCksIF9jb25maWcudXJsLCB0cnVlKTtcblxuICAgICAgLy8gU2V0IHRoZSByZXF1ZXN0IHRpbWVvdXQgaW4gTVNcbiAgICAgIHJlcXVlc3QudGltZW91dCA9IF9jb25maWcudGltZW91dDtcblxuICAgICAgZnVuY3Rpb24gb25sb2FkZW5kKGV2ZW50KSB7XG4gICAgICAgIGlmICghcmVxdWVzdCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFN0YXR1cyAwIG1lYW5zIG5vIHJlc3BvbnNlIHdhcyByZWNlaXZlZCwgd2hpY2ggb25lcnJvciBhbmQgb25hYm9ydCBub3JtYWxseVxuICAgICAgICAvLyByZWplY3QgYmVmb3JlIHRoaXMgcnVucy4gRmlyZWZveCAxNTIgZmlyZXMgb25seSByZWFkeXN0YXRlY2hhbmdlIGFuZCBsb2FkZW5kIGZvclxuICAgICAgICAvLyBuYXZpZ2F0aW9uLWNhbmNlbGVkIHJlcXVlc3RzIChodHRwczovL2J1Z3ppbGxhLm1vemlsbGEub3JnL3Nob3dfYnVnLmNnaT9pZD0xNTA1Mzg5KSxcbiAgICAgICAgLy8gbGVhdmluZyBzZXR0bGUoKSB0byByZXNvbHZlIHRoZW0gYXMgYW4gZW1wdHkgc3VjY2Vzcy4gRUNPTk5BQk9SVEVEIGlzIHRoZSBlcnJvclxuICAgICAgICAvLyBvbmFib3J0IHJhaXNlZCBvbiBGaXJlZm94IDE1MS4gUmVhZHMgb3ZlciBmaWxlOiwgd2hpY2ggc29tZSBlbnZpcm9ubWVudHMgcmVwb3J0IGFzXG4gICAgICAgIC8vIHN0YXR1cyAwIG9uIHN1Y2Nlc3MsIGFyZSBleGNsdWRlZCBieSB0aGUgcmVxdWVzdCBVUkwncyBzY2hlbWUgYWZ0ZXIgYnJvd3Nlci1zdHlsZVxuICAgICAgICAvLyBwcmVwcm9jZXNzaW5nLCBieSB0aGUgcGFnZSBvcmlnaW4ncyBzY2hlbWUgZm9yIHJlbGF0aXZlIFVSTHMgKHdoaWNoIGluaGVyaXQgaXQpLCBvclxuICAgICAgICAvLyBieSByZXNwb25zZVVSTCB3aGVyZSBpbXBsZW1lbnRlZC5cbiAgICAgICAgaWYgKFxuICAgICAgICAgIHJlcXVlc3Quc3RhdHVzID09PSAwICYmXG4gICAgICAgICAgKHBhcnNlUHJvdG9jb2wobm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjayhfY29uZmlnLnVybCkpIHx8XG4gICAgICAgICAgICBwYXJzZVByb3RvY29sKHBsYXRmb3JtLm9yaWdpbikpICE9PSAnZmlsZScgJiZcbiAgICAgICAgICAhKHJlcXVlc3QucmVzcG9uc2VVUkwgJiYgcmVxdWVzdC5yZXNwb25zZVVSTC5zdGFydHNXaXRoKCdmaWxlOicpKVxuICAgICAgICApIHtcbiAgICAgICAgICByZWplY3QobmV3IEF4aW9zRXJyb3IoJ1JlcXVlc3QgYWJvcnRlZCcsIEF4aW9zRXJyb3IuRUNPTk5BQk9SVEVELCBjb25maWcsIHJlcXVlc3QpKTtcbiAgICAgICAgICBkb25lKCk7XG5cbiAgICAgICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gV2hlbiBsb2FkZW5kIGlzIHN0aWxsIGRpc3BhdGNoaW5nLCBmbHVzaGluZyB3aXRoIGl0IGdpdmVzIHByb2dyZXNzXG4gICAgICAgIC8vIGxpc3RlbmVycyBhIGZpbmFsIGRlbGl2ZXJ5IHdob3NlIGV2ZW50IGhhcyBhIGxpdmUgdGFyZ2V0LiBUaGUgbGVnYWN5XG4gICAgICAgIC8vIHJlYWR5LXN0YXRlIGZhbGxiYWNrIGhhcyBubyBldmVudCwgc28gcmVwbGF5IGl0cyBwZW5kaW5nIHByb2dyZXNzLlxuICAgICAgICAvLyBBIHRocm93aW5nIGxpc3RlbmVyIG11c3Qgbm90IGJsb2NrIHNldHRsZW1lbnQ7IHJldGhyb3cgYXN5bmNocm9ub3VzbHksXG4gICAgICAgIC8vIG1hdGNoaW5nIGhvdyBsaXN0ZW5lciBlcnJvcnMgc3VyZmFjZSBvbiB0aGUgdGhyb3R0bGUgdGltZXIgcGF0aC5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoZXZlbnQpIHtcbiAgICAgICAgICAgIGZsdXNoRG93bmxvYWRXaXRoRXZlbnQgJiYgZmx1c2hEb3dubG9hZFdpdGhFdmVudChldmVudCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGZsdXNoRG93bmxvYWQgJiYgZmx1c2hEb3dubG9hZCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBIGZpbmFsIHByb2dyZXNzIGNhbGxiYWNrIGNhbiBjYW5jZWwgdGhlIHJlcXVlc3Qgc3luY2hyb25vdXNseS5cbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUHJlcGFyZSB0aGUgcmVzcG9uc2VcbiAgICAgICAgY29uc3QgcmVzcG9uc2VIZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oXG4gICAgICAgICAgJ2dldEFsbFJlc3BvbnNlSGVhZGVycycgaW4gcmVxdWVzdCAmJiByZXF1ZXN0LmdldEFsbFJlc3BvbnNlSGVhZGVycygpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9XG4gICAgICAgICAgIXJlc3BvbnNlVHlwZSB8fCByZXNwb25zZVR5cGUgPT09ICd0ZXh0JyB8fCByZXNwb25zZVR5cGUgPT09ICdqc29uJ1xuICAgICAgICAgICAgPyByZXF1ZXN0LnJlc3BvbnNlVGV4dFxuICAgICAgICAgICAgOiByZXF1ZXN0LnJlc3BvbnNlO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IHtcbiAgICAgICAgICBkYXRhOiByZXNwb25zZURhdGEsXG4gICAgICAgICAgc3RhdHVzOiByZXF1ZXN0LnN0YXR1cyxcbiAgICAgICAgICBzdGF0dXNUZXh0OiByZXF1ZXN0LnN0YXR1c1RleHQsXG4gICAgICAgICAgaGVhZGVyczogcmVzcG9uc2VIZWFkZXJzLFxuICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICB9O1xuXG4gICAgICAgIHNldHRsZShcbiAgICAgICAgICBmdW5jdGlvbiBfcmVzb2x2ZSh2YWx1ZSkge1xuICAgICAgICAgICAgcmVzb2x2ZSh2YWx1ZSk7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBmdW5jdGlvbiBfcmVqZWN0KGVycikge1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICApO1xuXG4gICAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICB9XG5cbiAgICAgIGlmICgnb25sb2FkZW5kJyBpbiByZXF1ZXN0KSB7XG4gICAgICAgIC8vIFVzZSBvbmxvYWRlbmQgaWYgYXZhaWxhYmxlXG4gICAgICAgIHJlcXVlc3Qub25sb2FkZW5kID0gb25sb2FkZW5kO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gTGlzdGVuIGZvciByZWFkeSBzdGF0ZSB0byBlbXVsYXRlIG9ubG9hZGVuZFxuICAgICAgICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIGhhbmRsZUxvYWQoKSB7XG4gICAgICAgICAgaWYgKCFyZXF1ZXN0IHx8IHJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gNCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFRoZSByZXF1ZXN0IGVycm9yZWQgb3V0IGFuZCB3ZSBkaWRuJ3QgZ2V0IGEgcmVzcG9uc2UsIHRoaXMgd2lsbCBiZVxuICAgICAgICAgIC8vIGhhbmRsZWQgYnkgb25lcnJvciBpbnN0ZWFkXG4gICAgICAgICAgLy8gV2l0aCBvbmUgZXhjZXB0aW9uOiByZXF1ZXN0IHRoYXQgdXNpbmcgZmlsZTogcHJvdG9jb2wsIG1vc3QgYnJvd3NlcnNcbiAgICAgICAgICAvLyB3aWxsIHJldHVybiBzdGF0dXMgYXMgMCBldmVuIHRob3VnaCBpdCdzIGEgc3VjY2Vzc2Z1bCByZXF1ZXN0XG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgcmVxdWVzdC5zdGF0dXMgPT09IDAgJiZcbiAgICAgICAgICAgICEocmVxdWVzdC5yZXNwb25zZVVSTCAmJiByZXF1ZXN0LnJlc3BvbnNlVVJMLnN0YXJ0c1dpdGgoJ2ZpbGU6JykpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIHJlYWR5c3RhdGUgaGFuZGxlciBpcyBjYWxsaW5nIGJlZm9yZSBvbmVycm9yIG9yIG9udGltZW91dCBoYW5kbGVycyxcbiAgICAgICAgICAvLyBzbyB3ZSBzaG91bGQgY2FsbCBvbmxvYWRlbmQgb24gdGhlIG5leHQgJ3RpY2snXG4gICAgICAgICAgc2V0VGltZW91dChvbmxvYWRlbmQpO1xuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICAvLyBIYW5kbGUgYnJvd3NlciByZXF1ZXN0IGNhbmNlbGxhdGlvbiAoYXMgb3Bwb3NlZCB0byBhIG1hbnVhbCBjYW5jZWxsYXRpb24pXG4gICAgICByZXF1ZXN0Lm9uYWJvcnQgPSBmdW5jdGlvbiBoYW5kbGVBYm9ydCgpIHtcbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgcmVqZWN0KG5ldyBBeGlvc0Vycm9yKCdSZXF1ZXN0IGFib3J0ZWQnLCBBeGlvc0Vycm9yLkVDT05OQUJPUlRFRCwgY29uZmlnLCByZXF1ZXN0KSk7XG4gICAgICAgIGRvbmUoKTtcblxuICAgICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgICAgfTtcblxuICAgICAgLy8gSGFuZGxlIGxvdyBsZXZlbCBuZXR3b3JrIGVycm9yc1xuICAgICAgcmVxdWVzdC5vbmVycm9yID0gZnVuY3Rpb24gaGFuZGxlRXJyb3IoZXZlbnQpIHtcbiAgICAgICAgLy8gQnJvd3NlcnMgZGVsaXZlciBhIFByb2dyZXNzRXZlbnQgaW4gWEhSIG9uZXJyb3JcbiAgICAgICAgLy8gKG1lc3NhZ2UgbWF5IGJlIGVtcHR5OyB3aGVuIHByZXNlbnQsIHN1cmZhY2UgaXQpXG4gICAgICAgIC8vIFNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9kb2NzL1dlYi9BUEkvWE1MSHR0cFJlcXVlc3QvZXJyb3JfZXZlbnRcbiAgICAgICAgY29uc3QgbXNnID0gZXZlbnQgJiYgZXZlbnQubWVzc2FnZSA/IGV2ZW50Lm1lc3NhZ2UgOiAnTmV0d29yayBFcnJvcic7XG4gICAgICAgIGNvbnN0IGVyciA9IG5ldyBBeGlvc0Vycm9yKG1zZywgQXhpb3NFcnJvci5FUlJfTkVUV09SSywgY29uZmlnLCByZXF1ZXN0KTtcbiAgICAgICAgLy8gYXR0YWNoIHRoZSB1bmRlcmx5aW5nIGV2ZW50IGZvciBjb25zdW1lcnMgd2hvIHdhbnQgZGV0YWlsc1xuICAgICAgICBlcnIuZXZlbnQgPSBldmVudCB8fCBudWxsO1xuICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgZG9uZSgpO1xuICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgIH07XG5cbiAgICAgIC8vIEhhbmRsZSB0aW1lb3V0XG4gICAgICByZXF1ZXN0Lm9udGltZW91dCA9IGZ1bmN0aW9uIGhhbmRsZVRpbWVvdXQoKSB7XG4gICAgICAgIGlmICghcmVxdWVzdCkgcmV0dXJuO1xuICAgICAgICBsZXQgdGltZW91dEVycm9yTWVzc2FnZSA9IF9jb25maWcudGltZW91dFxuICAgICAgICAgID8gJ3RpbWVvdXQgb2YgJyArIF9jb25maWcudGltZW91dCArICdtcyBleGNlZWRlZCdcbiAgICAgICAgICA6ICd0aW1lb3V0IGV4Y2VlZGVkJztcbiAgICAgICAgY29uc3QgdHJhbnNpdGlvbmFsID0gX2NvbmZpZy50cmFuc2l0aW9uYWwgfHwgdHJhbnNpdGlvbmFsRGVmYXVsdHM7XG4gICAgICAgIGlmIChfY29uZmlnLnRpbWVvdXRFcnJvck1lc3NhZ2UpIHtcbiAgICAgICAgICB0aW1lb3V0RXJyb3JNZXNzYWdlID0gX2NvbmZpZy50aW1lb3V0RXJyb3JNZXNzYWdlO1xuICAgICAgICB9XG4gICAgICAgIHJlamVjdChcbiAgICAgICAgICBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgIHRpbWVvdXRFcnJvck1lc3NhZ2UsXG4gICAgICAgICAgICB0cmFuc2l0aW9uYWwuY2xhcmlmeVRpbWVvdXRFcnJvciA/IEF4aW9zRXJyb3IuRVRJTUVET1VUIDogQXhpb3NFcnJvci5FQ09OTkFCT1JURUQsXG4gICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgICBkb25lKCk7XG5cbiAgICAgICAgLy8gQ2xlYW4gdXAgcmVxdWVzdFxuICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgIH07XG5cbiAgICAgIC8vIFJlbW92ZSBDb250ZW50LVR5cGUgaWYgZGF0YSBpcyB1bmRlZmluZWRcbiAgICAgIHJlcXVlc3REYXRhID09PSB1bmRlZmluZWQgJiYgcmVxdWVzdEhlYWRlcnMuc2V0Q29udGVudFR5cGUobnVsbCk7XG5cbiAgICAgIC8vIEFkZCB3aXRoQ3JlZGVudGlhbHMgdG8gcmVxdWVzdCBpZiBuZWVkZWRcbiAgICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQoX2NvbmZpZy53aXRoQ3JlZGVudGlhbHMpKSB7XG4gICAgICAgIHJlcXVlc3Qud2l0aENyZWRlbnRpYWxzID0gISFfY29uZmlnLndpdGhDcmVkZW50aWFscztcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIHJlc3BvbnNlVHlwZSB0byByZXF1ZXN0IGlmIG5lZWRlZFxuICAgICAgaWYgKHJlc3BvbnNlVHlwZSAmJiByZXNwb25zZVR5cGUgIT09ICdqc29uJykge1xuICAgICAgICByZXF1ZXN0LnJlc3BvbnNlVHlwZSA9IF9jb25maWcucmVzcG9uc2VUeXBlO1xuICAgICAgfVxuXG4gICAgICAvLyBIYW5kbGUgcHJvZ3Jlc3MgaWYgbmVlZGVkXG4gICAgICBpZiAob25Eb3dubG9hZFByb2dyZXNzKSB7XG4gICAgICAgIFtkb3dubG9hZFRocm90dGxlZCwgZmx1c2hEb3dubG9hZCwgZmx1c2hEb3dubG9hZFdpdGhFdmVudF0gPSBwcm9ncmVzc0V2ZW50UmVkdWNlcihcbiAgICAgICAgICBvbkRvd25sb2FkUHJvZ3Jlc3MsXG4gICAgICAgICAgdHJ1ZVxuICAgICAgICApO1xuICAgICAgICByZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgZG93bmxvYWRUaHJvdHRsZWQpO1xuICAgICAgfVxuXG4gICAgICAvLyBOb3QgYWxsIGJyb3dzZXJzIHN1cHBvcnQgdXBsb2FkIGV2ZW50c1xuICAgICAgaWYgKG9uVXBsb2FkUHJvZ3Jlc3MgJiYgcmVxdWVzdC51cGxvYWQpIHtcbiAgICAgICAgW3VwbG9hZFRocm90dGxlZCwgZmx1c2hVcGxvYWRdID0gcHJvZ3Jlc3NFdmVudFJlZHVjZXIob25VcGxvYWRQcm9ncmVzcyk7XG5cbiAgICAgICAgcmVxdWVzdC51cGxvYWQuYWRkRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCB1cGxvYWRUaHJvdHRsZWQpO1xuXG4gICAgICAgIHJlcXVlc3QudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWRlbmQnLCBmbHVzaFVwbG9hZCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChfY29uZmlnLmNhbmNlbFRva2VuIHx8IF9jb25maWcuc2lnbmFsKSB7XG4gICAgICAgIC8vIEhhbmRsZSBjYW5jZWxsYXRpb25cbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbiAgICAgICAgb25DYW5jZWxlZCA9IChjYW5jZWwpID0+IHtcbiAgICAgICAgICBpZiAoIXJlcXVlc3QpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmVqZWN0KCFjYW5jZWwgfHwgY2FuY2VsLnR5cGUgPyBuZXcgQ2FuY2VsZWRFcnJvcihudWxsLCBjb25maWcsIHJlcXVlc3QpIDogY2FuY2VsKTtcbiAgICAgICAgICBjb25zdCB4aHIgPSByZXF1ZXN0O1xuICAgICAgICAgIGRvbmUoKTtcbiAgICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgICAgICB4aHIuYWJvcnQoKTtcbiAgICAgICAgfTtcblxuICAgICAgICBfY29uZmlnLmNhbmNlbFRva2VuICYmIF9jb25maWcuY2FuY2VsVG9rZW4uc3Vic2NyaWJlKG9uQ2FuY2VsZWQpO1xuICAgICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcbiAgICAgICAgaWYgKF9jb25maWcuc2lnbmFsKSB7XG4gICAgICAgICAgX2NvbmZpZy5zaWduYWwuYWJvcnRlZFxuICAgICAgICAgICAgPyBvbkNhbmNlbGVkKClcbiAgICAgICAgICAgIDogX2NvbmZpZy5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcblxuICAgICAgY29uc3QgcHJvdG9jb2wgPSBwYXJzZVByb3RvY29sKF9jb25maWcudXJsKTtcblxuICAgICAgaWYgKHByb3RvY29sICYmICFwbGF0Zm9ybS5wcm90b2NvbHMuaW5jbHVkZXMocHJvdG9jb2wpKSB7XG4gICAgICAgIHJlamVjdChcbiAgICAgICAgICBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgICdVbnN1cHBvcnRlZCBwcm90b2NvbCAnICsgcHJvdG9jb2wgKyAnOicsXG4gICAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9CQURfUkVRVUVTVCxcbiAgICAgICAgICAgIGNvbmZpZ1xuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgICAgZG9uZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHNlbmRSZXF1ZXN0ID0gKCkgPT4ge1xuICAgICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcbiAgICAgICAgLy8gQXBwbHkgaGVhZGVycyBhZnRlciBhbiBhc3luY2hyb25vdXMgWFNSRiByZWFkIHNvIGV4aXN0aW5nIGhlYWRlcnMgYXJlXG4gICAgICAgIC8vIHJlcGxhY2VkIHRocm91Z2ggQXhpb3NIZWFkZXJzIHJhdGhlciB0aGFuIGFwcGVuZGVkIGJ5IHRoZSBuYXRpdmUgWEhSLlxuICAgICAgICBpZiAoJ3NldFJlcXVlc3RIZWFkZXInIGluIHJlcXVlc3QpIHtcbiAgICAgICAgICB1dGlscy5mb3JFYWNoKFxuICAgICAgICAgICAgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0KHJlcXVlc3RIZWFkZXJzKSxcbiAgICAgICAgICAgIGZ1bmN0aW9uIHNldFJlcXVlc3RIZWFkZXIodmFsLCBrZXkpIHtcbiAgICAgICAgICAgICAgcmVxdWVzdC5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgdmFsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJlcXVlc3Quc2VuZChyZXF1ZXN0RGF0YSB8fCBudWxsKTtcbiAgICAgIH07XG5cbiAgICAgIGlmICh4c3JmQ29va2llTmFtZSkge1xuICAgICAgICAvLyBOYXRpdmUgWEhSIHRpbWVvdXQgc3RhcnRzIGF0IHNlbmQoKS4gQ292ZXIgY29va2llIHByZXBhcmF0aW9uIGFuZCB0aGVcbiAgICAgICAgLy8gc3Vic2VxdWVudCByZXF1ZXN0IHdpdGggdGhlIHNhbWUgYnVkZ2V0IGFuZCBleGlzdGluZyB0aW1lb3V0IGhhbmRsZXIuXG4gICAgICAgIGNvbnN0IG5vdyA9XG4gICAgICAgICAgdHlwZW9mIHBlcmZvcm1hbmNlICE9PSAndW5kZWZpbmVkJyAmJiB1dGlscy5pc0Z1bmN0aW9uKHBlcmZvcm1hbmNlLm5vdylcbiAgICAgICAgICAgID8gKCkgPT4gcGVyZm9ybWFuY2Uubm93KClcbiAgICAgICAgICAgIDogRGF0ZS5ub3c7XG4gICAgICAgIGNvbnN0IGRlYWRsaW5lID0gcmVxdWVzdC50aW1lb3V0ID4gMCA/IG5vdygpICsgTnVtYmVyKHJlcXVlc3QudGltZW91dCkgOiB1bmRlZmluZWQ7XG4gICAgICAgIGNvbnN0IGFib3J0T25UaW1lb3V0ID0gKCkgPT4ge1xuICAgICAgICAgIGlmICghcmVxdWVzdCkgcmV0dXJuO1xuICAgICAgICAgIGNvbnN0IHhociA9IHJlcXVlc3Q7XG4gICAgICAgICAgeGhyLm9udGltZW91dCgpO1xuICAgICAgICAgIHhoci5hYm9ydCgpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoZGVhZGxpbmUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGNvbnN0IHNjaGVkdWxlVGltZW91dCA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IGRlYWRsaW5lIC0gbm93KCk7XG4gICAgICAgICAgICBpZiAocmVtYWluaW5nID4gMCkge1xuICAgICAgICAgICAgICAvLyBCcm93c2VyIHRpbWVycyBvdmVyZmxvdyBhYm92ZSB0aGUgc2lnbmVkIDMyLWJpdCBkZWxheSBsaW1pdC5cbiAgICAgICAgICAgICAgdGltZW91dElkID0gc2V0VGltZW91dChzY2hlZHVsZVRpbWVvdXQsIE1hdGgubWluKHJlbWFpbmluZywgMHg3ZmZmZmZmZikpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgYWJvcnRPblRpbWVvdXQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICAgIHNjaGVkdWxlVGltZW91dCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29va2llc1xuICAgICAgICAgIC5yZWFkQXN5bmMoeHNyZkNvb2tpZU5hbWUpXG4gICAgICAgICAgLnRoZW4oKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcbiAgICAgICAgICAgIC8vIFByb21pc2UgY2FsbGJhY2tzIG1heSBydW4gYmVmb3JlIGFuIG92ZXJkdWUgdGltZXIgYWZ0ZXIgYSBidXN5IHRhc2suXG4gICAgICAgICAgICBpZiAoZGVhZGxpbmUgIT09IHVuZGVmaW5lZCAmJiBub3coKSA+PSBkZWFkbGluZSkge1xuICAgICAgICAgICAgICBhYm9ydE9uVGltZW91dCgpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgY29uc3QgaGVhZGVyTmFtZSA9XG4gICAgICAgICAgICAgICAgdXRpbHMuaGFzT3duUHJvcChfY29uZmlnLCAneHNyZkhlYWRlck5hbWUnKSAmJiBfY29uZmlnLnhzcmZIZWFkZXJOYW1lO1xuICAgICAgICAgICAgICByZXF1ZXN0SGVhZGVycy5zZXQoaGVhZGVyTmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2VuZFJlcXVlc3QoKTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICAgIGlmICghcmVxdWVzdCkgcmV0dXJuO1xuICAgICAgICAgICAgcmVqZWN0KEF4aW9zRXJyb3IuZnJvbShlcnJvciwgbnVsbCwgY29uZmlnLCByZXF1ZXN0KSk7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNlbmRSZXF1ZXN0KCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG4iLCJpbXBvcnQgQ2FuY2VsZWRFcnJvciBmcm9tICcuLi9jYW5jZWwvQ2FuY2VsZWRFcnJvci5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuLi9jb3JlL0F4aW9zRXJyb3IuanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuY29uc3QgY29tcG9zZVNpZ25hbHMgPSAoc2lnbmFscywgdGltZW91dCkgPT4ge1xuICBzaWduYWxzID0gc2lnbmFscyA/IHNpZ25hbHMuZmlsdGVyKEJvb2xlYW4pIDogW107XG5cbiAgaWYgKCF0aW1lb3V0ICYmICFzaWduYWxzLmxlbmd0aCkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cbiAgbGV0IGFib3J0ZWQgPSBmYWxzZTtcblxuICBjb25zdCBvbmFib3J0ID0gZnVuY3Rpb24gKHJlYXNvbikge1xuICAgIGlmICghYWJvcnRlZCkge1xuICAgICAgYWJvcnRlZCA9IHRydWU7XG4gICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgY29uc3QgZXJyID0gcmVhc29uIGluc3RhbmNlb2YgRXJyb3IgPyByZWFzb24gOiB0aGlzLnJlYXNvbjtcbiAgICAgIGNvbnRyb2xsZXIuYWJvcnQoXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEF4aW9zRXJyb3JcbiAgICAgICAgICA/IGVyclxuICAgICAgICAgIDogbmV3IENhbmNlbGVkRXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IGVycilcbiAgICAgICk7XG4gICAgfVxuICB9O1xuXG4gIGxldCB0aW1lciA9XG4gICAgdGltZW91dCAmJlxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGltZXIgPSBudWxsO1xuICAgICAgb25hYm9ydChuZXcgQXhpb3NFcnJvcihgdGltZW91dCBvZiAke3RpbWVvdXR9bXMgZXhjZWVkZWRgLCBBeGlvc0Vycm9yLkVUSU1FRE9VVCkpO1xuICAgIH0sIHRpbWVvdXQpO1xuXG4gIGNvbnN0IHVuc3Vic2NyaWJlID0gKCkgPT4ge1xuICAgIGlmICghc2lnbmFscykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aW1lciAmJiBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgIHRpbWVyID0gbnVsbDtcbiAgICBzaWduYWxzLmZvckVhY2goKHNpZ25hbCkgPT4ge1xuICAgICAgY29uc3QgdW5zdWJzY3JpYmVTaWduYWwgPSB1dGlscy5nZXRTYWZlUHJvcChzaWduYWwsICd1bnN1YnNjcmliZScpO1xuICAgICAgdXRpbHMuaXNGdW5jdGlvbih1bnN1YnNjcmliZVNpZ25hbClcbiAgICAgICAgPyB1bnN1YnNjcmliZVNpZ25hbC5jYWxsKHNpZ25hbCwgb25hYm9ydClcbiAgICAgICAgOiBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbmFib3J0KTtcbiAgICB9KTtcbiAgICBzaWduYWxzID0gbnVsbDtcbiAgfTtcblxuICBzaWduYWxzLmZvckVhY2goKHNpZ25hbCkgPT4ge1xuICAgIGlmIChhYm9ydGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICBvbmFib3J0LmNhbGwoc2lnbmFsKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbmFib3J0LCB7IG9uY2U6IHRydWUgfSk7XG4gIH0pO1xuXG4gIGNvbnN0IHsgc2lnbmFsIH0gPSBjb250cm9sbGVyO1xuXG4gIHNpZ25hbC51bnN1YnNjcmliZSA9ICgpID0+IHV0aWxzLmFzYXAodW5zdWJzY3JpYmUpO1xuXG4gIHJldHVybiBzaWduYWw7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBjb21wb3NlU2lnbmFscztcbiIsImV4cG9ydCBjb25zdCBzdHJlYW1DaHVuayA9IGZ1bmN0aW9uKiAoY2h1bmssIGNodW5rU2l6ZSkge1xuICBsZXQgbGVuID0gY2h1bmsuYnl0ZUxlbmd0aDtcblxuICBpZiAoIWNodW5rU2l6ZSB8fCBsZW4gPCBjaHVua1NpemUpIHtcbiAgICB5aWVsZCBjaHVuaztcbiAgICByZXR1cm47XG4gIH1cblxuICBsZXQgcG9zID0gMDtcbiAgbGV0IGVuZDtcblxuICB3aGlsZSAocG9zIDwgbGVuKSB7XG4gICAgZW5kID0gcG9zICsgY2h1bmtTaXplO1xuICAgIHlpZWxkIGNodW5rLnNsaWNlKHBvcywgZW5kKTtcbiAgICBwb3MgPSBlbmQ7XG4gIH1cbn07XG5cbmV4cG9ydCBjb25zdCByZWFkQnl0ZXMgPSBhc3luYyBmdW5jdGlvbiogKGl0ZXJhYmxlLCBjaHVua1NpemUpIHtcbiAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiByZWFkU3RyZWFtKGl0ZXJhYmxlKSkge1xuICAgIHlpZWxkKiBzdHJlYW1DaHVuayhjaHVuaywgY2h1bmtTaXplKTtcbiAgfVxufTtcblxuY29uc3QgcmVhZFN0cmVhbSA9IGFzeW5jIGZ1bmN0aW9uKiAoc3RyZWFtKSB7XG4gIGlmIChzdHJlYW1bU3ltYm9sLmFzeW5jSXRlcmF0b3JdKSB7XG4gICAgeWllbGQqIHN0cmVhbTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCByZWFkZXIgPSBzdHJlYW0uZ2V0UmVhZGVyKCk7XG4gIHRyeSB7XG4gICAgZm9yICg7Oykge1xuICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICAgIGlmIChkb25lKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgeWllbGQgdmFsdWU7XG4gICAgfVxuICB9IGZpbmFsbHkge1xuICAgIGF3YWl0IHJlYWRlci5jYW5jZWwoKTtcbiAgfVxufTtcblxuZXhwb3J0IGNvbnN0IHRyYWNrU3RyZWFtID0gKHN0cmVhbSwgY2h1bmtTaXplLCBvblByb2dyZXNzLCBvbkZpbmlzaCkgPT4ge1xuICBjb25zdCBpdGVyYXRvciA9IHJlYWRCeXRlcyhzdHJlYW0sIGNodW5rU2l6ZSk7XG5cbiAgbGV0IGJ5dGVzID0gMDtcbiAgbGV0IGRvbmU7XG4gIGxldCBfb25GaW5pc2ggPSAoZSkgPT4ge1xuICAgIGlmICghZG9uZSkge1xuICAgICAgZG9uZSA9IHRydWU7XG4gICAgICBvbkZpbmlzaCAmJiBvbkZpbmlzaChlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIG5ldyBSZWFkYWJsZVN0cmVhbShcbiAgICB7XG4gICAgICBhc3luYyBwdWxsKGNvbnRyb2xsZXIpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCB7IGRvbmUsIHZhbHVlIH0gPSBhd2FpdCBpdGVyYXRvci5uZXh0KCk7XG5cbiAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgX29uRmluaXNoKCk7XG4gICAgICAgICAgICBjb250cm9sbGVyLmNsb3NlKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgbGV0IGxlbiA9IHZhbHVlLmJ5dGVMZW5ndGg7XG4gICAgICAgICAgaWYgKG9uUHJvZ3Jlc3MpIHtcbiAgICAgICAgICAgIGxldCBsb2FkZWRCeXRlcyA9IChieXRlcyArPSBsZW4pO1xuICAgICAgICAgICAgb25Qcm9ncmVzcyhsb2FkZWRCeXRlcyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnRyb2xsZXIuZW5xdWV1ZShuZXcgVWludDhBcnJheSh2YWx1ZSkpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBfb25GaW5pc2goZXJyKTtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBjYW5jZWwocmVhc29uKSB7XG4gICAgICAgIF9vbkZpbmlzaChyZWFzb24pO1xuICAgICAgICByZXR1cm4gaXRlcmF0b3IucmV0dXJuKCk7XG4gICAgICB9LFxuICAgIH0sXG4gICAge1xuICAgICAgaGlnaFdhdGVyTWFyazogMixcbiAgICB9XG4gICk7XG59O1xuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuY29uc3QgQ1JMRiA9ICdcXHJcXG4nO1xuY29uc3Qgbm9ybWFsaXplTGluZXMgPSAodmFsdWUpID0+IFN0cmluZyh2YWx1ZSkucmVwbGFjZSgvXFxyXFxufFxccnxcXG4vZywgQ1JMRik7XG5jb25zdCBlc2NhcGVOYW1lID0gKHZhbHVlKSA9PlxuICBTdHJpbmcodmFsdWUpLnJlcGxhY2UoL1tcXHJcXG5cIl0vZywgKGNoYXIpID0+XG4gICAgY2hhciA9PT0gJ1xccicgPyAnJTBEJyA6IGNoYXIgPT09ICdcXG4nID8gJyUwQScgOiAnJTIyJ1xuICApO1xuXG4vLyBDb3VudCBVVEYtOCBieXRlcyB3aXRob3V0IGFsbG9jYXRpbmcgYW4gZW5jb2RlZCBjb3B5IG9mIGEgZmllbGQuIEZvcm1EYXRhXG4vLyBzdHJpbmcgdmFsdWVzIG5vcm1hbGl6ZSBsaW5lIGVuZGluZ3M7IEJsb2IvRmlsZSBjb250ZW50cyByZW1haW4gdW5jaGFuZ2VkLlxuY29uc3Qgc3RyaW5nQnl0ZXMgPSAodmFsdWUsIG5vcm1hbGl6ZSkgPT4ge1xuICBsZXQgbGVuZ3RoID0gMDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNvZGUgPSB2YWx1ZS5jaGFyQ29kZUF0KGkpO1xuICAgIGlmIChub3JtYWxpemUgJiYgKGNvZGUgPT09IDEzIHx8IGNvZGUgPT09IDEwKSkge1xuICAgICAgaWYgKGNvZGUgPT09IDEzICYmIHZhbHVlLmNoYXJDb2RlQXQoaSArIDEpID09PSAxMCkgaSsrO1xuICAgICAgbGVuZ3RoICs9IDI7XG4gICAgfSBlbHNlIGlmIChjb2RlIDwgMHg4MCkge1xuICAgICAgbGVuZ3RoKys7XG4gICAgfSBlbHNlIGlmIChjb2RlIDwgMHg4MDApIHtcbiAgICAgIGxlbmd0aCArPSAyO1xuICAgIH0gZWxzZSBpZiAoXG4gICAgICBjb2RlID49IDB4ZDgwMCAmJlxuICAgICAgY29kZSA8PSAweGRiZmYgJiZcbiAgICAgIHZhbHVlLmNoYXJDb2RlQXQoaSArIDEpID49IDB4ZGMwMCAmJlxuICAgICAgdmFsdWUuY2hhckNvZGVBdChpICsgMSkgPD0gMHhkZmZmXG4gICAgKSB7XG4gICAgICBsZW5ndGggKz0gNDtcbiAgICAgIGkrKztcbiAgICB9IGVsc2Uge1xuICAgICAgbGVuZ3RoICs9IDM7XG4gICAgfVxuICB9XG4gIHJldHVybiBsZW5ndGg7XG59O1xuXG4vLyBEZXNjcmliZSBzZXJpYWxpemF0aW9uIGZhaWx1cmVzIGluZGVwZW5kZW50bHkgb2YgYW55IHJlcXVlc3QgbGlicmFyeS5cbmV4cG9ydCBjbGFzcyBGb3JtRGF0YUVycm9yIGV4dGVuZHMgVHlwZUVycm9yIHtcbiAgY29uc3RydWN0b3IobWVzc2FnZSwgcmVhc29uKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0Zvcm1EYXRhRXJyb3InO1xuICAgIHRoaXMucmVhc29uID0gcmVhc29uO1xuICB9XG59XG5cbi8vIFRoZSBjYWxsZXIgc3VwcGxpZXMgdGhlIGJvdW5kYXJ5LCBCbG9iIGltcGxlbWVudGF0aW9uLCBhbmQgbGltaXQgZXJyb3IuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBmb3JtRGF0YVRvQmxvYihmb3JtLCBCbG9iLCBsaW1pdCwgbGltaXRFcnJvciwgYm91bmRhcnkpIHtcbiAgaWYgKCF1dGlscy5pc0Z1bmN0aW9uKEJsb2IpKSB7XG4gICAgdGhyb3cgbmV3IEZvcm1EYXRhRXJyb3IoJ0Jsb2IgaXMgbm90IHN1cHBvcnRlZCcsICdibG9iJyk7XG4gIH1cblxuICBpZiAoXG4gICAgIXV0aWxzLmlzU3RyaW5nKGJvdW5kYXJ5KSB8fFxuICAgICEvXltBLVphLXowLTknKCkrXywuLzo9PyAtXXsxLDcwfSQvLnRlc3QoYm91bmRhcnkpIHx8XG4gICAgLyAkLy50ZXN0KGJvdW5kYXJ5KVxuICApIHtcbiAgICB0aHJvdyBuZXcgRm9ybURhdGFFcnJvcignSW52YWxpZCBtdWx0aXBhcnQgYm91bmRhcnknLCAnYm91bmRhcnknKTtcbiAgfVxuICBjb25zdCBmb290ZXIgPSAnLS0nICsgYm91bmRhcnkgKyAnLS0nICsgQ1JMRjtcbiAgbGV0IGxlbmd0aCA9IGZvb3Rlci5sZW5ndGg7XG4gIGNvbnN0IHBhcnRzID0gW107XG4gIGNvbnN0IGNoZWNrTGVuZ3RoID0gKGV4dHJhKSA9PiB7XG4gICAgaWYgKGxlbmd0aCArIGV4dHJhID4gbGltaXQpIHRocm93IGxpbWl0RXJyb3IoKTtcbiAgfTtcbiAgY2hlY2tMZW5ndGgoMCk7XG5cbiAgZm9yIChjb25zdCBbbmFtZSwgdmFsdWVdIG9mIGZvcm0pIHtcbiAgICBjb25zdCBpc1N0cmluZyA9IHV0aWxzLmlzU3RyaW5nKHZhbHVlKTtcbiAgICBjb25zdCB2YWx1ZUxlbmd0aCA9IGlzU3RyaW5nID8gc3RyaW5nQnl0ZXModmFsdWUsIHRydWUpIDogdmFsdWUuc2l6ZTtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZSh2YWx1ZUxlbmd0aCkgfHwgdmFsdWVMZW5ndGggPCAwKSB7XG4gICAgICB0aHJvdyBuZXcgRm9ybURhdGFFcnJvcignVW5zdXBwb3J0ZWQgRm9ybURhdGEgcGFydCBzaXplJywgJ3BhcnQnKTtcbiAgICB9XG4gICAgLy8gUmVqZWN0IGxhcmdlIHZhbHVlcyBhbmQgbmFtZXMgYmVmb3JlIGJ1aWxkaW5nIG5vcm1hbGl6ZWQgaGVhZGVyIHN0cmluZ3MuXG4gICAgY2hlY2tMZW5ndGgoXG4gICAgICB2YWx1ZUxlbmd0aCArXG4gICAgICAgIHN0cmluZ0J5dGVzKG5hbWUsIHRydWUpICtcbiAgICAgICAgKCFpc1N0cmluZyAmJiB2YWx1ZS5uYW1lID8gc3RyaW5nQnl0ZXModmFsdWUubmFtZSwgZmFsc2UpIDogMCkgK1xuICAgICAgICAoIWlzU3RyaW5nICYmIHZhbHVlLnR5cGUgPyBzdHJpbmdCeXRlcyh2YWx1ZS50eXBlLCBmYWxzZSkgOiAwKVxuICAgICk7XG5cbiAgICBsZXQgaGVhZGVyID1cbiAgICAgICctLScgK1xuICAgICAgYm91bmRhcnkgK1xuICAgICAgQ1JMRiArXG4gICAgICAnQ29udGVudC1EaXNwb3NpdGlvbjogZm9ybS1kYXRhOyBuYW1lPVwiJyArXG4gICAgICBlc2NhcGVOYW1lKG5vcm1hbGl6ZUxpbmVzKG5hbWUpKSArXG4gICAgICAnXCInO1xuICAgIGlmICghaXNTdHJpbmcpIHtcbiAgICAgIGhlYWRlciArPVxuICAgICAgICAnOyBmaWxlbmFtZT1cIicgK1xuICAgICAgICBlc2NhcGVOYW1lKHV0aWxzLmlzU3RyaW5nKHZhbHVlLm5hbWUpID8gdmFsdWUubmFtZSA6ICdibG9iJykgK1xuICAgICAgICAnXCInICtcbiAgICAgICAgQ1JMRiArXG4gICAgICAgICdDb250ZW50LVR5cGU6ICcgK1xuICAgICAgICBTdHJpbmcodmFsdWUudHlwZSB8fCAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJykucmVwbGFjZSgvW1xcclxcbl0vZywgJycpO1xuICAgIH1cbiAgICBoZWFkZXIgKz0gQ1JMRiArIENSTEY7XG4gICAgY29uc3QgcGFydExlbmd0aCA9IHN0cmluZ0J5dGVzKGhlYWRlciwgZmFsc2UpICsgdmFsdWVMZW5ndGggKyBDUkxGLmxlbmd0aDtcbiAgICBjaGVja0xlbmd0aChwYXJ0TGVuZ3RoKTtcbiAgICBsZW5ndGggKz0gcGFydExlbmd0aDtcbiAgICBwYXJ0cy5wdXNoKHsgaGVhZGVyLCB2YWx1ZSwgaXNTdHJpbmcgfSk7XG4gIH1cblxuICAvLyBOYXRpdmUgQmxvYiBjb21wb3NpdGlvbiByZXRhaW5zIGV4aXN0aW5nIEJsb2IvRmlsZSBkYXRhLiBObyBmaWxlIGlzIHJlYWRcbiAgLy8gYW5kIG5vIGNvbXBsZXRlIG11bHRpcGFydCBBcnJheUJ1ZmZlciBpcyBjcmVhdGVkIHRvIGRldGVybWluZSBpdHMgbGVuZ3RoLlxuICBjb25zdCBibG9iUGFydHMgPSBbXTtcbiAgZm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzKSB7XG4gICAgYmxvYlBhcnRzLnB1c2gocGFydC5oZWFkZXIsIHBhcnQuaXNTdHJpbmcgPyBub3JtYWxpemVMaW5lcyhwYXJ0LnZhbHVlKSA6IHBhcnQudmFsdWUsIENSTEYpO1xuICB9XG4gIGJsb2JQYXJ0cy5wdXNoKGZvb3Rlcik7XG4gIHJldHVybiBuZXcgQmxvYihibG9iUGFydHMsIHsgdHlwZTogJ211bHRpcGFydC9mb3JtLWRhdGE7IGJvdW5kYXJ5PScgKyBib3VuZGFyeSB9KTtcbn1cbiIsImltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCBmb3JtRGF0YVRvQmxvYiwgeyBGb3JtRGF0YUVycm9yIH0gZnJvbSAnLi4vaGVscGVycy9mb3JtRGF0YVRvQmxvYi5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZU11bHRpcGFydEJvZHkoZm9ybSwgQmxvYiwgbGltaXQsIGxpbWl0RXJyb3IsIGJvdW5kYXJ5KSB7XG4gIC8vIFJlcG9ydCBtaXNzaW5nIEJsb2Igc3VwcG9ydCBiZWZvcmUgdHJ5aW5nIHRvIHNlbGVjdCBhIHJhbmRvbSBzb3VyY2UuXG4gIGlmICghdXRpbHMuaXNGdW5jdGlvbihCbG9iKSkge1xuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdCbG9iIGlzIG5vdCBzdXBwb3J0ZWQnLCBBeGlvc0Vycm9yLkVSUl9OT1RfU1VQUE9SVCk7XG4gIH1cblxuICBpZiAoYm91bmRhcnkgPT09IHVuZGVmaW5lZCkge1xuICAgIGlmICh1dGlscy5pc0Z1bmN0aW9uKHBsYXRmb3JtLmdlbmVyYXRlU3RyaW5nKSkge1xuICAgICAgYm91bmRhcnkgPSAnYXhpb3MtJyArIHBsYXRmb3JtLmdlbmVyYXRlU3RyaW5nKDM2LCAnMDEyMzQ1Njc4OWFiY2RlZicpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBjcnlwdG8gPSB1dGlscy5nbG9iYWwuY3J5cHRvO1xuICAgICAgaWYgKCFjcnlwdG8gfHwgIXV0aWxzLmlzRnVuY3Rpb24oY3J5cHRvLmdldFJhbmRvbVZhbHVlcykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoJ1JhbmRvbSBieXRlIGdlbmVyYXRpb24gaXMgbm90IHN1cHBvcnRlZCcsIEF4aW9zRXJyb3IuRVJSX05PVF9TVVBQT1JUKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJhbmRvbSA9IG5ldyBVaW50OEFycmF5KDE4KTtcbiAgICAgIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMocmFuZG9tKTtcbiAgICAgIGJvdW5kYXJ5ID1cbiAgICAgICAgJ2F4aW9zLScgKyBBcnJheS5mcm9tKHJhbmRvbSwgKHZhbHVlKSA9PiAoJzAnICsgdmFsdWUudG9TdHJpbmcoMTYpKS5zbGljZSgtMikpLmpvaW4oJycpO1xuICAgIH1cbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIGZvcm1EYXRhVG9CbG9iKGZvcm0sIEJsb2IsIGxpbWl0LCBsaW1pdEVycm9yLCBib3VuZGFyeSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRm9ybURhdGFFcnJvcikge1xuICAgICAgY29uc3QgY29kZSA9XG4gICAgICAgIGVycm9yLnJlYXNvbiA9PT0gJ2JvdW5kYXJ5JyA/IEF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT05fVkFMVUUgOiBBeGlvc0Vycm9yLkVSUl9CQURfUkVRVUVTVDtcbiAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKGVycm9yLm1lc3NhZ2UsIGNvZGUpO1xuICAgIH1cbiAgICB0aHJvdyBlcnJvcjtcbiAgfVxufVxuIiwiLyoqXG4gKiBFc3RpbWF0ZSBkYXRhOiBVUkwgYnl0ZSBsZW5ndGhzICp3aXRob3V0KiBhbGxvY2F0aW5nIGxhcmdlIGJ1ZmZlcnMuXG4gKiAtIEZldGNoIHBlcmNlbnQtZGVjb2RlcyBhIGJhc2U2NCBib2R5IGJlZm9yZSBkZWNvZGluZyBpdC5cbiAqIC0gTm9kZSdzIEJ1ZmZlci5mcm9tKGJvZHksICdiYXNlNjQnKSBzaXplcyBpdHMgYmFja2luZyBhbGxvY2F0aW9uIGZyb20gdGhlXG4gKiAgIHBlcmNlbnQtZGVjb2RlZCBib2R5LCBpbmNsdWRpbmcgaWdub3JlZCBjaGFyYWN0ZXJzIGFuZCBjb250ZW50IGFmdGVyIHBhZGRpbmcuXG4gKiAtIE5vbi1iYXNlNjQgZGF0YSBpcyBwZXJjZW50LWRlY29kZWQgYW5kIHRoZW4gZW5jb2RlZCBhcyBVVEYtOC5cbiAqL1xuY29uc3QgaXNIZXhEaWdpdCA9IChjaGFyQ29kZSkgPT5cbiAgKGNoYXJDb2RlID49IDQ4ICYmIGNoYXJDb2RlIDw9IDU3KSB8fFxuICAoY2hhckNvZGUgPj0gNjUgJiYgY2hhckNvZGUgPD0gNzApIHx8XG4gIChjaGFyQ29kZSA+PSA5NyAmJiBjaGFyQ29kZSA8PSAxMDIpO1xuXG5jb25zdCBpc1BlcmNlbnRFbmNvZGVkQnl0ZSA9IChzdHIsIGksIGxlbikgPT5cbiAgaSArIDIgPCBsZW4gJiYgaXNIZXhEaWdpdChzdHIuY2hhckNvZGVBdChpICsgMSkpICYmIGlzSGV4RGlnaXQoc3RyLmNoYXJDb2RlQXQoaSArIDIpKTtcblxuY29uc3QgaGV4VmFsdWUgPSAoY2hhckNvZGUpID0+IChjaGFyQ29kZSA8PSA1NyA/IGNoYXJDb2RlIC0gNDggOiAoY2hhckNvZGUgJiAweGRmKSAtIDU1KTtcblxuY29uc3QgaXNCYXNlNjRDaGFyID0gKGNoYXJDb2RlKSA9PlxuICAoY2hhckNvZGUgPj0gNjUgJiYgY2hhckNvZGUgPD0gOTApIHx8IC8vIEEtWlxuICAoY2hhckNvZGUgPj0gOTcgJiYgY2hhckNvZGUgPD0gMTIyKSB8fCAvLyBhLXpcbiAgKGNoYXJDb2RlID49IDQ4ICYmIGNoYXJDb2RlIDw9IDU3KSB8fCAvLyAwLTlcbiAgY2hhckNvZGUgPT09IDQzIHx8IC8vICtcbiAgY2hhckNvZGUgPT09IDQ3IHx8IC8vIC9cbiAgY2hhckNvZGUgPT09IDQ1IHx8IC8vIC0gKGJhc2U2NHVybClcbiAgY2hhckNvZGUgPT09IDk1OyAvLyBfIChiYXNlNjR1cmwpXG5cbmNvbnN0IGlzQmFzZTY0V2hpdGVzcGFjZSA9IChjaGFyQ29kZSkgPT5cbiAgY2hhckNvZGUgPT09IDkgfHwgY2hhckNvZGUgPT09IDEwIHx8IGNoYXJDb2RlID09PSAxMiB8fCBjaGFyQ29kZSA9PT0gMTMgfHwgY2hhckNvZGUgPT09IDMyO1xuXG5jb25zdCBiYXNlNjRCeXRlcyA9IChzaWduaWZpY2FudCkgPT4ge1xuICBjb25zdCBncm91cHMgPSBNYXRoLmZsb29yKHNpZ25pZmljYW50IC8gNCk7XG4gIGNvbnN0IHJlbWFpbmRlciA9IHNpZ25pZmljYW50ICUgNDtcbiAgcmV0dXJuIGdyb3VwcyAqIDMgKyAocmVtYWluZGVyID09PSAyID8gMSA6IHJlbWFpbmRlciA9PT0gMyA/IDIgOiAwKTtcbn07XG5cbi8vIEJ1ZmZlci5ieXRlTGVuZ3RoKGJvZHksICdiYXNlNjQnKSB1c2VzIHRoZSByYXcgc3RyaW5nIGxlbmd0aCBhcyBhbiBhbGxvY2F0aW9uXG4vLyB1cHBlciBib3VuZCBldmVuIHdoZW4gQnVmZmVyLmZyb20gbGF0ZXIgaWdub3JlcyBjaGFyYWN0ZXJzIG9yIHN0b3BzIGF0ICc9Jy5cbmNvbnN0IGVzdGltYXRlQmFzZTY0QnVmZmVyQWxsb2NhdGlvbiA9IChib2R5KSA9PiB7XG4gIGNvbnN0IGxlbiA9IGJvZHkubGVuZ3RoO1xuICBsZXQgcGFkZGluZyA9IDA7XG5cbiAgaWYgKGxlbiA+IDAgJiYgYm9keS5jaGFyQ29kZUF0KGxlbiAtIDEpID09PSA2MSAvKiAnPScgKi8pIHtcbiAgICBwYWRkaW5nKys7XG5cbiAgICBpZiAobGVuID4gMSAmJiBib2R5LmNoYXJDb2RlQXQobGVuIC0gMikgPT09IDYxIC8qICc9JyAqLykge1xuICAgICAgcGFkZGluZysrO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBNYXRoLmZsb29yKCgobGVuIC0gcGFkZGluZykgKiAzKSAvIDQpO1xufTtcblxuY29uc3QgZXN0aW1hdGVQZXJjZW50RGVjb2RlZEJhc2U2NEJ1ZmZlckFsbG9jYXRpb24gPSAoYm9keSkgPT4ge1xuICAvLyBPcmRpbmFyeSBCYXNlNjQgbmVlZHMgb25seSBpdHMgbGVuZ3RoIGFuZCB0cmFpbGluZyBwYWRkaW5nLlxuICBpZiAoYm9keS5pbmRleE9mKCclJykgPT09IC0xKSB7XG4gICAgcmV0dXJuIGVzdGltYXRlQmFzZTY0QnVmZmVyQWxsb2NhdGlvbihib2R5KTtcbiAgfVxuXG4gIGxldCBsZW5ndGggPSAwO1xuICBsZXQgcHJldmlvdXMgPSAwO1xuICBsZXQgbGFzdCA9IDA7XG5cbiAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGJvZHkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICBsZXQgY29kZSA9IGJvZHkuY2hhckNvZGVBdChpKTtcbiAgICBpZiAoY29kZSA9PT0gMzcgLyogJyUnICovICYmIGlzUGVyY2VudEVuY29kZWRCeXRlKGJvZHksIGksIGxlbikpIHtcbiAgICAgIGNvZGUgPSBoZXhWYWx1ZShib2R5LmNoYXJDb2RlQXQoaSArIDEpKSAqIDE2ICsgaGV4VmFsdWUoYm9keS5jaGFyQ29kZUF0KGkgKyAyKSk7XG4gICAgICBpICs9IDI7XG4gICAgfVxuICAgIGxlbmd0aCsrO1xuICAgIHByZXZpb3VzID0gbGFzdDtcbiAgICBsYXN0ID0gY29kZTtcbiAgfVxuXG4gIGNvbnN0IHBhZGRpbmcgPSBsYXN0ID09PSA2MSA/IChwcmV2aW91cyA9PT0gNjEgPyAyIDogMSkgOiAwO1xuICByZXR1cm4gTWF0aC5mbG9vcigoKGxlbmd0aCAtIHBhZGRpbmcpICogMykgLyA0KTtcbn07XG5cbmNvbnN0IGVzdGltYXRlUGVyY2VudERlY29kZWRCYXNlNjRCeXRlcyA9IChib2R5KSA9PiB7XG4gIGNvbnN0IGxlbiA9IGJvZHkubGVuZ3RoO1xuICBsZXQgc2lnbmlmaWNhbnQgPSAwO1xuICBsZXQgcGFkZGluZyA9IDA7XG4gIGxldCBpbnZhbGlkID0gZmFsc2U7XG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIGxldCBjb2RlID0gYm9keS5jaGFyQ29kZUF0KGkpO1xuXG4gICAgaWYgKGNvZGUgPT09IDM3IC8qICclJyAqLyAmJiBpc1BlcmNlbnRFbmNvZGVkQnl0ZShib2R5LCBpLCBsZW4pKSB7XG4gICAgICBjb2RlID0gaGV4VmFsdWUoYm9keS5jaGFyQ29kZUF0KGkgKyAxKSkgKiAxNiArIGhleFZhbHVlKGJvZHkuY2hhckNvZGVBdChpICsgMikpO1xuICAgICAgaSArPSAyO1xuICAgIH1cblxuICAgIGlmIChpc0Jhc2U2NFdoaXRlc3BhY2UoY29kZSkpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmIChjb2RlID09PSA2MSAvKiAnPScgKi8pIHtcbiAgICAgIHBhZGRpbmcrKztcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmICghaXNCYXNlNjRDaGFyKGNvZGUpIHx8IHBhZGRpbmcgPiAwKSB7XG4gICAgICBpbnZhbGlkID0gdHJ1ZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIHNpZ25pZmljYW50Kys7XG4gIH1cblxuICAvLyBGZXRjaCByZWplY3RzIG1hbGZvcm1lZCBmb3JnaXZpbmctYmFzZTY0IGlucHV0LiBSZXR1cm5pbmcgdGhlIHJhdy1zaXplXG4gIC8vIGFsbG9jYXRpb24gYm91bmQga2VlcHMgdGhhdCBpbnZhbGlkIGlucHV0IGZyb20gYmVjb21pbmcgYSBwcmUtY2hlY2sgYnlwYXNzLlxuICBpZiAoXG4gICAgaW52YWxpZCB8fFxuICAgIHBhZGRpbmcgPiAyIHx8XG4gICAgKHBhZGRpbmcgPiAwICYmIChzaWduaWZpY2FudCArIHBhZGRpbmcpICUgNCAhPT0gMCkgfHxcbiAgICBzaWduaWZpY2FudCAlIDQgPT09IDFcbiAgKSB7XG4gICAgcmV0dXJuIGVzdGltYXRlQmFzZTY0QnVmZmVyQWxsb2NhdGlvbihib2R5KTtcbiAgfVxuXG4gIHJldHVybiBiYXNlNjRCeXRlcyhzaWduaWZpY2FudCk7XG59O1xuXG5jb25zdCBlc3RpbWF0ZURhdGFVUkxCeXRlcyA9ICh1cmwsIGVzdGltYXRlQmFzZTY0LCBiYXNlNjRQYXR0ZXJuKSA9PiB7XG4gIGlmICghdXJsIHx8IHR5cGVvZiB1cmwgIT09ICdzdHJpbmcnKSByZXR1cm4gMDtcbiAgaWYgKCEvXmRhdGE6L2kudGVzdCh1cmwpKSByZXR1cm4gMDtcblxuICBjb25zdCBjb21tYSA9IHVybC5pbmRleE9mKCcsJyk7XG4gIGlmIChjb21tYSA8IDApIHJldHVybiAwO1xuXG4gIGNvbnN0IG1ldGEgPSB1cmwuc2xpY2UoNSwgY29tbWEpO1xuICBjb25zdCBib2R5ID0gdXJsLnNsaWNlKGNvbW1hICsgMSk7XG4gIGNvbnN0IGlzQmFzZTY0ID0gYmFzZTY0UGF0dGVybi50ZXN0KG1ldGEpO1xuXG4gIGlmIChpc0Jhc2U2NCkge1xuICAgIHJldHVybiBlc3RpbWF0ZUJhc2U2NChib2R5KTtcbiAgfVxuXG4gIC8vIENvbXB1dGUgVVRGLTggYnl0ZSBsZW5ndGggZGlyZWN0bHkgZnJvbSBVVEYtMTYgY29kZSB1bml0cyB3aXRob3V0IGFsbG9jYXRpbmdcbiAgLy8gYSBieXRlIGJ1ZmZlciAoVGV4dEVuY29kZXIuZW5jb2RlIHdvdWxkIGRlZmVhdCB0aGUgRG9TIGd1YXJkIG9uIGxhcmdlIGJvZGllcykuXG4gIC8vIFZhbGlkICVYWCB0cmlwbGV0cyBjb3VudCBhcyBvbmUgZGVjb2RlZCBieXRlOyB0aGlzIG1hdGNoZXMgdGhlIGJ5dGVzIHRoYXRcbiAgLy8gZGVjb2RlVVJJQ29tcG9uZW50KGJvZHkpIHdvdWxkIHByb2R1Y2UgYmVmb3JlIEJ1ZmZlciByZS1lbmNvZGVzIHRoZSBzdHJpbmcuXG4gIGxldCBieXRlcyA9IDA7XG4gIGZvciAobGV0IGkgPSAwLCBsZW4gPSBib2R5Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgY29uc3QgYyA9IGJvZHkuY2hhckNvZGVBdChpKTtcbiAgICBpZiAoYyA9PT0gMzcgLyogJyUnICovICYmIGlzUGVyY2VudEVuY29kZWRCeXRlKGJvZHksIGksIGxlbikpIHtcbiAgICAgIGJ5dGVzICs9IDE7XG4gICAgICBpICs9IDI7XG4gICAgfSBlbHNlIGlmIChjIDwgMHg4MCkge1xuICAgICAgYnl0ZXMgKz0gMTtcbiAgICB9IGVsc2UgaWYgKGMgPCAweDgwMCkge1xuICAgICAgYnl0ZXMgKz0gMjtcbiAgICB9IGVsc2UgaWYgKGMgPj0gMHhkODAwICYmIGMgPD0gMHhkYmZmICYmIGkgKyAxIDwgbGVuKSB7XG4gICAgICBjb25zdCBuZXh0ID0gYm9keS5jaGFyQ29kZUF0KGkgKyAxKTtcbiAgICAgIGlmIChuZXh0ID49IDB4ZGMwMCAmJiBuZXh0IDw9IDB4ZGZmZikge1xuICAgICAgICBieXRlcyArPSA0O1xuICAgICAgICBpKys7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBieXRlcyArPSAzO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBieXRlcyArPSAzO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYnl0ZXM7XG59O1xuXG4vKipcbiAqIEVzdGltYXRlIHRoZSBwZXJjZW50LWRlY29kZWQgcGF5bG9hZCBzaXplIHVzZWQgYnkgRmV0Y2ggZGF0YTogVVJMcy5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBlc3RpbWF0ZURhdGFVUkxEZWNvZGVkQnl0ZXModXJsKSB7XG4gIC8vIEZldGNoIHJlbW92ZXMgVVJMIGZyYWdtZW50cyBiZWZvcmUgcHJvY2Vzc2luZyBhIGRhdGE6IFVSTC5cbiAgY29uc3QgZnJhZ21lbnRJbmRleCA9IHR5cGVvZiB1cmwgPT09ICdzdHJpbmcnID8gdXJsLmluZGV4T2YoJyMnKSA6IC0xO1xuXG4gIHJldHVybiBlc3RpbWF0ZURhdGFVUkxCeXRlcyhcbiAgICBmcmFnbWVudEluZGV4ID09PSAtMSA/IHVybCA6IHVybC5zbGljZSgwLCBmcmFnbWVudEluZGV4KSxcbiAgICBlc3RpbWF0ZVBlcmNlbnREZWNvZGVkQmFzZTY0Qnl0ZXMsXG4gICAgLzsgKmJhc2U2NFtcXHRcXG5cXGZcXHIgXSokL2lcbiAgKTtcbn1cblxuLyoqXG4gKiBFc3RpbWF0ZSB0aGUgQnVmZmVyIGJhY2tpbmcgYWxsb2NhdGlvbiB1c2VkIGFmdGVyIE5vZGUncyBwZXJjZW50LWRlY29kaW5nIHN0ZXAuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICogQHJldHVybnMge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVzdGltYXRlRGF0YVVSTEJ1ZmZlckFsbG9jYXRpb24odXJsKSB7XG4gIC8vIE1hdGNoIGZyb21EYXRhVVJJJ3MgY2FzZS1pbnNlbnNpdGl2ZSBwcm90b2NvbCBhbmQgZW5jb2Rpbmcgc3VmZml4LlxuICByZXR1cm4gZXN0aW1hdGVEYXRhVVJMQnl0ZXModXJsLCBlc3RpbWF0ZVBlcmNlbnREZWNvZGVkQmFzZTY0QnVmZmVyQWxsb2NhdGlvbiwgLztiYXNlNjQkL2kpO1xufVxuIiwiZXhwb3J0IGNvbnN0IFZFUlNJT04gPSBcIjEuMjEuMFwiOyIsImltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCBjb21wb3NlU2lnbmFscyBmcm9tICcuLi9oZWxwZXJzL2NvbXBvc2VTaWduYWxzLmpzJztcbmltcG9ydCB7IHRyYWNrU3RyZWFtIH0gZnJvbSAnLi4vaGVscGVycy90cmFja1N0cmVhbS5qcyc7XG5pbXBvcnQgY3JlYXRlTXVsdGlwYXJ0Qm9keSBmcm9tICcuLi9jb3JlL2NyZWF0ZU11bHRpcGFydEJvZHkuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQge1xuICBwcm9ncmVzc0V2ZW50UmVkdWNlcixcbiAgcHJvZ3Jlc3NFdmVudERlY29yYXRvcixcbiAgYXN5bmNEZWNvcmF0b3IsXG59IGZyb20gJy4uL2hlbHBlcnMvcHJvZ3Jlc3NFdmVudFJlZHVjZXIuanMnO1xuaW1wb3J0IHJlc29sdmVDb25maWcgZnJvbSAnLi4vaGVscGVycy9yZXNvbHZlQ29uZmlnLmpzJztcbmltcG9ydCBzZXR0bGUgZnJvbSAnLi4vY29yZS9zZXR0bGUuanMnO1xuaW1wb3J0IGVzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcyBmcm9tICcuLi9oZWxwZXJzL2VzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcy5qcyc7XG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSAnLi4vZW52L2RhdGEuanMnO1xuaW1wb3J0IHsgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0IH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgREVGQVVMVF9DSFVOS19TSVpFID0gNjQgKiAxMDI0O1xuXG5jb25zdCBERUZBVUxUX1JFUVVFU1RfT1BUSU9OUyA9IHtcbiAgY2FjaGU6ICdkZWZhdWx0JyxcbiAgcmVkaXJlY3Q6ICdmb2xsb3cnLFxuICByZWZlcnJlcjogJ2Fib3V0OmNsaWVudCcsXG4gIHJlZmVycmVyUG9saWN5OiAnJyxcbiAgbW9kZTogJ2NvcnMnLFxuICBpbnRlZ3JpdHk6ICcnLFxuICBrZWVwYWxpdmU6IGZhbHNlLFxuICBwcmlvcml0eTogJ2F1dG8nLFxuICB3aW5kb3c6IG51bGwsXG59O1xuXG5jb25zdCB7IGlzRnVuY3Rpb24gfSA9IHV0aWxzO1xuXG4vKipcbiAqIEVuY29kZSBhIFVURi04IHN0cmluZyB0byBhIExhdGluLTEgYnl0ZSBzdHJpbmcgZm9yIHVzZSB3aXRoIGJ0b2EoKS5cbiAqIFRoaXMgaXMgYSBtb2Rlcm4gcmVwbGFjZW1lbnQgZm9yIHRoZSBkZXByZWNhdGVkIHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChzdHIpKSBwYXR0ZXJuLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgVGhlIHN0cmluZyB0byBlbmNvZGVcbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBVVEYtOCBieXRlcyBhcyBhIExhdGluLTEgc3RyaW5nXG4gKi9cbmNvbnN0IGVuY29kZVVURjggPSAoc3RyKSA9PlxuICBlbmNvZGVVUklDb21wb25lbnQoc3RyKS5yZXBsYWNlKC8lKFswLTlBLUZdezJ9KS9naSwgKF8sIGhleCkgPT5cbiAgICBTdHJpbmcuZnJvbUNoYXJDb2RlKHBhcnNlSW50KGhleCwgMTYpKVxuICApO1xuXG4vLyBOb2RlJ3MgV0hBVFdHIFVSTCBwYXJzZXIgcmV0dXJucyBgdXNlcm5hbWVgIGFuZCBgcGFzc3dvcmRgIHBlcmNlbnQtZW5jb2RlZC5cbi8vIERlY29kZSBiZWZvcmUgY29tcG9zaW5nIHRoZSBgYXV0aGAgb3B0aW9uIHNvIGNyZWRlbnRpYWxzIHN1Y2ggYXNcbi8vIGBteSU0MGVtYWlsLmNvbTpwYXNzYCBhcmUgc2VudCBhcyBgbXlAZW1haWwuY29tOnBhc3NgLiBGYWxscyBiYWNrIHRvIHRoZVxuLy8gb3JpZ2luYWwgdmFsdWUgZm9yIG1hbGZvcm1lZCBpbnB1dCBzbyBhIGJhZCBlbmNvZGluZyBuZXZlciB0aHJvd3MuXG5jb25zdCBkZWNvZGVVUklDb21wb25lbnRTYWZlID0gKHZhbHVlKSA9PiB7XG4gIGlmICghdXRpbHMuaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbn07XG5cbmNvbnN0IHRlc3QgPSAoZm4sIC4uLmFyZ3MpID0+IHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gISFmbiguLi5hcmdzKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuY29uc3QgbWF5YmVXaXRoQXV0aENyZWRlbnRpYWxzID0gKHVybCkgPT4ge1xuICBjb25zdCBwcm90b2NvbEluZGV4ID0gdXJsLmluZGV4T2YoJzovLycpO1xuICBsZXQgdXJsVG9DaGVjayA9IHVybDtcbiAgaWYgKHByb3RvY29sSW5kZXggIT09IC0xKSB7XG4gICAgdXJsVG9DaGVjayA9IHVybFRvQ2hlY2suc2xpY2UocHJvdG9jb2xJbmRleCArIDMpO1xuICB9XG4gIHJldHVybiB1cmxUb0NoZWNrLmluY2x1ZGVzKCdAJykgfHwgdXJsVG9DaGVjay5pbmNsdWRlcygnOicpO1xufTtcblxuY29uc3QgZmFjdG9yeSA9IChlbnYpID0+IHtcbiAgY29uc3QgZ2xvYmFsT2JqZWN0ID1cbiAgICB1dGlscy5nbG9iYWwgIT09IHVuZGVmaW5lZCAmJiB1dGlscy5nbG9iYWwgIT09IG51bGwgPyB1dGlscy5nbG9iYWwgOiBnbG9iYWxUaGlzO1xuICBjb25zdCB7IFJlYWRhYmxlU3RyZWFtLCBUZXh0RW5jb2RlciB9ID0gZ2xvYmFsT2JqZWN0O1xuXG4gIGVudiA9IHV0aWxzLm1lcmdlLmNhbGwoXG4gICAge1xuICAgICAgc2tpcFVuZGVmaW5lZDogdHJ1ZSxcbiAgICB9LFxuICAgIHtcbiAgICAgIFJlcXVlc3Q6IGdsb2JhbE9iamVjdC5SZXF1ZXN0LFxuICAgICAgUmVzcG9uc2U6IGdsb2JhbE9iamVjdC5SZXNwb25zZSxcbiAgICAgIEJsb2I6IGdsb2JhbE9iamVjdC5CbG9iLFxuICAgIH0sXG4gICAgZW52XG4gICk7XG5cbiAgY29uc3QgZW52RmV0Y2ggPSB1dGlscy5oYXNPd25Qcm9wKGVudiwgJ2ZldGNoJykgPyBlbnYuZmV0Y2ggOiB1bmRlZmluZWQ7XG4gIGNvbnN0IHsgUmVxdWVzdCwgUmVzcG9uc2UsIEJsb2IgfSA9IGVudjtcbiAgY29uc3QgaXNGZXRjaFN1cHBvcnRlZCA9IGVudkZldGNoID8gaXNGdW5jdGlvbihlbnZGZXRjaCkgOiB0eXBlb2YgZmV0Y2ggPT09ICdmdW5jdGlvbic7XG4gIGNvbnN0IGlzUmVxdWVzdFN1cHBvcnRlZCA9IGlzRnVuY3Rpb24oUmVxdWVzdCk7XG4gIGNvbnN0IGlzUmVzcG9uc2VTdXBwb3J0ZWQgPSBpc0Z1bmN0aW9uKFJlc3BvbnNlKTtcblxuICBpZiAoIWlzRmV0Y2hTdXBwb3J0ZWQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBjb25zdCBpc1JlYWRhYmxlU3RyZWFtU3VwcG9ydGVkID0gaXNGZXRjaFN1cHBvcnRlZCAmJiBpc0Z1bmN0aW9uKFJlYWRhYmxlU3RyZWFtKTtcblxuICBjb25zdCBlbmNvZGVUZXh0ID1cbiAgICBpc0ZldGNoU3VwcG9ydGVkICYmXG4gICAgKHR5cGVvZiBUZXh0RW5jb2RlciA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgPyAoXG4gICAgICAgICAgKGVuY29kZXIpID0+IChzdHIpID0+XG4gICAgICAgICAgICBlbmNvZGVyLmVuY29kZShzdHIpXG4gICAgICAgICkobmV3IFRleHRFbmNvZGVyKCkpXG4gICAgICA6IGFzeW5jIChzdHIpID0+IG5ldyBVaW50OEFycmF5KGF3YWl0IG5ldyBSZXF1ZXN0KHN0cikuYXJyYXlCdWZmZXIoKSkpO1xuXG4gIGNvbnN0IHN1cHBvcnRzUmVxdWVzdFN0cmVhbSA9XG4gICAgaXNSZXF1ZXN0U3VwcG9ydGVkICYmXG4gICAgaXNSZWFkYWJsZVN0cmVhbVN1cHBvcnRlZCAmJlxuICAgIHRlc3QoKCkgPT4ge1xuICAgICAgbGV0IGR1cGxleEFjY2Vzc2VkID0gZmFsc2U7XG5cbiAgICAgIGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdChwbGF0Zm9ybS5vcmlnaW4sIHtcbiAgICAgICAgYm9keTogbmV3IFJlYWRhYmxlU3RyZWFtKCksXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBnZXQgZHVwbGV4KCkge1xuICAgICAgICAgIGR1cGxleEFjY2Vzc2VkID0gdHJ1ZTtcbiAgICAgICAgICByZXR1cm4gJ2hhbGYnO1xuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IGhhc0NvbnRlbnRUeXBlID0gcmVxdWVzdC5oZWFkZXJzLmhhcygnQ29udGVudC1UeXBlJyk7XG5cbiAgICAgIGlmIChyZXF1ZXN0LmJvZHkgIT0gbnVsbCkge1xuICAgICAgICByZXF1ZXN0LmJvZHkuY2FuY2VsKCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBkdXBsZXhBY2Nlc3NlZCAmJiAhaGFzQ29udGVudFR5cGU7XG4gICAgfSk7XG5cbiAgY29uc3Qgc3VwcG9ydHNSZXNwb25zZVN0cmVhbSA9XG4gICAgaXNSZXNwb25zZVN1cHBvcnRlZCAmJlxuICAgIGlzUmVhZGFibGVTdHJlYW1TdXBwb3J0ZWQgJiZcbiAgICB0ZXN0KCgpID0+IHV0aWxzLmlzUmVhZGFibGVTdHJlYW0obmV3IFJlc3BvbnNlKCcnKS5ib2R5KSk7XG5cbiAgLy8gU29tZSBydW50aW1lcyByZWplY3QgZXZlcnkgZXhwbGljaXQgY2FjaGUgbW9kZS4gVXNlIG93biBkZWZhdWx0cyBmb3IgYm90aFxuICAvLyBwcm9iZXMgc28gdW5yZWxhdGVkIHBvbGx1dGVkIG9wdGlvbnMgY2Fubm90IGFmZmVjdCBjYWNoZS1tb2RlIGRldGVjdGlvbi5cbiAgY29uc3QgcmVxdWVzdERlZmF1bHRzID0gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKG51bGwpLCBERUZBVUxUX1JFUVVFU1RfT1BUSU9OUyk7XG5cbiAgaWYgKGlzUmVxdWVzdFN1cHBvcnRlZCAmJiAhdGVzdCgoKSA9PiBuZXcgUmVxdWVzdChwbGF0Zm9ybS5vcmlnaW4sIHJlcXVlc3REZWZhdWx0cykpKSB7XG4gICAgZGVsZXRlIHJlcXVlc3REZWZhdWx0cy5jYWNoZTtcblxuICAgIC8vIE9ubHkgb21pdCBjYWNoZSB3aGVuIHRoYXQgbWFrZXMgUmVxdWVzdCBjb25zdHJ1Y3Rpb24gc3VjY2VlZC4gT3RoZXJ3aXNlXG4gICAgLy8gcmV0YWluIHRoZSBleHBsaWNpdCBkZWZhdWx0IHRoYXQgcHJvdGVjdHMgc3VwcG9ydGluZyBydW50aW1lcyBmcm9tIHBvbGx1dGlvbi5cbiAgICBpZiAoIXRlc3QoKCkgPT4gbmV3IFJlcXVlc3QocGxhdGZvcm0ub3JpZ2luLCByZXF1ZXN0RGVmYXVsdHMpKSkge1xuICAgICAgcmVxdWVzdERlZmF1bHRzLmNhY2hlID0gREVGQVVMVF9SRVFVRVNUX09QVElPTlMuY2FjaGU7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVzb2x2ZXJzID0ge1xuICAgIHN0cmVhbTogc3VwcG9ydHNSZXNwb25zZVN0cmVhbSAmJiAoKHJlcykgPT4gcmVzLmJvZHkpLFxuICB9O1xuXG4gIGlzRmV0Y2hTdXBwb3J0ZWQgJiZcbiAgICAoKCkgPT4ge1xuICAgICAgWyd0ZXh0JywgJ2FycmF5QnVmZmVyJywgJ2Jsb2InLCAnZm9ybURhdGEnLCAnc3RyZWFtJ10uZm9yRWFjaCgodHlwZSkgPT4ge1xuICAgICAgICAhcmVzb2x2ZXJzW3R5cGVdICYmXG4gICAgICAgICAgKHJlc29sdmVyc1t0eXBlXSA9IChyZXMsIGNvbmZpZykgPT4ge1xuICAgICAgICAgICAgbGV0IG1ldGhvZCA9IHJlcyAmJiByZXNbdHlwZV07XG5cbiAgICAgICAgICAgIGlmIChtZXRob2QpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG1ldGhvZC5jYWxsKHJlcyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgICBgUmVzcG9uc2UgdHlwZSAnJHt0eXBlfScgaXMgbm90IHN1cHBvcnRlZGAsXG4gICAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX05PVF9TVVBQT1JULFxuICAgICAgICAgICAgICBjb25maWdcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KSgpO1xuXG4gIGNvbnN0IGdldEJvZHlMZW5ndGggPSBhc3luYyAoYm9keSkgPT4ge1xuICAgIGlmIChib2R5ID09IG51bGwpIHtcbiAgICAgIHJldHVybiAwO1xuICAgIH1cblxuICAgIGlmICh1dGlscy5pc0Jsb2IoYm9keSkpIHtcbiAgICAgIHJldHVybiBib2R5LnNpemU7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQXJyYXlCdWZmZXJWaWV3KGJvZHkpIHx8IHV0aWxzLmlzQXJyYXlCdWZmZXIoYm9keSkpIHtcbiAgICAgIHJldHVybiBib2R5LmJ5dGVMZW5ndGg7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzVVJMU2VhcmNoUGFyYW1zKGJvZHkpKSB7XG4gICAgICBib2R5ID0gYm9keSArICcnO1xuICAgIH1cblxuICAgIGlmICh1dGlscy5pc1N0cmluZyhib2R5KSkge1xuICAgICAgcmV0dXJuIChhd2FpdCBlbmNvZGVUZXh0KGJvZHkpKS5ieXRlTGVuZ3RoO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCByZXNvbHZlQm9keUxlbmd0aCA9IGFzeW5jIChoZWFkZXJzLCBib2R5KSA9PiB7XG4gICAgY29uc3QgbGVuZ3RoID0gdXRpbHMudG9GaW5pdGVOdW1iZXIoaGVhZGVycy5nZXRDb250ZW50TGVuZ3RoKCkpO1xuXG4gICAgcmV0dXJuIGxlbmd0aCA9PSBudWxsID8gZ2V0Qm9keUxlbmd0aChib2R5KSA6IGxlbmd0aDtcbiAgfTtcblxuICByZXR1cm4gYXN5bmMgKGNvbmZpZykgPT4ge1xuICAgIGxldCB7XG4gICAgICB1cmwsXG4gICAgICBtZXRob2QsXG4gICAgICBkYXRhLFxuICAgICAgc2lnbmFsLFxuICAgICAgY2FuY2VsVG9rZW4sXG4gICAgICB0aW1lb3V0LFxuICAgICAgb25Eb3dubG9hZFByb2dyZXNzLFxuICAgICAgb25VcGxvYWRQcm9ncmVzcyxcbiAgICAgIHJlc3BvbnNlVHlwZSxcbiAgICAgIGhlYWRlcnMsXG4gICAgICB3aXRoQ3JlZGVudGlhbHMgPSAnc2FtZS1vcmlnaW4nLFxuICAgICAgZmV0Y2hPcHRpb25zLFxuICAgICAgbWF4Q29udGVudExlbmd0aCxcbiAgICAgIG1heEJvZHlMZW5ndGgsXG4gICAgICBtYXhSZWRpcmVjdHMsXG4gICAgfSA9IHJlc29sdmVDb25maWcoY29uZmlnKTtcblxuICAgIGNvbnN0IGhhc01heENvbnRlbnRMZW5ndGggPSB1dGlscy5pc051bWJlcihtYXhDb250ZW50TGVuZ3RoKSAmJiBtYXhDb250ZW50TGVuZ3RoID4gLTE7XG4gICAgY29uc3QgaGFzTWF4Qm9keUxlbmd0aCA9IHV0aWxzLmlzTnVtYmVyKG1heEJvZHlMZW5ndGgpICYmIG1heEJvZHlMZW5ndGggPiAtMTtcbiAgICBjb25zdCBvd24gPSAoa2V5KSA9PiAodXRpbHMuaGFzT3duUHJvcChjb25maWcsIGtleSkgPyBjb25maWdba2V5XSA6IHVuZGVmaW5lZCk7XG5cbiAgICBsZXQgX2ZldGNoID0gZW52RmV0Y2ggfHwgZmV0Y2g7XG5cbiAgICByZXNwb25zZVR5cGUgPSByZXNwb25zZVR5cGUgPyAocmVzcG9uc2VUeXBlICsgJycpLnRvTG93ZXJDYXNlKCkgOiAndGV4dCc7XG5cbiAgICBsZXQgY29tcG9zZWRTaWduYWwgPSBjb21wb3NlU2lnbmFscyhcbiAgICAgIFtzaWduYWwsIGNhbmNlbFRva2VuICYmIGNhbmNlbFRva2VuLnRvQWJvcnRTaWduYWwoKV0sXG4gICAgICB0aW1lb3V0XG4gICAgKTtcblxuICAgIGxldCByZXF1ZXN0ID0gbnVsbDtcblxuICAgIGNvbnN0IHVuc3Vic2NyaWJlID1cbiAgICAgIGNvbXBvc2VkU2lnbmFsICYmXG4gICAgICBjb21wb3NlZFNpZ25hbC51bnN1YnNjcmliZSAmJlxuICAgICAgKCgpID0+IHtcbiAgICAgICAgY29tcG9zZWRTaWduYWwudW5zdWJzY3JpYmUoKTtcbiAgICAgIH0pO1xuXG4gICAgbGV0IHJlcXVlc3RDb250ZW50TGVuZ3RoO1xuXG4gICAgLy8gQXhpb3NFcnJvcnMgd2UgcmFpc2Ugd2hpbGUgcmVxdWVzdCBvciByZXNwb25zZSBib2RpZXMgYXJlIGJlaW5nIHN0cmVhbWVkLiBDYXB0dXJlZFxuICAgIC8vIGJ5IGlkZW50aXR5IHNvIHRoZSBjYXRjaCBibG9jayBjYW4gc3VyZmFjZSBpdCBkaXJlY3RseSwgcmVnYXJkbGVzcyBvZlxuICAgIC8vIGhvdyB0aGUgcnVudGltZSB3cmFwcyB0aGUgcmVzdWx0aW5nIGZldGNoIHJlamVjdGlvbiAodW5kaWNpIGV4cG9zZXMgaXRcbiAgICAvLyBhcyBgZXJyLmNhdXNlYDsgc29tZSBicm93c2VycyBkcm9wIHRoZSBvcmlnaW5hbCBlcnJvciBlbnRpcmVseSkuXG4gICAgbGV0IHBlbmRpbmdCb2R5RXJyb3IgPSBudWxsO1xuICAgIGxldCBwZW5kaW5nUmVzcG9uc2VFcnJvciA9IG51bGw7XG5cbiAgICBjb25zdCBtYXhCb2R5TGVuZ3RoRXJyb3IgPSAoKSA9PlxuICAgICAgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICdSZXF1ZXN0IGJvZHkgbGFyZ2VyIHRoYW4gbWF4Qm9keUxlbmd0aCBsaW1pdCcsXG4gICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVFVRVNULFxuICAgICAgICBjb25maWcsXG4gICAgICAgIHJlcXVlc3RcbiAgICAgICk7XG5cbiAgICB0cnkge1xuICAgICAgLy8gSFRUUCBiYXNpYyBhdXRoZW50aWNhdGlvblxuICAgICAgbGV0IGF1dGggPSB1bmRlZmluZWQ7XG4gICAgICBjb25zdCBjb25maWdBdXRoID0gb3duKCdhdXRoJyk7XG5cbiAgICAgIGlmIChjb25maWdBdXRoKSB7XG4gICAgICAgIGNvbnN0IHVzZXJuYW1lID0gdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnQXV0aCwgJ3VzZXJuYW1lJykgfHwgJyc7XG4gICAgICAgIGNvbnN0IHBhc3N3b3JkID0gdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnQXV0aCwgJ3Bhc3N3b3JkJykgfHwgJyc7XG4gICAgICAgIGF1dGggPSB7XG4gICAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgICAgcGFzc3dvcmQsXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIGxldCBwYXJzZWRVUkw7XG4gICAgICBpZiAobWF5YmVXaXRoQXV0aENyZWRlbnRpYWxzKHVybCkpIHtcbiAgICAgICAgcGFyc2VkVVJMID0gbmV3IFVSTCh1cmwsIHBsYXRmb3JtLm9yaWdpbik7XG5cbiAgICAgICAgaWYgKCFhdXRoICYmIChwYXJzZWRVUkwudXNlcm5hbWUgfHwgcGFyc2VkVVJMLnBhc3N3b3JkKSkge1xuICAgICAgICAgIGNvbnN0IHVybFVzZXJuYW1lID0gZGVjb2RlVVJJQ29tcG9uZW50U2FmZShwYXJzZWRVUkwudXNlcm5hbWUpO1xuICAgICAgICAgIGNvbnN0IHVybFBhc3N3b3JkID0gZGVjb2RlVVJJQ29tcG9uZW50U2FmZShwYXJzZWRVUkwucGFzc3dvcmQpO1xuICAgICAgICAgIGF1dGggPSB7XG4gICAgICAgICAgICB1c2VybmFtZTogdXJsVXNlcm5hbWUsXG4gICAgICAgICAgICBwYXNzd29yZDogdXJsUGFzc3dvcmQsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwYXJzZWRVUkwudXNlcm5hbWUgfHwgcGFyc2VkVVJMLnBhc3N3b3JkKSB7XG4gICAgICAgICAgcGFyc2VkVVJMLnVzZXJuYW1lID0gJyc7XG4gICAgICAgICAgcGFyc2VkVVJMLnBhc3N3b3JkID0gJyc7XG4gICAgICAgICAgdXJsID0gcGFyc2VkVVJMLmhyZWY7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGF1dGgpIHtcbiAgICAgICAgaGVhZGVycy5kZWxldGUoJ2F1dGhvcml6YXRpb24nKTtcbiAgICAgICAgaGVhZGVycy5zZXQoXG4gICAgICAgICAgJ0F1dGhvcml6YXRpb24nLFxuICAgICAgICAgICdCYXNpYyAnICsgYnRvYShlbmNvZGVVVEY4KChhdXRoLnVzZXJuYW1lIHx8ICcnKSArICc6JyArIChhdXRoLnBhc3N3b3JkIHx8ICcnKSkpXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIC8vIEVuZm9yY2UgbWF4Q29udGVudExlbmd0aCBmb3IgZGF0YTogVVJMcyB1cC1mcm9udCBzbyB3ZSBuZXZlciBtYXRlcmlhbGl6ZVxuICAgICAgLy8gYW4gb3ZlcnNpemVkIHBheWxvYWQuIFRoZSBIVFRQIGFkYXB0ZXIgYXBwbGllcyB0aGUgc2FtZSBjaGVjayAoc2VlIGh0dHAuanNcbiAgICAgIC8vIFwiaWYgKHByb3RvY29sID09PSAnZGF0YTonKVwiIGJyYW5jaCkuXG4gICAgICBpZiAoaGFzTWF4Q29udGVudExlbmd0aCAmJiBwYXJzZWRVUkwgJiYgcGFyc2VkVVJMLnByb3RvY29sID09PSAnZGF0YTonKSB7XG4gICAgICAgIGNvbnN0IGVzdGltYXRlZCA9IGVzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcyhwYXJzZWRVUkwuaHJlZik7XG4gICAgICAgIGlmIChlc3RpbWF0ZWQgPiBtYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgICAnbWF4Q29udGVudExlbmd0aCBzaXplIG9mICcgKyBtYXhDb250ZW50TGVuZ3RoICsgJyBleGNlZWRlZCcsXG4gICAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9CQURfUkVTUE9OU0UsXG4gICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zdCBmb3JtQ29udGVudFR5cGUgPVxuICAgICAgICB1dGlscy5pc1NwZWNDb21wbGlhbnRGb3JtKGRhdGEpICYmIEF4aW9zSGVhZGVycy5mcm9tKG93bignaGVhZGVycycpKS5nZXRDb250ZW50VHlwZSgpO1xuICAgICAgbGV0IGZvcm1Cb3VuZGFyeTtcbiAgICAgIGlmIChcbiAgICAgICAgdXRpbHMuaXNTdHJpbmcoZm9ybUNvbnRlbnRUeXBlKSAmJlxuICAgICAgICAvXm11bHRpcGFydFxcL2Zvcm0tZGF0YSg/Olxccyo7fCQpL2kudGVzdChmb3JtQ29udGVudFR5cGUudHJpbSgpKVxuICAgICAgKSB7XG4gICAgICAgIGNvbnN0IHBhcmFtZXRlcnMgPSBBeGlvc0hlYWRlcnMucGFyc2VQYXJhbWV0ZXJzKGZvcm1Db250ZW50VHlwZSk7XG4gICAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHBhcmFtZXRlcnMsICdib3VuZGFyeScpKSBmb3JtQm91bmRhcnkgPSBwYXJhbWV0ZXJzLmJvdW5kYXJ5O1xuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgIHV0aWxzLmlzU3BlY0NvbXBsaWFudEZvcm0oZGF0YSkgJiZcbiAgICAgICAgbWV0aG9kICE9PSAnZ2V0JyAmJlxuICAgICAgICBtZXRob2QgIT09ICdoZWFkJyAmJlxuICAgICAgICAoaGFzTWF4Qm9keUxlbmd0aCB8fFxuICAgICAgICAgIChvblVwbG9hZFByb2dyZXNzICYmIHN1cHBvcnRzUmVxdWVzdFN0cmVhbSkgfHxcbiAgICAgICAgICBmb3JtQm91bmRhcnkgIT09IHVuZGVmaW5lZClcbiAgICAgICkge1xuICAgICAgICBkYXRhID0gY3JlYXRlTXVsdGlwYXJ0Qm9keShcbiAgICAgICAgICBkYXRhLFxuICAgICAgICAgIEJsb2IsXG4gICAgICAgICAgaGFzTWF4Qm9keUxlbmd0aCA/IG1heEJvZHlMZW5ndGggOiBJbmZpbml0eSxcbiAgICAgICAgICBtYXhCb2R5TGVuZ3RoRXJyb3IsXG4gICAgICAgICAgZm9ybUJvdW5kYXJ5XG4gICAgICAgICk7XG4gICAgICAgIC8vIEJsb2IudHlwZSBsb3dlcmNhc2VzIGl0cyB2YWx1ZSwgaW5jbHVkaW5nIGEgY2FzZS1zZW5zaXRpdmUgYm91bmRhcnkuXG4gICAgICAgIC8vIFJldGFpbiB0aGUgY2FsbGVyJ3MgaGVhZGVyIHdoZW4gYW4gZXhwbGljaXQgYm91bmRhcnkgd2FzIHNlcmlhbGl6ZWQuXG4gICAgICAgIGhlYWRlcnMuc2V0Q29udGVudFR5cGUoZm9ybUJvdW5kYXJ5ID09PSB1bmRlZmluZWQgPyBkYXRhLnR5cGUgOiBmb3JtQ29udGVudFR5cGUpO1xuICAgICAgICByZXF1ZXN0Q29udGVudExlbmd0aCA9IGRhdGEuc2l6ZTtcbiAgICAgIH1cblxuICAgICAgLy8gRW5mb3JjZSBtYXhCb2R5TGVuZ3RoIGFnYWluc3Qga25vd24tc2l6ZSBib2RpZXMgYmVmb3JlIGRpc3BhdGNoIHVzaW5nXG4gICAgICAvLyB0aGUgYm9keSdzICphY3R1YWwqIHNpemUg4oCUIG5ldmVyIGEgY2FsbGVyLWRlY2xhcmVkIENvbnRlbnQtTGVuZ3RoLFxuICAgICAgLy8gd2hpY2ggY291bGQgdW5kZXItcmVwb3J0IHRvIHNsaXAgYW4gb3ZlcnNpemVkIGJvZHkgcGFzdCB0aGUgY2hlY2suXG4gICAgICAvLyBVbmtub3duLXNpemUgc3RyZWFtcyByZXR1cm4gdW5kZWZpbmVkIGhlcmUgYW5kIGFyZSBjb3VudGVkIHBlci1jaHVua1xuICAgICAgLy8gYmVsb3cgYXMgZmV0Y2ggY29uc3VtZXMgdGhlbS5cbiAgICAgIGlmIChoYXNNYXhCb2R5TGVuZ3RoICYmIG1ldGhvZCAhPT0gJ2dldCcgJiYgbWV0aG9kICE9PSAnaGVhZCcpIHtcbiAgICAgICAgY29uc3Qgb3V0Ym91bmRMZW5ndGggPSBhd2FpdCBnZXRCb2R5TGVuZ3RoKGRhdGEpO1xuICAgICAgICBpZiAodHlwZW9mIG91dGJvdW5kTGVuZ3RoID09PSAnbnVtYmVyJyAmJiBpc0Zpbml0ZShvdXRib3VuZExlbmd0aCkpIHtcbiAgICAgICAgICByZXF1ZXN0Q29udGVudExlbmd0aCA9IG91dGJvdW5kTGVuZ3RoO1xuICAgICAgICAgIGlmIChvdXRib3VuZExlbmd0aCA+IG1heEJvZHlMZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG1heEJvZHlMZW5ndGhFcnJvcigpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBBIHN0cmVhbWVkIGJvZHkgdW5kZXIgbWF4Qm9keUxlbmd0aCBtdXN0IGJlIGNvdW50ZWQgYXMgZmV0Y2ggY29uc3VtZXNcbiAgICAgIC8vIGl0OyBpdHMgc2l6ZSBpcyBuZXZlciB0cnVzdGVkIGZyb20gYSBjYWxsZXItZGVjbGFyZWQgQ29udGVudC1MZW5ndGguXG4gICAgICBjb25zdCBtdXN0RW5mb3JjZVN0cmVhbUJvZHkgPVxuICAgICAgICBoYXNNYXhCb2R5TGVuZ3RoICYmICh1dGlscy5pc1JlYWRhYmxlU3RyZWFtKGRhdGEpIHx8IHV0aWxzLmlzU3RyZWFtKGRhdGEpKTtcblxuICAgICAgY29uc3QgdHJhY2tSZXF1ZXN0U3RyZWFtID0gKHN0cmVhbSwgb25Qcm9ncmVzcywgZmx1c2gpID0+XG4gICAgICAgIHRyYWNrU3RyZWFtKFxuICAgICAgICAgIHN0cmVhbSxcbiAgICAgICAgICBERUZBVUxUX0NIVU5LX1NJWkUsXG4gICAgICAgICAgKGxvYWRlZEJ5dGVzKSA9PiB7XG4gICAgICAgICAgICBpZiAoaGFzTWF4Qm9keUxlbmd0aCAmJiBsb2FkZWRCeXRlcyA+IG1heEJvZHlMZW5ndGgpIHtcbiAgICAgICAgICAgICAgdGhyb3cgKHBlbmRpbmdCb2R5RXJyb3IgPSBtYXhCb2R5TGVuZ3RoRXJyb3IoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvblByb2dyZXNzICYmIG9uUHJvZ3Jlc3MobG9hZGVkQnl0ZXMpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgZmx1c2hcbiAgICAgICAgKTtcblxuICAgICAgaWYgKFxuICAgICAgICBzdXBwb3J0c1JlcXVlc3RTdHJlYW0gJiZcbiAgICAgICAgbWV0aG9kICE9PSAnZ2V0JyAmJlxuICAgICAgICBtZXRob2QgIT09ICdoZWFkJyAmJlxuICAgICAgICAob25VcGxvYWRQcm9ncmVzcyB8fCBtdXN0RW5mb3JjZVN0cmVhbUJvZHkpXG4gICAgICApIHtcbiAgICAgICAgcmVxdWVzdENvbnRlbnRMZW5ndGggPVxuICAgICAgICAgIHJlcXVlc3RDb250ZW50TGVuZ3RoID09IG51bGxcbiAgICAgICAgICAgID8gYXdhaXQgcmVzb2x2ZUJvZHlMZW5ndGgoaGVhZGVycywgZGF0YSlcbiAgICAgICAgICAgIDogcmVxdWVzdENvbnRlbnRMZW5ndGg7XG5cbiAgICAgICAgLy8gQSBkZWNsYXJlZCBsZW5ndGggb2YgMCBpcyBvbmx5IHRydXN0ZWQgdG8gc2tpcCB0aGUgd3JhcCB3aGVuIHdlIGFyZVxuICAgICAgICAvLyBub3QgZW5mb3JjaW5nIGEgc3RyZWFtIGxpbWl0ICh3aGljaCBtdXN0IG5vdCByZWx5IG9uIHRoYXQgaGVhZGVyKS5cbiAgICAgICAgaWYgKHJlcXVlc3RDb250ZW50TGVuZ3RoICE9PSAwIHx8IG11c3RFbmZvcmNlU3RyZWFtQm9keSkge1xuICAgICAgICAgIGxldCBfcmVxdWVzdCA9IG5ldyBSZXF1ZXN0KHVybCwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBib2R5OiBkYXRhLFxuICAgICAgICAgICAgZHVwbGV4OiAnaGFsZicsXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBsZXQgY29udGVudFR5cGVIZWFkZXI7XG5cbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICB1dGlscy5pc0Zvcm1EYXRhKGRhdGEpICYmXG4gICAgICAgICAgICAoY29udGVudFR5cGVIZWFkZXIgPSBfcmVxdWVzdC5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBoZWFkZXJzLnNldENvbnRlbnRUeXBlKGNvbnRlbnRUeXBlSGVhZGVyKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoX3JlcXVlc3QuYm9keSkge1xuICAgICAgICAgICAgY29uc3QgW29uUHJvZ3Jlc3MsIGZsdXNoXSA9XG4gICAgICAgICAgICAgIChvblVwbG9hZFByb2dyZXNzICYmXG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudERlY29yYXRvcihcbiAgICAgICAgICAgICAgICAgIHJlcXVlc3RDb250ZW50TGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudFJlZHVjZXIoYXN5bmNEZWNvcmF0b3Iob25VcGxvYWRQcm9ncmVzcykpXG4gICAgICAgICAgICAgICAgKSkgfHxcbiAgICAgICAgICAgICAgW107XG5cbiAgICAgICAgICAgIGRhdGEgPSB0cmFja1JlcXVlc3RTdHJlYW0oX3JlcXVlc3QuYm9keSwgb25Qcm9ncmVzcywgZmx1c2gpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgbXVzdEVuZm9yY2VTdHJlYW1Cb2R5ICYmXG4gICAgICAgICFpc1JlcXVlc3RTdXBwb3J0ZWQgJiZcbiAgICAgICAgaXNSZWFkYWJsZVN0cmVhbVN1cHBvcnRlZCAmJlxuICAgICAgICBtZXRob2QgIT09ICdnZXQnICYmXG4gICAgICAgIG1ldGhvZCAhPT0gJ2hlYWQnXG4gICAgICApIHtcbiAgICAgICAgZGF0YSA9IHRyYWNrUmVxdWVzdFN0cmVhbShkYXRhKTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgIG11c3RFbmZvcmNlU3RyZWFtQm9keSAmJlxuICAgICAgICBpc1JlcXVlc3RTdXBwb3J0ZWQgJiZcbiAgICAgICAgIXN1cHBvcnRzUmVxdWVzdFN0cmVhbSAmJlxuICAgICAgICBtZXRob2QgIT09ICdnZXQnICYmXG4gICAgICAgIG1ldGhvZCAhPT0gJ2hlYWQnXG4gICAgICApIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgJ1N0cmVhbSByZXF1ZXN0IGJvZGllcyBhcmUgbm90IHN1cHBvcnRlZCBieSB0aGUgY3VycmVudCBmZXRjaCBpbXBsZW1lbnRhdGlvbicsXG4gICAgICAgICAgQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlQsXG4gICAgICAgICAgY29uZmlnLFxuICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCF1dGlscy5pc1N0cmluZyh3aXRoQ3JlZGVudGlhbHMpKSB7XG4gICAgICAgIHdpdGhDcmVkZW50aWFscyA9IHdpdGhDcmVkZW50aWFscyA/ICdpbmNsdWRlJyA6ICdvbWl0JztcbiAgICAgIH1cblxuICAgICAgLy8gQ2xvdWRmbGFyZSBXb3JrZXJzIHRocm93cyB3aGVuIGNyZWRlbnRpYWxzIGFyZSBkZWZpbmVkXG4gICAgICAvLyBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2Nsb3VkZmxhcmUvd29ya2VyZC9pc3N1ZXMvOTAyXG4gICAgICBjb25zdCBpc0NyZWRlbnRpYWxzU3VwcG9ydGVkID0gaXNSZXF1ZXN0U3VwcG9ydGVkICYmICdjcmVkZW50aWFscycgaW4gUmVxdWVzdC5wcm90b3R5cGU7XG5cbiAgICAgIC8vIElmIGRhdGEgaXMgRm9ybURhdGEgYW5kIENvbnRlbnQtVHlwZSBpcyBtdWx0aXBhcnQvZm9ybS1kYXRhIHdpdGhvdXQgYm91bmRhcnksXG4gICAgICAvLyBkZWxldGUgaXQgc28gZmV0Y2ggY2FuIHNldCBpdCBjb3JyZWN0bHkgd2l0aCB0aGUgYm91bmRhcnlcbiAgICAgIGlmICh1dGlscy5pc0Zvcm1EYXRhKGRhdGEpKSB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gaGVhZGVycy5nZXRDb250ZW50VHlwZSgpO1xuICAgICAgICBpZiAoXG4gICAgICAgICAgY29udGVudFR5cGUgJiZcbiAgICAgICAgICAvXm11bHRpcGFydFxcL2Zvcm0tZGF0YS9pLnRlc3QoY29udGVudFR5cGUpICYmXG4gICAgICAgICAgIS9ib3VuZGFyeT0vaS50ZXN0KGNvbnRlbnRUeXBlKVxuICAgICAgICApIHtcbiAgICAgICAgICBoZWFkZXJzLmRlbGV0ZSgnY29udGVudC10eXBlJyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gU2V0IFVzZXItQWdlbnQgaGVhZGVyIGlmIG5vdCBhbHJlYWR5IHNldCAoZmV0Y2ggZGVmYXVsdHMgdG8gJ25vZGUnIGluIE5vZGUuanMpXG4gICAgICBoZWFkZXJzLnNldCgnVXNlci1BZ2VudCcsICdheGlvcy8nICsgVkVSU0lPTiwgZmFsc2UpO1xuXG4gICAgICBjb25zdCBzYWZlRmV0Y2hPcHRpb25zID1cbiAgICAgICAgZmV0Y2hPcHRpb25zID09IG51bGwgPyBmZXRjaE9wdGlvbnMgOiBPYmplY3QuYXNzaWduKE9iamVjdC5jcmVhdGUobnVsbCksIGZldGNoT3B0aW9ucyk7XG5cbiAgICAgIGlmIChzYWZlRmV0Y2hPcHRpb25zKSB7XG4gICAgICAgIC8vIFRoZXNlIG9wdGlvbnMgYXJlIG93bmVkIGJ5IEF4aW9zIGFuZCBhcmUgYWxyZWFkeSByZWZsZWN0ZWQgaW4gdGhlXG4gICAgICAgIC8vIHJlc29sdmVkIFJlcXVlc3QgcGFzc2VkIHRvIGZldGNoLlxuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5ib2R5O1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5oZWFkZXJzO1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5tZXRob2Q7XG4gICAgICAgIGRlbGV0ZSBzYWZlRmV0Y2hPcHRpb25zLnNpZ25hbDtcbiAgICAgICAgZGVsZXRlIHNhZmVGZXRjaE9wdGlvbnMuZHVwbGV4O1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5jcmVkZW50aWFscztcbiAgICAgIH1cblxuICAgICAgY29uc3QgcmVzb2x2ZWRPcHRpb25zID0gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKG51bGwpLCBzYWZlRmV0Y2hPcHRpb25zLCB7XG4gICAgICAgIHNpZ25hbDogY29tcG9zZWRTaWduYWwsXG4gICAgICAgIG1ldGhvZDogbWV0aG9kLnRvVXBwZXJDYXNlKCksXG4gICAgICAgIGhlYWRlcnM6IHRvQnl0ZVN0cmluZ0hlYWRlck9iamVjdChoZWFkZXJzLm5vcm1hbGl6ZSgpKSxcbiAgICAgICAgYm9keTogZGF0YSxcbiAgICAgICAgZHVwbGV4OiAnaGFsZicsXG4gICAgICAgIGNyZWRlbnRpYWxzOiBpc0NyZWRlbnRpYWxzU3VwcG9ydGVkID8gd2l0aENyZWRlbnRpYWxzIDogdW5kZWZpbmVkLFxuICAgICAgfSk7XG5cbiAgICAgIGlmIChpc1JlcXVlc3RTdXBwb3J0ZWQpIHtcbiAgICAgICAgdXRpbHMuZm9yRWFjaChyZXF1ZXN0RGVmYXVsdHMsICh2YWx1ZSwga2V5KSA9PiB7XG4gICAgICAgICAgaWYgKHJlc29sdmVkT3B0aW9uc1trZXldID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJlc29sdmVkT3B0aW9uc1trZXldID0gdmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAocmVzb2x2ZWRPcHRpb25zLnNpZ25hbCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgcmVzb2x2ZWRPcHRpb25zLnNpZ25hbCA9IG51bGw7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAocmVzb2x2ZWRPcHRpb25zLmJvZHkgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHJlc29sdmVkT3B0aW9ucy5ib2R5ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAobWF4UmVkaXJlY3RzID09PSAwKSB7XG4gICAgICAgIHJlc29sdmVkT3B0aW9ucy5yZWRpcmVjdCA9ICdtYW51YWwnO1xuXG4gICAgICAgIGlmIChzYWZlRmV0Y2hPcHRpb25zKSB7XG4gICAgICAgICAgc2FmZUZldGNoT3B0aW9ucy5yZWRpcmVjdCA9ICdtYW51YWwnO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJlcXVlc3QgPSBpc1JlcXVlc3RTdXBwb3J0ZWQgJiYgbmV3IFJlcXVlc3QodXJsLCByZXNvbHZlZE9wdGlvbnMpO1xuXG4gICAgICBsZXQgcmVzcG9uc2UgPSBhd2FpdCAoaXNSZXF1ZXN0U3VwcG9ydGVkXG4gICAgICAgID8gX2ZldGNoKHJlcXVlc3QsIHNhZmVGZXRjaE9wdGlvbnMpXG4gICAgICAgIDogX2ZldGNoKHVybCwgcmVzb2x2ZWRPcHRpb25zKSk7XG5cbiAgICAgIGNvbnN0IHJlc3BvbnNlSGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKHJlc3BvbnNlLmhlYWRlcnMpO1xuXG4gICAgICAvLyBDaGVhcCBwcmUtY2hlY2s6IGlmIHRoZSBzZXJ2ZXIgaG9uZXN0bHkgZGVjbGFyZXMgYSBjb250ZW50LWxlbmd0aCB0aGF0XG4gICAgICAvLyBhbHJlYWR5IGV4Y2VlZHMgdGhlIGNhcCwgcmVqZWN0IGJlZm9yZSB3ZSBzdGFydCBzdHJlYW1pbmcuXG4gICAgICBpZiAoaGFzTWF4Q29udGVudExlbmd0aCkge1xuICAgICAgICBjb25zdCBkZWNsYXJlZExlbmd0aCA9IHV0aWxzLnRvRmluaXRlTnVtYmVyKHJlc3BvbnNlSGVhZGVycy5nZXRDb250ZW50TGVuZ3RoKCkpO1xuICAgICAgICBpZiAoZGVjbGFyZWRMZW5ndGggIT0gbnVsbCAmJiBkZWNsYXJlZExlbmd0aCA+IG1heENvbnRlbnRMZW5ndGgpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgICdtYXhDb250ZW50TGVuZ3RoIHNpemUgb2YgJyArIG1heENvbnRlbnRMZW5ndGggKyAnIGV4Y2VlZGVkJyxcbiAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSxcbiAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGlzU3RyZWFtUmVzcG9uc2UgPVxuICAgICAgICBzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtICYmIChyZXNwb25zZVR5cGUgPT09ICdzdHJlYW0nIHx8IHJlc3BvbnNlVHlwZSA9PT0gJ3Jlc3BvbnNlJyk7XG5cbiAgICAgIGlmIChcbiAgICAgICAgc3VwcG9ydHNSZXNwb25zZVN0cmVhbSAmJlxuICAgICAgICByZXNwb25zZS5ib2R5ICYmXG4gICAgICAgIChvbkRvd25sb2FkUHJvZ3Jlc3MgfHwgaGFzTWF4Q29udGVudExlbmd0aCB8fCAoaXNTdHJlYW1SZXNwb25zZSAmJiB1bnN1YnNjcmliZSkpXG4gICAgICApIHtcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHt9O1xuXG4gICAgICAgIFsnc3RhdHVzJywgJ3N0YXR1c1RleHQnLCAnaGVhZGVycyddLmZvckVhY2goKHByb3ApID0+IHtcbiAgICAgICAgICBvcHRpb25zW3Byb3BdID0gcmVzcG9uc2VbcHJvcF07XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQ29udGVudExlbmd0aCA9IHV0aWxzLnRvRmluaXRlTnVtYmVyKHJlc3BvbnNlSGVhZGVycy5nZXRDb250ZW50TGVuZ3RoKCkpO1xuXG4gICAgICAgIGNvbnN0IFtvblByb2dyZXNzLCBmbHVzaF0gPVxuICAgICAgICAgIChvbkRvd25sb2FkUHJvZ3Jlc3MgJiZcbiAgICAgICAgICAgIHByb2dyZXNzRXZlbnREZWNvcmF0b3IoXG4gICAgICAgICAgICAgIHJlc3BvbnNlQ29udGVudExlbmd0aCxcbiAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudFJlZHVjZXIoYXN5bmNEZWNvcmF0b3Iob25Eb3dubG9hZFByb2dyZXNzKSwgdHJ1ZSlcbiAgICAgICAgICAgICkpIHx8XG4gICAgICAgICAgW107XG5cbiAgICAgICAgbGV0IGJ5dGVzUmVhZCA9IDA7XG4gICAgICAgIGNvbnN0IG9uQ2h1bmtQcm9ncmVzcyA9IChsb2FkZWRCeXRlcykgPT4ge1xuICAgICAgICAgIGlmIChoYXNNYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgICAgICBieXRlc1JlYWQgPSBsb2FkZWRCeXRlcztcbiAgICAgICAgICAgIGlmIChieXRlc1JlYWQgPiBtYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgICAgICAgIHRocm93IChwZW5kaW5nUmVzcG9uc2VFcnJvciA9IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgICAgICdtYXhDb250ZW50TGVuZ3RoIHNpemUgb2YgJyArIG1heENvbnRlbnRMZW5ndGggKyAnIGV4Y2VlZGVkJyxcbiAgICAgICAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9CQURfUkVTUE9OU0UsXG4gICAgICAgICAgICAgICAgY29uZmlnLFxuICAgICAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICAgICAgKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIG9uUHJvZ3Jlc3MgJiYgb25Qcm9ncmVzcyhsb2FkZWRCeXRlcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmVzcG9uc2UgPSBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgdHJhY2tTdHJlYW0ocmVzcG9uc2UuYm9keSwgREVGQVVMVF9DSFVOS19TSVpFLCBvbkNodW5rUHJvZ3Jlc3MsICgpID0+IHtcbiAgICAgICAgICAgIGZsdXNoICYmIGZsdXNoKCk7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSAmJiB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgIH0pLFxuICAgICAgICAgIG9wdGlvbnNcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgcmVzcG9uc2VUeXBlID0gcmVzcG9uc2VUeXBlIHx8ICd0ZXh0JztcblxuICAgICAgbGV0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IHJlc29sdmVyc1t1dGlscy5maW5kS2V5KHJlc29sdmVycywgcmVzcG9uc2VUeXBlKSB8fCAndGV4dCddKFxuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgY29uZmlnXG4gICAgICApO1xuXG4gICAgICAvLyBGYWxsYmFjayBlbmZvcmNlbWVudCBmb3IgZW52aXJvbm1lbnRzIHdpdGhvdXQgUmVhZGFibGVTdHJlYW0gc3VwcG9ydFxuICAgICAgLy8gKGxlZ2FjeSBydW50aW1lcykuIERldGVjdCBtYXRlcmlhbGl6ZWQgc2l6ZSBmcm9tIHR5cGVkIG91dHB1dDsgc2tpcFxuICAgICAgLy8gc3RyZWFtcy9SZXNwb25zZSBwYXNzdGhyb3VnaCBzaW5jZSB0aGUgdXNlciB3aWxsIHJlYWQgdGhvc2UgdGhlbXNlbHZlcy5cbiAgICAgIGlmIChoYXNNYXhDb250ZW50TGVuZ3RoICYmICFzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtICYmICFpc1N0cmVhbVJlc3BvbnNlKSB7XG4gICAgICAgIGxldCBtYXRlcmlhbGl6ZWRTaXplO1xuICAgICAgICBpZiAocmVzcG9uc2VEYXRhICE9IG51bGwpIHtcbiAgICAgICAgICBpZiAodHlwZW9mIHJlc3BvbnNlRGF0YS5ieXRlTGVuZ3RoID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgbWF0ZXJpYWxpemVkU2l6ZSA9IHJlc3BvbnNlRGF0YS5ieXRlTGVuZ3RoO1xuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlc3BvbnNlRGF0YS5zaXplID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgbWF0ZXJpYWxpemVkU2l6ZSA9IHJlc3BvbnNlRGF0YS5zaXplO1xuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlc3BvbnNlRGF0YSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIG1hdGVyaWFsaXplZFNpemUgPVxuICAgICAgICAgICAgICB0eXBlb2YgVGV4dEVuY29kZXIgPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgICAgICA/IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShyZXNwb25zZURhdGEpLmJ5dGVMZW5ndGhcbiAgICAgICAgICAgICAgICA6IHJlc3BvbnNlRGF0YS5sZW5ndGg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgbWF0ZXJpYWxpemVkU2l6ZSA9PT0gJ251bWJlcicgJiYgbWF0ZXJpYWxpemVkU2l6ZSA+IG1heENvbnRlbnRMZW5ndGgpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgICdtYXhDb250ZW50TGVuZ3RoIHNpemUgb2YgJyArIG1heENvbnRlbnRMZW5ndGggKyAnIGV4Y2VlZGVkJyxcbiAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSxcbiAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgICFpc1N0cmVhbVJlc3BvbnNlICYmIHVuc3Vic2NyaWJlICYmIHVuc3Vic2NyaWJlKCk7XG5cbiAgICAgIHJldHVybiBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHNldHRsZShyZXNvbHZlLCByZWplY3QsIHtcbiAgICAgICAgICBkYXRhOiByZXNwb25zZURhdGEsXG4gICAgICAgICAgaGVhZGVyczogQXhpb3NIZWFkZXJzLmZyb20ocmVzcG9uc2UuaGVhZGVycyksXG4gICAgICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXG4gICAgICAgICAgc3RhdHVzVGV4dDogcmVzcG9uc2Uuc3RhdHVzVGV4dCxcbiAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHVuc3Vic2NyaWJlICYmIHVuc3Vic2NyaWJlKCk7XG5cbiAgICAgIC8vIFNhZmFyaSBjYW4gc3VyZmFjZSBmZXRjaCBhYm9ydHMgYXMgYSBET01FeGNlcHRpb24tbGlrZSBvYmplY3Qgd2hvc2VcbiAgICAgIC8vIGJyYW5kZWQgZ2V0dGVycyB0aHJvdy4gUHJlZmVyIG91ciBjb21wb3NlZCBzaWduYWwgcmVhc29uIGJlZm9yZSByZWFkaW5nXG4gICAgICAvLyB0aGUgY2F1Z2h0IGVycm9yLCBwcmVzZXJ2aW5nIHRpbWVvdXQgdnMgY2FuY2VsbGF0aW9uIHNlbWFudGljcy5cbiAgICAgIGlmIChjb21wb3NlZFNpZ25hbCAmJiBjb21wb3NlZFNpZ25hbC5hYm9ydGVkICYmIGNvbXBvc2VkU2lnbmFsLnJlYXNvbiBpbnN0YW5jZW9mIEF4aW9zRXJyb3IpIHtcbiAgICAgICAgY29uc3QgY2FuY2VsZWRFcnJvciA9IGNvbXBvc2VkU2lnbmFsLnJlYXNvbjtcbiAgICAgICAgY2FuY2VsZWRFcnJvci5jb25maWcgPSBjb25maWc7XG4gICAgICAgIHJlcXVlc3QgJiYgKGNhbmNlbGVkRXJyb3IucmVxdWVzdCA9IHJlcXVlc3QpO1xuICAgICAgICBpZiAoZXJyICE9PSBjYW5jZWxlZEVycm9yKSB7XG4gICAgICAgICAgLy8gTm9uLWVudW1lcmFibGUgdG8gbWF0Y2ggbmF0aXZlIEVycm9yIGBjYXVzZWAgc2VtYW50aWNzIHNvIGxvZ2dlcnNcbiAgICAgICAgICAvLyBkb24ndCByZWN1cnNlIGludG8gY2lyY3VsYXIgZmV0Y2ggaW50ZXJuYWxzIChzZWUgIzcyMDUpLlxuICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjYW5jZWxlZEVycm9yLCAnY2F1c2UnLCB7XG4gICAgICAgICAgICBfX3Byb3RvX186IG51bGwsXG4gICAgICAgICAgICB2YWx1ZTogZXJyLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBjYW5jZWxlZEVycm9yO1xuICAgICAgfVxuXG4gICAgICAvLyBTdXJmYWNlIGEgbWF4Qm9keUxlbmd0aCB2aW9sYXRpb24gd2UgcmFpc2VkIHdoaWxlIHRoZSByZXF1ZXN0IGJvZHkgd2FzXG4gICAgICAvLyBiZWluZyBzdHJlYW1lZC4gS2VlcGluZyB0aGUgb3JpZ2luYWwgZXJyb3IgKHJhdGhlciB0aGFuIHJlYWRpbmdcbiAgICAgIC8vIGBlcnIuY2F1c2UuaXNBeGlvc0Vycm9yYCkga2VlcHMgdGhlIGVycm9yIGRldGVybWluaXN0aWMgYWNyb3NzIHJ1bnRpbWVzXG4gICAgICAvLyBhbmQgYXZvaWRzIGJvdGggcHJvdG90eXBlLXBvbGx1dGlvbiByZWFkcyBhbmQgbWlzLWF0dHJpYnV0aW5nIGEgZm9yZWlnblxuICAgICAgLy8gQXhpb3NFcnJvciB0aGF0IG1lcmVseSBoYXBwZW5lZCB0byBsYW5kIGluIGBlcnIuY2F1c2VgLlxuICAgICAgaWYgKHBlbmRpbmdCb2R5RXJyb3IpIHtcbiAgICAgICAgcmVxdWVzdCAmJiAhcGVuZGluZ0JvZHlFcnJvci5yZXF1ZXN0ICYmIChwZW5kaW5nQm9keUVycm9yLnJlcXVlc3QgPSByZXF1ZXN0KTtcbiAgICAgICAgdGhyb3cgcGVuZGluZ0JvZHlFcnJvcjtcbiAgICAgIH1cblxuICAgICAgaWYgKHBlbmRpbmdSZXNwb25zZUVycm9yKSB7XG4gICAgICAgIHRocm93IHBlbmRpbmdSZXNwb25zZUVycm9yO1xuICAgICAgfVxuXG4gICAgICAvLyBSZS10aHJvdyBBeGlvc0Vycm9ycyB3ZSByYWlzZWQgc3luY2hyb25vdXNseSAoZGF0YTogVVJMIC8gY29udGVudC1sZW5ndGhcbiAgICAgIC8vIHByZS1jaGVja3MsIHJlc3BvbnNlIHNpemUgZW5mb3JjZW1lbnQpIHdpdGhvdXQgcmUtd3JhcHBpbmcgdGhlbS5cbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBBeGlvc0Vycm9yKSB7XG4gICAgICAgIHJlcXVlc3QgJiYgIWVyci5yZXF1ZXN0ICYmIChlcnIucmVxdWVzdCA9IHJlcXVlc3QpO1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG5cbiAgICAgIGlmIChlcnIgJiYgZXJyLm5hbWUgPT09ICdUeXBlRXJyb3InICYmIC9Mb2FkIGZhaWxlZHxmZXRjaC9pLnRlc3QoZXJyLm1lc3NhZ2UpKSB7XG4gICAgICAgIGNvbnN0IG5ldHdvcmtFcnJvciA9IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICdOZXR3b3JrIEVycm9yJyxcbiAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9ORVRXT1JLLFxuICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIGVyciAmJiBlcnIucmVzcG9uc2VcbiAgICAgICAgKTtcbiAgICAgICAgLy8gTm9uLWVudW1lcmFibGUgdG8gbWF0Y2ggbmF0aXZlIEVycm9yIGBjYXVzZWAgc2VtYW50aWNzIHNvIGxvZ2dlcnNcbiAgICAgICAgLy8gZG9uJ3QgcmVjdXJzZSBpbnRvIGNpcmN1bGFyIGZldGNoIGludGVybmFscyAoc2VlICM3MjA1KS5cbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG5ldHdvcmtFcnJvciwgJ2NhdXNlJywge1xuICAgICAgICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICAgICAgICB2YWx1ZTogZXJyLmNhdXNlIHx8IGVycixcbiAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aHJvdyBuZXR3b3JrRXJyb3I7XG4gICAgICB9XG5cbiAgICAgIHRocm93IEF4aW9zRXJyb3IuZnJvbShlcnIsIGVyciAmJiBlcnIuY29kZSwgY29uZmlnLCByZXF1ZXN0LCBlcnIgJiYgZXJyLnJlc3BvbnNlKTtcbiAgICB9XG4gIH07XG59O1xuXG5jb25zdCBzZWVkQ2FjaGUgPSBuZXcgTWFwKCk7XG5cbmV4cG9ydCBjb25zdCBnZXRGZXRjaCA9IChjb25maWcpID0+IHtcbiAgY29uc3QgZW52ID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgY29uZmlndXJlZEVudiA9IGNvbmZpZyAmJiB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZywgJ2VudicpICYmIGNvbmZpZy5lbnY7XG4gIFsnZmV0Y2gnLCAnUmVxdWVzdCcsICdSZXNwb25zZScsICdCbG9iJ10uZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgaWYgKGNvbmZpZ3VyZWRFbnYgJiYgdXRpbHMuaGFzT3duUHJvcChjb25maWd1cmVkRW52LCBrZXkpKSB7XG4gICAgICBlbnZba2V5XSA9IGNvbmZpZ3VyZWRFbnZba2V5XTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCB7IGZldGNoLCBSZXF1ZXN0LCBSZXNwb25zZSwgQmxvYiB9ID0gZW52O1xuICBjb25zdCBzZWVkcyA9IFtSZXF1ZXN0LCBSZXNwb25zZSwgZmV0Y2gsIEJsb2JdO1xuXG4gIGxldCBsZW4gPSBzZWVkcy5sZW5ndGgsXG4gICAgaSA9IGxlbixcbiAgICBzZWVkLFxuICAgIHRhcmdldCxcbiAgICBtYXAgPSBzZWVkQ2FjaGU7XG5cbiAgd2hpbGUgKGktLSkge1xuICAgIHNlZWQgPSBzZWVkc1tpXTtcbiAgICB0YXJnZXQgPSBtYXAuZ2V0KHNlZWQpO1xuXG4gICAgdGFyZ2V0ID09PSB1bmRlZmluZWQgJiYgbWFwLnNldChzZWVkLCAodGFyZ2V0ID0gaSA/IG5ldyBNYXAoKSA6IGZhY3RvcnkoZW52KSkpO1xuXG4gICAgbWFwID0gdGFyZ2V0O1xuICB9XG5cbiAgcmV0dXJuIHRhcmdldDtcbn07XG5cbmNvbnN0IGFkYXB0ZXIgPSBnZXRGZXRjaCgpO1xuXG5leHBvcnQgZGVmYXVsdCBhZGFwdGVyO1xuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBodHRwQWRhcHRlciBmcm9tICcuL2h0dHAuanMnO1xuaW1wb3J0IHhockFkYXB0ZXIgZnJvbSAnLi94aHIuanMnO1xuaW1wb3J0ICogYXMgZmV0Y2hBZGFwdGVyIGZyb20gJy4vZmV0Y2guanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcblxuLyoqXG4gKiBLbm93biBhZGFwdGVycyBtYXBwaW5nLlxuICogUHJvdmlkZXMgZW52aXJvbm1lbnQtc3BlY2lmaWMgYWRhcHRlcnMgZm9yIEF4aW9zOlxuICogLSBgaHR0cGAgZm9yIE5vZGUuanNcbiAqIC0gYHhocmAgZm9yIGJyb3dzZXJzXG4gKiAtIGBmZXRjaGAgZm9yIGZldGNoIEFQSS1iYXNlZCByZXF1ZXN0c1xuICpcbiAqIEB0eXBlIHtPYmplY3Q8c3RyaW5nLCBGdW5jdGlvbnxPYmplY3Q+fVxuICovXG5jb25zdCBrbm93bkFkYXB0ZXJzID0ge1xuICBodHRwOiBodHRwQWRhcHRlcixcbiAgeGhyOiB4aHJBZGFwdGVyLFxuICBmZXRjaDoge1xuICAgIGdldDogZmV0Y2hBZGFwdGVyLmdldEZldGNoLFxuICB9LFxufTtcblxuLy8gQXNzaWduIGFkYXB0ZXIgbmFtZXMgZm9yIGVhc2llciBkZWJ1Z2dpbmcgYW5kIGlkZW50aWZpY2F0aW9uXG51dGlscy5mb3JFYWNoKGtub3duQWRhcHRlcnMsIChmbiwgdmFsdWUpID0+IHtcbiAgaWYgKGZuKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIE51bGwtcHJvdG8gZGVzY3JpcHRvcnMgc28gYSBwb2xsdXRlZCBPYmplY3QucHJvdG90eXBlLmdldCBjYW5ub3QgdHVyblxuICAgICAgLy8gdGhlc2UgZGF0YSBkZXNjcmlwdG9ycyBpbnRvIGFjY2Vzc29yIGRlc2NyaXB0b3JzIG9uIHRoZSB3YXkgaW4uXG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZm4sICduYW1lJywgeyBfX3Byb3RvX186IG51bGwsIHZhbHVlIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1lbXB0eVxuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZm4sICdhZGFwdGVyTmFtZScsIHsgX19wcm90b19fOiBudWxsLCB2YWx1ZSB9KTtcbiAgfVxufSk7XG5cbi8qKlxuICogUmVuZGVyIGEgcmVqZWN0aW9uIHJlYXNvbiBzdHJpbmcgZm9yIHVua25vd24gb3IgdW5zdXBwb3J0ZWQgYWRhcHRlcnNcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVhc29uXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5jb25zdCByZW5kZXJSZWFzb24gPSAocmVhc29uKSA9PiBgLSAke3JlYXNvbn1gO1xuXG4vKipcbiAqIENoZWNrIGlmIHRoZSBhZGFwdGVyIGlzIHJlc29sdmVkIChmdW5jdGlvbiwgbnVsbCwgb3IgZmFsc2UpXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbnxudWxsfGZhbHNlfSBhZGFwdGVyXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuY29uc3QgaXNSZXNvbHZlZEhhbmRsZSA9IChhZGFwdGVyKSA9PlxuICB1dGlscy5pc0Z1bmN0aW9uKGFkYXB0ZXIpIHx8IGFkYXB0ZXIgPT09IG51bGwgfHwgYWRhcHRlciA9PT0gZmFsc2U7XG5cbi8qKlxuICogR2V0IHRoZSBmaXJzdCBzdWl0YWJsZSBhZGFwdGVyIGZyb20gdGhlIHByb3ZpZGVkIGxpc3QuXG4gKiBUcmllcyBlYWNoIGFkYXB0ZXIgaW4gb3JkZXIgdW50aWwgYSBzdXBwb3J0ZWQgb25lIGlzIGZvdW5kLlxuICogVGhyb3dzIGFuIEF4aW9zRXJyb3IgaWYgbm8gYWRhcHRlciBpcyBzdWl0YWJsZS5cbiAqXG4gKiBAcGFyYW0ge0FycmF5PHN0cmluZ3xGdW5jdGlvbj58c3RyaW5nfEZ1bmN0aW9ufSBhZGFwdGVycyAtIEFkYXB0ZXIocykgYnkgbmFtZSBvciBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWcgLSBBeGlvcyByZXF1ZXN0IGNvbmZpZ3VyYXRpb25cbiAqIEB0aHJvd3Mge0F4aW9zRXJyb3J9IElmIG5vIHN1aXRhYmxlIGFkYXB0ZXIgaXMgYXZhaWxhYmxlXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFRoZSByZXNvbHZlZCBhZGFwdGVyIGZ1bmN0aW9uXG4gKi9cbmZ1bmN0aW9uIGdldEFkYXB0ZXIoYWRhcHRlcnMsIGNvbmZpZykge1xuICBhZGFwdGVycyA9IHV0aWxzLmlzQXJyYXkoYWRhcHRlcnMpID8gYWRhcHRlcnMgOiBbYWRhcHRlcnNdO1xuXG4gIGNvbnN0IHsgbGVuZ3RoIH0gPSBhZGFwdGVycztcbiAgbGV0IG5hbWVPckFkYXB0ZXI7XG4gIGxldCBhZGFwdGVyO1xuXG4gIGNvbnN0IHJlamVjdGVkUmVhc29ucyA9IHt9O1xuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICBuYW1lT3JBZGFwdGVyID0gYWRhcHRlcnNbaV07XG4gICAgbGV0IGlkO1xuXG4gICAgYWRhcHRlciA9IG5hbWVPckFkYXB0ZXI7XG5cbiAgICBpZiAoIWlzUmVzb2x2ZWRIYW5kbGUobmFtZU9yQWRhcHRlcikpIHtcbiAgICAgIGFkYXB0ZXIgPSBrbm93bkFkYXB0ZXJzWyhpZCA9IFN0cmluZyhuYW1lT3JBZGFwdGVyKSkudG9Mb3dlckNhc2UoKV07XG5cbiAgICAgIGlmIChhZGFwdGVyID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoYFVua25vd24gYWRhcHRlciAnJHtpZH0nYCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGFkYXB0ZXIgJiYgKHV0aWxzLmlzRnVuY3Rpb24oYWRhcHRlcikgfHwgKGFkYXB0ZXIgPSBhZGFwdGVyLmdldChjb25maWcpKSkpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHJlamVjdGVkUmVhc29uc1tpZCB8fCAnIycgKyBpXSA9IGFkYXB0ZXI7XG4gIH1cblxuICBpZiAoIWFkYXB0ZXIpIHtcbiAgICBjb25zdCByZWFzb25zID0gT2JqZWN0LmVudHJpZXMocmVqZWN0ZWRSZWFzb25zKS5tYXAoXG4gICAgICAoW2lkLCBzdGF0ZV0pID0+XG4gICAgICAgIGBhZGFwdGVyICR7aWR9IGAgK1xuICAgICAgICAoc3RhdGUgPT09IGZhbHNlID8gJ2lzIG5vdCBzdXBwb3J0ZWQgYnkgdGhlIGVudmlyb25tZW50JyA6ICdpcyBub3QgYXZhaWxhYmxlIGluIHRoZSBidWlsZCcpXG4gICAgKTtcblxuICAgIGxldCBzID0gbGVuZ3RoXG4gICAgICA/IHJlYXNvbnMubGVuZ3RoID4gMVxuICAgICAgICA/ICdzaW5jZSA6XFxuJyArIHJlYXNvbnMubWFwKHJlbmRlclJlYXNvbikuam9pbignXFxuJylcbiAgICAgICAgOiAnICcgKyByZW5kZXJSZWFzb24ocmVhc29uc1swXSlcbiAgICAgIDogJ2FzIG5vIGFkYXB0ZXIgc3BlY2lmaWVkJztcblxuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgYFRoZXJlIGlzIG5vIHN1aXRhYmxlIGFkYXB0ZXIgdG8gZGlzcGF0Y2ggdGhlIHJlcXVlc3QgYCArIHMsXG4gICAgICBBeGlvc0Vycm9yLkVSUl9OT1RfU1VQUE9SVFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gYWRhcHRlcjtcbn1cblxuLyoqXG4gKiBFeHBvcnRzIEF4aW9zIGFkYXB0ZXJzIGFuZCB1dGlsaXR5IHRvIHJlc29sdmUgYW4gYWRhcHRlclxuICovXG5leHBvcnQgZGVmYXVsdCB7XG4gIC8qKlxuICAgKiBSZXNvbHZlIGFuIGFkYXB0ZXIgZnJvbSBhIGxpc3Qgb2YgYWRhcHRlciBuYW1lcyBvciBmdW5jdGlvbnMuXG4gICAqIEB0eXBlIHtGdW5jdGlvbn1cbiAgICovXG4gIGdldEFkYXB0ZXIsXG5cbiAgLyoqXG4gICAqIEV4cG9zZXMgYWxsIGtub3duIGFkYXB0ZXJzXG4gICAqIEB0eXBlIHtPYmplY3Q8c3RyaW5nLCBGdW5jdGlvbnxPYmplY3Q+fVxuICAgKi9cbiAgYWRhcHRlcnM6IGtub3duQWRhcHRlcnMsXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdHJhbnNmb3JtRGF0YSBmcm9tICcuL3RyYW5zZm9ybURhdGEuanMnO1xuaW1wb3J0IGlzQ2FuY2VsIGZyb20gJy4uL2NhbmNlbC9pc0NhbmNlbC5qcyc7XG5pbXBvcnQgZGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvaW5kZXguanMnO1xuaW1wb3J0IENhbmNlbGVkRXJyb3IgZnJvbSAnLi4vY2FuY2VsL0NhbmNlbGVkRXJyb3IuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgYWRhcHRlcnMgZnJvbSAnLi4vYWRhcHRlcnMvYWRhcHRlcnMuanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuLyoqXG4gKiBUaHJvd3MgYSBgQ2FuY2VsZWRFcnJvcmAgaWYgY2FuY2VsbGF0aW9uIGhhcyBiZWVuIHJlcXVlc3RlZC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnIFRoZSBjb25maWcgdGhhdCBpcyB0byBiZSB1c2VkIGZvciB0aGUgcmVxdWVzdFxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5mdW5jdGlvbiB0aHJvd0lmQ2FuY2VsbGF0aW9uUmVxdWVzdGVkKGNvbmZpZykge1xuICBpZiAoY29uZmlnLmNhbmNlbFRva2VuKSB7XG4gICAgY29uZmlnLmNhbmNlbFRva2VuLnRocm93SWZSZXF1ZXN0ZWQoKTtcbiAgfVxuXG4gIGlmIChjb25maWcuc2lnbmFsICYmIGNvbmZpZy5zaWduYWwuYWJvcnRlZCkge1xuICAgIHRocm93IG5ldyBDYW5jZWxlZEVycm9yKG51bGwsIGNvbmZpZyk7XG4gIH1cbn1cblxuLyoqXG4gKiBNaWxsaXNlY29uZHMgZWxhcHNlZCBzaW5jZSBgc3RhcnRgLCBmbG9vcmVkIGF0IHplcm8uXG4gKlxuICogV2FsbC1jbG9jaywgdG8gbWF0Y2ggdGhlIHJlc3Qgb2YgdGhlIGNvZGViYXNlIChzcGVlZG9tZXRlciwgdGhyb3R0bGUsXG4gKiBBeGlvc1RyYW5zZm9ybVN0cmVhbSkuIEEgYmFja3dhcmRzIGNsb2NrIGFkanVzdG1lbnQgbWlkLXJlcXVlc3Qgd291bGRcbiAqIG90aGVyd2lzZSBwcm9kdWNlIGEgbmVnYXRpdmUgZHVyYXRpb24sIHNvIHRoZSByZXN1bHQgaXMgY2xhbXBlZC5cbiAqXG4gKiBAcGFyYW0ge251bWJlcn0gc3RhcnQgVGltZXN0YW1wIGZyb20gYERhdGUubm93KClgXG4gKlxuICogQHJldHVybnMge251bWJlcn0gTm9uLW5lZ2F0aXZlIGVsYXBzZWQgbWlsbGlzZWNvbmRzXG4gKi9cbmZ1bmN0aW9uIGVsYXBzZWRTaW5jZShzdGFydCkge1xuICByZXR1cm4gTWF0aC5tYXgoMCwgRGF0ZS5ub3coKSAtIHN0YXJ0KTtcbn1cblxuLyoqXG4gKiBEaXNwYXRjaCBhIHJlcXVlc3QgdG8gdGhlIHNlcnZlciB1c2luZyB0aGUgY29uZmlndXJlZCBhZGFwdGVyLlxuICpcbiAqIEBwYXJhbSB7b2JqZWN0fSBjb25maWcgVGhlIGNvbmZpZyB0aGF0IGlzIHRvIGJlIHVzZWQgZm9yIHRoZSByZXF1ZXN0XG4gKlxuICogQHJldHVybnMge1Byb21pc2V9IFRoZSBQcm9taXNlIHRvIGJlIGZ1bGZpbGxlZFxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBkaXNwYXRjaFJlcXVlc3QoX2NvbmZpZykge1xuICAvLyBJbnRlcmNlcHRvcnMgbWF5IHJlcGxhY2UgdGhlIG1lcmdlZCBjb25maWcgd2l0aCBhbiBvcmRpbmFyeSBvYmplY3QuIEZsYXR0ZW5cbiAgLy8gaXQgYXQgdGhlIGRpc3BhdGNoIGJvdW5kYXJ5IHNvIHNoYXJlZCBwcm90b3R5cGUgbWVtYmVycyBjYW5ub3QgYmVjb21lXG4gIC8vIHJlcXVlc3QgYmVoYXZpb3IsIHdoaWxlIHByZXNlcnZpbmcgaW50ZW50aW9uYWwgdGVtcGxhdGUvY2xhc3MgbWVtYmVycy5cbiAgY29uc3QgY29uZmlnID0gdXRpbHMudG9TYWZlRmxhdE9iamVjdChfY29uZmlnKTtcblxuICB0aHJvd0lmQ2FuY2VsbGF0aW9uUmVxdWVzdGVkKGNvbmZpZyk7XG5cbiAgY29uZmlnLmhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuZnJvbSh1dGlscy5nZXRTYWZlUHJvcChjb25maWcsICdoZWFkZXJzJykpO1xuXG4gIC8vIFRyYW5zZm9ybSByZXF1ZXN0IGRhdGFcbiAgY29uZmlnLmRhdGEgPSB0cmFuc2Zvcm1EYXRhLmNhbGwoY29uZmlnLCBjb25maWcudHJhbnNmb3JtUmVxdWVzdCk7XG5cbiAgaWYgKFsncG9zdCcsICdwdXQnLCAncGF0Y2gnXS5pbmRleE9mKGNvbmZpZy5tZXRob2QpICE9PSAtMSkge1xuICAgIGNvbmZpZy5oZWFkZXJzLnNldENvbnRlbnRUeXBlKCdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnLCBmYWxzZSk7XG4gIH1cblxuICBjb25zdCBhZGFwdGVyID0gYWRhcHRlcnMuZ2V0QWRhcHRlcihjb25maWcuYWRhcHRlciB8fCBkZWZhdWx0cy5hZGFwdGVyLCBjb25maWcpO1xuXG4gIGNvbnN0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcblxuICByZXR1cm4gYWRhcHRlcihjb25maWcpLnRoZW4oXG4gICAgZnVuY3Rpb24gb25BZGFwdGVyUmVzb2x1dGlvbihyZXNwb25zZSkge1xuICAgICAgdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpO1xuXG4gICAgICByZXNwb25zZS5kdXJhdGlvbiA9IGVsYXBzZWRTaW5jZShzdGFydCk7XG5cbiAgICAgIC8vIEV4cG9zZSB0aGUgY3VycmVudCByZXNwb25zZSBvbiBjb25maWcgc28gdGhhdCB0cmFuc2Zvcm1SZXNwb25zZSBjYW5cbiAgICAgIC8vIGF0dGFjaCBpdCB0byBhbnkgQXhpb3NFcnJvciBpdCB0aHJvd3MgKGUuZy4gb24gSlNPTiBwYXJzZSBmYWlsdXJlKS5cbiAgICAgIC8vIFdlIGNsZWFuIGl0IHVwIGFmdGVyd2FyZHMgdG8gYXZvaWQgcG9sbHV0aW5nIHRoZSBjb25maWcgb2JqZWN0LlxuICAgICAgY29uZmlnLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gICAgICB0cnkge1xuICAgICAgICByZXNwb25zZS5kYXRhID0gdHJhbnNmb3JtRGF0YS5jYWxsKGNvbmZpZywgY29uZmlnLnRyYW5zZm9ybVJlc3BvbnNlLCByZXNwb25zZSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBkZWxldGUgY29uZmlnLnJlc3BvbnNlO1xuICAgICAgfVxuXG4gICAgICByZXNwb25zZS5oZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20ocmVzcG9uc2UuaGVhZGVycyk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9LFxuICAgIGZ1bmN0aW9uIG9uQWRhcHRlclJlamVjdGlvbihyZWFzb24pIHtcbiAgICAgIGlmICghaXNDYW5jZWwocmVhc29uKSkge1xuICAgICAgICB0aHJvd0lmQ2FuY2VsbGF0aW9uUmVxdWVzdGVkKGNvbmZpZyk7XG5cbiAgICAgICAgLy8gVHJhbnNmb3JtIHJlc3BvbnNlIGRhdGFcbiAgICAgICAgaWYgKHJlYXNvbiAmJiByZWFzb24ucmVzcG9uc2UpIHtcbiAgICAgICAgICByZWFzb24ucmVzcG9uc2UuZHVyYXRpb24gPSBlbGFwc2VkU2luY2Uoc3RhcnQpO1xuICAgICAgICAgIGNvbmZpZy5yZXNwb25zZSA9IHJlYXNvbi5yZXNwb25zZTtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmVhc29uLnJlc3BvbnNlLmRhdGEgPSB0cmFuc2Zvcm1EYXRhLmNhbGwoXG4gICAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICAgICAgY29uZmlnLnRyYW5zZm9ybVJlc3BvbnNlLFxuICAgICAgICAgICAgICByZWFzb24ucmVzcG9uc2VcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIGRlbGV0ZSBjb25maWcucmVzcG9uc2U7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJlYXNvbi5yZXNwb25zZS5oZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20ocmVhc29uLnJlc3BvbnNlLmhlYWRlcnMpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChyZWFzb24pO1xuICAgIH1cbiAgKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHsgVkVSU0lPTiB9IGZyb20gJy4uL2Vudi9kYXRhLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5cbmNvbnN0IHZhbGlkYXRvcnMgPSB7fTtcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcblsnb2JqZWN0JywgJ2Jvb2xlYW4nLCAnbnVtYmVyJywgJ2Z1bmN0aW9uJywgJ3N0cmluZycsICdzeW1ib2wnXS5mb3JFYWNoKCh0eXBlLCBpKSA9PiB7XG4gIHZhbGlkYXRvcnNbdHlwZV0gPSBmdW5jdGlvbiB2YWxpZGF0b3IodGhpbmcpIHtcbiAgICByZXR1cm4gdHlwZW9mIHRoaW5nID09PSB0eXBlIHx8ICdhJyArIChpIDwgMSA/ICduICcgOiAnICcpICsgdHlwZTtcbiAgfTtcbn0pO1xuXG5jb25zdCBkZXByZWNhdGVkV2FybmluZ3MgPSB7fTtcblxuLyoqXG4gKiBUcmFuc2l0aW9uYWwgb3B0aW9uIHZhbGlkYXRvclxuICpcbiAqIEBwYXJhbSB7ZnVuY3Rpb258Ym9vbGVhbj99IHZhbGlkYXRvciAtIHNldCB0byBmYWxzZSBpZiB0aGUgdHJhbnNpdGlvbmFsIG9wdGlvbiBoYXMgYmVlbiByZW1vdmVkXG4gKiBAcGFyYW0ge3N0cmluZz99IHZlcnNpb24gLSBkZXByZWNhdGVkIHZlcnNpb24gLyByZW1vdmVkIHNpbmNlIHZlcnNpb25cbiAqIEBwYXJhbSB7c3RyaW5nP30gbWVzc2FnZSAtIHNvbWUgbWVzc2FnZSB3aXRoIGFkZGl0aW9uYWwgaW5mb1xuICpcbiAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAqL1xudmFsaWRhdG9ycy50cmFuc2l0aW9uYWwgPSBmdW5jdGlvbiB0cmFuc2l0aW9uYWwodmFsaWRhdG9yLCB2ZXJzaW9uLCBtZXNzYWdlKSB7XG4gIGZ1bmN0aW9uIGZvcm1hdE1lc3NhZ2Uob3B0LCBkZXNjKSB7XG4gICAgcmV0dXJuIChcbiAgICAgICdbQXhpb3MgdicgK1xuICAgICAgVkVSU0lPTiArXG4gICAgICBcIl0gVHJhbnNpdGlvbmFsIG9wdGlvbiAnXCIgK1xuICAgICAgb3B0ICtcbiAgICAgIFwiJ1wiICtcbiAgICAgIGRlc2MgK1xuICAgICAgKG1lc3NhZ2UgPyAnLiAnICsgbWVzc2FnZSA6ICcnKVxuICAgICk7XG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICByZXR1cm4gKHZhbHVlLCBvcHQsIG9wdHMpID0+IHtcbiAgICBpZiAodmFsaWRhdG9yID09PSBmYWxzZSkge1xuICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgIGZvcm1hdE1lc3NhZ2Uob3B0LCAnIGhhcyBiZWVuIHJlbW92ZWQnICsgKHZlcnNpb24gPyAnIGluICcgKyB2ZXJzaW9uIDogJycpKSxcbiAgICAgICAgQXhpb3NFcnJvci5FUlJfREVQUkVDQVRFRFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAodmVyc2lvbiAmJiAhZGVwcmVjYXRlZFdhcm5pbmdzW29wdF0pIHtcbiAgICAgIGRlcHJlY2F0ZWRXYXJuaW5nc1tvcHRdID0gdHJ1ZTtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIGZvcm1hdE1lc3NhZ2UoXG4gICAgICAgICAgb3B0LFxuICAgICAgICAgICcgaGFzIGJlZW4gZGVwcmVjYXRlZCBzaW5jZSB2JyArIHZlcnNpb24gKyAnIGFuZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5lYXIgZnV0dXJlJ1xuICAgICAgICApXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiB2YWxpZGF0b3IgPyB2YWxpZGF0b3IodmFsdWUsIG9wdCwgb3B0cykgOiB0cnVlO1xuICB9O1xufTtcblxudmFsaWRhdG9ycy5zcGVsbGluZyA9IGZ1bmN0aW9uIHNwZWxsaW5nKGNvcnJlY3RTcGVsbGluZykge1xuICByZXR1cm4gKHZhbHVlLCBvcHQpID0+IHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29uc29sZVxuICAgIGNvbnNvbGUud2FybihgJHtvcHR9IGlzIGxpa2VseSBhIG1pc3NwZWxsaW5nIG9mICR7Y29ycmVjdFNwZWxsaW5nfWApO1xuICAgIHJldHVybiB0cnVlO1xuICB9O1xufTtcblxuLyoqXG4gKiBBc3NlcnQgb2JqZWN0J3MgcHJvcGVydGllcyB0eXBlXG4gKlxuICogQHBhcmFtIHtvYmplY3R9IG9wdGlvbnNcbiAqIEBwYXJhbSB7b2JqZWN0fSBzY2hlbWFcbiAqIEBwYXJhbSB7Ym9vbGVhbj99IGFsbG93VW5rbm93blxuICpcbiAqIEByZXR1cm5zIHtvYmplY3R9XG4gKi9cblxuZnVuY3Rpb24gYXNzZXJ0T3B0aW9ucyhvcHRpb25zLCBzY2hlbWEsIGFsbG93VW5rbm93bikge1xuICBpZiAodHlwZW9mIG9wdGlvbnMgIT09ICdvYmplY3QnIHx8IG9wdGlvbnMgPT09IG51bGwpIHtcbiAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcignb3B0aW9ucyBtdXN0IGJlIGFuIG9iamVjdCcsIEF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT05fVkFMVUUpO1xuICB9XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvcHRpb25zKTtcbiAgbGV0IGkgPSBrZXlzLmxlbmd0aDtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBjb25zdCBvcHQgPSBrZXlzW2ldO1xuICAgIC8vIFVzZSBoYXNPd25Qcm9wZXJ0eSBzbyBhIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUuPG9wdD4gY2Fubm90IHN1cHBseVxuICAgIC8vIGEgbm9uLWZ1bmN0aW9uIHZhbGlkYXRvciBhbmQgY2F1c2UgYSBUeXBlRXJyb3IuXG4gICAgY29uc3QgdmFsaWRhdG9yID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNjaGVtYSwgb3B0KSA/IHNjaGVtYVtvcHRdIDogdW5kZWZpbmVkO1xuICAgIGlmICh2YWxpZGF0b3IpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gb3B0aW9uc1tvcHRdO1xuICAgICAgY29uc3QgcmVzdWx0ID0gdmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWxpZGF0b3IodmFsdWUsIG9wdCwgb3B0aW9ucyk7XG4gICAgICBpZiAocmVzdWx0ICE9PSB0cnVlKSB7XG4gICAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICdvcHRpb24gJyArIG9wdCArICcgbXVzdCBiZSAnICsgcmVzdWx0LFxuICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT05fVkFMVUVcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoYWxsb3dVbmtub3duICE9PSB0cnVlKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcignVW5rbm93biBvcHRpb24gJyArIG9wdCwgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTik7XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgYXNzZXJ0T3B0aW9ucyxcbiAgdmFsaWRhdG9ycyxcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgYnVpbGRVUkwgZnJvbSAnLi4vaGVscGVycy9idWlsZFVSTC5qcyc7XG5pbXBvcnQgSW50ZXJjZXB0b3JNYW5hZ2VyIGZyb20gJy4vSW50ZXJjZXB0b3JNYW5hZ2VyLmpzJztcbmltcG9ydCBkaXNwYXRjaFJlcXVlc3QgZnJvbSAnLi9kaXNwYXRjaFJlcXVlc3QuanMnO1xuaW1wb3J0IG1lcmdlQ29uZmlnIGZyb20gJy4vbWVyZ2VDb25maWcuanMnO1xuaW1wb3J0IGJ1aWxkRnVsbFBhdGggZnJvbSAnLi9idWlsZEZ1bGxQYXRoLmpzJztcbmltcG9ydCBtZXRob2RMaXN0IGZyb20gJy4vbWV0aG9kTGlzdC5qcyc7XG5pbXBvcnQgdmFsaWRhdG9yIGZyb20gJy4uL2hlbHBlcnMvdmFsaWRhdG9yLmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi9BeGlvc0hlYWRlcnMuanMnO1xuaW1wb3J0IHRyYW5zaXRpb25hbERlZmF1bHRzIGZyb20gJy4uL2RlZmF1bHRzL3RyYW5zaXRpb25hbC5qcyc7XG5pbXBvcnQgeyBnZXRDYXVzZVN0YWNrSW5kZXggfSBmcm9tICcuL0F4aW9zRXJyb3IuanMnO1xuXG5jb25zdCB2YWxpZGF0b3JzID0gdmFsaWRhdG9yLnZhbGlkYXRvcnM7XG5cbi8vIFJlY29nbml6ZSBoZWFkZXIgbWFwcyB3aXRob3V0IGNvbnN1bWluZyBvYmplY3RzIGludGVuZGVkIGFzIGxpdGVyYWwgdmFsdWVzLlxuLy8gQXhpb3NIZWFkZXJzIGZyb20gb3RoZXIgYnVpbGRzIHNoYXJlIGEgYnJhbmQgYW5kIGhlYWRlci1jb250YWluZXIgaW50ZXJmYWNlLFxuLy8gYnV0IG5vdCBjb25zdHJ1Y3RvciBpZGVudGl0eS4gQSB0YWcgYW5kIHRvSlNPTiBhbG9uZSBjYW4gZGVzY3JpYmUgYSBsaXRlcmFsLlxuY29uc3QgaXNIZWFkZXJzQnVja2V0ID0gKHZhbHVlKSA9PiB7XG4gIGlmICh2YWx1ZSA9PSBudWxsIHx8IHV0aWxzLmlzUGxhaW5PYmplY3QodmFsdWUpIHx8IHZhbHVlIGluc3RhbmNlb2YgQXhpb3NIZWFkZXJzKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICB0cnkge1xuICAgIHJldHVybiAoXG4gICAgICB1dGlscy5pc09iamVjdCh2YWx1ZSkgJiZcbiAgICAgIHV0aWxzLmdldFNhZmVQcm9wKHZhbHVlLCBTeW1ib2wudG9TdHJpbmdUYWcpID09PSAnQXhpb3NIZWFkZXJzJyAmJlxuICAgICAgW1xuICAgICAgICAndG9KU09OJyxcbiAgICAgICAgJ3NldCcsXG4gICAgICAgICdnZXQnLFxuICAgICAgICAnaGFzJyxcbiAgICAgICAgJ2RlbGV0ZScsXG4gICAgICAgICdjbGVhcicsXG4gICAgICAgICdub3JtYWxpemUnLFxuICAgICAgICAnY29uY2F0JyxcbiAgICAgICAgJ3RvU3RyaW5nJyxcbiAgICAgICAgU3ltYm9sLml0ZXJhdG9yLFxuICAgICAgXS5ldmVyeSgobWV0aG9kKSA9PiB1dGlscy5pc0Z1bmN0aW9uKHV0aWxzLmdldFNhZmVQcm9wKHZhbHVlLCBtZXRob2QpKSlcbiAgICApO1xuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gQSBmYWlsZWQgb3B0aW9uYWwgYnJhbmQgcHJvYmUgbXVzdCBub3QgcHJldmVudCBsaXRlcmFsIGhlYWRlciBzZXJpYWxpemF0aW9uLlxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuLyoqXG4gKiBDcmVhdGUgYSBuZXcgaW5zdGFuY2Ugb2YgQXhpb3NcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gaW5zdGFuY2VDb25maWcgVGhlIGRlZmF1bHQgY29uZmlnIGZvciB0aGUgaW5zdGFuY2VcbiAqXG4gKiBAcmV0dXJuIHtBeGlvc30gQSBuZXcgaW5zdGFuY2Ugb2YgQXhpb3NcbiAqL1xuY2xhc3MgQXhpb3Mge1xuICBjb25zdHJ1Y3RvcihpbnN0YW5jZUNvbmZpZykge1xuICAgIHRoaXMuZGVmYXVsdHMgPSBpbnN0YW5jZUNvbmZpZyB8fCB7fTtcbiAgICB0aGlzLmludGVyY2VwdG9ycyA9IHtcbiAgICAgIHJlcXVlc3Q6IG5ldyBJbnRlcmNlcHRvck1hbmFnZXIoKSxcbiAgICAgIHJlc3BvbnNlOiBuZXcgSW50ZXJjZXB0b3JNYW5hZ2VyKCksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEaXNwYXRjaCBhIHJlcXVlc3RcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd8T2JqZWN0fSBjb25maWdPclVybCBUaGUgY29uZmlnIHNwZWNpZmljIGZvciB0aGlzIHJlcXVlc3QgKG1lcmdlZCB3aXRoIHRoaXMuZGVmYXVsdHMpXG4gICAqIEBwYXJhbSB7P09iamVjdH0gY29uZmlnXG4gICAqXG4gICAqIEByZXR1cm5zIHtQcm9taXNlfSBUaGUgUHJvbWlzZSB0byBiZSBmdWxmaWxsZWRcbiAgICovXG4gIGFzeW5jIHJlcXVlc3QoY29uZmlnT3JVcmwsIGNvbmZpZykge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5fcmVxdWVzdChjb25maWdPclVybCwgY29uZmlnKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGxldCBkdW1teSA9IHt9O1xuXG4gICAgICAgICAgRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UgPyBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZShkdW1teSkgOiAoZHVtbXkgPSBuZXcgRXJyb3IoKSk7XG5cbiAgICAgICAgICBjb25zdCBkdW1teVN0YWNrID0gZHVtbXkuc3RhY2s7XG4gICAgICAgICAgbGV0IHN0YWNrID0gJyc7XG5cbiAgICAgICAgICAvLyBzbGljZSBvZmYgdGhlIEVycm9yOiAuLi4gbGluZVxuICAgICAgICAgIGlmICh0eXBlb2YgZHVtbXlTdGFjayA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0TmV3bGluZUluZGV4ID0gZHVtbXlTdGFjay5pbmRleE9mKCdcXG4nKTtcblxuICAgICAgICAgICAgc3RhY2sgPSBmaXJzdE5ld2xpbmVJbmRleCA9PT0gLTEgPyAnJyA6IGR1bW15U3RhY2suc2xpY2UoZmlyc3ROZXdsaW5lSW5kZXggKyAxKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoIWVyci5zdGFjaykge1xuICAgICAgICAgICAgZXJyLnN0YWNrID0gc3RhY2s7XG4gICAgICAgICAgfSBlbHNlIGlmIChzdGFjaykge1xuICAgICAgICAgICAgLy8gTWF0Y2ggYSBjb21tb24gc3VmZml4IGFmdGVyIHRoZSAyIHRvcCBmcmFtZXMgd2hlbiBhdmFpbGFibGUsXG4gICAgICAgICAgICAvLyBvdGhlcndpc2UgY29tcGFyZSB0aGUgZnVsbCByZWNvbnN0cnVjdGVkIHN0YWNrLlxuICAgICAgICAgICAgY29uc3QgZmlyc3ROZXdsaW5lSW5kZXggPSBzdGFjay5pbmRleE9mKCdcXG4nKTtcbiAgICAgICAgICAgIGNvbnN0IHNlY29uZE5ld2xpbmVJbmRleCA9XG4gICAgICAgICAgICAgIGZpcnN0TmV3bGluZUluZGV4ID09PSAtMSA/IC0xIDogc3RhY2suaW5kZXhPZignXFxuJywgZmlyc3ROZXdsaW5lSW5kZXggKyAxKTtcbiAgICAgICAgICAgIGNvbnN0IGR1cGxpY2F0ZUNoZWNrU3VmZml4ID1cbiAgICAgICAgICAgICAgc2Vjb25kTmV3bGluZUluZGV4ID09PSAtMSA/IHN0YWNrIDogc3RhY2suc2xpY2Uoc2Vjb25kTmV3bGluZUluZGV4ICsgMSk7XG5cbiAgICAgICAgICAgIC8vIGBBeGlvc0Vycm9yLmZyb20oKWAgbWF5IGhhdmUgYWxyZWFkeSBpbmxpbmVkIHRoZSB3cmFwcGVkIGVycm9yJ3NcbiAgICAgICAgICAgIC8vIHN0YWNrIHVuZGVyIGEgYENhdXNlZCBieTpgIG1hcmtlci4gS2VlcCB0aGUgcmVjb25zdHJ1Y3RlZCBjYWxsZXJcbiAgICAgICAgICAgIC8vIGZyYW1lcyBhaGVhZCBvZiB0aGF0IG1hcmtlciBzbyBzdGFjay1vbmx5IHJlcG9ydGVycyBkbyBub3QgcmVhZFxuICAgICAgICAgICAgLy8gdGhlbSBhcyBwYXJ0IG9mIHRoZSBsb3ctbGV2ZWwgY2F1c2UuXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50U3RhY2sgPSBTdHJpbmcoZXJyLnN0YWNrKTtcbiAgICAgICAgICAgIGNvbnN0IGNhdXNlSW5kZXggPSBnZXRDYXVzZVN0YWNrSW5kZXgoZXJyLCBjdXJyZW50U3RhY2spO1xuICAgICAgICAgICAgY29uc3Qgc3RhY2tIZWFkID0gY2F1c2VJbmRleCA9PT0gLTEgPyBjdXJyZW50U3RhY2sgOiBjdXJyZW50U3RhY2suc2xpY2UoMCwgY2F1c2VJbmRleCk7XG4gICAgICAgICAgICBjb25zdCBjYXVzZVNlY3Rpb24gPSBjYXVzZUluZGV4ID09PSAtMSA/ICcnIDogY3VycmVudFN0YWNrLnNsaWNlKGNhdXNlSW5kZXgpO1xuXG4gICAgICAgICAgICBpZiAoIXN0YWNrSGVhZC5lbmRzV2l0aChkdXBsaWNhdGVDaGVja1N1ZmZpeCkpIHtcbiAgICAgICAgICAgICAgZXJyLnN0YWNrID0gc3RhY2tIZWFkICsgJ1xcbicgKyBzdGFjayArIGNhdXNlU2VjdGlvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBJZ25vcmUgZmFpbHVyZXMgZnJvbSBjdXN0b20gc3RhY2sgaG9va3Mgb3IgdW4td3JpdGFibGUgc3RhY2sgcHJvcGVydGllcy5cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgX3JlcXVlc3QoY29uZmlnT3JVcmwsIGNvbmZpZykge1xuICAgIC8qZXNsaW50IG5vLXBhcmFtLXJlYXNzaWduOjAqL1xuICAgIC8vIEFsbG93IGZvciBheGlvcygnZXhhbXBsZS91cmwnWywgY29uZmlnXSkgYSBsYSBmZXRjaCBBUElcbiAgICBpZiAodHlwZW9mIGNvbmZpZ09yVXJsID09PSAnc3RyaW5nJykge1xuICAgICAgY29uZmlnID0gY29uZmlnIHx8IHt9O1xuICAgICAgY29uZmlnLnVybCA9IGNvbmZpZ09yVXJsO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25maWcgPSBjb25maWdPclVybCB8fCB7fTtcbiAgICB9XG5cbiAgICBjb25maWcgPSBtZXJnZUNvbmZpZyh0aGlzLmRlZmF1bHRzLCBjb25maWcpO1xuXG4gICAgY29uc3QgeyB0cmFuc2l0aW9uYWwsIHBhcmFtc1NlcmlhbGl6ZXIsIGhlYWRlcnMgfSA9IGNvbmZpZztcblxuICAgIGlmICh0cmFuc2l0aW9uYWwgIT09IHVuZGVmaW5lZCkge1xuICAgICAgdmFsaWRhdG9yLmFzc2VydE9wdGlvbnMoXG4gICAgICAgIHRyYW5zaXRpb25hbCxcbiAgICAgICAge1xuICAgICAgICAgIHNpbGVudEpTT05QYXJzaW5nOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICAgIGZvcmNlZEpTT05QYXJzaW5nOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICAgIGNsYXJpZnlUaW1lb3V0RXJyb3I6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICAgICAgbGVnYWN5SW50ZXJjZXB0b3JSZXFSZXNPcmRlcmluZzogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgICAgICBhZHZlcnRpc2Vac3RkQWNjZXB0RW5jb2Rpbmc6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICAgICAgdmFsaWRhdGVTdGF0dXNVbmRlZmluZWRSZXNvbHZlczogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgICAgICBlbmNvZGVCYXNpY0F1dGhVc2VybmFtZTogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgICAgfSxcbiAgICAgICAgZmFsc2VcbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKHBhcmFtc1NlcmlhbGl6ZXIgIT0gbnVsbCkge1xuICAgICAgaWYgKHV0aWxzLmlzRnVuY3Rpb24ocGFyYW1zU2VyaWFsaXplcikpIHtcbiAgICAgICAgY29uZmlnLnBhcmFtc1NlcmlhbGl6ZXIgPSB7XG4gICAgICAgICAgc2VyaWFsaXplOiBwYXJhbXNTZXJpYWxpemVyLFxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFsaWRhdG9yLmFzc2VydE9wdGlvbnMoXG4gICAgICAgICAgcGFyYW1zU2VyaWFsaXplcixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBlbmNvZGU6IHZhbGlkYXRvcnMuZnVuY3Rpb24sXG4gICAgICAgICAgICBzZXJpYWxpemU6IHZhbGlkYXRvcnMuZnVuY3Rpb24sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0cnVlXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gU2V0IGNvbmZpZy5hbGxvd0Fic29sdXRlVXJsc1xuICAgIGlmIChjb25maWcuYWxsb3dBYnNvbHV0ZVVybHMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgLy8gZG8gbm90aGluZ1xuICAgIH0gZWxzZSBpZiAoXG4gICAgICB1dGlscy5oYXNPd25Qcm9wKHRoaXMuZGVmYXVsdHMsICdhbGxvd0Fic29sdXRlVXJscycpICYmXG4gICAgICB0aGlzLmRlZmF1bHRzLmFsbG93QWJzb2x1dGVVcmxzICE9PSB1bmRlZmluZWRcbiAgICApIHtcbiAgICAgIGNvbmZpZy5hbGxvd0Fic29sdXRlVXJscyA9IHRoaXMuZGVmYXVsdHMuYWxsb3dBYnNvbHV0ZVVybHM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbmZpZy5hbGxvd0Fic29sdXRlVXJscyA9IHRydWU7XG4gICAgfVxuXG4gICAgdmFsaWRhdG9yLmFzc2VydE9wdGlvbnMoXG4gICAgICBjb25maWcsXG4gICAgICB7XG4gICAgICAgIGJhc2VVcmw6IHZhbGlkYXRvcnMuc3BlbGxpbmcoJ2Jhc2VVUkwnKSxcbiAgICAgICAgd2l0aFhzcmZUb2tlbjogdmFsaWRhdG9ycy5zcGVsbGluZygnd2l0aFhTUkZUb2tlbicpLFxuICAgICAgfSxcbiAgICAgIHRydWVcbiAgICApO1xuXG4gICAgLy8gU2V0IGNvbmZpZy5tZXRob2RcbiAgICBjb25maWcubWV0aG9kID0gKFxuICAgICAgdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnLCAnbWV0aG9kJykgfHxcbiAgICAgIHV0aWxzLmdldFNhZmVQcm9wKHRoaXMuZGVmYXVsdHMsICdtZXRob2QnKSB8fFxuICAgICAgJ2dldCdcbiAgICApLnRvTG93ZXJDYXNlKCk7XG5cbiAgICAvLyBGbGF0dGVuIGhlYWRlciBkZWZhdWx0cyB3aXRob3V0IGNvbnN1bWluZyBsaXRlcmFsIG1ldGhvZC1uYW1lZCBoZWFkZXJzLlxuICAgIGNvbnN0IGNvbW1vbkhlYWRlcnMgPSB1dGlscy5nZXRTYWZlUHJvcChoZWFkZXJzLCAnY29tbW9uJyk7XG4gICAgY29uc3QgbWV0aG9kSGVhZGVycyA9IHV0aWxzLmdldFNhZmVQcm9wKGhlYWRlcnMsIGNvbmZpZy5tZXRob2QpO1xuICAgIGNvbnN0IGNvbnRleHRIZWFkZXJzID1cbiAgICAgIGhlYWRlcnMgJiZcbiAgICAgIHV0aWxzLm1lcmdlKFxuICAgICAgICBpc0hlYWRlcnNCdWNrZXQoY29tbW9uSGVhZGVycykgPyBjb21tb25IZWFkZXJzIDogdW5kZWZpbmVkLFxuICAgICAgICBpc0hlYWRlcnNCdWNrZXQobWV0aG9kSGVhZGVycykgPyBtZXRob2RIZWFkZXJzIDogdW5kZWZpbmVkXG4gICAgICApO1xuXG4gICAgaGVhZGVycyAmJlxuICAgICAgdXRpbHMuZm9yRWFjaChtZXRob2RMaXN0LmNvbmNhdCgnY29tbW9uJyksIChtZXRob2QpID0+IHtcbiAgICAgICAgaWYgKGlzSGVhZGVyc0J1Y2tldCh1dGlscy5nZXRTYWZlUHJvcChoZWFkZXJzLCBtZXRob2QpKSkge1xuICAgICAgICAgIGRlbGV0ZSBoZWFkZXJzW21ldGhvZF07XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgY29uZmlnLmhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuY29uY2F0KGNvbnRleHRIZWFkZXJzLCBoZWFkZXJzKTtcblxuICAgIC8vIGZpbHRlciBvdXQgc2tpcHBlZCBpbnRlcmNlcHRvcnNcbiAgICBjb25zdCByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbiA9IFtdO1xuICAgIGxldCBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgPSB0cnVlO1xuICAgIHRoaXMuaW50ZXJjZXB0b3JzLnJlcXVlc3QuZm9yRWFjaChmdW5jdGlvbiB1bnNoaWZ0UmVxdWVzdEludGVyY2VwdG9ycyhpbnRlcmNlcHRvcikge1xuICAgICAgaWYgKHR5cGVvZiBpbnRlcmNlcHRvci5ydW5XaGVuID09PSAnZnVuY3Rpb24nICYmIGludGVyY2VwdG9yLnJ1bldoZW4oY29uZmlnKSA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgPSBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgJiYgaW50ZXJjZXB0b3Iuc3luY2hyb25vdXM7XG5cbiAgICAgIGNvbnN0IHRyYW5zaXRpb25hbCA9IGNvbmZpZy50cmFuc2l0aW9uYWwgfHwgdHJhbnNpdGlvbmFsRGVmYXVsdHM7XG4gICAgICBjb25zdCBsZWdhY3lJbnRlcmNlcHRvclJlcVJlc09yZGVyaW5nID1cbiAgICAgICAgdHJhbnNpdGlvbmFsICYmIHRyYW5zaXRpb25hbC5sZWdhY3lJbnRlcmNlcHRvclJlcVJlc09yZGVyaW5nO1xuXG4gICAgICBpZiAobGVnYWN5SW50ZXJjZXB0b3JSZXFSZXNPcmRlcmluZykge1xuICAgICAgICByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbi51bnNoaWZ0KGludGVyY2VwdG9yLmZ1bGZpbGxlZCwgaW50ZXJjZXB0b3IucmVqZWN0ZWQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVxdWVzdEludGVyY2VwdG9yQ2hhaW4ucHVzaChpbnRlcmNlcHRvci5mdWxmaWxsZWQsIGludGVyY2VwdG9yLnJlamVjdGVkKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGNvbnN0IHJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbiA9IFtdO1xuICAgIHRoaXMuaW50ZXJjZXB0b3JzLnJlc3BvbnNlLmZvckVhY2goZnVuY3Rpb24gcHVzaFJlc3BvbnNlSW50ZXJjZXB0b3JzKGludGVyY2VwdG9yKSB7XG4gICAgICByZXNwb25zZUludGVyY2VwdG9yQ2hhaW4ucHVzaChpbnRlcmNlcHRvci5mdWxmaWxsZWQsIGludGVyY2VwdG9yLnJlamVjdGVkKTtcbiAgICB9KTtcblxuICAgIGxldCBwcm9taXNlO1xuICAgIGxldCBpID0gMDtcbiAgICBsZXQgbGVuO1xuXG4gICAgaWYgKCFzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMpIHtcbiAgICAgIGNvbnN0IGNoYWluID0gW2Rpc3BhdGNoUmVxdWVzdC5iaW5kKHRoaXMpLCB1bmRlZmluZWRdO1xuICAgICAgY2hhaW4udW5zaGlmdCguLi5yZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbik7XG4gICAgICBjaGFpbi5wdXNoKC4uLnJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbik7XG4gICAgICBsZW4gPSBjaGFpbi5sZW5ndGg7XG5cbiAgICAgIHByb21pc2UgPSBQcm9taXNlLnJlc29sdmUoY29uZmlnKTtcblxuICAgICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgICAgcHJvbWlzZSA9IHByb21pc2UudGhlbihjaGFpbltpKytdLCBjaGFpbltpKytdKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfVxuXG4gICAgbGVuID0gcmVxdWVzdEludGVyY2VwdG9yQ2hhaW4ubGVuZ3RoO1xuXG4gICAgbGV0IG5ld0NvbmZpZyA9IGNvbmZpZztcblxuICAgIHdoaWxlIChpIDwgbGVuKSB7XG4gICAgICBjb25zdCBvbkZ1bGZpbGxlZCA9IHJlcXVlc3RJbnRlcmNlcHRvckNoYWluW2krK107XG4gICAgICBjb25zdCBvblJlamVjdGVkID0gcmVxdWVzdEludGVyY2VwdG9yQ2hhaW5baSsrXTtcbiAgICAgIHRyeSB7XG4gICAgICAgIG5ld0NvbmZpZyA9IG9uRnVsZmlsbGVkID8gb25GdWxmaWxsZWQobmV3Q29uZmlnKSA6IG5ld0NvbmZpZztcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmICghb25SZWplY3RlZCkge1xuICAgICAgICAgIHByb21pc2UgPSBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHJlamVjdGVkUmVzdWx0ID0gb25SZWplY3RlZC5jYWxsKHRoaXMsIGVycm9yKTtcblxuICAgICAgICAgIGlmICh1dGlscy5pc1RoZW5hYmxlKHJlamVjdGVkUmVzdWx0KSkge1xuICAgICAgICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZShyZWplY3RlZFJlc3VsdCkudGhlbigoKSA9PlxuICAgICAgICAgICAgICBkaXNwYXRjaFJlcXVlc3QuY2FsbCh0aGlzLCBuZXdDb25maWcpXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAocmVqZWN0ZWRFcnJvcikge1xuICAgICAgICAgIHByb21pc2UgPSBQcm9taXNlLnJlamVjdChyZWplY3RlZEVycm9yKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICghcHJvbWlzZSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcHJvbWlzZSA9IGRpc3BhdGNoUmVxdWVzdC5jYWxsKHRoaXMsIG5ld0NvbmZpZyk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBwcm9taXNlID0gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGkgPSAwO1xuICAgIGxlbiA9IHJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbi5sZW5ndGg7XG5cbiAgICB3aGlsZSAoaSA8IGxlbikge1xuICAgICAgcHJvbWlzZSA9IHByb21pc2UudGhlbihyZXNwb25zZUludGVyY2VwdG9yQ2hhaW5baSsrXSwgcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluW2krK10pO1xuICAgIH1cblxuICAgIHJldHVybiBwcm9taXNlO1xuICB9XG5cbiAgZ2V0VXJpKGNvbmZpZykge1xuICAgIGNvbmZpZyA9IG1lcmdlQ29uZmlnKHRoaXMuZGVmYXVsdHMsIGNvbmZpZyk7XG4gICAgY29uc3QgZnVsbFBhdGggPSBidWlsZEZ1bGxQYXRoKGNvbmZpZy5iYXNlVVJMLCBjb25maWcudXJsLCBjb25maWcuYWxsb3dBYnNvbHV0ZVVybHMsIGNvbmZpZyk7XG4gICAgcmV0dXJuIGJ1aWxkVVJMKGZ1bGxQYXRoLCBjb25maWcucGFyYW1zLCBjb25maWcucGFyYW1zU2VyaWFsaXplcik7XG4gIH1cbn1cblxuLy8gUHJvdmlkZSBhbGlhc2VzIGZvciBzdXBwb3J0ZWQgcmVxdWVzdCBtZXRob2RzXG51dGlscy5mb3JFYWNoKFsnZGVsZXRlJywgJ2dldCcsICdoZWFkJywgJ29wdGlvbnMnXSwgZnVuY3Rpb24gZm9yRWFjaE1ldGhvZE5vRGF0YShtZXRob2QpIHtcbiAgLyplc2xpbnQgZnVuYy1uYW1lczowKi9cbiAgQXhpb3MucHJvdG90eXBlW21ldGhvZF0gPSBhc3luYyBmdW5jdGlvbiAodXJsLCBjb25maWcpIHtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KFxuICAgICAgbWVyZ2VDb25maWcoY29uZmlnIHx8IHt9LCB7XG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgdXJsLFxuICAgICAgICBkYXRhOiBjb25maWcgJiYgdXRpbHMuaGFzT3duUHJvcChjb25maWcsICdkYXRhJykgPyBjb25maWcuZGF0YSA6IHVuZGVmaW5lZCxcbiAgICAgIH0pXG4gICAgKTtcbiAgfTtcbn0pO1xuXG51dGlscy5mb3JFYWNoKFsncG9zdCcsICdwdXQnLCAncGF0Y2gnLCAncXVlcnknXSwgZnVuY3Rpb24gZm9yRWFjaE1ldGhvZFdpdGhEYXRhKG1ldGhvZCkge1xuICBmdW5jdGlvbiBnZW5lcmF0ZUhUVFBNZXRob2QoaXNGb3JtKSB7XG4gICAgcmV0dXJuIGFzeW5jIGZ1bmN0aW9uIGh0dHBNZXRob2QodXJsLCBkYXRhLCBjb25maWcpIHtcbiAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoXG4gICAgICAgIG1lcmdlQ29uZmlnKGNvbmZpZyB8fCB7fSwge1xuICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICBoZWFkZXJzOiBpc0Zvcm1cbiAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnbXVsdGlwYXJ0L2Zvcm0tZGF0YScsXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDoge30sXG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIGRhdGEsXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH07XG4gIH1cblxuICBBeGlvcy5wcm90b3R5cGVbbWV0aG9kXSA9IGdlbmVyYXRlSFRUUE1ldGhvZCgpO1xuXG4gIC8vIFFVRVJZIGlzIGEgc2FmZS9pZGVtcG90ZW50IHJlYWQgbWV0aG9kOyBtdWx0aXBhcnQgZm9ybSBib2RpZXMgZG9uJ3QgZml0XG4gIC8vIGl0cyBzZW1hbnRpY3MsIHNvIG5vIHF1ZXJ5Rm9ybSBzaG9ydGhhbmQgaXMgZ2VuZXJhdGVkLlxuICBpZiAobWV0aG9kICE9PSAncXVlcnknKSB7XG4gICAgQXhpb3MucHJvdG90eXBlW21ldGhvZCArICdGb3JtJ10gPSBnZW5lcmF0ZUhUVFBNZXRob2QodHJ1ZSk7XG4gIH1cbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBBeGlvcztcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IENhbmNlbGVkRXJyb3IgZnJvbSAnLi9DYW5jZWxlZEVycm9yLmpzJztcblxuLyoqXG4gKiBBIGBDYW5jZWxUb2tlbmAgaXMgYW4gb2JqZWN0IHRoYXQgY2FuIGJlIHVzZWQgdG8gcmVxdWVzdCBjYW5jZWxsYXRpb24gb2YgYW4gb3BlcmF0aW9uLlxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGV4ZWN1dG9yIFRoZSBleGVjdXRvciBmdW5jdGlvbi5cbiAqXG4gKiBAcmV0dXJucyB7Q2FuY2VsVG9rZW59XG4gKi9cbmNsYXNzIENhbmNlbFRva2VuIHtcbiAgY29uc3RydWN0b3IoZXhlY3V0b3IpIHtcbiAgICBpZiAodHlwZW9mIGV4ZWN1dG9yICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdleGVjdXRvciBtdXN0IGJlIGEgZnVuY3Rpb24uJyk7XG4gICAgfVxuXG4gICAgbGV0IHJlc29sdmVQcm9taXNlO1xuXG4gICAgdGhpcy5wcm9taXNlID0gbmV3IFByb21pc2UoZnVuY3Rpb24gcHJvbWlzZUV4ZWN1dG9yKHJlc29sdmUpIHtcbiAgICAgIHJlc29sdmVQcm9taXNlID0gcmVzb2x2ZTtcbiAgICB9KTtcblxuICAgIGNvbnN0IHRva2VuID0gdGhpcztcblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gICAgdGhpcy5wcm9taXNlLnRoZW4oKGNhbmNlbCkgPT4ge1xuICAgICAgaWYgKCF0b2tlbi5fbGlzdGVuZXJzKSByZXR1cm47XG5cbiAgICAgIGxldCBpID0gdG9rZW4uX2xpc3RlbmVycy5sZW5ndGg7XG5cbiAgICAgIHdoaWxlIChpLS0gPiAwKSB7XG4gICAgICAgIHRva2VuLl9saXN0ZW5lcnNbaV0oY2FuY2VsKTtcbiAgICAgIH1cbiAgICAgIHRva2VuLl9saXN0ZW5lcnMgPSBudWxsO1xuICAgIH0pO1xuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbiAgICB0aGlzLnByb21pc2UudGhlbiA9IChvbmZ1bGZpbGxlZCkgPT4ge1xuICAgICAgbGV0IF9yZXNvbHZlO1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbiAgICAgIGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICB0b2tlbi5zdWJzY3JpYmUocmVzb2x2ZSk7XG4gICAgICAgIF9yZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgIH0pLnRoZW4ob25mdWxmaWxsZWQpO1xuXG4gICAgICBwcm9taXNlLmNhbmNlbCA9IGZ1bmN0aW9uIHJlamVjdCgpIHtcbiAgICAgICAgdG9rZW4udW5zdWJzY3JpYmUoX3Jlc29sdmUpO1xuICAgICAgfTtcblxuICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfTtcblxuICAgIGV4ZWN1dG9yKGZ1bmN0aW9uIGNhbmNlbChtZXNzYWdlLCBjb25maWcsIHJlcXVlc3QpIHtcbiAgICAgIGlmICh0b2tlbi5yZWFzb24pIHtcbiAgICAgICAgLy8gQ2FuY2VsbGF0aW9uIGhhcyBhbHJlYWR5IGJlZW4gcmVxdWVzdGVkXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgdG9rZW4ucmVhc29uID0gbmV3IENhbmNlbGVkRXJyb3IobWVzc2FnZSwgY29uZmlnLCByZXF1ZXN0KTtcbiAgICAgIHJlc29sdmVQcm9taXNlKHRva2VuLnJlYXNvbik7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVGhyb3dzIGEgYENhbmNlbGVkRXJyb3JgIGlmIGNhbmNlbGxhdGlvbiBoYXMgYmVlbiByZXF1ZXN0ZWQuXG4gICAqL1xuICB0aHJvd0lmUmVxdWVzdGVkKCkge1xuICAgIGlmICh0aGlzLnJlYXNvbikge1xuICAgICAgdGhyb3cgdGhpcy5yZWFzb247XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFN1YnNjcmliZSB0byB0aGUgY2FuY2VsIHNpZ25hbFxuICAgKi9cblxuICBzdWJzY3JpYmUobGlzdGVuZXIpIHtcbiAgICBpZiAodGhpcy5yZWFzb24pIHtcbiAgICAgIGxpc3RlbmVyKHRoaXMucmVhc29uKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5fbGlzdGVuZXJzKSB7XG4gICAgICB0aGlzLl9saXN0ZW5lcnMucHVzaChsaXN0ZW5lcik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2xpc3RlbmVycyA9IFtsaXN0ZW5lcl07XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFVuc3Vic2NyaWJlIGZyb20gdGhlIGNhbmNlbCBzaWduYWxcbiAgICovXG5cbiAgdW5zdWJzY3JpYmUobGlzdGVuZXIpIHtcbiAgICBpZiAoIXRoaXMuX2xpc3RlbmVycykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpbmRleCA9IHRoaXMuX2xpc3RlbmVycy5pbmRleE9mKGxpc3RlbmVyKTtcbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICB0aGlzLl9saXN0ZW5lcnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICB9XG4gIH1cblxuICB0b0Fib3J0U2lnbmFsKCkge1xuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cbiAgICBjb25zdCBhYm9ydCA9IChlcnIpID0+IHtcbiAgICAgIGNvbnRyb2xsZXIuYWJvcnQoZXJyKTtcbiAgICB9O1xuXG4gICAgdGhpcy5zdWJzY3JpYmUoYWJvcnQpO1xuXG4gICAgY29udHJvbGxlci5zaWduYWwudW5zdWJzY3JpYmUgPSAoKSA9PiB0aGlzLnVuc3Vic2NyaWJlKGFib3J0KTtcblxuICAgIHJldHVybiBjb250cm9sbGVyLnNpZ25hbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGFuIG9iamVjdCB0aGF0IGNvbnRhaW5zIGEgbmV3IGBDYW5jZWxUb2tlbmAgYW5kIGEgZnVuY3Rpb24gdGhhdCwgd2hlbiBjYWxsZWQsXG4gICAqIGNhbmNlbHMgdGhlIGBDYW5jZWxUb2tlbmAuXG4gICAqL1xuICBzdGF0aWMgc291cmNlKCkge1xuICAgIGxldCBjYW5jZWw7XG4gICAgY29uc3QgdG9rZW4gPSBuZXcgQ2FuY2VsVG9rZW4oZnVuY3Rpb24gZXhlY3V0b3IoYykge1xuICAgICAgY2FuY2VsID0gYztcbiAgICB9KTtcbiAgICByZXR1cm4ge1xuICAgICAgdG9rZW4sXG4gICAgICBjYW5jZWwsXG4gICAgfTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDYW5jZWxUb2tlbjtcbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBTeW50YWN0aWMgc3VnYXIgZm9yIGludm9raW5nIGEgZnVuY3Rpb24gYW5kIGV4cGFuZGluZyBhbiBhcnJheSBmb3IgYXJndW1lbnRzLlxuICpcbiAqIENvbW1vbiB1c2UgY2FzZSB3b3VsZCBiZSB0byB1c2UgYEZ1bmN0aW9uLnByb3RvdHlwZS5hcHBseWAuXG4gKlxuICogIGBgYGpzXG4gKiAgZnVuY3Rpb24gZih4LCB5LCB6KSB7fVxuICogIGNvbnN0IGFyZ3MgPSBbMSwgMiwgM107XG4gKiAgZi5hcHBseShudWxsLCBhcmdzKTtcbiAqICBgYGBcbiAqXG4gKiBXaXRoIGBzcHJlYWRgIHRoaXMgZXhhbXBsZSBjYW4gYmUgcmUtd3JpdHRlbi5cbiAqXG4gKiAgYGBganNcbiAqICBzcHJlYWQoZnVuY3Rpb24oeCwgeSwgeikge30pKFsxLCAyLCAzXSk7XG4gKiAgYGBgXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2tcbiAqXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259XG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHNwcmVhZChjYWxsYmFjaykge1xuICByZXR1cm4gZnVuY3Rpb24gd3JhcChhcnIpIHtcbiAgICByZXR1cm4gY2FsbGJhY2suYXBwbHkobnVsbCwgYXJyKTtcbiAgfTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgdGhlIHBheWxvYWQgaXMgYW4gZXJyb3IgdGhyb3duIGJ5IEF4aW9zXG4gKlxuICogQHBhcmFtIHsqfSBwYXlsb2FkIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHBheWxvYWQgaXMgYW4gZXJyb3IgdGhyb3duIGJ5IEF4aW9zLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNBeGlvc0Vycm9yKHBheWxvYWQpIHtcbiAgcmV0dXJuIHV0aWxzLmlzT2JqZWN0KHBheWxvYWQpICYmIHBheWxvYWQuaXNBeGlvc0Vycm9yID09PSB0cnVlO1xufVxuIiwiY29uc3QgSHR0cFN0YXR1c0NvZGUgPSB7XG4gIENvbnRpbnVlOiAxMDAsXG4gIFN3aXRjaGluZ1Byb3RvY29sczogMTAxLFxuICBQcm9jZXNzaW5nOiAxMDIsXG4gIEVhcmx5SGludHM6IDEwMyxcbiAgT2s6IDIwMCxcbiAgQ3JlYXRlZDogMjAxLFxuICBBY2NlcHRlZDogMjAyLFxuICBOb25BdXRob3JpdGF0aXZlSW5mb3JtYXRpb246IDIwMyxcbiAgTm9Db250ZW50OiAyMDQsXG4gIFJlc2V0Q29udGVudDogMjA1LFxuICBQYXJ0aWFsQ29udGVudDogMjA2LFxuICBNdWx0aVN0YXR1czogMjA3LFxuICBBbHJlYWR5UmVwb3J0ZWQ6IDIwOCxcbiAgSW1Vc2VkOiAyMjYsXG4gIE11bHRpcGxlQ2hvaWNlczogMzAwLFxuICBNb3ZlZFBlcm1hbmVudGx5OiAzMDEsXG4gIEZvdW5kOiAzMDIsXG4gIFNlZU90aGVyOiAzMDMsXG4gIE5vdE1vZGlmaWVkOiAzMDQsXG4gIFVzZVByb3h5OiAzMDUsXG4gIFVudXNlZDogMzA2LFxuICBUZW1wb3JhcnlSZWRpcmVjdDogMzA3LFxuICBQZXJtYW5lbnRSZWRpcmVjdDogMzA4LFxuICBCYWRSZXF1ZXN0OiA0MDAsXG4gIFVuYXV0aG9yaXplZDogNDAxLFxuICBQYXltZW50UmVxdWlyZWQ6IDQwMixcbiAgRm9yYmlkZGVuOiA0MDMsXG4gIE5vdEZvdW5kOiA0MDQsXG4gIE1ldGhvZE5vdEFsbG93ZWQ6IDQwNSxcbiAgTm90QWNjZXB0YWJsZTogNDA2LFxuICBQcm94eUF1dGhlbnRpY2F0aW9uUmVxdWlyZWQ6IDQwNyxcbiAgUmVxdWVzdFRpbWVvdXQ6IDQwOCxcbiAgQ29uZmxpY3Q6IDQwOSxcbiAgR29uZTogNDEwLFxuICBMZW5ndGhSZXF1aXJlZDogNDExLFxuICBQcmVjb25kaXRpb25GYWlsZWQ6IDQxMixcbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIFVzZSBgQ29udGVudFRvb0xhcmdlYCBpbnN0ZWFkLlxuICAgKi9cbiAgUGF5bG9hZFRvb0xhcmdlOiA0MTMsXG4gIENvbnRlbnRUb29MYXJnZTogNDEzLFxuICBVcmlUb29Mb25nOiA0MTQsXG4gIFVuc3VwcG9ydGVkTWVkaWFUeXBlOiA0MTUsXG4gIFJhbmdlTm90U2F0aXNmaWFibGU6IDQxNixcbiAgRXhwZWN0YXRpb25GYWlsZWQ6IDQxNyxcbiAgSW1BVGVhcG90OiA0MTgsXG4gIE1pc2RpcmVjdGVkUmVxdWVzdDogNDIxLFxuICAvKipcbiAgICogQGRlcHJlY2F0ZWQgVXNlIGBVbnByb2Nlc3NhYmxlQ29udGVudGAgaW5zdGVhZC5cbiAgICovXG4gIFVucHJvY2Vzc2FibGVFbnRpdHk6IDQyMixcbiAgVW5wcm9jZXNzYWJsZUNvbnRlbnQ6IDQyMixcbiAgTG9ja2VkOiA0MjMsXG4gIEZhaWxlZERlcGVuZGVuY3k6IDQyNCxcbiAgVG9vRWFybHk6IDQyNSxcbiAgVXBncmFkZVJlcXVpcmVkOiA0MjYsXG4gIFByZWNvbmRpdGlvblJlcXVpcmVkOiA0MjgsXG4gIFRvb01hbnlSZXF1ZXN0czogNDI5LFxuICBSZXF1ZXN0SGVhZGVyRmllbGRzVG9vTGFyZ2U6IDQzMSxcbiAgVW5hdmFpbGFibGVGb3JMZWdhbFJlYXNvbnM6IDQ1MSxcbiAgSW50ZXJuYWxTZXJ2ZXJFcnJvcjogNTAwLFxuICBOb3RJbXBsZW1lbnRlZDogNTAxLFxuICBCYWRHYXRld2F5OiA1MDIsXG4gIFNlcnZpY2VVbmF2YWlsYWJsZTogNTAzLFxuICBHYXRld2F5VGltZW91dDogNTA0LFxuICBIdHRwVmVyc2lvbk5vdFN1cHBvcnRlZDogNTA1LFxuICBWYXJpYW50QWxzb05lZ290aWF0ZXM6IDUwNixcbiAgSW5zdWZmaWNpZW50U3RvcmFnZTogNTA3LFxuICBMb29wRGV0ZWN0ZWQ6IDUwOCxcbiAgTm90RXh0ZW5kZWQ6IDUxMCxcbiAgTmV0d29ya0F1dGhlbnRpY2F0aW9uUmVxdWlyZWQ6IDUxMSxcbiAgV2ViU2VydmVyUmV0dXJuc0FuVW5rbm93bkVycm9yOiA1MjAsXG4gIFdlYlNlcnZlcklzRG93bjogNTIxLFxuICBDb25uZWN0aW9uVGltZWRPdXQ6IDUyMixcbiAgT3JpZ2luSXNVbnJlYWNoYWJsZTogNTIzLFxuICBUaW1lb3V0T2NjdXJyZWQ6IDUyNCxcbiAgU3NsSGFuZHNoYWtlRmFpbGVkOiA1MjUsXG4gIEludmFsaWRTc2xDZXJ0aWZpY2F0ZTogNTI2LFxufTtcblxuT2JqZWN0LmVudHJpZXMoSHR0cFN0YXR1c0NvZGUpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICBpZiAoSHR0cFN0YXR1c0NvZGVbdmFsdWVdID09PSB1bmRlZmluZWQpIHtcbiAgICBIdHRwU3RhdHVzQ29kZVt2YWx1ZV0gPSBrZXk7XG4gIH1cbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBIdHRwU3RhdHVzQ29kZTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4vdXRpbHMuanMnO1xuaW1wb3J0IGJpbmQgZnJvbSAnLi9oZWxwZXJzL2JpbmQuanMnO1xuaW1wb3J0IEF4aW9zIGZyb20gJy4vY29yZS9BeGlvcy5qcyc7XG5pbXBvcnQgbWVyZ2VDb25maWcgZnJvbSAnLi9jb3JlL21lcmdlQ29uZmlnLmpzJztcbmltcG9ydCBkZWZhdWx0cyBmcm9tICcuL2RlZmF1bHRzL2luZGV4LmpzJztcbmltcG9ydCBmb3JtRGF0YVRvSlNPTiBmcm9tICcuL2hlbHBlcnMvZm9ybURhdGFUb0pTT04uanMnO1xuaW1wb3J0IENhbmNlbGVkRXJyb3IgZnJvbSAnLi9jYW5jZWwvQ2FuY2VsZWRFcnJvci5qcyc7XG5pbXBvcnQgQ2FuY2VsVG9rZW4gZnJvbSAnLi9jYW5jZWwvQ2FuY2VsVG9rZW4uanMnO1xuaW1wb3J0IGlzQ2FuY2VsIGZyb20gJy4vY2FuY2VsL2lzQ2FuY2VsLmpzJztcbmltcG9ydCB7IFZFUlNJT04gfSBmcm9tICcuL2Vudi9kYXRhLmpzJztcbmltcG9ydCB0b0Zvcm1EYXRhIGZyb20gJy4vaGVscGVycy90b0Zvcm1EYXRhLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4vY29yZS9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCBzcHJlYWQgZnJvbSAnLi9oZWxwZXJzL3NwcmVhZC5qcyc7XG5pbXBvcnQgaXNBeGlvc0Vycm9yIGZyb20gJy4vaGVscGVycy9pc0F4aW9zRXJyb3IuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuL2NvcmUvQXhpb3NIZWFkZXJzLmpzJztcbmltcG9ydCBhZGFwdGVycyBmcm9tICcuL2FkYXB0ZXJzL2FkYXB0ZXJzLmpzJztcbmltcG9ydCBIdHRwU3RhdHVzQ29kZSBmcm9tICcuL2hlbHBlcnMvSHR0cFN0YXR1c0NvZGUuanMnO1xuXG4vKipcbiAqIENyZWF0ZSBhbiBpbnN0YW5jZSBvZiBBeGlvc1xuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBkZWZhdWx0Q29uZmlnIFRoZSBkZWZhdWx0IGNvbmZpZyBmb3IgdGhlIGluc3RhbmNlXG4gKlxuICogQHJldHVybnMge0F4aW9zfSBBIG5ldyBpbnN0YW5jZSBvZiBBeGlvc1xuICovXG5mdW5jdGlvbiBjcmVhdGVJbnN0YW5jZShkZWZhdWx0Q29uZmlnKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBuZXcgQXhpb3MoZGVmYXVsdENvbmZpZyk7XG4gIGNvbnN0IGluc3RhbmNlID0gYmluZChBeGlvcy5wcm90b3R5cGUucmVxdWVzdCwgY29udGV4dCk7XG5cbiAgLy8gQ29weSBheGlvcy5wcm90b3R5cGUgdG8gaW5zdGFuY2VcbiAgdXRpbHMuZXh0ZW5kKGluc3RhbmNlLCBBeGlvcy5wcm90b3R5cGUsIGNvbnRleHQsIHsgYWxsT3duS2V5czogdHJ1ZSB9KTtcblxuICAvLyBDb3B5IGNvbnRleHQgdG8gaW5zdGFuY2VcbiAgdXRpbHMuZXh0ZW5kKGluc3RhbmNlLCBjb250ZXh0LCBudWxsLCB7IGFsbE93bktleXM6IHRydWUgfSk7XG5cbiAgLy8gRmFjdG9yeSBmb3IgY3JlYXRpbmcgbmV3IGluc3RhbmNlc1xuICBpbnN0YW5jZS5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUoaW5zdGFuY2VDb25maWcpIHtcbiAgICByZXR1cm4gY3JlYXRlSW5zdGFuY2UobWVyZ2VDb25maWcoZGVmYXVsdENvbmZpZywgaW5zdGFuY2VDb25maWcpKTtcbiAgfTtcblxuICByZXR1cm4gaW5zdGFuY2U7XG59XG5cbi8vIENyZWF0ZSB0aGUgZGVmYXVsdCBpbnN0YW5jZSB0byBiZSBleHBvcnRlZFxuY29uc3QgYXhpb3MgPSBjcmVhdGVJbnN0YW5jZShkZWZhdWx0cyk7XG5cbi8vIEV4cG9zZSBBeGlvcyBjbGFzcyB0byBhbGxvdyBjbGFzcyBpbmhlcml0YW5jZVxuYXhpb3MuQXhpb3MgPSBBeGlvcztcblxuLy8gRXhwb3NlIENhbmNlbCAmIENhbmNlbFRva2VuXG5heGlvcy5DYW5jZWxlZEVycm9yID0gQ2FuY2VsZWRFcnJvcjtcbmF4aW9zLkNhbmNlbFRva2VuID0gQ2FuY2VsVG9rZW47XG5heGlvcy5pc0NhbmNlbCA9IGlzQ2FuY2VsO1xuYXhpb3MuVkVSU0lPTiA9IFZFUlNJT047XG5heGlvcy50b0Zvcm1EYXRhID0gdG9Gb3JtRGF0YTtcblxuLy8gRXhwb3NlIEF4aW9zRXJyb3IgY2xhc3NcbmF4aW9zLkF4aW9zRXJyb3IgPSBBeGlvc0Vycm9yO1xuXG4vLyBhbGlhcyBmb3IgQ2FuY2VsZWRFcnJvciBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eVxuYXhpb3MuQ2FuY2VsID0gYXhpb3MuQ2FuY2VsZWRFcnJvcjtcblxuLy8gRXhwb3NlIGFsbC9zcHJlYWRcbmF4aW9zLmFsbCA9IGZ1bmN0aW9uIGFsbChwcm9taXNlcykge1xuICByZXR1cm4gUHJvbWlzZS5hbGwocHJvbWlzZXMpO1xufTtcblxuYXhpb3Muc3ByZWFkID0gc3ByZWFkO1xuXG4vLyBFeHBvc2UgaXNBeGlvc0Vycm9yXG5heGlvcy5pc0F4aW9zRXJyb3IgPSBpc0F4aW9zRXJyb3I7XG5cbi8vIEV4cG9zZSBtZXJnZUNvbmZpZ1xuYXhpb3MubWVyZ2VDb25maWcgPSBtZXJnZUNvbmZpZztcblxuYXhpb3MuQXhpb3NIZWFkZXJzID0gQXhpb3NIZWFkZXJzO1xuXG5heGlvcy5mb3JtVG9KU09OID0gKHRoaW5nKSA9PiBmb3JtRGF0YVRvSlNPTih1dGlscy5pc0hUTUxGb3JtKHRoaW5nKSA/IG5ldyBGb3JtRGF0YSh0aGluZykgOiB0aGluZyk7XG5cbmF4aW9zLmdldEFkYXB0ZXIgPSBhZGFwdGVycy5nZXRBZGFwdGVyO1xuXG5heGlvcy5IdHRwU3RhdHVzQ29kZSA9IEh0dHBTdGF0dXNDb2RlO1xuXG5heGlvcy5kZWZhdWx0ID0gYXhpb3M7XG5cbi8vIHRoaXMgbW9kdWxlIHNob3VsZCBvbmx5IGhhdmUgYSBkZWZhdWx0IGV4cG9ydFxuZXhwb3J0IGRlZmF1bHQgYXhpb3M7XG4iLCJpbXBvcnQgYXhpb3MgZnJvbSAnLi9saWIvYXhpb3MuanMnO1xuXG4vLyBUaGlzIG1vZHVsZSBpcyBpbnRlbmRlZCB0byB1bndyYXAgQXhpb3MgZGVmYXVsdCBleHBvcnQgYXMgbmFtZWQuXG4vLyBLZWVwIHRvcC1sZXZlbCBleHBvcnQgc2FtZSB3aXRoIHN0YXRpYyBwcm9wZXJ0aWVzXG4vLyBzbyB0aGF0IGl0IGNhbiBrZWVwIHNhbWUgd2l0aCBlcyBtb2R1bGUgb3IgY2pzXG5jb25zdCB7XG4gIEF4aW9zLFxuICBBeGlvc0Vycm9yLFxuICBDYW5jZWxlZEVycm9yLFxuICBpc0NhbmNlbCxcbiAgQ2FuY2VsVG9rZW4sXG4gIFZFUlNJT04sXG4gIGFsbCxcbiAgQ2FuY2VsLFxuICBpc0F4aW9zRXJyb3IsXG4gIHNwcmVhZCxcbiAgdG9Gb3JtRGF0YSxcbiAgQXhpb3NIZWFkZXJzLFxuICBIdHRwU3RhdHVzQ29kZSxcbiAgZm9ybVRvSlNPTixcbiAgZ2V0QWRhcHRlcixcbiAgbWVyZ2VDb25maWcsXG4gIGNyZWF0ZSxcbn0gPSBheGlvcztcblxuZXhwb3J0IHtcbiAgYXhpb3MgYXMgZGVmYXVsdCxcbiAgY3JlYXRlLFxuICBBeGlvcyxcbiAgQXhpb3NFcnJvcixcbiAgQ2FuY2VsZWRFcnJvcixcbiAgaXNDYW5jZWwsXG4gIENhbmNlbFRva2VuLFxuICBWRVJTSU9OLFxuICBhbGwsXG4gIENhbmNlbCxcbiAgaXNBeGlvc0Vycm9yLFxuICBzcHJlYWQsXG4gIHRvRm9ybURhdGEsXG4gIEF4aW9zSGVhZGVycyxcbiAgSHR0cFN0YXR1c0NvZGUsXG4gIGZvcm1Ub0pTT04sXG4gIGdldEFkYXB0ZXIsXG4gIG1lcmdlQ29uZmlnLFxufTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBU0EsU0FBd0IsS0FBSyxJQUFJLFNBQVM7Q0FDeEMsT0FBTyxTQUFTLE9BQU87RUFDckIsT0FBTyxHQUFHLE1BQU0sU0FBUyxTQUFTO0NBQ3BDO0FBQ0Y7O0FDUEEsSUFBTSxFQUFFLGFBQWEsT0FBTztBQUM1QixJQUFNLEVBQUUsbUJBQW1CO0FBQzNCLElBQU0sRUFBRSxVQUFVLGdCQUFnQjtBQUdsQyxJQUFNLG1CQUNILEVBQUUsc0JBQ0YsS0FBSyxTQUNKLGVBQWUsS0FBSyxLQUFLLElBQUksRUFBQSxDQUMvQixPQUFPLFNBQVM7QUFFbEIsSUFBTSxxQkFBcUIsU0FDekIsT0FBTyxTQUFTLGFBQ2YsU0FBUyxlQUFlLFNBQVMsaUJBQWlCLFNBQVM7Ozs7Ozs7Ozs7Ozs7OztBQWdCOUQsSUFBTSx1QkFBdUIsS0FBSyxXQUFXLFdBQzNDLFFBQVEsT0FBTyxhQUFjLENBQUMsVUFBVSxjQUFjOzs7Ozs7Ozs7OztBQVl4RCxJQUFNLHlCQUF5QixRQUFRO0NBQ3JDLElBQUksQ0FBQyxPQUFPLGFBQWEsR0FBRyxHQUMxQixPQUFPO0NBR1QsTUFBTSxRQUFRLE9BQU8sb0JBQW9CLEdBQUc7Q0FFNUMsSUFBSSxPQUFPLHVCQUNULE1BQU0sS0FBSyxHQUFHLE9BQU8sc0JBQXNCLEdBQUcsQ0FBQztDQUdqRCxPQUFPLE1BQU0sT0FBTyxTQUFTO0VBQzNCLElBQUksa0JBQWtCLElBQUksR0FDeEIsT0FBTztFQUdULE1BQU0sYUFBYSxPQUFPLHlCQUF5QixLQUFLLElBQUk7RUFFNUQsT0FBTyxDQUFDLENBQUMsY0FBYyxXQUFXLGdCQUFnQixXQUFXLGFBQWE7Q0FDNUUsQ0FBQztBQUNIOzs7Ozs7Ozs7Ozs7O0FBY0EsSUFBTSwwQkFBMEIsT0FBTyxTQUFTO0NBQzlDLElBQUksTUFBTTtDQUNWLE1BQU0sT0FBTyxDQUFDO0NBRWQsT0FBTyxPQUFPLE1BQU07RUFDbEIsSUFBSSxLQUFLLFFBQVEsR0FBRyxNQUFNLElBQ3hCLE9BQU87RUFFVCxLQUFLLEtBQUssR0FBRztFQUViLE1BQU0sWUFBWSxlQUFlLEdBQUc7RUFFcEMsSUFBSSxvQkFBb0IsS0FBSyxXQUFXLFFBQVEsS0FBSyxHQUNuRCxPQUFPO0VBR1QsSUFBSSxlQUFlLEtBQUssSUFBSSxHQUMxQixPQUFPO0VBRVQsTUFBTTtDQUNSO0NBQ0EsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7QUFhQSxJQUFNLGVBQWUsS0FBSyxTQUN4QixPQUFPLFFBQVEsdUJBQXVCLEtBQUssSUFBSSxJQUFJLElBQUksUUFBUSxLQUFBOzs7Ozs7Ozs7Ozs7QUFhakUsSUFBTSxvQkFBb0IsVUFBVTtDQUNsQyxJQUFJLFNBQVMsUUFBUyxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsWUFDbEUsT0FBTztDQUdULE1BQU0sa0JBQWtCLGVBQWUsS0FBSztDQUU1QyxJQUFJLG9CQUFvQixRQUFRLHNCQUFzQixLQUFLLEdBQ3pELE9BQU87Q0FHVCxNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUk7Q0FDakMsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJO0NBQ2pDLE1BQU0sT0FBTyxDQUFDO0NBQ2QsSUFBSSxVQUFVO0NBRWQsT0FBTyxXQUFXLE1BQU07RUFDdEIsSUFBSSxLQUFLLFFBQVEsT0FBTyxNQUFNLElBQzVCO0VBR0YsS0FBSyxLQUFLLE9BQU87RUFFakIsTUFBTSxZQUFZLFlBQVksUUFBUSxrQkFBa0IsZUFBZSxPQUFPO0VBRTlFLElBQUksb0JBQW9CLFNBQVMsV0FBVyxZQUFZLEtBQUssR0FDM0Q7RUFHRixNQUFNLFFBQVEsT0FBTyxvQkFBb0IsT0FBTztFQUVoRCxJQUFJLE9BQU8sdUJBQ1QsTUFBTSxLQUFLLEdBQUcsT0FBTyxzQkFBc0IsT0FBTyxDQUFDO0VBR3JELEtBQUssTUFBTSxRQUFRLE9BQU87R0FDeEIsSUFBSSxrQkFBa0IsSUFBSSxHQUN4QjtHQUdGLElBQUksQ0FBQyxlQUFlLFFBQVEsSUFBSSxHQUFHO0lBQ2pDLE9BQU8sUUFBUSxNQUFNO0lBQ3JCLE9BQU8sUUFBUTtHQUNqQjtFQUNGO0VBRUEsVUFBVTtDQUNaO0NBRUEsT0FBTztBQUNUO0FBRUEsSUFBTSxXQUFXLFdBQVcsVUFBVTtDQUNwQyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUs7Q0FDL0IsT0FBTyxNQUFNLFNBQVMsTUFBTSxPQUFPLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLFlBQVk7QUFDbEUsRUFBQSxDQUFHLE9BQU8sT0FBTyxJQUFJLENBQUM7QUFFdEIsSUFBTSxjQUFjLFNBQVM7Q0FDM0IsT0FBTyxLQUFLLFlBQVk7Q0FDeEIsUUFBUSxVQUFVLE9BQU8sS0FBSyxNQUFNO0FBQ3RDO0FBRUEsSUFBTSxjQUFjLFVBQVUsVUFBVSxPQUFPLFVBQVU7Ozs7Ozs7O0FBU3pELElBQU0sRUFBRSxZQUFZOzs7Ozs7OztBQVNwQixJQUFNLGNBQWMsV0FBVyxXQUFXOzs7Ozs7OztBQVMxQyxTQUFTLFNBQVMsS0FBSztDQUNyQixPQUNFLFFBQVEsUUFDUixDQUFDLFlBQVksR0FBRyxLQUNoQixJQUFJLGdCQUFnQixRQUNwQixDQUFDLFlBQVksSUFBSSxXQUFXLEtBQzVCQSxhQUFXLElBQUksWUFBWSxRQUFRLEtBQ25DLElBQUksWUFBWSxTQUFTLEdBQUc7QUFFaEM7Ozs7Ozs7O0FBU0EsSUFBTSxnQkFBZ0IsV0FBVyxhQUFhOzs7Ozs7OztBQVM5QyxTQUFTLGtCQUFrQixLQUFLO0NBQzlCLElBQUk7Q0FDSixJQUFJLE9BQU8sZ0JBQWdCLGVBQWUsWUFBWSxRQUNwRCxTQUFTLFlBQVksT0FBTyxHQUFHO01BRS9CLFNBQVMsT0FBTyxJQUFJLFVBQVUsY0FBYyxJQUFJLE1BQU07Q0FFeEQsT0FBTztBQUNUOzs7Ozs7OztBQVNBLElBQU0sV0FBVyxXQUFXLFFBQVE7Ozs7Ozs7QUFRcEMsSUFBTUEsZUFBYSxXQUFXLFVBQVU7Ozs7Ozs7O0FBU3hDLElBQU0sV0FBVyxXQUFXLFFBQVE7Ozs7Ozs7O0FBU3BDLElBQU0sWUFBWSxVQUFVLFVBQVUsUUFBUSxPQUFPLFVBQVU7Ozs7Ozs7QUFRL0QsSUFBTSxhQUFhLFVBQVUsVUFBVSxRQUFRLFVBQVU7Ozs7Ozs7O0FBU3pELElBQU0saUJBQWlCLFFBQVE7Q0FDN0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUNmLE9BQU87Q0FHVCxNQUFNLFlBQVksZUFBZSxHQUFHO0NBQ3BDLFFBQ0csY0FBYyxRQUFRLGNBQWMsT0FBTyxhQUFhLGVBQWUsU0FBUyxNQUFNLFVBVXRGLG9CQUFvQixLQUFLLFdBQVcsSUFBSSxLQUN0QyxDQUFDLGVBQWUsS0FBSyxXQUFXLEtBQUssQ0FBQyxlQUFlLEtBQUssUUFBUTtBQUV6RTs7Ozs7Ozs7QUFTQSxJQUFNLGlCQUFpQixRQUFRO0NBRTdCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxTQUFTLEdBQUcsR0FDaEMsT0FBTztDQUdULElBQUk7RUFDRixPQUFPLE9BQU8sS0FBSyxHQUFHLENBQUMsQ0FBQyxXQUFXLEtBQUssT0FBTyxlQUFlLEdBQUcsTUFBTSxPQUFPO0NBQ2hGLFNBQVMsR0FBRztFQUVWLE9BQU87Q0FDVDtBQUNGOzs7Ozs7OztBQVNBLElBQU0sU0FBUyxXQUFXLE1BQU07Ozs7Ozs7O0FBU2hDLElBQU0sU0FBUyxXQUFXLE1BQU07Ozs7Ozs7Ozs7OztBQWFoQyxJQUFNLHFCQUFxQixVQUFVO0NBQ25DLE9BQU8sQ0FBQyxFQUFFLFNBQVMsT0FBTyxNQUFNLFFBQVE7QUFDMUM7Ozs7Ozs7OztBQVVBLElBQU0saUJBQWlCLGFBQWEsWUFBWSxPQUFPLFNBQVMsYUFBYTs7Ozs7Ozs7QUFTN0UsSUFBTSxTQUFTLFdBQVcsTUFBTTs7Ozs7Ozs7QUFTaEMsSUFBTSxhQUFhLFdBQVcsVUFBVTtBQUN4QyxJQUFNLFFBQVEsV0FBVyxLQUFLOzs7Ozs7OztBQVM5QixJQUFNLFlBQVksUUFBUSxTQUFTLEdBQUcsS0FBS0EsYUFBVyxJQUFJLElBQUk7Ozs7Ozs7O0FBUzlELFNBQVMsWUFBWTtDQUNuQixJQUFJLE9BQU8sZUFBZSxhQUFhLE9BQU87Q0FDOUMsSUFBSSxPQUFPLFNBQVMsYUFBYSxPQUFPO0NBQ3hDLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTztDQUMxQyxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsT0FBTyxDQUFDO0FBQ1Y7QUFFQSxJQUFNLElBQUksVUFBVTtBQUNwQixJQUFNLGVBQWUsT0FBTyxFQUFFLGFBQWEsY0FBYyxFQUFFLFdBQVcsS0FBQTtBQUV0RSxJQUFNLGNBQWMsVUFBVTtDQUM1QixJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLElBQUksZ0JBQWdCLGlCQUFpQixjQUFjLE9BQU87Q0FFMUQsTUFBTSxRQUFRLGVBQWUsS0FBSztDQUNsQyxJQUFJLENBQUMsU0FBUyxVQUFVLE9BQU8sV0FBVyxPQUFPO0NBQ2pELElBQUksQ0FBQ0EsYUFBVyxNQUFNLE1BQU0sR0FBRyxPQUFPO0NBQ3RDLE1BQU0sT0FBTyxPQUFPLEtBQUs7Q0FDekIsT0FDRSxTQUFTLGNBRVIsU0FBUyxZQUFZQSxhQUFXLE1BQU0sUUFBUSxLQUFLLE1BQU0sU0FBUyxNQUFNO0FBRTdFOzs7Ozs7OztBQVNBLElBQU0sb0JBQW9CLFdBQVcsaUJBQWlCO0FBRXRELElBQU0sQ0FBQyxrQkFBa0IsV0FBVyxZQUFZLGFBQWE7Q0FDM0Q7Q0FDQTtDQUNBO0NBQ0E7QUFDRixDQUFDLENBQUMsSUFBSSxVQUFVOzs7Ozs7OztBQVNoQixJQUFNLFFBQVEsUUFBUTtDQUNwQixPQUFPLElBQUksT0FBTyxJQUFJLEtBQUssSUFBSSxJQUFJLFFBQVEsc0NBQXNDLEVBQUU7QUFDckY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsUUFBUSxLQUFLLElBQUksRUFBRSxhQUFhLFVBQVUsQ0FBQyxHQUFHO0NBRXJELElBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxhQUNqQztDQUdGLElBQUk7Q0FDSixJQUFJO0NBR0osSUFBSSxPQUFPLFFBQVEsVUFFakIsTUFBTSxDQUFDLEdBQUc7Q0FHWixJQUFJLFFBQVEsR0FBRyxHQUViLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUksR0FBRyxLQUNqQyxHQUFHLEtBQUssTUFBTSxJQUFJLElBQUksR0FBRyxHQUFHO01BRXpCO0VBRUwsSUFBSSxTQUFTLEdBQUcsR0FDZDtFQUlGLE1BQU0sT0FBTyxhQUFhLE9BQU8sb0JBQW9CLEdBQUcsSUFBSSxPQUFPLEtBQUssR0FBRztFQUMzRSxNQUFNLE1BQU0sS0FBSztFQUNqQixJQUFJO0VBRUosS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7R0FDeEIsTUFBTSxLQUFLO0dBQ1gsR0FBRyxLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQUssR0FBRztFQUNsQztDQUNGO0FBQ0Y7Ozs7Ozs7OztBQVVBLFNBQVMsUUFBUSxLQUFLLEtBQUs7Q0FDekIsSUFBSSxTQUFTLEdBQUcsR0FDZCxPQUFPO0NBR1QsTUFBTSxJQUFJLFlBQVk7Q0FDdEIsTUFBTSxPQUFPLE9BQU8sS0FBSyxHQUFHO0NBQzVCLElBQUksSUFBSSxLQUFLO0NBQ2IsSUFBSTtDQUNKLE9BQU8sTUFBTSxHQUFHO0VBQ2QsT0FBTyxLQUFLO0VBQ1osSUFBSSxRQUFRLEtBQUssWUFBWSxHQUMzQixPQUFPO0NBRVg7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLGlCQUFpQjtDQUVyQixJQUFJLE9BQU8sZUFBZSxhQUFhLE9BQU87Q0FDOUMsT0FBTyxPQUFPLFNBQVMsY0FBYyxPQUFPLE9BQU8sV0FBVyxjQUFjLFNBQVM7QUFDdkYsRUFBQSxDQUFHO0FBRUgsSUFBTSxvQkFBb0IsWUFBWSxDQUFDLFlBQVksT0FBTyxLQUFLLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQjNFLFNBQVMsTUFBTSxHQUFHLE1BQU07Q0FDdEIsTUFBTSxFQUFFLFVBQVUsa0JBQW1CLGlCQUFpQixJQUFJLEtBQUssUUFBUyxDQUFDO0NBQ3pFLE1BQU0sU0FBUyxDQUFDO0NBTWhCLE1BQU0sZ0JBQWdCLFdBQVcsT0FBTyxPQUFPLElBQUksSUFBSTtDQUN2RCxNQUFNLGVBQWUsS0FBSyxRQUFRO0VBRWhDLElBQUksUUFBUSxlQUFlLFFBQVEsaUJBQWlCLFFBQVEsYUFDMUQ7RUFHRixJQUFJLFlBQVk7RUFDaEIsSUFBSSxpQkFBaUIsT0FBTyxRQUFRLFVBQVU7R0FDNUMsTUFBTSxXQUFXLElBQUksWUFBWTtHQUNqQyxNQUFNLFdBQVcsY0FBYztHQUcvQixJQUFJLGFBQWEsS0FBQSxLQUFhLGVBQWUsUUFBUSxRQUFRLEdBQzNELFlBQVk7UUFFWixjQUFjLFlBQVk7RUFFOUI7RUFJQSxNQUFNLFdBQVcsZUFBZSxRQUFRLFNBQVMsSUFBSSxPQUFPLGFBQWEsS0FBQTtFQUN6RSxJQUFJLGNBQWMsUUFBUSxLQUFLLGNBQWMsR0FBRyxHQUM5QyxPQUFPLGFBQWEsTUFBTSxVQUFVLEdBQUc7T0FDbEMsSUFBSSxjQUFjLEdBQUcsR0FDMUIsT0FBTyxhQUFhLE1BQU0sQ0FBQyxHQUFHLEdBQUc7T0FDNUIsSUFBSSxRQUFRLEdBQUcsR0FDcEIsT0FBTyxhQUFhLElBQUksTUFBTTtPQUN6QixJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxHQUFHLEdBQzNDLE9BQU8sYUFBYTtDQUV4QjtDQUVBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsSUFBSSxHQUFHLEtBQUs7RUFDM0MsTUFBTSxTQUFTLEtBQUs7RUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxNQUFNLEdBQzVCO0VBR0YsUUFBUSxRQUFRLFdBQVc7RUFFM0IsSUFBSSxPQUFPLFdBQVcsWUFBWSxRQUFRLE1BQU0sS0FBSyxDQUFDLE9BQU8sdUJBQzNEO0VBR0YsTUFBTSxVQUFVLE9BQU8sc0JBQXNCLE1BQU07RUFDbkQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0dBQ3ZDLE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLElBQUkscUJBQXFCLEtBQUssUUFBUSxNQUFNLEdBQzFDLFlBQVksT0FBTyxTQUFTLE1BQU07RUFFdEM7Q0FDRjtDQUNBLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7O0FBYUEsSUFBTSxVQUFVLEdBQUcsR0FBRyxTQUFTLEVBQUUsZUFBZSxDQUFDLE1BQU07Q0FDckQsUUFDRSxJQUNDLEtBQUssUUFBUTtFQUNaLElBQUksV0FBV0EsYUFBVyxHQUFHLEdBQzNCLE9BQU8sZUFBZSxHQUFHLEtBQUs7R0FHNUIsV0FBVztHQUNYLE9BQU8sS0FBSyxLQUFLLE9BQU87R0FDeEIsVUFBVTtHQUNWLFlBQVk7R0FDWixjQUFjO0VBQ2hCLENBQUM7T0FFRCxPQUFPLGVBQWUsR0FBRyxLQUFLO0dBQzVCLFdBQVc7R0FDWCxPQUFPO0dBQ1AsVUFBVTtHQUNWLFlBQVk7R0FDWixjQUFjO0VBQ2hCLENBQUM7Q0FFTCxHQUNBLEVBQUUsV0FBVyxDQUNmO0NBQ0EsT0FBTztBQUNUOzs7Ozs7OztBQVNBLElBQU0sWUFBWSxZQUFZO0NBQzVCLElBQUksUUFBUSxXQUFXLENBQUMsTUFBTSxPQUM1QixVQUFVLFFBQVEsTUFBTSxDQUFDO0NBRTNCLE9BQU87QUFDVDs7Ozs7Ozs7OztBQVdBLElBQU0sWUFBWSxhQUFhLGtCQUFrQixPQUFPLGdCQUFnQjtDQUN0RSxZQUFZLFlBQVksT0FBTyxPQUFPLGlCQUFpQixXQUFXLFdBQVc7Q0FDN0UsT0FBTyxlQUFlLFlBQVksV0FBVyxlQUFlO0VBQzFELFdBQVc7RUFDWCxPQUFPO0VBQ1AsVUFBVTtFQUNWLFlBQVk7RUFDWixjQUFjO0NBQ2hCLENBQUM7Q0FDRCxPQUFPLGVBQWUsYUFBYSxTQUFTO0VBQzFDLFdBQVc7RUFDWCxPQUFPLGlCQUFpQjtDQUMxQixDQUFDO0NBQ0QsU0FBUyxPQUFPLE9BQU8sWUFBWSxXQUFXLEtBQUs7QUFDckQ7Ozs7Ozs7Ozs7QUFXQSxJQUFNLGdCQUFnQixXQUFXLFNBQVMsUUFBUSxlQUFlO0NBQy9ELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU0sU0FBUyxDQUFDO0NBRWhCLFVBQVUsV0FBVyxDQUFDO0NBRXRCLElBQUksYUFBYSxNQUFNLE9BQU87Q0FFOUIsR0FBRztFQUNELFFBQVEsT0FBTyxvQkFBb0IsU0FBUztFQUM1QyxJQUFJLE1BQU07RUFDVixPQUFPLE1BQU0sR0FBRztHQUNkLE9BQU8sTUFBTTtHQUNiLEtBQUssQ0FBQyxjQUFjLFdBQVcsTUFBTSxXQUFXLE9BQU8sTUFBTSxDQUFDLE9BQU8sT0FBTztJQUMxRSxRQUFRLFFBQVEsVUFBVTtJQUMxQixPQUFPLFFBQVE7R0FDakI7RUFDRjtFQUNBLFlBQVksV0FBVyxTQUFTLGVBQWUsU0FBUztDQUMxRCxTQUFTLGNBQWMsQ0FBQyxVQUFVLE9BQU8sV0FBVyxPQUFPLE1BQU0sY0FBYyxPQUFPO0NBRXRGLE9BQU87QUFDVDs7Ozs7Ozs7OztBQVdBLElBQU0sWUFBWSxLQUFLLGNBQWMsYUFBYTtDQUNoRCxNQUFNLE9BQU8sR0FBRztDQUNoQixJQUFJLGFBQWEsS0FBQSxLQUFhLFdBQVcsSUFBSSxRQUMzQyxXQUFXLElBQUk7Q0FFakIsWUFBWSxhQUFhO0NBQ3pCLE1BQU0sWUFBWSxJQUFJLFFBQVEsY0FBYyxRQUFRO0NBQ3BELE9BQU8sY0FBYyxNQUFNLGNBQWM7QUFDM0M7Ozs7Ozs7O0FBU0EsSUFBTSxXQUFXLFVBQVU7Q0FDekIsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixJQUFJLFFBQVEsS0FBSyxHQUFHLE9BQU87Q0FDM0IsSUFBSSxJQUFJLE1BQU07Q0FDZCxJQUFJLENBQUMsT0FBTyxjQUFjLENBQUMsS0FBSyxJQUFJLEtBQUssSUFBSSxZQUFZLE9BQU87Q0FJaEUsTUFBTSwwQkFBVSxJQUFJLElBQUk7Q0FDeEIsTUFBTSx1QkFBTyxJQUFJLElBQUk7Q0FDckIsSUFBSSxTQUFTO0NBRWIsT0FBTyxVQUFVLFFBQVEsUUFBUSxPQUFPLEdBQUc7RUFDekMsSUFBSSxLQUFLLElBQUksTUFBTSxHQUFHLE9BQU87RUFDN0IsS0FBSyxJQUFJLE1BQU07RUFFZixNQUFNLFlBQVksZUFBZSxNQUFNO0VBQ3ZDLElBQUksb0JBQW9CLFFBQVEsV0FBVyxXQUFXLEtBQUssR0FBRztFQUU5RCxPQUFPLG9CQUFvQixNQUFNLENBQUMsQ0FBQyxTQUFTLFFBQVE7R0FDbEQsTUFBTSxRQUFRLENBQUM7R0FDZixJQUNFLE9BQU8sVUFBVSxLQUFLLEtBQ3RCLFNBQVMsS0FDVCxRQUFRLEtBQ1IsT0FBTyxLQUFLLE1BQU0sT0FDbEIsZUFBZSxRQUFRLEdBQUcsR0FFMUIsUUFBUSxJQUFJLEtBQUs7RUFFckIsQ0FBQztFQUNELFNBQVM7Q0FDWDtDQUVBLElBQUksUUFBUSxTQUFTLEdBQUcsT0FBTztDQUMvQixNQUFNLE1BQU0sSUFBSSxNQUFNLENBQUM7Q0FDdkIsT0FBTyxNQUFNLEdBQ1gsSUFBSSxLQUFLLE1BQU07Q0FFakIsT0FBTztBQUNUOzs7Ozs7Ozs7QUFXQSxJQUFNLGlCQUFpQixlQUFlO0NBRXBDLFFBQVEsVUFBVTtFQUNoQixPQUFPLGNBQWMsaUJBQWlCO0NBQ3hDO0FBQ0YsRUFBQSxDQUFHLE9BQU8sZUFBZSxlQUFlLGVBQWUsVUFBVSxDQUFDOzs7Ozs7Ozs7QUFVbEUsSUFBTSxnQkFBZ0IsS0FBSyxPQUFPO0NBR2hDLE1BQU0sYUFGWSxPQUFPLElBQUksVUFBQSxDQUVELEtBQUssR0FBRztDQUVwQyxJQUFJO0NBRUosUUFBUSxTQUFTLFVBQVUsS0FBSyxNQUFNLENBQUMsT0FBTyxNQUFNO0VBQ2xELE1BQU0sT0FBTyxPQUFPO0VBQ3BCLEdBQUcsS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLEVBQUU7Q0FDL0I7QUFDRjs7Ozs7Ozs7O0FBVUEsSUFBTSxZQUFZLFFBQVEsUUFBUTtDQUNoQyxJQUFJO0NBQ0osTUFBTSxNQUFNLENBQUM7Q0FFYixRQUFRLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTyxNQUN0QyxJQUFJLEtBQUssT0FBTztDQUdsQixPQUFPO0FBQ1Q7QUFHQSxJQUFNLGFBQWEsV0FBVyxpQkFBaUI7QUFFL0MsSUFBTSxlQUFlLFFBQVE7Q0FDM0IsT0FBTyxJQUFJLFlBQVksQ0FBQyxDQUFDLFFBQVEseUJBQXlCLFNBQVMsU0FBUyxHQUFHLElBQUksSUFBSTtFQUNyRixPQUFPLEdBQUcsWUFBWSxJQUFJO0NBQzVCLENBQUM7QUFDSDtBQUVBLElBQU0sRUFBRSx5QkFBeUIsT0FBTzs7Ozs7Ozs7QUFTeEMsSUFBTSxXQUFXLFdBQVcsUUFBUTtBQUVwQyxJQUFNLHFCQUFxQixLQUFLLFlBQVk7Q0FDMUMsTUFBTSxjQUFjLE9BQU8sMEJBQTBCLEdBQUc7Q0FDeEQsTUFBTSxxQkFBcUIsQ0FBQztDQUU1QixRQUFRLGNBQWMsWUFBWSxTQUFTO0VBQ3pDLElBQUk7RUFDSixLQUFLLE1BQU0sUUFBUSxZQUFZLE1BQU0sR0FBRyxPQUFPLE9BQzdDLG1CQUFtQixRQUFRLE9BQU87Q0FFdEMsQ0FBQztDQUVELE9BQU8saUJBQWlCLEtBQUssa0JBQWtCO0FBQ2pEOzs7OztBQU9BLElBQU0saUJBQWlCLFFBQVE7Q0FDN0Isa0JBQWtCLE1BQU0sWUFBWSxTQUFTO0VBRTNDLElBQUlBLGFBQVcsR0FBRyxLQUFLO0dBQUM7R0FBYTtHQUFVO0VBQVEsQ0FBQyxDQUFDLFNBQVMsSUFBSSxHQUNwRSxPQUFPO0VBR1QsTUFBTSxRQUFRLElBQUk7RUFFbEIsSUFBSSxDQUFDQSxhQUFXLEtBQUssR0FBRztFQUV4QixXQUFXLGFBQWE7RUFFeEIsSUFBSSxjQUFjLFlBQVk7R0FDNUIsV0FBVyxXQUFXO0dBQ3RCO0VBQ0Y7RUFFQSxJQUFJLENBQUMsV0FBVyxLQUNkLFdBQVcsWUFBWTtHQUNyQixNQUFNLE1BQU0sdUNBQXVDLE9BQU8sR0FBRztFQUMvRDtDQUVKLENBQUM7QUFDSDs7Ozs7Ozs7O0FBVUEsSUFBTSxlQUFlLGVBQWUsY0FBYztDQUNoRCxNQUFNLE1BQU0sQ0FBQztDQUViLE1BQU0sVUFBVSxRQUFRO0VBQ3RCLElBQUksU0FBUyxVQUFVO0dBQ3JCLElBQUksU0FBUztFQUNmLENBQUM7Q0FDSDtDQUVBLFFBQVEsYUFBYSxJQUFJLE9BQU8sYUFBYSxJQUFJLE9BQU8sT0FBTyxhQUFhLENBQUMsQ0FBQyxNQUFNLFNBQVMsQ0FBQztDQUU5RixPQUFPO0FBQ1Q7QUFFQSxJQUFNLGFBQWEsQ0FBQztBQUVwQixJQUFNLGtCQUFrQixPQUFPLGlCQUFpQjtDQUM5QyxPQUFPLFNBQVMsUUFBUSxPQUFPLFNBQVUsUUFBUSxDQUFDLEtBQU0sSUFBSSxRQUFRO0FBQ3RFOzs7Ozs7OztBQVNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsT0FBTyxDQUFDLEVBQ04sU0FDQUEsYUFBVyxNQUFNLE1BQU0sS0FDdkIsTUFBTSxpQkFBaUIsY0FDdkIsTUFBTTtBQUVWOzs7Ozs7O0FBUUEsSUFBTSxnQkFBZ0IsUUFBUTtDQUM1QixNQUFNLDBCQUFVLElBQUksUUFBUTtDQUU1QixNQUFNLFNBQVMsV0FBVztFQUN4QixJQUFJLFNBQVMsTUFBTSxHQUFHO0dBQ3BCLElBQUksUUFBUSxJQUFJLE1BQU0sR0FDcEI7R0FJRixJQUFJLFNBQVMsTUFBTSxHQUNqQixPQUFPO0dBR1QsSUFBSSxFQUFFLFlBQVksU0FBUztJQUV6QixRQUFRLElBQUksTUFBTTtJQUVsQixJQUFJO0lBRUosSUFBSSxNQUFNLE1BQU0sR0FBRztLQUNqQixTQUFTLENBQUM7S0FDVixLQUFLLE1BQU0sU0FBUyxRQUFRO01BQzFCLE1BQU0sZUFBZSxNQUFNLEtBQUs7TUFDaEMsQ0FBQyxZQUFZLFlBQVksS0FBSyxPQUFPLEtBQUssWUFBWTtLQUN4RDtJQUNGLE9BQU87S0FDTCxTQUFTLFFBQVEsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDO0tBRWpDLFFBQVEsU0FBUyxPQUFPLFFBQVE7TUFDOUIsTUFBTSxlQUFlLE1BQU0sS0FBSztNQUNoQyxDQUFDLFlBQVksWUFBWSxNQUFNLE9BQU8sT0FBTztLQUMvQyxDQUFDO0lBQ0g7SUFFQSxRQUFRLE9BQU8sTUFBTTtJQUVyQixPQUFPO0dBQ1Q7RUFDRjtFQUVBLE9BQU87Q0FDVDtDQUVBLE9BQU8sTUFBTSxHQUFHO0FBQ2xCOzs7Ozs7O0FBUUEsSUFBTSxZQUFZLFdBQVcsZUFBZTs7Ozs7OztBQVE1QyxJQUFNLGNBQWMsVUFDbEIsVUFDQyxTQUFTLEtBQUssS0FBS0EsYUFBVyxLQUFLLE1BQ3BDQSxhQUFXLE1BQU0sSUFBSSxLQUNyQkEsYUFBVyxNQUFNLEtBQUs7Ozs7Ozs7OztBQWF4QixJQUFNLGtCQUFrQix1QkFBdUIseUJBQXlCO0NBQ3RFLElBQUksdUJBQ0YsT0FBTztDQUdULE9BQU8seUJBQ0QsT0FBTyxjQUFjO0VBQ3JCLFFBQVEsaUJBQ04sWUFDQyxFQUFFLFFBQVEsV0FBVztHQUNwQixJQUFJLFdBQVcsV0FBVyxTQUFTLE9BQ2pDLFVBQVUsVUFBVSxVQUFVLE1BQU0sQ0FBQyxDQUFDO0VBRTFDLEdBQ0EsS0FDRjtFQUVBLFFBQVEsT0FBTztHQUNiLFVBQVUsS0FBSyxFQUFFO0dBQ2pCLFFBQVEsWUFBWSxPQUFPLEdBQUc7RUFDaEM7Q0FDRixFQUFBLENBQUcsU0FBUyxLQUFLLE9BQU8sS0FBSyxDQUFDLENBQUMsS0FDOUIsT0FBTyxXQUFXLEVBQUU7QUFDM0IsRUFBQSxDQUFHLE9BQU8saUJBQWlCLFlBQVlBLGFBQVcsUUFBUSxXQUFXLENBQUM7Ozs7Ozs7QUFRdEUsSUFBTSxPQUNKLE9BQU8sbUJBQW1CLGNBQ3RCLGVBQWUsS0FBSyxPQUFPLElBQzFCLE9BQU8sWUFBWSxlQUFlLFFBQVEsWUFBYTtBQUk5RCxJQUFNLGNBQWMsVUFBVSxTQUFTLFFBQVFBLGFBQVcsTUFBTSxTQUFTOzs7Ozs7Ozs7Ozs7QUFhekUsSUFBTSxrQkFBa0IsVUFDdEIsU0FBUyxRQUFRLHVCQUF1QixPQUFPLFFBQVEsS0FBSyxXQUFXLEtBQUs7QUFFOUUsSUFBQSxnQkFBZTtDQUNiO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWTtDQUNaO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsUUFBUTtDQUNSO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxjQUFjO0NBQ2Q7Q0FDQTtDQUNBO0FBQ0Y7O0FDMXFDQSxJQUFNLG9CQUFvQkMsY0FBTSxZQUFZO0NBQzFDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUFnQkQsSUFBQSx3QkFBZ0IsZUFBZTtDQUU3QixNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUk7Q0FDakMsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBRUosY0FDRSxXQUFXLE1BQU0sSUFBSSxDQUFDLENBQUMsUUFBUSxTQUFTLE9BQU8sTUFBTTtFQUNuRCxJQUFJLEtBQUssUUFBUSxHQUFHO0VBQ3BCLE1BQU0sS0FBSyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWTtFQUM5QyxNQUFNLEtBQUssVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFFakMsTUFBTSxTQUFTQSxjQUFNLFdBQVcsUUFBUSxHQUFHO0VBRTNDLElBQUksQ0FBQyxPQUFRLFVBQVVBLGNBQU0sV0FBVyxtQkFBbUIsR0FBRyxHQUM1RDtFQUdGLElBQUksUUFBUSxjQUFjO0dBQ3hCLElBQUksUUFDRixPQUFPLElBQUksQ0FBQyxLQUFLLEdBQUc7UUFFcEIsT0FBTyxPQUFPLENBQUMsR0FBRztFQUV0QixPQUNFLE9BQU8sT0FBTyxTQUFTLE9BQU8sT0FBTyxPQUFPLE1BQU07Q0FFdEQsQ0FBQztDQUVILE9BQU87QUFDVDs7QUNuRUEsU0FBUyxhQUFhLEtBQUs7Q0FDekIsSUFBSSxRQUFRO0NBQ1osSUFBSSxNQUFNLElBQUk7Q0FFZCxPQUFPLFFBQVEsS0FBSztFQUNsQixNQUFNLE9BQU8sSUFBSSxXQUFXLEtBQUs7RUFFakMsSUFBSSxTQUFTLEtBQVEsU0FBUyxJQUM1QjtFQUdGLFNBQVM7Q0FDWDtDQUVBLE9BQU8sTUFBTSxPQUFPO0VBQ2xCLE1BQU0sT0FBTyxJQUFJLFdBQVcsTUFBTSxDQUFDO0VBRW5DLElBQUksU0FBUyxLQUFRLFNBQVMsSUFDNUI7RUFHRixPQUFPO0NBQ1Q7Q0FFQSxPQUFPLFVBQVUsS0FBSyxRQUFRLElBQUksU0FBUyxNQUFNLElBQUksTUFBTSxPQUFPLEdBQUc7QUFDdkU7QUFJQSxJQUFNLHFEQUFxQyxJQUFJLE9BQU8sNENBQTRDLEdBQUc7QUFFckcsSUFBTSx5REFBeUMsSUFBSSxPQUFPLDZDQUE2QyxHQUFHO0FBRTFHLFNBQVMsY0FBYyxPQUFPLGNBQWM7Q0FDMUMsSUFBSUMsY0FBTSxRQUFRLEtBQUssR0FDckIsT0FBTyxNQUFNLEtBQUssU0FBUyxjQUFjLE1BQU0sWUFBWSxDQUFDO0NBRzlELE9BQU8sYUFBYSxPQUFPLEtBQUssQ0FBQyxDQUFDLFFBQVEsY0FBYyxFQUFFLENBQUM7QUFDN0Q7QUFFQSxJQUFhLHVCQUF1QixVQUNsQyxjQUFjLE9BQU8sa0NBQWtDO0FBRXpELElBQWEsaUNBQWlDLFVBQzVDLGNBQWMsT0FBTyxzQ0FBc0M7QUFFN0QsU0FBZ0IseUJBQXlCLFNBQVM7Q0FDaEQsTUFBTSxvQkFBb0IsT0FBTyxPQUFPLElBQUk7Q0FFNUMsY0FBTSxRQUFRLFFBQVEsT0FBTyxJQUFJLE9BQU8sV0FBVztFQUNqRCxrQkFBa0IsVUFBVSw4QkFBOEIsS0FBSztDQUNqRSxDQUFDO0NBRUQsT0FBTztBQUNUOztBQ3JEQSxJQUFNQyxlQUFhLE9BQU8sV0FBVztBQUVyQyxTQUFTLGdCQUFnQixRQUFRO0NBQy9CLE9BQU8sVUFBVSxPQUFPLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVk7QUFDckQ7QUFFQSxTQUFTLGVBQWUsT0FBTztDQUM3QixJQUFJLFVBQVUsU0FBUyxTQUFTLE1BQzlCLE9BQU87Q0FHVCxPQUFPQyxjQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sSUFBSSxjQUFjLElBQUksb0JBQW9CLE9BQU8sS0FBSyxDQUFDO0FBQzdGO0FBRUEsU0FBUyxZQUFZLEtBQUs7Q0FDeEIsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJO0NBQ2pDLE1BQU0sV0FBVztDQUNqQixJQUFJO0NBRUosT0FBUSxRQUFRLFNBQVMsS0FBSyxHQUFHLEdBQy9CLE9BQU8sTUFBTSxNQUFNLE1BQU07Q0FHM0IsT0FBTztBQUNUO0FBRUEsSUFBTSxrQkFBa0I7QUFFeEIsU0FBUyxRQUFRLE9BQU87Q0FDdEIsSUFBSSxRQUFRO0NBQ1osSUFBSSxNQUFNLE1BQU07Q0FFaEIsT0FBTyxRQUFRLEtBQUs7RUFDbEIsTUFBTSxPQUFPLE1BQU0sV0FBVyxLQUFLO0VBRW5DLElBQUksU0FBUyxLQUFRLFNBQVMsSUFDNUI7RUFHRixTQUFTO0NBQ1g7Q0FFQSxPQUFPLE1BQU0sT0FBTztFQUNsQixNQUFNLE9BQU8sTUFBTSxXQUFXLE1BQU0sQ0FBQztFQUVyQyxJQUFJLFNBQVMsS0FBUSxTQUFTLElBQzVCO0VBR0YsT0FBTztDQUNUO0NBRUEsT0FBTyxVQUFVLEtBQUssUUFBUSxNQUFNLFNBQVMsUUFBUSxNQUFNLE1BQU0sT0FBTyxHQUFHO0FBQzdFO0FBRUEsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxNQUFNLE9BQU8sTUFBTSxTQUFTO0NBRTVCLElBQUksT0FBTyxLQUFLLE1BQU0sV0FBVyxDQUFDLE1BQU0sTUFBUSxNQUFNLFdBQVcsSUFBSSxNQUFNLElBQ3pFLE9BQU87Q0FHVCxJQUFJLFVBQVU7Q0FFZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxLQUFLO0VBQzdCLE1BQU0sT0FBTyxNQUFNLFdBQVcsQ0FBQztFQUUvQixJQUFJLFNBQVMsSUFDWCxPQUFPO0VBR1QsSUFBSSxTQUFTLElBQU07R0FDakIsS0FBSztHQUVMLElBQUksS0FBSyxNQUNQLE9BQU87RUFFWDtFQUVBLFdBQVcsTUFBTTtDQUNuQjtDQUVBLE9BQU87QUFDVDtBQUVBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDOUIsTUFBTSxhQUFhLE9BQU8sT0FBTyxJQUFJO0NBQ3JDLE1BQU0sTUFBTSxPQUFPLEtBQUs7Q0FDeEIsSUFBSSxRQUFRO0NBQ1osSUFBSSxTQUFTO0NBQ2IsSUFBSSxVQUFVO0NBRWQsU0FBUyxlQUFlLEtBQUs7RUFDM0IsTUFBTSxPQUFPLFFBQVEsSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDO0VBQzFDLE1BQU0sU0FBUyxLQUFLLFFBQVEsR0FBRztFQUUvQixJQUFJLFNBQVMsR0FDWDtFQUdGLE1BQU0sT0FBTyxRQUFRLEtBQUssTUFBTSxHQUFHLE1BQU0sQ0FBQztFQUUxQyxJQUFJLENBQUMsZ0JBQWdCLEtBQUssSUFBSSxHQUM1QjtFQUdGLE1BQU0saUJBQWlCLEtBQUssWUFBWTtFQUV4QyxJQUNFLG1CQUFtQixlQUNuQixtQkFBbUIsaUJBQ25CLG1CQUFtQixhQUVuQjtFQUdGLE1BQU0saUJBQWlCLFFBQVEsS0FBSyxNQUFNLFNBQVMsQ0FBQyxDQUFDO0VBQ3JELFdBQVcsa0JBQWtCLG1CQUFtQixjQUFjO0NBQ2hFO0NBRUEsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0VBQ25DLE1BQU0sT0FBTyxJQUFJLFdBQVcsQ0FBQztFQUU3QixJQUFJLFFBQVE7R0FDVixJQUFJLFNBQ0YsVUFBVTtRQUNMLElBQUksU0FBUyxJQUNsQixVQUFVO1FBQ0wsSUFBSSxTQUFTLElBQ2xCLFNBQVM7RUFFYixPQUFPLElBQUksU0FBUyxJQUNsQixTQUFTO09BQ0osSUFBSSxTQUFTLE1BQVEsU0FBUyxJQUFNO0dBQ3pDLGVBQWUsQ0FBQztHQUNoQixRQUFRLElBQUk7RUFDZDtDQUNGO0NBRUEsZUFBZSxJQUFJLE1BQU07Q0FFekIsT0FBTztBQUNUO0FBRUEsSUFBTSxxQkFBcUIsUUFBUSxpQ0FBaUMsS0FBSyxJQUFJLEtBQUssQ0FBQztBQVduRixJQUFNLG9CQUFvQjtBQUUxQixJQUFNLGNBQWMsU0FBVSxTQUFTLGNBQWMsb0JBQW9CO0FBRXpFLFNBQVMsaUJBQWlCLFNBQVMsT0FBTyxRQUFRLFFBQVEsb0JBQW9CO0NBQzVFLElBQUlBLGNBQU0sV0FBVyxNQUFNLEdBQ3pCLE9BQU8sT0FBTyxLQUFLLFNBQVMsT0FBTyxNQUFNO0NBRzNDLElBQUksb0JBQ0YsUUFBUTtDQUdWLElBQUksQ0FBQ0EsY0FBTSxTQUFTLEtBQUssR0FBRztDQUU1QixJQUFJQSxjQUFNLFNBQVMsTUFBTSxHQUN2QixPQUFPLE1BQU0sUUFBUSxNQUFNLE1BQU07Q0FHbkMsSUFBSUEsY0FBTSxTQUFTLE1BQU0sR0FDdkIsT0FBTyxPQUFPLEtBQUssS0FBSztBQUU1QjtBQUVBLFNBQVMsYUFBYSxRQUFRO0NBQzVCLE9BQU8sT0FDSixLQUFLLENBQUMsQ0FDTixZQUFZLENBQUMsQ0FDYixRQUFRLG9CQUFvQixHQUFHLE1BQU0sUUFBUTtFQUM1QyxPQUFPLEtBQUssWUFBWSxJQUFJO0NBQzlCLENBQUM7QUFDTDtBQUVBLFNBQVMsZUFBZSxLQUFLLFFBQVE7Q0FDbkMsTUFBTSxlQUFlQSxjQUFNLFlBQVksTUFBTSxNQUFNO0NBRW5EO0VBQUM7RUFBTztFQUFPO0NBQUssQ0FBQyxDQUFDLFNBQVMsZUFBZTtFQUM1QyxPQUFPLGVBQWUsS0FBSyxhQUFhLGNBQWM7R0FHcEQsV0FBVztHQUNYLE9BQU8sU0FBVSxNQUFNLE1BQU0sTUFBTTtJQUNqQyxPQUFPLEtBQUssV0FBVyxDQUFDLEtBQUssTUFBTSxRQUFRLE1BQU0sTUFBTSxJQUFJO0dBQzdEO0dBQ0EsY0FBYztFQUNoQixDQUFDO0NBQ0gsQ0FBQztBQUNIO0FBRUEsSUFBTUMsaUJBQU4sTUFBbUI7Q0FDakIsWUFBWSxTQUFTO0VBQ25CLFdBQVcsS0FBSyxJQUFJLE9BQU87Q0FDN0I7Q0FFQSxJQUFJLFFBQVEsZ0JBQWdCLFNBQVM7RUFDbkMsTUFBTSxPQUFPO0VBRWIsU0FBUyxVQUFVLFFBQVEsU0FBUyxVQUFVO0dBQzVDLE1BQU0sVUFBVSxnQkFBZ0IsT0FBTztHQUV2QyxJQUFJLENBQUMsU0FDSDtHQUdGLE1BQU0sTUFBTUQsY0FBTSxRQUFRLE1BQU0sT0FBTztHQUV2QyxJQUNFLENBQUMsT0FDRCxLQUFLLFNBQVMsS0FBQSxLQUNkLGFBQWEsUUFDWixhQUFhLEtBQUEsS0FBYSxLQUFLLFNBQVMsT0FFekMsS0FBSyxXQUFXLE9BQU8sT0FBTyxLQUFLLGVBQWUsTUFBTTtFQUU1RDtFQUVBLE1BQU0sY0FBYyxTQUFTLGFBQzNCQSxjQUFNLFFBQVEsVUFBVSxRQUFRLFlBQVksVUFBVSxRQUFRLFNBQVMsUUFBUSxDQUFDO0VBRWxGLElBQUlBLGNBQU0sY0FBYyxNQUFNLEtBQUssa0JBQWtCLEtBQUssYUFDeEQsV0FBVyxRQUFRLGNBQWM7T0FDNUIsSUFBSUEsY0FBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLE9BQU8sS0FBSyxNQUFNLENBQUMsa0JBQWtCLE1BQU0sR0FDeEYsV0FBV0UscUJBQWEsTUFBTSxHQUFHLGNBQWM7T0FDMUMsSUFBSUYsY0FBTSxTQUFTLE1BQU0sS0FBS0EsY0FBTSxlQUFlLE1BQU0sR0FBRztHQUNqRSxJQUFJLE1BQU0sT0FBTyxPQUFPLElBQUksR0FDMUIsTUFDQTtHQUNGLEtBQUssTUFBTSxTQUFTLFFBQVE7SUFDMUIsSUFBSSxDQUFDQSxjQUFNLFFBQVEsS0FBSyxHQUN0QixNQUFNLElBQUksVUFBVSw4Q0FBOEM7SUFHcEUsTUFBTSxNQUFNO0lBRVosSUFBSUEsY0FBTSxXQUFXLEtBQUssR0FBRyxHQUFHO0tBQzlCLE9BQU8sSUFBSTtLQUNYLElBQUksT0FBT0EsY0FBTSxRQUFRLElBQUksSUFBSSxDQUFDLEdBQUcsTUFBTSxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sTUFBTSxFQUFFO0lBQ3hFLE9BQ0UsSUFBSSxPQUFPLE1BQU07R0FFckI7R0FFQSxXQUFXLEtBQUssY0FBYztFQUNoQyxPQUNFLFVBQVUsUUFBUSxVQUFVLGdCQUFnQixRQUFRLE9BQU87RUFHN0QsT0FBTztDQUNUO0NBRUEsSUFBSSxRQUFRLFFBQVE7RUFDbEIsU0FBUyxnQkFBZ0IsTUFBTTtFQUUvQixJQUFJLFFBQVE7R0FDVixNQUFNLE1BQU1BLGNBQU0sUUFBUSxNQUFNLE1BQU07R0FFdEMsSUFBSSxLQUFLO0lBQ1AsTUFBTSxRQUFRLEtBQUs7SUFFbkIsSUFBSSxDQUFDLFFBQ0gsT0FBTztJQUdULElBQUksV0FBVyxNQUNiLE9BQU8sWUFBWSxLQUFLO0lBRzFCLElBQUlBLGNBQU0sV0FBVyxNQUFNLEdBQ3pCLE9BQU8sT0FBTyxLQUFLLE1BQU0sT0FBTyxHQUFHO0lBR3JDLElBQUlBLGNBQU0sU0FBUyxNQUFNLEdBQ3ZCLE9BQU8sT0FBTyxLQUFLLEtBQUs7SUFHMUIsTUFBTSxJQUFJLFVBQVUsd0NBQXdDO0dBQzlEO0VBQ0Y7Q0FDRjtDQUVBLElBQUksUUFBUSxTQUFTO0VBQ25CLFNBQVMsZ0JBQWdCLE1BQU07RUFFL0IsSUFBSSxRQUFRO0dBQ1YsTUFBTSxNQUFNQSxjQUFNLFFBQVEsTUFBTSxNQUFNO0dBRXRDLE9BQU8sQ0FBQyxFQUNOLE9BQ0EsS0FBSyxTQUFTLEtBQUEsTUFDYixDQUFDLFdBQVcsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTztFQUUvRDtFQUVBLE9BQU87Q0FDVDtDQUVBLE9BQU8sUUFBUSxTQUFTO0VBQ3RCLE1BQU0sT0FBTztFQUNiLElBQUksVUFBVTtFQUVkLFNBQVMsYUFBYSxTQUFTO0dBQzdCLFVBQVUsZ0JBQWdCLE9BQU87R0FFakMsSUFBSSxTQUFTO0lBQ1gsTUFBTSxNQUFNQSxjQUFNLFFBQVEsTUFBTSxPQUFPO0lBRXZDLElBQUksUUFBUSxDQUFDLFdBQVcsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJO0tBQ3hFLE9BQU8sS0FBSztLQUVaLFVBQVU7SUFDWjtHQUNGO0VBQ0Y7RUFFQSxJQUFJQSxjQUFNLFFBQVEsTUFBTSxHQUN0QixPQUFPLFFBQVEsWUFBWTtPQUUzQixhQUFhLE1BQU07RUFHckIsT0FBTztDQUNUO0NBRUEsTUFBTSxTQUFTO0VBQ2IsTUFBTSxPQUFPLE9BQU8sS0FBSyxJQUFJO0VBQzdCLElBQUksSUFBSSxLQUFLO0VBQ2IsSUFBSSxVQUFVO0VBRWQsT0FBTyxLQUFLO0dBQ1YsTUFBTSxNQUFNLEtBQUs7R0FDakIsSUFBSSxDQUFDLFdBQVcsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLEtBQUssU0FBUyxJQUFJLEdBQUc7SUFDckUsT0FBTyxLQUFLO0lBQ1osVUFBVTtHQUNaO0VBQ0Y7RUFFQSxPQUFPO0NBQ1Q7Q0FFQSxVQUFVLFFBQVE7RUFDaEIsTUFBTSxPQUFPO0VBQ2IsTUFBTSxVQUFVLE9BQU8sT0FBTyxJQUFJO0VBRWxDLGNBQU0sUUFBUSxPQUFPLE9BQU8sV0FBVztHQUNyQyxNQUFNLE1BQU1BLGNBQU0sUUFBUSxTQUFTLE1BQU07R0FFekMsSUFBSSxLQUFLO0lBQ1AsS0FBSyxPQUFPLGVBQWUsS0FBSztJQUNoQyxPQUFPLEtBQUs7SUFDWjtHQUNGO0dBRUEsTUFBTSxhQUFhLFdBQVcsU0FBUyxhQUFhLE1BQU0sSUFBSSxPQUFPLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztHQUVuRixJQUFJLGVBQWUsUUFDakIsT0FBTyxLQUFLO0dBR2QsS0FBSyxjQUFjLGVBQWUsS0FBSztHQUV2QyxRQUFRLGNBQWM7RUFDeEIsQ0FBQztFQUVELE9BQU87Q0FDVDtDQUVBLE9BQU8sR0FBRyxTQUFTO0VBQ2pCLE9BQU8sS0FBSyxZQUFZLE9BQU8sTUFBTSxHQUFHLE9BQU87Q0FDakQ7Q0FFQSxPQUFPLFdBQVc7RUFDaEIsTUFBTSxNQUFNLE9BQU8sT0FBTyxJQUFJO0VBRTlCLGNBQU0sUUFBUSxPQUFPLE9BQU8sV0FBVztHQUNyQyxTQUFTLFFBQ1AsVUFBVSxVQUNULElBQUksVUFBVSxhQUFhQSxjQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLElBQUk7RUFDMUUsQ0FBQztFQUVELE9BQU87Q0FDVDtDQUVBLENBQUMsT0FBTyxZQUFZO0VBQ2xCLE9BQU8sT0FBTyxRQUFRLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLFNBQVMsQ0FBQztDQUN4RDtDQUVBLFdBQVc7RUFDVCxPQUFPLE9BQU8sUUFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLEtBQUssQ0FBQyxRQUFRLFdBQVcsU0FBUyxPQUFPLEtBQUssQ0FBQyxDQUMvQyxLQUFLLElBQUk7Q0FDZDtDQUVBLGVBQWU7RUFDYixNQUFNLFFBQVEsS0FBSyxJQUFJLFlBQVk7RUFDbkMsT0FBT0EsY0FBTSxRQUFRLEtBQUssSUFBSSxRQUFRLFNBQVMsUUFBUSxVQUFVLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSztDQUN0RjtDQUVBLEtBQUssT0FBTyxlQUFlO0VBQ3pCLE9BQU87Q0FDVDtDQUVBLE9BQU8sS0FBSyxPQUFPO0VBQ2pCLE9BQU8saUJBQWlCLE9BQU8sUUFBUSxJQUFJLEtBQUssS0FBSztDQUN2RDtDQUVBLE9BQU8sZ0JBQWdCLE9BQU87RUFDNUIsT0FBTyxnQkFBZ0IsS0FBSztDQUM5QjtDQUVBLE9BQU8sT0FBTyxPQUFPLEdBQUcsU0FBUztFQUMvQixNQUFNLFdBQVcsSUFBSSxLQUFLLEtBQUs7RUFFL0IsUUFBUSxTQUFTLFdBQVcsU0FBUyxJQUFJLE1BQU0sQ0FBQztFQUVoRCxPQUFPO0NBQ1Q7Q0FFQSxPQUFPLFNBQVMsUUFBUTtFQVF0QixNQUFNLGFBQVksS0FOVkQsZ0JBQ04sS0FBS0EsZ0JBQ0gsRUFDRSxXQUFXLENBQUMsRUFDZCxFQUFBLENBRXdCO0VBQzVCLE1BQU0sWUFBWSxLQUFLO0VBRXZCLFNBQVMsZUFBZSxTQUFTO0dBQy9CLE1BQU0sVUFBVSxnQkFBZ0IsT0FBTztHQUV2QyxJQUFJLENBQUMsVUFBVSxVQUFVO0lBQ3ZCLGVBQWUsV0FBVyxPQUFPO0lBQ2pDLFVBQVUsV0FBVztHQUN2QjtFQUNGO0VBRUEsY0FBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLFFBQVEsY0FBYyxJQUFJLGVBQWUsTUFBTTtFQUU5RSxPQUFPO0NBQ1Q7QUFDRjtBQUVBRSxlQUFhLFNBQVM7Q0FDcEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0YsQ0FBQztBQUdERCxjQUFNLGtCQUFrQkMsZUFBYSxZQUFZLEVBQUUsU0FBUyxRQUFRO0NBQ2xFLElBQUksU0FBUyxJQUFJLEVBQUUsQ0FBQyxZQUFZLElBQUksSUFBSSxNQUFNLENBQUM7Q0FDL0MsT0FBTztFQUNMLFdBQVc7RUFDWCxJQUFJLGFBQWE7R0FDZixLQUFLLFVBQVU7RUFDakI7Q0FDRjtBQUNGLENBQUM7QUFFREQsY0FBTSxjQUFjQyxjQUFZOztBQy9kaEMsSUFBYSxXQUFXO0FBRXhCLFNBQVMsd0JBQXdCLFFBQVE7Q0FDdkMsSUFBSUUsY0FBTSxXQUFXLFFBQVEsUUFBUSxHQUNuQyxPQUFPO0NBR1QsSUFBSSxZQUFZLE9BQU8sZUFBZSxNQUFNO0NBRTVDLE9BQU8sYUFBYSxjQUFjLE9BQU8sV0FBVztFQUNsRCxJQUFJQSxjQUFNLFdBQVcsV0FBVyxRQUFRLEdBQ3RDLE9BQU87RUFHVCxZQUFZLE9BQU8sZUFBZSxTQUFTO0NBQzdDO0NBRUEsT0FBTztBQUNUO0FBS0EsU0FBUyxhQUFhLFFBQVEsWUFBWTtDQUN4QyxNQUFNLFlBQVksSUFBSSxJQUFJLFdBQVcsS0FBSyxNQUFNLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7Q0FDeEUsTUFBTSxPQUFPLENBQUM7Q0FFZCxNQUFNLFNBQVMsV0FBVztFQUN4QixJQUFJLFdBQVcsUUFBUSxPQUFPLFdBQVcsVUFBVSxPQUFPO0VBQzFELElBQUlBLGNBQU0sU0FBUyxNQUFNLEdBQUcsT0FBTztFQUNuQyxJQUFJLEtBQUssUUFBUSxNQUFNLE1BQU0sSUFBSSxPQUFPLEtBQUE7RUFFeEMsSUFBSSxrQkFBa0JDLGdCQUNwQixTQUFTLE9BQU8sT0FBTztFQUd6QixLQUFLLEtBQUssTUFBTTtFQUVoQixJQUFJO0VBQ0osSUFBSUQsY0FBTSxRQUFRLE1BQU0sR0FBRztHQUN6QixTQUFTLENBQUM7R0FDVixPQUFPLFNBQVMsR0FBRyxNQUFNO0lBQ3ZCLE1BQU0sZUFBZSxNQUFNLENBQUM7SUFDNUIsSUFBSSxDQUFDQSxjQUFNLFlBQVksWUFBWSxHQUNqQyxPQUFPLEtBQUs7R0FFaEIsQ0FBQztFQUNILE9BQU87R0FDTCxJQUFJLENBQUNBLGNBQU0sY0FBYyxNQUFNLEtBQUssd0JBQXdCLE1BQU0sR0FBRztJQUNuRSxLQUFLLElBQUk7SUFDVCxPQUFPO0dBQ1Q7R0FFQSxTQUFTLE9BQU8sT0FBTyxJQUFJO0dBQzNCLEtBQUssTUFBTSxDQUFDLEtBQUssVUFBVSxPQUFPLFFBQVEsTUFBTSxHQUFHO0lBQ2pELE1BQU0sZUFBZSxVQUFVLElBQUksSUFBSSxZQUFZLENBQUMsSUFBSSxXQUFXLE1BQU0sS0FBSztJQUM5RSxJQUFJLENBQUNBLGNBQU0sWUFBWSxZQUFZLEdBQ2pDLE9BQU8sT0FBTztHQUVsQjtFQUNGO0VBRUEsS0FBSyxJQUFJO0VBQ1QsT0FBTztDQUNUO0NBRUEsT0FBTyxNQUFNLE1BQU07QUFDckI7QUFFQSxTQUFTRSxrQkFBZ0IsT0FBTztDQUM5QixJQUFJO0VBQ0YsT0FBTyxPQUFPLEtBQUs7Q0FDckIsU0FBUyxLQUFLO0VBQ1osT0FBTztDQUNUO0FBQ0Y7QUFFQSxTQUFTLHNCQUFzQixPQUFPO0NBWXBDLE9BWGdCLE1BQU0sT0FDbkIsS0FBSyxVQUFVO0VBQ2QsSUFBSTtHQUNGLE9BQU8sU0FBUyxNQUFNLFVBQVVBLGtCQUFnQixNQUFNLE9BQU8sSUFBSUEsa0JBQWdCLEtBQUs7RUFDeEYsU0FBUyxLQUFLO0dBQ1osT0FBTztFQUNUO0NBQ0YsQ0FBQyxDQUFDLENBQ0QsT0FBTyxPQUFPLENBQUMsQ0FDZixLQUFLLElBRUssS0FBSyxNQUFNLFFBQVE7QUFDbEM7QUFJQSxJQUFhLHNCQUFzQjtBQUNuQyxJQUFNLGNBQWMsT0FBTyxZQUFZO0FBSXZDLFNBQWdCLG1CQUFtQixPQUFPLE9BQU87Q0FDL0MsTUFBTSxhQUFhRixjQUFNLFdBQVcsT0FBTyxXQUFXLEtBQUssTUFBTTtDQUVqRSxPQUFPLGNBQWMsTUFBTSxTQUFTLFVBQVUsSUFBSSxNQUFNLFNBQVMsV0FBVyxTQUFTO0FBQ3ZGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0JBLFNBQVMsaUJBQWlCLFFBQVEsUUFBUTtDQUN4QyxJQUFJO0VBQ0YsTUFBTSxjQUFjLFVBQVUsT0FBTztFQUVyQyxJQUFJLE9BQU8sZ0JBQWdCLFlBQVksQ0FBQyxhQUN0QztFQUdGLE1BQU0sY0FBYyxPQUFPO0VBRTNCLElBQUksT0FBTyxnQkFBZ0IsWUFBWSxDQUFDLGFBQ3RDO0VBS0YsTUFBTSxhQUFhLHNCQUFzQjtFQUN6QyxPQUFPLFFBQVEsY0FBYztFQUM3QixPQUFPLGVBQWUsUUFBUSxhQUFhO0dBQUUsV0FBVztHQUFNLE9BQU87RUFBVyxDQUFDO0NBQ25GLFNBQVMsR0FBRyxDQUVaO0FBQ0Y7QUFFQSxJQUFNRyxlQUFOLE1BQU1BLHFCQUFtQixNQUFNO0NBQzdCLE9BQU8sS0FBSyxPQUFPLE1BQU0sUUFBUSxTQUFTLFVBQVUsYUFBYTtFQUkvRCxJQUFJLFVBQVUsTUFBTTtFQUNwQixJQUFJLENBQUMsV0FBV0gsY0FBTSxRQUFRLE1BQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxRQUMxRCxVQUFVLHNCQUFzQixLQUFLO0VBR3ZDLE1BQU0sYUFBYSxJQUFJRyxhQUFXLFNBQVMsUUFBUSxNQUFNLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFPeEYsT0FBTyxlQUFlLFlBQVksU0FBUztHQUN6QyxXQUFXO0dBQ1gsT0FBTztHQUNQLFVBQVU7R0FDVixZQUFZO0dBQ1osY0FBYztFQUNoQixDQUFDO0VBQ0QsV0FBVyxPQUFPLE1BQU07RUFJeEIsaUJBQWlCLFlBQVksS0FBSztFQUdsQyxJQUFJLE1BQU0sVUFBVSxRQUFRLFdBQVcsVUFBVSxNQUMvQyxXQUFXLFNBQVMsTUFBTTtFQUc1QixlQUFlLE9BQU8sT0FBTyxZQUFZLFdBQVc7RUFDcEQsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Q0FhQSxZQUFZLFNBQVMsTUFBTSxRQUFRLFNBQVMsVUFBVTtFQUNwRCxNQUFNLE9BQU87RUFLYixPQUFPLGVBQWUsTUFBTSxXQUFXO0dBR3JDLFdBQVc7R0FDWCxPQUFPO0dBQ1AsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0VBQ2hCLENBQUM7RUFFRCxLQUFLLE9BQU87RUFDWixLQUFLLGVBQWU7RUFDcEIsU0FBUyxLQUFLLE9BQU87RUFDckIsV0FBVyxLQUFLLFNBQVM7RUFDekIsWUFBWSxLQUFLLFVBQVU7RUFDM0IsSUFBSSxVQUFVO0dBQ1osS0FBSyxXQUFXO0dBQ2hCLEtBQUssU0FBUyxTQUFTO0VBQ3pCO0NBQ0Y7Q0FFQSxTQUFTO0VBS1AsTUFBTSxTQUFTLEtBQUs7RUFDcEIsTUFBTSxhQUFhLFVBQVVILGNBQU0sV0FBVyxRQUFRLFFBQVEsSUFBSSxPQUFPLFNBQVMsS0FBQTtFQUNsRixNQUFNLG1CQUNKQSxjQUFNLFFBQVEsVUFBVSxLQUFLLFdBQVcsU0FBUyxJQUM3QyxhQUFhLFFBQVEsVUFBVSxJQUMvQkEsY0FBTSxhQUFhLE1BQU07RUFFL0IsT0FBTztHQUVMLFNBQVMsS0FBSztHQUNkLE1BQU0sS0FBSztHQUVYLGFBQWEsS0FBSztHQUNsQixRQUFRLEtBQUs7R0FFYixVQUFVLEtBQUs7R0FDZixZQUFZLEtBQUs7R0FDakIsY0FBYyxLQUFLO0dBQ25CLE9BQU8sS0FBSztHQUVaLFFBQVE7R0FDUixNQUFNLEtBQUs7R0FDWCxRQUFRLEtBQUs7RUFDZjtDQUNGO0FBQ0Y7QUFHQSxhQUFXLHVCQUF1QjtBQUNsQyxhQUFXLGlCQUFpQjtBQUM1QixhQUFXLGVBQWU7QUFDMUIsYUFBVyxZQUFZO0FBQ3ZCLGFBQVcsZUFBZTtBQUMxQixhQUFXLGNBQWM7QUFDekIsYUFBVyw0QkFBNEI7QUFDdkMsYUFBVyxpQkFBaUI7QUFDNUIsYUFBVyxtQkFBbUI7QUFDOUIsYUFBVyxrQkFBa0I7QUFDN0IsYUFBVyxlQUFlO0FBQzFCLGFBQVcsa0JBQWtCO0FBQzdCLGFBQVcsa0JBQWtCO0FBQzdCLGFBQVcsK0JBQStCOzs7Ozs7OztBQ2hRMUMsU0FBUyxZQUFZLE9BQU87Q0FDMUIsT0FBT0ksY0FBTSxjQUFjLEtBQUssS0FBS0EsY0FBTSxRQUFRLEtBQUs7QUFDMUQ7Ozs7Ozs7O0FBU0EsU0FBUyxlQUFlLEtBQUs7Q0FDM0IsT0FBT0EsY0FBTSxTQUFTLEtBQUssSUFBSSxJQUFJLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUN4RDs7Ozs7Ozs7OztBQVdBLFNBQVMsVUFBVSxNQUFNLEtBQUssTUFBTTtDQUNsQyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE9BQU8sS0FDSixPQUFPLEdBQUcsQ0FBQyxDQUNYLElBQUksU0FBUyxLQUFLLE9BQU8sR0FBRztFQUUzQixRQUFRLGVBQWUsS0FBSztFQUM1QixPQUFPLENBQUMsUUFBUSxJQUFJLE1BQU0sUUFBUSxNQUFNO0NBQzFDLENBQUMsQ0FBQyxDQUNELEtBQUssT0FBTyxNQUFNLEVBQUU7QUFDekI7Ozs7Ozs7O0FBU0EsU0FBUyxZQUFZLEtBQUs7Q0FDeEIsT0FBT0EsY0FBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXO0FBQ3BEO0FBRUEsSUFBTSxhQUFhQSxjQUFNLGFBQWFBLGVBQU8sQ0FBQyxHQUFHLE1BQU0sU0FBUyxPQUFPLE1BQU07Q0FDM0UsT0FBTyxXQUFXLEtBQUssSUFBSTtBQUM3QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXlCRCxTQUFTQyxhQUFXLEtBQUssVUFBVSxTQUFTO0NBQzFDLElBQUksQ0FBQ0QsY0FBTSxTQUFTLEdBQUcsR0FDckIsTUFBTSxJQUFJLFVBQVUsMEJBQTBCO0NBSWhELFdBQVcsWUFBWSxJQUF5QixTQUFVO0NBRTFELE1BQU0sVUFBVSxNQUFNLGFBQWE7RUFDakMsTUFBTSxRQUFRQSxjQUFNLFlBQVksU0FBUyxJQUFJO0VBQzdDLE9BQU9BLGNBQU0sWUFBWSxLQUFLLElBQUksV0FBVztDQUMvQztDQUVBLE1BQU0sYUFBYSxPQUFPLGNBQWMsSUFBSTtDQUU1QyxNQUFNLFVBQVUsT0FBTyxTQUFTLEtBQUs7Q0FDckMsTUFBTSxPQUFPLE9BQU8sUUFBUSxLQUFLO0NBQ2pDLE1BQU0sVUFBVSxPQUFPLFdBQVcsS0FBSztDQUN2QyxNQUFNLFFBQVEsT0FBTyxNQUFNLEtBQU0sT0FBTyxTQUFTLGVBQWU7Q0FDaEUsTUFBTSxXQUFXLE9BQU8sWUFBQSxHQUF1QztDQUMvRCxNQUFNLFVBQVUsU0FBU0EsY0FBTSxvQkFBb0IsUUFBUTtDQUMzRCxNQUFNLFFBQVEsQ0FBQztDQUVmLElBQUksQ0FBQ0EsY0FBTSxXQUFXLE9BQU8sR0FDM0IsTUFBTSxJQUFJLFVBQVUsNEJBQTRCO0NBR2xELFNBQVMsYUFBYSxPQUFPO0VBQzNCLElBQUksVUFBVSxNQUFNLE9BQU87RUFFM0IsSUFBSUEsY0FBTSxPQUFPLEtBQUssR0FDcEIsT0FBTyxNQUFNLFlBQVk7RUFHM0IsSUFBSUEsY0FBTSxVQUFVLEtBQUssR0FDdkIsT0FBTyxNQUFNLFNBQVM7RUFHeEIsSUFBSSxDQUFDLFdBQVdBLGNBQU0sT0FBTyxLQUFLLEdBQ2hDLE1BQU0sSUFBSUUsYUFBVyw4Q0FBOEM7RUFHckUsSUFBSUYsY0FBTSxjQUFjLEtBQUssS0FBS0EsY0FBTSxhQUFhLEtBQUssR0FBRztHQUMzRCxJQUFJLFdBQVcsT0FBTyxVQUFVLFlBQzlCLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDO0dBSzFCLE1BQU0sSUFBSUUsYUFDUixnREFDQUEsYUFBVyxlQUNiO0VBQ0Y7RUFFQSxPQUFPO0NBQ1Q7Q0FFQSxTQUFTLHdCQUF3QixPQUFPO0VBQ3RDLElBQUksUUFBUSxVQUNWLE1BQU0sSUFBSUEsYUFDUixrQ0FBa0MsUUFBUSwwQkFBMEIsVUFDcEVBLGFBQVcsNEJBQ2I7Q0FFSjtDQUVBLFNBQVMsd0JBQXdCLE9BQU8sT0FBTztFQUM3QyxJQUFJLGFBQWEsVUFDZixPQUFPLEtBQUssVUFBVSxLQUFLO0VBRzdCLE1BQU0sWUFBWSxDQUFDO0VBRW5CLE9BQU8sS0FBSyxVQUFVLE9BQU8sU0FBUyxXQUFXLE1BQU0sY0FBYztHQUNuRSxJQUFJLENBQUNGLGNBQU0sU0FBUyxZQUFZLEdBQzlCLE9BQU87R0FHVCxPQUFPLFVBQVUsVUFBVSxVQUFVLFVBQVUsU0FBUyxPQUFPLE1BQzdELFVBQVUsSUFBSTtHQUdoQixVQUFVLEtBQUssWUFBWTtHQUMzQix3QkFBd0IsUUFBUSxVQUFVLFNBQVMsQ0FBQztHQUVwRCxPQUFPO0VBQ1QsQ0FBQztDQUNIOzs7Ozs7Ozs7OztDQVlBLFNBQVMsZUFBZSxPQUFPLEtBQUssTUFBTTtFQUN4QyxJQUFJLE1BQU07RUFFVixJQUFJQSxjQUFNLGNBQWMsUUFBUSxLQUFLQSxjQUFNLGtCQUFrQixLQUFLLEdBQUc7R0FDbkUsU0FBUyxPQUFPLFVBQVUsTUFBTSxLQUFLLElBQUksR0FBRyxhQUFhLEtBQUssQ0FBQztHQUMvRCxPQUFPO0VBQ1Q7RUFFQSxJQUFJLFNBQVMsQ0FBQyxRQUFRLE9BQU8sVUFBVSxVQUFVO0dBQy9DLElBQUlBLGNBQU0sU0FBUyxLQUFLLElBQUksR0FBRztJQUU3QixNQUFNLGFBQWEsTUFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFO0lBRXhDLFFBQVEsd0JBQXdCLE9BQU8sQ0FBQztHQUMxQyxPQUFPLElBQ0pBLGNBQU0sUUFBUSxLQUFLLEtBQUssWUFBWSxLQUFLLE1BQ3hDQSxjQUFNLFdBQVcsS0FBSyxLQUFLQSxjQUFNLFNBQVMsS0FBSyxJQUFJLE9BQU8sTUFBTUEsY0FBTSxRQUFRLEtBQUssSUFDckY7SUFFQSxNQUFNLGVBQWUsR0FBRztJQUV4QixJQUFJLFFBQVEsU0FBUyxLQUFLLElBQUksT0FBTztLQUNuQyxFQUFFQSxjQUFNLFlBQVksRUFBRSxLQUFLLE9BQU8sU0FDaEMsU0FBUyxPQUVQLFlBQVksT0FDUixVQUFVLENBQUMsR0FBRyxHQUFHLE9BQU8sSUFBSSxJQUM1QixZQUFZLE9BQ1YsTUFDQSxNQUFNLE1BQ1osYUFBYSxFQUFFLENBQ2pCO0lBQ0osQ0FBQztJQUNELE9BQU87R0FDVDtFQUNGO0VBRUEsSUFBSSxZQUFZLEtBQUssR0FDbkIsT0FBTztFQUdULFNBQVMsT0FBTyxVQUFVLE1BQU0sS0FBSyxJQUFJLEdBQUcsYUFBYSxLQUFLLENBQUM7RUFFL0QsT0FBTztDQUNUO0NBRUEsTUFBTSxpQkFBaUIsT0FBTyxPQUFPLFlBQVk7RUFDL0M7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUVELFNBQVMsTUFBTSxPQUFPLE1BQU0sUUFBUSxHQUFHO0VBQ3JDLElBQUlBLGNBQU0sWUFBWSxLQUFLLEdBQUc7RUFFOUIsd0JBQXdCLEtBQUs7RUFFN0IsSUFBSSxNQUFNLFFBQVEsS0FBSyxNQUFNLElBQzNCLE1BQU0sSUFBSSxNQUFNLG9DQUFvQyxLQUFLLEtBQUssR0FBRyxDQUFDO0VBR3BFLE1BQU0sS0FBSyxLQUFLO0VBRWhCLGNBQU0sUUFBUSxPQUFPLFNBQVMsS0FBSyxJQUFJLEtBQUs7R0FLMUMsS0FIRSxFQUFFQSxjQUFNLFlBQVksRUFBRSxLQUFLLE9BQU8sU0FDbEMsUUFBUSxLQUFLLFVBQVUsSUFBSUEsY0FBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLE1BQU0sY0FBYyxPQUUxRSxNQUNiLE1BQU0sSUFBSSxPQUFPLEtBQUssT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDO0VBRXhELENBQUM7RUFFRCxNQUFNLElBQUk7Q0FDWjtDQUVBLElBQUksQ0FBQ0EsY0FBTSxTQUFTLEdBQUcsR0FDckIsTUFBTSxJQUFJLFVBQVUsd0JBQXdCO0NBRzlDLE1BQU0sR0FBRztDQUVULE9BQU87QUFDVDs7Ozs7Ozs7OztBQ3hRQSxTQUFTRyxTQUFPLEtBQUs7Q0FDbkIsTUFBTSxVQUFVO0VBQ2QsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxRQUFRLGdCQUFnQixTQUFTLFNBQVMsT0FBTztFQUM5RSxPQUFPLFFBQVE7Q0FDakIsQ0FBQztBQUNIOzs7Ozs7Ozs7QUFVQSxTQUFTLHFCQUFxQixRQUFRLFNBQVM7Q0FDN0MsS0FBSyxTQUFTLENBQUM7Q0FFZixVQUFVQyxhQUFXLFFBQVEsTUFBTSxPQUFPO0FBQzVDO0FBRUEsSUFBTSxZQUFZLHFCQUFxQjtBQUV2QyxVQUFVLFNBQVMsU0FBUyxPQUFPLE1BQU0sT0FBTztDQUM5QyxLQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDO0FBQ2hDO0FBRUEsVUFBVSxXQUFXLFNBQVMsU0FBUyxTQUFTO0NBQzlDLE1BQU0sVUFBVSxXQUNYLFVBQVUsUUFBUSxLQUFLLE1BQU0sT0FBT0QsUUFBTSxJQUMzQ0E7Q0FFSixPQUFPLEtBQUssT0FDVCxJQUFJLFNBQVMsS0FBSyxNQUFNO0VBQ3ZCLE9BQU8sUUFBUSxLQUFLLEVBQUUsSUFBSSxNQUFNLFFBQVEsS0FBSyxFQUFFO0NBQ2pELEdBQUcsRUFBRSxDQUFDLENBQ0wsS0FBSyxHQUFHO0FBQ2I7Ozs7Ozs7Ozs7QUMzQ0EsU0FBZ0IsT0FBTyxLQUFLO0NBQzFCLE9BQU8sbUJBQW1CLEdBQUcsQ0FBQyxDQUMzQixRQUFRLFNBQVMsR0FBRyxDQUFDLENBQ3JCLFFBQVEsUUFBUSxHQUFHLENBQUMsQ0FDcEIsUUFBUSxTQUFTLEdBQUcsQ0FBQyxDQUNyQixRQUFRLFFBQVEsR0FBRztBQUN4Qjs7Ozs7Ozs7OztBQVdBLFNBQXdCLFNBQVMsS0FBSyxRQUFRLFNBQVM7Q0FDckQsSUFBSSxDQUFDLFFBQ0gsT0FBTztDQUVULE1BQU0sT0FBTztDQUViLE1BQU0sV0FBV0UsY0FBTSxXQUFXLE9BQU8sSUFDckMsRUFDRSxXQUFXLFFBQ2IsSUFDQTtDQUtKLE1BQU0sVUFBVUEsY0FBTSxZQUFZLFVBQVUsUUFBUSxLQUFLO0NBQ3pELE1BQU0sY0FBY0EsY0FBTSxZQUFZLFVBQVUsV0FBVztDQUUzRCxJQUFJO0NBRUosSUFBSSxhQUNGLG1CQUFtQixZQUFZLFFBQVEsUUFBUTtNQUUvQyxtQkFBbUJBLGNBQU0sa0JBQWtCLE1BQU0sSUFDN0MsT0FBTyxTQUFTLElBQ2hCLElBQUkscUJBQXFCLFFBQVEsUUFBUSxDQUFDLENBQUMsU0FBUyxPQUFPO0NBR2pFLElBQUksa0JBQWtCO0VBQ3BCLE1BQU0sZ0JBQWdCLElBQUksUUFBUSxHQUFHO0VBRXJDLElBQUksa0JBQWtCLElBQ3BCLE1BQU0sSUFBSSxNQUFNLEdBQUcsYUFBYTtFQUVsQyxRQUFRLElBQUksUUFBUSxHQUFHLE1BQU0sS0FBSyxNQUFNLE9BQU87Q0FDakQ7Q0FFQSxPQUFPO0FBQ1Q7O0FDaEVBLElBQU0sYUFBYSxPQUFPLFdBQVc7QUFLckMsU0FBUyxjQUFjLFVBQVU7Q0FDL0IsT0FBTyxXQUFXLFNBQVMsU0FBUztBQUN0QztBQUVBLFNBQVMsYUFBYSxVQUFVO0NBQzlCLElBQUksQ0FBQyxVQUNIO0NBR0YsT0FBTyxTQUFTLFVBQVUsU0FBUyxTQUFTLFNBQVMsT0FBTyxNQUMxRCxTQUFTLElBQUk7QUFFakI7QUFJQSxTQUFTLG1CQUFtQixJQUFJO0NBQzlCLElBQUksT0FBTyxPQUFPLFlBQVksT0FBTyxNQUFNLE9BQU8sT0FBTyxFQUFFLENBQUMsTUFBTSxJQUNoRSxPQUFPLE9BQU8sRUFBRTtDQUdsQixPQUFPO0FBQ1Q7QUFFQSxTQUFTLG1CQUFtQixTQUFTLFdBQVc7Q0FDOUMsTUFBTSxXQUFXLFFBQVE7Q0FDekIsTUFBTSxTQUFTLGNBQWMsUUFBUTtDQUVyQyxJQUFJLGFBQWEsVUFBVSxhQUFhO0VBQ3RDLFVBQVUsY0FBYztFQUN4QixVQUFVLGVBQWUsTUFBTTtDQUNqQyxPQUFPLElBQUksV0FBVyxVQUFVLGdCQUFnQjtFQUM5QyxJQUFJLENBQUMsUUFDSCxVQUFVLGVBQWUsTUFBTTtPQUUvQixVQUFVLGVBQWUsUUFBUSxTQUFTLGlCQUFpQixPQUFPLElBQUk7R0FDcEUsSUFBSSxTQUFTLE1BQU0sV0FBVyxNQUFNLFNBQ2xDLFVBQVUsZUFBZSxPQUFPLEVBQUU7RUFFdEMsQ0FBQztDQUVMO0NBRUEsVUFBVSxpQkFBaUI7QUFDN0I7QUFFQSxJQUFNLHFCQUFOLE1BQXlCO0NBQ3ZCLGNBQWM7RUFDWixLQUFLLFdBQVcsQ0FBQztFQUNqQixLQUFLLGNBQWM7R0FDakIsYUFBYSxLQUFLO0dBQ2xCLGdCQUFnQixLQUFLLFNBQVM7R0FDOUIsZ0NBQWdCLElBQUksSUFBSTtHQUN4QixnQkFBZ0I7R0FDaEIsUUFBUTtFQUNWO0NBQ0Y7Ozs7Ozs7Ozs7Q0FXQSxJQUFJLFdBQVcsVUFBVSxTQUFTO0VBQ2hDLE1BQU0sVUFBVTtHQUNkO0dBQ0E7R0FDQSxhQUFhLFVBQVUsUUFBUSxjQUFjO0dBQzdDLFNBQVMsVUFBVSxRQUFRLFVBQVU7RUFDdkM7RUFDQSxNQUFNLFlBQVksS0FBSztFQUV2QixJQUFJLEtBQUssWUFBWSxNQUNuQixLQUFLLFdBQVcsQ0FBQztFQUduQixtQkFBbUIsTUFBTSxTQUFTO0VBRWxDLE1BQU0sS0FBSyxVQUFVO0VBRXJCLEtBQUssU0FBUyxLQUFLLE9BQU87RUFDMUIsVUFBVSxlQUFlLElBQUksSUFBSTtHQUMvQjtHQUNBLE9BQU8sS0FBSyxTQUFTLFNBQVM7RUFDaEMsQ0FBQztFQUNELFVBQVUsaUJBQWlCLEtBQUssU0FBUztFQUV6QyxPQUFPO0NBQ1Q7Ozs7Ozs7O0NBU0EsTUFBTSxJQUFJO0VBQ1IsTUFBTSxZQUFZLEtBQUs7RUFFdkIsbUJBQW1CLE1BQU0sU0FBUztFQUVsQyxNQUFNLFlBQVksbUJBQW1CLEVBQUU7RUFDdkMsTUFBTSxRQUFRLFVBQVUsZUFBZSxJQUFJLFNBQVM7RUFFcEQsSUFBSSxPQUFPO0dBQ1QsVUFBVSxlQUFlLE9BQU8sU0FBUztHQUd6QyxJQUFJLEtBQUssU0FBUyxNQUFNLFdBQVcsTUFBTSxTQUN2QztHQUdGLEtBQUssU0FBUyxNQUFNLFNBQVM7R0FHN0IsSUFBSSxDQUFDLFVBQVUsZ0JBQWdCO0lBQzdCLGFBQWEsS0FBSyxRQUFRO0lBQzFCLFVBQVUsaUJBQWlCLEtBQUssU0FBUztHQUMzQztFQUNGO0NBQ0Y7Ozs7OztDQU9BLFFBQVE7RUFDTixJQUFJLEtBQUssVUFBVTtHQUNqQixLQUFLLFdBQVcsQ0FBQztHQUNqQixtQkFBbUIsTUFBTSxLQUFLLFdBQVc7RUFDM0M7Q0FDRjs7Ozs7Ozs7Ozs7Q0FZQSxRQUFRLElBQUk7RUFDVixNQUFNLFlBQVksS0FBSztFQUV2QixtQkFBbUIsTUFBTSxTQUFTO0VBRWxDLFVBQVU7RUFFVixJQUFJO0dBQ0YsY0FBTSxRQUFRLEtBQUssVUFBVSxTQUFTLGVBQWUsR0FBRztJQUN0RCxJQUFJLE1BQU0sTUFDUixHQUFHLENBQUM7R0FFUixDQUFDO0VBQ0gsVUFBVTtHQUNSLElBQUksQ0FBQyxFQUFFLFVBQVUsZ0JBQWdCO0lBQy9CLG1CQUFtQixNQUFNLFNBQVM7SUFDbEMsYUFBYSxLQUFLLFFBQVE7SUFDMUIsVUFBVSxpQkFBaUIsY0FBYyxLQUFLLFFBQVE7R0FDeEQ7RUFDRjtDQUNGO0FBQ0Y7O0FDakxBLElBQUEsdUJBQWU7Q0FDYixtQkFBbUI7Q0FDbkIsbUJBQW1CO0NBQ25CLHFCQUFxQjtDQUNyQixpQ0FBaUM7Q0FDakMsNkJBQTZCO0NBQzdCLGlDQUFpQztDQUNqQyx5QkFBeUI7QUFDM0I7O0FJTkEsSUFBQSxrQkFBZTtDQUNiLFdBQVc7Q0FDWCxTQUFTO0VBQ1AsaUJISlcsT0FBTyxvQkFBb0IsY0FBYyxrQkFBa0I7RUdLdEUsVUZOVyxPQUFPLGFBQWEsY0FBYyxXQUFXO0VFT3hELE1EUFcsT0FBTyxTQUFTLGNBQWMsT0FBTztDQ1FsRDtDQUNBLFdBQVc7RUFBQztFQUFRO0VBQVM7RUFBUTtFQUFRO0VBQU87Q0FBTTtBQUM1RDs7Ozs7Ozs7O0FDWkEsSUFBTSxnQkFBZ0IsT0FBTyxXQUFXLGVBQWUsT0FBTyxhQUFhO0FBRTNFLElBQU0sYUFBYyxPQUFPLGNBQWMsWUFBWSxhQUFjLEtBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CbkUsSUFBTSx3QkFDSixrQkFDQyxDQUFDLGNBQWM7Q0FBQztDQUFlO0NBQWdCO0FBQUksQ0FBQyxDQUFDLFFBQVEsV0FBVyxPQUFPLElBQUk7Ozs7Ozs7Ozs7QUFXdEYsSUFBTSx3Q0FBd0M7Q0FDNUMsT0FDRSxPQUFPLHNCQUFzQixlQUU3QixnQkFBZ0IscUJBQ2hCLE9BQU8sS0FBSyxrQkFBa0I7QUFFbEMsRUFBQSxDQUFHO0FBRUgsSUFBTSxTQUFVLGlCQUFpQixPQUFPLFNBQVMsUUFBUzs7QUN4QzFELElBQUEsbUJBQWU7Q0FDYixHQUFHQztDQUNILEdBQUdDO0FBQ0w7O0FDQUEsU0FBd0IsaUJBQWlCLE1BQU0sU0FBUztDQUN0RCxPQUFPQyxhQUFXLE1BQU0sSUFBSUMsaUJBQVMsUUFBUSxnQkFBZ0IsR0FBRztFQUM5RCxTQUFTLFNBQVUsT0FBTyxLQUFLLE1BQU0sU0FBUztHQUM1QyxJQUFJQSxpQkFBUyxVQUFVQyxjQUFNLFNBQVMsS0FBSyxHQUFHO0lBQzVDLEtBQUssT0FBTyxLQUFLLE1BQU0sU0FBUyxRQUFRLENBQUM7SUFDekMsT0FBTztHQUNUO0dBRUEsT0FBTyxRQUFRLGVBQWUsTUFBTSxNQUFNLFNBQVM7RUFDckQ7RUFDQSxHQUFHO0NBQ0wsQ0FBQztBQUNIOztBQ1pBLElBQU0sWUFBQTtBQUVOLFNBQVMscUJBQXFCLE9BQU87Q0FDbkMsSUFBSSxRQUFRLFdBQ1YsTUFBTSxJQUFJQyxhQUNSLDBDQUEwQyxRQUFRLDBCQUEwQixXQUM1RUEsYUFBVyw0QkFDYjtBQUVKOzs7Ozs7OztBQVNBLFNBQVMsY0FBYyxNQUFNO0NBVzNCLE1BQU0sT0FBTyxDQUFDO0NBQ2QsTUFBTSxVQUFVO0NBQ2hCLElBQUk7Q0FFSixRQUFRLFFBQVEsUUFBUSxLQUFLLElBQUksT0FBTyxNQUFNO0VBQzVDLHFCQUFxQixLQUFLLE1BQU07RUFDaEMsS0FBSyxLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sRUFBRTtDQUN6RDtDQUVBLE9BQU87QUFDVDs7Ozs7Ozs7QUFTQSxTQUFTLGNBQWMsS0FBSztDQUMxQixNQUFNLE1BQU0sQ0FBQztDQUNiLE1BQU0sT0FBTyxPQUFPLEtBQUssR0FBRztDQUM1QixJQUFJO0NBQ0osTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSTtDQUNKLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQ3hCLE1BQU0sS0FBSztFQUNYLElBQUksT0FBTyxJQUFJO0NBQ2pCO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE9BQU87Q0FDN0IsSUFBSSxDQUFDQyxjQUFNLFFBQVEsS0FBSyxHQUFHLE9BQU87Q0FFbEMsTUFBTSxPQUFPLE9BQU8sS0FBSyxLQUFLO0NBQzlCLE9BQU8sS0FBSyxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU0sS0FBSyxVQUFVLFFBQVEsT0FBTyxLQUFLLENBQUMsSUFDbEYsY0FBYyxLQUFLLElBQ25CO0FBQ047QUFFQSxTQUFTLGdCQUFnQixLQUFLO0NBQzVCLE1BQU0sVUFBVSxDQUFDLEdBQUc7Q0FDcEIsT0FBTyxRQUFRLFFBQVE7RUFDckIsTUFBTSxTQUFTLFFBQVEsSUFBSTtFQUMzQixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUyxRQUFRO0dBQ25DLE1BQU0sUUFBUyxPQUFPLE9BQU8sZUFBZSxPQUFPLElBQUk7R0FDdkQsSUFBSUEsY0FBTSxRQUFRLEtBQUssS0FBS0EsY0FBTSxjQUFjLEtBQUssR0FDbkQsUUFBUSxLQUFLLEtBQUs7RUFFdEIsQ0FBQztDQUNIO0NBQ0EsT0FBTztBQUNUOzs7Ozs7OztBQVNBLFNBQVMsZUFBZSxVQUFVO0NBQ2hDLFNBQVMsVUFBVSxNQUFNLE9BQU8sUUFBUSxPQUFPO0VBQzdDLHFCQUFxQixLQUFLO0VBRTFCLElBQUksT0FBTyxLQUFLO0VBRWhCLElBQUksU0FBUyxhQUFhLE9BQU87RUFFakMsTUFBTSxlQUFlLE9BQU8sU0FBUyxDQUFDLElBQUk7RUFDMUMsTUFBTSxTQUFTLFNBQVMsS0FBSztFQUM3QixPQUFPLENBQUMsUUFBUUEsY0FBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLFNBQVM7RUFFeEQsSUFBSSxRQUFRO0dBQ1YsSUFBSUEsY0FBTSxXQUFXLFFBQVEsSUFBSSxHQUFHO0lBQ2xDLE9BQU8sUUFBUSxlQUFlLE9BQU8sS0FBSztJQUMxQyxPQUFPLFFBQVFBLGNBQU0sUUFBUSxPQUFPLEtBQUssSUFDckMsT0FBTyxLQUFLLENBQUMsT0FBTyxLQUFLLElBQ3pCLENBQUMsT0FBTyxPQUFPLEtBQUs7R0FDMUIsT0FDRSxPQUFPLFFBQVE7R0FHakIsT0FBTyxDQUFDO0VBQ1Y7RUFFQSxJQUFJLENBQUNBLGNBQU0sV0FBVyxRQUFRLElBQUksS0FBSyxDQUFDQSxjQUFNLFNBQVMsT0FBTyxLQUFLLEdBQ2pFLE9BQU8sUUFBUSxDQUFDO0VBS2xCLElBRmUsVUFBVSxNQUFNLE9BQU8sT0FBTyxPQUFPLEtBRTNDLEtBQUtBLGNBQU0sUUFBUSxPQUFPLEtBQUssR0FDdEMsT0FBTyxRQUFRLGNBQWMsT0FBTyxLQUFLO0VBRzNDLE9BQU8sQ0FBQztDQUNWO0NBRUEsSUFBSUEsY0FBTSxXQUFXLFFBQVEsS0FBS0EsY0FBTSxXQUFXLFNBQVMsT0FBTyxHQUFHO0VBQ3BFLE1BQU0sTUFBTSxDQUFDO0VBRWIsY0FBTSxhQUFhLFdBQVcsTUFBTSxVQUFVO0dBQzVDLFVBQVUsY0FBYyxJQUFJLEdBQUcsT0FBTyxLQUFLLENBQUM7RUFDOUMsQ0FBQztFQUVELE9BQU8sZ0JBQWdCLEdBQUc7Q0FDNUI7Q0FFQSxPQUFPO0FBQ1Q7O0FDaEpBLElBQU0sYUFBYSxPQUFPLE9BQU87Q0FDL0I7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGLENBQUM7O0FDSEQsSUFBTSxPQUFPLEtBQUssUUFBUyxPQUFPLFFBQVFDLGNBQU0sV0FBVyxLQUFLLEdBQUcsSUFBSSxJQUFJLE9BQU8sS0FBQTs7Ozs7Ozs7Ozs7QUFZbEYsU0FBUyxnQkFBZ0IsVUFBVSxRQUFRLFNBQVM7Q0FDbEQsSUFBSUEsY0FBTSxTQUFTLFFBQVEsR0FDekIsSUFBSTtFQUNGLENBQUMsVUFBVSxLQUFLLE1BQUEsQ0FBTyxRQUFRO0VBQy9CLE9BQU9BLGNBQU0sS0FBSyxRQUFRO0NBQzVCLFNBQVMsR0FBRztFQUNWLElBQUksRUFBRSxTQUFTLGVBQ2IsTUFBTTtDQUVWO0NBR0YsUUFBUSxXQUFXLEtBQUssVUFBQSxDQUFXLFFBQVE7QUFDN0M7QUFFQSxJQUFNLFdBQVc7Q0FDZixjQUFjQztDQUVkLFNBQVM7RUFBQztFQUFPO0VBQVE7Q0FBTztDQUVoQyxrQkFBa0IsQ0FDaEIsU0FBUyxpQkFBaUIsTUFBTSxTQUFTO0VBQ3ZDLE1BQU0sY0FBYyxRQUFRLGVBQWUsS0FBSztFQUNoRCxNQUFNLHFCQUFxQixZQUFZLFFBQVEsa0JBQWtCLElBQUk7RUFDckUsTUFBTSxrQkFBa0JELGNBQU0sU0FBUyxJQUFJO0VBRTNDLElBQUksbUJBQW1CQSxjQUFNLFdBQVcsSUFBSSxHQUMxQyxPQUFPLElBQUksU0FBUyxJQUFJO0VBSzFCLElBRm1CQSxjQUFNLFdBQVcsSUFFdkIsR0FDWCxPQUFPLHFCQUFxQixLQUFLLFVBQVUsZUFBZSxJQUFJLENBQUMsSUFBSTtFQUdyRSxJQUNFQSxjQUFNLGNBQWMsSUFBSSxLQUN4QkEsY0FBTSxTQUFTLElBQUksS0FDbkJBLGNBQU0sU0FBUyxJQUFJLEtBQ25CQSxjQUFNLE9BQU8sSUFBSSxLQUNqQkEsY0FBTSxPQUFPLElBQUksS0FDakJBLGNBQU0saUJBQWlCLElBQUksR0FFM0IsT0FBTztFQUVULElBQUlBLGNBQU0sa0JBQWtCLElBQUksR0FDOUIsT0FBTyxLQUFLO0VBRWQsSUFBSUEsY0FBTSxrQkFBa0IsSUFBSSxHQUFHO0dBQ2pDLFFBQVEsZUFBZSxtREFBbUQsS0FBSztHQUMvRSxPQUFPLEtBQUssU0FBUztFQUN2QjtFQUVBLElBQUk7RUFFSixJQUFJLGlCQUFpQjtHQUNuQixNQUFNLGlCQUFpQixJQUFJLE1BQU0sZ0JBQWdCO0dBQ2pELElBQUksWUFBWSxRQUFRLG1DQUFtQyxJQUFJLElBQzdELE9BQU8saUJBQWlCLE1BQU0sY0FBYyxDQUFDLENBQUMsU0FBUztHQUd6RCxLQUNHLGFBQWFBLGNBQU0sV0FBVyxJQUFJLE1BQ25DLFlBQVksUUFBUSxxQkFBcUIsSUFBSSxJQUM3QztJQUNBLE1BQU0sTUFBTSxJQUFJLE1BQU0sS0FBSztJQUMzQixNQUFNLFlBQVksT0FBTyxJQUFJO0lBRTdCLE9BQU9FLGFBQ0wsYUFBYSxFQUFFLFdBQVcsS0FBSyxJQUFJLE1BQ25DLGFBQWEsSUFBSSxVQUFVLEdBQzNCLGNBQ0Y7R0FDRjtFQUNGO0VBRUEsSUFBSSxtQkFBbUIsb0JBQW9CO0dBQ3pDLFFBQVEsZUFBZSxvQkFBb0IsS0FBSztHQUNoRCxPQUFPLGdCQUFnQixJQUFJO0VBQzdCO0VBRUEsT0FBTztDQUNULENBQ0Y7Q0FFQSxtQkFBbUIsQ0FDakIsU0FBUyxrQkFBa0IsTUFBTTtFQUMvQixNQUFNLGVBQWUsSUFBSSxNQUFNLGNBQWMsS0FBSyxTQUFTO0VBQzNELE1BQU0sb0JBQW9CLGdCQUFnQixhQUFhO0VBQ3ZELE1BQU0sZUFBZSxJQUFJLE1BQU0sY0FBYztFQUM3QyxNQUFNLGdCQUFnQixpQkFBaUI7RUFFdkMsSUFBSUYsY0FBTSxXQUFXLElBQUksS0FBS0EsY0FBTSxpQkFBaUIsSUFBSSxHQUN2RCxPQUFPO0VBR1QsSUFDRSxRQUNBQSxjQUFNLFNBQVMsSUFBSSxNQUNqQixxQkFBcUIsQ0FBQyxnQkFBaUIsZ0JBQ3pDO0dBRUEsTUFBTSxvQkFBb0IsRUFEQSxnQkFBZ0IsYUFBYSxzQkFDUDtHQUVoRCxJQUFJO0lBQ0YsT0FBTyxLQUFLLE1BQU0sTUFBTSxJQUFJLE1BQU0sY0FBYyxDQUFDO0dBQ25ELFNBQVMsR0FBRztJQUNWLElBQUksbUJBQW1CO0tBQ3JCLElBQUksRUFBRSxTQUFTLGVBQ2IsTUFBTUcsYUFBVyxLQUFLLEdBQUdBLGFBQVcsa0JBQWtCLE1BQU0sTUFBTSxJQUFJLE1BQU0sVUFBVSxDQUFDO0tBRXpGLE1BQU07SUFDUjtHQUNGO0VBQ0Y7RUFFQSxPQUFPO0NBQ1QsQ0FDRjs7Ozs7Q0FNQSxTQUFTO0NBRVQsZ0JBQWdCO0NBQ2hCLGdCQUFnQjtDQUVoQixrQkFBa0I7Q0FDbEIsZUFBZTtDQUVmLEtBQUs7RUFDSCxVQUFVQyxpQkFBUyxRQUFRO0VBQzNCLE1BQU1BLGlCQUFTLFFBQVE7Q0FDekI7Q0FFQSxnQkFBZ0IsU0FBUyxlQUFlLFFBQVE7RUFDOUMsT0FBTyxVQUFVLE9BQU8sU0FBUztDQUNuQztDQUVBLFNBQVMsRUFDUCxRQUFRO0VBQ04sUUFBUTtFQUNSLGdCQUFnQixLQUFBO0NBQ2xCLEVBQ0Y7QUFDRjtBQUVBSixjQUFNLFFBQVEsYUFBYSxXQUFXO0NBQ3BDLFNBQVMsUUFBUSxVQUFVLENBQUM7QUFDOUIsQ0FBQzs7Ozs7Ozs7OztBQ2pLRCxTQUF3QixjQUFjLEtBQUssVUFBVTtDQUNuRCxNQUFNLFNBQVMsUUFBUTtDQUN2QixNQUFNLFVBQVUsWUFBWTtDQUM1QixNQUFNLFVBQVVLLGVBQWEsS0FBSyxRQUFRLE9BQU87Q0FDakQsSUFBSSxPQUFPLFFBQVE7Q0FFbkIsY0FBTSxRQUFRLEtBQUssU0FBUyxVQUFVLElBQUk7RUFDeEMsT0FBTyxHQUFHLEtBQUssUUFBUSxNQUFNLFFBQVEsVUFBVSxHQUFHLFdBQVcsU0FBUyxTQUFTLEtBQUEsQ0FBUztDQUMxRixDQUFDO0NBRUQsUUFBUSxVQUFVO0NBRWxCLE9BQU87QUFDVDs7QUN6QkEsU0FBd0JDLFdBQVMsT0FBTztDQUN0QyxPQUFPLENBQUMsRUFBRSxTQUFTLE1BQU07QUFDM0I7O0FDQUEsSUFBTUMsa0JBQU4sY0FBNEJDLGFBQVc7Ozs7Ozs7Ozs7Q0FVckMsWUFBWSxTQUFTLFFBQVEsU0FBUztFQUNwQyxNQUFNLFdBQVcsT0FBTyxhQUFhLFNBQVNBLGFBQVcsY0FBYyxRQUFRLE9BQU87RUFDdEYsS0FBSyxPQUFPO0VBQ1osS0FBSyxhQUFhO0NBQ3BCO0FBQ0Y7Ozs7Ozs7Ozs7O0FDTkEsU0FBd0IsT0FBTyxTQUFTLFFBQVEsVUFBVTtDQUN4RCxNQUFNLGlCQUFpQixTQUFTLE9BQU87Q0FDdkMsSUFBSSxDQUFDLFNBQVMsVUFBVSxDQUFDLGtCQUFrQixlQUFlLFNBQVMsTUFBTSxHQUN2RSxRQUFRLFFBQVE7TUFFaEIsT0FBTyxJQUFJQyxhQUNULHFDQUFxQyxTQUFTLFFBQzlDLFNBQVMsVUFBVSxPQUFPLFNBQVMsU0FBUyxNQUFNQSxhQUFXLGtCQUFrQkEsYUFBVyxrQkFDMUYsU0FBUyxRQUNULFNBQVMsU0FDVCxRQUNGLENBQUM7QUFFTDs7QUN4QkEsSUFBTSw2QkFBNkI7Ozs7Ozs7O0FBU25DLFNBQXdCLDZCQUE2QixLQUFLO0NBQ3hELElBQUksT0FBTyxRQUFRLFVBQ2pCLE9BQU87Q0FHVCxJQUFJLFFBQVE7Q0FFWixPQUFPLFFBQVEsSUFBSSxVQUFVLElBQUksV0FBVyxLQUFLLEtBQUssSUFDcEQ7Q0FHRixPQUFPLElBQUksTUFBTSxLQUFLLENBQUMsQ0FBQyxRQUFRLDRCQUE0QixFQUFFO0FBQ2hFOztBQ3JCQSxTQUF3QixjQUFjLEtBQUs7Q0FDekMsTUFBTSxRQUFRLDRCQUE0QixLQUFLLEdBQUc7Q0FDbEQsT0FBUSxTQUFTLE1BQU0sRUFBRSxDQUFDLFlBQVksS0FBTTtBQUM5Qzs7QUNGQSxJQUFNLHFCQUFxQixVQUFVO0NBQ25DLElBQUk7RUFDRixPQUFPLG1CQUFtQixLQUFLO0NBQ2pDLFNBQVMsR0FBRztFQUNWLE9BQU87Q0FDVDtBQUNGO0FBRUEsSUFBQSxrQkFBZUMsaUJBQVMsd0JBRXBCO0NBQ0UsTUFBTSxNQUFNLE9BQU8sU0FBUyxNQUFNLFFBQVEsUUFBUSxVQUFVO0VBQzFELElBQUksT0FBTyxhQUFhLGFBQWE7RUFFckMsTUFBTSxTQUFTLENBQUMsR0FBRyxLQUFLLEdBQUcsbUJBQW1CLEtBQUssR0FBRztFQUV0RCxJQUFJQyxjQUFNLFNBQVMsT0FBTyxHQUN4QixPQUFPLEtBQUssV0FBVyxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsWUFBWSxHQUFHO0VBRTFELElBQUlBLGNBQU0sU0FBUyxJQUFJLEdBQ3JCLE9BQU8sS0FBSyxRQUFRLE1BQU07RUFFNUIsSUFBSUEsY0FBTSxTQUFTLE1BQU0sR0FDdkIsT0FBTyxLQUFLLFVBQVUsUUFBUTtFQUVoQyxJQUFJLFdBQVcsTUFDYixPQUFPLEtBQUssUUFBUTtFQUV0QixJQUFJQSxjQUFNLFNBQVMsUUFBUSxHQUN6QixPQUFPLEtBQUssWUFBWSxVQUFVO0VBR3BDLFNBQVMsU0FBUyxPQUFPLEtBQUssSUFBSTtDQUNwQztDQUVBLEtBQUssTUFBTTtFQUNULElBQUksT0FBTyxhQUFhLGFBQWEsT0FBTztFQUM1QyxNQUFNLGVBQWUsU0FBUztFQUM5QixJQUFJLENBQUMsY0FBYyxPQUFPO0VBTTFCLE1BQU0sVUFBVSxhQUFhLE1BQU0sR0FBRztFQUN0QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7R0FDdkMsTUFBTSxTQUFTLFFBQVEsRUFBRSxDQUFDLFFBQVEsUUFBUSxFQUFFO0dBQzVDLE1BQU0sS0FBSyxPQUFPLFFBQVEsR0FBRztHQUM3QixJQUFJLE9BQU8sTUFBTSxPQUFPLE1BQU0sR0FBRyxFQUFFLE1BQU0sTUFDdkMsT0FBTyxrQkFBa0IsT0FBTyxNQUFNLEtBQUssQ0FBQyxDQUFDO0VBRWpEO0VBQ0EsT0FBTztDQUNUO0NBRUEsTUFBTSxVQUFVLE1BQU07RUFDcEIsSUFBSTtHQUNGLE1BQU0sUUFBUSxPQUFPLFdBQVcsZUFBZSxPQUFPO0dBQ3RELElBQUksU0FBU0EsY0FBTSxXQUFXLE1BQU0sR0FBRyxHQUFHO0lBQ3hDLE1BQU0sU0FBUyxNQUFNLE1BQU0sSUFBSSxJQUFJO0lBRW5DLE9BQU8sU0FBUyxrQkFBa0IsT0FBTyxLQUFLLElBQUk7R0FDcEQ7RUFDRixTQUFTLEdBQUcsQ0FFWjtFQUVBLE9BQU8sS0FBSyxLQUFLLElBQUk7Q0FDdkI7Q0FFQSxPQUFPLE1BQU07RUFDWCxLQUFLLE1BQU0sTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLE9BQVUsR0FBRztDQUNqRDtBQUNGLElBRUE7Q0FDRSxRQUFRLENBQUM7Q0FDVCxPQUFPO0VBQ0wsT0FBTztDQUNUO0NBQ0EsTUFBTSxZQUFZO0VBQ2hCLE9BQU87Q0FDVDtDQUNBLFNBQVMsQ0FBQztBQUNaOzs7Ozs7OztBQy9FSixTQUFTLFlBQVksY0FBYyxLQUFLO0NBQ3RDLGVBQWUsZ0JBQWdCO0NBQy9CLE1BQU0sUUFBUSxJQUFJLE1BQU0sWUFBWTtDQUNwQyxNQUFNLGFBQWEsSUFBSSxNQUFNLFlBQVk7Q0FDekMsSUFBSSxPQUFPO0NBQ1gsSUFBSSxPQUFPO0NBQ1gsSUFBSTtDQUVKLE1BQU0sUUFBUSxLQUFBLElBQVksTUFBTTtDQUVoQyxPQUFPLFNBQVMsS0FBSyxhQUFhO0VBQ2hDLE1BQU0sTUFBTSxLQUFLLElBQUk7RUFFckIsTUFBTSxZQUFZLFdBQVc7RUFFN0IsSUFBSSxDQUFDLGVBQ0gsZ0JBQWdCO0VBR2xCLE1BQU0sUUFBUTtFQUNkLFdBQVcsUUFBUTtFQUVuQixJQUFJLElBQUk7RUFDUixJQUFJLGFBQWE7RUFFakIsT0FBTyxNQUFNLE1BQU07R0FDakIsY0FBYyxNQUFNO0dBQ3BCLElBQUksSUFBSTtFQUNWO0VBRUEsUUFBUSxPQUFPLEtBQUs7RUFFcEIsSUFBSSxTQUFTLE1BQ1gsUUFBUSxPQUFPLEtBQUs7RUFHdEIsSUFBSSxNQUFNLGdCQUFnQixLQUN4QjtFQUdGLE1BQU0sU0FBUyxhQUFhLE1BQU07RUFFbEMsT0FBTyxTQUFTLEtBQUssTUFBTyxhQUFhLE1BQVEsTUFBTSxJQUFJLEtBQUE7Q0FDN0Q7QUFDRjs7Ozs7Ozs7QUM5Q0EsU0FBUyxTQUFTLElBQUksTUFBTTtDQUMxQixJQUFJLFlBQVk7Q0FDaEIsSUFBSSxZQUFZLE1BQU87Q0FDdkIsSUFBSTtDQUNKLElBQUk7Q0FFSixNQUFNLFVBQVUsTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNO0VBQ3pDLFlBQVk7RUFDWixXQUFXO0VBQ1gsSUFBSSxPQUFPO0dBQ1QsYUFBYSxLQUFLO0dBQ2xCLFFBQVE7RUFDVjtFQUNBLEdBQUcsR0FBRyxJQUFJO0NBQ1o7Q0FFQSxNQUFNLGFBQWEsR0FBRyxTQUFTO0VBQzdCLE1BQU0sTUFBTSxLQUFLLElBQUk7RUFDckIsTUFBTSxTQUFTLE1BQU07RUFDckIsSUFBSSxVQUFVLFdBQ1osT0FBTyxNQUFNLEdBQUc7T0FDWDtHQUNMLFdBQVc7R0FDWCxJQUFJLENBQUMsT0FDSCxRQUFRLGlCQUFpQjtJQUN2QixRQUFRO0lBQ1IsT0FBTyxRQUFRO0dBQ2pCLEdBQUcsWUFBWSxNQUFNO0VBRXpCO0NBQ0Y7Q0FFQSxNQUFNLGNBQWMsWUFBWSxPQUFPLFFBQVE7Q0FDL0MsTUFBTSxhQUFhLEdBQUcsU0FBUyxPQUFPLElBQUk7Q0FFMUMsT0FBTztFQUFDO0VBQVc7RUFBTztDQUFTO0FBQ3JDOztBQ3RDQSxJQUFhLHdCQUF3QixVQUFVLGtCQUFrQixPQUFPLE1BQU07Q0FDNUUsSUFBSSxnQkFBZ0I7Q0FDcEIsTUFBTSxlQUFlLFlBQVksSUFBSSxHQUFHO0NBRXhDLE9BQU8sVUFBVSxNQUFNO0VBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUNDLGNBQU0sU0FBUyxFQUFFLE1BQU0sR0FDaEM7RUFFRixNQUFNLFlBQVksRUFBRTtFQUNwQixNQUFNLFFBQVEsRUFBRSxtQkFBbUIsRUFBRSxRQUFRLEtBQUE7RUFDN0MsTUFBTSxTQUFTLEtBQUssSUFBSSxHQUFHLFNBQVMsT0FBTyxLQUFLLElBQUksV0FBVyxLQUFLLElBQUksU0FBUztFQUNqRixNQUFNLGdCQUFnQixLQUFLLElBQUksR0FBRyxTQUFTLGFBQWE7RUFDeEQsTUFBTSxPQUFPLGFBQWEsYUFBYTtFQUV2QyxnQkFBZ0IsS0FBSyxJQUFJLGVBQWUsTUFBTTtFQWM5QyxTQUFTO0dBWFA7R0FDQTtHQUNBLFVBQVUsUUFBUSxTQUFTLFFBQVEsS0FBQTtHQUNuQyxPQUFPO0dBQ1AsTUFBTSxPQUFPLE9BQU8sS0FBQTtHQUNwQixXQUFXLFFBQVEsU0FBUyxRQUFRLFVBQVUsT0FBTyxLQUFBO0dBQ3JELE9BQU87R0FDUCxrQkFBa0IsU0FBUztJQUMxQixtQkFBbUIsYUFBYSxXQUFXO0VBR2xDLENBQUM7Q0FDZixHQUFHLElBQUk7QUFDVDtBQUVBLElBQWEsMEJBQTBCLE9BQU8sY0FBYztDQUMxRCxNQUFNLG1CQUFtQixTQUFTO0NBRWxDLE9BQU8sRUFDSixXQUNDLFVBQVUsRUFBRSxDQUFDO0VBQ1g7RUFDQTtFQUNBO0NBQ0YsQ0FBQyxHQUNILFVBQVUsRUFDWjtBQUNGO0FBRUEsSUFBYSxrQkFDVixJQUFJLFlBQVlBLGNBQU0sVUFDdEIsR0FBRyxTQUNGLGdCQUFnQixHQUFHLEdBQUcsSUFBSSxDQUFDOztBQ25EL0IsSUFBQSwwQkFBZUMsaUJBQVMsMEJBQ2xCLFlBQVksUUFBUTtDQUNwQixNQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsV0FBV0EsaUJBQVMsTUFBTTtDQUV0RCxPQUNFLE9BQU8sYUFBYSxJQUFJLFlBQVksT0FBTyxTQUFTLElBQUksUUFBUSxPQUFPLFNBQVMsSUFBSTtBQUV4RixFQUFBLENBQUcsSUFBSSxJQUFJQSxpQkFBUyxNQUFNLENBQUMsVUFDckI7Ozs7Ozs7OztBQ0RWLFNBQXdCLGNBQWMsS0FBSztDQUl6QyxJQUFJLE9BQU8sUUFBUSxVQUNqQixPQUFPO0NBR1QsT0FBTyw4QkFBOEIsS0FBSyxHQUFHO0FBQy9DOzs7Ozs7Ozs7O0FDUkEsU0FBd0IsWUFBWSxTQUFTLGFBQWE7Q0FDeEQsSUFBSSxDQUFDLGFBQ0gsT0FBTztDQUdULElBQUksTUFBTSxRQUFRO0NBRWxCLE9BQU8sTUFBTSxLQUFLLFFBQVEsV0FBVyxNQUFNLENBQUMsTUFBTSxJQUNoRDtDQUdGLE9BQU8sUUFBUSxNQUFNLEdBQUcsR0FBRyxJQUFJLE1BQU0sWUFBWSxRQUFRLFFBQVEsRUFBRTtBQUNyRTs7QUNmQSxJQUFNLHdCQUF3QjtBQVU5QixTQUFTLGVBQWUsVUFBVTtDQUNoQyxJQUFJLENBQUMsVUFDSCxPQUFPO0NBR1QsT0FBTyxTQUFTLFFBQVEsMEJBQTBCLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTztFQUN6RixPQUFPLEdBQUcsWUFBWSxnQkFBZ0I7Q0FDeEMsQ0FBQztBQUNIO0FBRUEsU0FBUyx3QkFBd0IsS0FBSztDQUNwQyxNQUFNLGNBQWMsSUFBSSxRQUFRLDhCQUE4QixLQUFLLFNBQVMsRUFBRTtDQUM5RSxNQUFNLGdCQUFnQixZQUFZLFFBQVEsR0FBRztDQUc3QyxNQUFNLDhCQURKLGtCQUFrQixLQUFLLGNBQWMsWUFBWSxNQUFNLEdBQUcsYUFBYSxFQUFBLENBQ25CLFFBQ3BELHlCQUNBLEtBQUssVUFDUDtDQUVBLElBQUksa0JBQWtCLElBQ3BCLE9BQU87Q0FHVCxPQUFPLEdBQUcsMkJBQTJCLEdBQUcsZUFBZSxZQUFZLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQztBQUM3RjtBQUVBLFNBQVMsMkJBQTJCLEtBQUssUUFBUTtDQUMvQyxJQUFJLE9BQU8sUUFBUSxVQUFVO0VBQzNCLE1BQU0sZ0JBQWdCLDZCQUE2QixHQUFHO0VBQ3RELElBQUksc0JBQXNCLEtBQUssYUFBYSxHQUMxQyxNQUFNLElBQUlDLGFBQ1IsZUFBZSxLQUFLLFVBQVUsd0JBQXdCLGFBQWEsQ0FBQyxFQUFFLGdDQUN0RUEsYUFBVyxpQkFDWCxNQUNGO0NBRUo7QUFDRjs7Ozs7Ozs7Ozs7QUFZQSxTQUF3QixjQUFjLFNBQVMsY0FBYyxtQkFBbUIsUUFBUTtDQUN0RiwyQkFBMkIsY0FBYyxNQUFNO0NBQy9DLElBQUksZ0JBQWdCLENBQUMsY0FBYyxZQUFZO0NBQy9DLElBQUksWUFBWSxpQkFBaUIsc0JBQXNCLFFBQVE7RUFDN0QsMkJBQTJCLFNBQVMsTUFBTTtFQUMxQyxPQUFPLFlBQVksU0FBUyxZQUFZO0NBQzFDO0NBQ0EsT0FBTztBQUNUOztBQ3RFQSxTQUF3QixvQkFBb0IsUUFBUTtDQUNsRCxNQUFNLFVBQVUsQ0FBQyxFQUFFLE9BQU8sT0FBTyxDQUFDO0NBQ2xDLE1BQU0seUJBQVMsSUFBSSxRQUFRO0NBQzNCLE1BQU0sMEJBQVUsSUFBSSxRQUFRO0NBRTVCLE9BQU8sUUFBUSxRQUFRO0VBQ3JCLE1BQU0sRUFBRSxPQUFPLFNBQVMsUUFBUSxJQUFJO0VBQ3BDLElBQUksQ0FBQ0MsY0FBTSxjQUFjLEtBQUssS0FBSyxDQUFDQSxjQUFNLFFBQVEsS0FBSyxHQUFHO0VBQzFELElBQUksTUFBTTtHQUNSLE9BQU8sT0FBTyxLQUFLO0dBQ25CO0VBQ0Y7RUFDQSxJQUFJLE9BQU8sSUFBSSxLQUFLLEdBQ2xCLE1BQU0sSUFBSUMsYUFDUix5Q0FDQUEsYUFBVyxvQkFDYjtFQUVGLElBQUksUUFBUSxJQUFJLEtBQUssR0FBRztFQUN4QixRQUFRLElBQUksS0FBSztFQUNqQixPQUFPLElBQUksS0FBSztFQUNoQixRQUFRLEtBQUs7R0FBRTtHQUFPLE1BQU07RUFBSyxDQUFDO0VBRWxDLE1BQU0sT0FBTyxPQUFPLEtBQUssS0FBSztFQUM5QixJQUFJLE9BQU8seUJBQXlCLE9BQU8sMEJBQ3pDLE9BQU8sc0JBQXNCLEtBQUssQ0FBQyxDQUFDLFNBQVMsUUFBUTtHQUNuRCxNQUFNLGFBQWEsT0FBTyx5QkFBeUIsT0FBTyxHQUFHO0dBQzdELElBQUksY0FBYyxXQUFXLFlBQVksS0FBSyxLQUFLLEdBQUc7RUFDeEQsQ0FBQztFQUlILEtBQUssU0FBUyxRQUFRO0dBQ3BCLElBQUksUUFBUSxlQUFlLFFBQVEsaUJBQWlCLFFBQVEsYUFBYTtJQUN2RSxNQUFNLGFBQWEsT0FBTyx5QkFBeUIsT0FBTyxHQUFHO0lBQzdELElBQUksY0FBY0QsY0FBTSxXQUFXLFlBQVksT0FBTyxHQUNwRCxRQUFRLEtBQUssRUFBRSxPQUFPLFdBQVcsTUFBTSxDQUFDO0dBRTVDLE9BQ0UsUUFBUSxLQUFLLEVBQUUsT0FBTyxNQUFNLEtBQUssQ0FBQztFQUV0QyxDQUFDO0NBQ0g7QUFDRjs7QUMxQ0EsSUFBTSxtQkFBbUIsVUFBVyxpQkFBaUJFLGlCQUFlLEVBQUUsR0FBRyxNQUFNLElBQUk7QUFFbkYsSUFBTSxxQkFBcUIsVUFBVTtDQUNuQyxJQUFJLE9BQU8seUJBQXlCLE9BQU8sMEJBQ3pDLE9BQU8sT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE9BQ3hCLE9BQU8sc0JBQXNCLEtBQUssQ0FBQyxDQUFDLFFBQVEsV0FBVztFQUNyRCxNQUFNLGFBQWEsT0FBTyx5QkFBeUIsT0FBTyxNQUFNO0VBQ2hFLE9BQU8sY0FBYyxXQUFXO0NBQ2xDLENBQUMsQ0FDSDtDQUVGLE9BQU8sT0FBTyxLQUFLLEtBQUs7QUFDMUI7QUFJQSxTQUFTLFlBQVksR0FBRyxHQUFHO0NBQ3pCLE1BQU0sVUFBVSxDQUFDO0NBQ2pCLE1BQU0seUJBQVMsSUFBSSxRQUFRO0NBQzNCLE1BQU0sUUFBUSxDQUFDO0NBRWYsU0FBUyxLQUFLLFFBQVEsUUFBUTtFQUM1QixJQUFJLENBQUNDLGNBQU0sY0FBYyxNQUFNLEdBQzdCLE9BQU9BLGNBQU0sUUFBUSxNQUFNLElBQUksT0FBTyxNQUFNLElBQUk7RUFHbEQsTUFBTSxPQUFPQSxjQUFNLGNBQWMsTUFBTSxJQUFJLFNBQVM7RUFDcEQsSUFBSSxRQUFRLE9BQU8sSUFBSSxNQUFNO0VBQzdCLElBQUksQ0FBQyxPQUFPO0dBQ1Ysd0JBQVEsSUFBSSxRQUFRO0dBQ3BCLE9BQU8sSUFBSSxRQUFRLEtBQUs7RUFDMUI7RUFDQSxJQUFJLE1BQU0sSUFBSSxJQUFJLEdBQUcsT0FBTyxNQUFNLElBQUksSUFBSTtFQUUxQyxNQUFNLFNBQVMsQ0FBQztFQUNoQixNQUFNLElBQUksTUFBTSxNQUFNO0VBQ3RCLFFBQVEsS0FBSztHQUFFO0dBQU07R0FBUTtFQUFPLENBQUM7RUFDckMsT0FBTztDQUNUO0NBRUEsTUFBTSxTQUFTQSxjQUFNLFlBQVksQ0FBQyxJQUFJLEtBQUssS0FBQSxHQUFXLENBQUMsSUFBSSxLQUFLLEdBQUcsQ0FBQztDQUNwRSxPQUFPLFFBQVEsUUFBUTtFQUNyQixNQUFNLEVBQUUsTUFBTSxRQUFRLFFBQVEsV0FBVyxRQUFRLElBQUk7RUFDckQsTUFBTSxXQUFXLElBQUksSUFBSSxrQkFBa0IsSUFBSSxDQUFDO0VBQ2hELE1BQU0sYUFBYSxJQUFJLElBQUksa0JBQWtCLE1BQU0sQ0FBQztFQUdwRCxpQkFBQSxJQUZpQixJQUFJLENBQUMsR0FBRyxVQUFVLEdBQUcsVUFBVSxDQUU3QyxFQUFBLENBQUUsU0FBUyxRQUFRO0dBQ3BCLElBQUksUUFBUSxlQUFlLFFBQVEsaUJBQWlCLFFBQVEsYUFBYTtHQUN6RSxNQUFNLFlBQVksV0FBVyxJQUFJLEdBQUc7R0FDcEMsTUFBTSxRQUFRLFlBQVksT0FBTyxPQUFPLEtBQUE7R0FDeEMsTUFBTSxZQUNILENBQUMsYUFBYUEsY0FBTSxjQUFjLEtBQUssTUFBTSxTQUFTLElBQUksR0FBRyxJQUFJLEtBQUssT0FBTyxLQUFBO0dBQ2hGLE9BQU8sT0FBTyxZQUFZLEtBQUssVUFBVSxLQUFLLElBQUksS0FBSyxLQUFBLEdBQVcsUUFBUTtFQUM1RSxDQUFDO0NBQ0g7Q0FFQSxvQkFBb0IsTUFBTTtDQUMxQixPQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsUUFBUSxRQUFRLE1BQU0sVUFBVTtDQUN0RCxJQUFJQSxjQUFNLGNBQWMsTUFBTSxLQUFLQSxjQUFNLGNBQWMsTUFBTSxHQUMzRCxPQUFPQSxjQUFNLE1BQU0sS0FBSyxFQUFFLFNBQVMsR0FBRyxRQUFRLE1BQU07TUFDL0MsSUFBSUEsY0FBTSxjQUFjLE1BQU0sR0FDbkMsT0FBT0EsY0FBTSxNQUFNLENBQUMsR0FBRyxNQUFNO01BQ3hCLElBQUlBLGNBQU0sUUFBUSxNQUFNLEdBQzdCLE9BQU8sT0FBTyxNQUFNO0NBRXRCLE9BQU87QUFDVDtBQUVBLFNBQVMsb0JBQW9CLEdBQUcsR0FBRyxNQUFNLFVBQVU7Q0FDakQsSUFBSSxDQUFDQSxjQUFNLFlBQVksQ0FBQyxHQUN0QixPQUFPLGVBQWUsR0FBRyxHQUFHLE1BQU0sUUFBUTtNQUNyQyxJQUFJLENBQUNBLGNBQU0sWUFBWSxDQUFDLEdBQzdCLE9BQU8sZUFBZSxLQUFBLEdBQVcsR0FBRyxNQUFNLFFBQVE7QUFFdEQ7QUFHQSxTQUFTLGlCQUFpQixHQUFHLEdBQUc7Q0FDOUIsSUFBSSxDQUFDQSxjQUFNLFlBQVksQ0FBQyxHQUN0QixPQUFPLGVBQWUsS0FBQSxHQUFXLENBQUM7QUFFdEM7QUFHQSxTQUFTLGlCQUFpQixHQUFHLEdBQUc7Q0FDOUIsSUFBSSxDQUFDQSxjQUFNLFlBQVksQ0FBQyxHQUN0QixPQUFPLGVBQWUsS0FBQSxHQUFXLENBQUM7TUFDN0IsSUFBSSxDQUFDQSxjQUFNLFlBQVksQ0FBQyxHQUM3QixPQUFPLGVBQWUsS0FBQSxHQUFXLENBQUM7QUFFdEM7QUFFQSxTQUFTLDRCQUE0QixTQUFTLFNBQVMsTUFBTTtDQUMzRCxNQUFNLGdCQUFnQkEsY0FBTSxXQUFXLFNBQVMsY0FBYyxJQUMxRCxRQUFRLGVBQ1IsS0FBQTtDQUVKLElBQUksQ0FBQ0EsY0FBTSxZQUFZLGFBQWEsR0FBRztFQUNyQyxJQUFJQSxjQUFNLGNBQWMsYUFBYSxHQUMvQkE7T0FBQUEsY0FBTSxXQUFXLGVBQWUsSUFBSSxHQUN0QyxPQUFPLGNBQWM7RUFBQSxPQUd2QjtDQUVKO0NBRUEsTUFBTSxnQkFBZ0JBLGNBQU0sV0FBVyxTQUFTLGNBQWMsSUFDMUQsUUFBUSxlQUNSLEtBQUE7Q0FFSixJQUFJQSxjQUFNLGNBQWMsYUFBYSxLQUFLQSxjQUFNLFdBQVcsZUFBZSxJQUFJLEdBQzVFLE9BQU8sY0FBYztBQUl6QjtBQUdBLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRyxNQUFNLFNBQVMsU0FBUztDQUNyRCxJQUFJQSxjQUFNLFdBQVcsU0FBUyxJQUFJLEdBQ2hDLE9BQU8sZUFBZSxHQUFHLENBQUM7TUFDckIsSUFBSUEsY0FBTSxXQUFXLFNBQVMsSUFBSSxHQUN2QyxPQUFPLGVBQWUsS0FBQSxHQUFXLENBQUM7QUFFdEM7QUFFQSxTQUFTLGFBQWEsR0FBRyxHQUFHLE1BQU07Q0FDaEMsT0FBTyxvQkFBb0IsZ0JBQWdCLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUMvRTtBQUtBLElBQU0sMkJBQTJCLE9BQU8sT0FBTztDQUM3QyxXQUFXO0NBQ1gsT0FBTyxPQUFPLFVBQVU7Q0FDeEIsWUFBWTtDQUNaLFVBQVU7Q0FDVixjQUFjO0FBQ2hCLENBQUM7QUFLRCxJQUFNLFdBQVc7Q0FDZixLQUFLO0NBQ0wsUUFBUTtDQUNSLE1BQU07Q0FDTixTQUFTO0NBQ1Qsa0JBQWtCO0NBQ2xCLG1CQUFtQjtDQUNuQixRQUFRO0NBQ1Isa0JBQWtCO0NBQ2xCLFNBQVM7Q0FDVCxxQkFBcUI7Q0FDckIsaUJBQWlCO0NBQ2pCLGVBQWU7Q0FDZixTQUFTO0NBQ1QsY0FBYztDQUNkLGdCQUFnQjtDQUNoQixnQkFBZ0I7Q0FDaEIsa0JBQWtCO0NBQ2xCLG9CQUFvQjtDQUNwQixZQUFZO0NBQ1osa0JBQWtCO0NBQ2xCLGVBQWU7Q0FDZixnQkFBZ0I7Q0FDaEIsV0FBVztDQUNYLFdBQVc7Q0FDWCxZQUFZO0NBQ1osYUFBYTtDQUNiLFlBQVk7Q0FDWixvQkFBb0I7Q0FDcEIsa0JBQWtCO0NBQ2xCLGdCQUFnQjtDQUNoQixTQUFTO0FBQ1g7Ozs7Ozs7Ozs7QUFXQSxTQUF3QkMsY0FBWSxTQUFTLFNBQVM7Q0FFcEQsVUFBVSxXQUFXLENBQUM7Q0FDdEIsVUFBVSxXQUFXLENBQUM7Q0FNdEIsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJO0NBQ2pDLE9BQU8sZUFBZSxRQUFRLGtCQUFrQix3QkFBd0I7Q0FFeEUsTUFBTSxPQUFPLGtCQUFrQjtFQUFFLEdBQUc7RUFBUyxHQUFHO0NBQVEsQ0FBQztDQUV6RCxLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sS0FBSyxRQUFRLElBQUksS0FBSyxLQUFLO0VBQy9DLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLElBQUksU0FBUyxlQUFlLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtFQUM1RSxNQUFNLFFBQVFELGNBQU0sV0FBVyxVQUFVLElBQUksSUFBSSxTQUFTLFFBQVE7RUFDbEUsTUFBTSxJQUFJQSxjQUFNLFdBQVcsU0FBUyxJQUFJLElBQUksUUFBUSxRQUFRLEtBQUE7RUFDNUQsTUFBTSxJQUFJQSxjQUFNLFdBQVcsU0FBUyxJQUFJLElBQUksUUFBUSxRQUFRLEtBQUE7RUFDNUQsTUFBTSxjQUNKLFVBQVUsa0JBQWtCLE1BQU0sR0FBRyxHQUFHLE1BQU0sU0FBUyxPQUFPLElBQUksTUFBTSxHQUFHLEdBQUcsSUFBSTtFQUNwRixjQUFPLFlBQVksV0FBVyxLQUFLLFVBQVUsb0JBQXFCLE9BQU8sUUFBUTtDQUNuRjtDQUVBLElBQ0VBLGNBQU0sV0FBVyxTQUFTLGdCQUFnQixLQUMxQ0EsY0FBTSxZQUFZLFFBQVEsY0FBYyxLQUN4Qyw0QkFBNEIsU0FBUyxTQUFTLGlDQUFpQyxNQUFNLE9BQ3JGO0VBQ0EsSUFBSUEsY0FBTSxXQUFXLFNBQVMsZ0JBQWdCLEdBQzVDLE9BQU8saUJBQWlCLGVBQWUsS0FBQSxHQUFXLFFBQVEsY0FBYztPQUV4RSxPQUFPLE9BQU87Q0FFbEI7Q0FFQSxPQUFPO0FBQ1Q7O0FDMU9BLElBQU0sNEJBQTRCLENBQUMsZ0JBQWdCLGdCQUFnQjs7Ozs7Ozs7Ozs7O0FBYW5FLFNBQXdCLG1CQUFtQixTQUFTLGFBQWEsUUFBUTtDQUN2RSxJQUFJLFdBQVcsZ0JBQWdCO0VBQzdCLFFBQVEsSUFBSSxXQUFXO0VBQ3ZCO0NBQ0Y7Q0FFQSxPQUFPLFFBQVEsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLFNBQVM7RUFDeEQsSUFBSSwwQkFBMEIsU0FBUyxJQUFJLFlBQVksQ0FBQyxHQUN0RCxRQUFRLElBQUksS0FBSyxHQUFHO0NBRXhCLENBQUM7QUFDSDs7Ozs7Ozs7OztBQ1BBLElBQU1FLGdCQUFjLFFBQ2xCLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxRQUFRLHFCQUFxQixHQUFHLFFBQ3RELE9BQU8sYUFBYSxTQUFTLEtBQUssRUFBRSxDQUFDLENBQ3ZDO0FBRUYsSUFBTSxjQUFjLFNBQVNDLGdCQUFRLEtBQUssSUFBSTtBQUU5QyxTQUFTLGNBQWMsUUFBUSxpQkFBaUIsWUFBWTtDQUMxRCxNQUFNLFlBQVlDLGNBQVksQ0FBQyxHQUFHLE1BQU07Q0FJeEMsTUFBTSxPQUFPLFFBQVNDLGNBQU0sV0FBVyxXQUFXLEdBQUcsSUFBSSxVQUFVLE9BQU8sS0FBQTtDQUUxRSxNQUFNLE9BQU8sSUFBSSxNQUFNO0NBQ3ZCLElBQUksZ0JBQWdCLElBQUksZUFBZTtDQUN2QyxNQUFNLGlCQUFpQixJQUFJLGdCQUFnQjtDQUMzQyxNQUFNLGlCQUFpQixJQUFJLGdCQUFnQjtDQUMzQyxJQUFJLFVBQVUsSUFBSSxTQUFTO0NBQzNCLE1BQU0sT0FBTyxJQUFJLE1BQU07Q0FDdkIsTUFBTSxVQUFVLElBQUksU0FBUztDQUM3QixNQUFNLG9CQUFvQixJQUFJLG1CQUFtQjtDQUNqRCxNQUFNLE1BQU0sSUFBSSxLQUFLO0NBRXJCLFVBQVUsVUFBVSxVQUFVQyxlQUFhLEtBQUssT0FBTztDQUV2RCxVQUFVLE1BQU0sU0FDZCxjQUFjLFNBQVMsS0FBSyxtQkFBbUIsU0FBUyxHQUN4RCxJQUFJLFFBQVEsR0FDWixJQUFJLGtCQUFrQixDQUN4QjtDQUdBLElBQUksTUFBTTtFQUNSLE1BQU0sV0FBV0QsY0FBTSxZQUFZLE1BQU0sVUFBVSxLQUFLO0VBQ3hELE1BQU0sV0FBV0EsY0FBTSxZQUFZLE1BQU0sVUFBVSxLQUFLO0VBQ3hELE1BQU0sZUFBZSxJQUFJLGNBQWM7RUFDdkMsTUFBTSxpQkFDSixnQkFDQUEsY0FBTSxXQUFXLGNBQWMseUJBQXlCLEtBQ3hELGFBQWEsNEJBQTRCO0VBRTNDLElBQUk7R0FDRixRQUFRLElBQ04saUJBRUEsV0FDRSxNQUNHLGlCQUFpQkgsYUFBVyxRQUFRLElBQUksWUFDdkMsT0FDQyxXQUFXQSxhQUFXLFFBQVEsSUFBSSxHQUN2QyxDQUNKO0VBQ0YsU0FBUyxHQUFHO0dBQ1YsTUFBTUssYUFBVyxLQUFLLEdBQUdBLGFBQVcsc0JBQXNCLE1BQU07RUFDbEU7Q0FDRjtDQUVBLElBQUlGLGNBQU0sV0FBVyxJQUFJLEdBQUc7RUFDMUIsTUFBTSxhQUFhQSxjQUFNLFlBQVksTUFBTSxZQUFZO0VBRXZELElBQ0VHLGlCQUFTLHlCQUNUQSxpQkFBUyxrQ0FDVEgsY0FBTSxjQUFjLElBQUksR0FFeEIsUUFBUSxlQUFlLEtBQUEsQ0FBUztPQUMzQixJQUFJQSxjQUFNLFdBQVcsVUFBVSxHQUVwQyxtQkFBbUIsU0FBUyxXQUFXLEtBQUssSUFBSSxHQUFHLElBQUksc0JBQXNCLENBQUM7Q0FFbEY7Q0FNQSxJQUFJRyxpQkFBUyx1QkFBdUI7RUFDbEMsSUFBSUgsY0FBTSxXQUFXLGFBQWEsR0FDaEMsZ0JBQWdCLGNBQWMsU0FBUztFQVN6QyxJQUZFLGtCQUFrQixRQUFTLGlCQUFpQixRQUFRSSx3QkFBZ0IsVUFBVSxHQUFHLEdBRS9EO0dBQ2xCLE1BQU0sWUFBWSxrQkFBa0Isa0JBQWtCLGVBQWUsY0FBYztHQUVuRixJQUFJLFdBQ0YsUUFBUSxJQUFJLGdCQUFnQixTQUFTO0VBRXpDO0NBQ0Y7Q0FFQSxPQUFPO0FBQ1Q7QUNyR0EsSUFBQSxjQUY4QixPQUFPLG1CQUFtQixlQUd0RCxTQUFVLFFBQVE7Q0FDaEIsT0FBTyxJQUFJLFFBQVEsU0FBUyxtQkFBbUIsU0FBUyxRQUFRO0VBQzlELElBQUk7RUFDSixJQUFJO0dBQ0YsTUFBTSxRQUNKQyxpQkFBUyx5QkFBeUIsT0FBTyxXQUFXLGVBQWUsT0FBTztHQUM1RSxlQUFlLFNBQVNDLGNBQU0sV0FBVyxNQUFNLEdBQUc7RUFDcEQsU0FBUyxHQUFHLENBRVo7RUFDQSxJQUFJO0VBQ0osTUFBTSxVQUFVLGNBQ2QsUUFDQSxnQkFDSyxTQUFTO0dBQ1IsaUJBQWlCO0dBQ2pCLE9BQU87RUFDVCxJQUNBLEtBQUEsQ0FDTjtFQUNBLElBQUksY0FBYyxRQUFRO0VBQzFCLE1BQU0saUJBQWlCQyxlQUFhLEtBQUssUUFBUSxPQUFPLENBQUMsQ0FBQyxVQUFVO0VBQ3BFLElBQUksRUFBRSxjQUFjLGtCQUFrQix1QkFBdUI7RUFDN0QsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJLGlCQUFpQjtFQUNyQixJQUFJLGFBQWEsZUFBZTtFQUVoQyxTQUFTLE9BQU87R0FDZCxhQUFhLFNBQVM7R0FHdEIsSUFBSTtJQUNGLGVBQWUsWUFBWTtHQUM3QixTQUFTLEtBQUs7SUFDWixpQkFBaUI7S0FDZixNQUFNO0lBQ1IsQ0FBQztHQUNIO0dBQ0EsSUFBSTtJQUNGLGlCQUFpQixjQUFjO0dBQ2pDLFNBQVMsS0FBSztJQUNaLGlCQUFpQjtLQUNmLE1BQU07SUFDUixDQUFDO0dBQ0g7R0FJQSxJQUFJLFNBQVM7SUFDWCxxQkFBcUIsUUFBUSxvQkFBb0IsWUFBWSxpQkFBaUI7SUFDOUUsSUFBSSxRQUFRLFFBQVE7S0FDbEIsbUJBQW1CLFFBQVEsT0FBTyxvQkFBb0IsWUFBWSxlQUFlO0tBQ2pGLGVBQWUsUUFBUSxPQUFPLG9CQUFvQixXQUFXLFdBQVc7SUFDMUU7R0FDRjtHQUVBLFFBQVEsZUFBZSxRQUFRLFlBQVksWUFBWSxVQUFVO0dBRWpFLFFBQVEsVUFBVSxRQUFRLE9BQU8sb0JBQW9CLFNBQVMsVUFBVTtFQUMxRTtFQUVBLElBQUksVUFBVSxJQUFJLGVBQWU7RUFFakMsUUFBUSxLQUFLLFFBQVEsT0FBTyxZQUFZLEdBQUcsUUFBUSxLQUFLLElBQUk7RUFHNUQsUUFBUSxVQUFVLFFBQVE7RUFFMUIsU0FBUyxVQUFVLE9BQU87R0FDeEIsSUFBSSxDQUFDLFNBQ0g7R0FXRixJQUNFLFFBQVEsV0FBVyxNQUNsQixjQUFjLDZCQUE2QixRQUFRLEdBQUcsQ0FBQyxLQUN0RCxjQUFjRixpQkFBUyxNQUFNLE9BQU8sVUFDdEMsRUFBRSxRQUFRLGVBQWUsUUFBUSxZQUFZLFdBQVcsT0FBTyxJQUMvRDtJQUNBLE9BQU8sSUFBSUcsYUFBVyxtQkFBbUJBLGFBQVcsY0FBYyxRQUFRLE9BQU8sQ0FBQztJQUNsRixLQUFLO0lBR0wsVUFBVTtJQUNWO0dBQ0Y7R0FPQSxJQUFJO0lBQ0YsSUFBSSxPQUNGLDBCQUEwQix1QkFBdUIsS0FBSztTQUV0RCxpQkFBaUIsY0FBYztHQUVuQyxTQUFTLEtBQUs7SUFDWixpQkFBaUI7S0FDZixNQUFNO0lBQ1IsQ0FBQztHQUNIO0dBR0EsSUFBSSxDQUFDLFNBQ0g7R0FJRixNQUFNLGtCQUFrQkQsZUFBYSxLQUNuQywyQkFBMkIsV0FBVyxRQUFRLHNCQUFzQixDQUN0RTtHQWNBLE9BQ0UsU0FBUyxTQUFTLE9BQU87SUFDdkIsUUFBUSxLQUFLO0lBQ2IsS0FBSztHQUNQLEdBQ0EsU0FBUyxRQUFRLEtBQUs7SUFDcEIsT0FBTyxHQUFHO0lBQ1YsS0FBSztHQUNQLEdBQ0E7SUFqQkEsTUFKQSxDQUFDLGdCQUFnQixpQkFBaUIsVUFBVSxpQkFBaUIsU0FDekQsUUFBUSxlQUNSLFFBQVE7SUFHWixRQUFRLFFBQVE7SUFDaEIsWUFBWSxRQUFRO0lBQ3BCLFNBQVM7SUFDVDtJQUNBO0dBWUEsQ0FDRjtHQUdBLFVBQVU7RUFDWjtFQUVBLElBQUksZUFBZSxTQUVqQixRQUFRLFlBQVk7T0FHcEIsUUFBUSxxQkFBcUIsU0FBUyxhQUFhO0dBQ2pELElBQUksQ0FBQyxXQUFXLFFBQVEsZUFBZSxHQUNyQztHQU9GLElBQ0UsUUFBUSxXQUFXLEtBQ25CLEVBQUUsUUFBUSxlQUFlLFFBQVEsWUFBWSxXQUFXLE9BQU8sSUFFL0Q7R0FJRixXQUFXLFNBQVM7RUFDdEI7RUFJRixRQUFRLFVBQVUsU0FBUyxjQUFjO0dBQ3ZDLElBQUksQ0FBQyxTQUNIO0dBR0YsT0FBTyxJQUFJQyxhQUFXLG1CQUFtQkEsYUFBVyxjQUFjLFFBQVEsT0FBTyxDQUFDO0dBQ2xGLEtBQUs7R0FHTCxVQUFVO0VBQ1o7RUFHQSxRQUFRLFVBQVUsU0FBUyxZQUFZLE9BQU87R0FLNUMsTUFBTSxNQUFNLElBQUlBLGFBREosU0FBUyxNQUFNLFVBQVUsTUFBTSxVQUFVLGlCQUNyQkEsYUFBVyxhQUFhLFFBQVEsT0FBTztHQUV2RSxJQUFJLFFBQVEsU0FBUztHQUNyQixPQUFPLEdBQUc7R0FDVixLQUFLO0dBQ0wsVUFBVTtFQUNaO0VBR0EsUUFBUSxZQUFZLFNBQVMsZ0JBQWdCO0dBQzNDLElBQUksQ0FBQyxTQUFTO0dBQ2QsSUFBSSxzQkFBc0IsUUFBUSxVQUM5QixnQkFBZ0IsUUFBUSxVQUFVLGdCQUNsQztHQUNKLE1BQU0sZUFBZSxRQUFRLGdCQUFnQkM7R0FDN0MsSUFBSSxRQUFRLHFCQUNWLHNCQUFzQixRQUFRO0dBRWhDLE9BQ0UsSUFBSUQsYUFDRixxQkFDQSxhQUFhLHNCQUFzQkEsYUFBVyxZQUFZQSxhQUFXLGNBQ3JFLFFBQ0EsT0FDRixDQUNGO0dBQ0EsS0FBSztHQUdMLFVBQVU7RUFDWjtFQUdBLGdCQUFnQixLQUFBLEtBQWEsZUFBZSxlQUFlLElBQUk7RUFHL0QsSUFBSSxDQUFDRixjQUFNLFlBQVksUUFBUSxlQUFlLEdBQzVDLFFBQVEsa0JBQWtCLENBQUMsQ0FBQyxRQUFRO0VBSXRDLElBQUksZ0JBQWdCLGlCQUFpQixRQUNuQyxRQUFRLGVBQWUsUUFBUTtFQUlqQyxJQUFJLG9CQUFvQjtHQUN0QixDQUFDLG1CQUFtQixlQUFlLDBCQUEwQixxQkFDM0Qsb0JBQ0EsSUFDRjtHQUNBLFFBQVEsaUJBQWlCLFlBQVksaUJBQWlCO0VBQ3hEO0VBR0EsSUFBSSxvQkFBb0IsUUFBUSxRQUFRO0dBQ3RDLENBQUMsaUJBQWlCLGVBQWUscUJBQXFCLGdCQUFnQjtHQUV0RSxRQUFRLE9BQU8saUJBQWlCLFlBQVksZUFBZTtHQUUzRCxRQUFRLE9BQU8saUJBQWlCLFdBQVcsV0FBVztFQUN4RDtFQUVBLElBQUksUUFBUSxlQUFlLFFBQVEsUUFBUTtHQUd6QyxjQUFjLFdBQVc7SUFDdkIsSUFBSSxDQUFDLFNBQ0g7SUFFRixPQUFPLENBQUMsVUFBVSxPQUFPLE9BQU8sSUFBSUksZ0JBQWMsTUFBTSxRQUFRLE9BQU8sSUFBSSxNQUFNO0lBQ2pGLE1BQU0sTUFBTTtJQUNaLEtBQUs7SUFDTCxVQUFVO0lBQ1YsSUFBSSxNQUFNO0dBQ1o7R0FFQSxRQUFRLGVBQWUsUUFBUSxZQUFZLFVBQVUsVUFBVTtHQUMvRCxJQUFJLENBQUMsU0FBUztHQUNkLElBQUksUUFBUSxRQUNWLFFBQVEsT0FBTyxVQUNYLFdBQVcsSUFDWCxRQUFRLE9BQU8saUJBQWlCLFNBQVMsVUFBVTtFQUUzRDtFQUVBLElBQUksQ0FBQyxTQUFTO0VBRWQsTUFBTSxXQUFXLGNBQWMsUUFBUSxHQUFHO0VBRTFDLElBQUksWUFBWSxDQUFDTCxpQkFBUyxVQUFVLFNBQVMsUUFBUSxHQUFHO0dBQ3RELE9BQ0UsSUFBSUcsYUFDRiwwQkFBMEIsV0FBVyxLQUNyQ0EsYUFBVyxpQkFDWCxNQUNGLENBQ0Y7R0FDQSxLQUFLO0dBQ0w7RUFDRjtFQUVBLE1BQU0sb0JBQW9CO0dBQ3hCLElBQUksQ0FBQyxTQUFTO0dBR2QsSUFBSSxzQkFBc0IsU0FDeEIsY0FBTSxRQUNKLHlCQUF5QixjQUFjLEdBQ3ZDLFNBQVMsaUJBQWlCLEtBQUssS0FBSztJQUNsQyxRQUFRLGlCQUFpQixLQUFLLEdBQUc7R0FDbkMsQ0FDRjtHQUVGLFFBQVEsS0FBSyxlQUFlLElBQUk7RUFDbEM7RUFFQSxJQUFJLGdCQUFnQjtHQUdsQixNQUFNLE1BQ0osT0FBTyxnQkFBZ0IsZUFBZUYsY0FBTSxXQUFXLFlBQVksR0FBRyxVQUM1RCxZQUFZLElBQUksSUFDdEIsS0FBSztHQUNYLE1BQU0sV0FBVyxRQUFRLFVBQVUsSUFBSSxJQUFJLElBQUksT0FBTyxRQUFRLE9BQU8sSUFBSSxLQUFBO0dBQ3pFLE1BQU0sdUJBQXVCO0lBQzNCLElBQUksQ0FBQyxTQUFTO0lBQ2QsTUFBTSxNQUFNO0lBQ1osSUFBSSxVQUFVO0lBQ2QsSUFBSSxNQUFNO0dBQ1o7R0FDQSxJQUFJLGFBQWEsS0FBQSxHQUFXO0lBQzFCLE1BQU0sd0JBQXdCO0tBQzVCLE1BQU0sWUFBWSxXQUFXLElBQUk7S0FDakMsSUFBSSxZQUFZLEdBRWQsWUFBWSxXQUFXLGlCQUFpQixLQUFLLElBQUksV0FBVyxVQUFVLENBQUM7VUFFdkUsZUFBZTtJQUVuQjtJQUNBLGdCQUFnQjtHQUNsQjtHQUVBLGdCQUNHLFVBQVUsY0FBYyxDQUFDLENBQ3pCLE1BQU0sVUFBVTtJQUNmLElBQUksQ0FBQyxTQUFTO0lBRWQsSUFBSSxhQUFhLEtBQUEsS0FBYSxJQUFJLEtBQUssVUFBVTtLQUMvQyxlQUFlO0tBQ2Y7SUFDRjtJQUNBLElBQUksT0FBTztLQUNULE1BQU0sYUFDSkEsY0FBTSxXQUFXLFNBQVMsZ0JBQWdCLEtBQUssUUFBUTtLQUN6RCxlQUFlLElBQUksWUFBWSxLQUFLO0lBQ3RDO0lBQ0EsWUFBWTtHQUNkLENBQUMsQ0FBQyxDQUNELE9BQU8sVUFBVTtJQUNoQixJQUFJLENBQUMsU0FBUztJQUNkLE9BQU9FLGFBQVcsS0FBSyxPQUFPLE1BQU0sUUFBUSxPQUFPLENBQUM7SUFDcEQsS0FBSztJQUNMLFVBQVU7R0FDWixDQUFDO0VBQ0wsT0FDRSxZQUFZO0NBRWhCLENBQUM7QUFDSDs7QUMzWEYsSUFBTSxrQkFBa0IsU0FBUyxZQUFZO0NBQzNDLFVBQVUsVUFBVSxRQUFRLE9BQU8sT0FBTyxJQUFJLENBQUM7Q0FFL0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLFFBQ3ZCO0NBR0YsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0NBRXZDLElBQUksVUFBVTtDQUVkLE1BQU0sVUFBVSxTQUFVLFFBQVE7RUFDaEMsSUFBSSxDQUFDLFNBQVM7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLE1BQU0sTUFBTSxrQkFBa0IsUUFBUSxTQUFTLEtBQUs7R0FDcEQsV0FBVyxNQUNULGVBQWVHLGVBQ1gsTUFDQSxJQUFJQyxnQkFBYyxlQUFlLFFBQVEsSUFBSSxVQUFVLEdBQUcsQ0FDaEU7RUFDRjtDQUNGO0NBRUEsSUFBSSxRQUNGLFdBQ0EsaUJBQWlCO0VBQ2YsUUFBUTtFQUNSLFFBQVEsSUFBSUQsYUFBVyxjQUFjLFFBQVEsY0FBY0EsYUFBVyxTQUFTLENBQUM7Q0FDbEYsR0FBRyxPQUFPO0NBRVosTUFBTSxvQkFBb0I7RUFDeEIsSUFBSSxDQUFDLFNBQ0g7RUFFRixTQUFTLGFBQWEsS0FBSztFQUMzQixRQUFRO0VBQ1IsUUFBUSxTQUFTLFdBQVc7R0FDMUIsTUFBTSxvQkFBb0JFLGNBQU0sWUFBWSxRQUFRLGFBQWE7R0FDakUsY0FBTSxXQUFXLGlCQUFpQixJQUM5QixrQkFBa0IsS0FBSyxRQUFRLE9BQU8sSUFDdEMsT0FBTyxvQkFBb0IsU0FBUyxPQUFPO0VBQ2pELENBQUM7RUFDRCxVQUFVO0NBQ1o7Q0FFQSxRQUFRLFNBQVMsV0FBVztFQUMxQixJQUFJLFNBQ0Y7RUFHRixJQUFJLE9BQU8sU0FBUztHQUNsQixRQUFRLEtBQUssTUFBTTtHQUNuQjtFQUNGO0VBRUEsT0FBTyxpQkFBaUIsU0FBUyxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDMUQsQ0FBQztDQUVELE1BQU0sRUFBRSxXQUFXO0NBRW5CLE9BQU8sb0JBQW9CQSxjQUFNLEtBQUssV0FBVztDQUVqRCxPQUFPO0FBQ1Q7O0FDcEVBLElBQWEsY0FBYyxXQUFXLE9BQU8sV0FBVztDQUN0RCxJQUFJLE1BQU0sTUFBTTtDQUVoQixJQUFJLENBQUMsYUFBYSxNQUFNLFdBQVc7RUFDakMsTUFBTTtFQUNOO0NBQ0Y7Q0FFQSxJQUFJLE1BQU07Q0FDVixJQUFJO0NBRUosT0FBTyxNQUFNLEtBQUs7RUFDaEIsTUFBTSxNQUFNO0VBQ1osTUFBTSxNQUFNLE1BQU0sS0FBSyxHQUFHO0VBQzFCLE1BQU07Q0FDUjtBQUNGO0FBRUEsSUFBYSxZQUFZLGlCQUFpQixVQUFVLFdBQVc7Q0FDN0QsV0FBVyxNQUFNLFNBQVMsV0FBVyxRQUFRLEdBQzNDLE9BQU8sWUFBWSxPQUFPLFNBQVM7QUFFdkM7QUFFQSxJQUFNLGFBQWEsaUJBQWlCLFFBQVE7Q0FDMUMsSUFBSSxPQUFPLE9BQU8sZ0JBQWdCO0VBQ2hDLE9BQU87RUFDUDtDQUNGO0NBRUEsTUFBTSxTQUFTLE9BQU8sVUFBVTtDQUNoQyxJQUFJO0VBQ0YsU0FBUztHQUNQLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxPQUFPLEtBQUs7R0FDMUMsSUFBSSxNQUNGO0dBRUYsTUFBTTtFQUNSO0NBQ0YsVUFBVTtFQUNSLE1BQU0sT0FBTyxPQUFPO0NBQ3RCO0FBQ0Y7QUFFQSxJQUFhLGVBQWUsUUFBUSxXQUFXLFlBQVksYUFBYTtDQUN0RSxNQUFNLFdBQVcsVUFBVSxRQUFRLFNBQVM7Q0FFNUMsSUFBSSxRQUFRO0NBQ1osSUFBSTtDQUNKLElBQUksYUFBYSxNQUFNO0VBQ3JCLElBQUksQ0FBQyxNQUFNO0dBQ1QsT0FBTztHQUNQLFlBQVksU0FBUyxDQUFDO0VBQ3hCO0NBQ0Y7Q0FFQSxPQUFPLElBQUksZUFDVDtFQUNFLE1BQU0sS0FBSyxZQUFZO0dBQ3JCLElBQUk7SUFDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLO0lBRTVDLElBQUksTUFBTTtLQUNSLFVBQVU7S0FDVixXQUFXLE1BQU07S0FDakI7SUFDRjtJQUVBLElBQUksTUFBTSxNQUFNO0lBQ2hCLElBQUksWUFFRixXQUFXLFNBRGlCLEdBQ047SUFFeEIsV0FBVyxRQUFRLElBQUksV0FBVyxLQUFLLENBQUM7R0FDMUMsU0FBUyxLQUFLO0lBQ1osVUFBVSxHQUFHO0lBQ2IsTUFBTTtHQUNSO0VBQ0Y7RUFDQSxPQUFPLFFBQVE7R0FDYixVQUFVLE1BQU07R0FDaEIsT0FBTyxTQUFTLE9BQU87RUFDekI7Q0FDRixHQUNBLEVBQ0UsZUFBZSxFQUNqQixDQUNGO0FBQ0Y7O0FDdEZBLElBQU0sT0FBTztBQUNiLElBQU0sa0JBQWtCLFVBQVUsT0FBTyxLQUFLLENBQUMsQ0FBQyxRQUFRLGVBQWUsSUFBSTtBQUMzRSxJQUFNLGNBQWMsVUFDbEIsT0FBTyxLQUFLLENBQUMsQ0FBQyxRQUFRLGFBQWEsU0FDakMsU0FBUyxPQUFPLFFBQVEsU0FBUyxPQUFPLFFBQVEsS0FDbEQ7QUFJRixJQUFNLGVBQWUsT0FBTyxjQUFjO0NBQ3hDLElBQUksU0FBUztDQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztFQUNyQyxNQUFNLE9BQU8sTUFBTSxXQUFXLENBQUM7RUFDL0IsSUFBSSxjQUFjLFNBQVMsTUFBTSxTQUFTLEtBQUs7R0FDN0MsSUFBSSxTQUFTLE1BQU0sTUFBTSxXQUFXLElBQUksQ0FBQyxNQUFNLElBQUk7R0FDbkQsVUFBVTtFQUNaLE9BQU8sSUFBSSxPQUFPLEtBQ2hCO09BQ0ssSUFBSSxPQUFPLE1BQ2hCLFVBQVU7T0FDTCxJQUNMLFFBQVEsU0FDUixRQUFRLFNBQ1IsTUFBTSxXQUFXLElBQUksQ0FBQyxLQUFLLFNBQzNCLE1BQU0sV0FBVyxJQUFJLENBQUMsS0FBSyxPQUMzQjtHQUNBLFVBQVU7R0FDVjtFQUNGLE9BQ0UsVUFBVTtDQUVkO0NBQ0EsT0FBTztBQUNUO0FBR0EsSUFBYSxnQkFBYixjQUFtQyxVQUFVO0NBQzNDLFlBQVksU0FBUyxRQUFRO0VBQzNCLE1BQU0sT0FBTztFQUNiLEtBQUssT0FBTztFQUNaLEtBQUssU0FBUztDQUNoQjtBQUNGO0FBR0EsU0FBd0IsZUFBZSxNQUFNLE1BQU0sT0FBTyxZQUFZLFVBQVU7Q0FDOUUsSUFBSSxDQUFDQyxjQUFNLFdBQVcsSUFBSSxHQUN4QixNQUFNLElBQUksY0FBYyx5QkFBeUIsTUFBTTtDQUd6RCxJQUNFLENBQUNBLGNBQU0sU0FBUyxRQUFRLEtBQ3hCLENBQUMsbUNBQW1DLEtBQUssUUFBUSxLQUNqRCxLQUFLLEtBQUssUUFBUSxHQUVsQixNQUFNLElBQUksY0FBYyw4QkFBOEIsVUFBVTtDQUVsRSxNQUFNLFNBQVMsT0FBTyxXQUFXO0NBQ2pDLElBQUksU0FBUyxPQUFPO0NBQ3BCLE1BQU0sUUFBUSxDQUFDO0NBQ2YsTUFBTSxlQUFlLFVBQVU7RUFDN0IsSUFBSSxTQUFTLFFBQVEsT0FBTyxNQUFNLFdBQVc7Q0FDL0M7Q0FDQSxZQUFZLENBQUM7Q0FFYixLQUFLLE1BQU0sQ0FBQyxNQUFNLFVBQVUsTUFBTTtFQUNoQyxNQUFNLFdBQVdBLGNBQU0sU0FBUyxLQUFLO0VBQ3JDLE1BQU0sY0FBYyxXQUFXLFlBQVksT0FBTyxJQUFJLElBQUksTUFBTTtFQUNoRSxJQUFJLENBQUMsT0FBTyxTQUFTLFdBQVcsS0FBSyxjQUFjLEdBQ2pELE1BQU0sSUFBSSxjQUFjLGtDQUFrQyxNQUFNO0VBR2xFLFlBQ0UsY0FDRSxZQUFZLE1BQU0sSUFBSSxLQUNyQixDQUFDLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxNQUFNLEtBQUssSUFBSSxNQUMzRCxDQUFDLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxNQUFNLEtBQUssSUFBSSxFQUNoRTtFQUVBLElBQUksU0FDRixPQUNBLFdBQ0EsZ0RBRUEsV0FBVyxlQUFlLElBQUksQ0FBQyxJQUMvQjtFQUNGLElBQUksQ0FBQyxVQUNILFVBQ0Usa0JBQ0EsV0FBV0EsY0FBTSxTQUFTLE1BQU0sSUFBSSxJQUFJLE1BQU0sT0FBTyxNQUFNLElBQzNELHlCQUdBLE9BQU8sTUFBTSxRQUFRLDBCQUEwQixDQUFDLENBQUMsUUFBUSxXQUFXLEVBQUU7RUFFMUUsVUFBVTtFQUNWLE1BQU0sYUFBYSxZQUFZLFFBQVEsS0FBSyxJQUFJLGNBQWM7RUFDOUQsWUFBWSxVQUFVO0VBQ3RCLFVBQVU7RUFDVixNQUFNLEtBQUs7R0FBRTtHQUFRO0dBQU87RUFBUyxDQUFDO0NBQ3hDO0NBSUEsTUFBTSxZQUFZLENBQUM7Q0FDbkIsS0FBSyxNQUFNLFFBQVEsT0FDakIsVUFBVSxLQUFLLEtBQUssUUFBUSxLQUFLLFdBQVcsZUFBZSxLQUFLLEtBQUssSUFBSSxLQUFLLE9BQU8sSUFBSTtDQUUzRixVQUFVLEtBQUssTUFBTTtDQUNyQixPQUFPLElBQUksS0FBSyxXQUFXLEVBQUUsTUFBTSxtQ0FBbUMsU0FBUyxDQUFDO0FBQ2xGOztBQzNHQSxTQUF3QixvQkFBb0IsTUFBTSxNQUFNLE9BQU8sWUFBWSxVQUFVO0NBRW5GLElBQUksQ0FBQ0MsY0FBTSxXQUFXLElBQUksR0FDeEIsTUFBTSxJQUFJQyxhQUFXLHlCQUF5QkEsYUFBVyxlQUFlO0NBRzFFLElBQUksYUFBYSxLQUFBLEdBQVc7RUFDMUIsSUFBSUQsY0FBTSxXQUFXRSxpQkFBUyxjQUFjLEdBQzFDLFdBQVcsV0FBV0EsaUJBQVMsZUFBZSxJQUFJLGtCQUFrQjtPQUMvRDtHQUNMLE1BQU0sU0FBU0YsY0FBTSxPQUFPO0dBQzVCLElBQUksQ0FBQyxVQUFVLENBQUNBLGNBQU0sV0FBVyxPQUFPLGVBQWUsR0FDckQsTUFBTSxJQUFJQyxhQUFXLDJDQUEyQ0EsYUFBVyxlQUFlO0dBRTVGLE1BQU0seUJBQVMsSUFBSSxXQUFXLEVBQUU7R0FDaEMsT0FBTyxnQkFBZ0IsTUFBTTtHQUM3QixXQUNFLFdBQVcsTUFBTSxLQUFLLFNBQVMsV0FBVyxNQUFNLE1BQU0sU0FBUyxFQUFFLEVBQUEsQ0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO0VBQzFGO0NBQ0Y7Q0FFQSxJQUFJO0VBQ0YsT0FBTyxlQUFlLE1BQU0sTUFBTSxPQUFPLFlBQVksUUFBUTtDQUMvRCxTQUFTLE9BQU87RUFDZCxJQUFJLGlCQUFpQixlQUFlO0dBQ2xDLE1BQU0sT0FDSixNQUFNLFdBQVcsYUFBYUEsYUFBVyx1QkFBdUJBLGFBQVc7R0FDN0UsTUFBTSxJQUFJQSxhQUFXLE1BQU0sU0FBUyxJQUFJO0VBQzFDO0VBQ0EsTUFBTTtDQUNSO0FBQ0Y7Ozs7Ozs7OztBQzdCQSxJQUFNLGNBQWMsYUFDakIsWUFBWSxNQUFNLFlBQVksTUFDOUIsWUFBWSxNQUFNLFlBQVksTUFDOUIsWUFBWSxNQUFNLFlBQVk7QUFFakMsSUFBTSx3QkFBd0IsS0FBSyxHQUFHLFFBQ3BDLElBQUksSUFBSSxPQUFPLFdBQVcsSUFBSSxXQUFXLElBQUksQ0FBQyxDQUFDLEtBQUssV0FBVyxJQUFJLFdBQVcsSUFBSSxDQUFDLENBQUM7QUFFdEYsSUFBTSxZQUFZLGFBQWMsWUFBWSxLQUFLLFdBQVcsTUFBTSxXQUFXLE9BQVE7QUFFckYsSUFBTSxnQkFBZ0IsYUFDbkIsWUFBWSxNQUFNLFlBQVksTUFDOUIsWUFBWSxNQUFNLFlBQVksT0FDOUIsWUFBWSxNQUFNLFlBQVksTUFDL0IsYUFBYSxNQUNiLGFBQWEsTUFDYixhQUFhLE1BQ2IsYUFBYTtBQUVmLElBQU0sc0JBQXNCLGFBQzFCLGFBQWEsS0FBSyxhQUFhLE1BQU0sYUFBYSxNQUFNLGFBQWEsTUFBTSxhQUFhO0FBRTFGLElBQU0sZUFBZSxnQkFBZ0I7Q0FDbkMsTUFBTSxTQUFTLEtBQUssTUFBTSxjQUFjLENBQUM7Q0FDekMsTUFBTSxZQUFZLGNBQWM7Q0FDaEMsT0FBTyxTQUFTLEtBQUssY0FBYyxJQUFJLElBQUksY0FBYyxJQUFJLElBQUk7QUFDbkU7QUFJQSxJQUFNLGtDQUFrQyxTQUFTO0NBQy9DLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLElBQUksVUFBVTtDQUVkLElBQUksTUFBTSxLQUFLLEtBQUssV0FBVyxNQUFNLENBQUMsTUFBTSxJQUFjO0VBQ3hEO0VBRUEsSUFBSSxNQUFNLEtBQUssS0FBSyxXQUFXLE1BQU0sQ0FBQyxNQUFNLElBQzFDO0NBRUo7Q0FFQSxPQUFPLEtBQUssT0FBUSxNQUFNLFdBQVcsSUFBSyxDQUFDO0FBQzdDO0FBMkJBLElBQU0scUNBQXFDLFNBQVM7Q0FDbEQsTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSSxjQUFjO0NBQ2xCLElBQUksVUFBVTtDQUNkLElBQUksVUFBVTtDQUVkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7RUFDNUIsSUFBSSxPQUFPLEtBQUssV0FBVyxDQUFDO0VBRTVCLElBQUksU0FBUyxNQUFnQixxQkFBcUIsTUFBTSxHQUFHLEdBQUcsR0FBRztHQUMvRCxPQUFPLFNBQVMsS0FBSyxXQUFXLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxTQUFTLEtBQUssV0FBVyxJQUFJLENBQUMsQ0FBQztHQUM5RSxLQUFLO0VBQ1A7RUFFQSxJQUFJLG1CQUFtQixJQUFJLEdBQ3pCO0VBR0YsSUFBSSxTQUFTLElBQWM7R0FDekI7R0FDQTtFQUNGO0VBRUEsSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLFVBQVUsR0FBRztHQUN0QyxVQUFVO0dBQ1Y7RUFDRjtFQUVBO0NBQ0Y7Q0FJQSxJQUNFLFdBQ0EsVUFBVSxLQUNULFVBQVUsTUFBTSxjQUFjLFdBQVcsTUFBTSxLQUNoRCxjQUFjLE1BQU0sR0FFcEIsT0FBTywrQkFBK0IsSUFBSTtDQUc1QyxPQUFPLFlBQVksV0FBVztBQUNoQztBQUVBLElBQU0sd0JBQXdCLEtBQUssZ0JBQWdCLGtCQUFrQjtDQUNuRSxJQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsVUFBVSxPQUFPO0NBQzVDLElBQUksQ0FBQyxVQUFVLEtBQUssR0FBRyxHQUFHLE9BQU87Q0FFakMsTUFBTSxRQUFRLElBQUksUUFBUSxHQUFHO0NBQzdCLElBQUksUUFBUSxHQUFHLE9BQU87Q0FFdEIsTUFBTSxPQUFPLElBQUksTUFBTSxHQUFHLEtBQUs7Q0FDL0IsTUFBTSxPQUFPLElBQUksTUFBTSxRQUFRLENBQUM7Q0FHaEMsSUFGaUIsY0FBYyxLQUFLLElBRXpCLEdBQ1QsT0FBTyxlQUFlLElBQUk7Q0FPNUIsSUFBSSxRQUFRO0NBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLEtBQUssUUFBUSxJQUFJLEtBQUssS0FBSztFQUMvQyxNQUFNLElBQUksS0FBSyxXQUFXLENBQUM7RUFDM0IsSUFBSSxNQUFNLE1BQWdCLHFCQUFxQixNQUFNLEdBQUcsR0FBRyxHQUFHO0dBQzVELFNBQVM7R0FDVCxLQUFLO0VBQ1AsT0FBTyxJQUFJLElBQUksS0FDYixTQUFTO09BQ0osSUFBSSxJQUFJLE1BQ2IsU0FBUztPQUNKLElBQUksS0FBSyxTQUFVLEtBQUssU0FBVSxJQUFJLElBQUksS0FBSztHQUNwRCxNQUFNLE9BQU8sS0FBSyxXQUFXLElBQUksQ0FBQztHQUNsQyxJQUFJLFFBQVEsU0FBVSxRQUFRLE9BQVE7SUFDcEMsU0FBUztJQUNUO0dBQ0YsT0FDRSxTQUFTO0VBRWIsT0FDRSxTQUFTO0NBRWI7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7QUFRQSxTQUF3Qiw0QkFBNEIsS0FBSztDQUV2RCxNQUFNLGdCQUFnQixPQUFPLFFBQVEsV0FBVyxJQUFJLFFBQVEsR0FBRyxJQUFJO0NBRW5FLE9BQU8scUJBQ0wsa0JBQWtCLEtBQUssTUFBTSxJQUFJLE1BQU0sR0FBRyxhQUFhLEdBQ3ZELG1DQUNBLHlCQUNGO0FBQ0Y7O0FDckxBLElBQWFFLFlBQVU7O0FDa0J2QixJQUFNLHFCQUFxQjtBQUUzQixJQUFNLDBCQUEwQjtDQUM5QixPQUFPO0NBQ1AsVUFBVTtDQUNWLFVBQVU7Q0FDVixnQkFBZ0I7Q0FDaEIsTUFBTTtDQUNOLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsVUFBVTtDQUNWLFFBQVE7QUFDVjtBQUVBLElBQU0sRUFBRSxlQUFlQzs7Ozs7Ozs7O0FBVXZCLElBQU0sY0FBYyxRQUNsQixtQkFBbUIsR0FBRyxDQUFDLENBQUMsUUFBUSxxQkFBcUIsR0FBRyxRQUN0RCxPQUFPLGFBQWEsU0FBUyxLQUFLLEVBQUUsQ0FBQyxDQUN2QztBQU1GLElBQU0sMEJBQTBCLFVBQVU7Q0FDeEMsSUFBSSxDQUFDQSxjQUFNLFNBQVMsS0FBSyxHQUN2QixPQUFPO0NBR1QsSUFBSTtFQUNGLE9BQU8sbUJBQW1CLEtBQUs7Q0FDakMsU0FBUyxPQUFPO0VBQ2QsT0FBTztDQUNUO0FBQ0Y7QUFFQSxJQUFNLFFBQVEsSUFBSSxHQUFHLFNBQVM7Q0FDNUIsSUFBSTtFQUNGLE9BQU8sQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJO0NBQ3JCLFNBQVMsR0FBRztFQUNWLE9BQU87Q0FDVDtBQUNGO0FBRUEsSUFBTSw0QkFBNEIsUUFBUTtDQUN4QyxNQUFNLGdCQUFnQixJQUFJLFFBQVEsS0FBSztDQUN2QyxJQUFJLGFBQWE7Q0FDakIsSUFBSSxrQkFBa0IsSUFDcEIsYUFBYSxXQUFXLE1BQU0sZ0JBQWdCLENBQUM7Q0FFakQsT0FBTyxXQUFXLFNBQVMsR0FBRyxLQUFLLFdBQVcsU0FBUyxHQUFHO0FBQzVEO0FBRUEsSUFBTSxXQUFXLFFBQVE7Q0FDdkIsTUFBTSxlQUNKQSxjQUFNLFdBQVcsS0FBQSxLQUFhQSxjQUFNLFdBQVcsT0FBT0EsY0FBTSxTQUFTO0NBQ3ZFLE1BQU0sRUFBRSxnQkFBZ0IsZ0JBQWdCO0NBRXhDLE1BQU1BLGNBQU0sTUFBTSxLQUNoQixFQUNFLGVBQWUsS0FDakIsR0FDQTtFQUNFLFNBQVMsYUFBYTtFQUN0QixVQUFVLGFBQWE7RUFDdkIsTUFBTSxhQUFhO0NBQ3JCLEdBQ0EsR0FDRjtDQUVBLE1BQU0sV0FBV0EsY0FBTSxXQUFXLEtBQUssT0FBTyxJQUFJLElBQUksUUFBUSxLQUFBO0NBQzlELE1BQU0sRUFBRSxTQUFTLFVBQVUsU0FBUztDQUNwQyxNQUFNLG1CQUFtQixXQUFXLFdBQVcsUUFBUSxJQUFJLE9BQU8sVUFBVTtDQUM1RSxNQUFNLHFCQUFxQixXQUFXLE9BQU87Q0FDN0MsTUFBTSxzQkFBc0IsV0FBVyxRQUFRO0NBRS9DLElBQUksQ0FBQyxrQkFDSCxPQUFPO0NBR1QsTUFBTSw0QkFBNEIsb0JBQW9CLFdBQVcsY0FBYztDQUUvRSxNQUFNLGFBQ0oscUJBQ0MsT0FBTyxnQkFBZ0IsZUFFakIsYUFBYSxRQUNaLFFBQVEsT0FBTyxHQUFHLEVBQUEsQ0FDcEIsSUFBSSxZQUFZLENBQUMsSUFDbkIsT0FBTyxRQUFRLElBQUksV0FBVyxNQUFNLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUM7Q0FFeEUsTUFBTSx3QkFDSixzQkFDQSw2QkFDQSxXQUFXO0VBQ1QsSUFBSSxpQkFBaUI7RUFFckIsTUFBTSxVQUFVLElBQUksUUFBUUMsaUJBQVMsUUFBUTtHQUMzQyxNQUFNLElBQUksZUFBZTtHQUN6QixRQUFRO0dBQ1IsSUFBSSxTQUFTO0lBQ1gsaUJBQWlCO0lBQ2pCLE9BQU87R0FDVDtFQUNGLENBQUM7RUFFRCxNQUFNLGlCQUFpQixRQUFRLFFBQVEsSUFBSSxjQUFjO0VBRXpELElBQUksUUFBUSxRQUFRLE1BQ2xCLFFBQVEsS0FBSyxPQUFPO0VBR3RCLE9BQU8sa0JBQWtCLENBQUM7Q0FDNUIsQ0FBQztDQUVILE1BQU0seUJBQ0osdUJBQ0EsNkJBQ0EsV0FBV0QsY0FBTSxpQkFBaUIsSUFBSSxTQUFTLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQztDQUkxRCxNQUFNLGtCQUFrQixPQUFPLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRyx1QkFBdUI7Q0FFbEYsSUFBSSxzQkFBc0IsQ0FBQyxXQUFXLElBQUksUUFBUUMsaUJBQVMsUUFBUSxlQUFlLENBQUMsR0FBRztFQUNwRixPQUFPLGdCQUFnQjtFQUl2QixJQUFJLENBQUMsV0FBVyxJQUFJLFFBQVFBLGlCQUFTLFFBQVEsZUFBZSxDQUFDLEdBQzNELGdCQUFnQixRQUFRLHdCQUF3QjtDQUVwRDtDQUVBLE1BQU0sWUFBWSxFQUNoQixRQUFRLDRCQUE0QixRQUFRLElBQUksTUFDbEQ7Q0FFQSwyQkFDUztFQUNMO0dBQUM7R0FBUTtHQUFlO0dBQVE7R0FBWTtFQUFRLENBQUMsQ0FBQyxTQUFTLFNBQVM7R0FDdEUsQ0FBQyxVQUFVLFVBQ1IsVUFBVSxTQUFTLEtBQUssV0FBVztJQUNsQyxJQUFJLFNBQVMsT0FBTyxJQUFJO0lBRXhCLElBQUksUUFDRixPQUFPLE9BQU8sS0FBSyxHQUFHO0lBR3hCLE1BQU0sSUFBSUMsYUFDUixrQkFBa0IsS0FBSyxxQkFDdkJBLGFBQVcsaUJBQ1gsTUFDRjtHQUNGO0VBQ0osQ0FBQztDQUNILEVBQUEsQ0FBRztDQUVMLE1BQU0sZ0JBQWdCLE9BQU8sU0FBUztFQUNwQyxJQUFJLFFBQVEsTUFDVixPQUFPO0VBR1QsSUFBSUYsY0FBTSxPQUFPLElBQUksR0FDbkIsT0FBTyxLQUFLO0VBR2QsSUFBSUEsY0FBTSxrQkFBa0IsSUFBSSxLQUFLQSxjQUFNLGNBQWMsSUFBSSxHQUMzRCxPQUFPLEtBQUs7RUFHZCxJQUFJQSxjQUFNLGtCQUFrQixJQUFJLEdBQzlCLE9BQU8sT0FBTztFQUdoQixJQUFJQSxjQUFNLFNBQVMsSUFBSSxHQUNyQixRQUFRLE1BQU0sV0FBVyxJQUFJLEVBQUEsQ0FBRztDQUVwQztDQUVBLE1BQU0sb0JBQW9CLE9BQU8sU0FBUyxTQUFTO0VBQ2pELE1BQU0sU0FBU0EsY0FBTSxlQUFlLFFBQVEsaUJBQWlCLENBQUM7RUFFOUQsT0FBTyxVQUFVLE9BQU8sY0FBYyxJQUFJLElBQUk7Q0FDaEQ7Q0FFQSxPQUFPLE9BQU8sV0FBVztFQUN2QixJQUFJLEVBQ0YsS0FDQSxRQUNBLE1BQ0EsUUFDQSxhQUNBLFNBQ0Esb0JBQ0Esa0JBQ0EsY0FDQSxTQUNBLGtCQUFrQixlQUNsQixjQUNBLGtCQUNBLGVBQ0EsaUJBQ0UsY0FBYyxNQUFNO0VBRXhCLE1BQU0sc0JBQXNCQSxjQUFNLFNBQVMsZ0JBQWdCLEtBQUssbUJBQW1CO0VBQ25GLE1BQU0sbUJBQW1CQSxjQUFNLFNBQVMsYUFBYSxLQUFLLGdCQUFnQjtFQUMxRSxNQUFNLE9BQU8sUUFBU0EsY0FBTSxXQUFXLFFBQVEsR0FBRyxJQUFJLE9BQU8sT0FBTyxLQUFBO0VBRXBFLElBQUksU0FBUyxZQUFZO0VBRXpCLGVBQWUsZ0JBQWdCLGVBQWUsR0FBQSxDQUFJLFlBQVksSUFBSTtFQUVsRSxJQUFJLGlCQUFpQixlQUNuQixDQUFDLFFBQVEsZUFBZSxZQUFZLGNBQWMsQ0FBQyxHQUNuRCxPQUNGO0VBRUEsSUFBSSxVQUFVO0VBRWQsTUFBTSxjQUNKLGtCQUNBLGVBQWUsc0JBQ1I7R0FDTCxlQUFlLFlBQVk7RUFDN0I7RUFFRixJQUFJO0VBTUosSUFBSSxtQkFBbUI7RUFDdkIsSUFBSSx1QkFBdUI7RUFFM0IsTUFBTSwyQkFDSixJQUFJRSxhQUNGLGdEQUNBQSxhQUFXLGlCQUNYLFFBQ0EsT0FDRjtFQUVGLElBQUk7R0FFRixJQUFJLE9BQU8sS0FBQTtHQUNYLE1BQU0sYUFBYSxJQUFJLE1BQU07R0FFN0IsSUFBSSxZQUdGLE9BQU87SUFDTCxVQUhlRixjQUFNLFlBQVksWUFBWSxVQUFVLEtBQUs7SUFJNUQsVUFIZUEsY0FBTSxZQUFZLFlBQVksVUFBVSxLQUFLO0dBSTlEO0dBR0YsSUFBSTtHQUNKLElBQUkseUJBQXlCLEdBQUcsR0FBRztJQUNqQyxZQUFZLElBQUksSUFBSSxLQUFLQyxpQkFBUyxNQUFNO0lBRXhDLElBQUksQ0FBQyxTQUFTLFVBQVUsWUFBWSxVQUFVLFdBRzVDLE9BQU87S0FDTCxVQUhrQix1QkFBdUIsVUFBVSxRQUcvQjtLQUNwQixVQUhrQix1QkFBdUIsVUFBVSxRQUcvQjtJQUN0QjtJQUdGLElBQUksVUFBVSxZQUFZLFVBQVUsVUFBVTtLQUM1QyxVQUFVLFdBQVc7S0FDckIsVUFBVSxXQUFXO0tBQ3JCLE1BQU0sVUFBVTtJQUNsQjtHQUNGO0dBRUEsSUFBSSxNQUFNO0lBQ1IsUUFBUSxPQUFPLGVBQWU7SUFDOUIsUUFBUSxJQUNOLGlCQUNBLFdBQVcsS0FBSyxZQUFZLEtBQUssWUFBWSxNQUFNLE9BQU8sS0FBSyxZQUFZLEdBQUcsQ0FBQyxDQUNqRjtHQUNGO0dBS0EsSUFBSSx1QkFBdUIsYUFBYSxVQUFVLGFBQWEsU0FDM0M7UUFBQSw0QkFBNEIsVUFBVSxJQUM1QyxJQUFJLGtCQUNkLE1BQU0sSUFBSUMsYUFDUiw4QkFBOEIsbUJBQW1CLGFBQ2pEQSxhQUFXLGtCQUNYLFFBQ0EsT0FDRjtHQUFBO0dBSUosTUFBTSxrQkFDSkYsY0FBTSxvQkFBb0IsSUFBSSxLQUFLRyxlQUFhLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLGVBQWU7R0FDdEYsSUFBSTtHQUNKLElBQ0VILGNBQU0sU0FBUyxlQUFlLEtBQzlCLG1DQUFtQyxLQUFLLGdCQUFnQixLQUFLLENBQUMsR0FDOUQ7SUFDQSxNQUFNLGFBQWFHLGVBQWEsZ0JBQWdCLGVBQWU7SUFDL0QsSUFBSUgsY0FBTSxXQUFXLFlBQVksVUFBVSxHQUFHLGVBQWUsV0FBVztHQUMxRTtHQUVBLElBQ0VBLGNBQU0sb0JBQW9CLElBQUksS0FDOUIsV0FBVyxTQUNYLFdBQVcsV0FDVixvQkFDRSxvQkFBb0IseUJBQ3JCLGlCQUFpQixLQUFBLElBQ25CO0lBQ0EsT0FBTyxvQkFDTCxNQUNBLE1BQ0EsbUJBQW1CLGdCQUFnQixVQUNuQyxvQkFDQSxZQUNGO0lBR0EsUUFBUSxlQUFlLGlCQUFpQixLQUFBLElBQVksS0FBSyxPQUFPLGVBQWU7SUFDL0UsdUJBQXVCLEtBQUs7R0FDOUI7R0FPQSxJQUFJLG9CQUFvQixXQUFXLFNBQVMsV0FBVyxRQUFRO0lBQzdELE1BQU0saUJBQWlCLE1BQU0sY0FBYyxJQUFJO0lBQy9DLElBQUksT0FBTyxtQkFBbUIsWUFBWSxTQUFTLGNBQWMsR0FBRztLQUNsRSx1QkFBdUI7S0FDdkIsSUFBSSxpQkFBaUIsZUFDbkIsTUFBTSxtQkFBbUI7SUFFN0I7R0FDRjtHQUlBLE1BQU0sd0JBQ0oscUJBQXFCQSxjQUFNLGlCQUFpQixJQUFJLEtBQUtBLGNBQU0sU0FBUyxJQUFJO0dBRTFFLE1BQU0sc0JBQXNCLFFBQVEsWUFBWSxVQUM5QyxZQUNFLFFBQ0EscUJBQ0MsZ0JBQWdCO0lBQ2YsSUFBSSxvQkFBb0IsY0FBYyxlQUNwQyxNQUFPLG1CQUFtQixtQkFBbUI7SUFFL0MsY0FBYyxXQUFXLFdBQVc7R0FDdEMsR0FDQSxLQUNGO0dBRUYsSUFDRSx5QkFDQSxXQUFXLFNBQ1gsV0FBVyxXQUNWLG9CQUFvQix3QkFDckI7SUFDQSx1QkFDRSx3QkFBd0IsT0FDcEIsTUFBTSxrQkFBa0IsU0FBUyxJQUFJLElBQ3JDO0lBSU4sSUFBSSx5QkFBeUIsS0FBSyx1QkFBdUI7S0FDdkQsSUFBSSxXQUFXLElBQUksUUFBUSxLQUFLO01BQzlCLFFBQVE7TUFDUixNQUFNO01BQ04sUUFBUTtLQUNWLENBQUM7S0FFRCxJQUFJO0tBRUosSUFDRUEsY0FBTSxXQUFXLElBQUksTUFDcEIsb0JBQW9CLFNBQVMsUUFBUSxJQUFJLGNBQWMsSUFFeEQsUUFBUSxlQUFlLGlCQUFpQjtLQUcxQyxJQUFJLFNBQVMsTUFBTTtNQUNqQixNQUFNLENBQUMsWUFBWSxTQUNoQixvQkFDQyx1QkFDRSxzQkFDQSxxQkFBcUIsZUFBZSxnQkFBZ0IsQ0FBQyxDQUN2RCxLQUNGLENBQUM7TUFFSCxPQUFPLG1CQUFtQixTQUFTLE1BQU0sWUFBWSxLQUFLO0tBQzVEO0lBQ0Y7R0FDRixPQUFPLElBQ0wseUJBQ0EsQ0FBQyxzQkFDRCw2QkFDQSxXQUFXLFNBQ1gsV0FBVyxRQUVYLE9BQU8sbUJBQW1CLElBQUk7UUFDekIsSUFDTCx5QkFDQSxzQkFDQSxDQUFDLHlCQUNELFdBQVcsU0FDWCxXQUFXLFFBRVgsTUFBTSxJQUFJRSxhQUNSLCtFQUNBQSxhQUFXLGlCQUNYLFFBQ0EsT0FDRjtHQUdGLElBQUksQ0FBQ0YsY0FBTSxTQUFTLGVBQWUsR0FDakMsa0JBQWtCLGtCQUFrQixZQUFZO0dBS2xELE1BQU0seUJBQXlCLHNCQUFzQixpQkFBaUIsUUFBUTtHQUk5RSxJQUFJQSxjQUFNLFdBQVcsSUFBSSxHQUFHO0lBQzFCLE1BQU0sY0FBYyxRQUFRLGVBQWU7SUFDM0MsSUFDRSxlQUNBLHlCQUF5QixLQUFLLFdBQVcsS0FDekMsQ0FBQyxhQUFhLEtBQUssV0FBVyxHQUU5QixRQUFRLE9BQU8sY0FBYztHQUVqQztHQUdBLFFBQVEsSUFBSSxjQUFjLFdBQVdJLFdBQVMsS0FBSztHQUVuRCxNQUFNLG1CQUNKLGdCQUFnQixPQUFPLGVBQWUsT0FBTyxPQUFPLE9BQU8sT0FBTyxJQUFJLEdBQUcsWUFBWTtHQUV2RixJQUFJLGtCQUFrQjtJQUdwQixPQUFPLGlCQUFpQjtJQUN4QixPQUFPLGlCQUFpQjtJQUN4QixPQUFPLGlCQUFpQjtJQUN4QixPQUFPLGlCQUFpQjtJQUN4QixPQUFPLGlCQUFpQjtJQUN4QixPQUFPLGlCQUFpQjtHQUMxQjtHQUVBLE1BQU0sa0JBQWtCLE9BQU8sT0FBTyxPQUFPLE9BQU8sSUFBSSxHQUFHLGtCQUFrQjtJQUMzRSxRQUFRO0lBQ1IsUUFBUSxPQUFPLFlBQVk7SUFDM0IsU0FBUyx5QkFBeUIsUUFBUSxVQUFVLENBQUM7SUFDckQsTUFBTTtJQUNOLFFBQVE7SUFDUixhQUFhLHlCQUF5QixrQkFBa0IsS0FBQTtHQUMxRCxDQUFDO0dBRUQsSUFBSSxvQkFBb0I7SUFDdEIsY0FBTSxRQUFRLGtCQUFrQixPQUFPLFFBQVE7S0FDN0MsSUFBSSxnQkFBZ0IsU0FBUyxLQUFBLEdBQzNCLGdCQUFnQixPQUFPO0lBRTNCLENBQUM7SUFFRCxJQUFJLGdCQUFnQixXQUFXLEtBQUEsR0FDN0IsZ0JBQWdCLFNBQVM7SUFHM0IsSUFBSSxnQkFBZ0IsU0FBUyxLQUFBLEdBQzNCLGdCQUFnQixPQUFPO0dBRTNCO0dBRUEsSUFBSSxpQkFBaUIsR0FBRztJQUN0QixnQkFBZ0IsV0FBVztJQUUzQixJQUFJLGtCQUNGLGlCQUFpQixXQUFXO0dBRWhDO0dBRUEsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLEtBQUssZUFBZTtHQUVoRSxJQUFJLFdBQVcsT0FBTyxxQkFDbEIsT0FBTyxTQUFTLGdCQUFnQixJQUNoQyxPQUFPLEtBQUssZUFBZTtHQUUvQixNQUFNLGtCQUFrQkQsZUFBYSxLQUFLLFNBQVMsT0FBTztHQUkxRCxJQUFJLHFCQUFxQjtJQUN2QixNQUFNLGlCQUFpQkgsY0FBTSxlQUFlLGdCQUFnQixpQkFBaUIsQ0FBQztJQUM5RSxJQUFJLGtCQUFrQixRQUFRLGlCQUFpQixrQkFDN0MsTUFBTSxJQUFJRSxhQUNSLDhCQUE4QixtQkFBbUIsYUFDakRBLGFBQVcsa0JBQ1gsUUFDQSxPQUNGO0dBRUo7R0FFQSxNQUFNLG1CQUNKLDJCQUEyQixpQkFBaUIsWUFBWSxpQkFBaUI7R0FFM0UsSUFDRSwwQkFDQSxTQUFTLFNBQ1Isc0JBQXNCLHVCQUF3QixvQkFBb0IsY0FDbkU7SUFDQSxNQUFNLFVBQVUsQ0FBQztJQUVqQjtLQUFDO0tBQVU7S0FBYztJQUFTLENBQUMsQ0FBQyxTQUFTLFNBQVM7S0FDcEQsUUFBUSxRQUFRLFNBQVM7SUFDM0IsQ0FBQztJQUVELE1BQU0sd0JBQXdCRixjQUFNLGVBQWUsZ0JBQWdCLGlCQUFpQixDQUFDO0lBRXJGLE1BQU0sQ0FBQyxZQUFZLFNBQ2hCLHNCQUNDLHVCQUNFLHVCQUNBLHFCQUFxQixlQUFlLGtCQUFrQixHQUFHLElBQUksQ0FDL0QsS0FDRixDQUFDO0lBRUgsSUFBSSxZQUFZO0lBQ2hCLE1BQU0sbUJBQW1CLGdCQUFnQjtLQUN2QyxJQUFJLHFCQUFxQjtNQUN2QixZQUFZO01BQ1osSUFBSSxZQUFZLGtCQUNkLE1BQU8sdUJBQXVCLElBQUlFLGFBQ2hDLDhCQUE4QixtQkFBbUIsYUFDakRBLGFBQVcsa0JBQ1gsUUFDQSxPQUNGO0tBRUo7S0FDQSxjQUFjLFdBQVcsV0FBVztJQUN0QztJQUVBLFdBQVcsSUFBSSxTQUNiLFlBQVksU0FBUyxNQUFNLG9CQUFvQix1QkFBdUI7S0FDcEUsU0FBUyxNQUFNO0tBQ2YsZUFBZSxZQUFZO0lBQzdCLENBQUMsR0FDRCxPQUNGO0dBQ0Y7R0FFQSxlQUFlLGdCQUFnQjtHQUUvQixJQUFJLGVBQWUsTUFBTSxVQUFVRixjQUFNLFFBQVEsV0FBVyxZQUFZLEtBQUssT0FBTyxDQUNsRixVQUNBLE1BQ0Y7R0FLQSxJQUFJLHVCQUF1QixDQUFDLDBCQUEwQixDQUFDLGtCQUFrQjtJQUN2RSxJQUFJO0lBQ0osSUFBSSxnQkFBZ0IsTUFBTTtLQUN4QixJQUFJLE9BQU8sYUFBYSxlQUFlLFVBQ3JDLG1CQUFtQixhQUFhO1VBQzNCLElBQUksT0FBTyxhQUFhLFNBQVMsVUFDdEMsbUJBQW1CLGFBQWE7VUFDM0IsSUFBSSxPQUFPLGlCQUFpQixVQUNqQyxtQkFDRSxPQUFPLGdCQUFnQixhQUNuQixJQUFJLFlBQVksQ0FBQyxDQUFDLE9BQU8sWUFBWSxDQUFDLENBQUMsYUFDdkMsYUFBYTtJQUV2QjtJQUNBLElBQUksT0FBTyxxQkFBcUIsWUFBWSxtQkFBbUIsa0JBQzdELE1BQU0sSUFBSUUsYUFDUiw4QkFBOEIsbUJBQW1CLGFBQ2pEQSxhQUFXLGtCQUNYLFFBQ0EsT0FDRjtHQUVKO0dBRUEsQ0FBQyxvQkFBb0IsZUFBZSxZQUFZO0dBRWhELE9BQU8sTUFBTSxJQUFJLFNBQVMsU0FBUyxXQUFXO0lBQzVDLE9BQU8sU0FBUyxRQUFRO0tBQ3RCLE1BQU07S0FDTixTQUFTQyxlQUFhLEtBQUssU0FBUyxPQUFPO0tBQzNDLFFBQVEsU0FBUztLQUNqQixZQUFZLFNBQVM7S0FDckI7S0FDQTtJQUNGLENBQUM7R0FDSCxDQUFDO0VBQ0gsU0FBUyxLQUFLO0dBQ1osZUFBZSxZQUFZO0dBSzNCLElBQUksa0JBQWtCLGVBQWUsV0FBVyxlQUFlLGtCQUFrQkQsY0FBWTtJQUMzRixNQUFNLGdCQUFnQixlQUFlO0lBQ3JDLGNBQWMsU0FBUztJQUN2QixZQUFZLGNBQWMsVUFBVTtJQUNwQyxJQUFJLFFBQVEsZUFHVixPQUFPLGVBQWUsZUFBZSxTQUFTO0tBQzVDLFdBQVc7S0FDWCxPQUFPO0tBQ1AsVUFBVTtLQUNWLFlBQVk7S0FDWixjQUFjO0lBQ2hCLENBQUM7SUFFSCxNQUFNO0dBQ1I7R0FPQSxJQUFJLGtCQUFrQjtJQUNwQixXQUFXLENBQUMsaUJBQWlCLFlBQVksaUJBQWlCLFVBQVU7SUFDcEUsTUFBTTtHQUNSO0dBRUEsSUFBSSxzQkFDRixNQUFNO0dBS1IsSUFBSSxlQUFlQSxjQUFZO0lBQzdCLFdBQVcsQ0FBQyxJQUFJLFlBQVksSUFBSSxVQUFVO0lBQzFDLE1BQU07R0FDUjtHQUVBLElBQUksT0FBTyxJQUFJLFNBQVMsZUFBZSxxQkFBcUIsS0FBSyxJQUFJLE9BQU8sR0FBRztJQUM3RSxNQUFNLGVBQWUsSUFBSUEsYUFDdkIsaUJBQ0FBLGFBQVcsYUFDWCxRQUNBLFNBQ0EsT0FBTyxJQUFJLFFBQ2I7SUFHQSxPQUFPLGVBQWUsY0FBYyxTQUFTO0tBQzNDLFdBQVc7S0FDWCxPQUFPLElBQUksU0FBUztLQUNwQixVQUFVO0tBQ1YsWUFBWTtLQUNaLGNBQWM7SUFDaEIsQ0FBQztJQUNELE1BQU07R0FDUjtHQUVBLE1BQU1BLGFBQVcsS0FBSyxLQUFLLE9BQU8sSUFBSSxNQUFNLFFBQVEsU0FBUyxPQUFPLElBQUksUUFBUTtFQUNsRjtDQUNGO0FBQ0Y7QUFFQSxJQUFNLDRCQUFZLElBQUksSUFBSTtBQUUxQixJQUFhLFlBQVksV0FBVztDQUNsQyxNQUFNLE1BQU0sT0FBTyxPQUFPLElBQUk7Q0FDOUIsTUFBTSxnQkFBZ0IsVUFBVUYsY0FBTSxXQUFXLFFBQVEsS0FBSyxLQUFLLE9BQU87Q0FDMUU7RUFBQztFQUFTO0VBQVc7RUFBWTtDQUFNLENBQUMsQ0FBQyxTQUFTLFFBQVE7RUFDeEQsSUFBSSxpQkFBaUJBLGNBQU0sV0FBVyxlQUFlLEdBQUcsR0FDdEQsSUFBSSxPQUFPLGNBQWM7Q0FFN0IsQ0FBQztDQUNELE1BQU0sRUFBRSxPQUFPLFNBQVMsVUFBVSxTQUFTO0NBQzNDLE1BQU0sUUFBUTtFQUFDO0VBQVM7RUFBVTtFQUFPO0NBQUk7Q0FFN0MsSUFDRSxJQURRLE1BQU0sUUFFZCxNQUNBLFFBQ0EsTUFBTTtDQUVSLE9BQU8sS0FBSztFQUNWLE9BQU8sTUFBTTtFQUNiLFNBQVMsSUFBSSxJQUFJLElBQUk7RUFFckIsV0FBVyxLQUFBLEtBQWEsSUFBSSxJQUFJLE1BQU8sU0FBUyxvQkFBSSxJQUFJLElBQUksSUFBSSxRQUFRLEdBQUcsQ0FBRTtFQUU3RSxNQUFNO0NBQ1I7Q0FFQSxPQUFPO0FBQ1Q7QUFFZ0IsU0FBUzs7Ozs7Ozs7Ozs7QUMzdEJ6QixJQUFNLGdCQUFnQjtDQUNwQixNQUFBO0NBQ0EsS0FBS0s7Q0FDTCxPQUFPLEVBQ0wsS0FBS0MsU0FDUDtBQUNGO0FBR0FDLGNBQU0sUUFBUSxnQkFBZ0IsSUFBSSxVQUFVO0NBQzFDLElBQUksSUFBSTtFQUNOLElBQUk7R0FHRixPQUFPLGVBQWUsSUFBSSxRQUFRO0lBQUUsV0FBVztJQUFNO0dBQU0sQ0FBQztFQUM5RCxTQUFTLEdBQUcsQ0FFWjtFQUNBLE9BQU8sZUFBZSxJQUFJLGVBQWU7R0FBRSxXQUFXO0dBQU07RUFBTSxDQUFDO0NBQ3JFO0FBQ0YsQ0FBQzs7Ozs7OztBQVFELElBQU0sZ0JBQWdCLFdBQVcsS0FBSzs7Ozs7OztBQVF0QyxJQUFNLG9CQUFvQixZQUN4QkEsY0FBTSxXQUFXLE9BQU8sS0FBSyxZQUFZLFFBQVEsWUFBWTs7Ozs7Ozs7Ozs7QUFZL0QsU0FBU0MsYUFBVyxVQUFVLFFBQVE7Q0FDcEMsV0FBV0QsY0FBTSxRQUFRLFFBQVEsSUFBSSxXQUFXLENBQUMsUUFBUTtDQUV6RCxNQUFNLEVBQUUsV0FBVztDQUNuQixJQUFJO0NBQ0osSUFBSTtDQUVKLE1BQU0sa0JBQWtCLENBQUM7Q0FFekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSztFQUMvQixnQkFBZ0IsU0FBUztFQUN6QixJQUFJO0VBRUosVUFBVTtFQUVWLElBQUksQ0FBQyxpQkFBaUIsYUFBYSxHQUFHO0dBQ3BDLFVBQVUsZUFBZSxLQUFLLE9BQU8sYUFBYSxFQUFBLENBQUcsWUFBWTtHQUVqRSxJQUFJLFlBQVksS0FBQSxHQUNkLE1BQU0sSUFBSUUsYUFBVyxvQkFBb0IsR0FBRyxFQUFFO0VBRWxEO0VBRUEsSUFBSSxZQUFZRixjQUFNLFdBQVcsT0FBTyxNQUFNLFVBQVUsUUFBUSxJQUFJLE1BQU0sS0FDeEU7RUFHRixnQkFBZ0IsTUFBTSxNQUFNLEtBQUs7Q0FDbkM7Q0FFQSxJQUFJLENBQUMsU0FBUztFQUNaLE1BQU0sVUFBVSxPQUFPLFFBQVEsZUFBZSxDQUFDLENBQUMsS0FDN0MsQ0FBQyxJQUFJLFdBQ0osV0FBVyxHQUFHLE1BQ2IsVUFBVSxRQUFRLHdDQUF3QyxnQ0FDL0Q7RUFRQSxNQUFNLElBQUlFLGFBQ1IsMkRBUE0sU0FDSixRQUFRLFNBQVMsSUFDZixjQUFjLFFBQVEsSUFBSSxZQUFZLENBQUMsQ0FBQyxLQUFLLElBQUksSUFDakQsTUFBTSxhQUFhLFFBQVEsRUFBRSxJQUMvQiw0QkFJRkEsYUFBVyxlQUNiO0NBQ0Y7Q0FFQSxPQUFPO0FBQ1Q7Ozs7QUFLQSxJQUFBLG1CQUFlOzs7OztDQUtiLFlBQUE7Ozs7O0NBTUEsVUFBVTtBQUNaOzs7Ozs7Ozs7QUNsSEEsU0FBUyw2QkFBNkIsUUFBUTtDQUM1QyxJQUFJLE9BQU8sYUFDVCxPQUFPLFlBQVksaUJBQWlCO0NBR3RDLElBQUksT0FBTyxVQUFVLE9BQU8sT0FBTyxTQUNqQyxNQUFNLElBQUlDLGdCQUFjLE1BQU0sTUFBTTtBQUV4Qzs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxhQUFhLE9BQU87Q0FDM0IsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxLQUFLO0FBQ3ZDOzs7Ozs7OztBQVNBLFNBQXdCLGdCQUFnQixTQUFTO0NBSS9DLE1BQU0sU0FBU0MsY0FBTSxpQkFBaUIsT0FBTztDQUU3Qyw2QkFBNkIsTUFBTTtDQUVuQyxPQUFPLFVBQVVDLGVBQWEsS0FBS0QsY0FBTSxZQUFZLFFBQVEsU0FBUyxDQUFDO0NBR3ZFLE9BQU8sT0FBTyxjQUFjLEtBQUssUUFBUSxPQUFPLGdCQUFnQjtDQUVoRSxJQUFJO0VBQUM7RUFBUTtFQUFPO0NBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxNQUFNLE1BQU0sSUFDdEQsT0FBTyxRQUFRLGVBQWUscUNBQXFDLEtBQUs7Q0FHMUUsTUFBTSxVQUFVRSxpQkFBUyxXQUFXLE9BQU8sV0FBVyxTQUFTLFNBQVMsTUFBTTtDQUU5RSxNQUFNLFFBQVEsS0FBSyxJQUFJO0NBRXZCLE9BQU8sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUNyQixTQUFTLG9CQUFvQixVQUFVO0VBQ3JDLDZCQUE2QixNQUFNO0VBRW5DLFNBQVMsV0FBVyxhQUFhLEtBQUs7RUFLdEMsT0FBTyxXQUFXO0VBQ2xCLElBQUk7R0FDRixTQUFTLE9BQU8sY0FBYyxLQUFLLFFBQVEsT0FBTyxtQkFBbUIsUUFBUTtFQUMvRSxVQUFVO0dBQ1IsT0FBTyxPQUFPO0VBQ2hCO0VBRUEsU0FBUyxVQUFVRCxlQUFhLEtBQUssU0FBUyxPQUFPO0VBRXJELE9BQU87Q0FDVCxHQUNBLFNBQVMsbUJBQW1CLFFBQVE7RUFDbEMsSUFBSSxDQUFDRSxXQUFTLE1BQU0sR0FBRztHQUNyQiw2QkFBNkIsTUFBTTtHQUduQyxJQUFJLFVBQVUsT0FBTyxVQUFVO0lBQzdCLE9BQU8sU0FBUyxXQUFXLGFBQWEsS0FBSztJQUM3QyxPQUFPLFdBQVcsT0FBTztJQUN6QixJQUFJO0tBQ0YsT0FBTyxTQUFTLE9BQU8sY0FBYyxLQUNuQyxRQUNBLE9BQU8sbUJBQ1AsT0FBTyxRQUNUO0lBQ0YsVUFBVTtLQUNSLE9BQU8sT0FBTztJQUNoQjtJQUNBLE9BQU8sU0FBUyxVQUFVRixlQUFhLEtBQUssT0FBTyxTQUFTLE9BQU87R0FDckU7RUFDRjtFQUVBLE9BQU8sUUFBUSxPQUFPLE1BQU07Q0FDOUIsQ0FDRjtBQUNGOztBQzdHQSxJQUFNRyxlQUFhLENBQUM7QUFHcEI7Q0FBQztDQUFVO0NBQVc7Q0FBVTtDQUFZO0NBQVU7QUFBUSxDQUFDLENBQUMsU0FBUyxNQUFNLE1BQU07Q0FDbkYsYUFBVyxRQUFRLFNBQVMsVUFBVSxPQUFPO0VBQzNDLE9BQU8sT0FBTyxVQUFVLFFBQVEsT0FBTyxJQUFJLElBQUksT0FBTyxPQUFPO0NBQy9EO0FBQ0YsQ0FBQztBQUVELElBQU0scUJBQXFCLENBQUM7Ozs7Ozs7Ozs7QUFXNUIsYUFBVyxlQUFlLFNBQVMsYUFBYSxXQUFXLFNBQVMsU0FBUztDQUMzRSxTQUFTLGNBQWMsS0FBSyxNQUFNO0VBQ2hDLE9BQ0UsYUFDQUMsWUFDQSw0QkFDQSxNQUNBLE1BQ0EsUUFDQyxVQUFVLE9BQU8sVUFBVTtDQUVoQztDQUdBLFFBQVEsT0FBTyxLQUFLLFNBQVM7RUFDM0IsSUFBSSxjQUFjLE9BQ2hCLE1BQU0sSUFBSUMsYUFDUixjQUFjLEtBQUssdUJBQXVCLFVBQVUsU0FBUyxVQUFVLEdBQUcsR0FDMUVBLGFBQVcsY0FDYjtFQUdGLElBQUksV0FBVyxDQUFDLG1CQUFtQixNQUFNO0dBQ3ZDLG1CQUFtQixPQUFPO0dBRTFCLFFBQVEsS0FDTixjQUNFLEtBQ0EsaUNBQWlDLFVBQVUseUNBQzdDLENBQ0Y7RUFDRjtFQUVBLE9BQU8sWUFBWSxVQUFVLE9BQU8sS0FBSyxJQUFJLElBQUk7Q0FDbkQ7QUFDRjtBQUVBLGFBQVcsV0FBVyxTQUFTLFNBQVMsaUJBQWlCO0NBQ3ZELFFBQVEsT0FBTyxRQUFRO0VBRXJCLFFBQVEsS0FBSyxHQUFHLElBQUksOEJBQThCLGlCQUFpQjtFQUNuRSxPQUFPO0NBQ1Q7QUFDRjs7Ozs7Ozs7OztBQVlBLFNBQVMsY0FBYyxTQUFTLFFBQVEsY0FBYztDQUNwRCxJQUFJLE9BQU8sWUFBWSxZQUFZLFlBQVksTUFDN0MsTUFBTSxJQUFJQSxhQUFXLDZCQUE2QkEsYUFBVyxvQkFBb0I7Q0FFbkYsTUFBTSxPQUFPLE9BQU8sS0FBSyxPQUFPO0NBQ2hDLElBQUksSUFBSSxLQUFLO0NBQ2IsT0FBTyxNQUFNLEdBQUc7RUFDZCxNQUFNLE1BQU0sS0FBSztFQUdqQixNQUFNLFlBQVksT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLEdBQUcsSUFBSSxPQUFPLE9BQU8sS0FBQTtFQUNwRixJQUFJLFdBQVc7R0FDYixNQUFNLFFBQVEsUUFBUTtHQUN0QixNQUFNLFNBQVMsVUFBVSxLQUFBLEtBQWEsVUFBVSxPQUFPLEtBQUssT0FBTztHQUNuRSxJQUFJLFdBQVcsTUFDYixNQUFNLElBQUlBLGFBQ1IsWUFBWSxNQUFNLGNBQWMsUUFDaENBLGFBQVcsb0JBQ2I7R0FFRjtFQUNGO0VBQ0EsSUFBSSxpQkFBaUIsTUFDbkIsTUFBTSxJQUFJQSxhQUFXLG9CQUFvQixLQUFLQSxhQUFXLGNBQWM7Q0FFM0U7QUFDRjtBQUVBLElBQUEsb0JBQWU7Q0FDYjtDQUNBLFlBQUE7QUFDRjs7QUNqR0EsSUFBTSxhQUFhQyxrQkFBVTtBQUs3QixJQUFNLG1CQUFtQixVQUFVO0NBQ2pDLElBQUksU0FBUyxRQUFRQyxjQUFNLGNBQWMsS0FBSyxLQUFLLGlCQUFpQkMsZ0JBQ2xFLE9BQU87Q0FHVCxJQUFJO0VBQ0YsT0FDRUQsY0FBTSxTQUFTLEtBQUssS0FDcEJBLGNBQU0sWUFBWSxPQUFPLE9BQU8sV0FBVyxNQUFNLGtCQUNqRDtHQUNFO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBLE9BQU87RUFDVCxDQUFDLENBQUMsT0FBTyxXQUFXQSxjQUFNLFdBQVdBLGNBQU0sWUFBWSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0NBRTFFLFNBQVMsR0FBRztFQUVWLE9BQU87Q0FDVDtBQUNGOzs7Ozs7OztBQVNBLElBQU1FLFVBQU4sTUFBWTtDQUNWLFlBQVksZ0JBQWdCO0VBQzFCLEtBQUssV0FBVyxrQkFBa0IsQ0FBQztFQUNuQyxLQUFLLGVBQWU7R0FDbEIsU0FBUyxJQUFJLG1CQUFtQjtHQUNoQyxVQUFVLElBQUksbUJBQW1CO0VBQ25DO0NBQ0Y7Ozs7Ozs7OztDQVVBLE1BQU0sUUFBUSxhQUFhLFFBQVE7RUFDakMsSUFBSTtHQUNGLE9BQU8sTUFBTSxLQUFLLFNBQVMsYUFBYSxNQUFNO0VBQ2hELFNBQVMsS0FBSztHQUNaLElBQUksZUFBZSxPQUNqQixJQUFJO0lBQ0YsSUFBSSxRQUFRLENBQUM7SUFFYixNQUFNLG9CQUFvQixNQUFNLGtCQUFrQixLQUFLLElBQUssd0JBQVEsSUFBSSxNQUFNO0lBRTlFLE1BQU0sYUFBYSxNQUFNO0lBQ3pCLElBQUksUUFBUTtJQUdaLElBQUksT0FBTyxlQUFlLFVBQVU7S0FDbEMsTUFBTSxvQkFBb0IsV0FBVyxRQUFRLElBQUk7S0FFakQsUUFBUSxzQkFBc0IsS0FBSyxLQUFLLFdBQVcsTUFBTSxvQkFBb0IsQ0FBQztJQUNoRjtJQUVBLElBQUksQ0FBQyxJQUFJLE9BQ1AsSUFBSSxRQUFRO1NBQ1AsSUFBSSxPQUFPO0tBR2hCLE1BQU0sb0JBQW9CLE1BQU0sUUFBUSxJQUFJO0tBQzVDLE1BQU0scUJBQ0osc0JBQXNCLEtBQUssS0FBSyxNQUFNLFFBQVEsTUFBTSxvQkFBb0IsQ0FBQztLQUMzRSxNQUFNLHVCQUNKLHVCQUF1QixLQUFLLFFBQVEsTUFBTSxNQUFNLHFCQUFxQixDQUFDO0tBTXhFLE1BQU0sZUFBZSxPQUFPLElBQUksS0FBSztLQUNyQyxNQUFNLGFBQWEsbUJBQW1CLEtBQUssWUFBWTtLQUN2RCxNQUFNLFlBQVksZUFBZSxLQUFLLGVBQWUsYUFBYSxNQUFNLEdBQUcsVUFBVTtLQUNyRixNQUFNLGVBQWUsZUFBZSxLQUFLLEtBQUssYUFBYSxNQUFNLFVBQVU7S0FFM0UsSUFBSSxDQUFDLFVBQVUsU0FBUyxvQkFBb0IsR0FDMUMsSUFBSSxRQUFRLFlBQVksT0FBTyxRQUFRO0lBRTNDO0dBQ0YsU0FBUyxHQUFHLENBRVo7R0FHRixNQUFNO0VBQ1I7Q0FDRjtDQUVBLFNBQVMsYUFBYSxRQUFRO0VBRzVCLElBQUksT0FBTyxnQkFBZ0IsVUFBVTtHQUNuQyxTQUFTLFVBQVUsQ0FBQztHQUNwQixPQUFPLE1BQU07RUFDZixPQUNFLFNBQVMsZUFBZSxDQUFDO0VBRzNCLFNBQVNDLGNBQVksS0FBSyxVQUFVLE1BQU07RUFFMUMsTUFBTSxFQUFFLGNBQWMsa0JBQWtCLFlBQVk7RUFFcEQsSUFBSSxpQkFBaUIsS0FBQSxHQUNuQixrQkFBVSxjQUNSLGNBQ0E7R0FDRSxtQkFBbUIsV0FBVyxhQUFhLFdBQVcsT0FBTztHQUM3RCxtQkFBbUIsV0FBVyxhQUFhLFdBQVcsT0FBTztHQUM3RCxxQkFBcUIsV0FBVyxhQUFhLFdBQVcsT0FBTztHQUMvRCxpQ0FBaUMsV0FBVyxhQUFhLFdBQVcsT0FBTztHQUMzRSw2QkFBNkIsV0FBVyxhQUFhLFdBQVcsT0FBTztHQUN2RSxpQ0FBaUMsV0FBVyxhQUFhLFdBQVcsT0FBTztHQUMzRSx5QkFBeUIsV0FBVyxhQUFhLFdBQVcsT0FBTztFQUNyRSxHQUNBLEtBQ0Y7RUFHRixJQUFJLG9CQUFvQixNQUFNO0dBQzVCLElBQUlILGNBQU0sV0FBVyxnQkFBZ0IsR0FDbkMsT0FBTyxtQkFBbUIsRUFDeEIsV0FBVyxpQkFDYjtRQUVBLGtCQUFVLGNBQ1Isa0JBQ0E7SUFDRSxRQUFRLFdBQVc7SUFDbkIsV0FBVyxXQUFXO0dBQ3hCLEdBQ0EsSUFDRjtFQUVKO0VBR0EsSUFBSSxPQUFPLHNCQUFzQixLQUFBLEdBQVcsQ0FFNUMsT0FBTyxJQUNMQSxjQUFNLFdBQVcsS0FBSyxVQUFVLG1CQUFtQixLQUNuRCxLQUFLLFNBQVMsc0JBQXNCLEtBQUEsR0FFcEMsT0FBTyxvQkFBb0IsS0FBSyxTQUFTO09BRXpDLE9BQU8sb0JBQW9CO0VBRzdCLGtCQUFVLGNBQ1IsUUFDQTtHQUNFLFNBQVMsV0FBVyxTQUFTLFNBQVM7R0FDdEMsZUFBZSxXQUFXLFNBQVMsZUFBZTtFQUNwRCxHQUNBLElBQ0Y7RUFHQSxPQUFPLFVBQ0xBLGNBQU0sWUFBWSxRQUFRLFFBQVEsS0FDbENBLGNBQU0sWUFBWSxLQUFLLFVBQVUsUUFBUSxLQUN6QyxNQUFBLENBQ0EsWUFBWTtFQUdkLE1BQU0sZ0JBQWdCQSxjQUFNLFlBQVksU0FBUyxRQUFRO0VBQ3pELE1BQU0sZ0JBQWdCQSxjQUFNLFlBQVksU0FBUyxPQUFPLE1BQU07RUFDOUQsTUFBTSxpQkFDSixXQUNBQSxjQUFNLE1BQ0osZ0JBQWdCLGFBQWEsSUFBSSxnQkFBZ0IsS0FBQSxHQUNqRCxnQkFBZ0IsYUFBYSxJQUFJLGdCQUFnQixLQUFBLENBQ25EO0VBRUYsV0FDRUEsY0FBTSxRQUFRLFdBQVcsT0FBTyxRQUFRLElBQUksV0FBVztHQUNyRCxJQUFJLGdCQUFnQkEsY0FBTSxZQUFZLFNBQVMsTUFBTSxDQUFDLEdBQ3BELE9BQU8sUUFBUTtFQUVuQixDQUFDO0VBRUgsT0FBTyxVQUFVQyxlQUFhLE9BQU8sZ0JBQWdCLE9BQU87RUFHNUQsTUFBTSwwQkFBMEIsQ0FBQztFQUNqQyxJQUFJLGlDQUFpQztFQUNyQyxLQUFLLGFBQWEsUUFBUSxRQUFRLFNBQVMsMkJBQTJCLGFBQWE7R0FDakYsSUFBSSxPQUFPLFlBQVksWUFBWSxjQUFjLFlBQVksUUFBUSxNQUFNLE1BQU0sT0FDL0U7R0FHRixpQ0FBaUMsa0NBQWtDLFlBQVk7R0FFL0UsTUFBTSxlQUFlLE9BQU8sZ0JBQWdCRztHQUk1QyxJQUZFLGdCQUFnQixhQUFhLGlDQUc3Qix3QkFBd0IsUUFBUSxZQUFZLFdBQVcsWUFBWSxRQUFRO1FBRTNFLHdCQUF3QixLQUFLLFlBQVksV0FBVyxZQUFZLFFBQVE7RUFFNUUsQ0FBQztFQUVELE1BQU0sMkJBQTJCLENBQUM7RUFDbEMsS0FBSyxhQUFhLFNBQVMsUUFBUSxTQUFTLHlCQUF5QixhQUFhO0dBQ2hGLHlCQUF5QixLQUFLLFlBQVksV0FBVyxZQUFZLFFBQVE7RUFDM0UsQ0FBQztFQUVELElBQUk7RUFDSixJQUFJLElBQUk7RUFDUixJQUFJO0VBRUosSUFBSSxDQUFDLGdDQUFnQztHQUNuQyxNQUFNLFFBQVEsQ0FBQyxnQkFBZ0IsS0FBSyxJQUFJLEdBQUcsS0FBQSxDQUFTO0dBQ3BELE1BQU0sUUFBUSxHQUFHLHVCQUF1QjtHQUN4QyxNQUFNLEtBQUssR0FBRyx3QkFBd0I7R0FDdEMsTUFBTSxNQUFNO0dBRVosVUFBVSxRQUFRLFFBQVEsTUFBTTtHQUVoQyxPQUFPLElBQUksS0FDVCxVQUFVLFFBQVEsS0FBSyxNQUFNLE1BQU0sTUFBTSxJQUFJO0dBRy9DLE9BQU87RUFDVDtFQUVBLE1BQU0sd0JBQXdCO0VBRTlCLElBQUksWUFBWTtFQUVoQixPQUFPLElBQUksS0FBSztHQUNkLE1BQU0sY0FBYyx3QkFBd0I7R0FDNUMsTUFBTSxhQUFhLHdCQUF3QjtHQUMzQyxJQUFJO0lBQ0YsWUFBWSxjQUFjLFlBQVksU0FBUyxJQUFJO0dBQ3JELFNBQVMsT0FBTztJQUNkLElBQUksQ0FBQyxZQUFZO0tBQ2YsVUFBVSxRQUFRLE9BQU8sS0FBSztLQUM5QjtJQUNGO0lBRUEsSUFBSTtLQUNGLE1BQU0saUJBQWlCLFdBQVcsS0FBSyxNQUFNLEtBQUs7S0FFbEQsSUFBSUosY0FBTSxXQUFXLGNBQWMsR0FDakMsVUFBVSxRQUFRLFFBQVEsY0FBYyxDQUFDLENBQUMsV0FDeEMsZ0JBQWdCLEtBQUssTUFBTSxTQUFTLENBQ3RDO0lBRUosU0FBUyxlQUFlO0tBQ3RCLFVBQVUsUUFBUSxPQUFPLGFBQWE7SUFDeEM7SUFFQTtHQUNGO0VBQ0Y7RUFFQSxJQUFJLENBQUMsU0FDSCxJQUFJO0dBQ0YsVUFBVSxnQkFBZ0IsS0FBSyxNQUFNLFNBQVM7RUFDaEQsU0FBUyxPQUFPO0dBQ2QsVUFBVSxRQUFRLE9BQU8sS0FBSztFQUNoQztFQUdGLElBQUk7RUFDSixNQUFNLHlCQUF5QjtFQUUvQixPQUFPLElBQUksS0FDVCxVQUFVLFFBQVEsS0FBSyx5QkFBeUIsTUFBTSx5QkFBeUIsSUFBSTtFQUdyRixPQUFPO0NBQ1Q7Q0FFQSxPQUFPLFFBQVE7RUFDYixTQUFTRyxjQUFZLEtBQUssVUFBVSxNQUFNO0VBRTFDLE9BQU8sU0FEVSxjQUFjLE9BQU8sU0FBUyxPQUFPLEtBQUssT0FBTyxtQkFBbUIsTUFDckUsR0FBVSxPQUFPLFFBQVEsT0FBTyxnQkFBZ0I7Q0FDbEU7QUFDRjtBQUdBSCxjQUFNLFFBQVE7Q0FBQztDQUFVO0NBQU87Q0FBUTtBQUFTLEdBQUcsU0FBUyxvQkFBb0IsUUFBUTtDQUV2RixRQUFNLFVBQVUsVUFBVSxlQUFnQixLQUFLLFFBQVE7RUFDckQsT0FBTyxLQUFLLFFBQ1ZHLGNBQVksVUFBVSxDQUFDLEdBQUc7R0FDeEI7R0FDQTtHQUNBLE1BQU0sVUFBVUgsY0FBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLE9BQU8sT0FBTyxLQUFBO0VBQ25FLENBQUMsQ0FDSDtDQUNGO0FBQ0YsQ0FBQztBQUVEQSxjQUFNLFFBQVE7Q0FBQztDQUFRO0NBQU87Q0FBUztBQUFPLEdBQUcsU0FBUyxzQkFBc0IsUUFBUTtDQUN0RixTQUFTLG1CQUFtQixRQUFRO0VBQ2xDLE9BQU8sZUFBZSxXQUFXLEtBQUssTUFBTSxRQUFRO0dBQ2xELE9BQU8sS0FBSyxRQUNWRyxjQUFZLFVBQVUsQ0FBQyxHQUFHO0lBQ3hCO0lBQ0EsU0FBUyxTQUNMLEVBQ0UsZ0JBQWdCLHNCQUNsQixJQUNBLENBQUM7SUFDTDtJQUNBO0dBQ0YsQ0FBQyxDQUNIO0VBQ0Y7Q0FDRjtDQUVBLFFBQU0sVUFBVSxVQUFVLG1CQUFtQjtDQUk3QyxJQUFJLFdBQVcsU0FDYixRQUFNLFVBQVUsU0FBUyxVQUFVLG1CQUFtQixJQUFJO0FBRTlELENBQUM7Ozs7Ozs7OztBQzNWRCxJQUFNRSxnQkFBTixNQUFNQSxjQUFZO0NBQ2hCLFlBQVksVUFBVTtFQUNwQixJQUFJLE9BQU8sYUFBYSxZQUN0QixNQUFNLElBQUksVUFBVSw4QkFBOEI7RUFHcEQsSUFBSTtFQUVKLEtBQUssVUFBVSxJQUFJLFFBQVEsU0FBUyxnQkFBZ0IsU0FBUztHQUMzRCxpQkFBaUI7RUFDbkIsQ0FBQztFQUVELE1BQU0sUUFBUTtFQUdkLEtBQUssUUFBUSxNQUFNLFdBQVc7R0FDNUIsSUFBSSxDQUFDLE1BQU0sWUFBWTtHQUV2QixJQUFJLElBQUksTUFBTSxXQUFXO0dBRXpCLE9BQU8sTUFBTSxHQUNYLE1BQU0sV0FBVyxFQUFFLENBQUMsTUFBTTtHQUU1QixNQUFNLGFBQWE7RUFDckIsQ0FBQztFQUdELEtBQUssUUFBUSxRQUFRLGdCQUFnQjtHQUNuQyxJQUFJO0dBRUosTUFBTSxVQUFVLElBQUksU0FBUyxZQUFZO0lBQ3ZDLE1BQU0sVUFBVSxPQUFPO0lBQ3ZCLFdBQVc7R0FDYixDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7R0FFbkIsUUFBUSxTQUFTLFNBQVMsU0FBUztJQUNqQyxNQUFNLFlBQVksUUFBUTtHQUM1QjtHQUVBLE9BQU87RUFDVDtFQUVBLFNBQVMsU0FBUyxPQUFPLFNBQVMsUUFBUSxTQUFTO0dBQ2pELElBQUksTUFBTSxRQUVSO0dBR0YsTUFBTSxTQUFTLElBQUlDLGdCQUFjLFNBQVMsUUFBUSxPQUFPO0dBQ3pELGVBQWUsTUFBTSxNQUFNO0VBQzdCLENBQUM7Q0FDSDs7OztDQUtBLG1CQUFtQjtFQUNqQixJQUFJLEtBQUssUUFDUCxNQUFNLEtBQUs7Q0FFZjs7OztDQU1BLFVBQVUsVUFBVTtFQUNsQixJQUFJLEtBQUssUUFBUTtHQUNmLFNBQVMsS0FBSyxNQUFNO0dBQ3BCO0VBQ0Y7RUFFQSxJQUFJLEtBQUssWUFDUCxLQUFLLFdBQVcsS0FBSyxRQUFRO09BRTdCLEtBQUssYUFBYSxDQUFDLFFBQVE7Q0FFL0I7Ozs7Q0FNQSxZQUFZLFVBQVU7RUFDcEIsSUFBSSxDQUFDLEtBQUssWUFDUjtFQUVGLE1BQU0sUUFBUSxLQUFLLFdBQVcsUUFBUSxRQUFRO0VBQzlDLElBQUksVUFBVSxJQUNaLEtBQUssV0FBVyxPQUFPLE9BQU8sQ0FBQztDQUVuQztDQUVBLGdCQUFnQjtFQUNkLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtFQUV2QyxNQUFNLFNBQVMsUUFBUTtHQUNyQixXQUFXLE1BQU0sR0FBRztFQUN0QjtFQUVBLEtBQUssVUFBVSxLQUFLO0VBRXBCLFdBQVcsT0FBTyxvQkFBb0IsS0FBSyxZQUFZLEtBQUs7RUFFNUQsT0FBTyxXQUFXO0NBQ3BCOzs7OztDQU1BLE9BQU8sU0FBUztFQUNkLElBQUk7RUFJSixPQUFPO0dBQ0wsT0FBQSxJQUpnQkQsY0FBWSxTQUFTLFNBQVMsR0FBRztJQUNqRCxTQUFTO0dBQ1gsQ0FFTTtHQUNKO0VBQ0Y7Q0FDRjtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdHQSxTQUF3QkUsU0FBTyxVQUFVO0NBQ3ZDLE9BQU8sU0FBUyxLQUFLLEtBQUs7RUFDeEIsT0FBTyxTQUFTLE1BQU0sTUFBTSxHQUFHO0NBQ2pDO0FBQ0Y7Ozs7Ozs7OztBQ2hCQSxTQUF3QkMsZUFBYSxTQUFTO0NBQzVDLE9BQU9DLGNBQU0sU0FBUyxPQUFPLEtBQUssUUFBUSxpQkFBaUI7QUFDN0Q7O0FDYkEsSUFBTUMsbUJBQWlCO0NBQ3JCLFVBQVU7Q0FDVixvQkFBb0I7Q0FDcEIsWUFBWTtDQUNaLFlBQVk7Q0FDWixJQUFJO0NBQ0osU0FBUztDQUNULFVBQVU7Q0FDViw2QkFBNkI7Q0FDN0IsV0FBVztDQUNYLGNBQWM7Q0FDZCxnQkFBZ0I7Q0FDaEIsYUFBYTtDQUNiLGlCQUFpQjtDQUNqQixRQUFRO0NBQ1IsaUJBQWlCO0NBQ2pCLGtCQUFrQjtDQUNsQixPQUFPO0NBQ1AsVUFBVTtDQUNWLGFBQWE7Q0FDYixVQUFVO0NBQ1YsUUFBUTtDQUNSLG1CQUFtQjtDQUNuQixtQkFBbUI7Q0FDbkIsWUFBWTtDQUNaLGNBQWM7Q0FDZCxpQkFBaUI7Q0FDakIsV0FBVztDQUNYLFVBQVU7Q0FDVixrQkFBa0I7Q0FDbEIsZUFBZTtDQUNmLDZCQUE2QjtDQUM3QixnQkFBZ0I7Q0FDaEIsVUFBVTtDQUNWLE1BQU07Q0FDTixnQkFBZ0I7Q0FDaEIsb0JBQW9COzs7O0NBSXBCLGlCQUFpQjtDQUNqQixpQkFBaUI7Q0FDakIsWUFBWTtDQUNaLHNCQUFzQjtDQUN0QixxQkFBcUI7Q0FDckIsbUJBQW1CO0NBQ25CLFdBQVc7Q0FDWCxvQkFBb0I7Ozs7Q0FJcEIscUJBQXFCO0NBQ3JCLHNCQUFzQjtDQUN0QixRQUFRO0NBQ1Isa0JBQWtCO0NBQ2xCLFVBQVU7Q0FDVixpQkFBaUI7Q0FDakIsc0JBQXNCO0NBQ3RCLGlCQUFpQjtDQUNqQiw2QkFBNkI7Q0FDN0IsNEJBQTRCO0NBQzVCLHFCQUFxQjtDQUNyQixnQkFBZ0I7Q0FDaEIsWUFBWTtDQUNaLG9CQUFvQjtDQUNwQixnQkFBZ0I7Q0FDaEIseUJBQXlCO0NBQ3pCLHVCQUF1QjtDQUN2QixxQkFBcUI7Q0FDckIsY0FBYztDQUNkLGFBQWE7Q0FDYiwrQkFBK0I7Q0FDL0IsZ0NBQWdDO0NBQ2hDLGlCQUFpQjtDQUNqQixvQkFBb0I7Q0FDcEIscUJBQXFCO0NBQ3JCLGlCQUFpQjtDQUNqQixvQkFBb0I7Q0FDcEIsdUJBQXVCO0FBQ3pCO0FBRUEsT0FBTyxRQUFRQSxnQkFBYyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssV0FBVztDQUN2RCxJQUFJQSxpQkFBZSxXQUFXLEtBQUEsR0FDNUIsaUJBQWUsU0FBUztBQUU1QixDQUFDOzs7Ozs7Ozs7QUMxREQsU0FBUyxlQUFlLGVBQWU7Q0FDckMsTUFBTSxVQUFVLElBQUlDLFFBQU0sYUFBYTtDQUN2QyxNQUFNLFdBQVcsS0FBS0EsUUFBTSxVQUFVLFNBQVMsT0FBTztDQUd0RCxjQUFNLE9BQU8sVUFBVUEsUUFBTSxXQUFXLFNBQVMsRUFBRSxZQUFZLEtBQUssQ0FBQztDQUdyRSxjQUFNLE9BQU8sVUFBVSxTQUFTLE1BQU0sRUFBRSxZQUFZLEtBQUssQ0FBQztDQUcxRCxTQUFTLFNBQVMsU0FBUyxPQUFPLGdCQUFnQjtFQUNoRCxPQUFPLGVBQWVDLGNBQVksZUFBZSxjQUFjLENBQUM7Q0FDbEU7Q0FFQSxPQUFPO0FBQ1Q7QUFHQSxJQUFNLFFBQVEsZUFBZSxRQUFRO0FBR3JDLE1BQU0sUUFBUUQ7QUFHZCxNQUFNLGdCQUFnQkU7QUFDdEIsTUFBTSxjQUFjQztBQUNwQixNQUFNLFdBQVdDO0FBQ2pCLE1BQU0sVUFBVUM7QUFDaEIsTUFBTSxhQUFhQztBQUduQixNQUFNLGFBQWFDO0FBR25CLE1BQU0sU0FBUyxNQUFNO0FBR3JCLE1BQU0sTUFBTSxTQUFTLElBQUksVUFBVTtDQUNqQyxPQUFPLFFBQVEsSUFBSSxRQUFRO0FBQzdCO0FBRUEsTUFBTSxTQUFTQztBQUdmLE1BQU0sZUFBZUM7QUFHckIsTUFBTSxjQUFjUjtBQUVwQixNQUFNLGVBQWVTO0FBRXJCLE1BQU0sY0FBYyxVQUFVLGVBQWVDLGNBQU0sV0FBVyxLQUFLLElBQUksSUFBSSxTQUFTLEtBQUssSUFBSSxLQUFLO0FBRWxHLE1BQU0sYUFBYUMsaUJBQVM7QUFFNUIsTUFBTSxpQkFBaUJDO0FBRXZCLE1BQU0sVUFBVTs7QUNoRmhCLElBQU0sRUFDSixPQUNBLFlBQ0EsZUFDQSxVQUNBLGFBQ0EsU0FDQSxLQUNBLFFBQ0EsY0FDQSxRQUNBLFlBQ0EsY0FDQSxnQkFDQSxZQUNBLFlBQ0EsYUFDQSxXQUNFIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjMsMjQsMjUsMjYsMjcsMjgsMjksMzAsMzEsMzIsMzMsMzQsMzUsMzYsMzcsMzgsMzksNDAsNDEsNDIsNDMsNDQsNDUsNDYsNDcsNDgsNDksNTAsNTEsNTIsNTMsNTQsNTUsNTZdfQ==