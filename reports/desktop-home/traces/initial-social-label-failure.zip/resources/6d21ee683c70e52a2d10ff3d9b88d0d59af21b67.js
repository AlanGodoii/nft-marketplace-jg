import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/hero.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import { useDesktop } from "/src/lib/use-desktop.ts";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { ArrowDown, ArrowUpRight, ImageOff } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { buttonVariants } from "/src/components/ui/button.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/components/hero.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function Hero({ featured }) {
	_s();
	const desktop = useDesktop();
	if (desktop) return /* @__PURE__ */ _jsxDEV("section", {
		className: "desktop-home-hero desktop-home-only",
		"aria-labelledby": "desktop-hero-title",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "desktop-hero-copy",
			children: [
				/* @__PURE__ */ _jsxDEV("p", { children: "Bem-vindo à Kurio" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", {
					id: "desktop-hero-title",
					children: [
						"SEJA DONO DO FUTURO",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 14,
							columnNumber: 58
						}, this),
						"DA ARTE DIGITAL"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "desktop-hero-description",
					children: [
						"Descubra NFTs selecionados de criadores emergentes e consagrados.",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 116
						}, this),
						"Colecione arte digital rara, apoie artistas e tenha uma parte da",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 186
						}, this),
						"cultura da internet."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#catalogo",
					className: buttonVariants({ className: "desktop-explore" }),
					children: "EXPLORAR"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "banner-indicators",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 65
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 73
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 81
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("picture", { children: [/* @__PURE__ */ _jsxDEV("source", {
			media: "(min-width: 1024px)",
			srcSet: "/assets/figma/home/emerald-ape.webp"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 18
		}, this), /* @__PURE__ */ _jsxDEV("img", {
			src: "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=",
			alt: "Macaco com jaqueta verde e óculos, arte original Kurio",
			width: "450",
			height: "450",
			fetchPriority: "high"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 101
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 7
	}, this);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "kurio-hero legacy-hero",
		"aria-labelledby": "hero-title",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "hero-copy",
			children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm uppercase tracking-[0.2em] text-primary",
					children: "Kurio · NFT Marketplace"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", {
					id: "hero-title",
					className: "mt-6 text-4xl leading-tight font-bold sm:text-5xl",
					children: [
						"Descubra o seu",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-primary",
							children: "próximo NFT."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 31
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-6 max-w-md text-sm leading-7 text-muted-foreground",
					children: "Explore o universo dos colecionáveis digitais."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#catalogo",
					className: buttonVariants({ className: "mt-8 h-12 rounded-sm px-6" }),
					children: ["Explorar NFTs ", /* @__PURE__ */ _jsxDEV(ArrowDown, { "aria-hidden": "true" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "hero-art",
			children: featured.status === "loading" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				role: "status",
				children: "Carregando destaque"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, {
				"aria-hidden": "true",
				className: "size-full rounded-none"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 79
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 11
			}, this) : featured.status === "success" && featured.data ? /* @__PURE__ */ _jsxDEV(Link, {
				to: "/nfts/$nftId",
				params: { nftId: featured.data.nft.id },
				className: "relative block size-full",
				children: [featured.data.nft.image.src ? /* @__PURE__ */ _jsxDEV("img", {
					src: featured.data.nft.image.src,
					alt: featured.data.nft.image.alt,
					width: "450",
					height: "450",
					className: "size-full object-cover"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 15
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					role: "img",
					"aria-label": featured.data.nft.image.alt,
					className: "nft-art-placeholder size-full",
					children: [/* @__PURE__ */ _jsxDEV(ImageOff, {
						"aria-hidden": "true",
						className: "size-8"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Arte original indisponível" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 67
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-x-0 bottom-0 flex items-center justify-between gap-4 bg-background/95 p-5",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "font-bold",
						children: featured.data.nft.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 20
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: featured.data.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, {
						"aria-hidden": "true",
						className: "size-5 shrink-0 text-primary"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "flex size-full flex-col items-center justify-center gap-4 border border-dashed p-8 text-center text-muted-foreground",
				children: [/* @__PURE__ */ _jsxDEV(ImageOff, {
					"aria-hidden": "true",
					className: "size-8"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm",
					children: featured.status === "error" ? featured.message : "Destaque indisponível"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
}
_s(Hero, "8bC77epNsaDPkYpxNVwjV1y7/9Q=", false, function() {
	return [useDesktop];
});
_c = Hero;
var _c;
$RefreshReg$(_c, "Hero");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/components/hero.tsx?t=1793942929469";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/components/hero.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/components/hero.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/components/hero.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsV0FBVyxjQUFjLGdCQUFnQjtBQUNsRCxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGdCQUFnQjs7OztBQUd6QixPQUFPLFNBQVMsS0FBSyxFQUFFLFlBQTBEOztDQUMvRSxNQUFNLFVBQVUsV0FBVztDQUMzQixJQUFJLFNBQVMsT0FDVCx3QkFBQyxXQUFEO0VBQVMsV0FBVTtFQUFzQyxtQkFBZ0I7WUFBekUsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsS0FBRCxZQUFHLG9CQUFvQjs7Ozs7SUFDdkIsd0JBQUMsTUFBRDtLQUFJLElBQUc7ZUFBUDtNQUE0QjtNQUFtQix3QkFBQyxNQUFELENBQUs7Ozs7O01BQUM7S0FBbUI7Ozs7OztJQUN4RSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQXdDO01BQWlFLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7TUFBQztNQUFnRSx3QkFBQyxNQUFELENBQUs7Ozs7O01BQUM7S0FBdUI7Ozs7OztJQUM1TSx3QkFBQyxLQUFEO0tBQUcsTUFBSztLQUFZLFdBQVcsZUFBZSxFQUFFLFdBQVcsa0JBQWtCLENBQUM7ZUFBRztJQUFXOzs7OztJQUM1Rix3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFvQixlQUFZO2VBQS9DO01BQXNELHdCQUFDLFFBQUQsQ0FBTzs7Ozs7TUFBQyx3QkFBQyxRQUFELENBQU87Ozs7O01BQUMsd0JBQUMsUUFBRCxDQUFPOzs7OztLQUFNOzs7Ozs7R0FDaEY7Ozs7O1lBQ0wsd0JBQUMsV0FBRCxhQUFTLHdCQUFDLFVBQUQ7R0FBUSxPQUFNO0dBQXNCLFFBQU87RUFBdUM7Ozs7WUFBQyx3QkFBQyxPQUFEO0dBQUssS0FBSTtHQUE2RCxLQUFJO0dBQXlELE9BQU07R0FBTSxRQUFPO0dBQU0sZUFBYztFQUFROzs7O1VBQVU7Ozs7VUFDalI7Ozs7OztDQUViLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7RUFBeUIsbUJBQWdCO1lBQTVELENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWtEO0lBQTBCOzs7OztJQUN6Rix3QkFBQyxNQUFEO0tBQUksSUFBRztLQUFhLFdBQVU7ZUFBOUI7TUFBa0Y7TUFDbEUsd0JBQUMsTUFBRCxDQUFLOzs7OztNQUFDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFlO01BQWtCOzs7OztLQUNuRTs7Ozs7O0lBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBd0Q7SUFFbEU7Ozs7O0lBQ0gsd0JBQUMsS0FBRDtLQUFHLE1BQUs7S0FBWSxXQUFXLGVBQWUsRUFBRSxXQUFXLDRCQUE0QixDQUFDO2VBQXhGLENBQTJGLGtCQUMzRSx3QkFBQyxXQUFELEVBQVcsZUFBWSxPQUFROzs7O2FBQzVDOzs7Ozs7R0FDQTs7Ozs7WUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNaLFNBQVMsV0FBVyxZQUNuQixnREFBRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtJQUFVLE1BQUs7Y0FBUztHQUF5Qjs7OzthQUFDLHdCQUFDLFVBQUQ7SUFBVSxlQUFZO0lBQU8sV0FBVTtHQUEwQjs7OztXQUFHOzs7O2NBQ3RJLFNBQVMsV0FBVyxhQUFhLFNBQVMsT0FDNUMsd0JBQUMsTUFBRDtJQUFNLElBQUc7SUFBZSxRQUFRLEVBQUUsT0FBTyxTQUFTLEtBQUssSUFBSSxHQUFHO0lBQUcsV0FBVTtjQUEzRSxDQUNHLFNBQVMsS0FBSyxJQUFJLE1BQU0sTUFDdkIsd0JBQUMsT0FBRDtLQUFLLEtBQUssU0FBUyxLQUFLLElBQUksTUFBTTtLQUFLLEtBQUssU0FBUyxLQUFLLElBQUksTUFBTTtLQUFLLE9BQU07S0FBTSxRQUFPO0tBQU0sV0FBVTtJQUEwQjs7OztlQUV0SSx3QkFBQyxPQUFEO0tBQUssTUFBSztLQUFNLGNBQVksU0FBUyxLQUFLLElBQUksTUFBTTtLQUFLLFdBQVU7ZUFBbkUsQ0FDRSx3QkFBQyxVQUFEO01BQVUsZUFBWTtNQUFPLFdBQVU7S0FBVTs7OztlQUFDLHdCQUFDLFFBQUQsWUFBTSw2QkFBZ0M7Ozs7YUFDckY7Ozs7O2NBRVAsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBYSxTQUFTLEtBQUssSUFBSTtLQUFTOzs7O2VBQ3pELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFzQyxTQUFTLEtBQUs7S0FBZTs7OzthQUM3RTs7OztlQUNMLHdCQUFDLGNBQUQ7TUFBYyxlQUFZO01BQU8sV0FBVTtLQUFnQzs7OzthQUN4RTs7Ozs7WUFDRDs7Ozs7Y0FFTix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUFVLGVBQVk7S0FBTyxXQUFVO0lBQVU7Ozs7Y0FDakQsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBVyxTQUFTLFdBQVcsVUFBVSxTQUFTLFVBQVU7SUFBMkI7Ozs7WUFDakc7Ozs7OztFQUVKOzs7O1VBQ0U7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImhlcm8udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZURlc2t0b3AgfSBmcm9tICdAL2xpYi91c2UtZGVza3RvcCdcbmltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgQXJyb3dEb3duLCBBcnJvd1VwUmlnaHQsIEltYWdlT2ZmIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgYnV0dG9uVmFyaWFudHMgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2tlbGV0b24nXG5pbXBvcnQgdHlwZSB7IEZlYXR1cmVkTmZ0LCBSZW1vdGVEYXRhIH0gZnJvbSAnLi4vdHlwZXMnXG5cbmV4cG9ydCBmdW5jdGlvbiBIZXJvKHsgZmVhdHVyZWQgfTogeyBmZWF0dXJlZDogUmVtb3RlRGF0YTxGZWF0dXJlZE5mdCB8IG51bGw+IH0pIHtcbiAgY29uc3QgZGVza3RvcCA9IHVzZURlc2t0b3AoKVxuICBpZiAoZGVza3RvcCkgcmV0dXJuIChcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImRlc2t0b3AtaG9tZS1oZXJvIGRlc2t0b3AtaG9tZS1vbmx5XCIgYXJpYS1sYWJlbGxlZGJ5PVwiZGVza3RvcC1oZXJvLXRpdGxlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVza3RvcC1oZXJvLWNvcHlcIj5cbiAgICAgICAgICA8cD5CZW0tdmluZG8gw6AgS3VyaW88L3A+XG4gICAgICAgICAgPGgxIGlkPVwiZGVza3RvcC1oZXJvLXRpdGxlXCI+U0VKQSBET05PIERPIEZVVFVSTzxiciAvPkRBIEFSVEUgRElHSVRBTDwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZGVza3RvcC1oZXJvLWRlc2NyaXB0aW9uXCI+RGVzY3VicmEgTkZUcyBzZWxlY2lvbmFkb3MgZGUgY3JpYWRvcmVzIGVtZXJnZW50ZXMgZSBjb25zYWdyYWRvcy48YnIgLz5Db2xlY2lvbmUgYXJ0ZSBkaWdpdGFsIHJhcmEsIGFwb2llIGFydGlzdGFzIGUgdGVuaGEgdW1hIHBhcnRlIGRhPGJyIC8+Y3VsdHVyYSBkYSBpbnRlcm5ldC48L3A+XG4gICAgICAgICAgPGEgaHJlZj1cIiNjYXRhbG9nb1wiIGNsYXNzTmFtZT17YnV0dG9uVmFyaWFudHMoeyBjbGFzc05hbWU6ICdkZXNrdG9wLWV4cGxvcmUnIH0pfT5FWFBMT1JBUjwvYT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJhbm5lci1pbmRpY2F0b3JzXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PHNwYW4gLz48c3BhbiAvPjxzcGFuIC8+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cGljdHVyZT48c291cmNlIG1lZGlhPVwiKG1pbi13aWR0aDogMTAyNHB4KVwiIHNyY1NldD1cIi9hc3NldHMvZmlnbWEvaG9tZS9lbWVyYWxkLWFwZS53ZWJwXCIgLz48aW1nIHNyYz1cImRhdGE6aW1hZ2UvZ2lmO2Jhc2U2NCxSMGxHT0RsaEFRQUJBQUQvQUN3QUFBQUFBUUFCQUFBQ0FEcz1cIiBhbHQ9XCJNYWNhY28gY29tIGphcXVldGEgdmVyZGUgZSDDs2N1bG9zLCBhcnRlIG9yaWdpbmFsIEt1cmlvXCIgd2lkdGg9XCI0NTBcIiBoZWlnaHQ9XCI0NTBcIiBmZXRjaFByaW9yaXR5PVwiaGlnaFwiIC8+PC9waWN0dXJlPlxuICAgICAgPC9zZWN0aW9uPlxuICApXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwia3VyaW8taGVybyBsZWdhY3ktaGVyb1wiIGFyaWEtbGFiZWxsZWRieT1cImhlcm8tdGl0bGVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1jb3B5XCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLVswLjJlbV0gdGV4dC1wcmltYXJ5XCI+S3VyaW8gwrcgTkZUIE1hcmtldHBsYWNlPC9wPlxuICAgICAgICA8aDEgaWQ9XCJoZXJvLXRpdGxlXCIgY2xhc3NOYW1lPVwibXQtNiB0ZXh0LTR4bCBsZWFkaW5nLXRpZ2h0IGZvbnQtYm9sZCBzbTp0ZXh0LTV4bFwiPlxuICAgICAgICAgIERlc2N1YnJhIG8gc2V1PGJyIC8+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCI+cHLDs3hpbW8gTkZULjwvc3Bhbj5cbiAgICAgICAgPC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNiBtYXgtdy1tZCB0ZXh0LXNtIGxlYWRpbmctNyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICBFeHBsb3JlIG8gdW5pdmVyc28gZG9zIGNvbGVjaW9uw6F2ZWlzIGRpZ2l0YWlzLlxuICAgICAgICA8L3A+XG4gICAgICAgIDxhIGhyZWY9XCIjY2F0YWxvZ29cIiBjbGFzc05hbWU9e2J1dHRvblZhcmlhbnRzKHsgY2xhc3NOYW1lOiAnbXQtOCBoLTEyIHJvdW5kZWQtc20gcHgtNicgfSl9PlxuICAgICAgICAgIEV4cGxvcmFyIE5GVHMgPEFycm93RG93biBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICA8L2E+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1hcnRcIj5cbiAgICAgICAge2ZlYXR1cmVkLnN0YXR1cyA9PT0gJ2xvYWRpbmcnID8gKFxuICAgICAgICAgIDw+PHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiIHJvbGU9XCJzdGF0dXNcIj5DYXJyZWdhbmRvIGRlc3RhcXVlPC9zcGFuPjxTa2VsZXRvbiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJzaXplLWZ1bGwgcm91bmRlZC1ub25lXCIgLz48Lz5cbiAgICAgICAgKSA6IGZlYXR1cmVkLnN0YXR1cyA9PT0gJ3N1Y2Nlc3MnICYmIGZlYXR1cmVkLmRhdGEgPyAoXG4gICAgICAgICAgPExpbmsgdG89XCIvbmZ0cy8kbmZ0SWRcIiBwYXJhbXM9e3sgbmZ0SWQ6IGZlYXR1cmVkLmRhdGEubmZ0LmlkIH19IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJsb2NrIHNpemUtZnVsbFwiPlxuICAgICAgICAgICAge2ZlYXR1cmVkLmRhdGEubmZ0LmltYWdlLnNyYyA/IChcbiAgICAgICAgICAgICAgPGltZyBzcmM9e2ZlYXR1cmVkLmRhdGEubmZ0LmltYWdlLnNyY30gYWx0PXtmZWF0dXJlZC5kYXRhLm5mdC5pbWFnZS5hbHR9IHdpZHRoPVwiNDUwXCIgaGVpZ2h0PVwiNDUwXCIgY2xhc3NOYW1lPVwic2l6ZS1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8ZGl2IHJvbGU9XCJpbWdcIiBhcmlhLWxhYmVsPXtmZWF0dXJlZC5kYXRhLm5mdC5pbWFnZS5hbHR9IGNsYXNzTmFtZT1cIm5mdC1hcnQtcGxhY2Vob2xkZXIgc2l6ZS1mdWxsXCI+XG4gICAgICAgICAgICAgICAgPEltYWdlT2ZmIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInNpemUtOFwiIC8+PHNwYW4+QXJ0ZSBvcmlnaW5hbCBpbmRpc3BvbsOtdmVsPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXgtMCBib3R0b20tMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgYmctYmFja2dyb3VuZC85NSBwLTVcIj5cbiAgICAgICAgICAgICAgPGRpdj48aDIgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e2ZlYXR1cmVkLmRhdGEubmZ0Lm5hbWV9PC9oMj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2ZlYXR1cmVkLmRhdGEuZGVzY3JpcHRpb259PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJzaXplLTUgc2hyaW5rLTAgdGV4dC1wcmltYXJ5XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc2l6ZS1mdWxsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNCBib3JkZXIgYm9yZGVyLWRhc2hlZCBwLTggdGV4dC1jZW50ZXIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICA8SW1hZ2VPZmYgYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwic2l6ZS04XCIgLz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj57ZmVhdHVyZWQuc3RhdHVzID09PSAnZXJyb3InID8gZmVhdHVyZWQubWVzc2FnZSA6ICdEZXN0YXF1ZSBpbmRpc3BvbsOtdmVsJ308L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gIClcbn1cbiJdfQ==