import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/home-page.tsx");const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import { useDesktop } from "/src/lib/use-desktop.ts";
import { HomeEditorial, HomeSpotlight } from "/src/features/catalog/components/home-editorial.tsx";
import { Hero } from "/src/features/catalog/components/hero.tsx?t=1793942929469";
import { CatalogFilters } from "/src/features/catalog/components/catalog-filters.tsx";
import { CatalogToolbar } from "/src/features/catalog/components/catalog-toolbar.tsx?t=1793942997333";
import { CatalogGrid } from "/src/features/catalog/components/catalog-grid.tsx";
import { CatalogPagination } from "/src/features/catalog/components/catalog-pagination.tsx";
import { defaultCatalogSearch } from "/src/contracts/catalog.ts";
import { Button } from "/src/components/ui/button.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/home-page.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function HomePage({ catalog = { status: "unavailable" }, featured = { status: "unavailable" }, controls, onRetry, onRefresh, updating = false, options }) {
	_s();
	const desktop = useDesktop();
	const filters = controls?.filters ?? defaultCatalogSearch;
	const onFiltersChange = (value) => controls?.onFiltersChange(value);
	const onPageChange = (page) => controls?.onPageChange(page);
	const data = catalog.status === "success" ? catalog.data : undefined;
	const disabled = !controls;
	const filterProps = {
		filters,
		onFiltersChange,
		collections: data?.collections ?? options?.collections ?? [],
		networks: data?.networks ?? options?.networks ?? [],
		disabled,
		facets: data?.facets
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-16 pb-16",
		children: [
			/* @__PURE__ */ _jsxDEV(Hero, { featured }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "catalogo",
				"aria-labelledby": "catalog-title",
				className: "catalog-layout scroll-mt-6",
				children: [/* @__PURE__ */ _jsxDEV("aside", {
					"aria-label": "Filtros do catálogo",
					className: "desktop-filters",
					children: [/* @__PURE__ */ _jsxDEV(CatalogFilters, { ...filterProps }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 77
					}, this), desktop && /* @__PURE__ */ _jsxDEV(HomeSpotlight, { nft: data?.items.find((nft) => nft.availability.status === "available") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 124
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ _jsxDEV("details", {
							className: "mobile-filters mb-6 rounded-sm border p-4",
							children: [/* @__PURE__ */ _jsxDEV("summary", {
								className: "cursor-pointer text-sm font-medium",
								children: "Filtrar NFTs"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pt-5",
								children: /* @__PURE__ */ _jsxDEV(CatalogFilters, { ...filterProps }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 45,
									columnNumber: 35
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(CatalogToolbar, {
							total: data?.total,
							filters,
							onFiltersChange,
							disabled
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "catalog-refresh mt-4 flex min-h-9 items-center justify-between gap-4",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								"aria-live": "polite",
								className: "text-xs text-muted-foreground",
								children: updating ? "Atualizando catálogo…" : ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 13
							}, this), onRefresh && /* @__PURE__ */ _jsxDEV(Button, {
								variant: "link",
								disabled: updating,
								onClick: onRefresh,
								children: "Atualizar catálogo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 27
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "catalog-results py-8",
							"aria-busy": updating,
							children: /* @__PURE__ */ _jsxDEV(CatalogGrid, {
								catalog,
								onRetry
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 52,
								columnNumber: 70
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(CatalogPagination, {
							page: data?.page,
							pageCount: data?.pageCount,
							disabled: updating,
							onPageChange
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 7
			}, this),
			desktop && /* @__PURE__ */ _jsxDEV(HomeEditorial, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 19
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_s(HomePage, "8bC77epNsaDPkYpxNVwjV1y7/9Q=", false, function() {
	return [useDesktop];
});
_c = HomePage;
var _c;
$RefreshReg$(_c, "HomePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/home-page.tsx?t=1793942997333";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/home-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/home-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/home-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxlQUFlLHFCQUFxQjtBQUM3QyxTQUFTLFlBQVk7QUFDckIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx5QkFBeUI7QUFFbEMsU0FBUyw0QkFBNEI7QUFDckMsU0FBUyxjQUFjOzs7O0FBYXZCLE9BQU8sU0FBUyxTQUFTLEVBQ3ZCLFVBQVUsRUFBRSxRQUFRLGNBQWMsR0FDbEMsV0FBVyxFQUFFLFFBQVEsY0FBYyxHQUNuQyxVQUNBLFNBQVMsV0FBVyxXQUFXLE9BQU8sV0FDdEI7O0NBQ2hCLE1BQU0sVUFBVSxXQUFXO0NBQzNCLE1BQU0sVUFBVSxVQUFVLFdBQVc7Q0FDckMsTUFBTSxtQkFBc0QsVUFBUyxVQUFVLGdCQUFnQixLQUFLO0NBQ3BHLE1BQU0sZ0JBQWdCLFNBQWlCLFVBQVUsYUFBYSxJQUFJO0NBQ2xFLE1BQU0sT0FBTyxRQUFRLFdBQVcsWUFBWSxRQUFRLE9BQU87Q0FDM0QsTUFBTSxXQUFXLENBQUM7Q0FDbEIsTUFBTSxjQUFjO0VBQUU7RUFBUztFQUFpQixhQUFhLE1BQU0sZUFBZSxTQUFTLGVBQWUsQ0FBQztFQUFHLFVBQVUsTUFBTSxZQUFZLFNBQVMsWUFBWSxDQUFDO0VBQUc7RUFBVSxRQUFRLE1BQU07Q0FBTztDQUVsTSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxNQUFELEVBQWdCLFNBQVc7Ozs7O0dBQzNCLHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQVcsbUJBQWdCO0lBQWdCLFdBQVU7Y0FBakUsQ0FDRSx3QkFBQyxTQUFEO0tBQU8sY0FBVztLQUFzQixXQUFVO2VBQWxELENBQW9FLHdCQUFDLGdCQUFELEVBQWdCLEdBQUksWUFBYzs7OztlQUFFLFdBQVcsd0JBQUMsZUFBRCxFQUFlLEtBQUssTUFBTSxNQUFNLE1BQUssUUFBTyxJQUFJLGFBQWEsV0FBVyxXQUFXLEVBQUk7Ozs7YUFBUzs7Ozs7Y0FDbk4sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFdBQUQ7T0FBUyxXQUFVO2lCQUFuQixDQUNFLHdCQUFDLFdBQUQ7UUFBUyxXQUFVO2tCQUFxQztPQUFxQjs7OztpQkFDN0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQU8sd0JBQUMsZ0JBQUQsRUFBZ0IsR0FBSSxZQUFjOzs7OztPQUFNOzs7O2VBQ3ZEOzs7Ozs7TUFDVCx3QkFBQyxnQkFBRDtPQUFnQixPQUFPLE1BQU07T0FBZ0I7T0FBMEI7T0FBMkI7TUFBVzs7Ozs7TUFDN0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsTUFBSztRQUFTLGFBQVU7UUFBUyxXQUFVO2tCQUFpQyxXQUFXLDBCQUEwQjtPQUFNOzs7O2lCQUN6SCxhQUFhLHdCQUFDLFFBQUQ7UUFBUSxTQUFRO1FBQU8sVUFBVTtRQUFVLFNBQVM7a0JBQVc7T0FBMEI7Ozs7ZUFDcEc7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQXVCLGFBQVc7aUJBQVUsd0JBQUMsYUFBRDtRQUFzQjtRQUFrQjtPQUFVOzs7OztNQUFNOzs7OztNQUNuSCx3QkFBQyxtQkFBRDtPQUFtQixNQUFNLE1BQU07T0FBTSxXQUFXLE1BQU07T0FBVyxVQUFVO09BQzNEO01BQWU7Ozs7O0tBQzVCOzs7OztZQUNFOzs7Ozs7R0FDUixXQUFXLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O0VBQ3pCOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJob21lLXBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZURlc2t0b3AgfSBmcm9tICdAL2xpYi91c2UtZGVza3RvcCdcbmltcG9ydCB7IEhvbWVFZGl0b3JpYWwsIEhvbWVTcG90bGlnaHQgfSBmcm9tICcuL2NvbXBvbmVudHMvaG9tZS1lZGl0b3JpYWwnXG5pbXBvcnQgeyBIZXJvIH0gZnJvbSAnLi9jb21wb25lbnRzL2hlcm8nXG5pbXBvcnQgeyBDYXRhbG9nRmlsdGVycyB9IGZyb20gJy4vY29tcG9uZW50cy9jYXRhbG9nLWZpbHRlcnMnXG5pbXBvcnQgeyBDYXRhbG9nVG9vbGJhciB9IGZyb20gJy4vY29tcG9uZW50cy9jYXRhbG9nLXRvb2xiYXInXG5pbXBvcnQgeyBDYXRhbG9nR3JpZCB9IGZyb20gJy4vY29tcG9uZW50cy9jYXRhbG9nLWdyaWQnXG5pbXBvcnQgeyBDYXRhbG9nUGFnaW5hdGlvbiB9IGZyb20gJy4vY29tcG9uZW50cy9jYXRhbG9nLXBhZ2luYXRpb24nXG5pbXBvcnQgdHlwZSB7IENvbGxlY3Rpb24sIE5ldHdvcmsgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnXG5pbXBvcnQgeyBkZWZhdWx0Q2F0YWxvZ1NlYXJjaCB9IGZyb20gJ0AvY29udHJhY3RzL2NhdGFsb2cnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHR5cGUgeyBDYXRhbG9nQ29udHJvbHMsIENhdGFsb2dQYWdlLCBGZWF0dXJlZE5mdCwgUmVtb3RlRGF0YSB9IGZyb20gJy4vdHlwZXMnXG5cbmludGVyZmFjZSBIb21lUGFnZVByb3BzIHtcbiAgY2F0YWxvZz86IFJlbW90ZURhdGE8Q2F0YWxvZ1BhZ2U+XG4gIGZlYXR1cmVkPzogUmVtb3RlRGF0YTxGZWF0dXJlZE5mdCB8IG51bGw+XG4gIGNvbnRyb2xzPzogQ2F0YWxvZ0NvbnRyb2xzXG4gIG9uUmV0cnk/OiAoKSA9PiB2b2lkXG4gIG9uUmVmcmVzaD86ICgpID0+IHZvaWRcbiAgdXBkYXRpbmc/OiBib29sZWFuXG4gIG9wdGlvbnM/OiB7IGNvbGxlY3Rpb25zOiBDb2xsZWN0aW9uW107IG5ldHdvcmtzOiBOZXR3b3JrW10gfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gSG9tZVBhZ2Uoe1xuICBjYXRhbG9nID0geyBzdGF0dXM6ICd1bmF2YWlsYWJsZScgfSxcbiAgZmVhdHVyZWQgPSB7IHN0YXR1czogJ3VuYXZhaWxhYmxlJyB9LFxuICBjb250cm9scyxcbiAgb25SZXRyeSwgb25SZWZyZXNoLCB1cGRhdGluZyA9IGZhbHNlLCBvcHRpb25zLFxufTogSG9tZVBhZ2VQcm9wcykge1xuICBjb25zdCBkZXNrdG9wID0gdXNlRGVza3RvcCgpXG4gIGNvbnN0IGZpbHRlcnMgPSBjb250cm9scz8uZmlsdGVycyA/PyBkZWZhdWx0Q2F0YWxvZ1NlYXJjaFxuICBjb25zdCBvbkZpbHRlcnNDaGFuZ2U6IENhdGFsb2dDb250cm9sc1snb25GaWx0ZXJzQ2hhbmdlJ10gPSB2YWx1ZSA9PiBjb250cm9scz8ub25GaWx0ZXJzQ2hhbmdlKHZhbHVlKVxuICBjb25zdCBvblBhZ2VDaGFuZ2UgPSAocGFnZTogbnVtYmVyKSA9PiBjb250cm9scz8ub25QYWdlQ2hhbmdlKHBhZ2UpXG4gIGNvbnN0IGRhdGEgPSBjYXRhbG9nLnN0YXR1cyA9PT0gJ3N1Y2Nlc3MnID8gY2F0YWxvZy5kYXRhIDogdW5kZWZpbmVkXG4gIGNvbnN0IGRpc2FibGVkID0gIWNvbnRyb2xzXG4gIGNvbnN0IGZpbHRlclByb3BzID0geyBmaWx0ZXJzLCBvbkZpbHRlcnNDaGFuZ2UsIGNvbGxlY3Rpb25zOiBkYXRhPy5jb2xsZWN0aW9ucyA/PyBvcHRpb25zPy5jb2xsZWN0aW9ucyA/PyBbXSwgbmV0d29ya3M6IGRhdGE/Lm5ldHdvcmtzID8/IG9wdGlvbnM/Lm5ldHdvcmtzID8/IFtdLCBkaXNhYmxlZCwgZmFjZXRzOiBkYXRhPy5mYWNldHMgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTE2IHBiLTE2XCI+XG4gICAgICA8SGVybyBmZWF0dXJlZD17ZmVhdHVyZWR9IC8+XG4gICAgICA8c2VjdGlvbiBpZD1cImNhdGFsb2dvXCIgYXJpYS1sYWJlbGxlZGJ5PVwiY2F0YWxvZy10aXRsZVwiIGNsYXNzTmFtZT1cImNhdGFsb2ctbGF5b3V0IHNjcm9sbC1tdC02XCI+XG4gICAgICAgIDxhc2lkZSBhcmlhLWxhYmVsPVwiRmlsdHJvcyBkbyBjYXTDoWxvZ29cIiBjbGFzc05hbWU9XCJkZXNrdG9wLWZpbHRlcnNcIj48Q2F0YWxvZ0ZpbHRlcnMgey4uLmZpbHRlclByb3BzfSAvPntkZXNrdG9wICYmIDxIb21lU3BvdGxpZ2h0IG5mdD17ZGF0YT8uaXRlbXMuZmluZChuZnQgPT4gbmZ0LmF2YWlsYWJpbGl0eS5zdGF0dXMgPT09ICdhdmFpbGFibGUnKX0gLz59PC9hc2lkZT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwibW9iaWxlLWZpbHRlcnMgbWItNiByb3VuZGVkLXNtIGJvcmRlciBwLTRcIj5cbiAgICAgICAgICAgIDxzdW1tYXJ5IGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQtc20gZm9udC1tZWRpdW1cIj5GaWx0cmFyIE5GVHM8L3N1bW1hcnk+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTVcIj48Q2F0YWxvZ0ZpbHRlcnMgey4uLmZpbHRlclByb3BzfSAvPjwvZGl2PlxuICAgICAgICAgIDwvZGV0YWlscz5cbiAgICAgICAgICA8Q2F0YWxvZ1Rvb2xiYXIgdG90YWw9e2RhdGE/LnRvdGFsfSBmaWx0ZXJzPXtmaWx0ZXJzfSBvbkZpbHRlcnNDaGFuZ2U9e29uRmlsdGVyc0NoYW5nZX0gZGlzYWJsZWQ9e2Rpc2FibGVkfSAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZy1yZWZyZXNoIG10LTQgZmxleCBtaW4taC05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPnt1cGRhdGluZyA/ICdBdHVhbGl6YW5kbyBjYXTDoWxvZ2/igKYnIDogJyd9PC9wPlxuICAgICAgICAgICAge29uUmVmcmVzaCAmJiA8QnV0dG9uIHZhcmlhbnQ9XCJsaW5rXCIgZGlzYWJsZWQ9e3VwZGF0aW5nfSBvbkNsaWNrPXtvblJlZnJlc2h9PkF0dWFsaXphciBjYXTDoWxvZ288L0J1dHRvbj59XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRhbG9nLXJlc3VsdHMgcHktOFwiIGFyaWEtYnVzeT17dXBkYXRpbmd9PjxDYXRhbG9nR3JpZCBjYXRhbG9nPXtjYXRhbG9nfSBvblJldHJ5PXtvblJldHJ5fSAvPjwvZGl2PlxuICAgICAgICAgIDxDYXRhbG9nUGFnaW5hdGlvbiBwYWdlPXtkYXRhPy5wYWdlfSBwYWdlQ291bnQ9e2RhdGE/LnBhZ2VDb3VudH0gZGlzYWJsZWQ9e3VwZGF0aW5nfVxuICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtvblBhZ2VDaGFuZ2V9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgICAge2Rlc2t0b3AgJiYgPEhvbWVFZGl0b3JpYWwgLz59XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==