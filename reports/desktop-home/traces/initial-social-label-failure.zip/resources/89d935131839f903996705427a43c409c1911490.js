import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=22c23eb4";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=22c23eb4";
// node_modules/react-hook-form/dist/index.esm.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var isCheckBoxInput = (element) => element.type === "checkbox";
var isFileInput = (element) => element.type === "file";
var isDateObject = (value) => value instanceof Date;
var isNullOrUndefined = (value) => value == null;
var isObjectType = (value) => typeof value === "object";
var isObject = (value) => !isNullOrUndefined(value) && !Array.isArray(value) && isObjectType(value) && !isDateObject(value);
var getEventValue = (event) => isObject(event) && event.target ? isCheckBoxInput(event.target) ? event.target.checked : isFileInput(event.target) ? event.target.files : event.target.value : event;
var FIELD_PATH_RE = /[.[\]'"]/;
var stringToPath = (input) => input.split(FIELD_PATH_RE).filter(Boolean);
function getNullAncestorValue(control, name) {
	const segments = stringToPath(name);
	let formValues = control._formValues;
	let defaultValues = control._defaultValues;
	for (let i = 0; i < segments.length - 1; i++) {
		const key = segments[i];
		formValues = formValues == null ? formValues : formValues[key];
		defaultValues = defaultValues == null ? defaultValues : defaultValues[key];
		if (formValues === null || defaultValues === null) return null;
	}
}
var isNameInFieldArray = (names, name) => name.split(".").some((part, index, arr) => !isNaN(Number(part)) && names.has(arr.slice(0, index).join(".")));
var isWeb = typeof window !== "undefined" && typeof window.HTMLElement !== "undefined" && typeof document !== "undefined";
function cloneObject(data) {
	if (data === null || typeof data !== "object") return data;
	if (data instanceof Date) return new Date(data);
	const isBlobInstance = typeof Blob !== "undefined" && data instanceof Blob;
	const isFileListInstance = typeof FileList !== "undefined" && data instanceof FileList;
	if (isWeb && (isBlobInstance || isFileListInstance)) return data;
	const isArray = Array.isArray(data);
	const prototype = Object.getPrototypeOf(data);
	if (!isArray && prototype && prototype.constructor !== Object) return data;
	const copy = isArray ? new Array(data.length) : Object.create(prototype);
	for (const key in data) if (Object.prototype.hasOwnProperty.call(data, key)) copy[key] = cloneObject(data[key]);
	return copy;
}
var EVENTS = {
	BLUR: "blur",
	FOCUS_OUT: "focusout",
	CHANGE: "change",
	SUBMIT: "submit",
	TRIGGER: "trigger",
	VALID: "valid"
};
var VALIDATION_MODE = {
	onBlur: "onBlur",
	onChange: "onChange",
	onSubmit: "onSubmit",
	onTouched: "onTouched",
	all: "all"
};
var INPUT_VALIDATION_RULES = {
	max: "max",
	min: "min",
	maxLength: "maxLength",
	minLength: "minLength",
	pattern: "pattern",
	required: "required",
	validate: "validate"
};
var REGISTER_VALIDATION_RULES = [
	INPUT_VALIDATION_RULES.required,
	INPUT_VALIDATION_RULES.min,
	INPUT_VALIDATION_RULES.max,
	INPUT_VALIDATION_RULES.minLength,
	INPUT_VALIDATION_RULES.maxLength,
	INPUT_VALIDATION_RULES.pattern,
	INPUT_VALIDATION_RULES.validate
];
var FORM_ERROR_TYPE = "form";
var ROOT_ERROR_TYPE = "root";
var PROTOTYPE_KEYWORDS = [
	"__proto__",
	"constructor",
	"prototype"
];
var IS_KEY_RE = /^\w*$/;
var isKey = (value) => IS_KEY_RE.test(value);
var isUndefined = (val) => val === void 0;
var get = (object, path, defaultValue) => {
	if (!path || !isObject(object)) return defaultValue;
	const paths = isKey(path) ? [path] : stringToPath(path);
	if (paths.some((key) => PROTOTYPE_KEYWORDS.includes(key))) return defaultValue;
	const result = paths.reduce((result, key) => {
		return isNullOrUndefined(result) ? void 0 : result[key];
	}, object);
	return isUndefined(result) || result === object ? isUndefined(object[path]) ? defaultValue : object[path] : result;
};
var isBoolean = (value) => typeof value === "boolean";
var isFunction = (value) => typeof value === "function";
var set = (object, path, value) => {
	let index = -1;
	const tempPath = isKey(path) ? [path] : stringToPath(path);
	const length = tempPath.length;
	const lastIndex = length - 1;
	while (++index < length) {
		const key = tempPath[index];
		let newValue = value;
		if (index !== lastIndex) {
			const objValue = object[key];
			newValue = isObject(objValue) || Array.isArray(objValue) ? objValue : !isNaN(+tempPath[index + 1]) ? [] : {};
		}
		if (PROTOTYPE_KEYWORDS.includes(key)) return;
		object[key] = newValue;
		object = object[key];
	}
};
/**
* Separate context for `control` to prevent unnecessary rerenders.
* Internal hooks that only need control use this instead of full form context.
*/
var HookFormControlContext = import_react.createContext(null);
HookFormControlContext.displayName = "HookFormControlContext";
/**
* @internal Internal hook to access only control from context.
*/
var useFormControlContext = () => import_react.useContext(HookFormControlContext);
var getProxyFormState = (formState, control, localProxyFormState, isRoot = true) => {
	const result = {};
	for (const key in formState) Object.defineProperty(result, key, { get: () => {
		const _key = key;
		if (control._proxyFormState[_key] !== VALIDATION_MODE.all) control._proxyFormState[_key] = !isRoot || VALIDATION_MODE.all;
		localProxyFormState && (localProxyFormState[_key] = true);
		return formState[_key];
	} });
	return result;
};
var useIsomorphicLayoutEffect = isWeb ? import_react.useLayoutEffect : import_react.useEffect;
var isPlainObject = (tempObject) => {
	const prototypeCopy = tempObject.constructor && tempObject.constructor.prototype;
	return isObject(prototypeCopy) && prototypeCopy.hasOwnProperty("isPrototypeOf");
};
var isPrimitive = (value) => isNullOrUndefined(value) || !isObjectType(value);
var isEmptyObjectWithCustomPrototype = (object, keys) => keys.length === 0 && !Array.isArray(object) && Object.getPrototypeOf(object) !== null && !isPlainObject(object);
function deepEqual(object1, object2, isErrorObject = false, visited = /* @__PURE__ */ new WeakMap()) {
	if (object1 === object2) return true;
	if (isPrimitive(object1) || isPrimitive(object2)) return Object.is(object1, object2);
	if (isDateObject(object1) && isDateObject(object2)) return Object.is(object1.getTime(), object2.getTime());
	if (Array.isArray(object1) && Array.isArray(object2) && object1.length !== object2.length) return false;
	const keys1 = Object.keys(object1);
	const keys2 = Object.keys(object2);
	if (keys1.length !== keys2.length) return false;
	if (isEmptyObjectWithCustomPrototype(object1, keys1) || isEmptyObjectWithCustomPrototype(object2, keys2)) return Object.is(object1, object2);
	if (!keys1.length && Array.isArray(object1) !== Array.isArray(object2)) return false;
	const visitedPairs = visited.get(object1);
	if (visitedPairs && visitedPairs.has(object2)) return true;
	if (visitedPairs) visitedPairs.add(object2);
	else {
		const ws = /* @__PURE__ */ new WeakSet();
		ws.add(object2);
		visited.set(object1, ws);
	}
	for (const key of keys1) {
		const val1 = object1[key];
		if (!Object.prototype.hasOwnProperty.call(object2, key)) return false;
		if (!isErrorObject || key !== "ref") {
			const val2 = object2[key];
			if (isDateObject(val1) && isDateObject(val2) || (isObject(val1) || Array.isArray(val1)) && (isObject(val2) || Array.isArray(val2)) ? !deepEqual(val1, val2, isErrorObject, visited) : !Object.is(val1, val2)) return false;
		}
	}
	return true;
}
function useResyncOnReconnect(getInitialValue) {
	const _connected = import_react.useRef(false);
	const _initialized = import_react.useRef(false);
	const _prevValue = import_react.useRef(void 0);
	const _renderCount = import_react.useRef(0);
	_renderCount.current++;
	if (!_initialized.current && getInitialValue) {
		_initialized.current = true;
		_prevValue.current = cloneObject(getInitialValue());
	}
	return {
		resyncIfNeeded: import_react.useCallback((enabled, getCurrentValue, setValue) => {
			if (enabled && (_connected.current || _initialized.current && _renderCount.current > 1)) {
				const currentValue = getCurrentValue();
				if (!deepEqual(_prevValue.current, currentValue)) setValue(currentValue);
			}
			_connected.current = true;
		}, []),
		snapshot: import_react.useCallback((enabled, getCurrentValue) => {
			if (enabled) _prevValue.current = cloneObject(getCurrentValue());
		}, [])
	};
}
/**
* Subscribes to form state with re-renders isolated to this hook.
* Optionally scope to specific field names to minimize re-render surface.
*
* @see [API](https://react-hook-form.com/docs/useformstate)
*
* @example
* ```tsx
* const { errors, isDirty } = useFormState({ control, name: "email" });
* ```
*/
function useFormState(props) {
	const formControl = useFormControlContext();
	const { control = formControl, disabled, name, exact } = props || {};
	const getCurrentFormState = () => ({
		...control._formState,
		defaultValues: control._defaultValues
	});
	const [formState, updateFormState] = import_react.useState(getCurrentFormState);
	const _localProxyFormState = import_react.useRef({
		isDirty: false,
		isLoading: false,
		dirtyFields: false,
		touchedFields: false,
		validatingFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFormState);
	useIsomorphicLayoutEffect(() => {
		resyncIfNeeded(!disabled, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			name,
			formState: _localProxyFormState.current,
			exact,
			callback: (formState) => {
				!disabled && updateFormState({
					...control._formState,
					...formState,
					defaultValues: control._defaultValues
				});
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, getCurrentFormState);
		};
	}, [
		control,
		name,
		disabled,
		exact,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => {
		_localProxyFormState.current.isValid && control._setValid(true);
	}, [control]);
	return import_react.useMemo(() => getProxyFormState(formState, control, _localProxyFormState.current, false), [formState, control]);
}
var isString = (value) => typeof value === "string";
var generateWatchOutput = (names, _names, formValues, isGlobal, defaultValue) => {
	if (isString(names)) {
		isGlobal && _names.watch.add(names);
		return get(formValues, names, defaultValue);
	}
	if (Array.isArray(names)) return names.map((fieldName) => (isGlobal && _names.watch.add(fieldName), get(formValues, fieldName, get(defaultValue, fieldName))));
	isGlobal && (_names.watchAll = true);
	return formValues;
};
/**
* Subscribes to field value changes and isolates re-renders to the hook level.
*
* @see [API](https://react-hook-form.com/docs/usewatch)
*
* @example
* ```tsx
* const email = useWatch({ control, name: "email" });
* const all   = useWatch({ control });
* const adult = useWatch({ control, name: "age", compute: (v) => v >= 18 });
* ```
*/
function useWatch(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, defaultValue, disabled, exact, compute } = props || {};
	const _defaultValue = import_react.useRef(defaultValue);
	const _compute = import_react.useRef(compute);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	_compute.current = compute;
	const getInitialOutput = () => {
		const defaultValue = control._getWatch(name, _defaultValue.current);
		return _compute.current ? _compute.current(defaultValue) : defaultValue;
	};
	const [value, updateValue] = import_react.useState(getInitialOutput);
	const _computeFormValues = import_react.useRef(value);
	const getCurrentOutput = import_react.useCallback((values) => {
		const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
		return _compute.current ? _compute.current(formValues) : formValues;
	}, [
		control._formValues,
		control._names,
		name
	]);
	const refreshValue = import_react.useCallback((values) => {
		if (!disabled) {
			const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
			if (_compute.current) {
				const computedFormValues = _compute.current(formValues);
				if (!deepEqual(computedFormValues, _computeFormValues.current)) {
					updateValue(computedFormValues);
					_computeFormValues.current = computedFormValues;
				}
			} else updateValue(formValues);
		}
	}, [
		control._formValues,
		control._names,
		disabled,
		name
	]);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getInitialOutput);
	const _refreshValue = import_react.useRef(refreshValue);
	_refreshValue.current = refreshValue;
	const _getCurrentOutput = import_react.useRef(getCurrentOutput);
	_getCurrentOutput.current = getCurrentOutput;
	useIsomorphicLayoutEffect(() => {
		if (_prevControl.current !== control || !deepEqual(_prevName.current, name)) {
			_prevControl.current = control;
			_prevName.current = name;
			_refreshValue.current();
		} else resyncIfNeeded(!disabled, () => _getCurrentOutput.current(), (currentValue) => {
			const nextValue = cloneObject(currentValue);
			updateValue(nextValue);
			_computeFormValues.current = nextValue;
		});
		const unsubscribe = control._subscribe({
			name,
			formState: { values: true },
			exact,
			callback: (formState) => {
				_refreshValue.current(formState.values);
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, () => _getCurrentOutput.current());
		};
	}, [
		control,
		exact,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._removeUnmounted());
	const controlChanged = _prevControl.current !== control;
	const prevName = _prevName.current;
	const nameChanged = import_react.useMemo(() => !controlChanged && !deepEqual(prevName, name), [
		controlChanged,
		name,
		prevName
	]);
	if (controlChanged || nameChanged) _defaultValue.current = defaultValue;
	return !disabled && (controlChanged || nameChanged) ? getCurrentOutput() : value;
}
/**
* Hook for controlled inputs. Returns `field`, `fieldState`, and `formState`.
* Re-renders are isolated to the hook level.
*
* @see [API](https://react-hook-form.com/docs/usecontroller)
*
* @example
* ```tsx
* const { field, fieldState } = useController({ control, name: "email" });
* return <input {...field} />;
* ```
*/
function useController(props) {
	const formControl = useFormControlContext();
	const { name, disabled, control = formControl, shouldUnregister, defaultValue, exact = true } = props;
	const isArrayField = isNameInFieldArray(control._names.array, name);
	const value = useWatch({
		control,
		name,
		defaultValue: import_react.useMemo(() => {
			const resolved = get(control._formValues, name, get(control._defaultValues, name, defaultValue));
			return isUndefined(resolved) ? getNullAncestorValue(control, name) : resolved;
		}, [
			control,
			name,
			defaultValue
		]),
		exact
	});
	const formState = useFormState({
		control,
		name,
		exact
	});
	const _props = import_react.useRef(props);
	const _proxyRef = import_react.useRef(null);
	const _registerProps = import_react.useRef(control.register(name, {
		...props.rules,
		value,
		...isBoolean(props.disabled) ? { disabled: props.disabled } : {}
	}));
	_props.current = props;
	const fieldState = import_react.useMemo(() => Object.defineProperties({}, {
		invalid: {
			enumerable: true,
			get: () => !!get(formState.errors, name)
		},
		isDirty: {
			enumerable: true,
			get: () => !!get(formState.dirtyFields, name)
		},
		isTouched: {
			enumerable: true,
			get: () => !!get(formState.touchedFields, name)
		},
		isValidating: {
			enumerable: true,
			get: () => !!get(formState.validatingFields, name)
		},
		error: {
			enumerable: true,
			get: () => get(formState.errors, name)
		}
	}), [formState, name]);
	const onChange = import_react.useCallback((event) => {
		const value = getEventValue(event);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onChange({
			target: {
				value: getEventValue(event),
				name
			},
			type: EVENTS.CHANGE
		});
	}, [name, control]);
	const onBlur = import_react.useCallback(() => {
		const value = get(control._formValues, name);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onBlur({
			target: {
				value,
				name
			},
			type: EVENTS.BLUR
		});
	}, [name, control]);
	const ref = import_react.useCallback((elm) => {
		if (elm) _proxyRef.current = {
			focus: () => isFunction(elm.focus) && elm.focus(),
			select: () => isFunction(elm.select) && elm.select(),
			setCustomValidity: (message) => isFunction(elm.setCustomValidity) && elm.setCustomValidity(message),
			reportValidity: () => isFunction(elm.reportValidity) && elm.reportValidity()
		};
		const field = get(control._fields, name);
		if (field && field._f && elm) {
			field._f.ref = _proxyRef.current;
			field._f._c = true;
		}
	}, [control._fields, name]);
	const field = import_react.useMemo(() => ({
		name,
		value,
		...isBoolean(disabled) || formState.disabled ? { disabled: formState.disabled || disabled } : {},
		onChange,
		onBlur,
		ref
	}), [
		name,
		disabled,
		formState.disabled,
		onChange,
		onBlur,
		ref,
		value
	]);
	import_react.useEffect(() => {
		const _shouldUnregisterField = control._options.shouldUnregister || shouldUnregister;
		_registerProps.current = control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		const updateMounted = (name, value) => {
			const field = get(control._fields, name);
			if (field && field._f) {
				field._f.mount = value;
				field._f._c = value;
			}
		};
		updateMounted(name, true);
		if (_shouldUnregisterField) {
			const value = cloneObject(get(shouldUnregister ? control._defaultValues : control._options.values || control._defaultValues, name, get(control._options.defaultValues, name, _props.current.defaultValue)));
			set(control._defaultValues, name, value);
			if (isUndefined(get(control._formValues, name))) set(control._formValues, name, value);
		}
		!isArrayField && control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		if (_proxyRef.current) {
			const field = get(control._fields, name);
			if (field && field._f) field._f.ref = _proxyRef.current;
		}
		return () => {
			(isArrayField ? _shouldUnregisterField && !control._state.action : _shouldUnregisterField) ? control.unregister(name) : updateMounted(name, false);
		};
	}, [
		name,
		control,
		isArrayField,
		shouldUnregister
	]);
	import_react.useEffect(() => {
		control._setDisabledField({
			disabled,
			name
		});
	}, [
		disabled,
		name,
		control
	]);
	return import_react.useMemo(() => ({
		field,
		formState,
		fieldState
	}), [
		field,
		formState,
		fieldState
	]);
}
/**
* Component wrapper around `useController` for controlled inputs.
*
* @see [API](https://react-hook-form.com/docs/usecontroller/controller)
*
* @example
* ```tsx
* <Controller
*   control={control}
*   name="test"
*   render={({ field, fieldState, formState }) => <input {...field} />}
* />
* ```
*/
var Controller = (props) => props.render(useController(props));
/**
* Displays the validation error for a single field.
* Reads from `control` when provided, otherwise from the nearest `FormProvider`.
*
* @see [API](https://react-hook-form.com/docs/useformstate/errormessage)
*
* @example
* ```tsx
* <ErrorMessage control={control} name="email" as="p" />
* <ErrorMessage name="email" as="span" />
* <ErrorMessage control={control} name="email"
*   render={({ message }) => <Alert>{message}</Alert>} />
* ```
*/
var ErrorMessage = ({ as, control, name, render }) => {
	const { errors } = useFormState({
		control,
		name
	});
	const error = get(errors, name);
	if (!error) return null;
	const message = error.message || "";
	if (render) return render({
		message,
		messages: error.types
	});
	return import_react.createElement(as || import_react.Fragment, null, message);
};
var generateId = () => typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
	const r = Math.random() * 16 | 0;
	return (c === "x" ? r : r & 3 | 8).toString(16);
});
var getFocusFieldName = (name, index, options = {}) => options.shouldFocus || isUndefined(options.shouldFocus) ? options.focusName || `${name}.${isUndefined(options.focusIndex) ? index : options.focusIndex}.` : "";
var getValidationModes = (mode) => ({
	isOnSubmit: !mode || mode === VALIDATION_MODE.onSubmit,
	isOnBlur: mode === VALIDATION_MODE.onBlur,
	isOnChange: mode === VALIDATION_MODE.onChange,
	isOnAll: mode === VALIDATION_MODE.all,
	isOnTouch: mode === VALIDATION_MODE.onTouched
});
var isWatched = (name, _names, isBlurEvent) => {
	if (isBlurEvent) return false;
	if (_names.watchAll || _names.watch.has(name)) return true;
	for (const watchName of _names.watch) if (name.startsWith(watchName) && name.charAt(watchName.length) === ".") return true;
	return false;
};
var iterateFieldsByAction = (fields, action, fieldsNames) => {
	for (const key of fieldsNames || Object.keys(fields)) {
		if (key === "_f") continue;
		const field = fieldsNames ? get(fields, key) : fields[key];
		if (field) {
			const { _f } = field;
			if (_f) {
				if (_f.refs && _f.refs[0] && action(_f.refs[0], _f.name)) return true;
				else if (_f.ref && action(_f.ref, _f.name)) return true;
				else if (iterateFieldsByAction(field, action)) return true;
			} else if (isObject(field) || Array.isArray(field)) {
				if (iterateFieldsByAction(field, action)) return true;
			}
		}
	}
};
var updateFieldArrayRootError = (errors, error, name) => {
	const existingErrors = get(errors, name);
	const fieldArrayErrors = Array.isArray(existingErrors) ? existingErrors : [];
	set(fieldArrayErrors, ROOT_ERROR_TYPE, error[name]);
	set(errors, name, fieldArrayErrors);
	return errors;
};
var isEmptyObject = (value) => isObject(value) && !Object.keys(value).length;
var isHTMLElement = (value) => {
	if (!isWeb) return false;
	const owner = value ? value.ownerDocument : 0;
	return value instanceof (owner && owner.defaultView ? owner.defaultView.HTMLElement : HTMLElement);
};
var isRadioInput = (element) => element.type === "radio";
var isRegex = (value) => value instanceof RegExp;
var appendErrors = (name, validateAllFieldCriteria, errors, type, message) => validateAllFieldCriteria ? {
	...errors[name],
	types: {
		...errors[name] && errors[name].types ? errors[name].types : {},
		[type]: message || true
	}
} : {};
var defaultResult = {
	value: false,
	isValid: false
};
var validResult = {
	value: true,
	isValid: true
};
var getCheckboxValue = (options) => {
	if (!Array.isArray(options)) return defaultResult;
	if (options.length > 1) {
		const values = options.filter((option) => option && option.checked && !option.disabled).map((option) => option.value);
		return {
			value: values,
			isValid: !!values.length
		};
	}
	const option = options[0];
	if (!option || !option.checked || option.disabled) return defaultResult;
	if (!option.attributes || !("value" in option.attributes)) return validResult;
	return isUndefined(option.value) || option.value === "" ? validResult : {
		value: option.value,
		isValid: true
	};
};
var defaultReturn = {
	isValid: false,
	value: null
};
var getRadioValue = (options) => Array.isArray(options) ? options.reduce((previous, option) => option && option.checked && !option.disabled ? {
	isValid: true,
	value: option.value
} : previous, defaultReturn) : defaultReturn;
function getValidateError(result, ref, type = "validate") {
	if (isString(result) || Array.isArray(result) && !!result.length && result.every(isString) || isBoolean(result) && !result) return {
		type,
		message: isString(result) ? result : "",
		ref
	};
}
var getValueAndMessage = (validationData) => isObject(validationData) && !isRegex(validationData) ? validationData : {
	value: validationData,
	message: ""
};
var validateField = async (field, disabledFieldNames, formValues, validateAllFieldCriteria, shouldUseNativeValidation, isFieldArray) => {
	const { ref, refs, required, maxLength, minLength, min, max, pattern, validate, name, valueAsNumber, mount, _c } = field._f;
	const inputValue = get(formValues, name);
	if (!mount || disabledFieldNames.has(name)) return {};
	const inputRef = refs ? refs[0] : ref;
	const setCustomValidity = (message) => {
		if (shouldUseNativeValidation && inputRef.reportValidity) {
			const validityMessage = isBoolean(message) ? "" : message || "";
			if (refs) refs.forEach((ref) => isFunction(ref.setCustomValidity) && ref.setCustomValidity(validityMessage));
			else inputRef.setCustomValidity(validityMessage);
			inputRef.reportValidity();
		}
	};
	const error = {};
	const isRadio = !_c && isRadioInput(ref);
	const isCheckBox = !_c && isCheckBoxInput(ref);
	const isRadioOrCheckbox = isRadio || isCheckBox;
	const isEmpty = (valueAsNumber || isFileInput(ref)) && isUndefined(ref.value) && isUndefined(inputValue) || isHTMLElement(ref) && ref.value === "" && !_c || inputValue === "" || Array.isArray(inputValue) && !inputValue.length;
	const appendErrorsCurry = appendErrors.bind(null, name, validateAllFieldCriteria, error);
	const getMinMaxMessage = (exceedMax, maxLengthMessage, minLengthMessage, maxType = INPUT_VALIDATION_RULES.maxLength, minType = INPUT_VALIDATION_RULES.minLength) => {
		const message = exceedMax ? maxLengthMessage : minLengthMessage;
		error[name] = {
			type: exceedMax ? maxType : minType,
			message,
			ref,
			...appendErrorsCurry(exceedMax ? maxType : minType, message)
		};
	};
	if (isFieldArray ? !Array.isArray(inputValue) || !inputValue.length : required && (!isRadioOrCheckbox && (isEmpty || isNullOrUndefined(inputValue)) || isBoolean(inputValue) && !inputValue || isCheckBox && !getCheckboxValue(refs).isValid || isRadio && !getRadioValue(refs).isValid)) {
		const { value, message } = isString(required) ? {
			value: !!required,
			message: required
		} : getValueAndMessage(required);
		if (value) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.required,
				message,
				ref: inputRef,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.required, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (!isEmpty && (!isNullOrUndefined(min) || !isNullOrUndefined(max))) {
		let exceedMax;
		let exceedMin;
		const maxOutput = getValueAndMessage(max);
		const minOutput = getValueAndMessage(min);
		if (!isNullOrUndefined(inputValue) && !isDateObject(inputValue) && !isNaN(inputValue)) {
			const valueNumber = !_c && ref.valueAsNumber || (inputValue ? +inputValue : inputValue);
			if (!isNullOrUndefined(maxOutput.value)) exceedMax = valueNumber > maxOutput.value;
			if (!isNullOrUndefined(minOutput.value)) exceedMin = valueNumber < minOutput.value;
		} else {
			const valueDate = !_c && ref.valueAsDate || new Date(inputValue);
			const convertTimeToDate = (time) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + time);
			const isTime = ref.type == "time";
			const isWeek = ref.type == "week";
			if (isString(maxOutput.value) && inputValue) exceedMax = isTime ? convertTimeToDate(inputValue) > convertTimeToDate(maxOutput.value) : isWeek ? inputValue > maxOutput.value : valueDate > new Date(maxOutput.value);
			if (isString(minOutput.value) && inputValue) exceedMin = isTime ? convertTimeToDate(inputValue) < convertTimeToDate(minOutput.value) : isWeek ? inputValue < minOutput.value : valueDate < new Date(minOutput.value);
		}
		if (exceedMax || exceedMin) {
			getMinMaxMessage(!!exceedMax, maxOutput.message, minOutput.message, INPUT_VALIDATION_RULES.max, INPUT_VALIDATION_RULES.min);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if ((!isNullOrUndefined(maxLength) || !isNullOrUndefined(minLength)) && !isEmpty && (isString(inputValue) || isFieldArray && Array.isArray(inputValue))) {
		const maxLengthOutput = getValueAndMessage(maxLength);
		const minLengthOutput = getValueAndMessage(minLength);
		const exceedMax = !isNullOrUndefined(maxLengthOutput.value) && inputValue.length > +maxLengthOutput.value;
		const exceedMin = !isNullOrUndefined(minLengthOutput.value) && inputValue.length < +minLengthOutput.value;
		if (exceedMax || exceedMin) {
			getMinMaxMessage(exceedMax, maxLengthOutput.message, minLengthOutput.message);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if (pattern && !isEmpty && isString(inputValue)) {
		const { value: patternValue, message } = getValueAndMessage(pattern);
		if (isRegex(patternValue) && !inputValue.match(patternValue)) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.pattern,
				message,
				ref,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.pattern, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (validate) {
		if (isFunction(validate)) {
			const validateError = getValidateError(await validate(inputValue, formValues), inputRef);
			if (validateError) {
				error[name] = {
					...validateError,
					...appendErrorsCurry(INPUT_VALIDATION_RULES.validate, validateError.message)
				};
				if (!validateAllFieldCriteria) {
					setCustomValidity(validateError.message);
					return error;
				}
			}
		} else if (isObject(validate)) {
			let validationResult = {};
			for (const key in validate) {
				if (!isEmptyObject(validationResult) && !validateAllFieldCriteria) break;
				const validateError = getValidateError(await validate[key](inputValue, formValues), inputRef, key);
				if (validateError) {
					validationResult = {
						...validateError,
						...appendErrorsCurry(key, validateError.message)
					};
					if (!validateAllFieldCriteria) setCustomValidity(validateError.message);
					if (validateAllFieldCriteria) error[name] = validationResult;
				}
			}
			if (!isEmptyObject(validationResult)) {
				error[name] = {
					ref: inputRef,
					...validationResult
				};
				if (!validateAllFieldCriteria) return error;
			}
		}
	}
	const fieldError = error[name];
	setCustomValidity(fieldError ? fieldError.message : true);
	return error;
};
var convertToArrayPayload = (value) => Array.isArray(value) ? value : [value];
var appendAt = (data, value) => [...data, ...convertToArrayPayload(value)];
var fillEmptyArray = (value) => Array.isArray(value) ? value.map(() => void 0) : void 0;
function insert(data, index, value) {
	return [
		...data.slice(0, index),
		...convertToArrayPayload(value),
		...data.slice(index)
	];
}
var moveArrayAt = (data, from, to) => {
	if (!Array.isArray(data)) return [];
	if (isUndefined(data[to])) data[to] = void 0;
	data.splice(to, 0, data.splice(from, 1)[0]);
	return data;
};
var prependAt = (data, value) => [...convertToArrayPayload(value), ...convertToArrayPayload(data)];
var compact = (value) => Array.isArray(value) ? value.filter(Boolean) : [];
function removeAtIndexes(data, indexes) {
	let i = 0;
	const temp = [...data];
	for (const index of indexes) {
		temp.splice(index - i, 1);
		i++;
	}
	return compact(temp).length ? temp : [];
}
var removeArrayAt = (data, index) => isUndefined(index) ? [] : removeAtIndexes(data, [...new Set(convertToArrayPayload(index))].sort((a, b) => a - b));
var swapArrayAt = (data, indexA, indexB) => {
	[data[indexA], data[indexB]] = [data[indexB], data[indexA]];
};
function baseGet(object, updatePath) {
	const length = updatePath.length - 1;
	let index = 0;
	while (index < length) {
		if (isNullOrUndefined(object)) {
			object = void 0;
			break;
		}
		object = object[updatePath[index]];
		index++;
	}
	return object;
}
function isEmptyArray(obj) {
	for (const key in obj) if (obj.hasOwnProperty(key) && !isUndefined(obj[key])) return false;
	return true;
}
function unset(object, path) {
	if (isString(path) && Object.prototype.hasOwnProperty.call(object, path)) {
		delete object[path];
		return object;
	}
	const paths = Array.isArray(path) ? path : isKey(path) ? [path] : stringToPath(path);
	if (paths.some((segment) => PROTOTYPE_KEYWORDS.includes(String(segment)))) return object;
	const childObject = paths.length === 1 ? object : baseGet(object, paths);
	const index = paths.length - 1;
	const key = paths[index];
	if (childObject) delete childObject[key];
	if (index !== 0 && (isObject(childObject) && isEmptyObject(childObject) || Array.isArray(childObject) && isEmptyArray(childObject))) unset(object, paths.slice(0, -1));
	return object;
}
var updateAt = (fieldValues, index, value) => {
	fieldValues[index] = value;
	return fieldValues;
};
/**
* Hook for dynamic field arrays. Provides `fields` and mutation methods:
* `append`, `prepend`, `remove`, `insert`, `swap`, `move`, `update`, `replace`.
*
* @see [API](https://react-hook-form.com/docs/usefieldarray)
*
* @example
* ```tsx
* const { fields, append } = useFieldArray({ control, name: "items" });
* return fields.map((f, i) => <input key={f.id} {...register(`items.${i}.name`)} />);
* ```
*/
function useFieldArray(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, keyName = "id", disabled, shouldUnregister, rules } = props;
	const getCurrentFieldArray = () => control._getFieldArray(name);
	const [fields, setFields] = import_react.useState(getCurrentFieldArray);
	const ids = import_react.useRef(control._getFieldArray(name).map(generateId));
	const _actioned = import_react.useRef(false);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFieldArray);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	if (!disabled) control._names.array.add(name);
	import_react.useMemo(() => !disabled && rules && fields && control.register(name, rules), [
		control,
		name,
		fields,
		rules,
		disabled
	]);
	useIsomorphicLayoutEffect(() => {
		if (disabled) return;
		if (_prevControl.current === control && _prevName.current === name) resyncIfNeeded(true, getCurrentFieldArray, (fieldValues) => {
			setFields(fieldValues);
			ids.current = fieldValues.map(generateId);
		});
		else {
			_prevControl.current = control;
			_prevName.current = name;
			const fieldValues = getCurrentFieldArray();
			if (!deepEqual(fields, fieldValues)) {
				setFields(fieldValues);
				ids.current = fieldValues.map(generateId);
			}
			snapshot(true, getCurrentFieldArray);
		}
		const unsubscribe = control._subjects.array.subscribe({ next: ({ values, name: fieldArrayName }) => {
			if (fieldArrayName === name || !fieldArrayName) {
				const fieldValues = get(values, name);
				if (Array.isArray(fieldValues)) {
					setFields(fieldValues);
					ids.current = fieldValues.map(generateId);
				} else if (!fieldArrayName) {
					setFields([]);
					ids.current = [];
				}
			}
		} }).unsubscribe;
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFieldArray);
		};
	}, [
		control,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	const updateValues = import_react.useCallback((updatedFieldArrayValues) => {
		_actioned.current = true;
		control._setFieldArray(name, updatedFieldArrayValues);
	}, [control, name]);
	const append = (value, options) => {
		if (disabled) return;
		const appendValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = appendAt(control._getFieldArray(name), appendValue);
		control._names.focus = getFocusFieldName(name, updatedFieldArrayValues.length - 1, options);
		ids.current = appendAt(ids.current, appendValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, appendAt, { argA: fillEmptyArray(value) });
	};
	const prepend = (value, options) => {
		if (disabled) return;
		const prependValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = prependAt(control._getFieldArray(name), prependValue);
		control._names.focus = getFocusFieldName(name, 0, options);
		ids.current = prependAt(ids.current, prependValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, prependAt, { argA: fillEmptyArray(value) });
	};
	const remove = (index) => {
		if (disabled) return;
		const updatedFieldArrayValues = removeArrayAt(control._getFieldArray(name), index);
		ids.current = removeArrayAt(ids.current, index);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		!Array.isArray(get(control._fields, name)) && set(control._fields, name, void 0);
		control._setFieldArray(name, updatedFieldArrayValues, removeArrayAt, { argA: index });
	};
	const insert$1 = (index, value, options) => {
		if (disabled) return;
		const insertValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = insert(control._getFieldArray(name), index, insertValue);
		control._names.focus = getFocusFieldName(name, index, options);
		ids.current = insert(ids.current, index, insertValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, insert, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const swap = (indexA, indexB) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		swapArrayAt(updatedFieldArrayValues, indexA, indexB);
		swapArrayAt(ids.current, indexA, indexB);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, swapArrayAt, {
			argA: indexA,
			argB: indexB
		}, false);
	};
	const move = (from, to) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		moveArrayAt(updatedFieldArrayValues, from, to);
		moveArrayAt(ids.current, from, to);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, moveArrayAt, {
			argA: from,
			argB: to
		}, false);
	};
	const update = (index, value) => {
		if (disabled) return;
		const updateValue = cloneObject(value);
		const updatedFieldArrayValues = updateAt(control._getFieldArray(name), index, updateValue);
		ids.current = [...updatedFieldArrayValues].map((item, i) => !item || i === index ? generateId() : ids.current[i]);
		updateValues(updatedFieldArrayValues);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, updatedFieldArrayValues, updateAt, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const replace = (value) => {
		if (disabled) return;
		const updatedFieldArrayValues = convertToArrayPayload(cloneObject(value));
		ids.current = updatedFieldArrayValues.map(generateId);
		updateValues([...updatedFieldArrayValues]);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, [...updatedFieldArrayValues], (data) => Array.isArray(data) ? data.slice(0, updatedFieldArrayValues.length) : data, {});
	};
	import_react.useEffect(() => {
		if (disabled) {
			control._state.actionArrayLengths.delete(name);
			return;
		}
		control._state.action = false;
		control._state.actionArrayLengths.delete(name);
		isWatched(name, control._names) && control._subjects.state.next({ ...control._formState });
		const validationModes = getValidationModes(control._options.mode);
		const reValidateModes = getValidationModes(control._options.reValidateMode);
		if (_actioned.current && (!validationModes.isOnSubmit || control._formState.isSubmitted) && !reValidateModes.isOnSubmit && (!validationModes.isOnBlur || control._formState.isSubmitted && reValidateModes.isOnChange)) {
			const fieldArrayValues = get(control._formValues, name);
			if (control._options.resolver) control._runSchema([name]).then((result) => {
				control._updateIsValidating([name]);
				if (fieldArrayValues !== get(control._formValues, name)) return;
				const error = get(result.errors, name);
				const existingError = get(control._formState.errors, name);
				const existingErrorType = existingError && (existingError.type || existingError.root && existingError.root.type);
				const existingErrorMessage = existingError && (existingError.message || existingError.root && existingError.root.message);
				if (existingError ? !error && existingErrorType || error && (existingErrorType !== error.type || existingErrorMessage !== error.message) : error && error.type) {
					if (error) isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(+key)) ? updateFieldArrayRootError(control._formState.errors, { [name]: error }, name) : set(control._formState.errors, name, error);
					else unset(control._formState.errors, name);
					control._formState.errors = { ...control._formState.errors };
					control._subjects.state.next({ errors: control._formState.errors });
				}
			});
			else {
				const field = get(control._fields, name);
				if (field && field._f) validateField(field, control._names.disabled, control._formValues, control._options.criteriaMode === VALIDATION_MODE.all, control._options.shouldUseNativeValidation, true).then((error) => {
					if (fieldArrayValues !== get(control._formValues, name)) return;
					if (!isEmptyObject(error)) {
						updateFieldArrayRootError(control._formState.errors, error, name);
						control._formState.errors = { ...control._formState.errors };
						control._subjects.state.next({ errors: control._formState.errors });
					} else {
						const existingError = get(control._formState.errors, name);
						if (existingError && existingError[ROOT_ERROR_TYPE]) {
							unset(control._formState.errors, `${name}.${ROOT_ERROR_TYPE}`);
							control._formState.errors = { ...control._formState.errors };
							control._subjects.state.next({ errors: control._formState.errors });
						}
					}
				});
			}
		}
		_actioned.current && control._subjects.state.next({
			name,
			values: cloneObject(control._formValues)
		});
		control._names.focus && iterateFieldsByAction(control._fields, (ref, key) => {
			if (control._names.focus && key.startsWith(control._names.focus) && ref.focus) {
				ref.focus();
				return 1;
			}
		});
		control._names.focus = "";
		control._setValid();
		_actioned.current = false;
	}, [
		fields,
		name,
		control,
		disabled
	]);
	import_react.useEffect(() => {
		if (!disabled) isUndefined(get(control._formValues, name)) && control._setFieldArray(name);
		return () => {
			control._state.actionArrayLengths.delete(name);
			control._state.actionArrayLengths.size || (control._state.action = false);
			if (disabled) return;
			const shouldKeepFieldArrayValues = !(control._options.shouldUnregister || shouldUnregister);
			const updateMounted = (name, value) => {
				const field = get(control._fields, name);
				if (field && field._f) field._f.mount = value;
			};
			if (_actioned.current && shouldKeepFieldArrayValues) control._subjects.state.next({
				name,
				values: cloneObject(control._formValues)
			});
			if (!shouldKeepFieldArrayValues && control._state.action && [...control._state.actionArrayLengths.keys()].some((arrayName) => name.startsWith(arrayName + "."))) return;
			shouldKeepFieldArrayValues ? updateMounted(name, false) : control.unregister(name);
		};
	}, [
		name,
		control,
		keyName,
		shouldUnregister,
		disabled
	]);
	return {
		swap: import_react.useCallback(swap, [
			updateValues,
			name,
			control,
			disabled
		]),
		move: import_react.useCallback(move, [
			updateValues,
			name,
			control,
			disabled
		]),
		prepend: import_react.useCallback(prepend, [
			updateValues,
			name,
			control,
			disabled
		]),
		append: import_react.useCallback(append, [
			updateValues,
			name,
			control,
			disabled
		]),
		remove: import_react.useCallback(remove, [
			updateValues,
			name,
			control,
			disabled
		]),
		insert: import_react.useCallback(insert$1, [
			updateValues,
			name,
			control,
			disabled
		]),
		update: import_react.useCallback(update, [
			updateValues,
			name,
			control,
			disabled
		]),
		replace: import_react.useCallback(replace, [
			updateValues,
			name,
			control,
			disabled
		]),
		fields: import_react.useMemo(() => fields.map((field, index) => ({
			...field,
			...isBoolean(disabled) ? { disabled } : {},
			[keyName]: ids.current[index] || generateId()
		})), [
			fields,
			keyName,
			disabled
		])
	};
}
/**
* Component based on `useFieldArray` hook to work with controlled component.
*
* @example
* ```tsx
* function App() {
*   const { control, register } = useForm<FormValues>({
*     defaultValues: {
*       test: [
*         {
*           value: '',
*         },
*       ],
*     },
*   });
*
*   return (
*     <form>
*       <FieldArray
*         control={control}
*         name="test"
*         render={({ fields }) =>
*           fields.map((field, index) => (
*             <input key={field.id} {...register(`test.${index}.value`)} />
*           ))
*         }
*       />
*     </form>
*   );
* }
* ```
*/
var FieldArray = (props) => props.render(useFieldArray(props));
var isFileLike = (value) => typeof Blob !== "undefined" && value instanceof Blob || typeof File !== "undefined" && value instanceof File;
var isFileListLike = (value) => typeof FileList !== "undefined" && value instanceof FileList;
var flatten = (obj) => {
	const output = {};
	for (const key of Object.keys(obj)) if (isObjectType(obj[key]) && obj[key] !== null && !isDateObject(obj[key]) && !isFileLike(obj[key]) && !isFileListLike(obj[key])) {
		const nested = flatten(obj[key]);
		for (const nestedKey of Object.keys(nested)) output[`${key}.${nestedKey}`] = nested[nestedKey];
	} else output[key] = obj[key];
	return output;
};
function jsonToFormData(json) {
	const result = new FormData();
	const flattenFormValues = flatten(json);
	for (const key in flattenFormValues) {
		const value = flattenFormValues[key];
		if (isUndefined(value)) continue;
		if (typeof FileList !== "undefined" && value instanceof FileList) {
			for (let index = 0; index < value.length; index++) {
				const file = value[index];
				file && result.append(key, file);
			}
			continue;
		}
		result.append(key, value);
	}
	return result;
}
function safeJSONStringify(value) {
	try {
		return JSON.stringify(value);
	} catch (_a) {
		return "";
	}
}
function noop() {}
var POST_REQUEST = "post";
function defaultValidateStatus(status) {
	return status >= 200 && status < 300;
}
/**
* Form component that handles submission, including optional `action` fetch and server error wiring.
*
* @see [API](https://react-hook-form.com/docs/useform/form)
*
* @example
* ```tsx
* <Form action="/api" control={control}>
*   <input {...register("name")} />
*   <p>{errors?.root?.server && 'Server error'}</p>
*   <button>Submit</button>
* </Form>
* ```
*/
function Form(props) {
	const formControl = useFormControlContext();
	const [mounted, setMounted] = import_react.useState(false);
	const { control = formControl, onSubmit = noop, children, action, method = POST_REQUEST, headers, encType, onError = noop, render, onSuccess = noop, validateStatus = defaultValidateStatus, ...rest } = props;
	const handleSubmit = import_react.useMemo(() => {
		return control.handleSubmit(async (data, event) => {
			const formData = jsonToFormData(data);
			const formDataJson = safeJSONStringify(data);
			if (onSubmit) await onSubmit({
				data,
				event,
				method,
				formData,
				formDataJson
			});
			if (isString(action)) try {
				const hasContentType = (type) => headers && Object.entries(headers).some(([name, value]) => name.toLowerCase() === "content-type" && type.test(value)) || encType && type.test(encType);
				let body = formData;
				if (hasContentType(/json/i)) body = formDataJson;
				else if (hasContentType(/^\s*application\/x-www-form-urlencoded\s*(;|$)/i)) body = new URLSearchParams(Array.from(formData, ([name, value]) => [name, isString(value) ? value : value.name]));
				else if (hasContentType(/^\s*text\/plain\s*(;|$)/i)) body = Array.from(formData, ([name, value]) => `${name}=${isString(value) ? value : value.name}\r\n`).join("");
				const isMultipart = (value) => /^\s*multipart\/form-data\s*(;|$)/i.test(value);
				const response = await fetch(action, {
					method,
					headers: {
						...Object.fromEntries(Object.entries(headers || {}).filter(([name, value]) => name.toLowerCase() !== "content-type" || !isMultipart(value))),
						...encType && !isMultipart(encType) && { "Content-Type": encType }
					},
					body
				});
				if (response && !validateStatus(response.status)) {
					onError({ response });
					return { type: String(response.status) };
				} else onSuccess({ response });
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
			if (isFunction(action)) try {
				await action(formData);
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
		});
	}, [
		control,
		onSubmit,
		method,
		action,
		headers,
		encType,
		validateStatus,
		onError,
		onSuccess
	]);
	const submit = import_react.useCallback(async (event) => {
		const err = await handleSubmit(event);
		if (err && control) {
			control._subjects.state.next({ isSubmitSuccessful: false });
			control.setError("root.server", err);
		}
	}, [handleSubmit, control]);
	import_react.useEffect(() => {
		setMounted(true);
	}, []);
	if (render) return render({ submit });
	return import_react.createElement("form", {
		noValidate: mounted,
		action,
		...!isFunction(action) && {
			method,
			encType
		},
		onSubmit: submit,
		...rest
	}, children);
}
var FormState = ({ control, disabled, exact, name, render }) => render(useFormState({
	control,
	name,
	disabled,
	exact
}));
/** @deprecated Use `FormState` instead. Kept as an alias for backward compatibility. */
var FormStateSubscribe = FormState;
var createSubject = () => {
	let _observers = /* @__PURE__ */ new Set();
	let _iterationCount = 0;
	const next = (value) => {
		const observers = _observers;
		_iterationCount++;
		for (const observer of observers) observer.next && observer.next(value);
		observers === _observers && _iterationCount--;
	};
	const subscribe = (observer) => {
		_observers.add(observer);
		return { unsubscribe: () => {
			if (_iterationCount) {
				_observers = new Set(_observers);
				_iterationCount = 0;
			}
			_observers.delete(observer);
		} };
	};
	const unsubscribe = () => {
		_observers = /* @__PURE__ */ new Set();
		_iterationCount = 0;
	};
	return {
		get observers() {
			return Array.from(_observers);
		},
		next,
		subscribe,
		unsubscribe
	};
};
function extractFormValues(fieldsState, formValues) {
	const values = Array.isArray(fieldsState) ? [] : {};
	for (const key in fieldsState) if (Object.prototype.hasOwnProperty.call(fieldsState, key)) {
		const fieldState = fieldsState[key];
		const fieldValue = formValues[key];
		if (fieldState && (isObject(fieldState) || Array.isArray(fieldState)) && fieldValue) values[key] = extractFormValues(fieldState, fieldValue);
		else if (fieldsState[key]) values[key] = fieldValue;
	}
	return values;
}
var hasOwn = (value, key) => value !== null && isObjectType(value) && Object.prototype.hasOwnProperty.call(value, key);
var has = (object, path) => {
	if (!path) return false;
	let result = object;
	for (const key of isKey(path) ? [path] : stringToPath(path)) {
		if (!hasOwn(result, key)) return hasOwn(object, path);
		result = result[key];
	}
	return true;
};
var isMultipleSelect = (element) => element.type === `select-multiple`;
var isSelectEdited = (select) => {
	const options = [...select.options];
	return !select.multiple && select.size < 2 && !options.some((option) => option.defaultSelected) ? select.selectedIndex !== options.findIndex((option) => !option.disabled) : options.some((option) => option.selected !== option.defaultSelected);
};
var isEdited = (ref) => isCheckBoxInput(ref) ? ref.checked !== ref.defaultChecked : ref.type === "select-one" || isMultipleSelect(ref) ? isSelectEdited(ref) : !isRadioInput(ref) && "defaultValue" in ref && ref.value !== ref.defaultValue;
var isRadioOrCheckbox = (ref) => isRadioInput(ref) || isCheckBoxInput(ref);
var live = (ref) => isHTMLElement(ref) && ref.isConnected;
function isDirtyContainer(value) {
	return Array.isArray(value) || isObject(value);
}
function collectDirtyFieldNames(dirtyTree, cachedDirtyFields, prefix = "", names = []) {
	for (const key in dirtyTree) {
		const path = prefix ? `${prefix}.${key}` : key;
		const value = dirtyTree[key];
		if (isDirtyContainer(value) && isDirtyContainer(get(cachedDirtyFields, path))) collectDirtyFieldNames(value, cachedDirtyFields, path, names);
		else names.push(path);
	}
	return names;
}
var objectHasFunction = (data) => {
	for (const key in data) if (isFunction(data[key])) return true;
	return false;
};
function isTraversable(value) {
	return Array.isArray(value) || isObject(value) && !objectHasFunction(value);
}
function isRegisteredLeaf(fieldRef) {
	return !!(fieldRef && "_f" in fieldRef);
}
function isEmptyDirtyContainer(value) {
	return Array.isArray(value) ? !value.some((item) => !isUndefined(item)) : !Object.keys(value).length;
}
function clearDirtyField(container, key) {
	if (Array.isArray(container)) container[key] = void 0;
	else delete container[key];
}
function markFieldsDirty(data, fields = {}, fieldRefs) {
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			fields[key] = Array.isArray(value) ? [] : {};
			markFieldsDirty(value, fields[key], fieldRef);
			if (isEmptyDirtyContainer(fields[key])) clearDirtyField(fields, key);
		} else if (!isUndefined(value)) fields[key] = true;
	}
	return fields;
}
function getDirtyFields(data, formValues, dirtyFieldsFromValues, fieldRefs) {
	if (!dirtyFieldsFromValues) dirtyFieldsFromValues = markFieldsDirty(formValues, Array.isArray(isNullOrUndefined(formValues) ? data : formValues) ? [] : {}, fieldRefs);
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			if (isUndefined(formValues) || isPrimitive(dirtyFieldsFromValues[key])) dirtyFieldsFromValues[key] = markFieldsDirty(value, Array.isArray(value) ? [] : {}, fieldRef);
			else getDirtyFields(value, isNullOrUndefined(formValues) ? {} : formValues[key], dirtyFieldsFromValues[key], fieldRef);
			if (isEmptyDirtyContainer(dirtyFieldsFromValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		} else if (deepEqual(value, isNullOrUndefined(formValues) ? void 0 : formValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		else dirtyFieldsFromValues[key] = true;
	}
	return dirtyFieldsFromValues;
}
var getFieldArrayItemNames = (names, name) => {
	const segments = name.split(".");
	const matches = [];
	let prefix = segments[0];
	for (let i = 1; i < segments.length; prefix += "." + segments[i++]) if (!isNaN(+segments[i]) && names.has(prefix)) matches.push(`${prefix}.${segments[i]}`);
	return matches;
};
var getFieldValueAs = (value, { valueAsNumber, valueAsDate, setValueAs }) => isUndefined(value) ? value : valueAsNumber ? value === "" ? NaN : value ? +value : value : valueAsDate && isString(value) ? new Date(value) : setValueAs ? setValueAs(value) : value;
function getFieldValue(_f) {
	const ref = _f.ref;
	if (isFileInput(ref)) return ref.files;
	if (isRadioInput(ref)) return getRadioValue(_f.refs).value;
	if (isMultipleSelect(ref)) return [...ref.selectedOptions].map(({ value }) => value);
	if (isCheckBoxInput(ref)) return getCheckboxValue(_f.refs).value;
	return getFieldValueAs(ref.value, _f);
}
var getResolverOptions = (fieldsNames, _fields, criteriaMode, shouldUseNativeValidation) => {
	const fields = {};
	for (const name of fieldsNames) {
		const field = get(_fields, name);
		field && set(fields, name, field._f);
	}
	return {
		criteriaMode,
		names: [...fieldsNames],
		fields,
		shouldUseNativeValidation
	};
};
var getRuleValue = (rule) => isUndefined(rule) ? rule : isRegex(rule) ? rule.source : isObject(rule) ? isRegex(rule.value) ? rule.value.source : rule.value : rule;
var ASYNC_FUNCTION = "AsyncFunction";
var hasPromiseValidation = (fieldReference) => {
	if (!fieldReference || !fieldReference.validate) return false;
	if (isFunction(fieldReference.validate)) return fieldReference.validate.constructor.name === ASYNC_FUNCTION;
	if (isObject(fieldReference.validate)) {
		for (const key in fieldReference.validate) if (fieldReference.validate[key].constructor.name === ASYNC_FUNCTION) return true;
	}
	return false;
};
var hasValidation = (options) => options.mount && (options.required || !isUndefined(options.required) && options.required !== false || !isUndefined(options.min) || !isUndefined(options.max) || !isUndefined(options.maxLength) || !isUndefined(options.minLength) || options.pattern || options.validate);
function schemaErrorLookup(errors, _fields, name) {
	const error = get(errors, name);
	if (error && (error.type || error.message) || Array.isArray(error)) return {
		error,
		name
	};
	const names = name.split(".");
	while (names.length) {
		const fieldName = names.join(".");
		const field = get(_fields, fieldName);
		const foundError = get(errors, fieldName);
		if (field && !Array.isArray(field) && name !== fieldName) return { name };
		if (foundError && foundError.type) return {
			name: fieldName,
			error: foundError
		};
		if (foundError && foundError.root && foundError.root.type) return {
			name: `${fieldName}.root`,
			error: foundError.root
		};
		names.pop();
	}
	return { name };
}
var shouldRenderFormState = (formStateData, _proxyFormState, isRoot) => {
	const keys = Object.keys(formStateData).filter((key) => key !== "name");
	return !keys.length || isRoot && keys.length >= Object.keys(_proxyFormState).length || keys.find((key) => _proxyFormState[key] === (!isRoot || VALIDATION_MODE.all));
};
var isNameMatch = (currentName, signalName, exact) => exact ? currentName === signalName || currentName.startsWith(signalName + ".") : currentName.startsWith(signalName) || signalName.startsWith(currentName);
var shouldSubscribeByName = (name, signalName, exact) => {
	if (!name || !signalName || name === signalName) return true;
	if (!Array.isArray(name)) return isNameMatch(name, signalName, exact);
	for (const currentName of name) if (currentName && isNameMatch(currentName, signalName, exact)) return true;
	return false;
};
var skipValidation = (isBlurEvent, isTouched, isSubmitted, reValidateMode, mode) => {
	if (mode.isOnAll) return false;
	else if (!isSubmitted && mode.isOnTouch) return !(isTouched || isBlurEvent);
	else if (isSubmitted ? reValidateMode.isOnBlur : mode.isOnBlur) return !isBlurEvent;
	else if (isSubmitted ? reValidateMode.isOnChange : mode.isOnChange) return isBlurEvent;
	return true;
};
var unsetEmptyArray = (ref, name) => {
	const array = get(ref, name);
	!compact(array).length && !(array && array.root) && unset(ref, name);
};
var defaultOptions = {
	mode: VALIDATION_MODE.onSubmit,
	reValidateMode: VALIDATION_MODE.onChange,
	shouldFocusError: true
};
var replaceDirtyFieldsInPlace = (dirtyFields, nextDirtyFields) => {
	for (const key in dirtyFields) delete dirtyFields[key];
	Object.assign(dirtyFields, nextDirtyFields);
};
var DEFAULT_FORM_STATE = {
	submitCount: 0,
	isDirty: false,
	isReady: false,
	isValidating: false,
	isSubmitted: false,
	isSubmitting: false,
	isSubmitSuccessful: false,
	isValid: false,
	touchedFields: {},
	dirtyFields: {},
	validatingFields: {}
};
function createFormControl(props = {}) {
	let _options = {
		...defaultOptions,
		...props
	};
	let _formState = {
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(_options.defaultValues),
		errors: cloneObject(_options.errors) || {},
		disabled: _options.disabled || false
	};
	let _fields = {};
	let _defaultValues = isObject(_options.defaultValues) || isObject(_options.values) ? cloneObject(_options.defaultValues || _options.values) || {} : {};
	let _formValues = _options.shouldUnregister ? {} : cloneObject(_defaultValues);
	let _state = {
		action: false,
		actionArrayLengths: /* @__PURE__ */ new Map(),
		mount: false,
		watch: false,
		keepIsValid: false
	};
	let _dirtyFieldsStale = false;
	let _names = {
		mount: /* @__PURE__ */ new Set(),
		disabled: /* @__PURE__ */ new Set(),
		unMount: /* @__PURE__ */ new Set(),
		array: /* @__PURE__ */ new Set(),
		watch: /* @__PURE__ */ new Set(),
		registerName: /* @__PURE__ */ new Set()
	};
	const delayErrorCallbacks = {};
	const timers = {};
	const _valuesSubscribers = /* @__PURE__ */ new Set();
	let _validationModeBeforeSubmit = getValidationModes(_options.mode);
	let _validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
	const defaultProxyFormState = {
		isDirty: false,
		dirtyFields: false,
		validatingFields: false,
		touchedFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	};
	const _proxyFormState = { ...defaultProxyFormState };
	const _proxySubscribeFormState = {};
	const _isTracked = (...keys) => keys.some((key) => _proxyFormState[key] || _proxySubscribeFormState[key]);
	const _hasValuesSubscriber = (name) => {
		for (const subscriber of _valuesSubscribers) if (shouldSubscribeByName(subscriber.name, name, subscriber.exact)) return true;
		return false;
	};
	const _subjects = {
		array: createSubject(),
		state: createSubject()
	};
	let _setValidCallId = 0;
	let _resetCallId = 0;
	let _registerCallId = 0;
	const _registerCallIds = {};
	let shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
	const debounce = (name, callback) => (wait) => {
		clearTimeout(timers[name]);
		timers[name] = setTimeout(callback, wait);
	};
	const cancelDelayedError = (name) => {
		clearTimeout(timers[name]);
		delete timers[name];
		delete delayErrorCallbacks[name];
	};
	const cancelDelayedErrorTree = (name) => {
		cancelDelayedError(name);
		const prefix = `${name}.`;
		for (const key of Object.keys(delayErrorCallbacks)) key.startsWith(prefix) && cancelDelayedError(key);
	};
	const _setValid = async (shouldUpdateValid) => {
		if (_state.keepIsValid) return;
		if (!_options.disabled && (_isTracked("isValid") || shouldUpdateValid)) {
			const callId = ++_setValidCallId;
			let isValid;
			if (_options.resolver) {
				isValid = isEmptyObject((await _runSchema()).errors);
				callId === _setValidCallId && _updateIsValidating();
			} else isValid = await executeBuiltInValidation({
				fields: _fields,
				onlyCheckValid: true,
				eventType: EVENTS.VALID
			});
			if (callId === _setValidCallId && isValid !== _formState.isValid) _subjects.state.next({ isValid });
		}
	};
	const _updateValidatingFields = (names, isValidating) => {
		const fieldNames = [...names];
		if (!fieldNames.some((name) => name && (isValidating ? get(_formState.validatingFields, name) !== true : has(_formState.validatingFields, name)))) return;
		const validatingFields = cloneObject(_formState.validatingFields);
		for (const name of fieldNames) if (name) isValidating ? set(validatingFields, name, true) : unset(validatingFields, name);
		if (!deepEqual(_formState.validatingFields, validatingFields)) _formState.validatingFields = validatingFields;
	};
	const _updateIsValidating = (names, isValidating) => {
		if (!_options.disabled && _isTracked("isValidating", "validatingFields")) {
			_updateValidatingFields(names || _names.mount, isValidating);
			_subjects.state.next({
				validatingFields: _formState.validatingFields,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _updateDirtyFields = () => {
		_formState.dirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
	};
	const _setFieldArray = (name, values = [], method, args, shouldSetValues = true, shouldUpdateFieldsAndState = true) => {
		if (args && method && !_options.disabled) {
			_state.action = true;
			_state.keepIsValid = false;
			const field = get(_fields, name);
			const rootField = field && field._f;
			const fields = rootField ? Object.assign([], field) : field;
			if (!_state.actionArrayLengths.has(name)) _state.actionArrayLengths.set(name, Array.isArray(fields) ? fields.length : 0);
			if (shouldUpdateFieldsAndState && Array.isArray(fields)) {
				const fieldValues = method(fields, args.argA, args.argB) || fields;
				rootField ? set(_fields, name, {
					...fieldValues,
					_f: rootField
				}) : shouldSetValues && set(_fields, name, fieldValues);
			}
			const fieldArrayErrors = get(_formState.errors, name);
			if (shouldUpdateFieldsAndState && Array.isArray(fieldArrayErrors)) {
				const rootError = fieldArrayErrors.root;
				const errors = method(fieldArrayErrors, args.argA, args.argB) || fieldArrayErrors;
				if (rootError) errors.root = rootError;
				shouldSetValues && set(_formState.errors, name, errors);
				unsetEmptyArray(_formState.errors, name);
				_formState.errors = { ..._formState.errors };
			}
			const touchedFieldsArray = get(_formState.touchedFields, name);
			const shouldUpdateTouchedFields = shouldUpdateFieldsAndState && Array.isArray(touchedFieldsArray);
			if (shouldUpdateTouchedFields) {
				const touchedFields = method(touchedFieldsArray, args.argA, args.argB);
				shouldSetValues && set(_formState.touchedFields, name, touchedFields);
			}
			const dirtyFieldsArray = get(_formState.dirtyFields, name);
			if (shouldUpdateFieldsAndState && Array.isArray(dirtyFieldsArray)) {
				const dirtyFields = method(dirtyFieldsArray, args.argA, args.argB) || dirtyFieldsArray;
				shouldSetValues && set(_formState.dirtyFields, name, dirtyFields);
			}
			if (_isTracked("dirtyFields")) _updateDirtyFields();
			else _dirtyFieldsStale = true;
			_subjects.state.next({
				name,
				isDirty: _getDirty(name, values),
				dirtyFields: _formState.dirtyFields,
				...shouldUpdateTouchedFields && { touchedFields: _formState.touchedFields },
				errors: _formState.errors,
				isValid: _formState.isValid
			});
		} else set(_formValues, name, values);
	};
	const updateErrors = (name, error) => {
		set(_formState.errors, name, error);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({ errors: _formState.errors });
	};
	const _setErrors = (errors) => {
		Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
		const hasErrors = !isEmptyObject(errors);
		_formState.errors = cloneObject(errors);
		_subjects.state.next({
			errors: _formState.errors,
			...hasErrors ? { isValid: false } : {}
		});
		!hasErrors && _state.mount && _setValid();
	};
	const toPath = (name) => isKey(name) ? [name] : stringToPath(name);
	const hasExplicitNullIntermediate = (name) => {
		const segments = toPath(name);
		let formValues = _formValues;
		let defaultValues = _defaultValues;
		for (let i = 0; i < segments.length - 1; i++) {
			const key = segments[i];
			formValues = isNullOrUndefined(formValues) ? formValues : formValues[key];
			defaultValues = isNullOrUndefined(defaultValues) ? defaultValues : defaultValues[key];
			if (formValues === null && defaultValues !== null) return true;
		}
		return false;
	};
	const isStaleArrayField = (name) => {
		if (!_state.actionArrayLengths.size) return false;
		const segments = toPath(name);
		let node = _formValues;
		let path = "";
		let ownerDepth = -1;
		let ownerPreActionLength = 0;
		for (let i = 0; i < segments.length; i++) {
			if (isNullOrUndefined(node)) return false;
			const key = segments[i];
			path = path ? `${path}.${key}` : key;
			if (Array.isArray(node) && +key >= node.length) return ownerDepth === -1 ? false : i === ownerDepth ? +key < ownerPreActionLength : true;
			if (_state.actionArrayLengths.has(path)) {
				ownerDepth = i + 1;
				ownerPreActionLength = _state.actionArrayLengths.get(path);
			}
			node = node[key];
			if (isUndefined(node) && ownerDepth !== -1 && i > ownerDepth && +segments[ownerDepth] < ownerPreActionLength) return true;
		}
		return false;
	};
	const isPastArrayEnd = (name) => {
		let node = _formValues;
		for (const key of toPath(name)) {
			if (Array.isArray(node) && +key >= node.length) return true;
			node = node && node[key];
		}
		return false;
	};
	const updateValidAndValue = (name, shouldSkipSetValueAs, value, ref) => {
		const field = get(_fields, name);
		if (field) {
			if (hasExplicitNullIntermediate(name) || isStaleArrayField(name)) return;
			const wasUnsetInFormValues = isUndefined(get(_formValues, name));
			const defaultValue = get(_formValues, name, isUndefined(value) ? get(_defaultValues, name) : value);
			const isEditedBeforeReady = !!ref && !_formState.isReady && isEdited(ref);
			if (isUndefined(defaultValue) || ref && ref.defaultChecked || isEditedBeforeReady || shouldSkipSetValueAs) {
				const fieldValue = shouldSkipSetValueAs ? defaultValue : getFieldValue(field._f);
				if (!isUndefined(fieldValue) || !isPastArrayEnd(name)) {
					if (_isTracked("dirtyFields") && !deepEqual(get(_formValues, name), fieldValue)) _dirtyFieldsStale = true;
					set(_formValues, name, fieldValue);
					if (isEditedBeforeReady) updateTouchAndDirty(name, fieldValue);
				}
			} else setFieldValue(name, defaultValue);
			if (_state.mount && !_state.action) {
				if (_options.resolver && _isTracked("isValidating", "validatingFields")) Promise.resolve().then(() => _setValid());
				else _setValid();
				if (wasUnsetInFormValues && _formState.isDirty && _isTracked("isDirty")) {
					if (!_getDirty()) {
						_formState.isDirty = false;
						_subjects.state.next({ ..._formState });
					}
				}
				if (_options.shouldUnregister && wasUnsetInFormValues && !isUndefined(get(_formValues, name)) && isWatched(name, _names)) _state.watch = true;
			}
		}
	};
	const updateTouchAndDirty = (name, fieldValue, isBlurEvent, shouldDirty, shouldRender) => {
		let shouldUpdateField = false;
		let isPreviousDirty = false;
		const output = { name };
		if (!_options.disabled || shouldDirty === true) {
			if (!isBlurEvent || shouldDirty) {
				const isCurrentFieldPristine = deepEqual(get(_defaultValues, name), fieldValue);
				if (_isTracked("isDirty")) {
					isPreviousDirty = _formState.isDirty;
					_formState.isDirty = output.isDirty = !isCurrentFieldPristine || _getDirty();
					shouldUpdateField = isPreviousDirty !== output.isDirty;
				}
				isPreviousDirty = !!get(_formState.dirtyFields, name);
				if (isCurrentFieldPristine) unset(_formState.dirtyFields, name);
				else {
					const defaultFieldValue = get(_defaultValues, name);
					const field = get(_fields, name);
					const dirtyValue = !(field && field._f) && (isObject(defaultFieldValue) || Array.isArray(defaultFieldValue)) ? getDirtyFields(defaultFieldValue, fieldValue, void 0, field) : true;
					set(_formState.dirtyFields, name, dirtyValue);
				}
				let didResyncDirtyFields = false;
				if (_dirtyFieldsStale || isCurrentFieldPristine && (_isTracked("isDirty") ? _formState.isDirty : _getDirty())) {
					_dirtyFieldsStale = false;
					const nextDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
					if (!deepEqual(_formState.dirtyFields, nextDirtyFields)) {
						didResyncDirtyFields = true;
						replaceDirtyFieldsInPlace(_formState.dirtyFields, nextDirtyFields);
					}
				}
				output.dirtyFields = _formState.dirtyFields;
				shouldUpdateField = shouldUpdateField || _isTracked("dirtyFields") && (didResyncDirtyFields || isPreviousDirty !== !isCurrentFieldPristine);
			}
			if (isBlurEvent) {
				const isPreviousFieldTouched = has(_formState.touchedFields, name) ? get(_formState.touchedFields, name) : void 0;
				if (!isPreviousFieldTouched) {
					set(_formState.touchedFields, name, isBlurEvent);
					output.touchedFields = _formState.touchedFields;
					shouldUpdateField = shouldUpdateField || _isTracked("touchedFields") && isPreviousFieldTouched !== isBlurEvent;
				}
			}
			shouldUpdateField && shouldRender && _subjects.state.next(output);
		}
		return shouldUpdateField ? output : {};
	};
	const shouldRenderByError = (name, isValid, error, fieldState) => {
		const previousFieldError = get(_formState.errors, name);
		const shouldUpdateValid = _isTracked("isValid") && isBoolean(isValid) && _formState.isValid !== isValid;
		if (_options.delayError && error) {
			delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
			delayErrorCallbacks[name](_options.delayError);
		} else {
			cancelDelayedError(name);
			error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			_formState.errors = { ..._formState.errors };
		}
		if ((error ? !deepEqual(previousFieldError, error, true) : previousFieldError) || !isEmptyObject(fieldState) || shouldUpdateValid) {
			const updatedFormState = {
				...fieldState,
				...shouldUpdateValid && isBoolean(isValid) ? { isValid } : {},
				errors: _formState.errors,
				name
			};
			_subjects.state.next(updatedFormState);
		}
	};
	const _runSchema = async (name) => {
		_updateIsValidating(name, true);
		return await _options.resolver(_formValues, _options.context, getResolverOptions(name || _names.mount, _fields, _options.criteriaMode, _options.shouldUseNativeValidation));
	};
	const executeSchemaAndUpdateState = async (names) => {
		const resetCallId = _resetCallId;
		const registerCallId = _registerCallId;
		const registeredNames = names ? names.filter((name) => get(_fields, name)) : [];
		const { errors } = await _runSchema(names);
		if (resetCallId !== _resetCallId) return errors;
		_updateIsValidating(names);
		if (names) {
			for (const name of names) {
				if (registeredNames.includes(name) && (!get(_fields, name) || _registerCallIds[name] > registerCallId)) {
					unset(errors, name);
					continue;
				}
				const error = get(errors, name);
				cancelDelayedErrorTree(name);
				const isFieldArrayRootError = _names.array.has(name) && isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(Number(key)));
				const field = get(_fields, name);
				const hasNestedFields = isObject(field) && Object.keys(field).some((key) => key !== "_f");
				isFieldArrayRootError ? updateFieldArrayRootError(_formState.errors, { [name]: error }, name) : error && (error.type || error.message) || Array.isArray(error) || isObject(error) && hasNestedFields ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			}
			_formState.errors = { ..._formState.errors };
		} else {
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = errors;
		}
		return errors;
	};
	const validateForm = async ({ name, eventType }) => {
		if (_options.validate) {
			const resetCallId = _resetCallId;
			const result = await _options.validate({
				formValues: _formValues,
				formState: _formState,
				name,
				eventType
			});
			if (resetCallId !== _resetCallId) return true;
			if (isObject(result)) {
				let isValid = true;
				clearErrors(FORM_ERROR_TYPE);
				for (const key in result) {
					const error = result[key];
					if (error) {
						isValid = false;
						setError(`${FORM_ERROR_TYPE}.${key}`, {
							message: isString(error.message) ? error.message : "",
							type: error.type || INPUT_VALIDATION_RULES.validate
						});
					}
				}
				return isValid;
			} else if (isString(result) || !result) {
				setError(FORM_ERROR_TYPE, {
					message: result || "",
					type: INPUT_VALIDATION_RULES.validate
				});
				return false;
			} else {
				clearErrors(FORM_ERROR_TYPE);
				return true;
			}
		}
		return true;
	};
	const executeBuiltInValidation = async ({ fields, onlyCheckValid, name, eventType, context = {
		valid: true,
		runRootValidation: false
	} }) => {
		const resetCallId = _resetCallId;
		if (_options.validate && !context.runRootValidation) {
			context.runRootValidation = true;
			if (!await validateForm({
				name,
				eventType
			})) {
				context.valid = false;
				if (onlyCheckValid) return context.valid;
			}
		}
		for (const name in fields) {
			const field = fields[name];
			if (field) {
				const { _f, ...fieldValue } = field;
				if (_f) {
					const isFieldArrayRoot = _names.array.has(_f.name);
					const isPromiseFunction = field._f && hasPromiseValidation(field._f);
					const shouldTrackIsValidatingState = _isTracked("isValidating", "validatingFields");
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name], true);
					const registerCallId = _registerCallId;
					const fieldError = await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation && !onlyCheckValid, isFieldArrayRoot);
					if (resetCallId !== _resetCallId) return context.valid;
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name]);
					if (!get(_fields, _f.name) || _registerCallIds[_f.name] > registerCallId) continue;
					if (fieldError[_f.name]) {
						context.valid = false;
						if (onlyCheckValid) break;
					}
					if (!onlyCheckValid) {
						cancelDelayedError(_f.name);
						get(fieldError, _f.name) ? isFieldArrayRoot ? updateFieldArrayRootError(_formState.errors, fieldError, _f.name) : set(_formState.errors, _f.name, fieldError[_f.name]) : unset(_formState.errors, _f.name);
					}
					if (_options.shouldUseNativeValidation && fieldError[_f.name]) break;
				}
				!isEmptyObject(fieldValue) && await executeBuiltInValidation({
					context,
					onlyCheckValid,
					fields: fieldValue,
					name,
					eventType
				});
			}
		}
		return context.valid;
	};
	const _removeUnmounted = () => {
		for (const name of _names.unMount) {
			const field = get(_fields, name);
			field && (field._f.refs ? field._f.refs.every((ref) => !live(ref)) : !live(field._f.ref)) && unregister(name);
		}
		_names.unMount = /* @__PURE__ */ new Set();
	};
	const _getDirty = (name, data) => (name && !isUndefined(data) && set(_formValues, name, data), !deepEqual(_state.mount ? _formValues : _defaultValues, _defaultValues));
	const _getWatch = (names, defaultValue, isGlobal) => {
		const values = _state.mount ? _formValues : isUndefined(defaultValue) || !isUndefined(names) ? _defaultValues : defaultValue;
		return generateWatchOutput(names, _names, isUndefined(names) ? { ...values } : values, isGlobal, defaultValue);
	};
	const _getFieldArray = (name) => compact(get(_state.mount ? _formValues : _defaultValues, name, _options.shouldUnregister ? get(_defaultValues, name, []) : []));
	const setFieldValue = (name, value, options = {}, skipClone = false, skipRender = false, skipValueRender = false) => {
		const field = get(_fields, name);
		let fieldValue = value;
		if (field) {
			const fieldReference = field._f;
			if (fieldReference) {
				!fieldReference.disabled && set(_formValues, name, getFieldValueAs(value, fieldReference));
				fieldValue = isHTMLElement(fieldReference.ref) && isNullOrUndefined(value) ? "" : value;
				if (isMultipleSelect(fieldReference.ref)) [...fieldReference.ref.options].forEach((optionRef) => optionRef.selected = fieldValue.includes(optionRef.value));
				else if (fieldReference.refs) {
					if (isCheckBoxInput(fieldReference.ref)) fieldReference.refs.forEach((checkboxRef) => {
						if (!checkboxRef.defaultChecked || !checkboxRef.disabled) {
							if (Array.isArray(fieldValue)) checkboxRef.checked = !!fieldValue.find((data) => data === checkboxRef.value);
							else checkboxRef.checked = fieldValue === checkboxRef.value || !!fieldValue;
						}
					});
					else fieldReference.refs.forEach((radioRef) => radioRef.checked = radioRef.value === fieldValue);
				} else if (isFileInput(fieldReference.ref)) fieldReference.ref.value = "";
				else {
					fieldReference.ref.value = fieldValue;
					if (!fieldReference.ref.type && !skipRender && !skipValueRender) _subjects.state.next({
						name,
						values: skipClone ? _formValues : _hasValuesSubscriber(name) ? cloneObject(_formValues) : void 0
					});
				}
			}
		}
		(options.shouldDirty || options.shouldTouch) && updateTouchAndDirty(name, field && field._f && !field._f.disabled && (field._f.valueAsNumber || field._f.valueAsDate || field._f.setValueAs) ? getFieldValueAs(value, field._f) : fieldValue, options.shouldTouch, options.shouldDirty, !skipRender);
		options.shouldValidate && trigger(name, { delayError: options.delayError });
		if (options.shouldValidate && field && field._f && field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0)) trigger(field._f.deps);
	};
	const setFieldValues = (name, value, options, skipClone = false, skipRender = false, skipValueRender = false) => {
		for (const fieldKey in value) {
			if (!Object.prototype.hasOwnProperty.call(value, fieldKey)) continue;
			const fieldValue = value[fieldKey];
			const fieldName = name + "." + fieldKey;
			const field = get(_fields, fieldName);
			if (_names.array.has(fieldName)) _subjects.array.next({
				name: fieldName,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			(_names.array.has(name) || isObject(fieldValue) || field && !field._f) && !isDateObject(fieldValue) ? setFieldValues(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender) : setFieldValue(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender);
		}
	};
	const _setValue = (name, value, options, skipClone, skipStateEmit = false) => {
		const field = get(_fields, name);
		const isFieldArray = _names.array.has(name);
		const cloneValue = skipClone ? value : cloneObject(value);
		const isValueUnchanged = deepEqual(get(_formValues, name), cloneValue);
		if (!isValueUnchanged) set(_formValues, name, cloneValue);
		if (isFieldArray) {
			_subjects.array.next({
				name,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			if (_isTracked("isDirty", "dirtyFields") && options.shouldDirty) {
				_updateDirtyFields();
				_formState.isDirty = _getDirty(name, cloneValue);
				if (!skipStateEmit) _subjects.state.next({
					name,
					dirtyFields: _formState.dirtyFields,
					isDirty: _formState.isDirty
				});
			}
			options.shouldValidate && trigger(name, { delayError: options.delayError });
		} else {
			const isEmpty = Array.isArray(cloneValue) && !cloneValue.length || isEmptyObject(cloneValue);
			const skipValueRender = !isValueUnchanged && !skipStateEmit;
			if (!field || field._f || isNullOrUndefined(cloneValue) || isEmpty) setFieldValue(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
			else setFieldValues(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
		}
		if (!isValueUnchanged && !skipStateEmit) {
			const watched = isWatched(name, _names);
			const emittedName = _state.mount || watched ? name : void 0;
			const fieldArrayItemNames = isFieldArray ? [] : getFieldArrayItemNames(_names.array, name);
			const values = skipClone ? _formValues : _hasValuesSubscriber(emittedName) || fieldArrayItemNames.some(_hasValuesSubscriber) ? cloneObject(_formValues) : void 0;
			_subjects.state.next({
				...watched && _formState,
				name: emittedName,
				values
			});
			for (const itemName of fieldArrayItemNames) _subjects.state.next({
				name: itemName,
				values
			});
		}
	};
	const setValue = (name, value, options = {}) => _setValue(name, value, options, false);
	const setValues = (formValues, options = {}) => {
		const updatedFormValues = isFunction(formValues) ? formValues(_formValues) : formValues;
		if (!deepEqual(_formValues, updatedFormValues)) {
			_formValues = {
				..._formValues,
				...updatedFormValues
			};
			for (const fieldName of /* @__PURE__ */ new Set([..._names.mount, ..._names.array])) if (has(updatedFormValues, fieldName)) _setValue(fieldName, get(updatedFormValues, fieldName), options, true, true);
			_subjects.state.next({
				..._formState,
				name: void 0,
				type: void 0,
				..._valuesSubscribers.size ? { values: _formValues } : {}
			});
			if (options.shouldValidate) _setValid();
		}
	};
	const onChange = async (event) => {
		_state.mount = true;
		const target = event.target;
		let name = target.name;
		let isFieldValueUpdated = true;
		const field = get(_fields, name);
		const registerCallId = _registerCallId;
		const _updateIsFieldValueUpdated = (fieldValue) => {
			isFieldValueUpdated = !!get(_fields, name) && !(_registerCallIds[name] > registerCallId) && deepEqual(fieldValue, get(_formValues, name, fieldValue));
		};
		if (field) {
			_state.keepIsValid = false;
			let error;
			let isValid;
			let shouldFlushError = false;
			const fieldValue = target.type ? getFieldValue(field._f) : getEventValue(event);
			const isBlurEvent = event.type === EVENTS.BLUR || event.type === EVENTS.FOCUS_OUT;
			const hasNoValidationEffect = !hasValidation(field._f) && !_options.validate && !_options.resolver && !get(_formState.errors, name) && !field._f.deps;
			const shouldSkipValidation = hasNoValidationEffect || skipValidation(isBlurEvent, get(_formState.touchedFields, name), _formState.isSubmitted, _validationModeAfterSubmit, _validationModeBeforeSubmit);
			const watched = isWatched(name, _names, isBlurEvent);
			set(_formValues, name, cloneObject(fieldValue));
			if (isBlurEvent) {
				if (!target || !target.readOnly) {
					field._f.onBlur && field._f.onBlur(event);
					if (Object.prototype.hasOwnProperty.call(delayErrorCallbacks, name)) {
						shouldFlushError = true;
						delayErrorCallbacks[name](0);
					}
				}
			} else if (field._f.onChange) field._f.onChange(event);
			const fieldState = updateTouchAndDirty(name, fieldValue, isBlurEvent);
			const shouldRender = !isEmptyObject(fieldState) || watched;
			!isBlurEvent && _subjects.state.next({
				name,
				type: event.type,
				..._hasValuesSubscriber(name) ? { values: cloneObject(_formValues) } : {}
			});
			if (shouldSkipValidation) {
				if ((!hasNoValidationEffect || !_formState.isValid) && _isTracked("isValid")) {
					if (_options.mode === "onBlur") {
						if (isBlurEvent) _setValid();
					} else if (!isBlurEvent) _setValid();
				}
				return shouldRender && _subjects.state.next({
					name,
					...watched ? {} : fieldState
				});
			}
			if (!_options.resolver && _options.validate) await validateForm({
				name,
				eventType: event.type
			});
			!isBlurEvent && watched && _subjects.state.next({ ..._formState });
			if (_options.resolver) {
				const resetCallId = _resetCallId;
				const { errors } = await _runSchema([name]);
				if (resetCallId !== _resetCallId) return;
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (!isFieldValueUpdated) {
					!isEmptyObject(fieldState) && _subjects.state.next(fieldState);
					return;
				}
				const previousErrorLookupResult = schemaErrorLookup(_formState.errors, _fields, name);
				const errorLookupResult = schemaErrorLookup(errors, _fields, previousErrorLookupResult.name || name);
				error = errorLookupResult.error;
				name = errorLookupResult.name;
				isValid = isEmptyObject(errors);
			} else {
				const resetCallId = _resetCallId;
				const setValidCallId = ++_setValidCallId;
				_updateIsValidating([name], true);
				error = (await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation))[name];
				if (resetCallId !== _resetCallId) return;
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (isFieldValueUpdated) {
					if (error) isValid = false;
					else if (_isTracked("isValid")) {
						isValid = await executeBuiltInValidation({
							fields: _fields,
							onlyCheckValid: true,
							name,
							eventType: event.type
						});
						if (resetCallId !== _resetCallId) return;
						_updateIsFieldValueUpdated(fieldValue);
						if (setValidCallId !== _setValidCallId) isValid = void 0;
					}
				}
			}
			if (isFieldValueUpdated) {
				field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0) && trigger(field._f.deps);
				shouldRenderByError(name, isValid, error, fieldState);
				shouldFlushError && Object.prototype.hasOwnProperty.call(delayErrorCallbacks, name) && delayErrorCallbacks[name](0);
			}
		}
	};
	const _focusInput = (ref, key) => {
		if (get(_formState.errors, key) && ref.focus) {
			ref.focus();
			return 1;
		}
	};
	const trigger = async (name, options = {}) => {
		_state.keepIsValid = false;
		let isValid;
		let validationResult;
		const fieldNames = convertToArrayPayload(name);
		const resetCallId = _resetCallId;
		if (_options.resolver) {
			const errors = await executeSchemaAndUpdateState(isUndefined(name) ? name : fieldNames);
			isValid = isEmptyObject(errors);
			validationResult = name ? !fieldNames.some((name) => get(errors, name)) : isValid;
		} else if (name) {
			validationResult = (await Promise.all(fieldNames.map(async (fieldName) => {
				const field = get(_fields, fieldName);
				return await executeBuiltInValidation({
					fields: field && field._f ? { [fieldName]: field } : field,
					eventType: EVENTS.TRIGGER
				});
			}))).every(Boolean);
			(validationResult || _formState.isValid) && _setValid();
		} else validationResult = isValid = await executeBuiltInValidation({
			fields: _fields,
			name,
			eventType: EVENTS.TRIGGER
		});
		if (resetCallId !== _resetCallId) return validationResult;
		if (options.delayError && _options.delayError && isString(name)) {
			const error = get(_formState.errors, name);
			if (error) {
				unset(_formState.errors, name);
				delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
				delayErrorCallbacks[name](_options.delayError);
			} else cancelDelayedError(name);
		}
		if (options.shouldTouch) for (const fieldName of name ? fieldNames : _names.mount) !_names.array.has(fieldName) && set(_formState.touchedFields, fieldName, true);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({
			...!isString(name) || _isTracked("isValid") && isValid !== _formState.isValid ? {} : { name },
			..._options.resolver || !name ? { isValid } : {},
			...options.shouldTouch && _isTracked("touchedFields") ? { touchedFields: _formState.touchedFields } : {},
			errors: _formState.errors
		});
		options.shouldFocus && !validationResult && iterateFieldsByAction(_fields, _focusInput, name ? fieldNames : _names.mount);
		return validationResult;
	};
	const getValues = ((fieldNames, config) => {
		let values = isUndefined(fieldNames) && !config ? { ..._state.mount ? _formValues : _defaultValues } : _state.mount ? _formValues : _defaultValues;
		if (config) values = extractFormValues(config.dirtyFields ? _formState.dirtyFields : _formState.touchedFields, values);
		return isUndefined(fieldNames) ? values : isString(fieldNames) ? get(values, fieldNames) : fieldNames.map((name) => get(values, name));
	});
	const getErrors = ((fieldNames) => isUndefined(fieldNames) ? { ..._formState.errors } : isString(fieldNames) ? get(_formState.errors, fieldNames) : fieldNames.map((name) => get(_formState.errors, name)));
	const getFieldState = (name, formState) => {
		const targetFormState = formState || _formState;
		const error = get(targetFormState.errors, name);
		return {
			invalid: !!error,
			isDirty: !!get(targetFormState.dirtyFields, name),
			error,
			isValidating: !!get(targetFormState.validatingFields, name),
			isTouched: !!get(targetFormState.touchedFields, name)
		};
	};
	const clearErrors = (name) => {
		const names = name ? convertToArrayPayload(name) : void 0;
		if (names) names.forEach((inputName) => {
			cancelDelayedErrorTree(inputName);
			unset(_formState.errors, inputName);
			_formState.errors = { ..._formState.errors };
			_subjects.state.next({
				name: inputName,
				errors: _formState.errors
			});
		});
		else {
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = {};
			_subjects.state.next({ errors: _formState.errors });
		}
	};
	const setError = (name, error, options) => {
		cancelDelayedErrorTree(name);
		const field = get(_fields, name, { _f: {} });
		const ref = field._f && field._f.ref;
		const { ref: currentRef, message, type, types, ...restOfErrorTree } = get(_formState.errors, name) || {};
		set(_formState.errors, name, {
			...restOfErrorTree,
			...error,
			ref
		});
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({
			name,
			errors: _formState.errors,
			isValid: false
		});
		options && options.shouldFocus && ref && ref.focus && ref.focus();
	};
	const watch = (name, defaultValue) => {
		if (isFunction(name)) {
			const valuesSubscriber = {};
			_valuesSubscribers.add(valuesSubscriber);
			const { unsubscribe } = _subjects.state.subscribe({ next: (payload) => "values" in payload && name(payload.values || _getWatch(void 0, defaultValue), payload) });
			return { unsubscribe: () => {
				_valuesSubscribers.delete(valuesSubscriber);
				unsubscribe();
			} };
		}
		return _getWatch(name, defaultValue, true);
	};
	const _subscribe = (props) => {
		const valuesSubscriber = {
			name: props.name,
			exact: props.exact
		};
		props.formState && props.formState.values && _valuesSubscribers.add(valuesSubscriber);
		const { unsubscribe } = _subjects.state.subscribe({ next: (formState) => {
			if (shouldSubscribeByName(props.name, formState.name, props.exact) && shouldRenderFormState(formState, props.formState || _proxyFormState, props.reRenderRoot)) {
				const values = formState.values || { ..._formValues };
				props.callback({
					..._formState,
					...formState,
					validatingFields: _formState.validatingFields,
					isValidating: _formState.isValidating,
					values,
					defaultValues: _defaultValues
				});
			}
		} });
		return () => {
			_valuesSubscribers.delete(valuesSubscriber);
			unsubscribe();
		};
	};
	const subscribe = (props) => {
		_state.mount = true;
		const trackedKeys = Object.keys(props.formState || {}).filter((key) => props.formState && props.formState[key]);
		for (const key of trackedKeys) _proxySubscribeFormState[key] = (_proxySubscribeFormState[key] || 0) + 1;
		const unsubscribe = _subscribe({
			...props,
			formState: {
				...defaultProxyFormState,
				...props.formState
			}
		});
		return () => {
			for (const key of trackedKeys.splice(0)) _proxySubscribeFormState[key]--;
			unsubscribe();
		};
	};
	const unregister = (name, options = {}) => {
		const fieldNames = name ? convertToArrayPayload(name) : _names.mount;
		if (!options.keepIsValidating) _updateValidatingFields(fieldNames);
		for (const fieldName of fieldNames) {
			_names.mount.delete(fieldName);
			_names.array.delete(fieldName);
			_names.disabled.delete(fieldName);
			unset(_fields, fieldName);
			!options.keepValue && unset(_formValues, fieldName);
			if (!options.keepError) {
				cancelDelayedErrorTree(fieldName);
				unset(_formState.errors, fieldName);
			}
			!options.keepDirty && unset(_formState.dirtyFields, fieldName);
			!options.keepTouched && unset(_formState.touchedFields, fieldName);
			!_options.shouldUnregister && !options.keepDefaultValue && unset(_defaultValues, fieldName);
		}
		if (!options.keepError) _formState.errors = { ..._formState.errors };
		_valuesSubscribers.size && _subjects.state.next({ values: cloneObject(_formValues) });
		_subjects.state.next({
			..._formState,
			...options.keepDirty ? {} : { isDirty: _getDirty() },
			...options.keepIsValidating ? {} : { isValidating: !isEmptyObject(_formState.validatingFields) }
		});
		!options.keepIsValid && _setValid();
	};
	const _setDisabledField = ({ disabled, name }) => {
		if (isBoolean(disabled) && _state.mount || !!disabled || _names.disabled.has(name)) {
			const disabledStateChanged = _names.disabled.has(name) !== !!disabled;
			disabled ? _names.disabled.add(name) : _names.disabled.delete(name);
			disabledStateChanged && _state.mount && !_state.action && _setValid();
		}
	};
	const register = (name, options = {}) => {
		let field = get(_fields, name);
		const disabledIsDefined = isBoolean(options.disabled) || isBoolean(_options.disabled);
		const shouldRevalidateRemount = !_names.registerName.has(name) && field && field._f && !field._f.mount;
		if (!field || !field._f) _registerCallIds[name] = ++_registerCallId;
		set(_fields, name, {
			...field || {},
			_f: {
				...field && field._f ? field._f : { ref: { name } },
				name,
				mount: true,
				...options
			}
		});
		_names.mount.add(name);
		if (field && field._f) {
			const nextField = get(_fields, name);
			for (const rule of REGISTER_VALIDATION_RULES) if (!(rule in options)) delete nextField._f[rule];
		}
		if (field && !shouldRevalidateRemount) _setDisabledField({
			disabled: isBoolean(options.disabled) ? options.disabled : _options.disabled,
			name
		});
		else updateValidAndValue(name, true, options.value);
		return {
			...disabledIsDefined ? { disabled: options.disabled || _options.disabled } : {},
			..._options.progressive ? {
				required: !!getRuleValue(options.required),
				min: getRuleValue(options.min),
				max: getRuleValue(options.max),
				minLength: getRuleValue(options.minLength),
				maxLength: getRuleValue(options.maxLength),
				pattern: getRuleValue(options.pattern)
			} : {},
			name,
			onChange,
			onBlur: onChange,
			ref: (ref) => {
				if (ref) {
					_names.registerName.add(name);
					register(name, options);
					_names.registerName.delete(name);
					field = get(_fields, name);
					const fieldRef = isUndefined(ref.value) ? ref.querySelectorAll ? ref.querySelectorAll("input,select,textarea")[0] || ref : ref : ref;
					const radioOrCheckbox = isRadioOrCheckbox(fieldRef);
					const refs = field._f.refs || [];
					if (radioOrCheckbox ? refs.find((option) => option === fieldRef) : fieldRef === field._f.ref) return;
					const newField = { ...field._f };
					if (radioOrCheckbox) {
						newField.refs = [
							...refs.filter(live),
							fieldRef,
							...Array.isArray(get(_defaultValues, name)) ? [{}] : []
						];
						newField.ref = {
							type: fieldRef.type,
							name
						};
					} else {
						newField.ref = fieldRef;
						delete newField.refs;
					}
					set(_fields, name, { _f: newField });
					updateValidAndValue(name, false, void 0, fieldRef);
				} else {
					field = get(_fields, name, {});
					if (field._f) field._f.mount = false;
					(_options.shouldUnregister || options.shouldUnregister) && !(isNameInFieldArray(_names.array, name) && _state.action) && _names.unMount.add(name);
				}
			}
		};
	};
	const _focusError = () => _options.shouldFocusError && !_options.shouldUseNativeValidation && iterateFieldsByAction(_fields, _focusInput, _names.mount);
	const _disableForm = (disabled) => {
		if (isBoolean(disabled)) {
			_subjects.state.next({ disabled });
			iterateFieldsByAction(_fields, (ref, name) => {
				const currentField = get(_fields, name);
				if (currentField) {
					ref.disabled = currentField._f.disabled || disabled;
					if (Array.isArray(currentField._f.refs)) currentField._f.refs.forEach((inputRef) => {
						inputRef.disabled = currentField._f.disabled || disabled;
					});
				}
			}, 0);
		}
	};
	const handleSubmit = (onValid, onInvalid) => async (e) => {
		let result = void 0;
		let onValidError = void 0;
		if (e) {
			e.preventDefault && e.preventDefault();
			e.persist && e.persist();
		}
		let fieldValues = cloneObject(_formValues);
		_subjects.state.next({ isSubmitting: true });
		const resetCallId = _resetCallId;
		const onSubmitError = (error) => {
			if (resetCallId === _resetCallId) _subjects.state.next({ isSubmitting: false });
			throw error;
		};
		if (_options.resolver) {
			let validationResult;
			try {
				validationResult = await _runSchema();
			} catch (error) {
				onSubmitError(error);
			}
			const { errors, values } = validationResult;
			if (resetCallId !== _resetCallId) return;
			_updateIsValidating();
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = errors;
			fieldValues = cloneObject(values);
		} else {
			try {
				await executeBuiltInValidation({
					fields: _fields,
					eventType: EVENTS.SUBMIT
				});
			} catch (error) {
				onSubmitError(error);
			}
			if (resetCallId !== _resetCallId) return;
			unset(_formState.errors, ROOT_ERROR_TYPE);
			_formState.errors = { ..._formState.errors };
		}
		if (_names.disabled.size) for (const name of _names.disabled) unset(fieldValues, name);
		if (isEmptyObject(_formState.errors)) {
			_subjects.state.next({ errors: {} });
			try {
				result = await onValid(fieldValues, e);
			} catch (error) {
				onValidError = error;
			}
		} else {
			if (onInvalid) try {
				await onInvalid({ ..._formState.errors }, e);
			} catch (error) {
				onSubmitError(error);
			}
			_focusError();
			setTimeout(_focusError);
		}
		_subjects.state.next({
			isSubmitted: true,
			isSubmitting: false,
			isSubmitSuccessful: isEmptyObject(_formState.errors) && !onValidError,
			submitCount: _formState.submitCount + 1,
			errors: _formState.errors
		});
		if (onValidError) throw onValidError;
		return result;
	};
	const resetField = (name, options = {}) => {
		if (get(_fields, name)) {
			_updateValidatingFields([name]);
			if (isUndefined(options.defaultValue)) setValue(name, cloneObject(get(_defaultValues, name)));
			else {
				setValue(name, options.defaultValue);
				set(_defaultValues, name, cloneObject(options.defaultValue));
			}
			if (!options.keepTouched) unset(_formState.touchedFields, name);
			if (!options.keepDirty) {
				unset(_formState.dirtyFields, name);
				_formState.isDirty = !isUndefined(options.defaultValue) ? _getDirty(name, cloneObject(get(_defaultValues, name))) : _getDirty();
			}
			if (!options.keepError) {
				cancelDelayedErrorTree(name);
				unset(_formState.errors, name);
				_formState.errors = { ..._formState.errors };
				_setValid();
			}
			_subjects.state.next({
				..._formState,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _reset = (formValues, keepStateOptions = {}) => {
		_resetCallId++;
		_setValidCallId++;
		const updatedValues = formValues ? cloneObject(formValues) : _defaultValues;
		const cloneUpdatedValues = cloneObject(updatedValues);
		const isEmptyResetValues = isEmptyObject(formValues);
		const values = cloneUpdatedValues;
		const fieldRefs = _fields;
		Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
		if (!keepStateOptions.keepDefaultValues) _defaultValues = updatedValues;
		if (!keepStateOptions.keepValues) {
			if (keepStateOptions.keepDirtyValues) {
				const fieldsToCheck = /* @__PURE__ */ new Set([..._names.mount, ...collectDirtyFieldNames(getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs), _formState.dirtyFields)]);
				for (const fieldName of fieldsToCheck) {
					const isDirty = get(_formState.dirtyFields, fieldName);
					const existingValue = get(_formValues, fieldName);
					const newValue = get(values, fieldName);
					if (isDirty && !isUndefined(existingValue)) set(values, fieldName, existingValue);
					else if (!isDirty && !isUndefined(newValue)) setValue(fieldName, newValue);
				}
			} else {
				if (isWeb && isUndefined(formValues)) for (const name of _names.mount) {
					const field = get(_fields, name);
					if (field && field._f) {
						const fieldReference = Array.isArray(field._f.refs) ? field._f.refs[0] : field._f.ref;
						if (isHTMLElement(fieldReference)) {
							const form = fieldReference.closest("form");
							if (form) {
								form.reset();
								break;
							}
						}
					}
				}
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) setValue(fieldName, get(values, fieldName));
				else _fields = {};
			}
			if (_options.shouldUnregister) {
				_formValues = keepStateOptions.keepDefaultValues ? cloneObject(_defaultValues) : {};
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) set(_formValues, fieldName, get(values, fieldName));
			} else _formValues = cloneObject(values);
			_subjects.array.next({ values: { ...values } });
			_subjects.state.next({
				name: void 0,
				type: void 0,
				values: { ...values }
			});
		}
		_names = {
			mount: keepStateOptions.keepDirtyValues ? _names.mount : /* @__PURE__ */ new Set(),
			unMount: /* @__PURE__ */ new Set(),
			array: /* @__PURE__ */ new Set(),
			registerName: /* @__PURE__ */ new Set(),
			disabled: keepStateOptions.keepValues || keepStateOptions.keepDirtyValues || keepStateOptions.keepFieldsRef ? new Set([..._names.disabled].filter((name) => get(_fields, name))) : /* @__PURE__ */ new Set(),
			watch: /* @__PURE__ */ new Set(),
			watchAll: false,
			focus: ""
		};
		_state.mount = !_proxyFormState.isValid || !!keepStateOptions.keepIsValid || !!keepStateOptions.keepDirtyValues || !_options.shouldUnregister && !isEmptyObject(values);
		_state.watch = !!_options.shouldUnregister;
		_state.keepIsValid = !!keepStateOptions.keepIsValid;
		_state.action = false;
		_state.actionArrayLengths.clear();
		_dirtyFieldsStale = false;
		if (!keepStateOptions.keepErrors) _formState.errors = {};
		_subjects.state.next({
			submitCount: keepStateOptions.keepSubmitCount ? _formState.submitCount : 0,
			isDirty: isEmptyResetValues ? false : keepStateOptions.keepDirty ? _formState.isDirty : keepStateOptions.keepValues ? _getDirty() : !!(keepStateOptions.keepDefaultValues && formValues && !deepEqual(formValues, _defaultValues)),
			isSubmitted: keepStateOptions.keepIsSubmitted ? _formState.isSubmitted : false,
			dirtyFields: isEmptyResetValues ? {} : keepStateOptions.keepDirtyValues ? keepStateOptions.keepDefaultValues && _formValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : _formState.dirtyFields : keepStateOptions.keepDefaultValues && formValues ? getDirtyFields(_defaultValues, formValues, void 0, fieldRefs) : keepStateOptions.keepDirty ? _formState.dirtyFields : keepStateOptions.keepValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : {},
			touchedFields: keepStateOptions.keepTouched ? _formState.touchedFields : {},
			...!keepStateOptions.keepIsValidating && (_formState.isValidating || !isEmptyObject(_formState.validatingFields)) ? {
				validatingFields: {},
				isValidating: false
			} : null,
			errors: keepStateOptions.keepErrors ? _formState.errors : {},
			isSubmitSuccessful: keepStateOptions.keepIsSubmitSuccessful ? _formState.isSubmitSuccessful : false,
			isSubmitting: false,
			defaultValues: _defaultValues
		});
	};
	const reset = (formValues, keepStateOptions) => _reset(isFunction(formValues) ? formValues(_formValues) : formValues, {
		..._options.resetOptions,
		...keepStateOptions
	});
	const setFocus = (name, options = {}) => {
		const field = get(_fields, name);
		const fieldReference = field && field._f;
		if (fieldReference) {
			const fieldRef = fieldReference.refs ? fieldReference.refs[0] : fieldReference.ref;
			if (fieldRef.focus) setTimeout(() => {
				fieldRef.focus();
				options.shouldSelect && isFunction(fieldRef.select) && fieldRef.select();
			});
		}
	};
	const _setFormState = (updatedFormState) => {
		const { name, type, values, ...formState } = updatedFormState;
		if (Object.keys(formState).length) _formState = {
			..._formState,
			...formState
		};
	};
	_subjects.state.subscribe({ next: _setFormState });
	const _resetDefaultValues = () => isFunction(_options.defaultValues) && _options.defaultValues().then((values) => {
		reset(values, _options.resetOptions);
		_subjects.state.next({ isLoading: false });
	});
	const resetDefaultValues = (values, options = {}) => {
		_defaultValues = cloneObject(values);
		if (!options.keepDirty) {
			const newDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
			_formState.dirtyFields = newDirtyFields;
			_formState.isDirty = !isEmptyObject(newDirtyFields);
		}
		if (!options.keepIsValid) _setValid();
		_subjects.state.next({
			..._formState,
			defaultValues: _defaultValues
		});
	};
	const methods = {
		control: {
			register,
			unregister,
			getFieldState,
			handleSubmit,
			setError,
			_subscribe,
			_runSchema,
			_updateIsValidating,
			_focusError,
			_getWatch,
			_getDirty,
			_setValid,
			_setFieldArray,
			_setDisabledField,
			_setErrors,
			_getFieldArray,
			_reset,
			_resetDefaultValues,
			_removeUnmounted,
			_disableForm,
			_subjects,
			_proxyFormState,
			get _fields() {
				return _fields;
			},
			get _formValues() {
				return _formValues;
			},
			get _state() {
				return _state;
			},
			set _state(value) {
				_state = value;
			},
			get _defaultValues() {
				return _defaultValues;
			},
			get _names() {
				return _names;
			},
			set _names(value) {
				_names = value;
			},
			get _formState() {
				return _formState;
			},
			get _options() {
				return _options;
			},
			set _options(value) {
				_options = {
					..._options,
					...value
				};
				_validationModeBeforeSubmit = getValidationModes(_options.mode);
				_validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
				shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
			}
		},
		subscribe,
		trigger,
		register,
		handleSubmit,
		watch,
		setValue,
		setValues,
		getValues,
		getErrors,
		reset,
		resetField,
		resetDefaultValues,
		clearErrors,
		unregister,
		setError,
		setFocus,
		getFieldState
	};
	return {
		...methods,
		formControl: methods
	};
}
var RESET_OPTIONS = {
	mode: defaultOptions.mode,
	reValidateMode: defaultOptions.reValidateMode,
	shouldFocusError: defaultOptions.shouldFocusError,
	resolver: void 0,
	criteriaMode: void 0,
	delayError: void 0,
	shouldUnregister: void 0,
	shouldUseNativeValidation: void 0,
	context: void 0,
	progressive: void 0,
	resetOptions: void 0
};
/**
* Core hook for managing a form. Returns all methods and state for
* registration, validation, and submission.
*
* @see [API](https://react-hook-form.com/docs/useform)
*
* @example
* ```tsx
* const { register, handleSubmit, formState: { errors } } = useForm<FormValues>();
* <form onSubmit={handleSubmit(onSubmit)}>
*   <input {...register("email", { required: true })} />
* </form>
* ```
*/
function useForm(props = {}) {
	const _formControl = import_react.useRef(void 0);
	const _values = import_react.useRef(void 0);
	const _formControlProp = import_react.useRef(props.formControl);
	const _hadDisabled = import_react.useRef(false);
	const _hadValidate = import_react.useRef(!!props.validate);
	const _hadErrors = import_react.useRef(!!props.errors);
	const _isMounted = import_react.useRef(false);
	const [formState, updateFormState] = import_react.useState(() => ({
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(props.defaultValues),
		errors: props.errors || {},
		disabled: props.disabled || false,
		defaultValues: isFunction(props.defaultValues) ? void 0 : props.defaultValues
	}));
	if (!_formControl.current || props.formControl && _formControlProp.current !== props.formControl) {
		_formControlProp.current = props.formControl;
		_hadDisabled.current = false;
		if (props.formControl) {
			_formControl.current = {
				...props.formControl,
				formState
			};
			if (props.defaultValues && !isFunction(props.defaultValues)) props.formControl.reset(props.defaultValues, props.resetOptions);
		} else {
			const { formControl, ...rest } = createFormControl(props);
			_formControl.current = {
				...rest,
				formState
			};
		}
	}
	const control = _formControl.current.control;
	const previousOptions = control._options;
	const removedOptions = {};
	for (const key in RESET_OPTIONS) if (key in previousOptions && !(key in props)) removedOptions[key] = RESET_OPTIONS[key];
	if (_hadDisabled.current && !props.disabled) removedOptions.disabled = false;
	control._options = {
		...removedOptions,
		...props,
		validate: props.validate
	};
	const getCurrentFormState = () => ({
		...control._formState,
		defaultValues: control._defaultValues
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFormState);
	useIsomorphicLayoutEffect(() => {
		resyncIfNeeded(true, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			formState: control._proxyFormState,
			callback: () => updateFormState({
				...control._formState,
				defaultValues: control._defaultValues
			}),
			reRenderRoot: true
		});
		updateFormState((data) => ({
			...data,
			isReady: true
		}));
		control._formState.isReady = true;
		control._subjects.state.next({ isReady: true });
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFormState);
		};
	}, [
		control,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => {
		control._disableForm(_hadDisabled.current && !props.disabled ? false : props.disabled);
		_hadDisabled.current = !!props.disabled;
	}, [control, props.disabled]);
	import_react.useEffect(() => {
		if (props.mode) control._options.mode = props.mode;
		if (props.reValidateMode) control._options.reValidateMode = props.reValidateMode;
	}, [
		control,
		props.mode,
		props.reValidateMode
	]);
	import_react.useEffect(() => {
		if (props.errors) {
			control._setErrors(props.errors);
			control._focusError();
		} else if (_hadErrors.current) control._setErrors({});
		_hadErrors.current = !!props.errors;
	}, [control, props.errors]);
	import_react.useEffect(() => {
		if (_hadValidate.current && !props.validate) _formControl.current && _formControl.current.clearErrors(FORM_ERROR_TYPE);
		_hadValidate.current = !!props.validate;
	}, [props.validate]);
	import_react.useEffect(() => {
		props.shouldUnregister && control._subjects.state.next({ values: control._getWatch() });
	}, [control, props.shouldUnregister]);
	import_react.useEffect(() => {
		if (control._proxyFormState.isDirty) {
			const isDirty = control._getDirty();
			if (isDirty !== formState.isDirty) control._subjects.state.next({ isDirty });
		}
	}, [control, formState.isDirty]);
	import_react.useEffect(() => {
		if (props.values && !deepEqual(props.values, _values.current)) {
			control._reset(props.values, {
				keepFieldsRef: true,
				...control._options.resetOptions
			});
			if (!(control._options.resetOptions && control._options.resetOptions.keepIsValid)) control._setValid();
			_values.current = props.values;
			updateFormState((state) => ({ ...state }));
		} else control._resetDefaultValues();
	}, [control, props.values]);
	import_react.useEffect(() => {
		if (!control._state.mount || !_isMounted.current && !props.values) {
			control._setValid();
			control._state.mount = true;
		}
		_isMounted.current = true;
		if (control._state.watch) {
			control._state.watch = false;
			control._subjects.state.next({ ...control._formState });
		}
		control._removeUnmounted();
	});
	_formControl.current.formState = import_react.useMemo(() => getProxyFormState(formState, control), [control, formState]);
	return _formControl.current;
}
var HookFormContext = import_react.createContext(null);
HookFormContext.displayName = "HookFormContext";
/**
* Retrieves all `useForm` methods from the nearest `FormProvider`.
* Use in deeply nested components to avoid prop-drilling.
*
* @see [API](https://react-hook-form.com/docs/useformcontext)
*
* @example
* ```tsx
* const { register } = useFormContext<FormValues>();
* ```
*/
var useFormContext = () => import_react.useContext(HookFormContext);
/**
* Provides all `useForm` methods to the component tree via React Context.
* Pair with `useFormContext` to consume them in any descendant.
*
* @see [API](https://react-hook-form.com/docs/useformcontext)
*
* @example
* ```tsx
* <FormProvider {...methods}>
*   <form onSubmit={methods.handleSubmit(onSubmit)}>{children}</form>
* </FormProvider>
* ```
*/
var FormProvider = ({ children, watch, getValues, getErrors, getFieldState, setError, clearErrors, setValue, setValues, trigger, formState, resetField, reset, resetDefaultValues, handleSubmit, unregister, control, register, setFocus, subscribe }) => {
	const memoizedValue = import_react.useMemo(() => ({
		watch,
		getValues,
		getErrors,
		getFieldState,
		setError,
		clearErrors,
		setValue,
		setValues,
		trigger,
		formState,
		resetField,
		reset,
		resetDefaultValues,
		handleSubmit,
		unregister,
		control,
		register,
		setFocus,
		subscribe
	}), [
		clearErrors,
		control,
		formState,
		getErrors,
		getFieldState,
		getValues,
		handleSubmit,
		register,
		reset,
		resetDefaultValues,
		resetField,
		setError,
		setFocus,
		setValue,
		setValues,
		subscribe,
		trigger,
		unregister,
		watch
	]);
	return import_react.createElement(HookFormContext.Provider, { value: memoizedValue }, import_react.createElement(HookFormControlContext.Provider, { value: memoizedValue.control }, children));
};
/**
* Component wrapper around `useWatch`. Re-renders only when watched fields change.
*
* @see [API](https://react-hook-form.com/docs/usewatch)
*
* @example
* ```tsx
* <Watch
*   control={control}
*   names={["foo", "bar"]}
*   render={([foo, bar]) => <span>{foo} {bar}</span>}
* />
* ```
*/
var Watch = (props) => props.render(useWatch({
	name: props.names,
	...props
}));
export { Controller, ErrorMessage, FieldArray, Form, FormProvider, FormState, FormStateSubscribe, Watch, appendErrors, createFormControl, get, set, useController, useFieldArray, useForm, useFormContext, useFormState, useWatch };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtaG9vay1mb3JtLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL3JlYWN0LWhvb2stZm9ybS9kaXN0L2luZGV4LmVzbS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxudmFyIGlzQ2hlY2tCb3hJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdjaGVja2JveCc7XG5cbnZhciBpc0ZpbGVJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdmaWxlJztcblxudmFyIGlzRGF0ZU9iamVjdCA9ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBEYXRlO1xuXG52YXIgaXNOdWxsT3JVbmRlZmluZWQgPSAodmFsdWUpID0+IHZhbHVlID09IG51bGw7XG5cbmNvbnN0IGlzT2JqZWN0VHlwZSA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JztcbnZhciBpc09iamVjdCA9ICh2YWx1ZSkgPT4gIWlzTnVsbE9yVW5kZWZpbmVkKHZhbHVlKSAmJlxuICAgICFBcnJheS5pc0FycmF5KHZhbHVlKSAmJlxuICAgIGlzT2JqZWN0VHlwZSh2YWx1ZSkgJiZcbiAgICAhaXNEYXRlT2JqZWN0KHZhbHVlKTtcblxudmFyIGdldEV2ZW50VmFsdWUgPSAoZXZlbnQpID0+IGlzT2JqZWN0KGV2ZW50KSAmJiBldmVudC50YXJnZXRcbiAgICA/IGlzQ2hlY2tCb3hJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgID8gZXZlbnQudGFyZ2V0LmNoZWNrZWRcbiAgICAgICAgOiBpc0ZpbGVJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgICAgICA/IGV2ZW50LnRhcmdldC5maWxlc1xuICAgICAgICAgICAgOiBldmVudC50YXJnZXQudmFsdWVcbiAgICA6IGV2ZW50O1xuXG5jb25zdCBGSUVMRF9QQVRIX1JFID0gL1suW1xcXSdcIl0vO1xudmFyIHN0cmluZ1RvUGF0aCA9IChpbnB1dCkgPT4gaW5wdXQuc3BsaXQoRklFTERfUEFUSF9SRSkuZmlsdGVyKEJvb2xlYW4pO1xuXG5mdW5jdGlvbiBnZXROdWxsQW5jZXN0b3JWYWx1ZShjb250cm9sLCBuYW1lKSB7XG4gICAgY29uc3Qgc2VnbWVudHMgPSBzdHJpbmdUb1BhdGgobmFtZSk7XG4gICAgbGV0IGZvcm1WYWx1ZXMgPSBjb250cm9sLl9mb3JtVmFsdWVzO1xuICAgIGxldCBkZWZhdWx0VmFsdWVzID0gY29udHJvbC5fZGVmYXVsdFZhbHVlcztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICBjb25zdCBrZXkgPSBzZWdtZW50c1tpXTtcbiAgICAgICAgZm9ybVZhbHVlcyA9XG4gICAgICAgICAgICBmb3JtVmFsdWVzID09IG51bGxcbiAgICAgICAgICAgICAgICA/IGZvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGZvcm1WYWx1ZXNba2V5XTtcbiAgICAgICAgZGVmYXVsdFZhbHVlcyA9XG4gICAgICAgICAgICBkZWZhdWx0VmFsdWVzID09IG51bGxcbiAgICAgICAgICAgICAgICA/IGRlZmF1bHRWYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGRlZmF1bHRWYWx1ZXNba2V5XTtcbiAgICAgICAgaWYgKGZvcm1WYWx1ZXMgPT09IG51bGwgfHwgZGVmYXVsdFZhbHVlcyA9PT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxudmFyIGlzTmFtZUluRmllbGRBcnJheSA9IChuYW1lcywgbmFtZSkgPT4gbmFtZVxuICAgIC5zcGxpdCgnLicpXG4gICAgLnNvbWUoKHBhcnQsIGluZGV4LCBhcnIpID0+ICFpc05hTihOdW1iZXIocGFydCkpICYmIG5hbWVzLmhhcyhhcnIuc2xpY2UoMCwgaW5kZXgpLmpvaW4oJy4nKSkpO1xuXG52YXIgaXNXZWIgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiB3aW5kb3cuSFRNTEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJztcblxuZnVuY3Rpb24gY2xvbmVPYmplY3QoZGF0YSkge1xuICAgIGlmIChkYXRhID09PSBudWxsIHx8IHR5cGVvZiBkYXRhICE9PSAnb2JqZWN0Jykge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgaWYgKGRhdGEgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgICAgIHJldHVybiBuZXcgRGF0ZShkYXRhKTtcbiAgICB9XG4gICAgY29uc3QgaXNCbG9iSW5zdGFuY2UgPSB0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgZGF0YSBpbnN0YW5jZW9mIEJsb2I7XG4gICAgY29uc3QgaXNGaWxlTGlzdEluc3RhbmNlID0gdHlwZW9mIEZpbGVMaXN0ICE9PSAndW5kZWZpbmVkJyAmJiBkYXRhIGluc3RhbmNlb2YgRmlsZUxpc3Q7XG4gICAgaWYgKGlzV2ViICYmIChpc0Jsb2JJbnN0YW5jZSB8fCBpc0ZpbGVMaXN0SW5zdGFuY2UpKSB7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICBjb25zdCBpc0FycmF5ID0gQXJyYXkuaXNBcnJheShkYXRhKTtcbiAgICBjb25zdCBwcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YoZGF0YSk7XG4gICAgaWYgKCFpc0FycmF5ICYmIHByb3RvdHlwZSAmJiBwcm90b3R5cGUuY29uc3RydWN0b3IgIT09IE9iamVjdCkge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgY29uc3QgY29weSA9IGlzQXJyYXkgPyBuZXcgQXJyYXkoZGF0YS5sZW5ndGgpIDogT2JqZWN0LmNyZWF0ZShwcm90b3R5cGUpO1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkYXRhLCBrZXkpKSB7XG4gICAgICAgICAgICBjb3B5W2tleV0gPSBjbG9uZU9iamVjdChkYXRhW2tleV0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjb3B5O1xufVxuXG5jb25zdCBFVkVOVFMgPSB7XG4gICAgQkxVUjogJ2JsdXInLFxuICAgIEZPQ1VTX09VVDogJ2ZvY3Vzb3V0JyxcbiAgICBDSEFOR0U6ICdjaGFuZ2UnLFxuICAgIFNVQk1JVDogJ3N1Ym1pdCcsXG4gICAgVFJJR0dFUjogJ3RyaWdnZXInLFxuICAgIFZBTElEOiAndmFsaWQnLFxufTtcbmNvbnN0IFZBTElEQVRJT05fTU9ERSA9IHtcbiAgICBvbkJsdXI6ICdvbkJsdXInLFxuICAgIG9uQ2hhbmdlOiAnb25DaGFuZ2UnLFxuICAgIG9uU3VibWl0OiAnb25TdWJtaXQnLFxuICAgIG9uVG91Y2hlZDogJ29uVG91Y2hlZCcsXG4gICAgYWxsOiAnYWxsJyxcbn07XG5jb25zdCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTID0ge1xuICAgIG1heDogJ21heCcsXG4gICAgbWluOiAnbWluJyxcbiAgICBtYXhMZW5ndGg6ICdtYXhMZW5ndGgnLFxuICAgIG1pbkxlbmd0aDogJ21pbkxlbmd0aCcsXG4gICAgcGF0dGVybjogJ3BhdHRlcm4nLFxuICAgIHJlcXVpcmVkOiAncmVxdWlyZWQnLFxuICAgIHZhbGlkYXRlOiAndmFsaWRhdGUnLFxufTtcbmNvbnN0IFJFR0lTVEVSX1ZBTElEQVRJT05fUlVMRVMgPSBbXG4gICAgSU5QVVRfVkFMSURBVElPTl9SVUxFUy5yZXF1aXJlZCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbixcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbkxlbmd0aCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heExlbmd0aCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnBhdHRlcm4sXG4gICAgSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSxcbl07XG5jb25zdCBGT1JNX0VSUk9SX1RZUEUgPSAnZm9ybSc7XG5jb25zdCBST09UX0VSUk9SX1RZUEUgPSAncm9vdCc7XG5jb25zdCBQUk9UT1RZUEVfS0VZV09SRFMgPSBbJ19fcHJvdG9fXycsICdjb25zdHJ1Y3RvcicsICdwcm90b3R5cGUnXTtcblxuY29uc3QgSVNfS0VZX1JFID0gL15cXHcqJC87XG52YXIgaXNLZXkgPSAodmFsdWUpID0+IElTX0tFWV9SRS50ZXN0KHZhbHVlKTtcblxudmFyIGlzVW5kZWZpbmVkID0gKHZhbCkgPT4gdmFsID09PSB1bmRlZmluZWQ7XG5cbnZhciBnZXQgPSAob2JqZWN0LCBwYXRoLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgICBpZiAoIXBhdGggfHwgIWlzT2JqZWN0KG9iamVjdCkpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgcGF0aHMgPSBpc0tleShwYXRoKSA/IFtwYXRoXSA6IHN0cmluZ1RvUGF0aChwYXRoKTtcbiAgICBpZiAocGF0aHMuc29tZSgoa2V5KSA9PiBQUk9UT1RZUEVfS0VZV09SRFMuaW5jbHVkZXMoa2V5KSkpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gcGF0aHMucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuICAgICAgICByZXR1cm4gaXNOdWxsT3JVbmRlZmluZWQocmVzdWx0KVxuICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgIDogcmVzdWx0W2tleV07XG4gICAgfSwgb2JqZWN0KTtcbiAgICByZXR1cm4gKGlzVW5kZWZpbmVkKHJlc3VsdCkgfHwgcmVzdWx0ID09PSBvYmplY3RcbiAgICAgICAgPyBpc1VuZGVmaW5lZChvYmplY3RbcGF0aF0pXG4gICAgICAgICAgICA/IGRlZmF1bHRWYWx1ZVxuICAgICAgICAgICAgOiBvYmplY3RbcGF0aF1cbiAgICAgICAgOiByZXN1bHQpO1xufTtcblxudmFyIGlzQm9vbGVhbiA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbic7XG5cbnZhciBpc0Z1bmN0aW9uID0gKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbic7XG5cbnZhciBzZXQgPSAob2JqZWN0LCBwYXRoLCB2YWx1ZSkgPT4ge1xuICAgIGxldCBpbmRleCA9IC0xO1xuICAgIGNvbnN0IHRlbXBQYXRoID0gaXNLZXkocGF0aCkgPyBbcGF0aF0gOiBzdHJpbmdUb1BhdGgocGF0aCk7XG4gICAgY29uc3QgbGVuZ3RoID0gdGVtcFBhdGgubGVuZ3RoO1xuICAgIGNvbnN0IGxhc3RJbmRleCA9IGxlbmd0aCAtIDE7XG4gICAgd2hpbGUgKCsraW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gdGVtcFBhdGhbaW5kZXhdO1xuICAgICAgICBsZXQgbmV3VmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgaWYgKGluZGV4ICE9PSBsYXN0SW5kZXgpIHtcbiAgICAgICAgICAgIGNvbnN0IG9ialZhbHVlID0gb2JqZWN0W2tleV07XG4gICAgICAgICAgICBuZXdWYWx1ZSA9XG4gICAgICAgICAgICAgICAgaXNPYmplY3Qob2JqVmFsdWUpIHx8IEFycmF5LmlzQXJyYXkob2JqVmFsdWUpXG4gICAgICAgICAgICAgICAgICAgID8gb2JqVmFsdWVcbiAgICAgICAgICAgICAgICAgICAgOiAhaXNOYU4oK3RlbXBQYXRoW2luZGV4ICsgMV0pXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFtdXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHt9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChQUk9UT1RZUEVfS0VZV09SRFMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIG9iamVjdFtrZXldID0gbmV3VmFsdWU7XG4gICAgICAgIG9iamVjdCA9IG9iamVjdFtrZXldO1xuICAgIH1cbn07XG5cbi8qKlxuICogU2VwYXJhdGUgY29udGV4dCBmb3IgYGNvbnRyb2xgIHRvIHByZXZlbnQgdW5uZWNlc3NhcnkgcmVyZW5kZXJzLlxuICogSW50ZXJuYWwgaG9va3MgdGhhdCBvbmx5IG5lZWQgY29udHJvbCB1c2UgdGhpcyBpbnN0ZWFkIG9mIGZ1bGwgZm9ybSBjb250ZXh0LlxuICovXG5jb25zdCBIb29rRm9ybUNvbnRyb2xDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbkhvb2tGb3JtQ29udHJvbENvbnRleHQuZGlzcGxheU5hbWUgPSAnSG9va0Zvcm1Db250cm9sQ29udGV4dCc7XG4vKipcbiAqIEBpbnRlcm5hbCBJbnRlcm5hbCBob29rIHRvIGFjY2VzcyBvbmx5IGNvbnRyb2wgZnJvbSBjb250ZXh0LlxuICovXG5jb25zdCB1c2VGb3JtQ29udHJvbENvbnRleHQgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KEhvb2tGb3JtQ29udHJvbENvbnRleHQpO1xuXG52YXIgZ2V0UHJveHlGb3JtU3RhdGUgPSAoZm9ybVN0YXRlLCBjb250cm9sLCBsb2NhbFByb3h5Rm9ybVN0YXRlLCBpc1Jvb3QgPSB0cnVlKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZm9ybVN0YXRlKSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXN1bHQsIGtleSwge1xuICAgICAgICAgICAgZ2V0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgX2tleSA9IGtleTtcbiAgICAgICAgICAgICAgICBpZiAoY29udHJvbC5fcHJveHlGb3JtU3RhdGVbX2tleV0gIT09IFZBTElEQVRJT05fTU9ERS5hbGwpIHtcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fcHJveHlGb3JtU3RhdGVbX2tleV0gPSAhaXNSb290IHx8IFZBTElEQVRJT05fTU9ERS5hbGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGxvY2FsUHJveHlGb3JtU3RhdGUgJiYgKGxvY2FsUHJveHlGb3JtU3RhdGVbX2tleV0gPSB0cnVlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZm9ybVN0YXRlW19rZXldO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuXG5jb25zdCB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0ID0gaXNXZWJcbiAgICA/IFJlYWN0LnVzZUxheW91dEVmZmVjdFxuICAgIDogUmVhY3QudXNlRWZmZWN0O1xuXG52YXIgaXNQbGFpbk9iamVjdCA9ICh0ZW1wT2JqZWN0KSA9PiB7XG4gICAgY29uc3QgcHJvdG90eXBlQ29weSA9IHRlbXBPYmplY3QuY29uc3RydWN0b3IgJiYgdGVtcE9iamVjdC5jb25zdHJ1Y3Rvci5wcm90b3R5cGU7XG4gICAgcmV0dXJuIChpc09iamVjdChwcm90b3R5cGVDb3B5KSAmJiBwcm90b3R5cGVDb3B5Lmhhc093blByb3BlcnR5KCdpc1Byb3RvdHlwZU9mJykpO1xufTtcblxudmFyIGlzUHJpbWl0aXZlID0gKHZhbHVlKSA9PiBpc051bGxPclVuZGVmaW5lZCh2YWx1ZSkgfHwgIWlzT2JqZWN0VHlwZSh2YWx1ZSk7XG5cbmNvbnN0IGlzRW1wdHlPYmplY3RXaXRoQ3VzdG9tUHJvdG90eXBlID0gKG9iamVjdCwga2V5cykgPT4ga2V5cy5sZW5ndGggPT09IDAgJiZcbiAgICAhQXJyYXkuaXNBcnJheShvYmplY3QpICYmXG4gICAgT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iamVjdCkgIT09IG51bGwgJiZcbiAgICAhaXNQbGFpbk9iamVjdChvYmplY3QpO1xuZnVuY3Rpb24gZGVlcEVxdWFsKG9iamVjdDEsIG9iamVjdDIsIGlzRXJyb3JPYmplY3QgPSBmYWxzZSwgdmlzaXRlZCA9IG5ldyBXZWFrTWFwKCkpIHtcbiAgICBpZiAob2JqZWN0MSA9PT0gb2JqZWN0Mikge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGlzUHJpbWl0aXZlKG9iamVjdDEpIHx8IGlzUHJpbWl0aXZlKG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QuaXMob2JqZWN0MSwgb2JqZWN0Mik7XG4gICAgfVxuICAgIGlmIChpc0RhdGVPYmplY3Qob2JqZWN0MSkgJiYgaXNEYXRlT2JqZWN0KG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QuaXMob2JqZWN0MS5nZXRUaW1lKCksIG9iamVjdDIuZ2V0VGltZSgpKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkob2JqZWN0MSkgJiZcbiAgICAgICAgQXJyYXkuaXNBcnJheShvYmplY3QyKSAmJlxuICAgICAgICBvYmplY3QxLmxlbmd0aCAhPT0gb2JqZWN0Mi5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBrZXlzMSA9IE9iamVjdC5rZXlzKG9iamVjdDEpO1xuICAgIGNvbnN0IGtleXMyID0gT2JqZWN0LmtleXMob2JqZWN0Mik7XG4gICAgaWYgKGtleXMxLmxlbmd0aCAhPT0ga2V5czIubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGlzRW1wdHlPYmplY3RXaXRoQ3VzdG9tUHJvdG90eXBlKG9iamVjdDEsIGtleXMxKSB8fFxuICAgICAgICBpc0VtcHR5T2JqZWN0V2l0aEN1c3RvbVByb3RvdHlwZShvYmplY3QyLCBrZXlzMikpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5pcyhvYmplY3QxLCBvYmplY3QyKTtcbiAgICB9XG4gICAgaWYgKCFrZXlzMS5sZW5ndGggJiYgQXJyYXkuaXNBcnJheShvYmplY3QxKSAhPT0gQXJyYXkuaXNBcnJheShvYmplY3QyKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHZpc2l0ZWRQYWlycyA9IHZpc2l0ZWQuZ2V0KG9iamVjdDEpO1xuICAgIGlmICh2aXNpdGVkUGFpcnMgJiYgdmlzaXRlZFBhaXJzLmhhcyhvYmplY3QyKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHZpc2l0ZWRQYWlycykge1xuICAgICAgICB2aXNpdGVkUGFpcnMuYWRkKG9iamVjdDIpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3Qgd3MgPSBuZXcgV2Vha1NldCgpO1xuICAgICAgICB3cy5hZGQob2JqZWN0Mik7XG4gICAgICAgIHZpc2l0ZWQuc2V0KG9iamVjdDEsIHdzKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgb2Yga2V5czEpIHtcbiAgICAgICAgY29uc3QgdmFsMSA9IG9iamVjdDFba2V5XTtcbiAgICAgICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0Miwga2V5KSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghaXNFcnJvck9iamVjdCB8fCBrZXkgIT09ICdyZWYnKSB7XG4gICAgICAgICAgICBjb25zdCB2YWwyID0gb2JqZWN0MltrZXldO1xuICAgICAgICAgICAgaWYgKChpc0RhdGVPYmplY3QodmFsMSkgJiYgaXNEYXRlT2JqZWN0KHZhbDIpKSB8fFxuICAgICAgICAgICAgICAgICgoaXNPYmplY3QodmFsMSkgfHwgQXJyYXkuaXNBcnJheSh2YWwxKSkgJiZcbiAgICAgICAgICAgICAgICAgICAgKGlzT2JqZWN0KHZhbDIpIHx8IEFycmF5LmlzQXJyYXkodmFsMikpKVxuICAgICAgICAgICAgICAgID8gIWRlZXBFcXVhbCh2YWwxLCB2YWwyLCBpc0Vycm9yT2JqZWN0LCB2aXNpdGVkKVxuICAgICAgICAgICAgICAgIDogIU9iamVjdC5pcyh2YWwxLCB2YWwyKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn1cblxuZnVuY3Rpb24gdXNlUmVzeW5jT25SZWNvbm5lY3QoZ2V0SW5pdGlhbFZhbHVlKSB7XG4gICAgY29uc3QgX2Nvbm5lY3RlZCA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgX2luaXRpYWxpemVkID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBfcHJldlZhbHVlID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gICAgY29uc3QgX3JlbmRlckNvdW50ID0gUmVhY3QudXNlUmVmKDApO1xuICAgIF9yZW5kZXJDb3VudC5jdXJyZW50Kys7XG4gICAgaWYgKCFfaW5pdGlhbGl6ZWQuY3VycmVudCAmJiBnZXRJbml0aWFsVmFsdWUpIHtcbiAgICAgICAgX2luaXRpYWxpemVkLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBfcHJldlZhbHVlLmN1cnJlbnQgPSBjbG9uZU9iamVjdChnZXRJbml0aWFsVmFsdWUoKSk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3luY0lmTmVlZGVkID0gUmVhY3QudXNlQ2FsbGJhY2soKGVuYWJsZWQsIGdldEN1cnJlbnRWYWx1ZSwgc2V0VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGVuYWJsZWQgJiZcbiAgICAgICAgICAgIChfY29ubmVjdGVkLmN1cnJlbnQgfHxcbiAgICAgICAgICAgICAgICAoX2luaXRpYWxpemVkLmN1cnJlbnQgJiYgX3JlbmRlckNvdW50LmN1cnJlbnQgPiAxKSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRWYWx1ZSA9IGdldEN1cnJlbnRWYWx1ZSgpO1xuICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoX3ByZXZWYWx1ZS5jdXJyZW50LCBjdXJyZW50VmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgc2V0VmFsdWUoY3VycmVudFZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBfY29ubmVjdGVkLmN1cnJlbnQgPSB0cnVlO1xuICAgIH0sIFtdKTtcbiAgICBjb25zdCBzbmFwc2hvdCA9IFJlYWN0LnVzZUNhbGxiYWNrKChlbmFibGVkLCBnZXRDdXJyZW50VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGVuYWJsZWQpIHtcbiAgICAgICAgICAgIF9wcmV2VmFsdWUuY3VycmVudCA9IGNsb25lT2JqZWN0KGdldEN1cnJlbnRWYWx1ZSgpKTtcbiAgICAgICAgfVxuICAgIH0sIFtdKTtcbiAgICByZXR1cm4geyByZXN5bmNJZk5lZWRlZCwgc25hcHNob3QgfTtcbn1cblxuLyoqXG4gKiBTdWJzY3JpYmVzIHRvIGZvcm0gc3RhdGUgd2l0aCByZS1yZW5kZXJzIGlzb2xhdGVkIHRvIHRoaXMgaG9vay5cbiAqIE9wdGlvbmFsbHkgc2NvcGUgdG8gc3BlY2lmaWMgZmllbGQgbmFtZXMgdG8gbWluaW1pemUgcmUtcmVuZGVyIHN1cmZhY2UuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3Jtc3RhdGUpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgeyBlcnJvcnMsIGlzRGlydHkgfSA9IHVzZUZvcm1TdGF0ZSh7IGNvbnRyb2wsIG5hbWU6IFwiZW1haWxcIiB9KTtcbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VGb3JtU3RhdGUocHJvcHMpIHtcbiAgICBjb25zdCBmb3JtQ29udHJvbCA9IHVzZUZvcm1Db250cm9sQ29udGV4dCgpO1xuICAgIGNvbnN0IHsgY29udHJvbCA9IGZvcm1Db250cm9sLCBkaXNhYmxlZCwgbmFtZSwgZXhhY3QgfSA9IHByb3BzIHx8IHt9O1xuICAgIGNvbnN0IGdldEN1cnJlbnRGb3JtU3RhdGUgPSAoKSA9PiAoe1xuICAgICAgICAuLi5jb250cm9sLl9mb3JtU3RhdGUsXG4gICAgICAgIGRlZmF1bHRWYWx1ZXM6IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsXG4gICAgfSk7XG4gICAgY29uc3QgW2Zvcm1TdGF0ZSwgdXBkYXRlRm9ybVN0YXRlXSA9IFJlYWN0LnVzZVN0YXRlKGdldEN1cnJlbnRGb3JtU3RhdGUpO1xuICAgIGNvbnN0IF9sb2NhbFByb3h5Rm9ybVN0YXRlID0gUmVhY3QudXNlUmVmKHtcbiAgICAgICAgaXNEaXJ0eTogZmFsc2UsXG4gICAgICAgIGlzTG9hZGluZzogZmFsc2UsXG4gICAgICAgIGRpcnR5RmllbGRzOiBmYWxzZSxcbiAgICAgICAgdG91Y2hlZEZpZWxkczogZmFsc2UsXG4gICAgICAgIHZhbGlkYXRpbmdGaWVsZHM6IGZhbHNlLFxuICAgICAgICBpc1ZhbGlkYXRpbmc6IGZhbHNlLFxuICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgZXJyb3JzOiBmYWxzZSxcbiAgICB9KTtcbiAgICBjb25zdCB7IHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdCB9ID0gdXNlUmVzeW5jT25SZWNvbm5lY3QoZ2V0Q3VycmVudEZvcm1TdGF0ZSk7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHJlc3luY0lmTmVlZGVkKCFkaXNhYmxlZCwgZ2V0Q3VycmVudEZvcm1TdGF0ZSwgdXBkYXRlRm9ybVN0YXRlKTtcbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGZvcm1TdGF0ZTogX2xvY2FsUHJveHlGb3JtU3RhdGUuY3VycmVudCxcbiAgICAgICAgICAgIGV4YWN0LFxuICAgICAgICAgICAgY2FsbGJhY2s6IChmb3JtU3RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICAhZGlzYWJsZWQgJiZcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybVN0YXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgc25hcHNob3QoIWRpc2FibGVkLCBnZXRDdXJyZW50Rm9ybVN0YXRlKTtcbiAgICAgICAgfTtcbiAgICB9LCBbY29udHJvbCwgbmFtZSwgZGlzYWJsZWQsIGV4YWN0LCByZXN5bmNJZk5lZWRlZCwgc25hcHNob3RdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBfbG9jYWxQcm94eUZvcm1TdGF0ZS5jdXJyZW50LmlzVmFsaWQgJiYgY29udHJvbC5fc2V0VmFsaWQodHJ1ZSk7XG4gICAgfSwgW2NvbnRyb2xdKTtcbiAgICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBnZXRQcm94eUZvcm1TdGF0ZShmb3JtU3RhdGUsIGNvbnRyb2wsIF9sb2NhbFByb3h5Rm9ybVN0YXRlLmN1cnJlbnQsIGZhbHNlKSwgW2Zvcm1TdGF0ZSwgY29udHJvbF0pO1xufVxuXG52YXIgaXNTdHJpbmcgPSAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZyc7XG5cbnZhciBnZW5lcmF0ZVdhdGNoT3V0cHV0ID0gKG5hbWVzLCBfbmFtZXMsIGZvcm1WYWx1ZXMsIGlzR2xvYmFsLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgICBpZiAoaXNTdHJpbmcobmFtZXMpKSB7XG4gICAgICAgIGlzR2xvYmFsICYmIF9uYW1lcy53YXRjaC5hZGQobmFtZXMpO1xuICAgICAgICByZXR1cm4gZ2V0KGZvcm1WYWx1ZXMsIG5hbWVzLCBkZWZhdWx0VmFsdWUpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShuYW1lcykpIHtcbiAgICAgICAgcmV0dXJuIG5hbWVzLm1hcCgoZmllbGROYW1lKSA9PiAoaXNHbG9iYWwgJiYgX25hbWVzLndhdGNoLmFkZChmaWVsZE5hbWUpLFxuICAgICAgICAgICAgZ2V0KGZvcm1WYWx1ZXMsIGZpZWxkTmFtZSwgZ2V0KGRlZmF1bHRWYWx1ZSwgZmllbGROYW1lKSkpKTtcbiAgICB9XG4gICAgaXNHbG9iYWwgJiYgKF9uYW1lcy53YXRjaEFsbCA9IHRydWUpO1xuICAgIHJldHVybiBmb3JtVmFsdWVzO1xufTtcblxuLyoqXG4gKiBTdWJzY3JpYmVzIHRvIGZpZWxkIHZhbHVlIGNoYW5nZXMgYW5kIGlzb2xhdGVzIHJlLXJlbmRlcnMgdG8gdGhlIGhvb2sgbGV2ZWwuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2V3YXRjaClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCBlbWFpbCA9IHVzZVdhdGNoKHsgY29udHJvbCwgbmFtZTogXCJlbWFpbFwiIH0pO1xuICogY29uc3QgYWxsICAgPSB1c2VXYXRjaCh7IGNvbnRyb2wgfSk7XG4gKiBjb25zdCBhZHVsdCA9IHVzZVdhdGNoKHsgY29udHJvbCwgbmFtZTogXCJhZ2VcIiwgY29tcHV0ZTogKHYpID0+IHYgPj0gMTggfSk7XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlV2F0Y2gocHJvcHMpIHtcbiAgICBjb25zdCBmb3JtQ29udHJvbCA9IHVzZUZvcm1Db250cm9sQ29udGV4dCgpO1xuICAgIGNvbnN0IHsgY29udHJvbCA9IGZvcm1Db250cm9sLCBuYW1lLCBkZWZhdWx0VmFsdWUsIGRpc2FibGVkLCBleGFjdCwgY29tcHV0ZSwgfSA9IHByb3BzIHx8IHt9O1xuICAgIGNvbnN0IF9kZWZhdWx0VmFsdWUgPSBSZWFjdC51c2VSZWYoZGVmYXVsdFZhbHVlKTtcbiAgICBjb25zdCBfY29tcHV0ZSA9IFJlYWN0LnVzZVJlZihjb21wdXRlKTtcbiAgICBjb25zdCBfcHJldkNvbnRyb2wgPSBSZWFjdC51c2VSZWYoY29udHJvbCk7XG4gICAgY29uc3QgX3ByZXZOYW1lID0gUmVhY3QudXNlUmVmKG5hbWUpO1xuICAgIF9jb21wdXRlLmN1cnJlbnQgPSBjb21wdXRlO1xuICAgIGNvbnN0IGdldEluaXRpYWxPdXRwdXQgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRWYWx1ZSA9IGNvbnRyb2wuX2dldFdhdGNoKG5hbWUsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgIHJldHVybiBfY29tcHV0ZS5jdXJyZW50ID8gX2NvbXB1dGUuY3VycmVudChkZWZhdWx0VmFsdWUpIDogZGVmYXVsdFZhbHVlO1xuICAgIH07XG4gICAgY29uc3QgW3ZhbHVlLCB1cGRhdGVWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZShnZXRJbml0aWFsT3V0cHV0KTtcbiAgICBjb25zdCBfY29tcHV0ZUZvcm1WYWx1ZXMgPSBSZWFjdC51c2VSZWYodmFsdWUpO1xuICAgIGNvbnN0IGdldEN1cnJlbnRPdXRwdXQgPSBSZWFjdC51c2VDYWxsYmFjaygodmFsdWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWUsIGNvbnRyb2wuX25hbWVzLCB2YWx1ZXMgfHwgY29udHJvbC5fZm9ybVZhbHVlcywgZmFsc2UsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgIHJldHVybiBfY29tcHV0ZS5jdXJyZW50XG4gICAgICAgICAgICA/IF9jb21wdXRlLmN1cnJlbnQoZm9ybVZhbHVlcylcbiAgICAgICAgICAgIDogZm9ybVZhbHVlcztcbiAgICB9LCBbY29udHJvbC5fZm9ybVZhbHVlcywgY29udHJvbC5fbmFtZXMsIG5hbWVdKTtcbiAgICBjb25zdCByZWZyZXNoVmFsdWUgPSBSZWFjdC51c2VDYWxsYmFjaygodmFsdWVzKSA9PiB7XG4gICAgICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWUsIGNvbnRyb2wuX25hbWVzLCB2YWx1ZXMgfHwgY29udHJvbC5fZm9ybVZhbHVlcywgZmFsc2UsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgICAgICBpZiAoX2NvbXB1dGUuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbXB1dGVkRm9ybVZhbHVlcyA9IF9jb21wdXRlLmN1cnJlbnQoZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoY29tcHV0ZWRGb3JtVmFsdWVzLCBfY29tcHV0ZUZvcm1WYWx1ZXMuY3VycmVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlVmFsdWUoY29tcHV0ZWRGb3JtVmFsdWVzKTtcbiAgICAgICAgICAgICAgICAgICAgX2NvbXB1dGVGb3JtVmFsdWVzLmN1cnJlbnQgPSBjb21wdXRlZEZvcm1WYWx1ZXM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlVmFsdWUoZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbC5fZm9ybVZhbHVlcywgY29udHJvbC5fbmFtZXMsIGRpc2FibGVkLCBuYW1lXSk7XG4gICAgY29uc3QgeyByZXN5bmNJZk5lZWRlZCwgc25hcHNob3QgfSA9IHVzZVJlc3luY09uUmVjb25uZWN0KGdldEluaXRpYWxPdXRwdXQpO1xuICAgIGNvbnN0IF9yZWZyZXNoVmFsdWUgPSBSZWFjdC51c2VSZWYocmVmcmVzaFZhbHVlKTtcbiAgICBfcmVmcmVzaFZhbHVlLmN1cnJlbnQgPSByZWZyZXNoVmFsdWU7XG4gICAgY29uc3QgX2dldEN1cnJlbnRPdXRwdXQgPSBSZWFjdC51c2VSZWYoZ2V0Q3VycmVudE91dHB1dCk7XG4gICAgX2dldEN1cnJlbnRPdXRwdXQuY3VycmVudCA9IGdldEN1cnJlbnRPdXRwdXQ7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChfcHJldkNvbnRyb2wuY3VycmVudCAhPT0gY29udHJvbCB8fFxuICAgICAgICAgICAgIWRlZXBFcXVhbChfcHJldk5hbWUuY3VycmVudCwgbmFtZSkpIHtcbiAgICAgICAgICAgIF9wcmV2Q29udHJvbC5jdXJyZW50ID0gY29udHJvbDtcbiAgICAgICAgICAgIF9wcmV2TmFtZS5jdXJyZW50ID0gbmFtZTtcbiAgICAgICAgICAgIF9yZWZyZXNoVmFsdWUuY3VycmVudCgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmVzeW5jSWZOZWVkZWQoIWRpc2FibGVkLCAoKSA9PiBfZ2V0Q3VycmVudE91dHB1dC5jdXJyZW50KCksIChjdXJyZW50VmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0VmFsdWUgPSBjbG9uZU9iamVjdChjdXJyZW50VmFsdWUpO1xuICAgICAgICAgICAgICAgIHVwZGF0ZVZhbHVlKG5leHRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgX2NvbXB1dGVGb3JtVmFsdWVzLmN1cnJlbnQgPSBuZXh0VmFsdWU7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1bnN1YnNjcmliZSA9IGNvbnRyb2wuX3N1YnNjcmliZSh7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgZm9ybVN0YXRlOiB7XG4gICAgICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGV4YWN0LFxuICAgICAgICAgICAgY2FsbGJhY2s6IChmb3JtU3RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICBfcmVmcmVzaFZhbHVlLmN1cnJlbnQoZm9ybVN0YXRlLnZhbHVlcyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICBzbmFwc2hvdCghZGlzYWJsZWQsICgpID0+IF9nZXRDdXJyZW50T3V0cHV0LmN1cnJlbnQoKSk7XG4gICAgICAgIH07XG4gICAgfSwgW2NvbnRyb2wsIGV4YWN0LCBuYW1lLCBkaXNhYmxlZCwgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90XSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IGNvbnRyb2wuX3JlbW92ZVVubW91bnRlZCgpKTtcbiAgICAvLyBJZiBuYW1lIG9yIGNvbnRyb2wgY2hhbmdlZCBmb3IgdGhpcyByZW5kZXIsIHN5bmNocm9ub3VzbHkgcmVmbGVjdCB0aGVcbiAgICAvLyBsYXRlc3QgdmFsdWUgc28gY2FsbGVycyAobGlrZSB1c2VDb250cm9sbGVyKSBzZWUgdGhlIGNvcnJlY3QgdmFsdWVcbiAgICAvLyBpbW1lZGlhdGVseSBvbiB0aGUgc2FtZSByZW5kZXIuXG4gICAgLy8gT3B0aW1pemU6IENoZWNrIGNvbnRyb2wgcmVmZXJlbmNlIGZpcnN0IGJlZm9yZSBleHBlbnNpdmUgZGVlcEVxdWFsXG4gICAgY29uc3QgY29udHJvbENoYW5nZWQgPSBfcHJldkNvbnRyb2wuY3VycmVudCAhPT0gY29udHJvbDtcbiAgICBjb25zdCBwcmV2TmFtZSA9IF9wcmV2TmFtZS5jdXJyZW50O1xuICAgIGNvbnN0IG5hbWVDaGFuZ2VkID0gUmVhY3QudXNlTWVtbygoKSA9PiAhY29udHJvbENoYW5nZWQgJiYgIWRlZXBFcXVhbChwcmV2TmFtZSwgbmFtZSksIFtjb250cm9sQ2hhbmdlZCwgbmFtZSwgcHJldk5hbWVdKTtcbiAgICBpZiAoY29udHJvbENoYW5nZWQgfHwgbmFtZUNoYW5nZWQpIHtcbiAgICAgICAgX2RlZmF1bHRWYWx1ZS5jdXJyZW50ID0gZGVmYXVsdFZhbHVlO1xuICAgIH1cbiAgICBjb25zdCBzaG91bGRSZXR1cm5JbW1lZGlhdGUgPSAhZGlzYWJsZWQgJiYgKGNvbnRyb2xDaGFuZ2VkIHx8IG5hbWVDaGFuZ2VkKTtcbiAgICByZXR1cm4gc2hvdWxkUmV0dXJuSW1tZWRpYXRlID8gZ2V0Q3VycmVudE91dHB1dCgpIDogdmFsdWU7XG59XG5cbi8qKlxuICogSG9vayBmb3IgY29udHJvbGxlZCBpbnB1dHMuIFJldHVybnMgYGZpZWxkYCwgYGZpZWxkU3RhdGVgLCBhbmQgYGZvcm1TdGF0ZWAuXG4gKiBSZS1yZW5kZXJzIGFyZSBpc29sYXRlZCB0byB0aGUgaG9vayBsZXZlbC5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWNvbnRyb2xsZXIpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgeyBmaWVsZCwgZmllbGRTdGF0ZSB9ID0gdXNlQ29udHJvbGxlcih7IGNvbnRyb2wsIG5hbWU6IFwiZW1haWxcIiB9KTtcbiAqIHJldHVybiA8aW5wdXQgey4uLmZpZWxkfSAvPjtcbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VDb250cm9sbGVyKHByb3BzKSB7XG4gICAgY29uc3QgZm9ybUNvbnRyb2wgPSB1c2VGb3JtQ29udHJvbENvbnRleHQoKTtcbiAgICBjb25zdCB7IG5hbWUsIGRpc2FibGVkLCBjb250cm9sID0gZm9ybUNvbnRyb2wsIHNob3VsZFVucmVnaXN0ZXIsIGRlZmF1bHRWYWx1ZSwgZXhhY3QgPSB0cnVlLCB9ID0gcHJvcHM7XG4gICAgY29uc3QgaXNBcnJheUZpZWxkID0gaXNOYW1lSW5GaWVsZEFycmF5KGNvbnRyb2wuX25hbWVzLmFycmF5LCBuYW1lKTtcbiAgICBjb25zdCBkZWZhdWx0VmFsdWVNZW1vID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc29sdmVkID0gZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUsIGdldChjb250cm9sLl9kZWZhdWx0VmFsdWVzLCBuYW1lLCBkZWZhdWx0VmFsdWUpKTtcbiAgICAgICAgcmV0dXJuIChpc1VuZGVmaW5lZChyZXNvbHZlZCkgPyBnZXROdWxsQW5jZXN0b3JWYWx1ZShjb250cm9sLCBuYW1lKSA6IHJlc29sdmVkKTtcbiAgICB9LCBbY29udHJvbCwgbmFtZSwgZGVmYXVsdFZhbHVlXSk7XG4gICAgY29uc3QgdmFsdWUgPSB1c2VXYXRjaCh7XG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogZGVmYXVsdFZhbHVlTWVtbyxcbiAgICAgICAgZXhhY3QsXG4gICAgfSk7XG4gICAgY29uc3QgZm9ybVN0YXRlID0gdXNlRm9ybVN0YXRlKHtcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgZXhhY3QsXG4gICAgfSk7XG4gICAgY29uc3QgX3Byb3BzID0gUmVhY3QudXNlUmVmKHByb3BzKTtcbiAgICBjb25zdCBfcHJveHlSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgX3JlZ2lzdGVyUHJvcHMgPSBSZWFjdC51c2VSZWYoY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgIC4uLnByb3BzLnJ1bGVzLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgLi4uKGlzQm9vbGVhbihwcm9wcy5kaXNhYmxlZCkgPyB7IGRpc2FibGVkOiBwcm9wcy5kaXNhYmxlZCB9IDoge30pLFxuICAgIH0pKTtcbiAgICBfcHJvcHMuY3VycmVudCA9IHByb3BzO1xuICAgIGNvbnN0IGZpZWxkU3RhdGUgPSBSZWFjdC51c2VNZW1vKCgpID0+IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHt9LCB7XG4gICAgICAgIGludmFsaWQ6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBpc0RpcnR5OiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBpc1RvdWNoZWQ6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKSxcbiAgICAgICAgfSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiBnZXQoZm9ybVN0YXRlLmVycm9ycywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgfSksIFtmb3JtU3RhdGUsIG5hbWVdKTtcbiAgICBjb25zdCBvbkNoYW5nZSA9IFJlYWN0LnVzZUNhbGxiYWNrKChldmVudCkgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGdldEV2ZW50VmFsdWUoZXZlbnQpO1xuICAgICAgICBpZiAoIWdldChjb250cm9sLl9maWVsZHMsIG5hbWUpKSB7XG4gICAgICAgICAgICBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50ID0gY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgICAgICAgICAgLi4uX3Byb3BzLmN1cnJlbnQucnVsZXMsXG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX3JlZ2lzdGVyUHJvcHMuY3VycmVudC5vbkNoYW5nZSh7XG4gICAgICAgICAgICB0YXJnZXQ6IHtcbiAgICAgICAgICAgICAgICB2YWx1ZTogZ2V0RXZlbnRWYWx1ZShldmVudCksXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0eXBlOiBFVkVOVFMuQ0hBTkdFLFxuICAgICAgICB9KTtcbiAgICB9LCBbbmFtZSwgY29udHJvbF0pO1xuICAgIGNvbnN0IG9uQmx1ciA9IFJlYWN0LnVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSk7XG4gICAgICAgIGlmICghZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSkpIHtcbiAgICAgICAgICAgIF9yZWdpc3RlclByb3BzLmN1cnJlbnQgPSBjb250cm9sLnJlZ2lzdGVyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICAuLi5fcHJvcHMuY3VycmVudC5ydWxlcyxcbiAgICAgICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50Lm9uQmx1cih7XG4gICAgICAgICAgICB0YXJnZXQ6IHtcbiAgICAgICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHR5cGU6IEVWRU5UUy5CTFVSLFxuICAgICAgICB9KTtcbiAgICB9LCBbbmFtZSwgY29udHJvbF0pO1xuICAgIGNvbnN0IHJlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKChlbG0pID0+IHtcbiAgICAgICAgaWYgKGVsbSkge1xuICAgICAgICAgICAgX3Byb3h5UmVmLmN1cnJlbnQgPSB7XG4gICAgICAgICAgICAgICAgZm9jdXM6ICgpID0+IGlzRnVuY3Rpb24oZWxtLmZvY3VzKSAmJiBlbG0uZm9jdXMoKSxcbiAgICAgICAgICAgICAgICBzZWxlY3Q6ICgpID0+IGlzRnVuY3Rpb24oZWxtLnNlbGVjdCkgJiYgZWxtLnNlbGVjdCgpLFxuICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5OiAobWVzc2FnZSkgPT4gaXNGdW5jdGlvbihlbG0uc2V0Q3VzdG9tVmFsaWRpdHkpICYmIGVsbS5zZXRDdXN0b21WYWxpZGl0eShtZXNzYWdlKSxcbiAgICAgICAgICAgICAgICByZXBvcnRWYWxpZGl0eTogKCkgPT4gaXNGdW5jdGlvbihlbG0ucmVwb3J0VmFsaWRpdHkpICYmIGVsbS5yZXBvcnRWYWxpZGl0eSgpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YgJiYgZWxtKSB7XG4gICAgICAgICAgICBmaWVsZC5fZi5yZWYgPSBfcHJveHlSZWYuY3VycmVudDtcbiAgICAgICAgICAgIGZpZWxkLl9mLl9jID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLl9maWVsZHMsIG5hbWVdKTtcbiAgICBjb25zdCBmaWVsZCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIC4uLihpc0Jvb2xlYW4oZGlzYWJsZWQpIHx8IGZvcm1TdGF0ZS5kaXNhYmxlZFxuICAgICAgICAgICAgPyB7IGRpc2FibGVkOiBmb3JtU3RhdGUuZGlzYWJsZWQgfHwgZGlzYWJsZWQgfVxuICAgICAgICAgICAgOiB7fSksXG4gICAgICAgIG9uQ2hhbmdlLFxuICAgICAgICBvbkJsdXIsXG4gICAgICAgIHJlZixcbiAgICB9KSwgW25hbWUsIGRpc2FibGVkLCBmb3JtU3RhdGUuZGlzYWJsZWQsIG9uQ2hhbmdlLCBvbkJsdXIsIHJlZiwgdmFsdWVdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBfc2hvdWxkVW5yZWdpc3RlckZpZWxkID0gY29udHJvbC5fb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyIHx8IHNob3VsZFVucmVnaXN0ZXI7XG4gICAgICAgIF9yZWdpc3RlclByb3BzLmN1cnJlbnQgPSBjb250cm9sLnJlZ2lzdGVyKG5hbWUsIHtcbiAgICAgICAgICAgIC4uLl9wcm9wcy5jdXJyZW50LnJ1bGVzLFxuICAgICAgICAgICAgLi4uKGlzQm9vbGVhbihfcHJvcHMuY3VycmVudC5kaXNhYmxlZClcbiAgICAgICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IF9wcm9wcy5jdXJyZW50LmRpc2FibGVkIH1cbiAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZU1vdW50ZWQgPSAobmFtZSwgdmFsdWUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICBmaWVsZC5fZi5tb3VudCA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIGZpZWxkLl9mLl9jID0gdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHVwZGF0ZU1vdW50ZWQobmFtZSwgdHJ1ZSk7XG4gICAgICAgIGlmIChfc2hvdWxkVW5yZWdpc3RlckZpZWxkKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGNsb25lT2JqZWN0KGdldChzaG91bGRVbnJlZ2lzdGVyXG4gICAgICAgICAgICAgICAgPyBjb250cm9sLl9kZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgOiBjb250cm9sLl9vcHRpb25zLnZhbHVlcyB8fCBjb250cm9sLl9kZWZhdWx0VmFsdWVzLCBuYW1lLCBnZXQoY29udHJvbC5fb3B0aW9ucy5kZWZhdWx0VmFsdWVzLCBuYW1lLCBfcHJvcHMuY3VycmVudC5kZWZhdWx0VmFsdWUpKSk7XG4gICAgICAgICAgICBzZXQoY29udHJvbC5fZGVmYXVsdFZhbHVlcywgbmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgaWYgKGlzVW5kZWZpbmVkKGdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lKSkpIHtcbiAgICAgICAgICAgICAgICBzZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgICFpc0FycmF5RmllbGQgJiZcbiAgICAgICAgICAgIGNvbnRyb2wucmVnaXN0ZXIobmFtZSwge1xuICAgICAgICAgICAgICAgIC4uLl9wcm9wcy5jdXJyZW50LnJ1bGVzLFxuICAgICAgICAgICAgICAgIC4uLihpc0Jvb2xlYW4oX3Byb3BzLmN1cnJlbnQuZGlzYWJsZWQpXG4gICAgICAgICAgICAgICAgICAgID8geyBkaXNhYmxlZDogX3Byb3BzLmN1cnJlbnQuZGlzYWJsZWQgfVxuICAgICAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICBpZiAoX3Byb3h5UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICBmaWVsZC5fZi5yZWYgPSBfcHJveHlSZWYuY3VycmVudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgKGlzQXJyYXlGaWVsZFxuICAgICAgICAgICAgICAgID8gX3Nob3VsZFVucmVnaXN0ZXJGaWVsZCAmJiAhY29udHJvbC5fc3RhdGUuYWN0aW9uXG4gICAgICAgICAgICAgICAgOiBfc2hvdWxkVW5yZWdpc3RlckZpZWxkKVxuICAgICAgICAgICAgICAgID8gY29udHJvbC51bnJlZ2lzdGVyKG5hbWUpXG4gICAgICAgICAgICAgICAgOiB1cGRhdGVNb3VudGVkKG5hbWUsIGZhbHNlKTtcbiAgICAgICAgfTtcbiAgICB9LCBbbmFtZSwgY29udHJvbCwgaXNBcnJheUZpZWxkLCBzaG91bGRVbnJlZ2lzdGVyXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29udHJvbC5fc2V0RGlzYWJsZWRGaWVsZCh7XG4gICAgICAgICAgICBkaXNhYmxlZCxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgIH0pO1xuICAgIH0sIFtkaXNhYmxlZCwgbmFtZSwgY29udHJvbF0pO1xuICAgIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgICAgIGZpZWxkLFxuICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgIGZpZWxkU3RhdGUsXG4gICAgfSksIFtmaWVsZCwgZm9ybVN0YXRlLCBmaWVsZFN0YXRlXSk7XG59XG5cbi8qKlxuICogQ29tcG9uZW50IHdyYXBwZXIgYXJvdW5kIGB1c2VDb250cm9sbGVyYCBmb3IgY29udHJvbGxlZCBpbnB1dHMuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vjb250cm9sbGVyL2NvbnRyb2xsZXIpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogPENvbnRyb2xsZXJcbiAqICAgY29udHJvbD17Y29udHJvbH1cbiAqICAgbmFtZT1cInRlc3RcIlxuICogICByZW5kZXI9eyh7IGZpZWxkLCBmaWVsZFN0YXRlLCBmb3JtU3RhdGUgfSkgPT4gPGlucHV0IHsuLi5maWVsZH0gLz59XG4gKiAvPlxuICogYGBgXG4gKi9cbmNvbnN0IENvbnRyb2xsZXIgPSAocHJvcHMpID0+IHByb3BzLnJlbmRlcih1c2VDb250cm9sbGVyKHByb3BzKSk7XG5cbi8qKlxuICogRGlzcGxheXMgdGhlIHZhbGlkYXRpb24gZXJyb3IgZm9yIGEgc2luZ2xlIGZpZWxkLlxuICogUmVhZHMgZnJvbSBgY29udHJvbGAgd2hlbiBwcm92aWRlZCwgb3RoZXJ3aXNlIGZyb20gdGhlIG5lYXJlc3QgYEZvcm1Qcm92aWRlcmAuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3Jtc3RhdGUvZXJyb3JtZXNzYWdlKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIDxFcnJvck1lc3NhZ2UgY29udHJvbD17Y29udHJvbH0gbmFtZT1cImVtYWlsXCIgYXM9XCJwXCIgLz5cbiAqIDxFcnJvck1lc3NhZ2UgbmFtZT1cImVtYWlsXCIgYXM9XCJzcGFuXCIgLz5cbiAqIDxFcnJvck1lc3NhZ2UgY29udHJvbD17Y29udHJvbH0gbmFtZT1cImVtYWlsXCJcbiAqICAgcmVuZGVyPXsoeyBtZXNzYWdlIH0pID0+IDxBbGVydD57bWVzc2FnZX08L0FsZXJ0Pn0gLz5cbiAqIGBgYFxuICovXG5jb25zdCBFcnJvck1lc3NhZ2UgPSAoeyBhcywgY29udHJvbCwgbmFtZSwgcmVuZGVyLCB9KSA9PiB7XG4gICAgY29uc3QgeyBlcnJvcnMgfSA9IHVzZUZvcm1TdGF0ZSh7XG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIG5hbWU6IG5hbWUsXG4gICAgfSk7XG4gICAgY29uc3QgZXJyb3IgPSBnZXQoZXJyb3JzLCBuYW1lKTtcbiAgICBpZiAoIWVycm9yKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZSB8fCAnJztcbiAgICBpZiAocmVuZGVyKSB7XG4gICAgICAgIHJldHVybiByZW5kZXIoeyBtZXNzYWdlLCBtZXNzYWdlczogZXJyb3IudHlwZXMgfSk7XG4gICAgfVxuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KGFzIHx8IFJlYWN0LkZyYWdtZW50LCBudWxsLCBtZXNzYWdlKTtcbn07XG5cbnZhciBnZW5lcmF0ZUlkID0gKCkgPT4gdHlwZW9mIGNyeXB0byAhPT0gJ3VuZGVmaW5lZCcgJiYgY3J5cHRvLnJhbmRvbVVVSURcbiAgICA/IGNyeXB0by5yYW5kb21VVUlEKClcbiAgICA6ICd4eHh4eHh4eC14eHh4LTR4eHgteXh4eC14eHh4eHh4eHh4eHgnLnJlcGxhY2UoL1t4eV0vZywgKGMpID0+IHtcbiAgICAgICAgY29uc3QgciA9IChNYXRoLnJhbmRvbSgpICogMTYpIHwgMDtcbiAgICAgICAgcmV0dXJuIChjID09PSAneCcgPyByIDogKHIgJiAweDMpIHwgMHg4KS50b1N0cmluZygxNik7XG4gICAgfSk7XG5cbnZhciBnZXRGb2N1c0ZpZWxkTmFtZSA9IChuYW1lLCBpbmRleCwgb3B0aW9ucyA9IHt9KSA9PiBvcHRpb25zLnNob3VsZEZvY3VzIHx8IGlzVW5kZWZpbmVkKG9wdGlvbnMuc2hvdWxkRm9jdXMpXG4gICAgPyBvcHRpb25zLmZvY3VzTmFtZSB8fFxuICAgICAgICBgJHtuYW1lfS4ke2lzVW5kZWZpbmVkKG9wdGlvbnMuZm9jdXNJbmRleCkgPyBpbmRleCA6IG9wdGlvbnMuZm9jdXNJbmRleH0uYFxuICAgIDogJyc7XG5cbnZhciBnZXRWYWxpZGF0aW9uTW9kZXMgPSAobW9kZSkgPT4gKHtcbiAgICBpc09uU3VibWl0OiAhbW9kZSB8fCBtb2RlID09PSBWQUxJREFUSU9OX01PREUub25TdWJtaXQsXG4gICAgaXNPbkJsdXI6IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5vbkJsdXIsXG4gICAgaXNPbkNoYW5nZTogbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLm9uQ2hhbmdlLFxuICAgIGlzT25BbGw6IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5hbGwsXG4gICAgaXNPblRvdWNoOiBtb2RlID09PSBWQUxJREFUSU9OX01PREUub25Ub3VjaGVkLFxufSk7XG5cbnZhciBpc1dhdGNoZWQgPSAobmFtZSwgX25hbWVzLCBpc0JsdXJFdmVudCkgPT4ge1xuICAgIGlmIChpc0JsdXJFdmVudClcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChfbmFtZXMud2F0Y2hBbGwgfHwgX25hbWVzLndhdGNoLmhhcyhuYW1lKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgZm9yIChjb25zdCB3YXRjaE5hbWUgb2YgX25hbWVzLndhdGNoKSB7XG4gICAgICAgIGlmIChuYW1lLnN0YXJ0c1dpdGgod2F0Y2hOYW1lKSAmJiBuYW1lLmNoYXJBdCh3YXRjaE5hbWUubGVuZ3RoKSA9PT0gJy4nKVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbmNvbnN0IGl0ZXJhdGVGaWVsZHNCeUFjdGlvbiA9IChmaWVsZHMsIGFjdGlvbiwgZmllbGRzTmFtZXMpID0+IHtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBmaWVsZHNOYW1lcyB8fCBPYmplY3Qua2V5cyhmaWVsZHMpKSB7XG4gICAgICAgIGlmIChrZXkgPT09ICdfZicpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZpZWxkID0gKGZpZWxkc05hbWVzID8gZ2V0KGZpZWxkcywga2V5KSA6IGZpZWxkc1trZXldKTtcbiAgICAgICAgaWYgKGZpZWxkKSB7XG4gICAgICAgICAgICBjb25zdCB7IF9mIH0gPSBmaWVsZDtcbiAgICAgICAgICAgIGlmIChfZikge1xuICAgICAgICAgICAgICAgIGlmIChfZi5yZWZzICYmIF9mLnJlZnNbMF0gJiYgYWN0aW9uKF9mLnJlZnNbMF0sIF9mLm5hbWUpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChfZi5yZWYgJiYgYWN0aW9uKF9mLnJlZiwgX2YubmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKGZpZWxkLCBhY3Rpb24pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGlzT2JqZWN0KGZpZWxkKSB8fCBBcnJheS5pc0FycmF5KGZpZWxkKSkge1xuICAgICAgICAgICAgICAgIGlmIChpdGVyYXRlRmllbGRzQnlBY3Rpb24oZmllbGQsIGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybjtcbn07XG5cbnZhciB1cGRhdGVGaWVsZEFycmF5Um9vdEVycm9yID0gKGVycm9ycywgZXJyb3IsIG5hbWUpID0+IHtcbiAgICBjb25zdCBleGlzdGluZ0Vycm9ycyA9IGdldChlcnJvcnMsIG5hbWUpO1xuICAgIGNvbnN0IGZpZWxkQXJyYXlFcnJvcnMgPSBBcnJheS5pc0FycmF5KGV4aXN0aW5nRXJyb3JzKSA/IGV4aXN0aW5nRXJyb3JzIDogW107XG4gICAgc2V0KGZpZWxkQXJyYXlFcnJvcnMsIFJPT1RfRVJST1JfVFlQRSwgZXJyb3JbbmFtZV0pO1xuICAgIHNldChlcnJvcnMsIG5hbWUsIGZpZWxkQXJyYXlFcnJvcnMpO1xuICAgIHJldHVybiBlcnJvcnM7XG59O1xuXG52YXIgaXNFbXB0eU9iamVjdCA9ICh2YWx1ZSkgPT4gaXNPYmplY3QodmFsdWUpICYmICFPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoO1xuXG52YXIgaXNIVE1MRWxlbWVudCA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICghaXNXZWIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBvd25lciA9IHZhbHVlID8gdmFsdWUub3duZXJEb2N1bWVudCA6IDA7XG4gICAgcmV0dXJuICh2YWx1ZSBpbnN0YW5jZW9mXG4gICAgICAgIChvd25lciAmJiBvd25lci5kZWZhdWx0VmlldyA/IG93bmVyLmRlZmF1bHRWaWV3LkhUTUxFbGVtZW50IDogSFRNTEVsZW1lbnQpKTtcbn07XG5cbnZhciBpc1JhZGlvSW5wdXQgPSAoZWxlbWVudCkgPT4gZWxlbWVudC50eXBlID09PSAncmFkaW8nO1xuXG52YXIgaXNSZWdleCA9ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBSZWdFeHA7XG5cbnZhciBhcHBlbmRFcnJvcnMgPSAobmFtZSwgdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhLCBlcnJvcnMsIHR5cGUsIG1lc3NhZ2UpID0+IHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYVxuICAgID8ge1xuICAgICAgICAuLi5lcnJvcnNbbmFtZV0sXG4gICAgICAgIHR5cGVzOiB7XG4gICAgICAgICAgICAuLi4oZXJyb3JzW25hbWVdICYmIGVycm9yc1tuYW1lXS50eXBlcyA/IGVycm9yc1tuYW1lXS50eXBlcyA6IHt9KSxcbiAgICAgICAgICAgIFt0eXBlXTogbWVzc2FnZSB8fCB0cnVlLFxuICAgICAgICB9LFxuICAgIH1cbiAgICA6IHt9O1xuXG5jb25zdCBkZWZhdWx0UmVzdWx0ID0ge1xuICAgIHZhbHVlOiBmYWxzZSxcbiAgICBpc1ZhbGlkOiBmYWxzZSxcbn07XG5jb25zdCB2YWxpZFJlc3VsdCA9IHsgdmFsdWU6IHRydWUsIGlzVmFsaWQ6IHRydWUgfTtcbnZhciBnZXRDaGVja2JveFZhbHVlID0gKG9wdGlvbnMpID0+IHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkob3B0aW9ucykpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRSZXN1bHQ7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gb3B0aW9uc1xuICAgICAgICAgICAgLmZpbHRlcigob3B0aW9uKSA9PiBvcHRpb24gJiYgb3B0aW9uLmNoZWNrZWQgJiYgIW9wdGlvbi5kaXNhYmxlZClcbiAgICAgICAgICAgIC5tYXAoKG9wdGlvbikgPT4gb3B0aW9uLnZhbHVlKTtcbiAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHZhbHVlcywgaXNWYWxpZDogISF2YWx1ZXMubGVuZ3RoIH07XG4gICAgfVxuICAgIGNvbnN0IG9wdGlvbiA9IG9wdGlvbnNbMF07XG4gICAgaWYgKCFvcHRpb24gfHwgIW9wdGlvbi5jaGVja2VkIHx8IG9wdGlvbi5kaXNhYmxlZCkge1xuICAgICAgICByZXR1cm4gZGVmYXVsdFJlc3VsdDtcbiAgICB9XG4gICAgaWYgKCFvcHRpb24uYXR0cmlidXRlcyB8fCAhKCd2YWx1ZScgaW4gb3B0aW9uLmF0dHJpYnV0ZXMpKSB7XG4gICAgICAgIHJldHVybiB2YWxpZFJlc3VsdDtcbiAgICB9XG4gICAgcmV0dXJuIGlzVW5kZWZpbmVkKG9wdGlvbi52YWx1ZSkgfHwgb3B0aW9uLnZhbHVlID09PSAnJ1xuICAgICAgICA/IHZhbGlkUmVzdWx0XG4gICAgICAgIDogeyB2YWx1ZTogb3B0aW9uLnZhbHVlLCBpc1ZhbGlkOiB0cnVlIH07XG59O1xuXG5jb25zdCBkZWZhdWx0UmV0dXJuID0ge1xuICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgIHZhbHVlOiBudWxsLFxufTtcbnZhciBnZXRSYWRpb1ZhbHVlID0gKG9wdGlvbnMpID0+IEFycmF5LmlzQXJyYXkob3B0aW9ucylcbiAgICA/IG9wdGlvbnMucmVkdWNlKChwcmV2aW91cywgb3B0aW9uKSA9PiBvcHRpb24gJiYgb3B0aW9uLmNoZWNrZWQgJiYgIW9wdGlvbi5kaXNhYmxlZFxuICAgICAgICA/IHtcbiAgICAgICAgICAgIGlzVmFsaWQ6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogb3B0aW9uLnZhbHVlLFxuICAgICAgICB9XG4gICAgICAgIDogcHJldmlvdXMsIGRlZmF1bHRSZXR1cm4pXG4gICAgOiBkZWZhdWx0UmV0dXJuO1xuXG5mdW5jdGlvbiBnZXRWYWxpZGF0ZUVycm9yKHJlc3VsdCwgcmVmLCB0eXBlID0gJ3ZhbGlkYXRlJykge1xuICAgIGlmIChpc1N0cmluZyhyZXN1bHQpIHx8XG4gICAgICAgIChBcnJheS5pc0FycmF5KHJlc3VsdCkgJiYgISFyZXN1bHQubGVuZ3RoICYmIHJlc3VsdC5ldmVyeShpc1N0cmluZykpIHx8XG4gICAgICAgIChpc0Jvb2xlYW4ocmVzdWx0KSAmJiAhcmVzdWx0KSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGlzU3RyaW5nKHJlc3VsdCkgPyByZXN1bHQgOiAnJyxcbiAgICAgICAgICAgIHJlZixcbiAgICAgICAgfTtcbiAgICB9XG59XG5cbnZhciBnZXRWYWx1ZUFuZE1lc3NhZ2UgPSAodmFsaWRhdGlvbkRhdGEpID0+IGlzT2JqZWN0KHZhbGlkYXRpb25EYXRhKSAmJiAhaXNSZWdleCh2YWxpZGF0aW9uRGF0YSlcbiAgICA/IHZhbGlkYXRpb25EYXRhXG4gICAgOiB7XG4gICAgICAgIHZhbHVlOiB2YWxpZGF0aW9uRGF0YSxcbiAgICAgICAgbWVzc2FnZTogJycsXG4gICAgfTtcblxudmFyIHZhbGlkYXRlRmllbGQgPSBhc3luYyAoZmllbGQsIGRpc2FibGVkRmllbGROYW1lcywgZm9ybVZhbHVlcywgdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhLCBzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLCBpc0ZpZWxkQXJyYXkpID0+IHtcbiAgICBjb25zdCB7IHJlZiwgcmVmcywgcmVxdWlyZWQsIG1heExlbmd0aCwgbWluTGVuZ3RoLCBtaW4sIG1heCwgcGF0dGVybiwgdmFsaWRhdGUsIG5hbWUsIHZhbHVlQXNOdW1iZXIsIG1vdW50LCBfYywgfSA9IGZpZWxkLl9mO1xuICAgIGNvbnN0IGlucHV0VmFsdWUgPSBnZXQoZm9ybVZhbHVlcywgbmFtZSk7XG4gICAgaWYgKCFtb3VudCB8fCBkaXNhYmxlZEZpZWxkTmFtZXMuaGFzKG5hbWUpKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgY29uc3QgaW5wdXRSZWYgPSByZWZzID8gcmVmc1swXSA6IHJlZjtcbiAgICBjb25zdCBzZXRDdXN0b21WYWxpZGl0eSA9IChtZXNzYWdlKSA9PiB7XG4gICAgICAgIGlmIChzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmIGlucHV0UmVmLnJlcG9ydFZhbGlkaXR5KSB7XG4gICAgICAgICAgICBjb25zdCB2YWxpZGl0eU1lc3NhZ2UgPSBpc0Jvb2xlYW4obWVzc2FnZSkgPyAnJyA6IG1lc3NhZ2UgfHwgJyc7XG4gICAgICAgICAgICBpZiAocmVmcykge1xuICAgICAgICAgICAgICAgIHJlZnMuZm9yRWFjaCgocmVmKSA9PiBpc0Z1bmN0aW9uKHJlZi5zZXRDdXN0b21WYWxpZGl0eSkgJiZcbiAgICAgICAgICAgICAgICAgICAgcmVmLnNldEN1c3RvbVZhbGlkaXR5KHZhbGlkaXR5TWVzc2FnZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgaW5wdXRSZWYuc2V0Q3VzdG9tVmFsaWRpdHkodmFsaWRpdHlNZXNzYWdlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlucHV0UmVmLnJlcG9ydFZhbGlkaXR5KCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGVycm9yID0ge307XG4gICAgY29uc3QgaXNSYWRpbyA9ICFfYyAmJiBpc1JhZGlvSW5wdXQocmVmKTtcbiAgICBjb25zdCBpc0NoZWNrQm94ID0gIV9jICYmIGlzQ2hlY2tCb3hJbnB1dChyZWYpO1xuICAgIGNvbnN0IGlzUmFkaW9PckNoZWNrYm94ID0gaXNSYWRpbyB8fCBpc0NoZWNrQm94O1xuICAgIGNvbnN0IGlzRW1wdHkgPSAoKHZhbHVlQXNOdW1iZXIgfHwgaXNGaWxlSW5wdXQocmVmKSkgJiZcbiAgICAgICAgaXNVbmRlZmluZWQocmVmLnZhbHVlKSAmJlxuICAgICAgICBpc1VuZGVmaW5lZChpbnB1dFZhbHVlKSkgfHxcbiAgICAgICAgKGlzSFRNTEVsZW1lbnQocmVmKSAmJiByZWYudmFsdWUgPT09ICcnICYmICFfYykgfHxcbiAgICAgICAgaW5wdXRWYWx1ZSA9PT0gJycgfHxcbiAgICAgICAgKEFycmF5LmlzQXJyYXkoaW5wdXRWYWx1ZSkgJiYgIWlucHV0VmFsdWUubGVuZ3RoKTtcbiAgICBjb25zdCBhcHBlbmRFcnJvcnNDdXJyeSA9IGFwcGVuZEVycm9ycy5iaW5kKG51bGwsIG5hbWUsIHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSwgZXJyb3IpO1xuICAgIGNvbnN0IGdldE1pbk1heE1lc3NhZ2UgPSAoZXhjZWVkTWF4LCBtYXhMZW5ndGhNZXNzYWdlLCBtaW5MZW5ndGhNZXNzYWdlLCBtYXhUeXBlID0gSU5QVVRfVkFMSURBVElPTl9SVUxFUy5tYXhMZW5ndGgsIG1pblR5cGUgPSBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbkxlbmd0aCkgPT4ge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXhjZWVkTWF4ID8gbWF4TGVuZ3RoTWVzc2FnZSA6IG1pbkxlbmd0aE1lc3NhZ2U7XG4gICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgdHlwZTogZXhjZWVkTWF4ID8gbWF4VHlwZSA6IG1pblR5cGUsXG4gICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgcmVmLFxuICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoZXhjZWVkTWF4ID8gbWF4VHlwZSA6IG1pblR5cGUsIG1lc3NhZ2UpLFxuICAgICAgICB9O1xuICAgIH07XG4gICAgaWYgKGlzRmllbGRBcnJheVxuICAgICAgICA/ICFBcnJheS5pc0FycmF5KGlucHV0VmFsdWUpIHx8ICFpbnB1dFZhbHVlLmxlbmd0aFxuICAgICAgICA6IHJlcXVpcmVkICYmXG4gICAgICAgICAgICAoKCFpc1JhZGlvT3JDaGVja2JveCAmJiAoaXNFbXB0eSB8fCBpc051bGxPclVuZGVmaW5lZChpbnB1dFZhbHVlKSkpIHx8XG4gICAgICAgICAgICAgICAgKGlzQm9vbGVhbihpbnB1dFZhbHVlKSAmJiAhaW5wdXRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAoaXNDaGVja0JveCAmJiAhZ2V0Q2hlY2tib3hWYWx1ZShyZWZzKS5pc1ZhbGlkKSB8fFxuICAgICAgICAgICAgICAgIChpc1JhZGlvICYmICFnZXRSYWRpb1ZhbHVlKHJlZnMpLmlzVmFsaWQpKSkge1xuICAgICAgICBjb25zdCB7IHZhbHVlLCBtZXNzYWdlIH0gPSBpc1N0cmluZyhyZXF1aXJlZClcbiAgICAgICAgICAgID8geyB2YWx1ZTogISFyZXF1aXJlZCwgbWVzc2FnZTogcmVxdWlyZWQgfVxuICAgICAgICAgICAgOiBnZXRWYWx1ZUFuZE1lc3NhZ2UocmVxdWlyZWQpO1xuICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgICAgIHR5cGU6IElOUFVUX1ZBTElEQVRJT05fUlVMRVMucmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgICAgICByZWY6IGlucHV0UmVmLFxuICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KElOUFVUX1ZBTElEQVRJT05fUlVMRVMucmVxdWlyZWQsIG1lc3NhZ2UpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkobWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGlmICghaXNFbXB0eSAmJiAoIWlzTnVsbE9yVW5kZWZpbmVkKG1pbikgfHwgIWlzTnVsbE9yVW5kZWZpbmVkKG1heCkpKSB7XG4gICAgICAgIGxldCBleGNlZWRNYXg7XG4gICAgICAgIGxldCBleGNlZWRNaW47XG4gICAgICAgIGNvbnN0IG1heE91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtYXgpO1xuICAgICAgICBjb25zdCBtaW5PdXRwdXQgPSBnZXRWYWx1ZUFuZE1lc3NhZ2UobWluKTtcbiAgICAgICAgaWYgKCFpc051bGxPclVuZGVmaW5lZChpbnB1dFZhbHVlKSAmJlxuICAgICAgICAgICAgIWlzRGF0ZU9iamVjdChpbnB1dFZhbHVlKSAmJlxuICAgICAgICAgICAgIWlzTmFOKGlucHV0VmFsdWUpKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZU51bWJlciA9ICghX2MgJiYgcmVmLnZhbHVlQXNOdW1iZXIpIHx8XG4gICAgICAgICAgICAgICAgKGlucHV0VmFsdWUgPyAraW5wdXRWYWx1ZSA6IGlucHV0VmFsdWUpO1xuICAgICAgICAgICAgaWYgKCFpc051bGxPclVuZGVmaW5lZChtYXhPdXRwdXQudmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWF4ID0gdmFsdWVOdW1iZXIgPiBtYXhPdXRwdXQudmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWlzTnVsbE9yVW5kZWZpbmVkKG1pbk91dHB1dC52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBleGNlZWRNaW4gPSB2YWx1ZU51bWJlciA8IG1pbk91dHB1dC52YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlRGF0ZSA9ICghX2MgJiYgcmVmLnZhbHVlQXNEYXRlKSB8fFxuICAgICAgICAgICAgICAgIG5ldyBEYXRlKGlucHV0VmFsdWUpO1xuICAgICAgICAgICAgY29uc3QgY29udmVydFRpbWVUb0RhdGUgPSAodGltZSkgPT4gbmV3IERhdGUobmV3IERhdGUoKS50b0RhdGVTdHJpbmcoKSArICcgJyArIHRpbWUpO1xuICAgICAgICAgICAgY29uc3QgaXNUaW1lID0gcmVmLnR5cGUgPT0gJ3RpbWUnO1xuICAgICAgICAgICAgY29uc3QgaXNXZWVrID0gcmVmLnR5cGUgPT0gJ3dlZWsnO1xuICAgICAgICAgICAgaWYgKGlzU3RyaW5nKG1heE91dHB1dC52YWx1ZSkgJiYgaW5wdXRWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGV4Y2VlZE1heCA9IGlzVGltZVxuICAgICAgICAgICAgICAgICAgICA/IGNvbnZlcnRUaW1lVG9EYXRlKGlucHV0VmFsdWUpID4gY29udmVydFRpbWVUb0RhdGUobWF4T3V0cHV0LnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICA6IGlzV2Vla1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBpbnB1dFZhbHVlID4gbWF4T3V0cHV0LnZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHZhbHVlRGF0ZSA+IG5ldyBEYXRlKG1heE91dHB1dC52YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcobWluT3V0cHV0LnZhbHVlKSAmJiBpbnB1dFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWluID0gaXNUaW1lXG4gICAgICAgICAgICAgICAgICAgID8gY29udmVydFRpbWVUb0RhdGUoaW5wdXRWYWx1ZSkgPCBjb252ZXJ0VGltZVRvRGF0ZShtaW5PdXRwdXQudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgIDogaXNXZWVrXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGlucHV0VmFsdWUgPCBtaW5PdXRwdXQudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWVEYXRlIDwgbmV3IERhdGUobWluT3V0cHV0LnZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZXhjZWVkTWF4IHx8IGV4Y2VlZE1pbikge1xuICAgICAgICAgICAgZ2V0TWluTWF4TWVzc2FnZSghIWV4Y2VlZE1heCwgbWF4T3V0cHV0Lm1lc3NhZ2UsIG1pbk91dHB1dC5tZXNzYWdlLCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heCwgSU5QVVRfVkFMSURBVElPTl9SVUxFUy5taW4pO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShlcnJvcltuYW1lXS5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKCghaXNOdWxsT3JVbmRlZmluZWQobWF4TGVuZ3RoKSB8fCAhaXNOdWxsT3JVbmRlZmluZWQobWluTGVuZ3RoKSkgJiZcbiAgICAgICAgIWlzRW1wdHkgJiZcbiAgICAgICAgKGlzU3RyaW5nKGlucHV0VmFsdWUpIHx8IChpc0ZpZWxkQXJyYXkgJiYgQXJyYXkuaXNBcnJheShpbnB1dFZhbHVlKSkpKSB7XG4gICAgICAgIGNvbnN0IG1heExlbmd0aE91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtYXhMZW5ndGgpO1xuICAgICAgICBjb25zdCBtaW5MZW5ndGhPdXRwdXQgPSBnZXRWYWx1ZUFuZE1lc3NhZ2UobWluTGVuZ3RoKTtcbiAgICAgICAgY29uc3QgZXhjZWVkTWF4ID0gIWlzTnVsbE9yVW5kZWZpbmVkKG1heExlbmd0aE91dHB1dC52YWx1ZSkgJiZcbiAgICAgICAgICAgIGlucHV0VmFsdWUubGVuZ3RoID4gK21heExlbmd0aE91dHB1dC52YWx1ZTtcbiAgICAgICAgY29uc3QgZXhjZWVkTWluID0gIWlzTnVsbE9yVW5kZWZpbmVkKG1pbkxlbmd0aE91dHB1dC52YWx1ZSkgJiZcbiAgICAgICAgICAgIGlucHV0VmFsdWUubGVuZ3RoIDwgK21pbkxlbmd0aE91dHB1dC52YWx1ZTtcbiAgICAgICAgaWYgKGV4Y2VlZE1heCB8fCBleGNlZWRNaW4pIHtcbiAgICAgICAgICAgIGdldE1pbk1heE1lc3NhZ2UoZXhjZWVkTWF4LCBtYXhMZW5ndGhPdXRwdXQubWVzc2FnZSwgbWluTGVuZ3RoT3V0cHV0Lm1lc3NhZ2UpO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShlcnJvcltuYW1lXS5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKHBhdHRlcm4gJiYgIWlzRW1wdHkgJiYgaXNTdHJpbmcoaW5wdXRWYWx1ZSkpIHtcbiAgICAgICAgY29uc3QgeyB2YWx1ZTogcGF0dGVyblZhbHVlLCBtZXNzYWdlIH0gPSBnZXRWYWx1ZUFuZE1lc3NhZ2UocGF0dGVybik7XG4gICAgICAgIGlmIChpc1JlZ2V4KHBhdHRlcm5WYWx1ZSkgJiYgIWlucHV0VmFsdWUubWF0Y2gocGF0dGVyblZhbHVlKSkge1xuICAgICAgICAgICAgZXJyb3JbbmFtZV0gPSB7XG4gICAgICAgICAgICAgICAgdHlwZTogSU5QVVRfVkFMSURBVElPTl9SVUxFUy5wYXR0ZXJuLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgcmVmLFxuICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KElOUFVUX1ZBTElEQVRJT05fUlVMRVMucGF0dGVybiwgbWVzc2FnZSksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKHZhbGlkYXRlKSB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKHZhbGlkYXRlKSkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdmFsaWRhdGUoaW5wdXRWYWx1ZSwgZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICBjb25zdCB2YWxpZGF0ZUVycm9yID0gZ2V0VmFsaWRhdGVFcnJvcihyZXN1bHQsIGlucHV0UmVmKTtcbiAgICAgICAgICAgIGlmICh2YWxpZGF0ZUVycm9yKSB7XG4gICAgICAgICAgICAgICAgZXJyb3JbbmFtZV0gPSB7XG4gICAgICAgICAgICAgICAgICAgIC4uLnZhbGlkYXRlRXJyb3IsXG4gICAgICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KElOUFVUX1ZBTElEQVRJT05fUlVMRVMudmFsaWRhdGUsIHZhbGlkYXRlRXJyb3IubWVzc2FnZSksXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eSh2YWxpZGF0ZUVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzT2JqZWN0KHZhbGlkYXRlKSkge1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRpb25SZXN1bHQgPSB7fTtcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIHZhbGlkYXRlKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFpc0VtcHR5T2JqZWN0KHZhbGlkYXRpb25SZXN1bHQpICYmICF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHZhbGlkYXRlRXJyb3IgPSBnZXRWYWxpZGF0ZUVycm9yKGF3YWl0IHZhbGlkYXRlW2tleV0oaW5wdXRWYWx1ZSwgZm9ybVZhbHVlcyksIGlucHV0UmVmLCBrZXkpO1xuICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0ZUVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi52YWxpZGF0ZUVycm9yLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3Vycnkoa2V5LCB2YWxpZGF0ZUVycm9yLm1lc3NhZ2UpLFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkodmFsaWRhdGVFcnJvci5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvcltuYW1lXSA9IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWlzRW1wdHlPYmplY3QodmFsaWRhdGlvblJlc3VsdCkpIHtcbiAgICAgICAgICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgICAgICAgICAgcmVmOiBpbnB1dFJlZixcbiAgICAgICAgICAgICAgICAgICAgLi4udmFsaWRhdGlvblJlc3VsdCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgZmllbGRFcnJvciA9IGVycm9yW25hbWVdO1xuICAgIHNldEN1c3RvbVZhbGlkaXR5KGZpZWxkRXJyb3IgPyBmaWVsZEVycm9yLm1lc3NhZ2UgOiB0cnVlKTtcbiAgICByZXR1cm4gZXJyb3I7XG59O1xuXG52YXIgY29udmVydFRvQXJyYXlQYXlsb2FkID0gKHZhbHVlKSA9PiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZSA6IFt2YWx1ZV0pO1xuXG52YXIgYXBwZW5kQXQgPSAoZGF0YSwgdmFsdWUpID0+IFtcbiAgICAuLi5kYXRhLFxuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZCh2YWx1ZSksXG5dO1xuXG52YXIgZmlsbEVtcHR5QXJyYXkgPSAodmFsdWUpID0+IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKCgpID0+IHVuZGVmaW5lZCkgOiB1bmRlZmluZWQ7XG5cbmZ1bmN0aW9uIGluc2VydChkYXRhLCBpbmRleCwgdmFsdWUpIHtcbiAgICByZXR1cm4gW1xuICAgICAgICAuLi5kYXRhLnNsaWNlKDAsIGluZGV4KSxcbiAgICAgICAgLi4uY29udmVydFRvQXJyYXlQYXlsb2FkKHZhbHVlKSxcbiAgICAgICAgLi4uZGF0YS5zbGljZShpbmRleCksXG4gICAgXTtcbn1cblxudmFyIG1vdmVBcnJheUF0ID0gKGRhdGEsIGZyb20sIHRvKSA9PiB7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKGlzVW5kZWZpbmVkKGRhdGFbdG9dKSkge1xuICAgICAgICBkYXRhW3RvXSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZGF0YS5zcGxpY2UodG8sIDAsIGRhdGEuc3BsaWNlKGZyb20sIDEpWzBdKTtcbiAgICByZXR1cm4gZGF0YTtcbn07XG5cbnZhciBwcmVwZW5kQXQgPSAoZGF0YSwgdmFsdWUpID0+IFtcbiAgICAuLi5jb252ZXJ0VG9BcnJheVBheWxvYWQodmFsdWUpLFxuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZChkYXRhKSxcbl07XG5cbnZhciBjb21wYWN0ID0gKHZhbHVlKSA9PiBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmZpbHRlcihCb29sZWFuKSA6IFtdO1xuXG5mdW5jdGlvbiByZW1vdmVBdEluZGV4ZXMoZGF0YSwgaW5kZXhlcykge1xuICAgIGxldCBpID0gMDtcbiAgICBjb25zdCB0ZW1wID0gWy4uLmRhdGFdO1xuICAgIGZvciAoY29uc3QgaW5kZXggb2YgaW5kZXhlcykge1xuICAgICAgICB0ZW1wLnNwbGljZShpbmRleCAtIGksIDEpO1xuICAgICAgICBpKys7XG4gICAgfVxuICAgIHJldHVybiBjb21wYWN0KHRlbXApLmxlbmd0aCA/IHRlbXAgOiBbXTtcbn1cbnZhciByZW1vdmVBcnJheUF0ID0gKGRhdGEsIGluZGV4KSA9PiBpc1VuZGVmaW5lZChpbmRleClcbiAgICA/IFtdXG4gICAgOiByZW1vdmVBdEluZGV4ZXMoZGF0YSwgWy4uLm5ldyBTZXQoY29udmVydFRvQXJyYXlQYXlsb2FkKGluZGV4KSldLnNvcnQoKGEsIGIpID0+IGEgLSBiKSk7XG5cbnZhciBzd2FwQXJyYXlBdCA9IChkYXRhLCBpbmRleEEsIGluZGV4QikgPT4ge1xuICAgIFtkYXRhW2luZGV4QV0sIGRhdGFbaW5kZXhCXV0gPSBbZGF0YVtpbmRleEJdLCBkYXRhW2luZGV4QV1dO1xufTtcblxuZnVuY3Rpb24gYmFzZUdldChvYmplY3QsIHVwZGF0ZVBhdGgpIHtcbiAgICBjb25zdCBsZW5ndGggPSB1cGRhdGVQYXRoLmxlbmd0aCAtIDE7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICB3aGlsZSAoaW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgaWYgKGlzTnVsbE9yVW5kZWZpbmVkKG9iamVjdCkpIHtcbiAgICAgICAgICAgIG9iamVjdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIG9iamVjdCA9IG9iamVjdFt1cGRhdGVQYXRoW2luZGV4XV07XG4gICAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiBvYmplY3Q7XG59XG5mdW5jdGlvbiBpc0VtcHR5QXJyYXkob2JqKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gb2JqKSB7XG4gICAgICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoa2V5KSAmJiAhaXNVbmRlZmluZWQob2JqW2tleV0pKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiB1bnNldChvYmplY3QsIHBhdGgpIHtcbiAgICBpZiAoaXNTdHJpbmcocGF0aCkgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcGF0aCkpIHtcbiAgICAgICAgZGVsZXRlIG9iamVjdFtwYXRoXTtcbiAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICB9XG4gICAgY29uc3QgcGF0aHMgPSBBcnJheS5pc0FycmF5KHBhdGgpXG4gICAgICAgID8gcGF0aFxuICAgICAgICA6IGlzS2V5KHBhdGgpXG4gICAgICAgICAgICA/IFtwYXRoXVxuICAgICAgICAgICAgOiBzdHJpbmdUb1BhdGgocGF0aCk7XG4gICAgaWYgKHBhdGhzLnNvbWUoKHNlZ21lbnQpID0+IFBST1RPVFlQRV9LRVlXT1JEUy5pbmNsdWRlcyhTdHJpbmcoc2VnbWVudCkpKSkge1xuICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgIH1cbiAgICBjb25zdCBjaGlsZE9iamVjdCA9IHBhdGhzLmxlbmd0aCA9PT0gMSA/IG9iamVjdCA6IGJhc2VHZXQob2JqZWN0LCBwYXRocyk7XG4gICAgY29uc3QgaW5kZXggPSBwYXRocy5sZW5ndGggLSAxO1xuICAgIGNvbnN0IGtleSA9IHBhdGhzW2luZGV4XTtcbiAgICBpZiAoY2hpbGRPYmplY3QpIHtcbiAgICAgICAgZGVsZXRlIGNoaWxkT2JqZWN0W2tleV07XG4gICAgfVxuICAgIGlmIChpbmRleCAhPT0gMCAmJlxuICAgICAgICAoKGlzT2JqZWN0KGNoaWxkT2JqZWN0KSAmJiBpc0VtcHR5T2JqZWN0KGNoaWxkT2JqZWN0KSkgfHxcbiAgICAgICAgICAgIChBcnJheS5pc0FycmF5KGNoaWxkT2JqZWN0KSAmJiBpc0VtcHR5QXJyYXkoY2hpbGRPYmplY3QpKSkpIHtcbiAgICAgICAgdW5zZXQob2JqZWN0LCBwYXRocy5zbGljZSgwLCAtMSkpO1xuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0O1xufVxuXG52YXIgdXBkYXRlQXQgPSAoZmllbGRWYWx1ZXMsIGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgIGZpZWxkVmFsdWVzW2luZGV4XSA9IHZhbHVlO1xuICAgIHJldHVybiBmaWVsZFZhbHVlcztcbn07XG5cbi8qKlxuICogSG9vayBmb3IgZHluYW1pYyBmaWVsZCBhcnJheXMuIFByb3ZpZGVzIGBmaWVsZHNgIGFuZCBtdXRhdGlvbiBtZXRob2RzOlxuICogYGFwcGVuZGAsIGBwcmVwZW5kYCwgYHJlbW92ZWAsIGBpbnNlcnRgLCBgc3dhcGAsIGBtb3ZlYCwgYHVwZGF0ZWAsIGByZXBsYWNlYC5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZpZWxkYXJyYXkpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgeyBmaWVsZHMsIGFwcGVuZCB9ID0gdXNlRmllbGRBcnJheSh7IGNvbnRyb2wsIG5hbWU6IFwiaXRlbXNcIiB9KTtcbiAqIHJldHVybiBmaWVsZHMubWFwKChmLCBpKSA9PiA8aW5wdXQga2V5PXtmLmlkfSB7Li4ucmVnaXN0ZXIoYGl0ZW1zLiR7aX0ubmFtZWApfSAvPik7XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlRmllbGRBcnJheShwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIG5hbWUsIGtleU5hbWUgPSAnaWQnLCBkaXNhYmxlZCwgc2hvdWxkVW5yZWdpc3RlciwgcnVsZXMsIH0gPSBwcm9wcztcbiAgICBjb25zdCBnZXRDdXJyZW50RmllbGRBcnJheSA9ICgpID0+IGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSk7XG4gICAgY29uc3QgW2ZpZWxkcywgc2V0RmllbGRzXSA9IFJlYWN0LnVzZVN0YXRlKGdldEN1cnJlbnRGaWVsZEFycmF5KTtcbiAgICBjb25zdCBpZHMgPSBSZWFjdC51c2VSZWYoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgIGNvbnN0IF9hY3Rpb25lZCA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgeyByZXN5bmNJZk5lZWRlZCwgc25hcHNob3QgfSA9IHVzZVJlc3luY09uUmVjb25uZWN0KGdldEN1cnJlbnRGaWVsZEFycmF5KTtcbiAgICBjb25zdCBfcHJldkNvbnRyb2wgPSBSZWFjdC51c2VSZWYoY29udHJvbCk7XG4gICAgY29uc3QgX3ByZXZOYW1lID0gUmVhY3QudXNlUmVmKG5hbWUpO1xuICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgY29udHJvbC5fbmFtZXMuYXJyYXkuYWRkKG5hbWUpO1xuICAgIH1cbiAgICBSZWFjdC51c2VNZW1vKCgpID0+ICFkaXNhYmxlZCAmJlxuICAgICAgICBydWxlcyAmJlxuICAgICAgICBmaWVsZHMgJiZcbiAgICAgICAgY29udHJvbC5yZWdpc3RlcihuYW1lLCBydWxlcyksIFtjb250cm9sLCBuYW1lLCBmaWVsZHMsIHJ1bGVzLCBkaXNhYmxlZF0pO1xuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoX3ByZXZDb250cm9sLmN1cnJlbnQgPT09IGNvbnRyb2wgJiYgX3ByZXZOYW1lLmN1cnJlbnQgPT09IG5hbWUpIHtcbiAgICAgICAgICAgIHJlc3luY0lmTmVlZGVkKHRydWUsIGdldEN1cnJlbnRGaWVsZEFycmF5LCAoZmllbGRWYWx1ZXMpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZHMoZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgIGlkcy5jdXJyZW50ID0gZmllbGRWYWx1ZXMubWFwKGdlbmVyYXRlSWQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBfcHJldkNvbnRyb2wuY3VycmVudCA9IGNvbnRyb2w7XG4gICAgICAgICAgICBfcHJldk5hbWUuY3VycmVudCA9IG5hbWU7XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlcyA9IGdldEN1cnJlbnRGaWVsZEFycmF5KCk7XG4gICAgICAgICAgICBpZiAoIWRlZXBFcXVhbChmaWVsZHMsIGZpZWxkVmFsdWVzKSkge1xuICAgICAgICAgICAgICAgIHNldEZpZWxkcyhmaWVsZFZhbHVlcyk7XG4gICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBmaWVsZFZhbHVlcy5tYXAoZ2VuZXJhdGVJZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzbmFwc2hvdCh0cnVlLCBnZXRDdXJyZW50RmllbGRBcnJheSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJqZWN0cy5hcnJheS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHsgdmFsdWVzLCBuYW1lOiBmaWVsZEFycmF5TmFtZSwgfSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZEFycmF5TmFtZSA9PT0gbmFtZSB8fCAhZmllbGRBcnJheU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZXMgPSBnZXQodmFsdWVzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZmllbGRWYWx1ZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBmaWVsZFZhbHVlcy5tYXAoZ2VuZXJhdGVJZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWZpZWxkQXJyYXlOYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pLnVuc3Vic2NyaWJlO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNuYXBzaG90KHRydWUsIGdldEN1cnJlbnRGaWVsZEFycmF5KTtcbiAgICAgICAgfTtcbiAgICB9LCBbY29udHJvbCwgbmFtZSwgZGlzYWJsZWQsIHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdF0pO1xuICAgIGNvbnN0IHVwZGF0ZVZhbHVlcyA9IFJlYWN0LnVzZUNhbGxiYWNrKCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcykgPT4ge1xuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgIH0sIFtjb250cm9sLCBuYW1lXSk7XG4gICAgY29uc3QgYXBwZW5kID0gKHZhbHVlLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGFwcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gYXBwZW5kQXQoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKSwgYXBwZW5kVmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLmxlbmd0aCAtIDEsIG9wdGlvbnMpO1xuICAgICAgICBpZHMuY3VycmVudCA9IGFwcGVuZEF0KGlkcy5jdXJyZW50LCBhcHBlbmRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBhcHBlbmRBdCwge1xuICAgICAgICAgICAgYXJnQTogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHByZXBlbmQgPSAodmFsdWUsIG9wdGlvbnMpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJlcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcHJlcGVuZEF0KGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSksIHByZXBlbmRWYWx1ZSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gZ2V0Rm9jdXNGaWVsZE5hbWUobmFtZSwgMCwgb3B0aW9ucyk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcHJlcGVuZEF0KGlkcy5jdXJyZW50LCBwcmVwZW5kVmFsdWUubWFwKGdlbmVyYXRlSWQpKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgcHJlcGVuZEF0LCB7XG4gICAgICAgICAgICBhcmdBOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVtb3ZlID0gKGluZGV4KSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcmVtb3ZlQXJyYXlBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcmVtb3ZlQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXgpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICAhQXJyYXkuaXNBcnJheShnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKSkgJiZcbiAgICAgICAgICAgIHNldChjb250cm9sLl9maWVsZHMsIG5hbWUsIHVuZGVmaW5lZCk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIHJlbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGluc2VydCQxID0gKGluZGV4LCB2YWx1ZSwgb3B0aW9ucykgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpbnNlcnRWYWx1ZSA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGluc2VydChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgaW5zZXJ0VmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIGluZGV4LCBvcHRpb25zKTtcbiAgICAgICAgaWRzLmN1cnJlbnQgPSBpbnNlcnQoaWRzLmN1cnJlbnQsIGluZGV4LCBpbnNlcnRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBpbnNlcnQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICAgICAgYXJnQjogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHN3YXAgPSAoaW5kZXhBLCBpbmRleEIpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSBjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICBzd2FwQXJyYXlBdCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICBzd2FwQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBzd2FwQXJyYXlBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXhBLFxuICAgICAgICAgICAgYXJnQjogaW5kZXhCLFxuICAgICAgICB9LCBmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCBtb3ZlID0gKGZyb20sIHRvKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKTtcbiAgICAgICAgbW92ZUFycmF5QXQodXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIGZyb20sIHRvKTtcbiAgICAgICAgbW92ZUFycmF5QXQoaWRzLmN1cnJlbnQsIGZyb20sIHRvKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGZyb20sXG4gICAgICAgICAgICBhcmdCOiB0byxcbiAgICAgICAgfSwgZmFsc2UpO1xuICAgIH07XG4gICAgY29uc3QgdXBkYXRlID0gKGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVWYWx1ZSA9IGNsb25lT2JqZWN0KHZhbHVlKTtcbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSB1cGRhdGVBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgdXBkYXRlVmFsdWUpO1xuICAgICAgICBpZHMuY3VycmVudCA9IFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10ubWFwKChpdGVtLCBpKSA9PiAhaXRlbSB8fCBpID09PSBpbmRleCA/IGdlbmVyYXRlSWQoKSA6IGlkcy5jdXJyZW50W2ldKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCB1cGRhdGVBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXgsXG4gICAgICAgICAgICBhcmdCOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVwbGFjZSA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBpZHMuY3VycmVudCA9IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLm1hcChnZW5lcmF0ZUlkKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBzZXRGaWVsZHMoWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSwgKGRhdGEpID0+IEFycmF5LmlzQXJyYXkoZGF0YSlcbiAgICAgICAgICAgID8gZGF0YS5zbGljZSgwLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcy5sZW5ndGgpXG4gICAgICAgICAgICA6IGRhdGEsIHt9KTtcbiAgICB9O1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb250cm9sLl9zdGF0ZS5hY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgaXNXYXRjaGVkKG5hbWUsIGNvbnRyb2wuX25hbWVzKSAmJlxuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpb25Nb2RlcyA9IGdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLm1vZGUpO1xuICAgICAgICBjb25zdCByZVZhbGlkYXRlTW9kZXMgPSBnZXRWYWxpZGF0aW9uTW9kZXMoY29udHJvbC5fb3B0aW9ucy5yZVZhbGlkYXRlTW9kZSk7XG4gICAgICAgIGlmIChfYWN0aW9uZWQuY3VycmVudCAmJlxuICAgICAgICAgICAgKCF2YWxpZGF0aW9uTW9kZXMuaXNPblN1Ym1pdCB8fCBjb250cm9sLl9mb3JtU3RhdGUuaXNTdWJtaXR0ZWQpICYmXG4gICAgICAgICAgICAhcmVWYWxpZGF0ZU1vZGVzLmlzT25TdWJtaXQgJiZcbiAgICAgICAgICAgICghdmFsaWRhdGlvbk1vZGVzLmlzT25CbHVyIHx8XG4gICAgICAgICAgICAgICAgKGNvbnRyb2wuX2Zvcm1TdGF0ZS5pc1N1Ym1pdHRlZCAmJiByZVZhbGlkYXRlTW9kZXMuaXNPbkNoYW5nZSkpKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZEFycmF5VmFsdWVzID0gZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGNvbnRyb2wuX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgICAgICBjb250cm9sLl9ydW5TY2hlbWEoW25hbWVdKS50aGVuKChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZEFycmF5VmFsdWVzICE9PSBnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IGdldChyZXN1bHQuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdFcnJvciA9IGdldChjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdFcnJvclR5cGUgPSBleGlzdGluZ0Vycm9yICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAoZXhpc3RpbmdFcnJvci50eXBlIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGV4aXN0aW5nRXJyb3Iucm9vdCAmJiBleGlzdGluZ0Vycm9yLnJvb3QudHlwZSkpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBleGlzdGluZ0Vycm9yTWVzc2FnZSA9IGV4aXN0aW5nRXJyb3IgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIChleGlzdGluZ0Vycm9yLm1lc3NhZ2UgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZXhpc3RpbmdFcnJvci5yb290ICYmIGV4aXN0aW5nRXJyb3Iucm9vdC5tZXNzYWdlKSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ0Vycm9yXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICghZXJyb3IgJiYgZXhpc3RpbmdFcnJvclR5cGUpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGVycm9yICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChleGlzdGluZ0Vycm9yVHlwZSAhPT0gZXJyb3IudHlwZSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdFcnJvck1lc3NhZ2UgIT09IGVycm9yLm1lc3NhZ2UpKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBlcnJvciAmJiBlcnJvci50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc09iamVjdChlcnJvcikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIU9iamVjdC5rZXlzKGVycm9yKS5zb21lKChrZXkpID0+ICFOdW1iZXIuaXNOYU4oK2tleSkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdXBkYXRlRmllbGRBcnJheVJvb3RFcnJvcihjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCB7IFtuYW1lXTogZXJyb3IgfSwgbmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzZXQoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgbmFtZSwgZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5zZXQoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5jb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnM6IGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGVGaWVsZChmaWVsZCwgY29udHJvbC5fbmFtZXMuZGlzYWJsZWQsIGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIGNvbnRyb2wuX29wdGlvbnMuY3JpdGVyaWFNb2RlID09PSBWQUxJREFUSU9OX01PREUuYWxsLCBjb250cm9sLl9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24sIHRydWUpLnRoZW4oKGVycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGRBcnJheVZhbHVlcyAhPT0gZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0VtcHR5T2JqZWN0KGVycm9yKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgZXJyb3IsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdFcnJvciA9IGdldChjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdFcnJvciAmJiBleGlzdGluZ0Vycm9yW1JPT1RfRVJST1JfVFlQRV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5zZXQoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgYCR7bmFtZX0uJHtST09UX0VSUk9SX1RZUEV9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnM6IGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIEV4dGVybmFsIHVwZGF0ZXMgdGhhdCBjaGFuZ2UgYGZpZWxkc2AgKGUuZy4gcmVzZXQoKSBvciBzZXRWYWx1ZSgpIG9uXG4gICAgICAgIC8vIHRoZSBhcnJheSkgYWxyZWFkeSBub3RpZnkgc3Vic2NyaWJlcnMgd2l0aCB0aGUgdXAtdG8tZGF0ZSB2YWx1ZXNcbiAgICAgICAgLy8gdGhlbXNlbHZlcywgc28gb25seSByZS1icm9hZGNhc3QgaGVyZSBmb3IgZ2VudWluZSBhcnJheSBtZXRob2QgY2FsbHMuXG4gICAgICAgIF9hY3Rpb25lZC5jdXJyZW50ICYmXG4gICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlczogY2xvbmVPYmplY3QoY29udHJvbC5fZm9ybVZhbHVlcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgY29udHJvbC5fbmFtZXMuZm9jdXMgJiZcbiAgICAgICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihjb250cm9sLl9maWVsZHMsIChyZWYsIGtleSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChjb250cm9sLl9uYW1lcy5mb2N1cyAmJlxuICAgICAgICAgICAgICAgICAgICBrZXkuc3RhcnRzV2l0aChjb250cm9sLl9uYW1lcy5mb2N1cykgJiZcbiAgICAgICAgICAgICAgICAgICAgcmVmLmZvY3VzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlZi5mb2N1cygpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gJyc7XG4gICAgICAgIGNvbnRyb2wuX3NldFZhbGlkKCk7XG4gICAgICAgIF9hY3Rpb25lZC5jdXJyZW50ID0gZmFsc2U7XG4gICAgfSwgW2ZpZWxkcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWRpc2FibGVkKSB7XG4gICAgICAgICAgICBpc1VuZGVmaW5lZChnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSkpICYmXG4gICAgICAgICAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgIGNvbnRyb2wuX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5zaXplIHx8IChjb250cm9sLl9zdGF0ZS5hY3Rpb24gPSBmYWxzZSk7XG4gICAgICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBzaG91bGRLZWVwRmllbGRBcnJheVZhbHVlcyA9ICEoY29udHJvbC5fb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyIHx8IHNob3VsZFVucmVnaXN0ZXIpO1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlTW91bnRlZCA9IChuYW1lLCB2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLm1vdW50ID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmIChfYWN0aW9uZWQuY3VycmVudCAmJiBzaG91bGRLZWVwRmllbGRBcnJheVZhbHVlcykge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZXM6IGNsb25lT2JqZWN0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFzaG91bGRLZWVwRmllbGRBcnJheVZhbHVlcyAmJlxuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3N0YXRlLmFjdGlvbiAmJlxuICAgICAgICAgICAgICAgIFsuLi5jb250cm9sLl9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMua2V5cygpXS5zb21lKChhcnJheU5hbWUpID0+IG5hbWUuc3RhcnRzV2l0aChhcnJheU5hbWUgKyAnLicpKSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzXG4gICAgICAgICAgICAgICAgPyB1cGRhdGVNb3VudGVkKG5hbWUsIGZhbHNlKVxuICAgICAgICAgICAgICAgIDogY29udHJvbC51bnJlZ2lzdGVyKG5hbWUpO1xuICAgICAgICB9O1xuICAgIH0sIFtuYW1lLCBjb250cm9sLCBrZXlOYW1lLCBzaG91bGRVbnJlZ2lzdGVyLCBkaXNhYmxlZF0pO1xuICAgIHJldHVybiB7XG4gICAgICAgIHN3YXA6IFJlYWN0LnVzZUNhbGxiYWNrKHN3YXAsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIG1vdmU6IFJlYWN0LnVzZUNhbGxiYWNrKG1vdmUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHByZXBlbmQ6IFJlYWN0LnVzZUNhbGxiYWNrKHByZXBlbmQsIFtcbiAgICAgICAgICAgIHVwZGF0ZVZhbHVlcyxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBjb250cm9sLFxuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgIF0pLFxuICAgICAgICBhcHBlbmQ6IFJlYWN0LnVzZUNhbGxiYWNrKGFwcGVuZCwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgcmVtb3ZlOiBSZWFjdC51c2VDYWxsYmFjayhyZW1vdmUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIGluc2VydDogUmVhY3QudXNlQ2FsbGJhY2soaW5zZXJ0JDEsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHVwZGF0ZTogUmVhY3QudXNlQ2FsbGJhY2sodXBkYXRlLCBbdXBkYXRlVmFsdWVzLCBuYW1lLCBjb250cm9sLCBkaXNhYmxlZF0pLFxuICAgICAgICByZXBsYWNlOiBSZWFjdC51c2VDYWxsYmFjayhyZXBsYWNlLCBbXG4gICAgICAgICAgICB1cGRhdGVWYWx1ZXMsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgY29udHJvbCxcbiAgICAgICAgICAgIGRpc2FibGVkLFxuICAgICAgICBdKSxcbiAgICAgICAgZmllbGRzOiBSZWFjdC51c2VNZW1vKCgpID0+IGZpZWxkcy5tYXAoKGZpZWxkLCBpbmRleCkgPT4gKHtcbiAgICAgICAgICAgIC4uLmZpZWxkLFxuICAgICAgICAgICAgLi4uKGlzQm9vbGVhbihkaXNhYmxlZCkgPyB7IGRpc2FibGVkIH0gOiB7fSksXG4gICAgICAgICAgICBba2V5TmFtZV06IGlkcy5jdXJyZW50W2luZGV4XSB8fCBnZW5lcmF0ZUlkKCksXG4gICAgICAgIH0pKSwgW2ZpZWxkcywga2V5TmFtZSwgZGlzYWJsZWRdKSxcbiAgICB9O1xufVxuXG4vKipcbiAqIENvbXBvbmVudCBiYXNlZCBvbiBgdXNlRmllbGRBcnJheWAgaG9vayB0byB3b3JrIHdpdGggY29udHJvbGxlZCBjb21wb25lbnQuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCB7IGNvbnRyb2wsIHJlZ2lzdGVyIH0gPSB1c2VGb3JtPEZvcm1WYWx1ZXM+KHtcbiAqICAgICBkZWZhdWx0VmFsdWVzOiB7XG4gKiAgICAgICB0ZXN0OiBbXG4gKiAgICAgICAgIHtcbiAqICAgICAgICAgICB2YWx1ZTogJycsXG4gKiAgICAgICAgIH0sXG4gKiAgICAgICBdLFxuICogICAgIH0sXG4gKiAgIH0pO1xuICpcbiAqICAgcmV0dXJuIChcbiAqICAgICA8Zm9ybT5cbiAqICAgICAgIDxGaWVsZEFycmF5XG4gKiAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gKiAgICAgICAgIG5hbWU9XCJ0ZXN0XCJcbiAqICAgICAgICAgcmVuZGVyPXsoeyBmaWVsZHMgfSkgPT5cbiAqICAgICAgICAgICBmaWVsZHMubWFwKChmaWVsZCwgaW5kZXgpID0+IChcbiAqICAgICAgICAgICAgIDxpbnB1dCBrZXk9e2ZpZWxkLmlkfSB7Li4ucmVnaXN0ZXIoYHRlc3QuJHtpbmRleH0udmFsdWVgKX0gLz5cbiAqICAgICAgICAgICApKVxuICogICAgICAgICB9XG4gKiAgICAgICAvPlxuICogICAgIDwvZm9ybT5cbiAqICAgKTtcbiAqIH1cbiAqIGBgYFxuICovXG5jb25zdCBGaWVsZEFycmF5ID0gKHByb3BzKSA9PiBwcm9wcy5yZW5kZXIodXNlRmllbGRBcnJheShwcm9wcykpO1xuXG5jb25zdCBpc0ZpbGVMaWtlID0gKHZhbHVlKSA9PiAodHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgQmxvYikgfHxcbiAgICAodHlwZW9mIEZpbGUgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgRmlsZSk7XG5jb25zdCBpc0ZpbGVMaXN0TGlrZSA9ICh2YWx1ZSkgPT4gdHlwZW9mIEZpbGVMaXN0ICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGVMaXN0O1xuY29uc3QgZmxhdHRlbiA9IChvYmopID0+IHtcbiAgICBjb25zdCBvdXRwdXQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhvYmopKSB7XG4gICAgICAgIGlmIChpc09iamVjdFR5cGUob2JqW2tleV0pICYmXG4gICAgICAgICAgICBvYmpba2V5XSAhPT0gbnVsbCAmJlxuICAgICAgICAgICAgIWlzRGF0ZU9iamVjdChvYmpba2V5XSkgJiZcbiAgICAgICAgICAgICFpc0ZpbGVMaWtlKG9ialtrZXldKSAmJlxuICAgICAgICAgICAgIWlzRmlsZUxpc3RMaWtlKG9ialtrZXldKSkge1xuICAgICAgICAgICAgY29uc3QgbmVzdGVkID0gZmxhdHRlbihvYmpba2V5XSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5lc3RlZEtleSBvZiBPYmplY3Qua2V5cyhuZXN0ZWQpKSB7XG4gICAgICAgICAgICAgICAgb3V0cHV0W2Ake2tleX0uJHtuZXN0ZWRLZXl9YF0gPSBuZXN0ZWRbbmVzdGVkS2V5XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG91dHB1dFtrZXldID0gb2JqW2tleV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbn07XG5cbmZ1bmN0aW9uIGpzb25Ub0Zvcm1EYXRhKGpzb24pIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgRm9ybURhdGEoKTtcbiAgICBjb25zdCBmbGF0dGVuRm9ybVZhbHVlcyA9IGZsYXR0ZW4oanNvbik7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZmxhdHRlbkZvcm1WYWx1ZXMpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBmbGF0dGVuRm9ybVZhbHVlc1trZXldO1xuICAgICAgICBpZiAoaXNVbmRlZmluZWQodmFsdWUpKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIEZpbGVMaXN0ICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGVMaXN0KSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgdmFsdWUubGVuZ3RoOyBpbmRleCsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmlsZSA9IHZhbHVlW2luZGV4XTtcbiAgICAgICAgICAgICAgICBmaWxlICYmIHJlc3VsdC5hcHBlbmQoa2V5LCBmaWxlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdC5hcHBlbmQoa2V5LCB2YWx1ZSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIHNhZmVKU09OU3RyaW5naWZ5KHZhbHVlKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHZhbHVlKTtcbiAgICB9XG4gICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG59XG5cbmZ1bmN0aW9uIG5vb3AoKSB7IH1cblxuY29uc3QgUE9TVF9SRVFVRVNUID0gJ3Bvc3QnO1xuZnVuY3Rpb24gZGVmYXVsdFZhbGlkYXRlU3RhdHVzKHN0YXR1cykge1xuICAgIHJldHVybiBzdGF0dXMgPj0gMjAwICYmIHN0YXR1cyA8IDMwMDtcbn1cbi8qKlxuICogRm9ybSBjb21wb25lbnQgdGhhdCBoYW5kbGVzIHN1Ym1pc3Npb24sIGluY2x1ZGluZyBvcHRpb25hbCBgYWN0aW9uYCBmZXRjaCBhbmQgc2VydmVyIGVycm9yIHdpcmluZy5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm0vZm9ybSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiA8Rm9ybSBhY3Rpb249XCIvYXBpXCIgY29udHJvbD17Y29udHJvbH0+XG4gKiAgIDxpbnB1dCB7Li4ucmVnaXN0ZXIoXCJuYW1lXCIpfSAvPlxuICogICA8cD57ZXJyb3JzPy5yb290Py5zZXJ2ZXIgJiYgJ1NlcnZlciBlcnJvcid9PC9wPlxuICogICA8YnV0dG9uPlN1Ym1pdDwvYnV0dG9uPlxuICogPC9Gb3JtPlxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIEZvcm0ocHJvcHMpIHtcbiAgICBjb25zdCBmb3JtQ29udHJvbCA9IHVzZUZvcm1Db250cm9sQ29udGV4dCgpO1xuICAgIGNvbnN0IFttb3VudGVkLCBzZXRNb3VudGVkXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCB7IGNvbnRyb2wgPSBmb3JtQ29udHJvbCwgb25TdWJtaXQgPSBub29wLCBjaGlsZHJlbiwgYWN0aW9uLCBtZXRob2QgPSBQT1NUX1JFUVVFU1QsIGhlYWRlcnMsIGVuY1R5cGUsIG9uRXJyb3IgPSBub29wLCByZW5kZXIsIG9uU3VjY2VzcyA9IG5vb3AsIHZhbGlkYXRlU3RhdHVzID0gZGVmYXVsdFZhbGlkYXRlU3RhdHVzLCAuLi5yZXN0IH0gPSBwcm9wcztcbiAgICBjb25zdCBoYW5kbGVTdWJtaXQgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICAgICAgcmV0dXJuIGNvbnRyb2wuaGFuZGxlU3VibWl0KGFzeW5jIChkYXRhLCBldmVudCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZm9ybURhdGEgPSBqc29uVG9Gb3JtRGF0YShkYXRhKTtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1EYXRhSnNvbiA9IHNhZmVKU09OU3RyaW5naWZ5KGRhdGEpO1xuICAgICAgICAgICAgaWYgKG9uU3VibWl0KSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgb25TdWJtaXQoe1xuICAgICAgICAgICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgICAgICAgbWV0aG9kLFxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YSxcbiAgICAgICAgICAgICAgICAgICAgZm9ybURhdGFKc29uLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzU3RyaW5nKGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBoYXNDb250ZW50VHlwZSA9ICh0eXBlKSA9PiAoaGVhZGVycyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmVudHJpZXMoaGVhZGVycykuc29tZSgoW25hbWUsIHZhbHVlXSkgPT4gbmFtZS50b0xvd2VyQ2FzZSgpID09PSAnY29udGVudC10eXBlJyAmJiB0eXBlLnRlc3QodmFsdWUpKSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIChlbmNUeXBlICYmIHR5cGUudGVzdChlbmNUeXBlKSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBib2R5ID0gZm9ybURhdGE7XG4gICAgICAgICAgICAgICAgICAgIGlmIChoYXNDb250ZW50VHlwZSgvanNvbi9pKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9keSA9IGZvcm1EYXRhSnNvbjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChoYXNDb250ZW50VHlwZSgvXlxccyphcHBsaWNhdGlvblxcL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFxccyooO3wkKS9pKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9keSA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoQXJyYXkuZnJvbShmb3JtRGF0YSwgKFtuYW1lLCB2YWx1ZV0pID0+IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU3RyaW5nKHZhbHVlKSA/IHZhbHVlIDogdmFsdWUubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0pKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChoYXNDb250ZW50VHlwZSgvXlxccyp0ZXh0XFwvcGxhaW5cXHMqKDt8JCkvaSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHkgPSBBcnJheS5mcm9tKGZvcm1EYXRhLCAoW25hbWUsIHZhbHVlXSkgPT4gYCR7bmFtZX09JHtpc1N0cmluZyh2YWx1ZSkgPyB2YWx1ZSA6IHZhbHVlLm5hbWV9XFxyXFxuYCkuam9pbignJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNNdWx0aXBhcnQgPSAodmFsdWUpID0+IC9eXFxzKm11bHRpcGFydFxcL2Zvcm0tZGF0YVxccyooO3wkKS9pLnRlc3QodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGFjdGlvbiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kLFxuICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLk9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhoZWFkZXJzIHx8IHt9KS5maWx0ZXIoKFtuYW1lLCB2YWx1ZV0pID0+IG5hbWUudG9Mb3dlckNhc2UoKSAhPT0gJ2NvbnRlbnQtdHlwZScgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWlzTXVsdGlwYXJ0KHZhbHVlKSkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihlbmNUeXBlICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFpc011bHRpcGFydChlbmNUeXBlKSAmJiB7ICdDb250ZW50LVR5cGUnOiBlbmNUeXBlIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UgJiYgIXZhbGlkYXRlU3RhdHVzKHJlc3BvbnNlLnN0YXR1cykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHR5cGU6IFN0cmluZyhyZXNwb25zZS5zdGF0dXMpIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvblN1Y2Nlc3MoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcih7IGVycm9yIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB0eXBlOiAnJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0Z1bmN0aW9uKGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhY3Rpb24oZm9ybURhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcih7IGVycm9yIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB0eXBlOiAnJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFJldHVybiBub3RoaW5nIHdoZW4gc3VjY2Vzc2Z1bC5cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSk7XG4gICAgfSwgW1xuICAgICAgICBjb250cm9sLFxuICAgICAgICBvblN1Ym1pdCxcbiAgICAgICAgbWV0aG9kLFxuICAgICAgICBhY3Rpb24sXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGVuY1R5cGUsXG4gICAgICAgIHZhbGlkYXRlU3RhdHVzLFxuICAgICAgICBvbkVycm9yLFxuICAgICAgICBvblN1Y2Nlc3MsXG4gICAgXSk7XG4gICAgY29uc3Qgc3VibWl0ID0gUmVhY3QudXNlQ2FsbGJhY2soYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGVyciA9IGF3YWl0IGhhbmRsZVN1Ym1pdChldmVudCk7XG4gICAgICAgIGlmIChlcnIgJiYgY29udHJvbCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7IGlzU3VibWl0U3VjY2Vzc2Z1bDogZmFsc2UgfSk7XG4gICAgICAgICAgICBjb250cm9sLnNldEVycm9yKCdyb290LnNlcnZlcicsIGVycik7XG4gICAgICAgIH1cbiAgICB9LCBbaGFuZGxlU3VibWl0LCBjb250cm9sXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgc2V0TW91bnRlZCh0cnVlKTtcbiAgICB9LCBbXSk7XG4gICAgaWYgKHJlbmRlcikge1xuICAgICAgICByZXR1cm4gcmVuZGVyKHsgc3VibWl0IH0pO1xuICAgIH1cbiAgICAvLyBSZWFjdCBmb3JiaWRzIHBhc3NpbmcgYG1ldGhvZGAvYGVuY1R5cGVgIGFsb25nc2lkZSBhIGZ1bmN0aW9uIGBhY3Rpb25gXG4gICAgLy8gKGEgU2VydmVyLUFjdGlvbi1zdHlsZSBzdWJtaXNzaW9uKSAtLSBpdCBtYW5hZ2VzIHRob3NlIGl0c2VsZiBhbmQgd2FybnNcbiAgICAvLyBpZiB0aGV5J3JlIHByZXNlbnQsIHNvIHRoZXkncmUgb25seSByZW5kZXJlZCBmb3Igc3RyaW5nL1VSTCBhY3Rpb25zLlxuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChcImZvcm1cIiwgeyBub1ZhbGlkYXRlOiBtb3VudGVkLCBhY3Rpb246IGFjdGlvbiwgLi4uKCFpc0Z1bmN0aW9uKGFjdGlvbikgJiYgeyBtZXRob2QsIGVuY1R5cGUgfSksIG9uU3VibWl0OiBzdWJtaXQsIC4uLnJlc3QgfSwgY2hpbGRyZW4pKTtcbn1cblxuY29uc3QgRm9ybVN0YXRlID0gKHsgY29udHJvbCwgZGlzYWJsZWQsIGV4YWN0LCBuYW1lLCByZW5kZXIsIH0pID0+IHJlbmRlcih1c2VGb3JtU3RhdGUoeyBjb250cm9sLCBuYW1lLCBkaXNhYmxlZCwgZXhhY3QgfSkpO1xuLyoqIEBkZXByZWNhdGVkIFVzZSBgRm9ybVN0YXRlYCBpbnN0ZWFkLiBLZXB0IGFzIGFuIGFsaWFzIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LiAqL1xuY29uc3QgRm9ybVN0YXRlU3Vic2NyaWJlID0gRm9ybVN0YXRlO1xuXG52YXIgY3JlYXRlU3ViamVjdCA9ICgpID0+IHtcbiAgICBsZXQgX29ic2VydmVycyA9IG5ldyBTZXQoKTtcbiAgICBsZXQgX2l0ZXJhdGlvbkNvdW50ID0gMDtcbiAgICBjb25zdCBuZXh0ID0gKHZhbHVlKSA9PiB7XG4gICAgICAgIGNvbnN0IG9ic2VydmVycyA9IF9vYnNlcnZlcnM7XG4gICAgICAgIF9pdGVyYXRpb25Db3VudCsrO1xuICAgICAgICBmb3IgKGNvbnN0IG9ic2VydmVyIG9mIG9ic2VydmVycykge1xuICAgICAgICAgICAgb2JzZXJ2ZXIubmV4dCAmJiBvYnNlcnZlci5uZXh0KHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBvYnNlcnZlcnMgPT09IF9vYnNlcnZlcnMgJiYgX2l0ZXJhdGlvbkNvdW50LS07XG4gICAgfTtcbiAgICBjb25zdCBzdWJzY3JpYmUgPSAob2JzZXJ2ZXIpID0+IHtcbiAgICAgICAgX29ic2VydmVycy5hZGQob2JzZXJ2ZXIpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoX2l0ZXJhdGlvbkNvdW50KSB7XG4gICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlcnMgPSBuZXcgU2V0KF9vYnNlcnZlcnMpO1xuICAgICAgICAgICAgICAgICAgICBfaXRlcmF0aW9uQ291bnQgPSAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBfb2JzZXJ2ZXJzLmRlbGV0ZShvYnNlcnZlcik7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSAoKSA9PiB7XG4gICAgICAgIF9vYnNlcnZlcnMgPSBuZXcgU2V0KCk7XG4gICAgICAgIF9pdGVyYXRpb25Db3VudCA9IDA7XG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgICBnZXQgb2JzZXJ2ZXJzKCkge1xuICAgICAgICAgICAgcmV0dXJuIEFycmF5LmZyb20oX29ic2VydmVycyk7XG4gICAgICAgIH0sXG4gICAgICAgIG5leHQsXG4gICAgICAgIHN1YnNjcmliZSxcbiAgICAgICAgdW5zdWJzY3JpYmUsXG4gICAgfTtcbn07XG5cbmZ1bmN0aW9uIGV4dHJhY3RGb3JtVmFsdWVzKGZpZWxkc1N0YXRlLCBmb3JtVmFsdWVzKSB7XG4gICAgY29uc3QgdmFsdWVzID0gKEFycmF5LmlzQXJyYXkoZmllbGRzU3RhdGUpID8gW10gOiB7fSk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZmllbGRzU3RhdGUpIHtcbiAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChmaWVsZHNTdGF0ZSwga2V5KSkge1xuICAgICAgICAgICAgY29uc3QgZmllbGRTdGF0ZSA9IGZpZWxkc1N0YXRlW2tleV07XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gZm9ybVZhbHVlc1trZXldO1xuICAgICAgICAgICAgaWYgKGZpZWxkU3RhdGUgJiZcbiAgICAgICAgICAgICAgICAoaXNPYmplY3QoZmllbGRTdGF0ZSkgfHwgQXJyYXkuaXNBcnJheShmaWVsZFN0YXRlKSkgJiZcbiAgICAgICAgICAgICAgICBmaWVsZFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdmFsdWVzW2tleV0gPSBleHRyYWN0Rm9ybVZhbHVlcyhmaWVsZFN0YXRlLCBmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGZpZWxkc1N0YXRlW2tleV0pIHtcbiAgICAgICAgICAgICAgICB2YWx1ZXNba2V5XSA9IGZpZWxkVmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlcztcbn1cblxuY29uc3QgaGFzT3duID0gKHZhbHVlLCBrZXkpID0+IHZhbHVlICE9PSBudWxsICYmXG4gICAgaXNPYmplY3RUeXBlKHZhbHVlKSAmJlxuICAgIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwga2V5KTtcbnZhciBoYXMgPSAob2JqZWN0LCBwYXRoKSA9PiB7XG4gICAgaWYgKCFwYXRoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgbGV0IHJlc3VsdCA9IG9iamVjdDtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBpc0tleShwYXRoKSA/IFtwYXRoXSA6IHN0cmluZ1RvUGF0aChwYXRoKSkge1xuICAgICAgICBpZiAoIWhhc093bihyZXN1bHQsIGtleSkpIHtcbiAgICAgICAgICAgIC8vIGBnZXRgIGFsc28gcmVzb2x2ZXMgYSBwYXRoIGhlbGQgYXMgYSBzaW5nbGUgbGl0ZXJhbCBrZXksIGVnIGB7ICdhLmInOiAxIH1gXG4gICAgICAgICAgICByZXR1cm4gaGFzT3duKG9iamVjdCwgcGF0aCk7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0ID0gcmVzdWx0W2tleV07XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufTtcblxudmFyIGlzTXVsdGlwbGVTZWxlY3QgPSAoZWxlbWVudCkgPT4gZWxlbWVudC50eXBlID09PSBgc2VsZWN0LW11bHRpcGxlYDtcblxuY29uc3QgaXNTZWxlY3RFZGl0ZWQgPSAoc2VsZWN0KSA9PiB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IFsuLi5zZWxlY3Qub3B0aW9uc107XG4gICAgcmV0dXJuICFzZWxlY3QubXVsdGlwbGUgJiZcbiAgICAgICAgc2VsZWN0LnNpemUgPCAyICYmXG4gICAgICAgICFvcHRpb25zLnNvbWUoKG9wdGlvbikgPT4gb3B0aW9uLmRlZmF1bHRTZWxlY3RlZClcbiAgICAgICAgPyBzZWxlY3Quc2VsZWN0ZWRJbmRleCAhPT0gb3B0aW9ucy5maW5kSW5kZXgoKG9wdGlvbikgPT4gIW9wdGlvbi5kaXNhYmxlZClcbiAgICAgICAgOiBvcHRpb25zLnNvbWUoKG9wdGlvbikgPT4gb3B0aW9uLnNlbGVjdGVkICE9PSBvcHRpb24uZGVmYXVsdFNlbGVjdGVkKTtcbn07XG52YXIgaXNFZGl0ZWQgPSAocmVmKSA9PiBpc0NoZWNrQm94SW5wdXQocmVmKVxuICAgID8gcmVmLmNoZWNrZWQgIT09IHJlZi5kZWZhdWx0Q2hlY2tlZFxuICAgIDogcmVmLnR5cGUgPT09ICdzZWxlY3Qtb25lJyB8fCBpc011bHRpcGxlU2VsZWN0KHJlZilcbiAgICAgICAgPyBpc1NlbGVjdEVkaXRlZChyZWYpXG4gICAgICAgIDogIWlzUmFkaW9JbnB1dChyZWYpICYmXG4gICAgICAgICAgICAnZGVmYXVsdFZhbHVlJyBpbiByZWYgJiZcbiAgICAgICAgICAgIHJlZi52YWx1ZSAhPT0gcmVmLmRlZmF1bHRWYWx1ZTtcblxudmFyIGlzUmFkaW9PckNoZWNrYm94ID0gKHJlZikgPT4gaXNSYWRpb0lucHV0KHJlZikgfHwgaXNDaGVja0JveElucHV0KHJlZik7XG5cbnZhciBsaXZlID0gKHJlZikgPT4gaXNIVE1MRWxlbWVudChyZWYpICYmIHJlZi5pc0Nvbm5lY3RlZDtcblxuZnVuY3Rpb24gaXNEaXJ0eUNvbnRhaW5lcih2YWx1ZSkge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKSB8fCBpc09iamVjdCh2YWx1ZSk7XG59XG5mdW5jdGlvbiBjb2xsZWN0RGlydHlGaWVsZE5hbWVzKGRpcnR5VHJlZSwgY2FjaGVkRGlydHlGaWVsZHMsIHByZWZpeCA9ICcnLCBuYW1lcyA9IFtdKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGlydHlUcmVlKSB7XG4gICAgICAgIGNvbnN0IHBhdGggPSBwcmVmaXggPyBgJHtwcmVmaXh9LiR7a2V5fWAgOiBrZXk7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gZGlydHlUcmVlW2tleV07XG4gICAgICAgIGlmIChpc0RpcnR5Q29udGFpbmVyKHZhbHVlKSAmJlxuICAgICAgICAgICAgaXNEaXJ0eUNvbnRhaW5lcihnZXQoY2FjaGVkRGlydHlGaWVsZHMsIHBhdGgpKSkge1xuICAgICAgICAgICAgY29sbGVjdERpcnR5RmllbGROYW1lcyh2YWx1ZSwgY2FjaGVkRGlydHlGaWVsZHMsIHBhdGgsIG5hbWVzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG5hbWVzLnB1c2gocGF0aCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5hbWVzO1xufVxuXG52YXIgb2JqZWN0SGFzRnVuY3Rpb24gPSAoZGF0YSkgPT4ge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24oZGF0YVtrZXldKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufTtcblxuZnVuY3Rpb24gaXNUcmF2ZXJzYWJsZSh2YWx1ZSkge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKSB8fCAoaXNPYmplY3QodmFsdWUpICYmICFvYmplY3RIYXNGdW5jdGlvbih2YWx1ZSkpO1xufVxuZnVuY3Rpb24gaXNSZWdpc3RlcmVkTGVhZihmaWVsZFJlZikge1xuICAgIHJldHVybiAhIShmaWVsZFJlZiAmJiAnX2YnIGluIGZpZWxkUmVmKTtcbn1cbmZ1bmN0aW9uIGlzRW1wdHlEaXJ0eUNvbnRhaW5lcih2YWx1ZSkge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKVxuICAgICAgICA/ICF2YWx1ZS5zb21lKChpdGVtKSA9PiAhaXNVbmRlZmluZWQoaXRlbSkpXG4gICAgICAgIDogIU9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGg7XG59XG5mdW5jdGlvbiBjbGVhckRpcnR5RmllbGQoY29udGFpbmVyLCBrZXkpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjb250YWluZXIpKSB7XG4gICAgICAgIGNvbnRhaW5lcltrZXldID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZGVsZXRlIGNvbnRhaW5lcltrZXldO1xuICAgIH1cbn1cbmZ1bmN0aW9uIG1hcmtGaWVsZHNEaXJ0eShkYXRhLCBmaWVsZHMgPSB7fSwgZmllbGRSZWZzKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGFba2V5XTtcbiAgICAgICAgY29uc3QgZmllbGRSZWYgPSBmaWVsZFJlZnMgJiYgZmllbGRSZWZzW2tleV07XG4gICAgICAgIGlmIChpc1RyYXZlcnNhYmxlKHZhbHVlKSAmJlxuICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KHZhbHVlKSB8fCAhaXNSZWdpc3RlcmVkTGVhZihmaWVsZFJlZikpKSB7XG4gICAgICAgICAgICBmaWVsZHNba2V5XSA9IEFycmF5LmlzQXJyYXkodmFsdWUpID8gW10gOiB7fTtcbiAgICAgICAgICAgIG1hcmtGaWVsZHNEaXJ0eSh2YWx1ZSwgZmllbGRzW2tleV0sIGZpZWxkUmVmKTtcbiAgICAgICAgICAgIGlmIChpc0VtcHR5RGlydHlDb250YWluZXIoZmllbGRzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgY2xlYXJEaXJ0eUZpZWxkKGZpZWxkcywga2V5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICghaXNVbmRlZmluZWQodmFsdWUpKSB7XG4gICAgICAgICAgICBmaWVsZHNba2V5XSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZpZWxkcztcbn1cbmZ1bmN0aW9uIGdldERpcnR5RmllbGRzKGRhdGEsIGZvcm1WYWx1ZXMsIGRpcnR5RmllbGRzRnJvbVZhbHVlcywgZmllbGRSZWZzKSB7XG4gICAgaWYgKCFkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMpIHtcbiAgICAgICAgZGlydHlGaWVsZHNGcm9tVmFsdWVzID0gbWFya0ZpZWxkc0RpcnR5KGZvcm1WYWx1ZXMsIChBcnJheS5pc0FycmF5KGlzTnVsbE9yVW5kZWZpbmVkKGZvcm1WYWx1ZXMpID8gZGF0YSA6IGZvcm1WYWx1ZXMpXG4gICAgICAgICAgICA/IFtdXG4gICAgICAgICAgICA6IHt9KSwgZmllbGRSZWZzKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGFba2V5XTtcbiAgICAgICAgY29uc3QgZmllbGRSZWYgPSBmaWVsZFJlZnMgJiYgZmllbGRSZWZzW2tleV07XG4gICAgICAgIGlmIChpc1RyYXZlcnNhYmxlKHZhbHVlKSAmJlxuICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KHZhbHVlKSB8fCAhaXNSZWdpc3RlcmVkTGVhZihmaWVsZFJlZikpKSB7XG4gICAgICAgICAgICBpZiAoaXNVbmRlZmluZWQoZm9ybVZhbHVlcykgfHwgaXNQcmltaXRpdmUoZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0gPSBtYXJrRmllbGRzRGlydHkodmFsdWUsIChBcnJheS5pc0FycmF5KHZhbHVlKSA/IFtdIDoge30pLCBmaWVsZFJlZik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBnZXREaXJ0eUZpZWxkcyh2YWx1ZSwgaXNOdWxsT3JVbmRlZmluZWQoZm9ybVZhbHVlcykgPyB7fSA6IGZvcm1WYWx1ZXNba2V5XSwgZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0sIGZpZWxkUmVmKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0VtcHR5RGlydHlDb250YWluZXIoZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgY2xlYXJEaXJ0eUZpZWxkKGRpcnR5RmllbGRzRnJvbVZhbHVlcywga2V5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChkZWVwRXF1YWwodmFsdWUsIGlzTnVsbE9yVW5kZWZpbmVkKGZvcm1WYWx1ZXMpID8gdW5kZWZpbmVkIDogZm9ybVZhbHVlc1trZXldKSkge1xuICAgICAgICAgICAgY2xlYXJEaXJ0eUZpZWxkKGRpcnR5RmllbGRzRnJvbVZhbHVlcywga2V5KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZGlydHlGaWVsZHNGcm9tVmFsdWVzO1xufVxuXG52YXIgZ2V0RmllbGRBcnJheUl0ZW1OYW1lcyA9IChuYW1lcywgbmFtZSkgPT4ge1xuICAgIGNvbnN0IHNlZ21lbnRzID0gbmFtZS5zcGxpdCgnLicpO1xuICAgIGNvbnN0IG1hdGNoZXMgPSBbXTtcbiAgICBsZXQgcHJlZml4ID0gc2VnbWVudHNbMF07XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBzZWdtZW50cy5sZW5ndGg7IHByZWZpeCArPSAnLicgKyBzZWdtZW50c1tpKytdKSB7XG4gICAgICAgIGlmICghaXNOYU4oK3NlZ21lbnRzW2ldKSAmJiBuYW1lcy5oYXMocHJlZml4KSkge1xuICAgICAgICAgICAgbWF0Y2hlcy5wdXNoKGAke3ByZWZpeH0uJHtzZWdtZW50c1tpXX1gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbWF0Y2hlcztcbn07XG5cbnZhciBnZXRGaWVsZFZhbHVlQXMgPSAodmFsdWUsIHsgdmFsdWVBc051bWJlciwgdmFsdWVBc0RhdGUsIHNldFZhbHVlQXMgfSkgPT4gaXNVbmRlZmluZWQodmFsdWUpXG4gICAgPyB2YWx1ZVxuICAgIDogdmFsdWVBc051bWJlclxuICAgICAgICA/IHZhbHVlID09PSAnJ1xuICAgICAgICAgICAgPyBOYU5cbiAgICAgICAgICAgIDogdmFsdWVcbiAgICAgICAgICAgICAgICA/ICt2YWx1ZVxuICAgICAgICAgICAgICAgIDogdmFsdWVcbiAgICAgICAgOiB2YWx1ZUFzRGF0ZSAmJiBpc1N0cmluZyh2YWx1ZSlcbiAgICAgICAgICAgID8gbmV3IERhdGUodmFsdWUpXG4gICAgICAgICAgICA6IHNldFZhbHVlQXNcbiAgICAgICAgICAgICAgICA/IHNldFZhbHVlQXModmFsdWUpXG4gICAgICAgICAgICAgICAgOiB2YWx1ZTtcblxuZnVuY3Rpb24gZ2V0RmllbGRWYWx1ZShfZikge1xuICAgIGNvbnN0IHJlZiA9IF9mLnJlZjtcbiAgICBpZiAoaXNGaWxlSW5wdXQocmVmKSkge1xuICAgICAgICByZXR1cm4gcmVmLmZpbGVzO1xuICAgIH1cbiAgICBpZiAoaXNSYWRpb0lucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIGdldFJhZGlvVmFsdWUoX2YucmVmcykudmFsdWU7XG4gICAgfVxuICAgIGlmIChpc011bHRpcGxlU2VsZWN0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5yZWYuc2VsZWN0ZWRPcHRpb25zXS5tYXAoKHsgdmFsdWUgfSkgPT4gdmFsdWUpO1xuICAgIH1cbiAgICBpZiAoaXNDaGVja0JveElucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIGdldENoZWNrYm94VmFsdWUoX2YucmVmcykudmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBnZXRGaWVsZFZhbHVlQXMocmVmLnZhbHVlLCBfZik7XG59XG5cbnZhciBnZXRSZXNvbHZlck9wdGlvbnMgPSAoZmllbGRzTmFtZXMsIF9maWVsZHMsIGNyaXRlcmlhTW9kZSwgc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbikgPT4ge1xuICAgIGNvbnN0IGZpZWxkcyA9IHt9O1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBmaWVsZHNOYW1lcykge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgZmllbGQgJiYgc2V0KGZpZWxkcywgbmFtZSwgZmllbGQuX2YpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBjcml0ZXJpYU1vZGUsXG4gICAgICAgIG5hbWVzOiBbLi4uZmllbGRzTmFtZXNdLFxuICAgICAgICBmaWVsZHMsXG4gICAgICAgIHNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24sXG4gICAgfTtcbn07XG5cbnZhciBnZXRSdWxlVmFsdWUgPSAocnVsZSkgPT4gaXNVbmRlZmluZWQocnVsZSlcbiAgICA/IHJ1bGVcbiAgICA6IGlzUmVnZXgocnVsZSlcbiAgICAgICAgPyBydWxlLnNvdXJjZVxuICAgICAgICA6IGlzT2JqZWN0KHJ1bGUpXG4gICAgICAgICAgICA/IGlzUmVnZXgocnVsZS52YWx1ZSlcbiAgICAgICAgICAgICAgICA/IHJ1bGUudmFsdWUuc291cmNlXG4gICAgICAgICAgICAgICAgOiBydWxlLnZhbHVlXG4gICAgICAgICAgICA6IHJ1bGU7XG5cbmNvbnN0IEFTWU5DX0ZVTkNUSU9OID0gJ0FzeW5jRnVuY3Rpb24nO1xudmFyIGhhc1Byb21pc2VWYWxpZGF0aW9uID0gKGZpZWxkUmVmZXJlbmNlKSA9PiB7XG4gICAgaWYgKCFmaWVsZFJlZmVyZW5jZSB8fCAhZmllbGRSZWZlcmVuY2UudmFsaWRhdGUpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICBpZiAoaXNGdW5jdGlvbihmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZSkpIHtcbiAgICAgICAgcmV0dXJuIGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlLmNvbnN0cnVjdG9yLm5hbWUgPT09IEFTWU5DX0ZVTkNUSU9OO1xuICAgIH1cbiAgICBpZiAoaXNPYmplY3QoZmllbGRSZWZlcmVuY2UudmFsaWRhdGUpKSB7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IGluIGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlKSB7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UudmFsaWRhdGVba2V5XS5jb25zdHJ1Y3Rvci5uYW1lID09PSBBU1lOQ19GVU5DVElPTikge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbnZhciBoYXNWYWxpZGF0aW9uID0gKG9wdGlvbnMpID0+IG9wdGlvbnMubW91bnQgJiZcbiAgICAob3B0aW9ucy5yZXF1aXJlZCB8fFxuICAgICAgICAoIWlzVW5kZWZpbmVkKG9wdGlvbnMucmVxdWlyZWQpICYmIG9wdGlvbnMucmVxdWlyZWQgIT09IGZhbHNlKSB8fFxuICAgICAgICAhaXNVbmRlZmluZWQob3B0aW9ucy5taW4pIHx8XG4gICAgICAgICFpc1VuZGVmaW5lZChvcHRpb25zLm1heCkgfHxcbiAgICAgICAgIWlzVW5kZWZpbmVkKG9wdGlvbnMubWF4TGVuZ3RoKSB8fFxuICAgICAgICAhaXNVbmRlZmluZWQob3B0aW9ucy5taW5MZW5ndGgpIHx8XG4gICAgICAgIG9wdGlvbnMucGF0dGVybiB8fFxuICAgICAgICBvcHRpb25zLnZhbGlkYXRlKTtcblxuZnVuY3Rpb24gc2NoZW1hRXJyb3JMb29rdXAoZXJyb3JzLCBfZmllbGRzLCBuYW1lKSB7XG4gICAgY29uc3QgZXJyb3IgPSBnZXQoZXJyb3JzLCBuYW1lKTtcbiAgICBpZiAoKGVycm9yICYmIChlcnJvci50eXBlIHx8IGVycm9yLm1lc3NhZ2UpKSB8fCBBcnJheS5pc0FycmF5KGVycm9yKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBuYW1lcyA9IG5hbWUuc3BsaXQoJy4nKTtcbiAgICB3aGlsZSAobmFtZXMubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IG5hbWVzLmpvaW4oJy4nKTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgY29uc3QgZm91bmRFcnJvciA9IGdldChlcnJvcnMsIGZpZWxkTmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiAhQXJyYXkuaXNBcnJheShmaWVsZCkgJiYgbmFtZSAhPT0gZmllbGROYW1lKSB7XG4gICAgICAgICAgICByZXR1cm4geyBuYW1lIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvdW5kRXJyb3IgJiYgZm91bmRFcnJvci50eXBlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGZpZWxkTmFtZSxcbiAgICAgICAgICAgICAgICBlcnJvcjogZm91bmRFcnJvcixcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvdW5kRXJyb3IgJiYgZm91bmRFcnJvci5yb290ICYmIGZvdW5kRXJyb3Iucm9vdC50eXBlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGAke2ZpZWxkTmFtZX0ucm9vdGAsXG4gICAgICAgICAgICAgICAgZXJyb3I6IGZvdW5kRXJyb3Iucm9vdCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgbmFtZXMucG9wKCk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWUsXG4gICAgfTtcbn1cblxudmFyIHNob3VsZFJlbmRlckZvcm1TdGF0ZSA9IChmb3JtU3RhdGVEYXRhLCBfcHJveHlGb3JtU3RhdGUsIGlzUm9vdCkgPT4ge1xuICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhmb3JtU3RhdGVEYXRhKS5maWx0ZXIoKGtleSkgPT4ga2V5ICE9PSAnbmFtZScpO1xuICAgIHJldHVybiAoIWtleXMubGVuZ3RoIHx8XG4gICAgICAgIChpc1Jvb3QgJiYga2V5cy5sZW5ndGggPj0gT2JqZWN0LmtleXMoX3Byb3h5Rm9ybVN0YXRlKS5sZW5ndGgpIHx8XG4gICAgICAgIGtleXMuZmluZCgoa2V5KSA9PiBfcHJveHlGb3JtU3RhdGVba2V5XSA9PT1cbiAgICAgICAgICAgICghaXNSb290IHx8IFZBTElEQVRJT05fTU9ERS5hbGwpKSk7XG59O1xuXG5jb25zdCBpc05hbWVNYXRjaCA9IChjdXJyZW50TmFtZSwgc2lnbmFsTmFtZSwgZXhhY3QpID0+IGV4YWN0XG4gICAgPyBjdXJyZW50TmFtZSA9PT0gc2lnbmFsTmFtZSB8fCBjdXJyZW50TmFtZS5zdGFydHNXaXRoKHNpZ25hbE5hbWUgKyAnLicpXG4gICAgOiBjdXJyZW50TmFtZS5zdGFydHNXaXRoKHNpZ25hbE5hbWUpIHx8IHNpZ25hbE5hbWUuc3RhcnRzV2l0aChjdXJyZW50TmFtZSk7XG52YXIgc2hvdWxkU3Vic2NyaWJlQnlOYW1lID0gKG5hbWUsIHNpZ25hbE5hbWUsIGV4YWN0KSA9PiB7XG4gICAgaWYgKCFuYW1lIHx8ICFzaWduYWxOYW1lIHx8IG5hbWUgPT09IHNpZ25hbE5hbWUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmICghQXJyYXkuaXNBcnJheShuYW1lKSkge1xuICAgICAgICByZXR1cm4gaXNOYW1lTWF0Y2gobmFtZSwgc2lnbmFsTmFtZSwgZXhhY3QpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGN1cnJlbnROYW1lIG9mIG5hbWUpIHtcbiAgICAgICAgaWYgKGN1cnJlbnROYW1lICYmIGlzTmFtZU1hdGNoKGN1cnJlbnROYW1lLCBzaWduYWxOYW1lLCBleGFjdCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbnZhciBza2lwVmFsaWRhdGlvbiA9IChpc0JsdXJFdmVudCwgaXNUb3VjaGVkLCBpc1N1Ym1pdHRlZCwgcmVWYWxpZGF0ZU1vZGUsIG1vZGUpID0+IHtcbiAgICBpZiAobW9kZS5pc09uQWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZWxzZSBpZiAoIWlzU3VibWl0dGVkICYmIG1vZGUuaXNPblRvdWNoKSB7XG4gICAgICAgIHJldHVybiAhKGlzVG91Y2hlZCB8fCBpc0JsdXJFdmVudCk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzU3VibWl0dGVkID8gcmVWYWxpZGF0ZU1vZGUuaXNPbkJsdXIgOiBtb2RlLmlzT25CbHVyKSB7XG4gICAgICAgIHJldHVybiAhaXNCbHVyRXZlbnQ7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzU3VibWl0dGVkID8gcmVWYWxpZGF0ZU1vZGUuaXNPbkNoYW5nZSA6IG1vZGUuaXNPbkNoYW5nZSkge1xuICAgICAgICByZXR1cm4gaXNCbHVyRXZlbnQ7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufTtcblxudmFyIHVuc2V0RW1wdHlBcnJheSA9IChyZWYsIG5hbWUpID0+IHtcbiAgICBjb25zdCBhcnJheSA9IGdldChyZWYsIG5hbWUpO1xuICAgICFjb21wYWN0KGFycmF5KS5sZW5ndGggJiZcbiAgICAgICAgIShhcnJheSAmJiBhcnJheS5yb290KSAmJlxuICAgICAgICB1bnNldChyZWYsIG5hbWUpO1xufTtcblxuY29uc3QgZGVmYXVsdE9wdGlvbnMgPSB7XG4gICAgbW9kZTogVkFMSURBVElPTl9NT0RFLm9uU3VibWl0LFxuICAgIHJlVmFsaWRhdGVNb2RlOiBWQUxJREFUSU9OX01PREUub25DaGFuZ2UsXG4gICAgc2hvdWxkRm9jdXNFcnJvcjogdHJ1ZSxcbn07XG5jb25zdCByZXBsYWNlRGlydHlGaWVsZHNJblBsYWNlID0gKGRpcnR5RmllbGRzLCBuZXh0RGlydHlGaWVsZHMpID0+IHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkaXJ0eUZpZWxkcykge1xuICAgICAgICBkZWxldGUgZGlydHlGaWVsZHNba2V5XTtcbiAgICB9XG4gICAgT2JqZWN0LmFzc2lnbihkaXJ0eUZpZWxkcywgbmV4dERpcnR5RmllbGRzKTtcbn07XG5jb25zdCBERUZBVUxUX0ZPUk1fU1RBVEUgPSB7XG4gICAgc3VibWl0Q291bnQ6IDAsXG4gICAgaXNEaXJ0eTogZmFsc2UsXG4gICAgaXNSZWFkeTogZmFsc2UsXG4gICAgaXNWYWxpZGF0aW5nOiBmYWxzZSxcbiAgICBpc1N1Ym1pdHRlZDogZmFsc2UsXG4gICAgaXNTdWJtaXR0aW5nOiBmYWxzZSxcbiAgICBpc1N1Ym1pdFN1Y2Nlc3NmdWw6IGZhbHNlLFxuICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgIHRvdWNoZWRGaWVsZHM6IHt9LFxuICAgIGRpcnR5RmllbGRzOiB7fSxcbiAgICB2YWxpZGF0aW5nRmllbGRzOiB7fSxcbn07XG5mdW5jdGlvbiBjcmVhdGVGb3JtQ29udHJvbChwcm9wcyA9IHt9KSB7XG4gICAgbGV0IF9vcHRpb25zID0ge1xuICAgICAgICAuLi5kZWZhdWx0T3B0aW9ucyxcbiAgICAgICAgLi4ucHJvcHMsXG4gICAgfTtcbiAgICBsZXQgX2Zvcm1TdGF0ZSA9IHtcbiAgICAgICAgLi4uY2xvbmVPYmplY3QoREVGQVVMVF9GT1JNX1NUQVRFKSxcbiAgICAgICAgaXNMb2FkaW5nOiBpc0Z1bmN0aW9uKF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpLFxuICAgICAgICBlcnJvcnM6IGNsb25lT2JqZWN0KF9vcHRpb25zLmVycm9ycykgfHwge30sXG4gICAgICAgIGRpc2FibGVkOiBfb3B0aW9ucy5kaXNhYmxlZCB8fCBmYWxzZSxcbiAgICB9O1xuICAgIGxldCBfZmllbGRzID0ge307XG4gICAgbGV0IF9kZWZhdWx0VmFsdWVzID0gaXNPYmplY3QoX29wdGlvbnMuZGVmYXVsdFZhbHVlcykgfHwgaXNPYmplY3QoX29wdGlvbnMudmFsdWVzKVxuICAgICAgICA/IGNsb25lT2JqZWN0KF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMgfHwgX29wdGlvbnMudmFsdWVzKSB8fCB7fVxuICAgICAgICA6IHt9O1xuICAgIGxldCBfZm9ybVZhbHVlcyA9IF9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXJcbiAgICAgICAgPyB7fVxuICAgICAgICA6IGNsb25lT2JqZWN0KF9kZWZhdWx0VmFsdWVzKTtcbiAgICBsZXQgX3N0YXRlID0ge1xuICAgICAgICBhY3Rpb246IGZhbHNlLFxuICAgICAgICBhY3Rpb25BcnJheUxlbmd0aHM6IG5ldyBNYXAoKSxcbiAgICAgICAgbW91bnQ6IGZhbHNlLFxuICAgICAgICB3YXRjaDogZmFsc2UsXG4gICAgICAgIGtlZXBJc1ZhbGlkOiBmYWxzZSxcbiAgICB9O1xuICAgIGxldCBfZGlydHlGaWVsZHNTdGFsZSA9IGZhbHNlO1xuICAgIGxldCBfbmFtZXMgPSB7XG4gICAgICAgIG1vdW50OiBuZXcgU2V0KCksXG4gICAgICAgIGRpc2FibGVkOiBuZXcgU2V0KCksXG4gICAgICAgIHVuTW91bnQ6IG5ldyBTZXQoKSxcbiAgICAgICAgYXJyYXk6IG5ldyBTZXQoKSxcbiAgICAgICAgd2F0Y2g6IG5ldyBTZXQoKSxcbiAgICAgICAgcmVnaXN0ZXJOYW1lOiBuZXcgU2V0KCksXG4gICAgfTtcbiAgICBjb25zdCBkZWxheUVycm9yQ2FsbGJhY2tzID0ge307XG4gICAgY29uc3QgdGltZXJzID0ge307XG4gICAgY29uc3QgX3ZhbHVlc1N1YnNjcmliZXJzID0gbmV3IFNldCgpO1xuICAgIGxldCBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMubW9kZSk7XG4gICAgbGV0IF92YWxpZGF0aW9uTW9kZUFmdGVyU3VibWl0ID0gZ2V0VmFsaWRhdGlvbk1vZGVzKF9vcHRpb25zLnJlVmFsaWRhdGVNb2RlKTtcbiAgICBjb25zdCBkZWZhdWx0UHJveHlGb3JtU3RhdGUgPSB7XG4gICAgICAgIGlzRGlydHk6IGZhbHNlLFxuICAgICAgICBkaXJ0eUZpZWxkczogZmFsc2UsXG4gICAgICAgIHZhbGlkYXRpbmdGaWVsZHM6IGZhbHNlLFxuICAgICAgICB0b3VjaGVkRmllbGRzOiBmYWxzZSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiBmYWxzZSxcbiAgICAgICAgaXNWYWxpZDogZmFsc2UsXG4gICAgICAgIGVycm9yczogZmFsc2UsXG4gICAgfTtcbiAgICBjb25zdCBfcHJveHlGb3JtU3RhdGUgPSB7XG4gICAgICAgIC4uLmRlZmF1bHRQcm94eUZvcm1TdGF0ZSxcbiAgICB9O1xuICAgIGNvbnN0IF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZSA9IHt9O1xuICAgIGNvbnN0IF9pc1RyYWNrZWQgPSAoLi4ua2V5cykgPT4ga2V5cy5zb21lKChrZXkpID0+IF9wcm94eUZvcm1TdGF0ZVtrZXldIHx8IF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZVtrZXldKTtcbiAgICBjb25zdCBfaGFzVmFsdWVzU3Vic2NyaWJlciA9IChuYW1lKSA9PiB7XG4gICAgICAgIGZvciAoY29uc3Qgc3Vic2NyaWJlciBvZiBfdmFsdWVzU3Vic2NyaWJlcnMpIHtcbiAgICAgICAgICAgIGlmIChzaG91bGRTdWJzY3JpYmVCeU5hbWUoc3Vic2NyaWJlci5uYW1lLCBuYW1lLCBzdWJzY3JpYmVyLmV4YWN0KSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9O1xuICAgIGNvbnN0IF9zdWJqZWN0cyA9IHtcbiAgICAgICAgYXJyYXk6IGNyZWF0ZVN1YmplY3QoKSxcbiAgICAgICAgc3RhdGU6IGNyZWF0ZVN1YmplY3QoKSxcbiAgICB9O1xuICAgIGxldCBfc2V0VmFsaWRDYWxsSWQgPSAwO1xuICAgIGxldCBfcmVzZXRDYWxsSWQgPSAwO1xuICAgIGxldCBfcmVnaXN0ZXJDYWxsSWQgPSAwO1xuICAgIGNvbnN0IF9yZWdpc3RlckNhbGxJZHMgPSB7fTtcbiAgICBsZXQgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMgPSBfb3B0aW9ucy5jcml0ZXJpYU1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5hbGw7XG4gICAgY29uc3QgZGVib3VuY2UgPSAobmFtZSwgY2FsbGJhY2spID0+ICh3YWl0KSA9PiB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lcnNbbmFtZV0pO1xuICAgICAgICB0aW1lcnNbbmFtZV0gPSBzZXRUaW1lb3V0KGNhbGxiYWNrLCB3YWl0KTtcbiAgICB9O1xuICAgIGNvbnN0IGNhbmNlbERlbGF5ZWRFcnJvciA9IChuYW1lKSA9PiB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lcnNbbmFtZV0pO1xuICAgICAgICBkZWxldGUgdGltZXJzW25hbWVdO1xuICAgICAgICBkZWxldGUgZGVsYXlFcnJvckNhbGxiYWNrc1tuYW1lXTtcbiAgICB9O1xuICAgIGNvbnN0IGNhbmNlbERlbGF5ZWRFcnJvclRyZWUgPSAobmFtZSkgPT4ge1xuICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3IobmFtZSk7XG4gICAgICAgIGNvbnN0IHByZWZpeCA9IGAke25hbWV9LmA7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGRlbGF5RXJyb3JDYWxsYmFja3MpKSB7XG4gICAgICAgICAgICBrZXkuc3RhcnRzV2l0aChwcmVmaXgpICYmIGNhbmNlbERlbGF5ZWRFcnJvcihrZXkpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfc2V0VmFsaWQgPSBhc3luYyAoc2hvdWxkVXBkYXRlVmFsaWQpID0+IHtcbiAgICAgICAgaWYgKF9zdGF0ZS5rZWVwSXNWYWxpZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICghX29wdGlvbnMuZGlzYWJsZWQgJiYgKF9pc1RyYWNrZWQoJ2lzVmFsaWQnKSB8fCBzaG91bGRVcGRhdGVWYWxpZCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGNhbGxJZCA9ICsrX3NldFZhbGlkQ2FsbElkO1xuICAgICAgICAgICAgbGV0IGlzVmFsaWQ7XG4gICAgICAgICAgICBpZiAoX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgICAgICBpc1ZhbGlkID0gaXNFbXB0eU9iamVjdCgoYXdhaXQgX3J1blNjaGVtYSgpKS5lcnJvcnMpO1xuICAgICAgICAgICAgICAgIGNhbGxJZCA9PT0gX3NldFZhbGlkQ2FsbElkICYmIF91cGRhdGVJc1ZhbGlkYXRpbmcoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBmaWVsZHM6IF9maWVsZHMsXG4gICAgICAgICAgICAgICAgICAgIG9ubHlDaGVja1ZhbGlkOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBldmVudFR5cGU6IEVWRU5UUy5WQUxJRCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjYWxsSWQgPT09IF9zZXRWYWxpZENhbGxJZCAmJiBpc1ZhbGlkICE9PSBfZm9ybVN0YXRlLmlzVmFsaWQpIHtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIGlzVmFsaWQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF91cGRhdGVWYWxpZGF0aW5nRmllbGRzID0gKG5hbWVzLCBpc1ZhbGlkYXRpbmcpID0+IHtcbiAgICAgICAgY29uc3QgZmllbGROYW1lcyA9IFsuLi5uYW1lc107XG4gICAgICAgIGlmICghZmllbGROYW1lcy5zb21lKChuYW1lKSA9PiBuYW1lICYmXG4gICAgICAgICAgICAoaXNWYWxpZGF0aW5nXG4gICAgICAgICAgICAgICAgPyBnZXQoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLCBuYW1lKSAhPT0gdHJ1ZVxuICAgICAgICAgICAgICAgIDogaGFzKF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgbmFtZSkpKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpbmdGaWVsZHMgPSBjbG9uZU9iamVjdChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMpO1xuICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgZmllbGROYW1lcykge1xuICAgICAgICAgICAgaWYgKG5hbWUpIHtcbiAgICAgICAgICAgICAgICBpc1ZhbGlkYXRpbmdcbiAgICAgICAgICAgICAgICAgICAgPyBzZXQodmFsaWRhdGluZ0ZpZWxkcywgbmFtZSwgdHJ1ZSlcbiAgICAgICAgICAgICAgICAgICAgOiB1bnNldCh2YWxpZGF0aW5nRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRlZXBFcXVhbChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIHZhbGlkYXRpbmdGaWVsZHMpKSB7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMgPSB2YWxpZGF0aW5nRmllbGRzO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfdXBkYXRlSXNWYWxpZGF0aW5nID0gKG5hbWVzLCBpc1ZhbGlkYXRpbmcpID0+IHtcbiAgICAgICAgaWYgKCFfb3B0aW9ucy5kaXNhYmxlZCAmJiBfaXNUcmFja2VkKCdpc1ZhbGlkYXRpbmcnLCAndmFsaWRhdGluZ0ZpZWxkcycpKSB7XG4gICAgICAgICAgICBfdXBkYXRlVmFsaWRhdGluZ0ZpZWxkcyhuYW1lcyB8fCBfbmFtZXMubW91bnQsIGlzVmFsaWRhdGluZyk7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgdmFsaWRhdGluZ0ZpZWxkczogX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLFxuICAgICAgICAgICAgICAgIGlzVmFsaWRhdGluZzogIWlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfdXBkYXRlRGlydHlGaWVsZHMgPSAoKSA9PiB7XG4gICAgICAgIF9mb3JtU3RhdGUuZGlydHlGaWVsZHMgPSBnZXREaXJ0eUZpZWxkcyhfZGVmYXVsdFZhbHVlcywgX2Zvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgX2ZpZWxkcyk7XG4gICAgfTtcbiAgICBjb25zdCBfc2V0RmllbGRBcnJheSA9IChuYW1lLCB2YWx1ZXMgPSBbXSwgbWV0aG9kLCBhcmdzLCBzaG91bGRTZXRWYWx1ZXMgPSB0cnVlLCBzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSA9IHRydWUpID0+IHtcbiAgICAgICAgaWYgKGFyZ3MgJiYgbWV0aG9kICYmICFfb3B0aW9ucy5kaXNhYmxlZCkge1xuICAgICAgICAgICAgX3N0YXRlLmFjdGlvbiA9IHRydWU7XG4gICAgICAgICAgICBfc3RhdGUua2VlcElzVmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgY29uc3Qgcm9vdEZpZWxkID0gZmllbGQgJiYgZmllbGQuX2Y7XG4gICAgICAgICAgICBjb25zdCBmaWVsZHMgPSByb290RmllbGQgPyBPYmplY3QuYXNzaWduKFtdLCBmaWVsZCkgOiBmaWVsZDtcbiAgICAgICAgICAgIGlmICghX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5oYXMobmFtZSkpIHtcbiAgICAgICAgICAgICAgICBfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLnNldChuYW1lLCBBcnJheS5pc0FycmF5KGZpZWxkcykgPyBmaWVsZHMubGVuZ3RoIDogMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc2hvdWxkVXBkYXRlRmllbGRzQW5kU3RhdGUgJiYgQXJyYXkuaXNBcnJheShmaWVsZHMpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZXMgPSBtZXRob2QoZmllbGRzLCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQikgfHwgZmllbGRzO1xuICAgICAgICAgICAgICAgIHJvb3RGaWVsZFxuICAgICAgICAgICAgICAgICAgICA/IHNldChfZmllbGRzLCBuYW1lLCB7IC4uLmZpZWxkVmFsdWVzLCBfZjogcm9vdEZpZWxkIH0pXG4gICAgICAgICAgICAgICAgICAgIDogc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZmllbGRzLCBuYW1lLCBmaWVsZFZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZEFycmF5RXJyb3JzID0gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSAmJiBBcnJheS5pc0FycmF5KGZpZWxkQXJyYXlFcnJvcnMpKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgcm9vdEVycm9yID0gZmllbGRBcnJheUVycm9ycy5yb290O1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9ycyA9IG1ldGhvZChmaWVsZEFycmF5RXJyb3JzLCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQikgfHwgZmllbGRBcnJheUVycm9ycztcbiAgICAgICAgICAgICAgICBpZiAocm9vdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGVycm9ycy5yb290ID0gcm9vdEVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzaG91bGRTZXRWYWx1ZXMgJiYgc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcnMpO1xuICAgICAgICAgICAgICAgIHVuc2V0RW1wdHlBcnJheShfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB0b3VjaGVkRmllbGRzQXJyYXkgPSBnZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IHNob3VsZFVwZGF0ZVRvdWNoZWRGaWVsZHMgPSBzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSAmJiBBcnJheS5pc0FycmF5KHRvdWNoZWRGaWVsZHNBcnJheSk7XG4gICAgICAgICAgICBpZiAoc2hvdWxkVXBkYXRlVG91Y2hlZEZpZWxkcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRvdWNoZWRGaWVsZHMgPSBtZXRob2QodG91Y2hlZEZpZWxkc0FycmF5LCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQik7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUsIHRvdWNoZWRGaWVsZHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZGlydHlGaWVsZHNBcnJheSA9IGdldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSAmJiBBcnJheS5pc0FycmF5KGRpcnR5RmllbGRzQXJyYXkpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGlydHlGaWVsZHMgPSBtZXRob2QoZGlydHlGaWVsZHNBcnJheSwgYXJncy5hcmdBLCBhcmdzLmFyZ0IpIHx8IGRpcnR5RmllbGRzQXJyYXk7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lLCBkaXJ0eUZpZWxkcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX2lzVHJhY2tlZCgnZGlydHlGaWVsZHMnKSkge1xuICAgICAgICAgICAgICAgIF91cGRhdGVEaXJ0eUZpZWxkcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgX2RpcnR5RmllbGRzU3RhbGUgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgaXNEaXJ0eTogX2dldERpcnR5KG5hbWUsIHZhbHVlcyksXG4gICAgICAgICAgICAgICAgZGlydHlGaWVsZHM6IF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsXG4gICAgICAgICAgICAgICAgLi4uKHNob3VsZFVwZGF0ZVRvdWNoZWRGaWVsZHMgJiYge1xuICAgICAgICAgICAgICAgICAgICB0b3VjaGVkRmllbGRzOiBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsXG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICBpc1ZhbGlkOiBfZm9ybVN0YXRlLmlzVmFsaWQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgdmFsdWVzKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgdXBkYXRlRXJyb3JzID0gKG5hbWUsIGVycm9yKSA9PiB7XG4gICAgICAgIHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwgZXJyb3IpO1xuICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBfc2V0RXJyb3JzID0gKGVycm9ycykgPT4ge1xuICAgICAgICBPYmplY3Qua2V5cyhkZWxheUVycm9yQ2FsbGJhY2tzKS5mb3JFYWNoKGNhbmNlbERlbGF5ZWRFcnJvcik7XG4gICAgICAgIGNvbnN0IGhhc0Vycm9ycyA9ICFpc0VtcHR5T2JqZWN0KGVycm9ycyk7XG4gICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0gY2xvbmVPYmplY3QoZXJyb3JzKTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgIC4uLihoYXNFcnJvcnMgPyB7IGlzVmFsaWQ6IGZhbHNlIH0gOiB7fSksXG4gICAgICAgIH0pO1xuICAgICAgICAhaGFzRXJyb3JzICYmIF9zdGF0ZS5tb3VudCAmJiBfc2V0VmFsaWQoKTtcbiAgICB9O1xuICAgIGNvbnN0IHRvUGF0aCA9IChuYW1lKSA9PiBpc0tleShuYW1lKSA/IFtuYW1lXSA6IHN0cmluZ1RvUGF0aChuYW1lKTtcbiAgICBjb25zdCBoYXNFeHBsaWNpdE51bGxJbnRlcm1lZGlhdGUgPSAobmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBzZWdtZW50cyA9IHRvUGF0aChuYW1lKTtcbiAgICAgICAgbGV0IGZvcm1WYWx1ZXMgPSBfZm9ybVZhbHVlcztcbiAgICAgICAgbGV0IGRlZmF1bHRWYWx1ZXMgPSBfZGVmYXVsdFZhbHVlcztcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWdtZW50cy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGtleSA9IHNlZ21lbnRzW2ldO1xuICAgICAgICAgICAgZm9ybVZhbHVlcyA9IGlzTnVsbE9yVW5kZWZpbmVkKGZvcm1WYWx1ZXMpID8gZm9ybVZhbHVlcyA6IGZvcm1WYWx1ZXNba2V5XTtcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXMgPSBpc051bGxPclVuZGVmaW5lZChkZWZhdWx0VmFsdWVzKVxuICAgICAgICAgICAgICAgID8gZGVmYXVsdFZhbHVlc1xuICAgICAgICAgICAgICAgIDogZGVmYXVsdFZhbHVlc1trZXldO1xuICAgICAgICAgICAgaWYgKGZvcm1WYWx1ZXMgPT09IG51bGwgJiYgZGVmYXVsdFZhbHVlcyAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9O1xuICAgIGNvbnN0IGlzU3RhbGVBcnJheUZpZWxkID0gKG5hbWUpID0+IHtcbiAgICAgICAgaWYgKCFfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLnNpemUpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzZWdtZW50cyA9IHRvUGF0aChuYW1lKTtcbiAgICAgICAgbGV0IG5vZGUgPSBfZm9ybVZhbHVlcztcbiAgICAgICAgbGV0IHBhdGggPSAnJztcbiAgICAgICAgbGV0IG93bmVyRGVwdGggPSAtMTtcbiAgICAgICAgbGV0IG93bmVyUHJlQWN0aW9uTGVuZ3RoID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWdtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGlzTnVsbE9yVW5kZWZpbmVkKG5vZGUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qga2V5ID0gc2VnbWVudHNbaV07XG4gICAgICAgICAgICBwYXRoID0gcGF0aCA/IGAke3BhdGh9LiR7a2V5fWAgOiBrZXk7XG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShub2RlKSAmJiAra2V5ID49IG5vZGUubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG93bmVyRGVwdGggPT09IC0xXG4gICAgICAgICAgICAgICAgICAgID8gZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgOiBpID09PSBvd25lckRlcHRoXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICtrZXkgPCBvd25lclByZUFjdGlvbkxlbmd0aFxuICAgICAgICAgICAgICAgICAgICAgICAgOiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKF9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuaGFzKHBhdGgpKSB7XG4gICAgICAgICAgICAgICAgb3duZXJEZXB0aCA9IGkgKyAxO1xuICAgICAgICAgICAgICAgIG93bmVyUHJlQWN0aW9uTGVuZ3RoID0gX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5nZXQocGF0aCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBub2RlID0gbm9kZVtrZXldO1xuICAgICAgICAgICAgaWYgKGlzVW5kZWZpbmVkKG5vZGUpICYmXG4gICAgICAgICAgICAgICAgb3duZXJEZXB0aCAhPT0gLTEgJiZcbiAgICAgICAgICAgICAgICBpID4gb3duZXJEZXB0aCAmJlxuICAgICAgICAgICAgICAgICtzZWdtZW50c1tvd25lckRlcHRoXSA8IG93bmVyUHJlQWN0aW9uTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG4gICAgY29uc3QgaXNQYXN0QXJyYXlFbmQgPSAobmFtZSkgPT4ge1xuICAgICAgICBsZXQgbm9kZSA9IF9mb3JtVmFsdWVzO1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiB0b1BhdGgobmFtZSkpIHtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpICYmICtrZXkgPj0gbm9kZS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG5vZGUgPSBub2RlICYmIG5vZGVba2V5XTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGVWYWxpZEFuZFZhbHVlID0gKG5hbWUsIHNob3VsZFNraXBTZXRWYWx1ZUFzLCB2YWx1ZSwgcmVmKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGlmIChoYXNFeHBsaWNpdE51bGxJbnRlcm1lZGlhdGUobmFtZSkgfHwgaXNTdGFsZUFycmF5RmllbGQobmFtZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB3YXNVbnNldEluRm9ybVZhbHVlcyA9IGlzVW5kZWZpbmVkKGdldChfZm9ybVZhbHVlcywgbmFtZSkpO1xuICAgICAgICAgICAgY29uc3QgZGVmYXVsdFZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBpc1VuZGVmaW5lZCh2YWx1ZSkgPyBnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpIDogdmFsdWUpO1xuICAgICAgICAgICAgY29uc3QgaXNFZGl0ZWRCZWZvcmVSZWFkeSA9ICEhcmVmICYmICFfZm9ybVN0YXRlLmlzUmVhZHkgJiYgaXNFZGl0ZWQocmVmKTtcbiAgICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChkZWZhdWx0VmFsdWUpIHx8XG4gICAgICAgICAgICAgICAgKHJlZiAmJiByZWYuZGVmYXVsdENoZWNrZWQpIHx8XG4gICAgICAgICAgICAgICAgaXNFZGl0ZWRCZWZvcmVSZWFkeSB8fFxuICAgICAgICAgICAgICAgIHNob3VsZFNraXBTZXRWYWx1ZUFzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IHNob3VsZFNraXBTZXRWYWx1ZUFzXG4gICAgICAgICAgICAgICAgICAgID8gZGVmYXVsdFZhbHVlXG4gICAgICAgICAgICAgICAgICAgIDogZ2V0RmllbGRWYWx1ZShmaWVsZC5fZik7XG4gICAgICAgICAgICAgICAgaWYgKCFpc1VuZGVmaW5lZChmaWVsZFZhbHVlKSB8fCAhaXNQYXN0QXJyYXlFbmQobmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9pc1RyYWNrZWQoJ2RpcnR5RmllbGRzJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICFkZWVwRXF1YWwoZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKSwgZmllbGRWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9kaXJ0eUZpZWxkc1N0YWxlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGZpZWxkVmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNFZGl0ZWRCZWZvcmVSZWFkeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlVG91Y2hBbmREaXJ0eShuYW1lLCBmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNldEZpZWxkVmFsdWUobmFtZSwgZGVmYXVsdFZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChfc3RhdGUubW91bnQgJiYgIV9zdGF0ZS5hY3Rpb24pIHtcbiAgICAgICAgICAgICAgICBpZiAoX29wdGlvbnMucmVzb2x2ZXIgJiZcbiAgICAgICAgICAgICAgICAgICAgX2lzVHJhY2tlZCgnaXNWYWxpZGF0aW5nJywgJ3ZhbGlkYXRpbmdGaWVsZHMnKSkge1xuICAgICAgICAgICAgICAgICAgICBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IF9zZXRWYWxpZCgpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAod2FzVW5zZXRJbkZvcm1WYWx1ZXMgJiZcbiAgICAgICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5pc0RpcnR5ICYmXG4gICAgICAgICAgICAgICAgICAgIF9pc1RyYWNrZWQoJ2lzRGlydHknKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0RpcnR5ID0gX2dldERpcnR5KCk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaXNEaXJ0eSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5pc0RpcnR5ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IC4uLl9mb3JtU3RhdGUgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKF9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgICAgICAgICAgd2FzVW5zZXRJbkZvcm1WYWx1ZXMgJiZcbiAgICAgICAgICAgICAgICAgICAgIWlzVW5kZWZpbmVkKGdldChfZm9ybVZhbHVlcywgbmFtZSkpICYmXG4gICAgICAgICAgICAgICAgICAgIGlzV2F0Y2hlZChuYW1lLCBfbmFtZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgIF9zdGF0ZS53YXRjaCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGVUb3VjaEFuZERpcnR5ID0gKG5hbWUsIGZpZWxkVmFsdWUsIGlzQmx1ckV2ZW50LCBzaG91bGREaXJ0eSwgc2hvdWxkUmVuZGVyKSA9PiB7XG4gICAgICAgIGxldCBzaG91bGRVcGRhdGVGaWVsZCA9IGZhbHNlO1xuICAgICAgICBsZXQgaXNQcmV2aW91c0RpcnR5ID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IHtcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgIH07XG4gICAgICAgIGlmICghX29wdGlvbnMuZGlzYWJsZWQgfHwgc2hvdWxkRGlydHkgPT09IHRydWUpIHtcbiAgICAgICAgICAgIGlmICghaXNCbHVyRXZlbnQgfHwgc2hvdWxkRGlydHkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc0N1cnJlbnRGaWVsZFByaXN0aW5lID0gZGVlcEVxdWFsKGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSksIGZpZWxkVmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmIChfaXNUcmFja2VkKCdpc0RpcnR5JykpIHtcbiAgICAgICAgICAgICAgICAgICAgaXNQcmV2aW91c0RpcnR5ID0gX2Zvcm1TdGF0ZS5pc0RpcnR5O1xuICAgICAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSBvdXRwdXQuaXNEaXJ0eSA9XG4gICAgICAgICAgICAgICAgICAgICAgICAhaXNDdXJyZW50RmllbGRQcmlzdGluZSB8fCBfZ2V0RGlydHkoKTtcbiAgICAgICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgPSBpc1ByZXZpb3VzRGlydHkgIT09IG91dHB1dC5pc0RpcnR5O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRGlydHkgPSAhIWdldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNDdXJyZW50RmllbGRQcmlzdGluZSkge1xuICAgICAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRlZmF1bHRGaWVsZFZhbHVlID0gZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRpcnR5VmFsdWUgPSAhKGZpZWxkICYmIGZpZWxkLl9mKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgKGlzT2JqZWN0KGRlZmF1bHRGaWVsZFZhbHVlKSB8fCBBcnJheS5pc0FycmF5KGRlZmF1bHRGaWVsZFZhbHVlKSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gZ2V0RGlydHlGaWVsZHMoZGVmYXVsdEZpZWxkVmFsdWUsIGZpZWxkVmFsdWUsIHVuZGVmaW5lZCwgZmllbGQpXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lLCBkaXJ0eVZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IGRpZFJlc3luY0RpcnR5RmllbGRzID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgaWYgKF9kaXJ0eUZpZWxkc1N0YWxlIHx8XG4gICAgICAgICAgICAgICAgICAgIChpc0N1cnJlbnRGaWVsZFByaXN0aW5lICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAoX2lzVHJhY2tlZCgnaXNEaXJ0eScpID8gX2Zvcm1TdGF0ZS5pc0RpcnR5IDogX2dldERpcnR5KCkpKSkge1xuICAgICAgICAgICAgICAgICAgICBfZGlydHlGaWVsZHNTdGFsZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXh0RGlydHlGaWVsZHMgPSBnZXREaXJ0eUZpZWxkcyhfZGVmYXVsdFZhbHVlcywgX2Zvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgX2ZpZWxkcyk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZGVlcEVxdWFsKF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5leHREaXJ0eUZpZWxkcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpZFJlc3luY0RpcnR5RmllbGRzID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcGxhY2VEaXJ0eUZpZWxkc0luUGxhY2UoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgbmV4dERpcnR5RmllbGRzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBvdXRwdXQuZGlydHlGaWVsZHMgPSBfZm9ybVN0YXRlLmRpcnR5RmllbGRzO1xuICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkID1cbiAgICAgICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIChfaXNUcmFja2VkKCdkaXJ0eUZpZWxkcycpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRpZFJlc3luY0RpcnR5RmllbGRzIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzUHJldmlvdXNEaXJ0eSAhPT0gIWlzQ3VycmVudEZpZWxkUHJpc3RpbmUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0JsdXJFdmVudCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzUHJldmlvdXNGaWVsZFRvdWNoZWQgPSBoYXMoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKVxuICAgICAgICAgICAgICAgICAgICA/IGdldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIGlmICghaXNQcmV2aW91c0ZpZWxkVG91Y2hlZCkge1xuICAgICAgICAgICAgICAgICAgICBzZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lLCBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICAgICAgICAgIG91dHB1dC50b3VjaGVkRmllbGRzID0gX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzO1xuICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCA9XG4gICAgICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChfaXNUcmFja2VkKCd0b3VjaGVkRmllbGRzJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQcmV2aW91c0ZpZWxkVG91Y2hlZCAhPT0gaXNCbHVyRXZlbnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkICYmIHNob3VsZFJlbmRlciAmJiBfc3ViamVjdHMuc3RhdGUubmV4dChvdXRwdXQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzaG91bGRVcGRhdGVGaWVsZCA/IG91dHB1dCA6IHt9O1xuICAgIH07XG4gICAgY29uc3Qgc2hvdWxkUmVuZGVyQnlFcnJvciA9IChuYW1lLCBpc1ZhbGlkLCBlcnJvciwgZmllbGRTdGF0ZSkgPT4ge1xuICAgICAgICBjb25zdCBwcmV2aW91c0ZpZWxkRXJyb3IgPSBnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICBjb25zdCBzaG91bGRVcGRhdGVWYWxpZCA9IF9pc1RyYWNrZWQoJ2lzVmFsaWQnKSAmJlxuICAgICAgICAgICAgaXNCb29sZWFuKGlzVmFsaWQpICYmXG4gICAgICAgICAgICBfZm9ybVN0YXRlLmlzVmFsaWQgIT09IGlzVmFsaWQ7XG4gICAgICAgIGlmIChfb3B0aW9ucy5kZWxheUVycm9yICYmIGVycm9yKSB7XG4gICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdID0gZGVib3VuY2UobmFtZSwgKCkgPT4gdXBkYXRlRXJyb3JzKG5hbWUsIGVycm9yKSk7XG4gICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdKF9vcHRpb25zLmRlbGF5RXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yKG5hbWUpO1xuICAgICAgICAgICAgZXJyb3JcbiAgICAgICAgICAgICAgICA/IHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwgZXJyb3IpXG4gICAgICAgICAgICAgICAgOiB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoKGVycm9yXG4gICAgICAgICAgICA/ICFkZWVwRXF1YWwocHJldmlvdXNGaWVsZEVycm9yLCBlcnJvciwgdHJ1ZSlcbiAgICAgICAgICAgIDogcHJldmlvdXNGaWVsZEVycm9yKSB8fFxuICAgICAgICAgICAgIWlzRW1wdHlPYmplY3QoZmllbGRTdGF0ZSkgfHxcbiAgICAgICAgICAgIHNob3VsZFVwZGF0ZVZhbGlkKSB7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkRm9ybVN0YXRlID0ge1xuICAgICAgICAgICAgICAgIC4uLmZpZWxkU3RhdGUsXG4gICAgICAgICAgICAgICAgLi4uKHNob3VsZFVwZGF0ZVZhbGlkICYmIGlzQm9vbGVhbihpc1ZhbGlkKSA/IHsgaXNWYWxpZCB9IDoge30pLFxuICAgICAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh1cGRhdGVkRm9ybVN0YXRlKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3J1blNjaGVtYSA9IGFzeW5jIChuYW1lKSA9PiB7XG4gICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcobmFtZSwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiBhd2FpdCBfb3B0aW9ucy5yZXNvbHZlcihfZm9ybVZhbHVlcywgX29wdGlvbnMuY29udGV4dCwgZ2V0UmVzb2x2ZXJPcHRpb25zKG5hbWUgfHwgX25hbWVzLm1vdW50LCBfZmllbGRzLCBfb3B0aW9ucy5jcml0ZXJpYU1vZGUsIF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24pKTtcbiAgICB9O1xuICAgIGNvbnN0IGV4ZWN1dGVTY2hlbWFBbmRVcGRhdGVTdGF0ZSA9IGFzeW5jIChuYW1lcykgPT4ge1xuICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgY29uc3QgcmVnaXN0ZXJDYWxsSWQgPSBfcmVnaXN0ZXJDYWxsSWQ7XG4gICAgICAgIGNvbnN0IHJlZ2lzdGVyZWROYW1lcyA9IG5hbWVzXG4gICAgICAgICAgICA/IG5hbWVzLmZpbHRlcigobmFtZSkgPT4gZ2V0KF9maWVsZHMsIG5hbWUpKVxuICAgICAgICAgICAgOiBbXTtcbiAgICAgICAgY29uc3QgeyBlcnJvcnMgfSA9IGF3YWl0IF9ydW5TY2hlbWEobmFtZXMpO1xuICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgcmV0dXJuIGVycm9ycztcbiAgICAgICAgfVxuICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKG5hbWVzKTtcbiAgICAgICAgaWYgKG5hbWVzKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgbmFtZXMpIHtcbiAgICAgICAgICAgICAgICBpZiAocmVnaXN0ZXJlZE5hbWVzLmluY2x1ZGVzKG5hbWUpICYmXG4gICAgICAgICAgICAgICAgICAgICghZ2V0KF9maWVsZHMsIG5hbWUpIHx8IF9yZWdpc3RlckNhbGxJZHNbbmFtZV0gPiByZWdpc3RlckNhbGxJZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdW5zZXQoZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yID0gZ2V0KGVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yVHJlZShuYW1lKTtcbiAgICAgICAgICAgICAgICBjb25zdCBpc0ZpZWxkQXJyYXlSb290RXJyb3IgPSBfbmFtZXMuYXJyYXkuaGFzKG5hbWUpICYmXG4gICAgICAgICAgICAgICAgICAgIGlzT2JqZWN0KGVycm9yKSAmJlxuICAgICAgICAgICAgICAgICAgICAhT2JqZWN0LmtleXMoZXJyb3IpLnNvbWUoKGtleSkgPT4gIU51bWJlci5pc05hTihOdW1iZXIoa2V5KSkpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGhhc05lc3RlZEZpZWxkcyA9IGlzT2JqZWN0KGZpZWxkKSAmJiBPYmplY3Qua2V5cyhmaWVsZCkuc29tZSgoa2V5KSA9PiBrZXkgIT09ICdfZicpO1xuICAgICAgICAgICAgICAgIGlzRmllbGRBcnJheVJvb3RFcnJvclxuICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoX2Zvcm1TdGF0ZS5lcnJvcnMsIHsgW25hbWVdOiBlcnJvciB9LCBuYW1lKVxuICAgICAgICAgICAgICAgICAgICA6IChlcnJvciAmJiAoZXJyb3IudHlwZSB8fCBlcnJvci5tZXNzYWdlKSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIEFycmF5LmlzQXJyYXkoZXJyb3IpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAoaXNPYmplY3QoZXJyb3IpICYmIGhhc05lc3RlZEZpZWxkcylcbiAgICAgICAgICAgICAgICAgICAgICAgID8gc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcilcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBPYmplY3Qua2V5cyhkZWxheUVycm9yQ2FsbGJhY2tzKS5mb3JFYWNoKGNhbmNlbERlbGF5ZWRFcnJvcik7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IGVycm9ycztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZXJyb3JzO1xuICAgIH07XG4gICAgY29uc3QgdmFsaWRhdGVGb3JtID0gYXN5bmMgKHsgbmFtZSwgZXZlbnRUeXBlLCB9KSA9PiB7XG4gICAgICAgIGlmIChfb3B0aW9ucy52YWxpZGF0ZSkge1xuICAgICAgICAgICAgY29uc3QgcmVzZXRDYWxsSWQgPSBfcmVzZXRDYWxsSWQ7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBfb3B0aW9ucy52YWxpZGF0ZSh7XG4gICAgICAgICAgICAgICAgZm9ybVZhbHVlczogX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgZm9ybVN0YXRlOiBfZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgZXZlbnRUeXBlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzT2JqZWN0KHJlc3VsdCkpIHtcbiAgICAgICAgICAgICAgICBsZXQgaXNWYWxpZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcnMoRk9STV9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiByZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSByZXN1bHRba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcihgJHtGT1JNX0VSUk9SX1RZUEV9LiR7a2V5fWAsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBpc1N0cmluZyhlcnJvci5tZXNzYWdlKSA/IGVycm9yLm1lc3NhZ2UgOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBlcnJvci50eXBlIHx8IElOUFVUX1ZBTElEQVRJT05fUlVMRVMudmFsaWRhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gaXNWYWxpZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGlzU3RyaW5nKHJlc3VsdCkgfHwgIXJlc3VsdCkge1xuICAgICAgICAgICAgICAgIHNldEVycm9yKEZPUk1fRVJST1JfVFlQRSwge1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXN1bHQgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IElOUFVUX1ZBTElEQVRJT05fUlVMRVMudmFsaWRhdGUsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcnMoRk9STV9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9O1xuICAgIGNvbnN0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbiA9IGFzeW5jICh7IGZpZWxkcywgb25seUNoZWNrVmFsaWQsIG5hbWUsIGV2ZW50VHlwZSwgY29udGV4dCA9IHtcbiAgICAgICAgdmFsaWQ6IHRydWUsXG4gICAgICAgIHJ1blJvb3RWYWxpZGF0aW9uOiBmYWxzZSxcbiAgICB9LCB9KSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICBpZiAoX29wdGlvbnMudmFsaWRhdGUgJiYgIWNvbnRleHQucnVuUm9vdFZhbGlkYXRpb24pIHtcbiAgICAgICAgICAgIGNvbnRleHQucnVuUm9vdFZhbGlkYXRpb24gPSB0cnVlO1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdmFsaWRhdGVGb3JtKHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGV2ZW50VHlwZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKCFyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBjb250ZXh0LnZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgaWYgKG9ubHlDaGVja1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnZhbGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IG5hbWUgaW4gZmllbGRzKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGZpZWxkc1tuYW1lXTtcbiAgICAgICAgICAgIGlmIChmaWVsZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgX2YsIC4uLmZpZWxkVmFsdWUgfSA9IGZpZWxkO1xuICAgICAgICAgICAgICAgIGlmIChfZikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0ZpZWxkQXJyYXlSb290ID0gX25hbWVzLmFycmF5LmhhcyhfZi5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNQcm9taXNlRnVuY3Rpb24gPSBmaWVsZC5fZiAmJiBoYXNQcm9taXNlVmFsaWRhdGlvbihmaWVsZC5fZik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNob3VsZFRyYWNrSXNWYWxpZGF0aW5nU3RhdGUgPSBfaXNUcmFja2VkKCdpc1ZhbGlkYXRpbmcnLCAndmFsaWRhdGluZ0ZpZWxkcycpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNQcm9taXNlRnVuY3Rpb24gJiYgc2hvdWxkVHJhY2tJc1ZhbGlkYXRpbmdTdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhbX2YubmFtZV0sIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlZ2lzdGVyQ2FsbElkID0gX3JlZ2lzdGVyQ2FsbElkO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZEVycm9yID0gYXdhaXQgdmFsaWRhdGVGaWVsZChmaWVsZCwgX25hbWVzLmRpc2FibGVkLCBfZm9ybVZhbHVlcywgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMsIF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24gJiYgIW9ubHlDaGVja1ZhbGlkLCBpc0ZpZWxkQXJyYXlSb290KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnZhbGlkO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1Byb21pc2VGdW5jdGlvbiAmJiBzaG91bGRUcmFja0lzVmFsaWRhdGluZ1N0YXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtfZi5uYW1lXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFnZXQoX2ZpZWxkcywgX2YubmFtZSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9yZWdpc3RlckNhbGxJZHNbX2YubmFtZV0gPiByZWdpc3RlckNhbGxJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpZWxkRXJyb3JbX2YubmFtZV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQudmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvbmx5Q2hlY2tWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICghb25seUNoZWNrVmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbERlbGF5ZWRFcnJvcihfZi5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdldChmaWVsZEVycm9yLCBfZi5uYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gaXNGaWVsZEFycmF5Um9vdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoX2Zvcm1TdGF0ZS5lcnJvcnMsIGZpZWxkRXJyb3IsIF9mLm5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBfZi5uYW1lLCBmaWVsZEVycm9yW19mLm5hbWVdKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIF9mLm5hbWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChfb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmIGZpZWxkRXJyb3JbX2YubmFtZV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICFpc0VtcHR5T2JqZWN0KGZpZWxkVmFsdWUpICYmXG4gICAgICAgICAgICAgICAgICAgIChhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9ubHlDaGVja1ZhbGlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRzOiBmaWVsZFZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZSxcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjb250ZXh0LnZhbGlkO1xuICAgIH07XG4gICAgY29uc3QgX3JlbW92ZVVubW91bnRlZCA9ICgpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIF9uYW1lcy51bk1vdW50KSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGZpZWxkICYmXG4gICAgICAgICAgICAgICAgKGZpZWxkLl9mLnJlZnNcbiAgICAgICAgICAgICAgICAgICAgPyBmaWVsZC5fZi5yZWZzLmV2ZXJ5KChyZWYpID0+ICFsaXZlKHJlZikpXG4gICAgICAgICAgICAgICAgICAgIDogIWxpdmUoZmllbGQuX2YucmVmKSkgJiZcbiAgICAgICAgICAgICAgICB1bnJlZ2lzdGVyKG5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIF9uYW1lcy51bk1vdW50ID0gbmV3IFNldCgpO1xuICAgIH07XG4gICAgY29uc3QgX2dldERpcnR5ID0gKG5hbWUsIGRhdGEpID0+IChuYW1lICYmICFpc1VuZGVmaW5lZChkYXRhKSAmJiBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGRhdGEpLFxuICAgICAgICAhZGVlcEVxdWFsKF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMsIF9kZWZhdWx0VmFsdWVzKSk7XG4gICAgY29uc3QgX2dldFdhdGNoID0gKG5hbWVzLCBkZWZhdWx0VmFsdWUsIGlzR2xvYmFsKSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IF9zdGF0ZS5tb3VudFxuICAgICAgICAgICAgPyBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgOiBpc1VuZGVmaW5lZChkZWZhdWx0VmFsdWUpIHx8ICFpc1VuZGVmaW5lZChuYW1lcylcbiAgICAgICAgICAgICAgICA/IF9kZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgOiBkZWZhdWx0VmFsdWU7XG4gICAgICAgIHJldHVybiBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWVzLCBfbmFtZXMsIGlzVW5kZWZpbmVkKG5hbWVzKSA/IHsgLi4udmFsdWVzIH0gOiB2YWx1ZXMsIGlzR2xvYmFsLCBkZWZhdWx0VmFsdWUpO1xuICAgIH07XG4gICAgY29uc3QgX2dldEZpZWxkQXJyYXkgPSAobmFtZSkgPT4gY29tcGFjdChnZXQoX3N0YXRlLm1vdW50ID8gX2Zvcm1WYWx1ZXMgOiBfZGVmYXVsdFZhbHVlcywgbmFtZSwgX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciA/IGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSwgW10pIDogW10pKTtcbiAgICBjb25zdCBzZXRGaWVsZFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zID0ge30sIHNraXBDbG9uZSA9IGZhbHNlLCBza2lwUmVuZGVyID0gZmFsc2UsIHNraXBWYWx1ZVJlbmRlciA9IGZhbHNlKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBsZXQgZmllbGRWYWx1ZSA9IHZhbHVlO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gZmllbGQuX2Y7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UpIHtcbiAgICAgICAgICAgICAgICAhZmllbGRSZWZlcmVuY2UuZGlzYWJsZWQgJiZcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBnZXRGaWVsZFZhbHVlQXModmFsdWUsIGZpZWxkUmVmZXJlbmNlKSk7XG4gICAgICAgICAgICAgICAgZmllbGRWYWx1ZSA9XG4gICAgICAgICAgICAgICAgICAgIGlzSFRNTEVsZW1lbnQoZmllbGRSZWZlcmVuY2UucmVmKSAmJiBpc051bGxPclVuZGVmaW5lZCh2YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJydcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWU7XG4gICAgICAgICAgICAgICAgaWYgKGlzTXVsdGlwbGVTZWxlY3QoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICBbLi4uZmllbGRSZWZlcmVuY2UucmVmLm9wdGlvbnNdLmZvckVhY2goKG9wdGlvblJlZikgPT4gKG9wdGlvblJlZi5zZWxlY3RlZCA9IGZpZWxkVmFsdWUuaW5jbHVkZXMob3B0aW9uUmVmLnZhbHVlKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChmaWVsZFJlZmVyZW5jZS5yZWZzKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0NoZWNrQm94SW5wdXQoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChjaGVja2JveFJlZikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2hlY2tib3hSZWYuZGVmYXVsdENoZWNrZWQgfHwgIWNoZWNrYm94UmVmLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGZpZWxkVmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveFJlZi5jaGVja2VkID0gISFmaWVsZFZhbHVlLmZpbmQoKGRhdGEpID0+IGRhdGEgPT09IGNoZWNrYm94UmVmLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94UmVmLmNoZWNrZWQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkVmFsdWUgPT09IGNoZWNrYm94UmVmLnZhbHVlIHx8ICEhZmllbGRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChyYWRpb1JlZikgPT4gKHJhZGlvUmVmLmNoZWNrZWQgPSByYWRpb1JlZi52YWx1ZSA9PT0gZmllbGRWYWx1ZSkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzRmlsZUlucHV0KGZpZWxkUmVmZXJlbmNlLnJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmLnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZmVyZW5jZS5yZWYudmFsdWUgPSBmaWVsZFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWZpZWxkUmVmZXJlbmNlLnJlZi50eXBlICYmICFza2lwUmVuZGVyICYmICFza2lwVmFsdWVSZW5kZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gX2Zvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBfaGFzVmFsdWVzU3Vic2NyaWJlcihuYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBjbG9uZU9iamVjdChfZm9ybVZhbHVlcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgKG9wdGlvbnMuc2hvdWxkRGlydHkgfHwgb3B0aW9ucy5zaG91bGRUb3VjaCkgJiZcbiAgICAgICAgICAgIHVwZGF0ZVRvdWNoQW5kRGlydHkobmFtZSwgZmllbGQgJiZcbiAgICAgICAgICAgICAgICBmaWVsZC5fZiAmJlxuICAgICAgICAgICAgICAgICFmaWVsZC5fZi5kaXNhYmxlZCAmJlxuICAgICAgICAgICAgICAgIChmaWVsZC5fZi52YWx1ZUFzTnVtYmVyIHx8XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLnZhbHVlQXNEYXRlIHx8XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLnNldFZhbHVlQXMpXG4gICAgICAgICAgICAgICAgPyBnZXRGaWVsZFZhbHVlQXModmFsdWUsIGZpZWxkLl9mKVxuICAgICAgICAgICAgICAgIDogZmllbGRWYWx1ZSwgb3B0aW9ucy5zaG91bGRUb3VjaCwgb3B0aW9ucy5zaG91bGREaXJ0eSwgIXNraXBSZW5kZXIpO1xuICAgICAgICBvcHRpb25zLnNob3VsZFZhbGlkYXRlICYmXG4gICAgICAgICAgICB0cmlnZ2VyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yOiBvcHRpb25zLmRlbGF5RXJyb3IsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9wdGlvbnMuc2hvdWxkVmFsaWRhdGUgJiZcbiAgICAgICAgICAgIGZpZWxkICYmXG4gICAgICAgICAgICBmaWVsZC5fZiAmJlxuICAgICAgICAgICAgZmllbGQuX2YuZGVwcyAmJlxuICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KGZpZWxkLl9mLmRlcHMpIHx8IGZpZWxkLl9mLmRlcHMubGVuZ3RoID4gMCkpIHtcbiAgICAgICAgICAgIHRyaWdnZXIoZmllbGQuX2YuZGVwcyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHNldEZpZWxkVmFsdWVzID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUgPSBmYWxzZSwgc2tpcFJlbmRlciA9IGZhbHNlLCBza2lwVmFsdWVSZW5kZXIgPSBmYWxzZSkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGZpZWxkS2V5IGluIHZhbHVlKSB7XG4gICAgICAgICAgICBpZiAoIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwgZmllbGRLZXkpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gdmFsdWVbZmllbGRLZXldO1xuICAgICAgICAgICAgY29uc3QgZmllbGROYW1lID0gbmFtZSArICcuJyArIGZpZWxkS2V5O1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgIGlmIChfbmFtZXMuYXJyYXkuaGFzKGZpZWxkTmFtZSkpIHtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuYXJyYXkubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGZpZWxkTmFtZSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVzOiBza2lwQ2xvbmUgPyBfZm9ybVZhbHVlcyA6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIChfbmFtZXMuYXJyYXkuaGFzKG5hbWUpIHx8XG4gICAgICAgICAgICAgICAgaXNPYmplY3QoZmllbGRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAoZmllbGQgJiYgIWZpZWxkLl9mKSkgJiZcbiAgICAgICAgICAgICAgICAhaXNEYXRlT2JqZWN0KGZpZWxkVmFsdWUpXG4gICAgICAgICAgICAgICAgPyBzZXRGaWVsZFZhbHVlcyhmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKVxuICAgICAgICAgICAgICAgIDogc2V0RmllbGRWYWx1ZShmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQgPSBmYWxzZSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNGaWVsZEFycmF5ID0gX25hbWVzLmFycmF5LmhhcyhuYW1lKTtcbiAgICAgICAgY29uc3QgY2xvbmVWYWx1ZSA9IHNraXBDbG9uZSA/IHZhbHVlIDogY2xvbmVPYmplY3QodmFsdWUpO1xuICAgICAgICBjb25zdCBwcmV2aW91c1ZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNWYWx1ZVVuY2hhbmdlZCA9IGRlZXBFcXVhbChwcmV2aW91c1ZhbHVlLCBjbG9uZVZhbHVlKTtcbiAgICAgICAgaWYgKCFpc1ZhbHVlVW5jaGFuZ2VkKSB7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGNsb25lVmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0ZpZWxkQXJyYXkpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5hcnJheS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lID8gX2Zvcm1WYWx1ZXMgOiBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChfaXNUcmFja2VkKCdpc0RpcnR5JywgJ2RpcnR5RmllbGRzJykgJiYgb3B0aW9ucy5zaG91bGREaXJ0eSkge1xuICAgICAgICAgICAgICAgIF91cGRhdGVEaXJ0eUZpZWxkcygpO1xuICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9IF9nZXREaXJ0eShuYW1lLCBjbG9uZVZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoIXNraXBTdGF0ZUVtaXQpIHtcbiAgICAgICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpcnR5RmllbGRzOiBfZm9ybVN0YXRlLmRpcnR5RmllbGRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNEaXJ0eTogX2Zvcm1TdGF0ZS5pc0RpcnR5LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvcHRpb25zLnNob3VsZFZhbGlkYXRlICYmXG4gICAgICAgICAgICAgICAgdHJpZ2dlcihuYW1lLCB7XG4gICAgICAgICAgICAgICAgICAgIGRlbGF5RXJyb3I6IG9wdGlvbnMuZGVsYXlFcnJvcixcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlzRW1wdHkgPSAoQXJyYXkuaXNBcnJheShjbG9uZVZhbHVlKSAmJiAhY2xvbmVWYWx1ZS5sZW5ndGgpIHx8XG4gICAgICAgICAgICAgICAgaXNFbXB0eU9iamVjdChjbG9uZVZhbHVlKTtcbiAgICAgICAgICAgIGNvbnN0IHNraXBWYWx1ZVJlbmRlciA9ICFpc1ZhbHVlVW5jaGFuZ2VkICYmICFza2lwU3RhdGVFbWl0O1xuICAgICAgICAgICAgaWYgKCFmaWVsZCB8fCBmaWVsZC5fZiB8fCBpc051bGxPclVuZGVmaW5lZChjbG9uZVZhbHVlKSB8fCBpc0VtcHR5KSB7XG4gICAgICAgICAgICAgICAgc2V0RmllbGRWYWx1ZShuYW1lLCBjbG9uZVZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQsIHNraXBWYWx1ZVJlbmRlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlcyhuYW1lLCBjbG9uZVZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQsIHNraXBWYWx1ZVJlbmRlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpc1ZhbHVlVW5jaGFuZ2VkICYmICFza2lwU3RhdGVFbWl0KSB7XG4gICAgICAgICAgICBjb25zdCB3YXRjaGVkID0gaXNXYXRjaGVkKG5hbWUsIF9uYW1lcyk7XG4gICAgICAgICAgICBjb25zdCBlbWl0dGVkTmFtZSA9IF9zdGF0ZS5tb3VudCB8fCB3YXRjaGVkID8gbmFtZSA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkQXJyYXlJdGVtTmFtZXMgPSBpc0ZpZWxkQXJyYXlcbiAgICAgICAgICAgICAgICA/IFtdXG4gICAgICAgICAgICAgICAgOiBnZXRGaWVsZEFycmF5SXRlbU5hbWVzKF9uYW1lcy5hcnJheSwgbmFtZSk7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZXMgPSBza2lwQ2xvbmVcbiAgICAgICAgICAgICAgICA/IF9mb3JtVmFsdWVzXG4gICAgICAgICAgICAgICAgOiBfaGFzVmFsdWVzU3Vic2NyaWJlcihlbWl0dGVkTmFtZSkgfHxcbiAgICAgICAgICAgICAgICAgICAgZmllbGRBcnJheUl0ZW1OYW1lcy5zb21lKF9oYXNWYWx1ZXNTdWJzY3JpYmVyKVxuICAgICAgICAgICAgICAgICAgICA/IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKVxuICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAuLi4od2F0Y2hlZCAmJiBfZm9ybVN0YXRlKSxcbiAgICAgICAgICAgICAgICBuYW1lOiBlbWl0dGVkTmFtZSxcbiAgICAgICAgICAgICAgICB2YWx1ZXMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbU5hbWUgb2YgZmllbGRBcnJheUl0ZW1OYW1lcykge1xuICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgbmFtZTogaXRlbU5hbWUsIHZhbHVlcyB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgc2V0VmFsdWUgPSAobmFtZSwgdmFsdWUsIG9wdGlvbnMgPSB7fSkgPT4gX3NldFZhbHVlKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBmYWxzZSk7XG4gICAgY29uc3Qgc2V0VmFsdWVzID0gKGZvcm1WYWx1ZXMsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBjb25zdCB1cGRhdGVkRm9ybVZhbHVlcyA9IGlzRnVuY3Rpb24oZm9ybVZhbHVlcylcbiAgICAgICAgICAgID8gZm9ybVZhbHVlcyhfZm9ybVZhbHVlcylcbiAgICAgICAgICAgIDogZm9ybVZhbHVlcztcbiAgICAgICAgaWYgKCFkZWVwRXF1YWwoX2Zvcm1WYWx1ZXMsIHVwZGF0ZWRGb3JtVmFsdWVzKSkge1xuICAgICAgICAgICAgX2Zvcm1WYWx1ZXMgPSB7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgLi4udXBkYXRlZEZvcm1WYWx1ZXMsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBmaWVsZE5hbWUgb2YgbmV3IFNldChbLi4uX25hbWVzLm1vdW50LCAuLi5fbmFtZXMuYXJyYXldKSkge1xuICAgICAgICAgICAgICAgIGlmIChoYXModXBkYXRlZEZvcm1WYWx1ZXMsIGZpZWxkTmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgX3NldFZhbHVlKGZpZWxkTmFtZSwgZ2V0KHVwZGF0ZWRGb3JtVmFsdWVzLCBmaWVsZE5hbWUpLCBvcHRpb25zLCB0cnVlLCB0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICBuYW1lOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdHlwZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIC4uLihfdmFsdWVzU3Vic2NyaWJlcnMuc2l6ZSA/IHsgdmFsdWVzOiBfZm9ybVZhbHVlcyB9IDoge30pLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5zaG91bGRWYWxpZGF0ZSkge1xuICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBvbkNoYW5nZSA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICBfc3RhdGUubW91bnQgPSB0cnVlO1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIGxldCBuYW1lID0gdGFyZ2V0Lm5hbWU7XG4gICAgICAgIGxldCBpc0ZpZWxkVmFsdWVVcGRhdGVkID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IHJlZ2lzdGVyQ2FsbElkID0gX3JlZ2lzdGVyQ2FsbElkO1xuICAgICAgICBjb25zdCBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZCA9IChmaWVsZFZhbHVlKSA9PiB7XG4gICAgICAgICAgICBpc0ZpZWxkVmFsdWVVcGRhdGVkID1cbiAgICAgICAgICAgICAgICAhIWdldChfZmllbGRzLCBuYW1lKSAmJlxuICAgICAgICAgICAgICAgICAgICAhKF9yZWdpc3RlckNhbGxJZHNbbmFtZV0gPiByZWdpc3RlckNhbGxJZCkgJiZcbiAgICAgICAgICAgICAgICAgICAgZGVlcEVxdWFsKGZpZWxkVmFsdWUsIGdldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSkpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIF9zdGF0ZS5rZWVwSXNWYWxpZCA9IGZhbHNlO1xuICAgICAgICAgICAgbGV0IGVycm9yO1xuICAgICAgICAgICAgbGV0IGlzVmFsaWQ7XG4gICAgICAgICAgICBsZXQgc2hvdWxkRmx1c2hFcnJvciA9IGZhbHNlO1xuICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IHRhcmdldC50eXBlXG4gICAgICAgICAgICAgICAgPyBnZXRGaWVsZFZhbHVlKGZpZWxkLl9mKVxuICAgICAgICAgICAgICAgIDogZ2V0RXZlbnRWYWx1ZShldmVudCk7XG4gICAgICAgICAgICBjb25zdCBpc0JsdXJFdmVudCA9IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5CTFVSIHx8IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5GT0NVU19PVVQ7XG4gICAgICAgICAgICBjb25zdCBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgPSAhaGFzVmFsaWRhdGlvbihmaWVsZC5fZikgJiZcbiAgICAgICAgICAgICAgICAhX29wdGlvbnMudmFsaWRhdGUgJiZcbiAgICAgICAgICAgICAgICAhX29wdGlvbnMucmVzb2x2ZXIgJiZcbiAgICAgICAgICAgICAgICAhZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSAmJlxuICAgICAgICAgICAgICAgICFmaWVsZC5fZi5kZXBzO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkU2tpcFZhbGlkYXRpb24gPSBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgfHxcbiAgICAgICAgICAgICAgICBza2lwVmFsaWRhdGlvbihpc0JsdXJFdmVudCwgZ2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSksIF9mb3JtU3RhdGUuaXNTdWJtaXR0ZWQsIF92YWxpZGF0aW9uTW9kZUFmdGVyU3VibWl0LCBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQpO1xuICAgICAgICAgICAgY29uc3Qgd2F0Y2hlZCA9IGlzV2F0Y2hlZChuYW1lLCBfbmFtZXMsIGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgY2xvbmVPYmplY3QoZmllbGRWYWx1ZSkpO1xuICAgICAgICAgICAgaWYgKGlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgaWYgKCF0YXJnZXQgfHwgIXRhcmdldC5yZWFkT25seSkge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZC5fZi5vbkJsdXIgJiYgZmllbGQuX2Yub25CbHVyKGV2ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkZWxheUVycm9yQ2FsbGJhY2tzLCBuYW1lKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hvdWxkRmx1c2hFcnJvciA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdKDApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoZmllbGQuX2Yub25DaGFuZ2UpIHtcbiAgICAgICAgICAgICAgICBmaWVsZC5fZi5vbkNoYW5nZShldmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZFN0YXRlID0gdXBkYXRlVG91Y2hBbmREaXJ0eShuYW1lLCBmaWVsZFZhbHVlLCBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICBjb25zdCBzaG91bGRSZW5kZXIgPSAhaXNFbXB0eU9iamVjdChmaWVsZFN0YXRlKSB8fCB3YXRjaGVkO1xuICAgICAgICAgICAgIWlzQmx1ckV2ZW50ICYmXG4gICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBldmVudC50eXBlLFxuICAgICAgICAgICAgICAgICAgICAuLi4oX2hhc1ZhbHVlc1N1YnNjcmliZXIobmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyB2YWx1ZXM6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChzaG91bGRTa2lwVmFsaWRhdGlvbikge1xuICAgICAgICAgICAgICAgIGlmICgoIWhhc05vVmFsaWRhdGlvbkVmZmVjdCB8fCAhX2Zvcm1TdGF0ZS5pc1ZhbGlkKSAmJlxuICAgICAgICAgICAgICAgICAgICBfaXNUcmFja2VkKCdpc1ZhbGlkJykpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9vcHRpb25zLm1vZGUgPT09ICdvbkJsdXInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNCbHVyRXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghaXNCbHVyRXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoc2hvdWxkUmVuZGVyICYmXG4gICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgbmFtZSwgLi4uKHdhdGNoZWQgPyB7fSA6IGZpZWxkU3RhdGUpIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghX29wdGlvbnMucmVzb2x2ZXIgJiYgX29wdGlvbnMudmFsaWRhdGUpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCB2YWxpZGF0ZUZvcm0oe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICBldmVudFR5cGU6IGV2ZW50LnR5cGUsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAhaXNCbHVyRXZlbnQgJiYgd2F0Y2hlZCAmJiBfc3ViamVjdHMuc3RhdGUubmV4dCh7IC4uLl9mb3JtU3RhdGUgfSk7XG4gICAgICAgICAgICBpZiAoX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGVycm9ycyB9ID0gYXdhaXQgX3J1blNjaGVtYShbbmFtZV0pO1xuICAgICAgICAgICAgICAgIGlmIChyZXNldENhbGxJZCAhPT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhbbmFtZV0pO1xuICAgICAgICAgICAgICAgIF91cGRhdGVJc0ZpZWxkVmFsdWVVcGRhdGVkKGZpZWxkVmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmICghaXNGaWVsZFZhbHVlVXBkYXRlZCkge1xuICAgICAgICAgICAgICAgICAgICAhaXNFbXB0eU9iamVjdChmaWVsZFN0YXRlKSAmJiBfc3ViamVjdHMuc3RhdGUubmV4dChmaWVsZFN0YXRlKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBwcmV2aW91c0Vycm9yTG9va3VwUmVzdWx0ID0gc2NoZW1hRXJyb3JMb29rdXAoX2Zvcm1TdGF0ZS5lcnJvcnMsIF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yTG9va3VwUmVzdWx0ID0gc2NoZW1hRXJyb3JMb29rdXAoZXJyb3JzLCBfZmllbGRzLCBwcmV2aW91c0Vycm9yTG9va3VwUmVzdWx0Lm5hbWUgfHwgbmFtZSk7XG4gICAgICAgICAgICAgICAgZXJyb3IgPSBlcnJvckxvb2t1cFJlc3VsdC5lcnJvcjtcbiAgICAgICAgICAgICAgICBuYW1lID0gZXJyb3JMb29rdXBSZXN1bHQubmFtZTtcbiAgICAgICAgICAgICAgICBpc1ZhbGlkID0gaXNFbXB0eU9iamVjdChlcnJvcnMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzZXRDYWxsSWQgPSBfcmVzZXRDYWxsSWQ7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2V0VmFsaWRDYWxsSWQgPSArK19zZXRWYWxpZENhbGxJZDtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgZXJyb3IgPSAoYXdhaXQgdmFsaWRhdGVGaWVsZChmaWVsZCwgX25hbWVzLmRpc2FibGVkLCBfZm9ybVZhbHVlcywgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMsIF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24pKVtuYW1lXTtcbiAgICAgICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcoW25hbWVdKTtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZChmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNGaWVsZFZhbHVlVXBkYXRlZCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChfaXNUcmFja2VkKCdpc1ZhbGlkJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbmx5Q2hlY2tWYWxpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogZXZlbnQudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZChmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZXRWYWxpZENhbGxJZCAhPT0gX3NldFZhbGlkQ2FsbElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNWYWxpZCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0ZpZWxkVmFsdWVVcGRhdGVkKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YuZGVwcyAmJlxuICAgICAgICAgICAgICAgICAgICAoIUFycmF5LmlzQXJyYXkoZmllbGQuX2YuZGVwcykgfHwgZmllbGQuX2YuZGVwcy5sZW5ndGggPiAwKSAmJlxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyKGZpZWxkLl9mLmRlcHMpO1xuICAgICAgICAgICAgICAgIHNob3VsZFJlbmRlckJ5RXJyb3IobmFtZSwgaXNWYWxpZCwgZXJyb3IsIGZpZWxkU3RhdGUpO1xuICAgICAgICAgICAgICAgIHNob3VsZEZsdXNoRXJyb3IgJiZcbiAgICAgICAgICAgICAgICAgICAgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGRlbGF5RXJyb3JDYWxsYmFja3MsIG5hbWUpICYmXG4gICAgICAgICAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0oMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9mb2N1c0lucHV0ID0gKHJlZiwga2V5KSA9PiB7XG4gICAgICAgIGlmIChnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIGtleSkgJiYgcmVmLmZvY3VzKSB7XG4gICAgICAgICAgICByZWYuZm9jdXMoKTtcbiAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICB9O1xuICAgIGNvbnN0IHRyaWdnZXIgPSBhc3luYyAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIF9zdGF0ZS5rZWVwSXNWYWxpZCA9IGZhbHNlO1xuICAgICAgICBsZXQgaXNWYWxpZDtcbiAgICAgICAgbGV0IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZXMgPSBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSk7XG4gICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICBpZiAoX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IGVycm9ycyA9IGF3YWl0IGV4ZWN1dGVTY2hlbWFBbmRVcGRhdGVTdGF0ZShpc1VuZGVmaW5lZChuYW1lKSA/IG5hbWUgOiBmaWVsZE5hbWVzKTtcbiAgICAgICAgICAgIGlzVmFsaWQgPSBpc0VtcHR5T2JqZWN0KGVycm9ycyk7XG4gICAgICAgICAgICB2YWxpZGF0aW9uUmVzdWx0ID0gbmFtZVxuICAgICAgICAgICAgICAgID8gIWZpZWxkTmFtZXMuc29tZSgobmFtZSkgPT4gZ2V0KGVycm9ycywgbmFtZSkpXG4gICAgICAgICAgICAgICAgOiBpc1ZhbGlkO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG5hbWUpIHtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSAoYXdhaXQgUHJvbWlzZS5hbGwoZmllbGROYW1lcy5tYXAoYXN5bmMgKGZpZWxkTmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkczogZmllbGQgJiYgZmllbGQuX2YgPyB7IFtmaWVsZE5hbWVdOiBmaWVsZCB9IDogZmllbGQsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlRSSUdHRVIsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KSkpLmV2ZXJ5KEJvb2xlYW4pO1xuICAgICAgICAgICAgISghdmFsaWRhdGlvblJlc3VsdCAmJiAhX2Zvcm1TdGF0ZS5pc1ZhbGlkKSAmJiBfc2V0VmFsaWQoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICBmaWVsZHM6IF9maWVsZHMsXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBldmVudFR5cGU6IEVWRU5UUy5UUklHR0VSLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWxpZGF0aW9uUmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRpb25zLmRlbGF5RXJyb3IgJiYgX29wdGlvbnMuZGVsYXlFcnJvciAmJiBpc1N0cmluZyhuYW1lKSkge1xuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0gPSBkZWJvdW5jZShuYW1lLCAoKSA9PiB1cGRhdGVFcnJvcnMobmFtZSwgZXJyb3IpKTtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdKF9vcHRpb25zLmRlbGF5RXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yKG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRpb25zLnNob3VsZFRvdWNoKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBuYW1lID8gZmllbGROYW1lcyA6IF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgICFfbmFtZXMuYXJyYXkuaGFzKGZpZWxkTmFtZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgZmllbGROYW1lLCB0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgLi4uKCFpc1N0cmluZyhuYW1lKSB8fFxuICAgICAgICAgICAgICAgIChfaXNUcmFja2VkKCdpc1ZhbGlkJykgJiYgaXNWYWxpZCAhPT0gX2Zvcm1TdGF0ZS5pc1ZhbGlkKVxuICAgICAgICAgICAgICAgID8ge31cbiAgICAgICAgICAgICAgICA6IHsgbmFtZSB9KSxcbiAgICAgICAgICAgIC4uLihfb3B0aW9ucy5yZXNvbHZlciB8fCAhbmFtZSA/IHsgaXNWYWxpZCB9IDoge30pLFxuICAgICAgICAgICAgLi4uKG9wdGlvbnMuc2hvdWxkVG91Y2ggJiYgX2lzVHJhY2tlZCgndG91Y2hlZEZpZWxkcycpXG4gICAgICAgICAgICAgICAgPyB7IHRvdWNoZWRGaWVsZHM6IF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcyB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICB9KTtcbiAgICAgICAgb3B0aW9ucy5zaG91bGRGb2N1cyAmJlxuICAgICAgICAgICAgIXZhbGlkYXRpb25SZXN1bHQgJiZcbiAgICAgICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihfZmllbGRzLCBfZm9jdXNJbnB1dCwgbmFtZSA/IGZpZWxkTmFtZXMgOiBfbmFtZXMubW91bnQpO1xuICAgICAgICByZXR1cm4gdmFsaWRhdGlvblJlc3VsdDtcbiAgICB9O1xuICAgIGNvbnN0IGdldFZhbHVlcyA9ICgoZmllbGROYW1lcywgY29uZmlnKSA9PiB7XG4gICAgICAgIGxldCB2YWx1ZXMgPSBpc1VuZGVmaW5lZChmaWVsZE5hbWVzKSAmJiAhY29uZmlnXG4gICAgICAgICAgICA/IHsgLi4uKF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMpIH1cbiAgICAgICAgICAgIDogX3N0YXRlLm1vdW50XG4gICAgICAgICAgICAgICAgPyBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgICAgIDogX2RlZmF1bHRWYWx1ZXM7XG4gICAgICAgIGlmIChjb25maWcpIHtcbiAgICAgICAgICAgIHZhbHVlcyA9IGV4dHJhY3RGb3JtVmFsdWVzKGNvbmZpZy5kaXJ0eUZpZWxkcyA/IF9mb3JtU3RhdGUuZGlydHlGaWVsZHMgOiBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGlzVW5kZWZpbmVkKGZpZWxkTmFtZXMpXG4gICAgICAgICAgICA/IHZhbHVlc1xuICAgICAgICAgICAgOiBpc1N0cmluZyhmaWVsZE5hbWVzKVxuICAgICAgICAgICAgICAgID8gZ2V0KHZhbHVlcywgZmllbGROYW1lcylcbiAgICAgICAgICAgICAgICA6IGZpZWxkTmFtZXMubWFwKChuYW1lKSA9PiBnZXQodmFsdWVzLCBuYW1lKSk7XG4gICAgfSk7XG4gICAgY29uc3QgZ2V0RXJyb3JzID0gKChmaWVsZE5hbWVzKSA9PiBpc1VuZGVmaW5lZChmaWVsZE5hbWVzKVxuICAgICAgICA/IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfVxuICAgICAgICA6IGlzU3RyaW5nKGZpZWxkTmFtZXMpXG4gICAgICAgICAgICA/IGdldChfZm9ybVN0YXRlLmVycm9ycywgZmllbGROYW1lcylcbiAgICAgICAgICAgIDogZmllbGROYW1lcy5tYXAoKG5hbWUpID0+IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSkpKTtcbiAgICBjb25zdCBnZXRGaWVsZFN0YXRlID0gKG5hbWUsIGZvcm1TdGF0ZSkgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXRGb3JtU3RhdGUgPSBmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZTtcbiAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQodGFyZ2V0Rm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBpbnZhbGlkOiAhIWVycm9yLFxuICAgICAgICAgICAgaXNEaXJ0eTogISFnZXQodGFyZ2V0Rm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKSxcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgaXNWYWxpZGF0aW5nOiAhIWdldCh0YXJnZXRGb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgbmFtZSksXG4gICAgICAgICAgICBpc1RvdWNoZWQ6ICEhZ2V0KHRhcmdldEZvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKSxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IGNsZWFyRXJyb3JzID0gKG5hbWUpID0+IHtcbiAgICAgICAgY29uc3QgbmFtZXMgPSBuYW1lID8gY29udmVydFRvQXJyYXlQYXlsb2FkKG5hbWUpIDogdW5kZWZpbmVkO1xuICAgICAgICBpZiAobmFtZXMpIHtcbiAgICAgICAgICAgIG5hbWVzLmZvckVhY2goKGlucHV0TmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNhbmNlbERlbGF5ZWRFcnJvclRyZWUoaW5wdXROYW1lKTtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgaW5wdXROYW1lKTtcbiAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGlucHV0TmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgT2JqZWN0LmtleXMoZGVsYXlFcnJvckNhbGxiYWNrcykuZm9yRWFjaChjYW5jZWxEZWxheWVkRXJyb3IpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7fTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHNldEVycm9yID0gKG5hbWUsIGVycm9yLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGNhbmNlbERlbGF5ZWRFcnJvclRyZWUobmFtZSk7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUsIHsgX2Y6IHt9IH0pO1xuICAgICAgICBjb25zdCByZWYgPSBmaWVsZC5fZiAmJiBmaWVsZC5fZi5yZWY7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRFcnJvciA9IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSkgfHwge307XG4gICAgICAgIGNvbnN0IHsgcmVmOiBjdXJyZW50UmVmLCBtZXNzYWdlLCB0eXBlLCB0eXBlcywgLi4ucmVzdE9mRXJyb3JUcmVlIH0gPSBjdXJyZW50RXJyb3I7XG4gICAgICAgIHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwge1xuICAgICAgICAgICAgLi4ucmVzdE9mRXJyb3JUcmVlLFxuICAgICAgICAgICAgLi4uZXJyb3IsXG4gICAgICAgICAgICByZWYsXG4gICAgICAgIH0pO1xuICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICAgIG9wdGlvbnMgJiYgb3B0aW9ucy5zaG91bGRGb2N1cyAmJiByZWYgJiYgcmVmLmZvY3VzICYmIHJlZi5mb2N1cygpO1xuICAgIH07XG4gICAgY29uc3Qgd2F0Y2ggPSAobmFtZSwgZGVmYXVsdFZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKG5hbWUpKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZXNTdWJzY3JpYmVyID0ge307XG4gICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlcnMuYWRkKHZhbHVlc1N1YnNjcmliZXIpO1xuICAgICAgICAgICAgY29uc3QgeyB1bnN1YnNjcmliZSB9ID0gX3N1YmplY3RzLnN0YXRlLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHBheWxvYWQpID0+ICd2YWx1ZXMnIGluIHBheWxvYWQgJiZcbiAgICAgICAgICAgICAgICAgICAgbmFtZShwYXlsb2FkLnZhbHVlcyB8fCBfZ2V0V2F0Y2godW5kZWZpbmVkLCBkZWZhdWx0VmFsdWUpLCBwYXlsb2FkKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB1bnN1YnNjcmliZTogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlcnMuZGVsZXRlKHZhbHVlc1N1YnNjcmliZXIpO1xuICAgICAgICAgICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfZ2V0V2F0Y2gobmFtZSwgZGVmYXVsdFZhbHVlLCB0cnVlKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zdWJzY3JpYmUgPSAocHJvcHMpID0+IHtcbiAgICAgICAgY29uc3QgdmFsdWVzU3Vic2NyaWJlciA9IHsgbmFtZTogcHJvcHMubmFtZSwgZXhhY3Q6IHByb3BzLmV4YWN0IH07XG4gICAgICAgIHByb3BzLmZvcm1TdGF0ZSAmJlxuICAgICAgICAgICAgcHJvcHMuZm9ybVN0YXRlLnZhbHVlcyAmJlxuICAgICAgICAgICAgX3ZhbHVlc1N1YnNjcmliZXJzLmFkZCh2YWx1ZXNTdWJzY3JpYmVyKTtcbiAgICAgICAgY29uc3QgeyB1bnN1YnNjcmliZSB9ID0gX3N1YmplY3RzLnN0YXRlLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAoZm9ybVN0YXRlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHNob3VsZFN1YnNjcmliZUJ5TmFtZShwcm9wcy5uYW1lLCBmb3JtU3RhdGUubmFtZSwgcHJvcHMuZXhhY3QpICYmXG4gICAgICAgICAgICAgICAgICAgIHNob3VsZFJlbmRlckZvcm1TdGF0ZShmb3JtU3RhdGUsIHByb3BzLmZvcm1TdGF0ZSB8fCBfcHJveHlGb3JtU3RhdGUsIHByb3BzLnJlUmVuZGVyUm9vdCkpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gZm9ybVN0YXRlLnZhbHVlcyB8fCB7IC4uLl9mb3JtVmFsdWVzIH07XG4gICAgICAgICAgICAgICAgICAgIHByb3BzLmNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0aW5nRmllbGRzOiBfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkYXRpbmc6IF9mb3JtU3RhdGUuaXNWYWxpZGF0aW5nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVzLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgX3ZhbHVlc1N1YnNjcmliZXJzLmRlbGV0ZSh2YWx1ZXNTdWJzY3JpYmVyKTtcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCBzdWJzY3JpYmUgPSAocHJvcHMpID0+IHtcbiAgICAgICAgX3N0YXRlLm1vdW50ID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgdHJhY2tlZEtleXMgPSBPYmplY3Qua2V5cyhwcm9wcy5mb3JtU3RhdGUgfHwge30pLmZpbHRlcigoa2V5KSA9PiBwcm9wcy5mb3JtU3RhdGUgJiYgcHJvcHMuZm9ybVN0YXRlW2tleV0pO1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiB0cmFja2VkS2V5cykge1xuICAgICAgICAgICAgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlW2tleV0gPSAoX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlW2tleV0gfHwgMCkgKyAxO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gX3N1YnNjcmliZSh7XG4gICAgICAgICAgICAuLi5wcm9wcyxcbiAgICAgICAgICAgIGZvcm1TdGF0ZToge1xuICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRQcm94eUZvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICAuLi5wcm9wcy5mb3JtU3RhdGUsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIC8vIHNwbGljZSgwKSBlbXB0aWVzIHRoZSBsaXN0LCBzbyBhIHJlcGVhdGVkIHVuc3Vic2NyaWJlIHJlbGVhc2VzIG5vdGhpbmdcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIHRyYWNrZWRLZXlzLnNwbGljZSgwKSkge1xuICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZVtrZXldLS07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgdW5yZWdpc3RlciA9IChuYW1lLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgZmllbGROYW1lcyA9IG5hbWVcbiAgICAgICAgICAgID8gY29udmVydFRvQXJyYXlQYXlsb2FkKG5hbWUpXG4gICAgICAgICAgICA6IF9uYW1lcy5tb3VudDtcbiAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBJc1ZhbGlkYXRpbmcpIHtcbiAgICAgICAgICAgIF91cGRhdGVWYWxpZGF0aW5nRmllbGRzKGZpZWxkTmFtZXMpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIGZpZWxkTmFtZXMpIHtcbiAgICAgICAgICAgIF9uYW1lcy5tb3VudC5kZWxldGUoZmllbGROYW1lKTtcbiAgICAgICAgICAgIF9uYW1lcy5hcnJheS5kZWxldGUoZmllbGROYW1lKTtcbiAgICAgICAgICAgIF9uYW1lcy5kaXNhYmxlZC5kZWxldGUoZmllbGROYW1lKTtcbiAgICAgICAgICAgIHVuc2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAhb3B0aW9ucy5rZWVwVmFsdWUgJiYgdW5zZXQoX2Zvcm1WYWx1ZXMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMua2VlcEVycm9yKSB7XG4gICAgICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yVHJlZShmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgIW9wdGlvbnMua2VlcERpcnR5ICYmIHVuc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAhb3B0aW9ucy5rZWVwVG91Y2hlZCAmJiB1bnNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAhX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciAmJlxuICAgICAgICAgICAgICAgICFvcHRpb25zLmtlZXBEZWZhdWx0VmFsdWUgJiZcbiAgICAgICAgICAgICAgICB1bnNldChfZGVmYXVsdFZhbHVlcywgZmllbGROYW1lKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIW9wdGlvbnMua2VlcEVycm9yKSB7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgfVxuICAgICAgICBfdmFsdWVzU3Vic2NyaWJlcnMuc2l6ZSAmJlxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIHZhbHVlczogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAuLi4ob3B0aW9ucy5rZWVwRGlydHkgPyB7fSA6IHsgaXNEaXJ0eTogX2dldERpcnR5KCkgfSksXG4gICAgICAgICAgICAuLi4ob3B0aW9ucy5rZWVwSXNWYWxpZGF0aW5nXG4gICAgICAgICAgICAgICAgPyB7fVxuICAgICAgICAgICAgICAgIDogeyBpc1ZhbGlkYXRpbmc6ICFpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcykgfSksXG4gICAgICAgIH0pO1xuICAgICAgICAhb3B0aW9ucy5rZWVwSXNWYWxpZCAmJiBfc2V0VmFsaWQoKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zZXREaXNhYmxlZEZpZWxkID0gKHsgZGlzYWJsZWQsIG5hbWUsIH0pID0+IHtcbiAgICAgICAgaWYgKChpc0Jvb2xlYW4oZGlzYWJsZWQpICYmIF9zdGF0ZS5tb3VudCkgfHxcbiAgICAgICAgICAgICEhZGlzYWJsZWQgfHxcbiAgICAgICAgICAgIF9uYW1lcy5kaXNhYmxlZC5oYXMobmFtZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHdhc0Rpc2FibGVkID0gX25hbWVzLmRpc2FibGVkLmhhcyhuYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IGlzRGlzYWJsZWQgPSAhIWRpc2FibGVkO1xuICAgICAgICAgICAgY29uc3QgZGlzYWJsZWRTdGF0ZUNoYW5nZWQgPSB3YXNEaXNhYmxlZCAhPT0gaXNEaXNhYmxlZDtcbiAgICAgICAgICAgIGRpc2FibGVkID8gX25hbWVzLmRpc2FibGVkLmFkZChuYW1lKSA6IF9uYW1lcy5kaXNhYmxlZC5kZWxldGUobmFtZSk7XG4gICAgICAgICAgICBkaXNhYmxlZFN0YXRlQ2hhbmdlZCAmJiBfc3RhdGUubW91bnQgJiYgIV9zdGF0ZS5hY3Rpb24gJiYgX3NldFZhbGlkKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHJlZ2lzdGVyID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBsZXQgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IGRpc2FibGVkSXNEZWZpbmVkID0gaXNCb29sZWFuKG9wdGlvbnMuZGlzYWJsZWQpIHx8IGlzQm9vbGVhbihfb3B0aW9ucy5kaXNhYmxlZCk7XG4gICAgICAgIGNvbnN0IHNob3VsZFJldmFsaWRhdGVSZW1vdW50ID0gIV9uYW1lcy5yZWdpc3Rlck5hbWUuaGFzKG5hbWUpICYmIGZpZWxkICYmIGZpZWxkLl9mICYmICFmaWVsZC5fZi5tb3VudDtcbiAgICAgICAgaWYgKCFmaWVsZCB8fCAhZmllbGQuX2YpIHtcbiAgICAgICAgICAgIF9yZWdpc3RlckNhbGxJZHNbbmFtZV0gPSArK19yZWdpc3RlckNhbGxJZDtcbiAgICAgICAgfVxuICAgICAgICBzZXQoX2ZpZWxkcywgbmFtZSwge1xuICAgICAgICAgICAgLi4uKGZpZWxkIHx8IHt9KSxcbiAgICAgICAgICAgIF9mOiB7XG4gICAgICAgICAgICAgICAgLi4uKGZpZWxkICYmIGZpZWxkLl9mID8gZmllbGQuX2YgOiB7IHJlZjogeyBuYW1lIH0gfSksXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBtb3VudDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIF9uYW1lcy5tb3VudC5hZGQobmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZikge1xuICAgICAgICAgICAgY29uc3QgbmV4dEZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgZm9yIChjb25zdCBydWxlIG9mIFJFR0lTVEVSX1ZBTElEQVRJT05fUlVMRVMpIHtcbiAgICAgICAgICAgICAgICBpZiAoIShydWxlIGluIG9wdGlvbnMpKSB7XG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBuZXh0RmllbGQuX2ZbcnVsZV07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChmaWVsZCAmJiAhc2hvdWxkUmV2YWxpZGF0ZVJlbW91bnQpIHtcbiAgICAgICAgICAgIF9zZXREaXNhYmxlZEZpZWxkKHtcbiAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNCb29sZWFuKG9wdGlvbnMuZGlzYWJsZWQpXG4gICAgICAgICAgICAgICAgICAgID8gb3B0aW9ucy5kaXNhYmxlZFxuICAgICAgICAgICAgICAgICAgICA6IF9vcHRpb25zLmRpc2FibGVkLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHVwZGF0ZVZhbGlkQW5kVmFsdWUobmFtZSwgdHJ1ZSwgb3B0aW9ucy52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLihkaXNhYmxlZElzRGVmaW5lZFxuICAgICAgICAgICAgICAgID8geyBkaXNhYmxlZDogb3B0aW9ucy5kaXNhYmxlZCB8fCBfb3B0aW9ucy5kaXNhYmxlZCB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICAuLi4oX29wdGlvbnMucHJvZ3Jlc3NpdmVcbiAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICEhZ2V0UnVsZVZhbHVlKG9wdGlvbnMucmVxdWlyZWQpLFxuICAgICAgICAgICAgICAgICAgICBtaW46IGdldFJ1bGVWYWx1ZShvcHRpb25zLm1pbiksXG4gICAgICAgICAgICAgICAgICAgIG1heDogZ2V0UnVsZVZhbHVlKG9wdGlvbnMubWF4KSxcbiAgICAgICAgICAgICAgICAgICAgbWluTGVuZ3RoOiBnZXRSdWxlVmFsdWUob3B0aW9ucy5taW5MZW5ndGgpLFxuICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg6IGdldFJ1bGVWYWx1ZShvcHRpb25zLm1heExlbmd0aCksXG4gICAgICAgICAgICAgICAgICAgIHBhdHRlcm46IGdldFJ1bGVWYWx1ZShvcHRpb25zLnBhdHRlcm4pLFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBvbkNoYW5nZSxcbiAgICAgICAgICAgIG9uQmx1cjogb25DaGFuZ2UsXG4gICAgICAgICAgICByZWY6IChyZWYpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVmKSB7XG4gICAgICAgICAgICAgICAgICAgIF9uYW1lcy5yZWdpc3Rlck5hbWUuYWRkKG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICByZWdpc3RlcihuYW1lLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgICAgICAgX25hbWVzLnJlZ2lzdGVyTmFtZS5kZWxldGUobmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFJlZiA9IGlzVW5kZWZpbmVkKHJlZi52YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gcmVmLnF1ZXJ5U2VsZWN0b3JBbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHJlZi5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dCxzZWxlY3QsdGV4dGFyZWEnKVswXSB8fCByZWZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHJlZlxuICAgICAgICAgICAgICAgICAgICAgICAgOiByZWY7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJhZGlvT3JDaGVja2JveCA9IGlzUmFkaW9PckNoZWNrYm94KGZpZWxkUmVmKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVmcyA9IGZpZWxkLl9mLnJlZnMgfHwgW107XG4gICAgICAgICAgICAgICAgICAgIGlmIChyYWRpb09yQ2hlY2tib3hcbiAgICAgICAgICAgICAgICAgICAgICAgID8gcmVmcy5maW5kKChvcHRpb24pID0+IG9wdGlvbiA9PT0gZmllbGRSZWYpXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGZpZWxkUmVmID09PSBmaWVsZC5fZi5yZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdGaWVsZCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZpZWxkLl9mLFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBpZiAocmFkaW9PckNoZWNrYm94KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdGaWVsZC5yZWZzID0gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnJlZnMuZmlsdGVyKGxpdmUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkUmVmLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihBcnJheS5pc0FycmF5KGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gW3t9XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFtdKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdGaWVsZC5yZWYgPSB7IHR5cGU6IGZpZWxkUmVmLnR5cGUsIG5hbWUgfTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld0ZpZWxkLnJlZiA9IGZpZWxkUmVmO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG5ld0ZpZWxkLnJlZnM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgc2V0KF9maWVsZHMsIG5hbWUsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9mOiBuZXdGaWVsZCxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZVZhbGlkQW5kVmFsdWUobmFtZSwgZmFsc2UsIHVuZGVmaW5lZCwgZmllbGRSZWYpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSwge30pO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLm1vdW50ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgKF9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgfHwgb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgIShpc05hbWVJbkZpZWxkQXJyYXkoX25hbWVzLmFycmF5LCBuYW1lKSAmJiBfc3RhdGUuYWN0aW9uKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgX25hbWVzLnVuTW91bnQuYWRkKG5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCBfZm9jdXNFcnJvciA9ICgpID0+IF9vcHRpb25zLnNob3VsZEZvY3VzRXJyb3IgJiZcbiAgICAgICAgIV9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24gJiZcbiAgICAgICAgaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKF9maWVsZHMsIF9mb2N1c0lucHV0LCBfbmFtZXMubW91bnQpO1xuICAgIGNvbnN0IF9kaXNhYmxlRm9ybSA9IChkaXNhYmxlZCkgPT4ge1xuICAgICAgICBpZiAoaXNCb29sZWFuKGRpc2FibGVkKSkge1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoeyBkaXNhYmxlZCB9KTtcbiAgICAgICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihfZmllbGRzLCAocmVmLCBuYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudEZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50RmllbGQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVmLmRpc2FibGVkID0gY3VycmVudEZpZWxkLl9mLmRpc2FibGVkIHx8IGRpc2FibGVkO1xuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjdXJyZW50RmllbGQuX2YucmVmcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRGaWVsZC5fZi5yZWZzLmZvckVhY2goKGlucHV0UmVmKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRSZWYuZGlzYWJsZWQgPSBjdXJyZW50RmllbGQuX2YuZGlzYWJsZWQgfHwgZGlzYWJsZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIDApO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVTdWJtaXQgPSAob25WYWxpZCwgb25JbnZhbGlkKSA9PiBhc3luYyAoZSkgPT4ge1xuICAgICAgICBsZXQgcmVzdWx0ID0gdW5kZWZpbmVkO1xuICAgICAgICBsZXQgb25WYWxpZEVycm9yID0gdW5kZWZpbmVkO1xuICAgICAgICBpZiAoZSkge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCAmJiBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICBlLnBlcnNpc3QgJiYgZS5wZXJzaXN0KCk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGZpZWxkVmFsdWVzID0gY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpO1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBpc1N1Ym1pdHRpbmc6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgY29uc3Qgb25TdWJtaXRFcnJvciA9IChlcnJvcikgPT4ge1xuICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkID09PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IGlzU3VibWl0dGluZzogZmFsc2UgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdGlvblJlc3VsdDtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdmFsaWRhdGlvblJlc3VsdCA9IGF3YWl0IF9ydW5TY2hlbWEoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIG9uU3VibWl0RXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgeyBlcnJvcnMsIHZhbHVlcyB9ID0gdmFsaWRhdGlvblJlc3VsdDtcbiAgICAgICAgICAgIGlmIChyZXNldENhbGxJZCAhPT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZygpO1xuICAgICAgICAgICAgT2JqZWN0LmtleXMoZGVsYXlFcnJvckNhbGxiYWNrcykuZm9yRWFjaChjYW5jZWxEZWxheWVkRXJyb3IpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSBlcnJvcnM7XG4gICAgICAgICAgICBmaWVsZFZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBFVkVOVFMuU1VCTUlULFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgb25TdWJtaXRFcnJvcihlcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBST09UX0VSUk9SX1RZUEUpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKF9uYW1lcy5kaXNhYmxlZC5zaXplKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgX25hbWVzLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoZmllbGRWYWx1ZXMsIG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUuZXJyb3JzKSkge1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIGVycm9yczoge30sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgb25WYWxpZChmaWVsZFZhbHVlcywgZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBvblZhbGlkRXJyb3IgPSBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGlmIChvbkludmFsaWQpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCBvbkludmFsaWQoeyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9LCBlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIG9uU3VibWl0RXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9mb2N1c0Vycm9yKCk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KF9mb2N1c0Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBpc1N1Ym1pdHRlZDogdHJ1ZSxcbiAgICAgICAgICAgIGlzU3VibWl0dGluZzogZmFsc2UsXG4gICAgICAgICAgICBpc1N1Ym1pdFN1Y2Nlc3NmdWw6IGlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS5lcnJvcnMpICYmICFvblZhbGlkRXJyb3IsXG4gICAgICAgICAgICBzdWJtaXRDb3VudDogX2Zvcm1TdGF0ZS5zdWJtaXRDb3VudCArIDEsXG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9uVmFsaWRFcnJvcikge1xuICAgICAgICAgICAgdGhyb3cgb25WYWxpZEVycm9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgICBjb25zdCByZXNldEZpZWxkID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBpZiAoZ2V0KF9maWVsZHMsIG5hbWUpKSB7XG4gICAgICAgICAgICBfdXBkYXRlVmFsaWRhdGluZ0ZpZWxkcyhbbmFtZV0pO1xuICAgICAgICAgICAgaWYgKGlzVW5kZWZpbmVkKG9wdGlvbnMuZGVmYXVsdFZhbHVlKSkge1xuICAgICAgICAgICAgICAgIHNldFZhbHVlKG5hbWUsIGNsb25lT2JqZWN0KGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNldFZhbHVlKG5hbWUsIG9wdGlvbnMuZGVmYXVsdFZhbHVlKTtcbiAgICAgICAgICAgICAgICBzZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIGNsb25lT2JqZWN0KG9wdGlvbnMuZGVmYXVsdFZhbHVlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMua2VlcFRvdWNoZWQpIHtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBEaXJ0eSkge1xuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9ICFpc1VuZGVmaW5lZChvcHRpb25zLmRlZmF1bHRWYWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgPyBfZ2V0RGlydHkobmFtZSwgY2xvbmVPYmplY3QoZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSkpXG4gICAgICAgICAgICAgICAgICAgIDogX2dldERpcnR5KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMua2VlcEVycm9yKSB7XG4gICAgICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yVHJlZShuYW1lKTtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICBpc1ZhbGlkYXRpbmc6ICFpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3Jlc2V0ID0gKGZvcm1WYWx1ZXMsIGtlZXBTdGF0ZU9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBfcmVzZXRDYWxsSWQrKztcbiAgICAgICAgX3NldFZhbGlkQ2FsbElkKys7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRWYWx1ZXMgPSBmb3JtVmFsdWVzID8gY2xvbmVPYmplY3QoZm9ybVZhbHVlcykgOiBfZGVmYXVsdFZhbHVlcztcbiAgICAgICAgY29uc3QgY2xvbmVVcGRhdGVkVmFsdWVzID0gY2xvbmVPYmplY3QodXBkYXRlZFZhbHVlcyk7XG4gICAgICAgIGNvbnN0IGlzRW1wdHlSZXNldFZhbHVlcyA9IGlzRW1wdHlPYmplY3QoZm9ybVZhbHVlcyk7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IGNsb25lVXBkYXRlZFZhbHVlcztcbiAgICAgICAgY29uc3QgZmllbGRSZWZzID0gX2ZpZWxkcztcbiAgICAgICAgT2JqZWN0LmtleXMoZGVsYXlFcnJvckNhbGxiYWNrcykuZm9yRWFjaChjYW5jZWxEZWxheWVkRXJyb3IpO1xuICAgICAgICBpZiAoIWtlZXBTdGF0ZU9wdGlvbnMua2VlcERlZmF1bHRWYWx1ZXMpIHtcbiAgICAgICAgICAgIF9kZWZhdWx0VmFsdWVzID0gdXBkYXRlZFZhbHVlcztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWtlZXBTdGF0ZU9wdGlvbnMua2VlcFZhbHVlcykge1xuICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRzVG9DaGVjayA9IG5ldyBTZXQoW1xuICAgICAgICAgICAgICAgICAgICAuLi5fbmFtZXMubW91bnQsXG4gICAgICAgICAgICAgICAgICAgIC4uLmNvbGxlY3REaXJ0eUZpZWxkTmFtZXMoZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIGZpZWxkUmVmcyksIF9mb3JtU3RhdGUuZGlydHlGaWVsZHMpLFxuICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIGZpZWxkc1RvQ2hlY2spIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNEaXJ0eSA9IGdldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBleGlzdGluZ1ZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdWYWx1ZSA9IGdldCh2YWx1ZXMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0RpcnR5ICYmICFpc1VuZGVmaW5lZChleGlzdGluZ1ZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0KHZhbHVlcywgZmllbGROYW1lLCBleGlzdGluZ1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghaXNEaXJ0eSAmJiAhaXNVbmRlZmluZWQobmV3VmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRWYWx1ZShmaWVsZE5hbWUsIG5ld1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChpc1dlYiAmJiBpc1VuZGVmaW5lZChmb3JtVmFsdWVzKSkge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gQXJyYXkuaXNBcnJheShmaWVsZC5fZi5yZWZzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGZpZWxkLl9mLnJlZnNbMF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmaWVsZC5fZi5yZWY7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzSFRNTEVsZW1lbnQoZmllbGRSZWZlcmVuY2UpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvcm0gPSBmaWVsZFJlZmVyZW5jZS5jbG9zZXN0KCdmb3JtJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmb3JtKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtLnJlc2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoa2VlcFN0YXRlT3B0aW9ucy5rZWVwRmllbGRzUmVmKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoZmllbGROYW1lLCBnZXQodmFsdWVzLCBmaWVsZE5hbWUpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgX2ZpZWxkcyA9IHt9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyKSB7XG4gICAgICAgICAgICAgICAgX2Zvcm1WYWx1ZXMgPSBrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgICAgID8gY2xvbmVPYmplY3QoX2RlZmF1bHRWYWx1ZXMpXG4gICAgICAgICAgICAgICAgICAgIDoge307XG4gICAgICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcEZpZWxkc1JlZikge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBfbmFtZXMubW91bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgZmllbGROYW1lLCBnZXQodmFsdWVzLCBmaWVsZE5hbWUpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIF9mb3JtVmFsdWVzID0gY2xvbmVPYmplY3QodmFsdWVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9zdWJqZWN0cy5hcnJheS5uZXh0KHtcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IHsgLi4udmFsdWVzIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdHlwZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHZhbHVlczogeyAuLi52YWx1ZXMgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIF9uYW1lcyA9IHtcbiAgICAgICAgICAgIG1vdW50OiBrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVZhbHVlcyA/IF9uYW1lcy5tb3VudCA6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIHVuTW91bnQ6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIGFycmF5OiBuZXcgU2V0KCksXG4gICAgICAgICAgICByZWdpc3Rlck5hbWU6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIGRpc2FibGVkOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBWYWx1ZXMgfHxcbiAgICAgICAgICAgICAgICBrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVZhbHVlcyB8fFxuICAgICAgICAgICAgICAgIGtlZXBTdGF0ZU9wdGlvbnMua2VlcEZpZWxkc1JlZlxuICAgICAgICAgICAgICAgID8gbmV3IFNldChbLi4uX25hbWVzLmRpc2FibGVkXS5maWx0ZXIoKG5hbWUpID0+IGdldChfZmllbGRzLCBuYW1lKSkpXG4gICAgICAgICAgICAgICAgOiBuZXcgU2V0KCksXG4gICAgICAgICAgICB3YXRjaDogbmV3IFNldCgpLFxuICAgICAgICAgICAgd2F0Y2hBbGw6IGZhbHNlLFxuICAgICAgICAgICAgZm9jdXM6ICcnLFxuICAgICAgICB9O1xuICAgICAgICBfc3RhdGUubW91bnQgPVxuICAgICAgICAgICAgIV9wcm94eUZvcm1TdGF0ZS5pc1ZhbGlkIHx8XG4gICAgICAgICAgICAgICAgISFrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1ZhbGlkIHx8XG4gICAgICAgICAgICAgICAgISFrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVZhbHVlcyB8fFxuICAgICAgICAgICAgICAgICghX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciAmJiAhaXNFbXB0eU9iamVjdCh2YWx1ZXMpKTtcbiAgICAgICAgX3N0YXRlLndhdGNoID0gISFfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyO1xuICAgICAgICBfc3RhdGUua2VlcElzVmFsaWQgPSAhIWtlZXBTdGF0ZU9wdGlvbnMua2VlcElzVmFsaWQ7XG4gICAgICAgIF9zdGF0ZS5hY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5jbGVhcigpO1xuICAgICAgICBfZGlydHlGaWVsZHNTdGFsZSA9IGZhbHNlO1xuICAgICAgICBpZiAoIWtlZXBTdGF0ZU9wdGlvbnMua2VlcEVycm9ycykge1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7fTtcbiAgICAgICAgfVxuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBzdWJtaXRDb3VudDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwU3VibWl0Q291bnRcbiAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuc3VibWl0Q291bnRcbiAgICAgICAgICAgICAgICA6IDAsXG4gICAgICAgICAgICBpc0RpcnR5OiBpc0VtcHR5UmVzZXRWYWx1ZXNcbiAgICAgICAgICAgICAgICA/IGZhbHNlXG4gICAgICAgICAgICAgICAgOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVxuICAgICAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuaXNEaXJ0eVxuICAgICAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcFZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBfZ2V0RGlydHkoKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiAhIShrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybVZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICFkZWVwRXF1YWwoZm9ybVZhbHVlcywgX2RlZmF1bHRWYWx1ZXMpKSxcbiAgICAgICAgICAgIGlzU3VibWl0dGVkOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1N1Ym1pdHRlZFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5pc1N1Ym1pdHRlZFxuICAgICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBkaXJ0eUZpZWxkczogKGlzRW1wdHlSZXNldFZhbHVlc1xuICAgICAgICAgICAgICAgID8ge31cbiAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzXG4gICAgICAgICAgICAgICAgICAgID8ga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJiBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBnZXREaXJ0eUZpZWxkcyhfZGVmYXVsdFZhbHVlcywgX2Zvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgZmllbGRSZWZzKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBfZm9ybVN0YXRlLmRpcnR5RmllbGRzXG4gICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJiBmb3JtVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBmb3JtVmFsdWVzLCB1bmRlZmluZWQsIGZpZWxkUmVmcylcbiAgICAgICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuZGlydHlGaWVsZHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcFZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBmaWVsZFJlZnMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgdG91Y2hlZEZpZWxkczoga2VlcFN0YXRlT3B0aW9ucy5rZWVwVG91Y2hlZFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzXG4gICAgICAgICAgICAgICAgOiB7fSxcbiAgICAgICAgICAgIC4uLigha2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNWYWxpZGF0aW5nICYmXG4gICAgICAgICAgICAgICAgKF9mb3JtU3RhdGUuaXNWYWxpZGF0aW5nIHx8ICFpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcykpXG4gICAgICAgICAgICAgICAgPyB7IHZhbGlkYXRpbmdGaWVsZHM6IHt9LCBpc1ZhbGlkYXRpbmc6IGZhbHNlIH1cbiAgICAgICAgICAgICAgICA6IG51bGwpLFxuICAgICAgICAgICAgZXJyb3JzOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBFcnJvcnMgPyBfZm9ybVN0YXRlLmVycm9ycyA6IHt9LFxuICAgICAgICAgICAgaXNTdWJtaXRTdWNjZXNzZnVsOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1N1Ym1pdFN1Y2Nlc3NmdWxcbiAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuaXNTdWJtaXRTdWNjZXNzZnVsXG4gICAgICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgICAgICAgIGlzU3VibWl0dGluZzogZmFsc2UsXG4gICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBfZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCByZXNldCA9IChmb3JtVmFsdWVzLCBrZWVwU3RhdGVPcHRpb25zKSA9PiBfcmVzZXQoaXNGdW5jdGlvbihmb3JtVmFsdWVzKSA/IGZvcm1WYWx1ZXMoX2Zvcm1WYWx1ZXMpIDogZm9ybVZhbHVlcywge1xuICAgICAgICAuLi5fb3B0aW9ucy5yZXNldE9wdGlvbnMsXG4gICAgICAgIC4uLmtlZXBTdGF0ZU9wdGlvbnMsXG4gICAgfSk7XG4gICAgY29uc3Qgc2V0Rm9jdXMgPSAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBjb25zdCBmaWVsZFJlZmVyZW5jZSA9IGZpZWxkICYmIGZpZWxkLl9mO1xuICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmID0gKGZpZWxkUmVmZXJlbmNlLnJlZnMgPyBmaWVsZFJlZmVyZW5jZS5yZWZzWzBdIDogZmllbGRSZWZlcmVuY2UucmVmKTtcbiAgICAgICAgICAgIGlmIChmaWVsZFJlZi5mb2N1cykge1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZi5mb2N1cygpO1xuICAgICAgICAgICAgICAgICAgICBvcHRpb25zLnNob3VsZFNlbGVjdCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgaXNGdW5jdGlvbihmaWVsZFJlZi5zZWxlY3QpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZi5zZWxlY3QoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldEZvcm1TdGF0ZSA9ICh1cGRhdGVkRm9ybVN0YXRlKSA9PiB7XG4gICAgICAgIC8vIGBuYW1lYCwgYHR5cGVgLCBhbmQgYHZhbHVlc2AgZGVzY3JpYmUgdGhlIGV2ZW50IHRoYXQgcHJvZHVjZWQgdGhpc1xuICAgICAgICAvLyB1cGRhdGUsIG5vdCB0aGUgZm9ybSdzIHBlcnNpc3RlZCBzdGF0ZSAodGhleSBhcmVuJ3QgcGFydCBvZlxuICAgICAgICAvLyBgRm9ybVN0YXRlYCkuIE1lcmdpbmcgdGhlbSBpbiB3b3VsZCBsZWFrIGEgc3RhbGUgYG5hbWVgL2B0eXBlYCBmcm9tXG4gICAgICAgIC8vIG9uZSBldmVudCBpbnRvIGEgbGF0ZXIsIHVucmVsYXRlZCBub3RpZmljYXRpb24gdGhhdCBkb2Vzbid0IHNwZWNpZnlcbiAgICAgICAgLy8gaXRzIG93bi5cbiAgICAgICAgY29uc3QgeyBuYW1lLCB0eXBlLCB2YWx1ZXMsIC4uLmZvcm1TdGF0ZSB9ID0gdXBkYXRlZEZvcm1TdGF0ZTtcbiAgICAgICAgaWYgKE9iamVjdC5rZXlzKGZvcm1TdGF0ZSkubGVuZ3RoKSB7XG4gICAgICAgICAgICBfZm9ybVN0YXRlID0ge1xuICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgLi4uZm9ybVN0YXRlLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgX3N1YmplY3RzLnN0YXRlLnN1YnNjcmliZSh7IG5leHQ6IF9zZXRGb3JtU3RhdGUgfSk7XG4gICAgY29uc3QgX3Jlc2V0RGVmYXVsdFZhbHVlcyA9ICgpID0+IGlzRnVuY3Rpb24oX29wdGlvbnMuZGVmYXVsdFZhbHVlcykgJiZcbiAgICAgICAgX29wdGlvbnMuZGVmYXVsdFZhbHVlcygpLnRoZW4oKHZhbHVlcykgPT4ge1xuICAgICAgICAgICAgcmVzZXQodmFsdWVzLCBfb3B0aW9ucy5yZXNldE9wdGlvbnMpO1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIGlzTG9hZGluZzogZmFsc2UsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgY29uc3QgcmVzZXREZWZhdWx0VmFsdWVzID0gKHZhbHVlcywgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIF9kZWZhdWx0VmFsdWVzID0gY2xvbmVPYmplY3QodmFsdWVzKTtcbiAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBEaXJ0eSkge1xuICAgICAgICAgICAgY29uc3QgbmV3RGlydHlGaWVsZHMgPSBnZXREaXJ0eUZpZWxkcyhfZGVmYXVsdFZhbHVlcywgX2Zvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgX2ZpZWxkcyk7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmRpcnR5RmllbGRzID0gbmV3RGlydHlGaWVsZHM7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSAhaXNFbXB0eU9iamVjdChuZXdEaXJ0eUZpZWxkcyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBJc1ZhbGlkKSB7XG4gICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgfVxuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgbWV0aG9kcyA9IHtcbiAgICAgICAgY29udHJvbDoge1xuICAgICAgICAgICAgcmVnaXN0ZXIsXG4gICAgICAgICAgICB1bnJlZ2lzdGVyLFxuICAgICAgICAgICAgZ2V0RmllbGRTdGF0ZSxcbiAgICAgICAgICAgIGhhbmRsZVN1Ym1pdCxcbiAgICAgICAgICAgIHNldEVycm9yLFxuICAgICAgICAgICAgX3N1YnNjcmliZSxcbiAgICAgICAgICAgIF9ydW5TY2hlbWEsXG4gICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nLFxuICAgICAgICAgICAgX2ZvY3VzRXJyb3IsXG4gICAgICAgICAgICBfZ2V0V2F0Y2gsXG4gICAgICAgICAgICBfZ2V0RGlydHksXG4gICAgICAgICAgICBfc2V0VmFsaWQsXG4gICAgICAgICAgICBfc2V0RmllbGRBcnJheSxcbiAgICAgICAgICAgIF9zZXREaXNhYmxlZEZpZWxkLFxuICAgICAgICAgICAgX3NldEVycm9ycyxcbiAgICAgICAgICAgIF9nZXRGaWVsZEFycmF5LFxuICAgICAgICAgICAgX3Jlc2V0LFxuICAgICAgICAgICAgX3Jlc2V0RGVmYXVsdFZhbHVlcyxcbiAgICAgICAgICAgIF9yZW1vdmVVbm1vdW50ZWQsXG4gICAgICAgICAgICBfZGlzYWJsZUZvcm0sXG4gICAgICAgICAgICBfc3ViamVjdHMsXG4gICAgICAgICAgICBfcHJveHlGb3JtU3RhdGUsXG4gICAgICAgICAgICBnZXQgX2ZpZWxkcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2ZpZWxkcztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX2Zvcm1WYWx1ZXMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9mb3JtVmFsdWVzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfc3RhdGUoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9zdGF0ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXQgX3N0YXRlKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgX3N0YXRlID0gdmFsdWU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9kZWZhdWx0VmFsdWVzKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfZGVmYXVsdFZhbHVlcztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX25hbWVzKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfbmFtZXM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2V0IF9uYW1lcyh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF9uYW1lcyA9IHZhbHVlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfZm9ybVN0YXRlKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfZm9ybVN0YXRlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfb3B0aW9ucygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX29wdGlvbnM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2V0IF9vcHRpb25zKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgX29wdGlvbnMgPSB7XG4gICAgICAgICAgICAgICAgICAgIC4uLl9vcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAuLi52YWx1ZSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIF92YWxpZGF0aW9uTW9kZUJlZm9yZVN1Ym1pdCA9IGdldFZhbGlkYXRpb25Nb2Rlcyhfb3B0aW9ucy5tb2RlKTtcbiAgICAgICAgICAgICAgICBfdmFsaWRhdGlvbk1vZGVBZnRlclN1Ym1pdCA9IGdldFZhbGlkYXRpb25Nb2Rlcyhfb3B0aW9ucy5yZVZhbGlkYXRlTW9kZSk7XG4gICAgICAgICAgICAgICAgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMgPVxuICAgICAgICAgICAgICAgICAgICBfb3B0aW9ucy5jcml0ZXJpYU1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5hbGw7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBzdWJzY3JpYmUsXG4gICAgICAgIHRyaWdnZXIsXG4gICAgICAgIHJlZ2lzdGVyLFxuICAgICAgICBoYW5kbGVTdWJtaXQsXG4gICAgICAgIHdhdGNoLFxuICAgICAgICBzZXRWYWx1ZSxcbiAgICAgICAgc2V0VmFsdWVzLFxuICAgICAgICBnZXRWYWx1ZXMsXG4gICAgICAgIGdldEVycm9ycyxcbiAgICAgICAgcmVzZXQsXG4gICAgICAgIHJlc2V0RmllbGQsXG4gICAgICAgIHJlc2V0RGVmYXVsdFZhbHVlcyxcbiAgICAgICAgY2xlYXJFcnJvcnMsXG4gICAgICAgIHVucmVnaXN0ZXIsXG4gICAgICAgIHNldEVycm9yLFxuICAgICAgICBzZXRGb2N1cyxcbiAgICAgICAgZ2V0RmllbGRTdGF0ZSxcbiAgICB9O1xuICAgIHJldHVybiB7XG4gICAgICAgIC4uLm1ldGhvZHMsXG4gICAgICAgIGZvcm1Db250cm9sOiBtZXRob2RzLFxuICAgIH07XG59XG5cbmNvbnN0IFJFU0VUX09QVElPTlMgPSB7XG4gICAgbW9kZTogZGVmYXVsdE9wdGlvbnMubW9kZSxcbiAgICByZVZhbGlkYXRlTW9kZTogZGVmYXVsdE9wdGlvbnMucmVWYWxpZGF0ZU1vZGUsXG4gICAgc2hvdWxkRm9jdXNFcnJvcjogZGVmYXVsdE9wdGlvbnMuc2hvdWxkRm9jdXNFcnJvcixcbiAgICByZXNvbHZlcjogdW5kZWZpbmVkLFxuICAgIGNyaXRlcmlhTW9kZTogdW5kZWZpbmVkLFxuICAgIGRlbGF5RXJyb3I6IHVuZGVmaW5lZCxcbiAgICBzaG91bGRVbnJlZ2lzdGVyOiB1bmRlZmluZWQsXG4gICAgc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbjogdW5kZWZpbmVkLFxuICAgIGNvbnRleHQ6IHVuZGVmaW5lZCxcbiAgICBwcm9ncmVzc2l2ZTogdW5kZWZpbmVkLFxuICAgIHJlc2V0T3B0aW9uczogdW5kZWZpbmVkLFxufTtcbi8qKlxuICogQ29yZSBob29rIGZvciBtYW5hZ2luZyBhIGZvcm0uIFJldHVybnMgYWxsIG1ldGhvZHMgYW5kIHN0YXRlIGZvclxuICogcmVnaXN0cmF0aW9uLCB2YWxpZGF0aW9uLCBhbmQgc3VibWlzc2lvbi5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm0pXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCBmb3JtU3RhdGU6IHsgZXJyb3JzIH0gfSA9IHVzZUZvcm08Rm9ybVZhbHVlcz4oKTtcbiAqIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfT5cbiAqICAgPGlucHV0IHsuLi5yZWdpc3RlcihcImVtYWlsXCIsIHsgcmVxdWlyZWQ6IHRydWUgfSl9IC8+XG4gKiA8L2Zvcm0+XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlRm9ybShwcm9wcyA9IHt9KSB7XG4gICAgY29uc3QgX2Zvcm1Db250cm9sID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gICAgY29uc3QgX3ZhbHVlcyA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICAgIGNvbnN0IF9mb3JtQ29udHJvbFByb3AgPSBSZWFjdC51c2VSZWYocHJvcHMuZm9ybUNvbnRyb2wpO1xuICAgIGNvbnN0IF9oYWREaXNhYmxlZCA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgX2hhZFZhbGlkYXRlID0gUmVhY3QudXNlUmVmKCEhcHJvcHMudmFsaWRhdGUpO1xuICAgIGNvbnN0IF9oYWRFcnJvcnMgPSBSZWFjdC51c2VSZWYoISFwcm9wcy5lcnJvcnMpO1xuICAgIGNvbnN0IF9pc01vdW50ZWQgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IFtmb3JtU3RhdGUsIHVwZGF0ZUZvcm1TdGF0ZV0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiAoe1xuICAgICAgICAuLi5jbG9uZU9iamVjdChERUZBVUxUX0ZPUk1fU1RBVEUpLFxuICAgICAgICBpc0xvYWRpbmc6IGlzRnVuY3Rpb24ocHJvcHMuZGVmYXVsdFZhbHVlcyksXG4gICAgICAgIGVycm9yczogcHJvcHMuZXJyb3JzIHx8IHt9LFxuICAgICAgICBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQgfHwgZmFsc2UsXG4gICAgICAgIGRlZmF1bHRWYWx1ZXM6IGlzRnVuY3Rpb24ocHJvcHMuZGVmYXVsdFZhbHVlcylcbiAgICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgICA6IHByb3BzLmRlZmF1bHRWYWx1ZXMsXG4gICAgfSkpO1xuICAgIGlmICghX2Zvcm1Db250cm9sLmN1cnJlbnQgfHxcbiAgICAgICAgKHByb3BzLmZvcm1Db250cm9sICYmIF9mb3JtQ29udHJvbFByb3AuY3VycmVudCAhPT0gcHJvcHMuZm9ybUNvbnRyb2wpKSB7XG4gICAgICAgIF9mb3JtQ29udHJvbFByb3AuY3VycmVudCA9IHByb3BzLmZvcm1Db250cm9sO1xuICAgICAgICBfaGFkRGlzYWJsZWQuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBpZiAocHJvcHMuZm9ybUNvbnRyb2wpIHtcbiAgICAgICAgICAgIF9mb3JtQ29udHJvbC5jdXJyZW50ID0ge1xuICAgICAgICAgICAgICAgIC4uLnByb3BzLmZvcm1Db250cm9sLFxuICAgICAgICAgICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAocHJvcHMuZGVmYXVsdFZhbHVlcyAmJiAhaXNGdW5jdGlvbihwcm9wcy5kZWZhdWx0VmFsdWVzKSkge1xuICAgICAgICAgICAgICAgIHByb3BzLmZvcm1Db250cm9sLnJlc2V0KHByb3BzLmRlZmF1bHRWYWx1ZXMsIHByb3BzLnJlc2V0T3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zdCB7IGZvcm1Db250cm9sLCAuLi5yZXN0IH0gPSBjcmVhdGVGb3JtQ29udHJvbChwcm9wcyk7XG4gICAgICAgICAgICBfZm9ybUNvbnRyb2wuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0LFxuICAgICAgICAgICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgY29udHJvbCA9IF9mb3JtQ29udHJvbC5jdXJyZW50LmNvbnRyb2w7XG4gICAgY29uc3QgcHJldmlvdXNPcHRpb25zID0gY29udHJvbC5fb3B0aW9ucztcbiAgICBjb25zdCByZW1vdmVkT3B0aW9ucyA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IGluIFJFU0VUX09QVElPTlMpIHtcbiAgICAgICAgaWYgKGtleSBpbiBwcmV2aW91c09wdGlvbnMgJiYgIShrZXkgaW4gcHJvcHMpKSB7XG4gICAgICAgICAgICByZW1vdmVkT3B0aW9uc1trZXldID0gUkVTRVRfT1BUSU9OU1trZXldO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChfaGFkRGlzYWJsZWQuY3VycmVudCAmJiAhcHJvcHMuZGlzYWJsZWQpIHtcbiAgICAgICAgcmVtb3ZlZE9wdGlvbnMuZGlzYWJsZWQgPSBmYWxzZTtcbiAgICB9XG4gICAgY29udHJvbC5fb3B0aW9ucyA9IHtcbiAgICAgICAgLi4ucmVtb3ZlZE9wdGlvbnMsXG4gICAgICAgIC4uLnByb3BzLFxuICAgICAgICB2YWxpZGF0ZTogcHJvcHMudmFsaWRhdGUsXG4gICAgfTtcbiAgICBjb25zdCBnZXRDdXJyZW50Rm9ybVN0YXRlID0gKCkgPT4gKHtcbiAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICBkZWZhdWx0VmFsdWVzOiBjb250cm9sLl9kZWZhdWx0VmFsdWVzLFxuICAgIH0pO1xuICAgIGNvbnN0IHsgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90IH0gPSB1c2VSZXN5bmNPblJlY29ubmVjdChnZXRDdXJyZW50Rm9ybVN0YXRlKTtcbiAgICB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgcmVzeW5jSWZOZWVkZWQodHJ1ZSwgZ2V0Q3VycmVudEZvcm1TdGF0ZSwgdXBkYXRlRm9ybVN0YXRlKTtcbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgZm9ybVN0YXRlOiBjb250cm9sLl9wcm94eUZvcm1TdGF0ZSxcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PiB1cGRhdGVGb3JtU3RhdGUoe1xuICAgICAgICAgICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBjb250cm9sLl9kZWZhdWx0VmFsdWVzLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICByZVJlbmRlclJvb3Q6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB1cGRhdGVGb3JtU3RhdGUoKGRhdGEpID0+ICh7XG4gICAgICAgICAgICAuLi5kYXRhLFxuICAgICAgICAgICAgaXNSZWFkeTogdHJ1ZSxcbiAgICAgICAgfSkpO1xuICAgICAgICBjb250cm9sLl9mb3JtU3RhdGUuaXNSZWFkeSA9IHRydWU7XG4gICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoeyBpc1JlYWR5OiB0cnVlIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNuYXBzaG90KHRydWUsIGdldEN1cnJlbnRGb3JtU3RhdGUpO1xuICAgICAgICB9O1xuICAgIH0sIFtjb250cm9sLCByZXN5bmNJZk5lZWRlZCwgc25hcHNob3RdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb250cm9sLl9kaXNhYmxlRm9ybShfaGFkRGlzYWJsZWQuY3VycmVudCAmJiAhcHJvcHMuZGlzYWJsZWQgPyBmYWxzZSA6IHByb3BzLmRpc2FibGVkKTtcbiAgICAgICAgX2hhZERpc2FibGVkLmN1cnJlbnQgPSAhIXByb3BzLmRpc2FibGVkO1xuICAgIH0sIFtjb250cm9sLCBwcm9wcy5kaXNhYmxlZF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChwcm9wcy5tb2RlKSB7XG4gICAgICAgICAgICBjb250cm9sLl9vcHRpb25zLm1vZGUgPSBwcm9wcy5tb2RlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwcm9wcy5yZVZhbGlkYXRlTW9kZSkge1xuICAgICAgICAgICAgY29udHJvbC5fb3B0aW9ucy5yZVZhbGlkYXRlTW9kZSA9IHByb3BzLnJlVmFsaWRhdGVNb2RlO1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLm1vZGUsIHByb3BzLnJlVmFsaWRhdGVNb2RlXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKHByb3BzLmVycm9ycykge1xuICAgICAgICAgICAgY29udHJvbC5fc2V0RXJyb3JzKHByb3BzLmVycm9ycyk7XG4gICAgICAgICAgICBjb250cm9sLl9mb2N1c0Vycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoX2hhZEVycm9ycy5jdXJyZW50KSB7XG4gICAgICAgICAgICBjb250cm9sLl9zZXRFcnJvcnMoe30pO1xuICAgICAgICB9XG4gICAgICAgIF9oYWRFcnJvcnMuY3VycmVudCA9ICEhcHJvcHMuZXJyb3JzO1xuICAgIH0sIFtjb250cm9sLCBwcm9wcy5lcnJvcnNdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoX2hhZFZhbGlkYXRlLmN1cnJlbnQgJiYgIXByb3BzLnZhbGlkYXRlKSB7XG4gICAgICAgICAgICBfZm9ybUNvbnRyb2wuY3VycmVudCAmJiBfZm9ybUNvbnRyb2wuY3VycmVudC5jbGVhckVycm9ycyhGT1JNX0VSUk9SX1RZUEUpO1xuICAgICAgICB9XG4gICAgICAgIF9oYWRWYWxpZGF0ZS5jdXJyZW50ID0gISFwcm9wcy52YWxpZGF0ZTtcbiAgICB9LCBbcHJvcHMudmFsaWRhdGVdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBwcm9wcy5zaG91bGRVbnJlZ2lzdGVyICYmXG4gICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IGNvbnRyb2wuX2dldFdhdGNoKCksXG4gICAgICAgICAgICB9KTtcbiAgICB9LCBbY29udHJvbCwgcHJvcHMuc2hvdWxkVW5yZWdpc3Rlcl0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChjb250cm9sLl9wcm94eUZvcm1TdGF0ZS5pc0RpcnR5KSB7XG4gICAgICAgICAgICBjb25zdCBpc0RpcnR5ID0gY29udHJvbC5fZ2V0RGlydHkoKTtcbiAgICAgICAgICAgIGlmIChpc0RpcnR5ICE9PSBmb3JtU3RhdGUuaXNEaXJ0eSkge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBpc0RpcnR5LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wsIGZvcm1TdGF0ZS5pc0RpcnR5XSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKHByb3BzLnZhbHVlcyAmJiAhZGVlcEVxdWFsKHByb3BzLnZhbHVlcywgX3ZhbHVlcy5jdXJyZW50KSkge1xuICAgICAgICAgICAgY29udHJvbC5fcmVzZXQocHJvcHMudmFsdWVzLCB7XG4gICAgICAgICAgICAgICAga2VlcEZpZWxkc1JlZjogdHJ1ZSxcbiAgICAgICAgICAgICAgICAuLi5jb250cm9sLl9vcHRpb25zLnJlc2V0T3B0aW9ucyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKCEoY29udHJvbC5fb3B0aW9ucy5yZXNldE9wdGlvbnMgJiZcbiAgICAgICAgICAgICAgICBjb250cm9sLl9vcHRpb25zLnJlc2V0T3B0aW9ucy5rZWVwSXNWYWxpZCkpIHtcbiAgICAgICAgICAgICAgICBjb250cm9sLl9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3ZhbHVlcy5jdXJyZW50ID0gcHJvcHMudmFsdWVzO1xuICAgICAgICAgICAgdXBkYXRlRm9ybVN0YXRlKChzdGF0ZSkgPT4gKHsgLi4uc3RhdGUgfSkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29udHJvbC5fcmVzZXREZWZhdWx0VmFsdWVzKCk7XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbCwgcHJvcHMudmFsdWVzXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFjb250cm9sLl9zdGF0ZS5tb3VudCB8fCAoIV9pc01vdW50ZWQuY3VycmVudCAmJiAhcHJvcHMudmFsdWVzKSkge1xuICAgICAgICAgICAgY29udHJvbC5fc2V0VmFsaWQoKTtcbiAgICAgICAgICAgIGNvbnRyb2wuX3N0YXRlLm1vdW50ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBfaXNNb3VudGVkLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBpZiAoY29udHJvbC5fc3RhdGUud2F0Y2gpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3N0YXRlLndhdGNoID0gZmFsc2U7XG4gICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgLi4uY29udHJvbC5fZm9ybVN0YXRlIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRyb2wuX3JlbW92ZVVubW91bnRlZCgpO1xuICAgIH0pO1xuICAgIF9mb3JtQ29udHJvbC5jdXJyZW50LmZvcm1TdGF0ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gZ2V0UHJveHlGb3JtU3RhdGUoZm9ybVN0YXRlLCBjb250cm9sKSwgW2NvbnRyb2wsIGZvcm1TdGF0ZV0pO1xuICAgIHJldHVybiBfZm9ybUNvbnRyb2wuY3VycmVudDtcbn1cblxuY29uc3QgSG9va0Zvcm1Db250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbkhvb2tGb3JtQ29udGV4dC5kaXNwbGF5TmFtZSA9ICdIb29rRm9ybUNvbnRleHQnO1xuLyoqXG4gKiBSZXRyaWV2ZXMgYWxsIGB1c2VGb3JtYCBtZXRob2RzIGZyb20gdGhlIG5lYXJlc3QgYEZvcm1Qcm92aWRlcmAuXG4gKiBVc2UgaW4gZGVlcGx5IG5lc3RlZCBjb21wb25lbnRzIHRvIGF2b2lkIHByb3AtZHJpbGxpbmcuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3JtY29udGV4dClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCB7IHJlZ2lzdGVyIH0gPSB1c2VGb3JtQ29udGV4dDxGb3JtVmFsdWVzPigpO1xuICogYGBgXG4gKi9cbmNvbnN0IHVzZUZvcm1Db250ZXh0ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChIb29rRm9ybUNvbnRleHQpO1xuLyoqXG4gKiBQcm92aWRlcyBhbGwgYHVzZUZvcm1gIG1ldGhvZHMgdG8gdGhlIGNvbXBvbmVudCB0cmVlIHZpYSBSZWFjdCBDb250ZXh0LlxuICogUGFpciB3aXRoIGB1c2VGb3JtQ29udGV4dGAgdG8gY29uc3VtZSB0aGVtIGluIGFueSBkZXNjZW5kYW50LlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybWNvbnRleHQpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogPEZvcm1Qcm92aWRlciB7Li4ubWV0aG9kc30+XG4gKiAgIDxmb3JtIG9uU3VibWl0PXttZXRob2RzLmhhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PntjaGlsZHJlbn08L2Zvcm0+XG4gKiA8L0Zvcm1Qcm92aWRlcj5cbiAqIGBgYFxuICovXG5jb25zdCBGb3JtUHJvdmlkZXIgPSAoeyBjaGlsZHJlbiwgd2F0Y2gsIGdldFZhbHVlcywgZ2V0RXJyb3JzLCBnZXRGaWVsZFN0YXRlLCBzZXRFcnJvciwgY2xlYXJFcnJvcnMsIHNldFZhbHVlLCBzZXRWYWx1ZXMsIHRyaWdnZXIsIGZvcm1TdGF0ZSwgcmVzZXRGaWVsZCwgcmVzZXQsIHJlc2V0RGVmYXVsdFZhbHVlcywgaGFuZGxlU3VibWl0LCB1bnJlZ2lzdGVyLCBjb250cm9sLCByZWdpc3Rlciwgc2V0Rm9jdXMsIHN1YnNjcmliZSwgfSkgPT4ge1xuICAgIGNvbnN0IG1lbW9pemVkVmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgICAgIHdhdGNoLFxuICAgICAgICBnZXRWYWx1ZXMsXG4gICAgICAgIGdldEVycm9ycyxcbiAgICAgICAgZ2V0RmllbGRTdGF0ZSxcbiAgICAgICAgc2V0RXJyb3IsXG4gICAgICAgIGNsZWFyRXJyb3JzLFxuICAgICAgICBzZXRWYWx1ZSxcbiAgICAgICAgc2V0VmFsdWVzLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgIHJlc2V0RmllbGQsXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgIGhhbmRsZVN1Ym1pdCxcbiAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgcmVnaXN0ZXIsXG4gICAgICAgIHNldEZvY3VzLFxuICAgICAgICBzdWJzY3JpYmUsXG4gICAgfSksIFtcbiAgICAgICAgY2xlYXJFcnJvcnMsXG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgZ2V0RXJyb3JzLFxuICAgICAgICBnZXRGaWVsZFN0YXRlLFxuICAgICAgICBnZXRWYWx1ZXMsXG4gICAgICAgIGhhbmRsZVN1Ym1pdCxcbiAgICAgICAgcmVnaXN0ZXIsXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgIHJlc2V0RmllbGQsXG4gICAgICAgIHNldEVycm9yLFxuICAgICAgICBzZXRGb2N1cyxcbiAgICAgICAgc2V0VmFsdWUsXG4gICAgICAgIHNldFZhbHVlcyxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICB1bnJlZ2lzdGVyLFxuICAgICAgICB3YXRjaCxcbiAgICBdKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoSG9va0Zvcm1Db250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBtZW1vaXplZFZhbHVlIH0sXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSG9va0Zvcm1Db250cm9sQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogbWVtb2l6ZWRWYWx1ZS5jb250cm9sIH0sIGNoaWxkcmVuKSkpO1xufTtcblxuLyoqXG4gKiBDb21wb25lbnQgd3JhcHBlciBhcm91bmQgYHVzZVdhdGNoYC4gUmUtcmVuZGVycyBvbmx5IHdoZW4gd2F0Y2hlZCBmaWVsZHMgY2hhbmdlLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNld2F0Y2gpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogPFdhdGNoXG4gKiAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gKiAgIG5hbWVzPXtbXCJmb29cIiwgXCJiYXJcIl19XG4gKiAgIHJlbmRlcj17KFtmb28sIGJhcl0pID0+IDxzcGFuPntmb299IHtiYXJ9PC9zcGFuPn1cbiAqIC8+XG4gKiBgYGBcbiAqL1xuY29uc3QgV2F0Y2ggPSAocHJvcHMpID0+IHByb3BzLnJlbmRlcih1c2VXYXRjaCh7IG5hbWU6IHByb3BzLm5hbWVzLCAuLi5wcm9wcyB9KSk7XG5cbmV4cG9ydCB7IENvbnRyb2xsZXIsIEVycm9yTWVzc2FnZSwgRmllbGRBcnJheSwgRm9ybSwgRm9ybVByb3ZpZGVyLCBGb3JtU3RhdGUsIEZvcm1TdGF0ZVN1YnNjcmliZSwgV2F0Y2gsIGFwcGVuZEVycm9ycywgY3JlYXRlRm9ybUNvbnRyb2wsIGdldCwgc2V0LCB1c2VDb250cm9sbGVyLCB1c2VGaWVsZEFycmF5LCB1c2VGb3JtLCB1c2VGb3JtQ29udGV4dCwgdXNlRm9ybVN0YXRlLCB1c2VXYXRjaCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguZXNtLm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUVBLElBQUksbUJBQW1CLFlBQVksUUFBUSxTQUFTO0FBRXBELElBQUksZUFBZSxZQUFZLFFBQVEsU0FBUztBQUVoRCxJQUFJLGdCQUFnQixVQUFVLGlCQUFpQjtBQUUvQyxJQUFJLHFCQUFxQixVQUFVLFNBQVM7QUFFNUMsSUFBTSxnQkFBZ0IsVUFBVSxPQUFPLFVBQVU7QUFDakQsSUFBSSxZQUFZLFVBQVUsQ0FBQyxrQkFBa0IsS0FBSyxLQUM5QyxDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQ3BCLGFBQWEsS0FBSyxLQUNsQixDQUFDLGFBQWEsS0FBSztBQUV2QixJQUFJLGlCQUFpQixVQUFVLFNBQVMsS0FBSyxLQUFLLE1BQU0sU0FDbEQsZ0JBQWdCLE1BQU0sTUFBTSxJQUN4QixNQUFNLE9BQU8sVUFDYixZQUFZLE1BQU0sTUFBTSxJQUNwQixNQUFNLE9BQU8sUUFDYixNQUFNLE9BQU8sUUFDckI7QUFFTixJQUFNLGdCQUFnQjtBQUN0QixJQUFJLGdCQUFnQixVQUFVLE1BQU0sTUFBTSxhQUFhLENBQUMsQ0FBQyxPQUFPLE9BQU87QUFFdkUsU0FBUyxxQkFBcUIsU0FBUyxNQUFNO0NBQ3pDLE1BQU0sV0FBVyxhQUFhLElBQUk7Q0FDbEMsSUFBSSxhQUFhLFFBQVE7Q0FDekIsSUFBSSxnQkFBZ0IsUUFBUTtDQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBSztFQUMxQyxNQUFNLE1BQU0sU0FBUztFQUNyQixhQUNJLGNBQWMsT0FDUixhQUNBLFdBQVc7RUFDckIsZ0JBQ0ksaUJBQWlCLE9BQ1gsZ0JBQ0EsY0FBYztFQUN4QixJQUFJLGVBQWUsUUFBUSxrQkFBa0IsTUFDekMsT0FBTztDQUVmO0FBRUo7QUFFQSxJQUFJLHNCQUFzQixPQUFPLFNBQVMsS0FDckMsTUFBTSxHQUFHLENBQUMsQ0FDVixNQUFNLE1BQU0sT0FBTyxRQUFRLENBQUMsTUFBTSxPQUFPLElBQUksQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0FBRWhHLElBQUksUUFBUSxPQUFPLFdBQVcsZUFDMUIsT0FBTyxPQUFPLGdCQUFnQixlQUM5QixPQUFPLGFBQWE7QUFFeEIsU0FBUyxZQUFZLE1BQU07Q0FDdkIsSUFBSSxTQUFTLFFBQVEsT0FBTyxTQUFTLFVBQ2pDLE9BQU87Q0FFWCxJQUFJLGdCQUFnQixNQUNoQixPQUFPLElBQUksS0FBSyxJQUFJO0NBRXhCLE1BQU0saUJBQWlCLE9BQU8sU0FBUyxlQUFlLGdCQUFnQjtDQUN0RSxNQUFNLHFCQUFxQixPQUFPLGFBQWEsZUFBZSxnQkFBZ0I7Q0FDOUUsSUFBSSxVQUFVLGtCQUFrQixxQkFDNUIsT0FBTztDQUVYLE1BQU0sVUFBVSxNQUFNLFFBQVEsSUFBSTtDQUNsQyxNQUFNLFlBQVksT0FBTyxlQUFlLElBQUk7Q0FDNUMsSUFBSSxDQUFDLFdBQVcsYUFBYSxVQUFVLGdCQUFnQixRQUNuRCxPQUFPO0NBRVgsTUFBTSxPQUFPLFVBQVUsSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLE9BQU8sT0FBTyxTQUFTO0NBQ3ZFLEtBQUssTUFBTSxPQUFPLE1BQ2QsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLE1BQU0sR0FBRyxHQUM5QyxLQUFLLE9BQU8sWUFBWSxLQUFLLElBQUk7Q0FHekMsT0FBTztBQUNYO0FBRUEsSUFBTSxTQUFTO0NBQ1gsTUFBTTtDQUNOLFdBQVc7Q0FDWCxRQUFRO0NBQ1IsUUFBUTtDQUNSLFNBQVM7Q0FDVCxPQUFPO0FBQ1g7QUFDQSxJQUFNLGtCQUFrQjtDQUNwQixRQUFRO0NBQ1IsVUFBVTtDQUNWLFVBQVU7Q0FDVixXQUFXO0NBQ1gsS0FBSztBQUNUO0FBQ0EsSUFBTSx5QkFBeUI7Q0FDM0IsS0FBSztDQUNMLEtBQUs7Q0FDTCxXQUFXO0NBQ1gsV0FBVztDQUNYLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsVUFBVTtBQUNkO0FBQ0EsSUFBTSw0QkFBNEI7Q0FDOUIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0FBQzNCO0FBQ0EsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxxQkFBcUI7Q0FBQztDQUFhO0NBQWU7QUFBVztBQUVuRSxJQUFNLFlBQVk7QUFDbEIsSUFBSSxTQUFTLFVBQVUsVUFBVSxLQUFLLEtBQUs7QUFFM0MsSUFBSSxlQUFlLFFBQVEsUUFBUSxLQUFBO0FBRW5DLElBQUksT0FBTyxRQUFRLE1BQU0saUJBQWlCO0NBQ3RDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxNQUFNLEdBQ3pCLE9BQU87Q0FFWCxNQUFNLFFBQVEsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksYUFBYSxJQUFJO0NBQ3RELElBQUksTUFBTSxNQUFNLFFBQVEsbUJBQW1CLFNBQVMsR0FBRyxDQUFDLEdBQ3BELE9BQU87Q0FFWCxNQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsUUFBUTtFQUN6QyxPQUFPLGtCQUFrQixNQUFNLElBQ3pCLEtBQUEsSUFDQSxPQUFPO0NBQ2pCLEdBQUcsTUFBTTtDQUNULE9BQVEsWUFBWSxNQUFNLEtBQUssV0FBVyxTQUNwQyxZQUFZLE9BQU8sS0FBSyxJQUNwQixlQUNBLE9BQU8sUUFDWDtBQUNWO0FBRUEsSUFBSSxhQUFhLFVBQVUsT0FBTyxVQUFVO0FBRTVDLElBQUksY0FBYyxVQUFVLE9BQU8sVUFBVTtBQUU3QyxJQUFJLE9BQU8sUUFBUSxNQUFNLFVBQVU7Q0FDL0IsSUFBSSxRQUFRO0NBQ1osTUFBTSxXQUFXLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLGFBQWEsSUFBSTtDQUN6RCxNQUFNLFNBQVMsU0FBUztDQUN4QixNQUFNLFlBQVksU0FBUztDQUMzQixPQUFPLEVBQUUsUUFBUSxRQUFRO0VBQ3JCLE1BQU0sTUFBTSxTQUFTO0VBQ3JCLElBQUksV0FBVztFQUNmLElBQUksVUFBVSxXQUFXO0dBQ3JCLE1BQU0sV0FBVyxPQUFPO0dBQ3hCLFdBQ0ksU0FBUyxRQUFRLEtBQUssTUFBTSxRQUFRLFFBQVEsSUFDdEMsV0FDQSxDQUFDLE1BQU0sQ0FBQyxTQUFTLFFBQVEsRUFBRSxJQUN2QixDQUFDLElBQ0QsQ0FBQztFQUNuQjtFQUNBLElBQUksbUJBQW1CLFNBQVMsR0FBRyxHQUMvQjtFQUVKLE9BQU8sT0FBTztFQUNkLFNBQVMsT0FBTztDQUNwQjtBQUNKOzs7OztBQU1BLElBQU0seUJBQUEsYUFBK0IsY0FBYyxJQUFJO0FBQ3ZELHVCQUF1QixjQUFjOzs7O0FBSXJDLElBQU0sOEJBQUEsYUFBb0MsV0FBVyxzQkFBc0I7QUFFM0UsSUFBSSxxQkFBcUIsV0FBVyxTQUFTLHFCQUFxQixTQUFTLFNBQVM7Q0FDaEYsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sV0FDZCxPQUFPLGVBQWUsUUFBUSxLQUFLLEVBQy9CLFdBQVc7RUFDUCxNQUFNLE9BQU87RUFDYixJQUFJLFFBQVEsZ0JBQWdCLFVBQVUsZ0JBQWdCLEtBQ2xELFFBQVEsZ0JBQWdCLFFBQVEsQ0FBQyxVQUFVLGdCQUFnQjtFQUUvRCx3QkFBd0Isb0JBQW9CLFFBQVE7RUFDcEQsT0FBTyxVQUFVO0NBQ3JCLEVBQ0osQ0FBQztDQUVMLE9BQU87QUFDWDtBQUVBLElBQU0sNEJBQTRCLFFBQUEsYUFDdEIsa0JBQUEsYUFDQTtBQUVaLElBQUksaUJBQWlCLGVBQWU7Q0FDaEMsTUFBTSxnQkFBZ0IsV0FBVyxlQUFlLFdBQVcsWUFBWTtDQUN2RSxPQUFRLFNBQVMsYUFBYSxLQUFLLGNBQWMsZUFBZSxlQUFlO0FBQ25GO0FBRUEsSUFBSSxlQUFlLFVBQVUsa0JBQWtCLEtBQUssS0FBSyxDQUFDLGFBQWEsS0FBSztBQUU1RSxJQUFNLG9DQUFvQyxRQUFRLFNBQVMsS0FBSyxXQUFXLEtBQ3ZFLENBQUMsTUFBTSxRQUFRLE1BQU0sS0FDckIsT0FBTyxlQUFlLE1BQU0sTUFBTSxRQUNsQyxDQUFDLGNBQWMsTUFBTTtBQUN6QixTQUFTLFVBQVUsU0FBUyxTQUFTLGdCQUFnQixPQUFPLDBCQUFVLElBQUksUUFBUSxHQUFHO0NBQ2pGLElBQUksWUFBWSxTQUNaLE9BQU87Q0FFWCxJQUFJLFlBQVksT0FBTyxLQUFLLFlBQVksT0FBTyxHQUMzQyxPQUFPLE9BQU8sR0FBRyxTQUFTLE9BQU87Q0FFckMsSUFBSSxhQUFhLE9BQU8sS0FBSyxhQUFhLE9BQU8sR0FDN0MsT0FBTyxPQUFPLEdBQUcsUUFBUSxRQUFRLEdBQUcsUUFBUSxRQUFRLENBQUM7Q0FFekQsSUFBSSxNQUFNLFFBQVEsT0FBTyxLQUNyQixNQUFNLFFBQVEsT0FBTyxLQUNyQixRQUFRLFdBQVcsUUFBUSxRQUMzQixPQUFPO0NBRVgsTUFBTSxRQUFRLE9BQU8sS0FBSyxPQUFPO0NBQ2pDLE1BQU0sUUFBUSxPQUFPLEtBQUssT0FBTztDQUNqQyxJQUFJLE1BQU0sV0FBVyxNQUFNLFFBQ3ZCLE9BQU87Q0FFWCxJQUFJLGlDQUFpQyxTQUFTLEtBQUssS0FDL0MsaUNBQWlDLFNBQVMsS0FBSyxHQUMvQyxPQUFPLE9BQU8sR0FBRyxTQUFTLE9BQU87Q0FFckMsSUFBSSxDQUFDLE1BQU0sVUFBVSxNQUFNLFFBQVEsT0FBTyxNQUFNLE1BQU0sUUFBUSxPQUFPLEdBQ2pFLE9BQU87Q0FFWCxNQUFNLGVBQWUsUUFBUSxJQUFJLE9BQU87Q0FDeEMsSUFBSSxnQkFBZ0IsYUFBYSxJQUFJLE9BQU8sR0FDeEMsT0FBTztDQUVYLElBQUksY0FDQSxhQUFhLElBQUksT0FBTztNQUV2QjtFQUNELE1BQU0scUJBQUssSUFBSSxRQUFRO0VBQ3ZCLEdBQUcsSUFBSSxPQUFPO0VBQ2QsUUFBUSxJQUFJLFNBQVMsRUFBRTtDQUMzQjtDQUNBLEtBQUssTUFBTSxPQUFPLE9BQU87RUFDckIsTUFBTSxPQUFPLFFBQVE7RUFDckIsSUFBSSxDQUFDLE9BQU8sVUFBVSxlQUFlLEtBQUssU0FBUyxHQUFHLEdBQ2xELE9BQU87RUFFWCxJQUFJLENBQUMsaUJBQWlCLFFBQVEsT0FBTztHQUNqQyxNQUFNLE9BQU8sUUFBUTtHQUNyQixJQUFLLGFBQWEsSUFBSSxLQUFLLGFBQWEsSUFBSSxNQUN0QyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsSUFBSSxPQUNqQyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsSUFBSSxLQUN2QyxDQUFDLFVBQVUsTUFBTSxNQUFNLGVBQWUsT0FBTyxJQUM3QyxDQUFDLE9BQU8sR0FBRyxNQUFNLElBQUksR0FDdkIsT0FBTztFQUVmO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxTQUFTLHFCQUFxQixpQkFBaUI7Q0FDM0MsTUFBTSxhQUFBLGFBQW1CLE9BQU8sS0FBSztDQUNyQyxNQUFNLGVBQUEsYUFBcUIsT0FBTyxLQUFLO0NBQ3ZDLE1BQU0sYUFBQSxhQUFtQixPQUFPLEtBQUEsQ0FBUztDQUN6QyxNQUFNLGVBQUEsYUFBcUIsT0FBTyxDQUFDO0NBQ25DLGFBQWE7Q0FDYixJQUFJLENBQUMsYUFBYSxXQUFXLGlCQUFpQjtFQUMxQyxhQUFhLFVBQVU7RUFDdkIsV0FBVyxVQUFVLFlBQVksZ0JBQWdCLENBQUM7Q0FDdEQ7Q0FpQkEsT0FBTztFQUFFLGdCQUFBLGFBaEJvQixhQUFhLFNBQVMsaUJBQWlCLGFBQWE7R0FDN0UsSUFBSSxZQUNDLFdBQVcsV0FDUCxhQUFhLFdBQVcsYUFBYSxVQUFVLElBQUs7SUFDekQsTUFBTSxlQUFlLGdCQUFnQjtJQUNyQyxJQUFJLENBQUMsVUFBVSxXQUFXLFNBQVMsWUFBWSxHQUMzQyxTQUFTLFlBQVk7R0FFN0I7R0FDQSxXQUFXLFVBQVU7RUFDekIsR0FBRyxDQUFDLENBTWtCO0VBQUcsVUFBQSxhQUxGLGFBQWEsU0FBUyxvQkFBb0I7R0FDN0QsSUFBSSxTQUNBLFdBQVcsVUFBVSxZQUFZLGdCQUFnQixDQUFDO0VBRTFELEdBQUcsQ0FBQyxDQUM0QjtDQUFFO0FBQ3RDOzs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLGFBQWEsT0FBTztDQUN6QixNQUFNLGNBQWMsc0JBQXNCO0NBQzFDLE1BQU0sRUFBRSxVQUFVLGFBQWEsVUFBVSxNQUFNLFVBQVUsU0FBUyxDQUFDO0NBQ25FLE1BQU0sNkJBQTZCO0VBQy9CLEdBQUcsUUFBUTtFQUNYLGVBQWUsUUFBUTtDQUMzQjtDQUNBLE1BQU0sQ0FBQyxXQUFXLG1CQUFBLGFBQXlCLFNBQVMsbUJBQW1CO0NBQ3ZFLE1BQU0sdUJBQUEsYUFBNkIsT0FBTztFQUN0QyxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZCxTQUFTO0VBQ1QsUUFBUTtDQUNaLENBQUM7Q0FDRCxNQUFNLEVBQUUsZ0JBQWdCLGFBQWEscUJBQXFCLG1CQUFtQjtDQUM3RSxnQ0FBZ0M7RUFDNUIsZUFBZSxDQUFDLFVBQVUscUJBQXFCLGVBQWU7RUFDOUQsTUFBTSxjQUFjLFFBQVEsV0FBVztHQUNuQztHQUNBLFdBQVcscUJBQXFCO0dBQ2hDO0dBQ0EsV0FBVyxjQUFjO0lBQ3JCLENBQUMsWUFDRyxnQkFBZ0I7S0FDWixHQUFHLFFBQVE7S0FDWCxHQUFHO0tBQ0gsZUFBZSxRQUFRO0lBQzNCLENBQUM7R0FDVDtFQUNKLENBQUM7RUFDRCxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsQ0FBQyxVQUFVLG1CQUFtQjtFQUMzQztDQUNKLEdBQUc7RUFBQztFQUFTO0VBQU07RUFBVTtFQUFPO0VBQWdCO0NBQVEsQ0FBQztDQUM3RCxhQUFNLGdCQUFnQjtFQUNsQixxQkFBcUIsUUFBUSxXQUFXLFFBQVEsVUFBVSxJQUFJO0NBQ2xFLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FDWixPQUFBLGFBQWEsY0FBYyxrQkFBa0IsV0FBVyxTQUFTLHFCQUFxQixTQUFTLEtBQUssR0FBRyxDQUFDLFdBQVcsT0FBTyxDQUFDO0FBQy9IO0FBRUEsSUFBSSxZQUFZLFVBQVUsT0FBTyxVQUFVO0FBRTNDLElBQUksdUJBQXVCLE9BQU8sUUFBUSxZQUFZLFVBQVUsaUJBQWlCO0NBQzdFLElBQUksU0FBUyxLQUFLLEdBQUc7RUFDakIsWUFBWSxPQUFPLE1BQU0sSUFBSSxLQUFLO0VBQ2xDLE9BQU8sSUFBSSxZQUFZLE9BQU8sWUFBWTtDQUM5QztDQUNBLElBQUksTUFBTSxRQUFRLEtBQUssR0FDbkIsT0FBTyxNQUFNLEtBQUssZUFBZSxZQUFZLE9BQU8sTUFBTSxJQUFJLFNBQVMsR0FDbkUsSUFBSSxZQUFZLFdBQVcsSUFBSSxjQUFjLFNBQVMsQ0FBQyxFQUFFO0NBRWpFLGFBQWEsT0FBTyxXQUFXO0NBQy9CLE9BQU87QUFDWDs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsU0FBUyxPQUFPO0NBQ3JCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLFVBQVUsYUFBYSxNQUFNLGNBQWMsVUFBVSxPQUFPLFlBQWEsU0FBUyxDQUFDO0NBQzNGLE1BQU0sZ0JBQUEsYUFBc0IsT0FBTyxZQUFZO0NBQy9DLE1BQU0sV0FBQSxhQUFpQixPQUFPLE9BQU87Q0FDckMsTUFBTSxlQUFBLGFBQXFCLE9BQU8sT0FBTztDQUN6QyxNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLFNBQVMsVUFBVTtDQUNuQixNQUFNLHlCQUF5QjtFQUMzQixNQUFNLGVBQWUsUUFBUSxVQUFVLE1BQU0sY0FBYyxPQUFPO0VBQ2xFLE9BQU8sU0FBUyxVQUFVLFNBQVMsUUFBUSxZQUFZLElBQUk7Q0FDL0Q7Q0FDQSxNQUFNLENBQUMsT0FBTyxlQUFBLGFBQXFCLFNBQVMsZ0JBQWdCO0NBQzVELE1BQU0scUJBQUEsYUFBMkIsT0FBTyxLQUFLO0NBQzdDLE1BQU0sbUJBQUEsYUFBeUIsYUFBYSxXQUFXO0VBQ25ELE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxRQUFRLFFBQVEsVUFBVSxRQUFRLGFBQWEsT0FBTyxjQUFjLE9BQU87RUFDeEgsT0FBTyxTQUFTLFVBQ1YsU0FBUyxRQUFRLFVBQVUsSUFDM0I7Q0FDVixHQUFHO0VBQUMsUUFBUTtFQUFhLFFBQVE7RUFBUTtDQUFJLENBQUM7Q0FDOUMsTUFBTSxlQUFBLGFBQXFCLGFBQWEsV0FBVztFQUMvQyxJQUFJLENBQUMsVUFBVTtHQUNYLE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxRQUFRLFFBQVEsVUFBVSxRQUFRLGFBQWEsT0FBTyxjQUFjLE9BQU87R0FDeEgsSUFBSSxTQUFTLFNBQVM7SUFDbEIsTUFBTSxxQkFBcUIsU0FBUyxRQUFRLFVBQVU7SUFDdEQsSUFBSSxDQUFDLFVBQVUsb0JBQW9CLG1CQUFtQixPQUFPLEdBQUc7S0FDNUQsWUFBWSxrQkFBa0I7S0FDOUIsbUJBQW1CLFVBQVU7SUFDakM7R0FDSixPQUVJLFlBQVksVUFBVTtFQUU5QjtDQUNKLEdBQUc7RUFBQyxRQUFRO0VBQWEsUUFBUTtFQUFRO0VBQVU7Q0FBSSxDQUFDO0NBQ3hELE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxxQkFBcUIsZ0JBQWdCO0NBQzFFLE1BQU0sZ0JBQUEsYUFBc0IsT0FBTyxZQUFZO0NBQy9DLGNBQWMsVUFBVTtDQUN4QixNQUFNLG9CQUFBLGFBQTBCLE9BQU8sZ0JBQWdCO0NBQ3ZELGtCQUFrQixVQUFVO0NBQzVCLGdDQUFnQztFQUM1QixJQUFJLGFBQWEsWUFBWSxXQUN6QixDQUFDLFVBQVUsVUFBVSxTQUFTLElBQUksR0FBRztHQUNyQyxhQUFhLFVBQVU7R0FDdkIsVUFBVSxVQUFVO0dBQ3BCLGNBQWMsUUFBUTtFQUMxQixPQUVJLGVBQWUsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsSUFBSSxpQkFBaUI7R0FDM0UsTUFBTSxZQUFZLFlBQVksWUFBWTtHQUMxQyxZQUFZLFNBQVM7R0FDckIsbUJBQW1CLFVBQVU7RUFDakMsQ0FBQztFQUVMLE1BQU0sY0FBYyxRQUFRLFdBQVc7R0FDbkM7R0FDQSxXQUFXLEVBQ1AsUUFBUSxLQUNaO0dBQ0E7R0FDQSxXQUFXLGNBQWM7SUFDckIsY0FBYyxRQUFRLFVBQVUsTUFBTTtHQUMxQztFQUNKLENBQUM7RUFDRCxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsQ0FBQztFQUN6RDtDQUNKLEdBQUc7RUFBQztFQUFTO0VBQU87RUFBTTtFQUFVO0VBQWdCO0NBQVEsQ0FBQztDQUM3RCxhQUFNLGdCQUFnQixRQUFRLGlCQUFpQixDQUFDO0NBS2hELE1BQU0saUJBQWlCLGFBQWEsWUFBWTtDQUNoRCxNQUFNLFdBQVcsVUFBVTtDQUMzQixNQUFNLGNBQUEsYUFBb0IsY0FBYyxDQUFDLGtCQUFrQixDQUFDLFVBQVUsVUFBVSxJQUFJLEdBQUc7RUFBQztFQUFnQjtFQUFNO0NBQVEsQ0FBQztDQUN2SCxJQUFJLGtCQUFrQixhQUNsQixjQUFjLFVBQVU7Q0FHNUIsT0FEOEIsQ0FBQyxhQUFhLGtCQUFrQixlQUMvQixpQkFBaUIsSUFBSTtBQUN4RDs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxVQUFVLGFBQWEsa0JBQWtCLGNBQWMsUUFBUSxTQUFVO0NBQ2pHLE1BQU0sZUFBZSxtQkFBbUIsUUFBUSxPQUFPLE9BQU8sSUFBSTtDQUtsRSxNQUFNLFFBQVEsU0FBUztFQUNuQjtFQUNBO0VBQ0EsY0FBQSxhQVAyQixjQUFjO0dBQ3pDLE1BQU0sV0FBVyxJQUFJLFFBQVEsYUFBYSxNQUFNLElBQUksUUFBUSxnQkFBZ0IsTUFBTSxZQUFZLENBQUM7R0FDL0YsT0FBUSxZQUFZLFFBQVEsSUFBSSxxQkFBcUIsU0FBUyxJQUFJLElBQUk7RUFDMUUsR0FBRztHQUFDO0dBQVM7R0FBTTtFQUFZLENBSUU7RUFDN0I7Q0FDSixDQUFDO0NBQ0QsTUFBTSxZQUFZLGFBQWE7RUFDM0I7RUFDQTtFQUNBO0NBQ0osQ0FBQztDQUNELE1BQU0sU0FBQSxhQUFlLE9BQU8sS0FBSztDQUNqQyxNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLE1BQU0saUJBQUEsYUFBdUIsT0FBTyxRQUFRLFNBQVMsTUFBTTtFQUN2RCxHQUFHLE1BQU07RUFDVDtFQUNBLEdBQUksVUFBVSxNQUFNLFFBQVEsSUFBSSxFQUFFLFVBQVUsTUFBTSxTQUFTLElBQUksQ0FBQztDQUNwRSxDQUFDLENBQUM7Q0FDRixPQUFPLFVBQVU7Q0FDakIsTUFBTSxhQUFBLGFBQW1CLGNBQWMsT0FBTyxpQkFBaUIsQ0FBQyxHQUFHO0VBQy9ELFNBQVM7R0FDTCxZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLFFBQVEsSUFBSTtFQUMzQztFQUNBLFNBQVM7R0FDTCxZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLGFBQWEsSUFBSTtFQUNoRDtFQUNBLFdBQVc7R0FDUCxZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLGVBQWUsSUFBSTtFQUNsRDtFQUNBLGNBQWM7R0FDVixZQUFZO0dBQ1osV0FBVyxDQUFDLENBQUMsSUFBSSxVQUFVLGtCQUFrQixJQUFJO0VBQ3JEO0VBQ0EsT0FBTztHQUNILFlBQVk7R0FDWixXQUFXLElBQUksVUFBVSxRQUFRLElBQUk7RUFDekM7Q0FDSixDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksQ0FBQztDQUNyQixNQUFNLFdBQUEsYUFBaUIsYUFBYSxVQUFVO0VBQzFDLE1BQU0sUUFBUSxjQUFjLEtBQUs7RUFDakMsSUFBSSxDQUFDLElBQUksUUFBUSxTQUFTLElBQUksR0FDMUIsZUFBZSxVQUFVLFFBQVEsU0FBUyxNQUFNO0dBQzVDLEdBQUcsT0FBTyxRQUFRO0dBQ2xCO0VBQ0osQ0FBQztFQUVMLE9BQU8sZUFBZSxRQUFRLFNBQVM7R0FDbkMsUUFBUTtJQUNKLE9BQU8sY0FBYyxLQUFLO0lBQzFCO0dBQ0o7R0FDQSxNQUFNLE9BQU87RUFDakIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQztDQUNsQixNQUFNLFNBQUEsYUFBZSxrQkFBa0I7RUFDbkMsTUFBTSxRQUFRLElBQUksUUFBUSxhQUFhLElBQUk7RUFDM0MsSUFBSSxDQUFDLElBQUksUUFBUSxTQUFTLElBQUksR0FDMUIsZUFBZSxVQUFVLFFBQVEsU0FBUyxNQUFNO0dBQzVDLEdBQUcsT0FBTyxRQUFRO0dBQ2xCO0VBQ0osQ0FBQztFQUVMLE9BQU8sZUFBZSxRQUFRLE9BQU87R0FDakMsUUFBUTtJQUNKO0lBQ0E7R0FDSjtHQUNBLE1BQU0sT0FBTztFQUNqQixDQUFDO0NBQ0wsR0FBRyxDQUFDLE1BQU0sT0FBTyxDQUFDO0NBQ2xCLE1BQU0sTUFBQSxhQUFZLGFBQWEsUUFBUTtFQUNuQyxJQUFJLEtBQ0EsVUFBVSxVQUFVO0dBQ2hCLGFBQWEsV0FBVyxJQUFJLEtBQUssS0FBSyxJQUFJLE1BQU07R0FDaEQsY0FBYyxXQUFXLElBQUksTUFBTSxLQUFLLElBQUksT0FBTztHQUNuRCxvQkFBb0IsWUFBWSxXQUFXLElBQUksaUJBQWlCLEtBQUssSUFBSSxrQkFBa0IsT0FBTztHQUNsRyxzQkFBc0IsV0FBVyxJQUFJLGNBQWMsS0FBSyxJQUFJLGVBQWU7RUFDL0U7RUFFSixNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtFQUN2QyxJQUFJLFNBQVMsTUFBTSxNQUFNLEtBQUs7R0FDMUIsTUFBTSxHQUFHLE1BQU0sVUFBVTtHQUN6QixNQUFNLEdBQUcsS0FBSztFQUNsQjtDQUNKLEdBQUcsQ0FBQyxRQUFRLFNBQVMsSUFBSSxDQUFDO0NBQzFCLE1BQU0sUUFBQSxhQUFjLGVBQWU7RUFDL0I7RUFDQTtFQUNBLEdBQUksVUFBVSxRQUFRLEtBQUssVUFBVSxXQUMvQixFQUFFLFVBQVUsVUFBVSxZQUFZLFNBQVMsSUFDM0MsQ0FBQztFQUNQO0VBQ0E7RUFDQTtDQUNKLElBQUk7RUFBQztFQUFNO0VBQVUsVUFBVTtFQUFVO0VBQVU7RUFBUTtFQUFLO0NBQUssQ0FBQztDQUN0RSxhQUFNLGdCQUFnQjtFQUNsQixNQUFNLHlCQUF5QixRQUFRLFNBQVMsb0JBQW9CO0VBQ3BFLGVBQWUsVUFBVSxRQUFRLFNBQVMsTUFBTTtHQUM1QyxHQUFHLE9BQU8sUUFBUTtHQUNsQixHQUFJLFVBQVUsT0FBTyxRQUFRLFFBQVEsSUFDL0IsRUFBRSxVQUFVLE9BQU8sUUFBUSxTQUFTLElBQ3BDLENBQUM7RUFDWCxDQUFDO0VBQ0QsTUFBTSxpQkFBaUIsTUFBTSxVQUFVO0dBQ25DLE1BQU0sUUFBUSxJQUFJLFFBQVEsU0FBUyxJQUFJO0dBQ3ZDLElBQUksU0FBUyxNQUFNLElBQUk7SUFDbkIsTUFBTSxHQUFHLFFBQVE7SUFDakIsTUFBTSxHQUFHLEtBQUs7R0FDbEI7RUFDSjtFQUNBLGNBQWMsTUFBTSxJQUFJO0VBQ3hCLElBQUksd0JBQXdCO0dBQ3hCLE1BQU0sUUFBUSxZQUFZLElBQUksbUJBQ3hCLFFBQVEsaUJBQ1IsUUFBUSxTQUFTLFVBQVUsUUFBUSxnQkFBZ0IsTUFBTSxJQUFJLFFBQVEsU0FBUyxlQUFlLE1BQU0sT0FBTyxRQUFRLFlBQVksQ0FBQyxDQUFDO0dBQ3RJLElBQUksUUFBUSxnQkFBZ0IsTUFBTSxLQUFLO0dBQ3ZDLElBQUksWUFBWSxJQUFJLFFBQVEsYUFBYSxJQUFJLENBQUMsR0FDMUMsSUFBSSxRQUFRLGFBQWEsTUFBTSxLQUFLO0VBRTVDO0VBQ0EsQ0FBQyxnQkFDRyxRQUFRLFNBQVMsTUFBTTtHQUNuQixHQUFHLE9BQU8sUUFBUTtHQUNsQixHQUFJLFVBQVUsT0FBTyxRQUFRLFFBQVEsSUFDL0IsRUFBRSxVQUFVLE9BQU8sUUFBUSxTQUFTLElBQ3BDLENBQUM7RUFDWCxDQUFDO0VBQ0wsSUFBSSxVQUFVLFNBQVM7R0FDbkIsTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7R0FDdkMsSUFBSSxTQUFTLE1BQU0sSUFDZixNQUFNLEdBQUcsTUFBTSxVQUFVO0VBRWpDO0VBQ0EsYUFBYTtHQUNULENBQUMsZUFDSywwQkFBMEIsQ0FBQyxRQUFRLE9BQU8sU0FDMUMsMEJBQ0EsUUFBUSxXQUFXLElBQUksSUFDdkIsY0FBYyxNQUFNLEtBQUs7RUFDbkM7Q0FDSixHQUFHO0VBQUM7RUFBTTtFQUFTO0VBQWM7Q0FBZ0IsQ0FBQztDQUNsRCxhQUFNLGdCQUFnQjtFQUNsQixRQUFRLGtCQUFrQjtHQUN0QjtHQUNBO0VBQ0osQ0FBQztDQUNMLEdBQUc7RUFBQztFQUFVO0VBQU07Q0FBTyxDQUFDO0NBQzVCLE9BQUEsYUFBYSxlQUFlO0VBQ3hCO0VBQ0E7RUFDQTtDQUNKLElBQUk7RUFBQztFQUFPO0VBQVc7Q0FBVSxDQUFDO0FBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUFnQi9ELElBQU0sZ0JBQWdCLEVBQUUsSUFBSSxTQUFTLE1BQU0sYUFBYztDQUNyRCxNQUFNLEVBQUUsV0FBVyxhQUFhO0VBQzVCO0VBQ007Q0FDVixDQUFDO0NBQ0QsTUFBTSxRQUFRLElBQUksUUFBUSxJQUFJO0NBQzlCLElBQUksQ0FBQyxPQUNELE9BQU87Q0FFWCxNQUFNLFVBQVUsTUFBTSxXQUFXO0NBQ2pDLElBQUksUUFDQSxPQUFPLE9BQU87RUFBRTtFQUFTLFVBQVUsTUFBTTtDQUFNLENBQUM7Q0FFcEQsT0FBQSxhQUFhLGNBQWMsTUFBQSxhQUFZLFVBQVUsTUFBTSxPQUFPO0FBQ2xFO0FBRUEsSUFBSSxtQkFBbUIsT0FBTyxXQUFXLGVBQWUsT0FBTyxhQUN6RCxPQUFPLFdBQVcsSUFDbEIsdUNBQXVDLFFBQVEsVUFBVSxNQUFNO0NBQzdELE1BQU0sSUFBSyxLQUFLLE9BQU8sSUFBSSxLQUFNO0NBQ2pDLFFBQVEsTUFBTSxNQUFNLElBQUssSUFBSSxJQUFPLEVBQUEsQ0FBSyxTQUFTLEVBQUU7QUFDeEQsQ0FBQztBQUVMLElBQUkscUJBQXFCLE1BQU0sT0FBTyxVQUFVLENBQUMsTUFBTSxRQUFRLGVBQWUsWUFBWSxRQUFRLFdBQVcsSUFDdkcsUUFBUSxhQUNOLEdBQUcsS0FBSyxHQUFHLFlBQVksUUFBUSxVQUFVLElBQUksUUFBUSxRQUFRLFdBQVcsS0FDMUU7QUFFTixJQUFJLHNCQUFzQixVQUFVO0NBQ2hDLFlBQVksQ0FBQyxRQUFRLFNBQVMsZ0JBQWdCO0NBQzlDLFVBQVUsU0FBUyxnQkFBZ0I7Q0FDbkMsWUFBWSxTQUFTLGdCQUFnQjtDQUNyQyxTQUFTLFNBQVMsZ0JBQWdCO0NBQ2xDLFdBQVcsU0FBUyxnQkFBZ0I7QUFDeEM7QUFFQSxJQUFJLGFBQWEsTUFBTSxRQUFRLGdCQUFnQjtDQUMzQyxJQUFJLGFBQ0EsT0FBTztDQUNYLElBQUksT0FBTyxZQUFZLE9BQU8sTUFBTSxJQUFJLElBQUksR0FDeEMsT0FBTztDQUNYLEtBQUssTUFBTSxhQUFhLE9BQU8sT0FDM0IsSUFBSSxLQUFLLFdBQVcsU0FBUyxLQUFLLEtBQUssT0FBTyxVQUFVLE1BQU0sTUFBTSxLQUNoRSxPQUFPO0NBRWYsT0FBTztBQUNYO0FBRUEsSUFBTSx5QkFBeUIsUUFBUSxRQUFRLGdCQUFnQjtDQUMzRCxLQUFLLE1BQU0sT0FBTyxlQUFlLE9BQU8sS0FBSyxNQUFNLEdBQUc7RUFDbEQsSUFBSSxRQUFRLE1BQ1I7RUFFSixNQUFNLFFBQVMsY0FBYyxJQUFJLFFBQVEsR0FBRyxJQUFJLE9BQU87RUFDdkQsSUFBSSxPQUFPO0dBQ1AsTUFBTSxFQUFFLE9BQU87R0FDZixJQUFJLElBQUk7SUFDSixJQUFJLEdBQUcsUUFBUSxHQUFHLEtBQUssTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUNuRCxPQUFPO1NBRU4sSUFBSSxHQUFHLE9BQU8sT0FBTyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQ3JDLE9BQU87U0FHUCxJQUFJLHNCQUFzQixPQUFPLE1BQU0sR0FDbkMsT0FBTztHQUduQixPQUNLLElBQUksU0FBUyxLQUFLLEtBQUssTUFBTSxRQUFRLEtBQUssR0FDdkM7UUFBQSxzQkFBc0IsT0FBTyxNQUFNLEdBQ25DLE9BQU87R0FBQTtFQUduQjtDQUNKO0FBRUo7QUFFQSxJQUFJLDZCQUE2QixRQUFRLE9BQU8sU0FBUztDQUNyRCxNQUFNLGlCQUFpQixJQUFJLFFBQVEsSUFBSTtDQUN2QyxNQUFNLG1CQUFtQixNQUFNLFFBQVEsY0FBYyxJQUFJLGlCQUFpQixDQUFDO0NBQzNFLElBQUksa0JBQWtCLGlCQUFpQixNQUFNLEtBQUs7Q0FDbEQsSUFBSSxRQUFRLE1BQU0sZ0JBQWdCO0NBQ2xDLE9BQU87QUFDWDtBQUVBLElBQUksaUJBQWlCLFVBQVUsU0FBUyxLQUFLLEtBQUssQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7QUFFdEUsSUFBSSxpQkFBaUIsVUFBVTtDQUMzQixJQUFJLENBQUMsT0FDRCxPQUFPO0NBRVgsTUFBTSxRQUFRLFFBQVEsTUFBTSxnQkFBZ0I7Q0FDNUMsT0FBUSxrQkFDSCxTQUFTLE1BQU0sY0FBYyxNQUFNLFlBQVksY0FBYztBQUN0RTtBQUVBLElBQUksZ0JBQWdCLFlBQVksUUFBUSxTQUFTO0FBRWpELElBQUksV0FBVyxVQUFVLGlCQUFpQjtBQUUxQyxJQUFJLGdCQUFnQixNQUFNLDBCQUEwQixRQUFRLE1BQU0sWUFBWSwyQkFDeEU7Q0FDRSxHQUFHLE9BQU87Q0FDVixPQUFPO0VBQ0gsR0FBSSxPQUFPLFNBQVMsT0FBTyxLQUFLLENBQUMsUUFBUSxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUM7R0FDOUQsT0FBTyxXQUFXO0NBQ3ZCO0FBQ0osSUFDRSxDQUFDO0FBRVAsSUFBTSxnQkFBZ0I7Q0FDbEIsT0FBTztDQUNQLFNBQVM7QUFDYjtBQUNBLElBQU0sY0FBYztDQUFFLE9BQU87Q0FBTSxTQUFTO0FBQUs7QUFDakQsSUFBSSxvQkFBb0IsWUFBWTtDQUNoQyxJQUFJLENBQUMsTUFBTSxRQUFRLE9BQU8sR0FDdEIsT0FBTztDQUVYLElBQUksUUFBUSxTQUFTLEdBQUc7RUFDcEIsTUFBTSxTQUFTLFFBQ1YsUUFBUSxXQUFXLFVBQVUsT0FBTyxXQUFXLENBQUMsT0FBTyxRQUFRLENBQUMsQ0FDaEUsS0FBSyxXQUFXLE9BQU8sS0FBSztFQUNqQyxPQUFPO0dBQUUsT0FBTztHQUFRLFNBQVMsQ0FBQyxDQUFDLE9BQU87RUFBTztDQUNyRDtDQUNBLE1BQU0sU0FBUyxRQUFRO0NBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxXQUFXLE9BQU8sVUFDckMsT0FBTztDQUVYLElBQUksQ0FBQyxPQUFPLGNBQWMsRUFBRSxXQUFXLE9BQU8sYUFDMUMsT0FBTztDQUVYLE9BQU8sWUFBWSxPQUFPLEtBQUssS0FBSyxPQUFPLFVBQVUsS0FDL0MsY0FDQTtFQUFFLE9BQU8sT0FBTztFQUFPLFNBQVM7Q0FBSztBQUMvQztBQUVBLElBQU0sZ0JBQWdCO0NBQ2xCLFNBQVM7Q0FDVCxPQUFPO0FBQ1g7QUFDQSxJQUFJLGlCQUFpQixZQUFZLE1BQU0sUUFBUSxPQUFPLElBQ2hELFFBQVEsUUFBUSxVQUFVLFdBQVcsVUFBVSxPQUFPLFdBQVcsQ0FBQyxPQUFPLFdBQ3JFO0NBQ0UsU0FBUztDQUNULE9BQU8sT0FBTztBQUNsQixJQUNFLFVBQVUsYUFBYSxJQUMzQjtBQUVOLFNBQVMsaUJBQWlCLFFBQVEsS0FBSyxPQUFPLFlBQVk7Q0FDdEQsSUFBSSxTQUFTLE1BQU0sS0FDZCxNQUFNLFFBQVEsTUFBTSxLQUFLLENBQUMsQ0FBQyxPQUFPLFVBQVUsT0FBTyxNQUFNLFFBQVEsS0FDakUsVUFBVSxNQUFNLEtBQUssQ0FBQyxRQUN2QixPQUFPO0VBQ0g7RUFDQSxTQUFTLFNBQVMsTUFBTSxJQUFJLFNBQVM7RUFDckM7Q0FDSjtBQUVSO0FBRUEsSUFBSSxzQkFBc0IsbUJBQW1CLFNBQVMsY0FBYyxLQUFLLENBQUMsUUFBUSxjQUFjLElBQzFGLGlCQUNBO0NBQ0UsT0FBTztDQUNQLFNBQVM7QUFDYjtBQUVKLElBQUksZ0JBQWdCLE9BQU8sT0FBTyxvQkFBb0IsWUFBWSwwQkFBMEIsMkJBQTJCLGlCQUFpQjtDQUNwSSxNQUFNLEVBQUUsS0FBSyxNQUFNLFVBQVUsV0FBVyxXQUFXLEtBQUssS0FBSyxTQUFTLFVBQVUsTUFBTSxlQUFlLE9BQU8sT0FBUSxNQUFNO0NBQzFILE1BQU0sYUFBYSxJQUFJLFlBQVksSUFBSTtDQUN2QyxJQUFJLENBQUMsU0FBUyxtQkFBbUIsSUFBSSxJQUFJLEdBQ3JDLE9BQU8sQ0FBQztDQUVaLE1BQU0sV0FBVyxPQUFPLEtBQUssS0FBSztDQUNsQyxNQUFNLHFCQUFxQixZQUFZO0VBQ25DLElBQUksNkJBQTZCLFNBQVMsZ0JBQWdCO0dBQ3RELE1BQU0sa0JBQWtCLFVBQVUsT0FBTyxJQUFJLEtBQUssV0FBVztHQUM3RCxJQUFJLE1BQ0EsS0FBSyxTQUFTLFFBQVEsV0FBVyxJQUFJLGlCQUFpQixLQUNsRCxJQUFJLGtCQUFrQixlQUFlLENBQUM7UUFHMUMsU0FBUyxrQkFBa0IsZUFBZTtHQUU5QyxTQUFTLGVBQWU7RUFDNUI7Q0FDSjtDQUNBLE1BQU0sUUFBUSxDQUFDO0NBQ2YsTUFBTSxVQUFVLENBQUMsTUFBTSxhQUFhLEdBQUc7Q0FDdkMsTUFBTSxhQUFhLENBQUMsTUFBTSxnQkFBZ0IsR0FBRztDQUM3QyxNQUFNLG9CQUFvQixXQUFXO0NBQ3JDLE1BQU0sV0FBWSxpQkFBaUIsWUFBWSxHQUFHLE1BQzlDLFlBQVksSUFBSSxLQUFLLEtBQ3JCLFlBQVksVUFBVSxLQUNyQixjQUFjLEdBQUcsS0FBSyxJQUFJLFVBQVUsTUFBTSxDQUFDLE1BQzVDLGVBQWUsTUFDZCxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVztDQUM5QyxNQUFNLG9CQUFvQixhQUFhLEtBQUssTUFBTSxNQUFNLDBCQUEwQixLQUFLO0NBQ3ZGLE1BQU0sb0JBQW9CLFdBQVcsa0JBQWtCLGtCQUFrQixVQUFVLHVCQUF1QixXQUFXLFVBQVUsdUJBQXVCLGNBQWM7RUFDaEssTUFBTSxVQUFVLFlBQVksbUJBQW1CO0VBQy9DLE1BQU0sUUFBUTtHQUNWLE1BQU0sWUFBWSxVQUFVO0dBQzVCO0dBQ0E7R0FDQSxHQUFHLGtCQUFrQixZQUFZLFVBQVUsU0FBUyxPQUFPO0VBQy9EO0NBQ0o7Q0FDQSxJQUFJLGVBQ0UsQ0FBQyxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVyxTQUMxQyxhQUNJLENBQUMsc0JBQXNCLFdBQVcsa0JBQWtCLFVBQVUsTUFDM0QsVUFBVSxVQUFVLEtBQUssQ0FBQyxjQUMxQixjQUFjLENBQUMsaUJBQWlCLElBQUksQ0FBQyxDQUFDLFdBQ3RDLFdBQVcsQ0FBQyxjQUFjLElBQUksQ0FBQyxDQUFDLFVBQVc7RUFDcEQsTUFBTSxFQUFFLE9BQU8sWUFBWSxTQUFTLFFBQVEsSUFDdEM7R0FBRSxPQUFPLENBQUMsQ0FBQztHQUFVLFNBQVM7RUFBUyxJQUN2QyxtQkFBbUIsUUFBUTtFQUNqQyxJQUFJLE9BQU87R0FDUCxNQUFNLFFBQVE7SUFDVixNQUFNLHVCQUF1QjtJQUM3QjtJQUNBLEtBQUs7SUFDTCxHQUFHLGtCQUFrQix1QkFBdUIsVUFBVSxPQUFPO0dBQ2pFO0dBQ0EsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsT0FBTztJQUN6QixPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsSUFBSSxDQUFDLFlBQVksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsa0JBQWtCLEdBQUcsSUFBSTtFQUNsRSxJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sWUFBWSxtQkFBbUIsR0FBRztFQUN4QyxNQUFNLFlBQVksbUJBQW1CLEdBQUc7RUFDeEMsSUFBSSxDQUFDLGtCQUFrQixVQUFVLEtBQzdCLENBQUMsYUFBYSxVQUFVLEtBQ3hCLENBQUMsTUFBTSxVQUFVLEdBQUc7R0FDcEIsTUFBTSxjQUFlLENBQUMsTUFBTSxJQUFJLGtCQUMzQixhQUFhLENBQUMsYUFBYTtHQUNoQyxJQUFJLENBQUMsa0JBQWtCLFVBQVUsS0FBSyxHQUNsQyxZQUFZLGNBQWMsVUFBVTtHQUV4QyxJQUFJLENBQUMsa0JBQWtCLFVBQVUsS0FBSyxHQUNsQyxZQUFZLGNBQWMsVUFBVTtFQUU1QyxPQUNLO0dBQ0QsTUFBTSxZQUFhLENBQUMsTUFBTSxJQUFJLGVBQzFCLElBQUksS0FBSyxVQUFVO0dBQ3ZCLE1BQU0scUJBQXFCLHlCQUFTLElBQUksc0JBQUssSUFBSSxLQUFLLEVBQUEsQ0FBRSxhQUFhLElBQUksTUFBTSxJQUFJO0dBQ25GLE1BQU0sU0FBUyxJQUFJLFFBQVE7R0FDM0IsTUFBTSxTQUFTLElBQUksUUFBUTtHQUMzQixJQUFJLFNBQVMsVUFBVSxLQUFLLEtBQUssWUFDN0IsWUFBWSxTQUNOLGtCQUFrQixVQUFVLElBQUksa0JBQWtCLFVBQVUsS0FBSyxJQUNqRSxTQUNJLGFBQWEsVUFBVSxRQUN2QixZQUFZLElBQUksS0FBSyxVQUFVLEtBQUs7R0FFbEQsSUFBSSxTQUFTLFVBQVUsS0FBSyxLQUFLLFlBQzdCLFlBQVksU0FDTixrQkFBa0IsVUFBVSxJQUFJLGtCQUFrQixVQUFVLEtBQUssSUFDakUsU0FDSSxhQUFhLFVBQVUsUUFDdkIsWUFBWSxJQUFJLEtBQUssVUFBVSxLQUFLO0VBRXREO0VBQ0EsSUFBSSxhQUFhLFdBQVc7R0FDeEIsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLFVBQVUsU0FBUyxVQUFVLFNBQVMsdUJBQXVCLEtBQUssdUJBQXVCLEdBQUc7R0FDMUgsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsTUFBTSxLQUFLLENBQUMsT0FBTztJQUNyQyxPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsS0FBSyxDQUFDLGtCQUFrQixTQUFTLEtBQUssQ0FBQyxrQkFBa0IsU0FBUyxNQUM5RCxDQUFDLFlBQ0EsU0FBUyxVQUFVLEtBQU0sZ0JBQWdCLE1BQU0sUUFBUSxVQUFVLElBQUs7RUFDdkUsTUFBTSxrQkFBa0IsbUJBQW1CLFNBQVM7RUFDcEQsTUFBTSxrQkFBa0IsbUJBQW1CLFNBQVM7RUFDcEQsTUFBTSxZQUFZLENBQUMsa0JBQWtCLGdCQUFnQixLQUFLLEtBQ3RELFdBQVcsU0FBUyxDQUFDLGdCQUFnQjtFQUN6QyxNQUFNLFlBQVksQ0FBQyxrQkFBa0IsZ0JBQWdCLEtBQUssS0FDdEQsV0FBVyxTQUFTLENBQUMsZ0JBQWdCO0VBQ3pDLElBQUksYUFBYSxXQUFXO0dBQ3hCLGlCQUFpQixXQUFXLGdCQUFnQixTQUFTLGdCQUFnQixPQUFPO0dBQzVFLElBQUksQ0FBQywwQkFBMEI7SUFDM0Isa0JBQWtCLE1BQU0sS0FBSyxDQUFDLE9BQU87SUFDckMsT0FBTztHQUNYO0VBQ0o7Q0FDSjtDQUNBLElBQUksV0FBVyxDQUFDLFdBQVcsU0FBUyxVQUFVLEdBQUc7RUFDN0MsTUFBTSxFQUFFLE9BQU8sY0FBYyxZQUFZLG1CQUFtQixPQUFPO0VBQ25FLElBQUksUUFBUSxZQUFZLEtBQUssQ0FBQyxXQUFXLE1BQU0sWUFBWSxHQUFHO0dBQzFELE1BQU0sUUFBUTtJQUNWLE1BQU0sdUJBQXVCO0lBQzdCO0lBQ0E7SUFDQSxHQUFHLGtCQUFrQix1QkFBdUIsU0FBUyxPQUFPO0dBQ2hFO0dBQ0EsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsT0FBTztJQUN6QixPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsSUFBSSxVQUFVO0VBQ1YsSUFBSSxXQUFXLFFBQVEsR0FBRztHQUV0QixNQUFNLGdCQUFnQixpQkFBaUIsTUFEbEIsU0FBUyxZQUFZLFVBQVUsR0FDTCxRQUFRO0dBQ3ZELElBQUksZUFBZTtJQUNmLE1BQU0sUUFBUTtLQUNWLEdBQUc7S0FDSCxHQUFHLGtCQUFrQix1QkFBdUIsVUFBVSxjQUFjLE9BQU87SUFDL0U7SUFDQSxJQUFJLENBQUMsMEJBQTBCO0tBQzNCLGtCQUFrQixjQUFjLE9BQU87S0FDdkMsT0FBTztJQUNYO0dBQ0o7RUFDSixPQUNLLElBQUksU0FBUyxRQUFRLEdBQUc7R0FDekIsSUFBSSxtQkFBbUIsQ0FBQztHQUN4QixLQUFLLE1BQU0sT0FBTyxVQUFVO0lBQ3hCLElBQUksQ0FBQyxjQUFjLGdCQUFnQixLQUFLLENBQUMsMEJBQ3JDO0lBRUosTUFBTSxnQkFBZ0IsaUJBQWlCLE1BQU0sU0FBUyxJQUFJLENBQUMsWUFBWSxVQUFVLEdBQUcsVUFBVSxHQUFHO0lBQ2pHLElBQUksZUFBZTtLQUNmLG1CQUFtQjtNQUNmLEdBQUc7TUFDSCxHQUFHLGtCQUFrQixLQUFLLGNBQWMsT0FBTztLQUNuRDtLQUNBLElBQUksQ0FBQywwQkFDRCxrQkFBa0IsY0FBYyxPQUFPO0tBRTNDLElBQUksMEJBQ0EsTUFBTSxRQUFRO0lBRXRCO0dBQ0o7R0FDQSxJQUFJLENBQUMsY0FBYyxnQkFBZ0IsR0FBRztJQUNsQyxNQUFNLFFBQVE7S0FDVixLQUFLO0tBQ0wsR0FBRztJQUNQO0lBQ0EsSUFBSSxDQUFDLDBCQUNELE9BQU87R0FFZjtFQUNKO0NBQ0o7Q0FDQSxNQUFNLGFBQWEsTUFBTTtDQUN6QixrQkFBa0IsYUFBYSxXQUFXLFVBQVUsSUFBSTtDQUN4RCxPQUFPO0FBQ1g7QUFFQSxJQUFJLHlCQUF5QixVQUFXLE1BQU0sUUFBUSxLQUFLLElBQUksUUFBUSxDQUFDLEtBQUs7QUFFN0UsSUFBSSxZQUFZLE1BQU0sVUFBVSxDQUM1QixHQUFHLE1BQ0gsR0FBRyxzQkFBc0IsS0FBSyxDQUNsQztBQUVBLElBQUksa0JBQWtCLFVBQVUsTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLFVBQVUsS0FBQSxDQUFTLElBQUksS0FBQTtBQUVwRixTQUFTLE9BQU8sTUFBTSxPQUFPLE9BQU87Q0FDaEMsT0FBTztFQUNILEdBQUcsS0FBSyxNQUFNLEdBQUcsS0FBSztFQUN0QixHQUFHLHNCQUFzQixLQUFLO0VBQzlCLEdBQUcsS0FBSyxNQUFNLEtBQUs7Q0FDdkI7QUFDSjtBQUVBLElBQUksZUFBZSxNQUFNLE1BQU0sT0FBTztDQUNsQyxJQUFJLENBQUMsTUFBTSxRQUFRLElBQUksR0FDbkIsT0FBTyxDQUFDO0NBRVosSUFBSSxZQUFZLEtBQUssR0FBRyxHQUNwQixLQUFLLE1BQU0sS0FBQTtDQUVmLEtBQUssT0FBTyxJQUFJLEdBQUcsS0FBSyxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRTtDQUMxQyxPQUFPO0FBQ1g7QUFFQSxJQUFJLGFBQWEsTUFBTSxVQUFVLENBQzdCLEdBQUcsc0JBQXNCLEtBQUssR0FDOUIsR0FBRyxzQkFBc0IsSUFBSSxDQUNqQztBQUVBLElBQUksV0FBVyxVQUFVLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxPQUFPLE9BQU8sSUFBSSxDQUFDO0FBRXpFLFNBQVMsZ0JBQWdCLE1BQU0sU0FBUztDQUNwQyxJQUFJLElBQUk7Q0FDUixNQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUk7Q0FDckIsS0FBSyxNQUFNLFNBQVMsU0FBUztFQUN6QixLQUFLLE9BQU8sUUFBUSxHQUFHLENBQUM7RUFDeEI7Q0FDSjtDQUNBLE9BQU8sUUFBUSxJQUFJLENBQUMsQ0FBQyxTQUFTLE9BQU8sQ0FBQztBQUMxQztBQUNBLElBQUksaUJBQWlCLE1BQU0sVUFBVSxZQUFZLEtBQUssSUFDaEQsQ0FBQyxJQUNELGdCQUFnQixNQUFNLENBQUMsR0FBRyxJQUFJLElBQUksc0JBQXNCLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQztBQUU1RixJQUFJLGVBQWUsTUFBTSxRQUFRLFdBQVc7Q0FDeEMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxTQUFTLEtBQUssT0FBTztBQUM5RDtBQUVBLFNBQVMsUUFBUSxRQUFRLFlBQVk7Q0FDakMsTUFBTSxTQUFTLFdBQVcsU0FBUztDQUNuQyxJQUFJLFFBQVE7Q0FDWixPQUFPLFFBQVEsUUFBUTtFQUNuQixJQUFJLGtCQUFrQixNQUFNLEdBQUc7R0FDM0IsU0FBUyxLQUFBO0dBQ1Q7RUFDSjtFQUNBLFNBQVMsT0FBTyxXQUFXO0VBQzNCO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGFBQWEsS0FBSztDQUN2QixLQUFLLE1BQU0sT0FBTyxLQUNkLElBQUksSUFBSSxlQUFlLEdBQUcsS0FBSyxDQUFDLFlBQVksSUFBSSxJQUFJLEdBQ2hELE9BQU87Q0FHZixPQUFPO0FBQ1g7QUFDQSxTQUFTLE1BQU0sUUFBUSxNQUFNO0NBQ3pCLElBQUksU0FBUyxJQUFJLEtBQUssT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLElBQUksR0FBRztFQUN0RSxPQUFPLE9BQU87RUFDZCxPQUFPO0NBQ1g7Q0FDQSxNQUFNLFFBQVEsTUFBTSxRQUFRLElBQUksSUFDMUIsT0FDQSxNQUFNLElBQUksSUFDTixDQUFDLElBQUksSUFDTCxhQUFhLElBQUk7Q0FDM0IsSUFBSSxNQUFNLE1BQU0sWUFBWSxtQkFBbUIsU0FBUyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEdBQ3BFLE9BQU87Q0FFWCxNQUFNLGNBQWMsTUFBTSxXQUFXLElBQUksU0FBUyxRQUFRLFFBQVEsS0FBSztDQUN2RSxNQUFNLFFBQVEsTUFBTSxTQUFTO0NBQzdCLE1BQU0sTUFBTSxNQUFNO0NBQ2xCLElBQUksYUFDQSxPQUFPLFlBQVk7Q0FFdkIsSUFBSSxVQUFVLE1BQ1IsU0FBUyxXQUFXLEtBQUssY0FBYyxXQUFXLEtBQy9DLE1BQU0sUUFBUSxXQUFXLEtBQUssYUFBYSxXQUFXLElBQzNELE1BQU0sUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7Q0FFcEMsT0FBTztBQUNYO0FBRUEsSUFBSSxZQUFZLGFBQWEsT0FBTyxVQUFVO0NBQzFDLFlBQVksU0FBUztDQUNyQixPQUFPO0FBQ1g7Ozs7Ozs7Ozs7Ozs7QUFjQSxTQUFTLGNBQWMsT0FBTztDQUMxQixNQUFNLGNBQWMsc0JBQXNCO0NBQzFDLE1BQU0sRUFBRSxVQUFVLGFBQWEsTUFBTSxVQUFVLE1BQU0sVUFBVSxrQkFBa0IsVUFBVztDQUM1RixNQUFNLDZCQUE2QixRQUFRLGVBQWUsSUFBSTtDQUM5RCxNQUFNLENBQUMsUUFBUSxhQUFBLGFBQW1CLFNBQVMsb0JBQW9CO0NBQy9ELE1BQU0sTUFBQSxhQUFZLE9BQU8sUUFBUSxlQUFlLElBQUksQ0FBQyxDQUFDLElBQUksVUFBVSxDQUFDO0NBQ3JFLE1BQU0sWUFBQSxhQUFrQixPQUFPLEtBQUs7Q0FDcEMsTUFBTSxFQUFFLGdCQUFnQixhQUFhLHFCQUFxQixvQkFBb0I7Q0FDOUUsTUFBTSxlQUFBLGFBQXFCLE9BQU8sT0FBTztDQUN6QyxNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLElBQUksQ0FBQyxVQUNELFFBQVEsT0FBTyxNQUFNLElBQUksSUFBSTtDQUVqQyxhQUFNLGNBQWMsQ0FBQyxZQUNqQixTQUNBLFVBQ0EsUUFBUSxTQUFTLE1BQU0sS0FBSyxHQUFHO0VBQUM7RUFBUztFQUFNO0VBQVE7RUFBTztDQUFRLENBQUM7Q0FDM0UsZ0NBQWdDO0VBQzVCLElBQUksVUFDQTtFQUVKLElBQUksYUFBYSxZQUFZLFdBQVcsVUFBVSxZQUFZLE1BQzFELGVBQWUsTUFBTSx1QkFBdUIsZ0JBQWdCO0dBQ3hELFVBQVUsV0FBVztHQUNyQixJQUFJLFVBQVUsWUFBWSxJQUFJLFVBQVU7RUFDNUMsQ0FBQztPQUVBO0dBQ0QsYUFBYSxVQUFVO0dBQ3ZCLFVBQVUsVUFBVTtHQUNwQixNQUFNLGNBQWMscUJBQXFCO0dBQ3pDLElBQUksQ0FBQyxVQUFVLFFBQVEsV0FBVyxHQUFHO0lBQ2pDLFVBQVUsV0FBVztJQUNyQixJQUFJLFVBQVUsWUFBWSxJQUFJLFVBQVU7R0FDNUM7R0FDQSxTQUFTLE1BQU0sb0JBQW9CO0VBQ3ZDO0VBQ0EsTUFBTSxjQUFjLFFBQVEsVUFBVSxNQUFNLFVBQVUsRUFDbEQsT0FBTyxFQUFFLFFBQVEsTUFBTSxxQkFBc0I7R0FDekMsSUFBSSxtQkFBbUIsUUFBUSxDQUFDLGdCQUFnQjtJQUM1QyxNQUFNLGNBQWMsSUFBSSxRQUFRLElBQUk7SUFDcEMsSUFBSSxNQUFNLFFBQVEsV0FBVyxHQUFHO0tBQzVCLFVBQVUsV0FBVztLQUNyQixJQUFJLFVBQVUsWUFBWSxJQUFJLFVBQVU7SUFDNUMsT0FDSyxJQUFJLENBQUMsZ0JBQWdCO0tBQ3RCLFVBQVUsQ0FBQyxDQUFDO0tBQ1osSUFBSSxVQUFVLENBQUM7SUFDbkI7R0FDSjtFQUNKLEVBQ0osQ0FBQyxDQUFDLENBQUM7RUFDSCxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsTUFBTSxvQkFBb0I7RUFDdkM7Q0FDSixHQUFHO0VBQUM7RUFBUztFQUFNO0VBQVU7RUFBZ0I7Q0FBUSxDQUFDO0NBQ3RELE1BQU0sZUFBQSxhQUFxQixhQUFhLDRCQUE0QjtFQUNoRSxVQUFVLFVBQVU7RUFDcEIsUUFBUSxlQUFlLE1BQU0sdUJBQXVCO0NBQ3hELEdBQUcsQ0FBQyxTQUFTLElBQUksQ0FBQztDQUNsQixNQUFNLFVBQVUsT0FBTyxZQUFZO0VBQy9CLElBQUksVUFDQTtFQUVKLE1BQU0sY0FBYyxzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDNUQsTUFBTSwwQkFBMEIsU0FBUyxRQUFRLGVBQWUsSUFBSSxHQUFHLFdBQVc7RUFDbEYsUUFBUSxPQUFPLFFBQVEsa0JBQWtCLE1BQU0sd0JBQXdCLFNBQVMsR0FBRyxPQUFPO0VBQzFGLElBQUksVUFBVSxTQUFTLElBQUksU0FBUyxZQUFZLElBQUksVUFBVSxDQUFDO0VBQy9ELGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixVQUFVLEVBQzVELE1BQU0sZUFBZSxLQUFLLEVBQzlCLENBQUM7Q0FDTDtDQUNBLE1BQU0sV0FBVyxPQUFPLFlBQVk7RUFDaEMsSUFBSSxVQUNBO0VBRUosTUFBTSxlQUFlLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUM3RCxNQUFNLDBCQUEwQixVQUFVLFFBQVEsZUFBZSxJQUFJLEdBQUcsWUFBWTtFQUNwRixRQUFRLE9BQU8sUUFBUSxrQkFBa0IsTUFBTSxHQUFHLE9BQU87RUFDekQsSUFBSSxVQUFVLFVBQVUsSUFBSSxTQUFTLGFBQWEsSUFBSSxVQUFVLENBQUM7RUFDakUsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLFdBQVcsRUFDN0QsTUFBTSxlQUFlLEtBQUssRUFDOUIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxVQUFVLFVBQVU7RUFDdEIsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsY0FBYyxRQUFRLGVBQWUsSUFBSSxHQUFHLEtBQUs7RUFDakYsSUFBSSxVQUFVLGNBQWMsSUFBSSxTQUFTLEtBQUs7RUFDOUMsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsQ0FBQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSSxDQUFDLEtBQ3JDLElBQUksUUFBUSxTQUFTLE1BQU0sS0FBQSxDQUFTO0VBQ3hDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixlQUFlLEVBQ2pFLE1BQU0sTUFDVixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFlBQVksT0FBTyxPQUFPLFlBQVk7RUFDeEMsSUFBSSxVQUNBO0VBRUosTUFBTSxjQUFjLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUM1RCxNQUFNLDBCQUEwQixPQUFPLFFBQVEsZUFBZSxJQUFJLEdBQUcsT0FBTyxXQUFXO0VBQ3ZGLFFBQVEsT0FBTyxRQUFRLGtCQUFrQixNQUFNLE9BQU8sT0FBTztFQUM3RCxJQUFJLFVBQVUsT0FBTyxJQUFJLFNBQVMsT0FBTyxZQUFZLElBQUksVUFBVSxDQUFDO0VBQ3BFLGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixRQUFRO0dBQzFELE1BQU07R0FDTixNQUFNLGVBQWUsS0FBSztFQUM5QixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFFBQVEsUUFBUSxXQUFXO0VBQzdCLElBQUksVUFDQTtFQUVKLE1BQU0sMEJBQTBCLFFBQVEsZUFBZSxJQUFJO0VBQzNELFlBQVkseUJBQXlCLFFBQVEsTUFBTTtFQUNuRCxZQUFZLElBQUksU0FBUyxRQUFRLE1BQU07RUFDdkMsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLGFBQWE7R0FDL0QsTUFBTTtHQUNOLE1BQU07RUFDVixHQUFHLEtBQUs7Q0FDWjtDQUNBLE1BQU0sUUFBUSxNQUFNLE9BQU87RUFDdkIsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsUUFBUSxlQUFlLElBQUk7RUFDM0QsWUFBWSx5QkFBeUIsTUFBTSxFQUFFO0VBQzdDLFlBQVksSUFBSSxTQUFTLE1BQU0sRUFBRTtFQUNqQyxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsYUFBYTtHQUMvRCxNQUFNO0dBQ04sTUFBTTtFQUNWLEdBQUcsS0FBSztDQUNaO0NBQ0EsTUFBTSxVQUFVLE9BQU8sVUFBVTtFQUM3QixJQUFJLFVBQ0E7RUFFSixNQUFNLGNBQWMsWUFBWSxLQUFLO0VBQ3JDLE1BQU0sMEJBQTBCLFNBQVMsUUFBUSxlQUFlLElBQUksR0FBRyxPQUFPLFdBQVc7RUFDekYsSUFBSSxVQUFVLENBQUMsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDLEtBQUssTUFBTSxNQUFNLENBQUMsUUFBUSxNQUFNLFFBQVEsV0FBVyxJQUFJLElBQUksUUFBUSxFQUFFO0VBQ2hILGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsQ0FBQyxHQUFHLHVCQUF1QixDQUFDO0VBQ3RDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixVQUFVO0dBQzVELE1BQU07R0FDTixNQUFNLGVBQWUsS0FBSztFQUM5QixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFdBQVcsVUFBVTtFQUN2QixJQUFJLFVBQ0E7RUFFSixNQUFNLDBCQUEwQixzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDeEUsSUFBSSxVQUFVLHdCQUF3QixJQUFJLFVBQVU7RUFDcEQsYUFBYSxDQUFDLEdBQUcsdUJBQXVCLENBQUM7RUFDekMsVUFBVSxDQUFDLEdBQUcsdUJBQXVCLENBQUM7RUFDdEMsUUFBUSxlQUFlLE1BQU0sQ0FBQyxHQUFHLHVCQUF1QixJQUFJLFNBQVMsTUFBTSxRQUFRLElBQUksSUFDakYsS0FBSyxNQUFNLEdBQUcsd0JBQXdCLE1BQU0sSUFDNUMsTUFBTSxDQUFDLENBQUM7Q0FDbEI7Q0FDQSxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLFVBQVU7R0FDVixRQUFRLE9BQU8sbUJBQW1CLE9BQU8sSUFBSTtHQUM3QztFQUNKO0VBQ0EsUUFBUSxPQUFPLFNBQVM7RUFDeEIsUUFBUSxPQUFPLG1CQUFtQixPQUFPLElBQUk7RUFDN0MsVUFBVSxNQUFNLFFBQVEsTUFBTSxLQUMxQixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLEdBQUcsUUFBUSxXQUNmLENBQUM7RUFDTCxNQUFNLGtCQUFrQixtQkFBbUIsUUFBUSxTQUFTLElBQUk7RUFDaEUsTUFBTSxrQkFBa0IsbUJBQW1CLFFBQVEsU0FBUyxjQUFjO0VBQzFFLElBQUksVUFBVSxZQUNULENBQUMsZ0JBQWdCLGNBQWMsUUFBUSxXQUFXLGdCQUNuRCxDQUFDLGdCQUFnQixlQUNoQixDQUFDLGdCQUFnQixZQUNiLFFBQVEsV0FBVyxlQUFlLGdCQUFnQixhQUFjO0dBQ3JFLE1BQU0sbUJBQW1CLElBQUksUUFBUSxhQUFhLElBQUk7R0FDdEQsSUFBSSxRQUFRLFNBQVMsVUFDakIsUUFBUSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVc7SUFDeEMsUUFBUSxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7SUFDbEMsSUFBSSxxQkFBcUIsSUFBSSxRQUFRLGFBQWEsSUFBSSxHQUNsRDtJQUVKLE1BQU0sUUFBUSxJQUFJLE9BQU8sUUFBUSxJQUFJO0lBQ3JDLE1BQU0sZ0JBQWdCLElBQUksUUFBUSxXQUFXLFFBQVEsSUFBSTtJQUN6RCxNQUFNLG9CQUFvQixrQkFDckIsY0FBYyxRQUNWLGNBQWMsUUFBUSxjQUFjLEtBQUs7SUFDbEQsTUFBTSx1QkFBdUIsa0JBQ3hCLGNBQWMsV0FDVixjQUFjLFFBQVEsY0FBYyxLQUFLO0lBQ2xELElBQUksZ0JBQ0csQ0FBQyxTQUFTLHFCQUNSLFVBQ0ksc0JBQXNCLE1BQU0sUUFDekIseUJBQXlCLE1BQU0sV0FDekMsU0FBUyxNQUFNLE1BQU07S0FDdkIsSUFBSSxPQUNBLFNBQVMsS0FBSyxLQUNWLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUNuRCwwQkFBMEIsUUFBUSxXQUFXLFFBQVEsR0FBRyxPQUFPLE1BQU0sR0FBRyxJQUFJLElBQzVFLElBQUksUUFBUSxXQUFXLFFBQVEsTUFBTSxLQUFLO1VBR2hELE1BQU0sUUFBUSxXQUFXLFFBQVEsSUFBSTtLQUV6QyxRQUFRLFdBQVcsU0FBUyxFQUFFLEdBQUcsUUFBUSxXQUFXLE9BQU87S0FDM0QsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsV0FBVyxPQUMvQixDQUFDO0lBQ0w7R0FDSixDQUFDO1FBRUE7SUFDRCxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtJQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLGNBQWMsT0FBTyxRQUFRLE9BQU8sVUFBVSxRQUFRLGFBQWEsUUFBUSxTQUFTLGlCQUFpQixnQkFBZ0IsS0FBSyxRQUFRLFNBQVMsMkJBQTJCLElBQUksQ0FBQyxDQUFDLE1BQU0sVUFBVTtLQUN4TCxJQUFJLHFCQUFxQixJQUFJLFFBQVEsYUFBYSxJQUFJLEdBQ2xEO0tBRUosSUFBSSxDQUFDLGNBQWMsS0FBSyxHQUFHO01BQ3ZCLDBCQUEwQixRQUFRLFdBQVcsUUFBUSxPQUFPLElBQUk7TUFDaEUsUUFBUSxXQUFXLFNBQVMsRUFBRSxHQUFHLFFBQVEsV0FBVyxPQUFPO01BQzNELFFBQVEsVUFBVSxNQUFNLEtBQUssRUFDekIsUUFBUSxRQUFRLFdBQVcsT0FDL0IsQ0FBQztLQUNMLE9BQ0s7TUFDRCxNQUFNLGdCQUFnQixJQUFJLFFBQVEsV0FBVyxRQUFRLElBQUk7TUFDekQsSUFBSSxpQkFBaUIsY0FBYyxrQkFBa0I7T0FDakQsTUFBTSxRQUFRLFdBQVcsUUFBUSxHQUFHLEtBQUssR0FBRyxpQkFBaUI7T0FDN0QsUUFBUSxXQUFXLFNBQVMsRUFBRSxHQUFHLFFBQVEsV0FBVyxPQUFPO09BQzNELFFBQVEsVUFBVSxNQUFNLEtBQUssRUFDekIsUUFBUSxRQUFRLFdBQVcsT0FDL0IsQ0FBQztNQUNMO0tBQ0o7SUFDSixDQUFDO0dBRVQ7RUFDSjtFQUlBLFVBQVUsV0FDTixRQUFRLFVBQVUsTUFBTSxLQUFLO0dBQ3pCO0dBQ0EsUUFBUSxZQUFZLFFBQVEsV0FBVztFQUMzQyxDQUFDO0VBQ0wsUUFBUSxPQUFPLFNBQ1gsc0JBQXNCLFFBQVEsVUFBVSxLQUFLLFFBQVE7R0FDakQsSUFBSSxRQUFRLE9BQU8sU0FDZixJQUFJLFdBQVcsUUFBUSxPQUFPLEtBQUssS0FDbkMsSUFBSSxPQUFPO0lBQ1gsSUFBSSxNQUFNO0lBQ1YsT0FBTztHQUNYO0VBRUosQ0FBQztFQUNMLFFBQVEsT0FBTyxRQUFRO0VBQ3ZCLFFBQVEsVUFBVTtFQUNsQixVQUFVLFVBQVU7Q0FDeEIsR0FBRztFQUFDO0VBQVE7RUFBTTtFQUFTO0NBQVEsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLENBQUMsVUFDRCxZQUFZLElBQUksUUFBUSxhQUFhLElBQUksQ0FBQyxLQUN0QyxRQUFRLGVBQWUsSUFBSTtFQUVuQyxhQUFhO0dBQ1QsUUFBUSxPQUFPLG1CQUFtQixPQUFPLElBQUk7R0FDN0MsUUFBUSxPQUFPLG1CQUFtQixTQUFTLFFBQVEsT0FBTyxTQUFTO0dBQ25FLElBQUksVUFDQTtHQUVKLE1BQU0sNkJBQTZCLEVBQUUsUUFBUSxTQUFTLG9CQUFvQjtHQUMxRSxNQUFNLGlCQUFpQixNQUFNLFVBQVU7SUFDbkMsTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7SUFDdkMsSUFBSSxTQUFTLE1BQU0sSUFDZixNQUFNLEdBQUcsUUFBUTtHQUV6QjtHQUNBLElBQUksVUFBVSxXQUFXLDRCQUNyQixRQUFRLFVBQVUsTUFBTSxLQUFLO0lBQ3pCO0lBQ0EsUUFBUSxZQUFZLFFBQVEsV0FBVztHQUMzQyxDQUFDO0dBRUwsSUFBSSxDQUFDLDhCQUNELFFBQVEsT0FBTyxVQUNmLENBQUMsR0FBRyxRQUFRLE9BQU8sbUJBQW1CLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxjQUFjLEtBQUssV0FBVyxZQUFZLEdBQUcsQ0FBQyxHQUNsRztHQUVKLDZCQUNNLGNBQWMsTUFBTSxLQUFLLElBQ3pCLFFBQVEsV0FBVyxJQUFJO0VBQ2pDO0NBQ0osR0FBRztFQUFDO0VBQU07RUFBUztFQUFTO0VBQWtCO0NBQVEsQ0FBQztDQUN2RCxPQUFPO0VBQ0gsTUFBQSxhQUFZLFlBQVksTUFBTTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUNyRSxNQUFBLGFBQVksWUFBWSxNQUFNO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3JFLFNBQUEsYUFBZSxZQUFZLFNBQVM7R0FDaEM7R0FDQTtHQUNBO0dBQ0E7RUFDSixDQUFDO0VBQ0QsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxRQUFBLGFBQWMsWUFBWSxRQUFRO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3pFLFFBQUEsYUFBYyxZQUFZLFVBQVU7R0FBQztHQUFjO0dBQU07R0FBUztFQUFRLENBQUM7RUFDM0UsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxTQUFBLGFBQWUsWUFBWSxTQUFTO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBO0VBQ0osQ0FBQztFQUNELFFBQUEsYUFBYyxjQUFjLE9BQU8sS0FBSyxPQUFPLFdBQVc7R0FDdEQsR0FBRztHQUNILEdBQUksVUFBVSxRQUFRLElBQUksRUFBRSxTQUFTLElBQUksQ0FBQztJQUN6QyxVQUFVLElBQUksUUFBUSxVQUFVLFdBQVc7RUFDaEQsRUFBRSxHQUFHO0dBQUM7R0FBUTtHQUFTO0VBQVEsQ0FBQztDQUNwQztBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQ0EsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDO0FBRS9ELElBQU0sY0FBYyxVQUFXLE9BQU8sU0FBUyxlQUFlLGlCQUFpQixRQUMxRSxPQUFPLFNBQVMsZUFBZSxpQkFBaUI7QUFDckQsSUFBTSxrQkFBa0IsVUFBVSxPQUFPLGFBQWEsZUFBZSxpQkFBaUI7QUFDdEYsSUFBTSxXQUFXLFFBQVE7Q0FDckIsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLEdBQUcsR0FDN0IsSUFBSSxhQUFhLElBQUksSUFBSSxLQUNyQixJQUFJLFNBQVMsUUFDYixDQUFDLGFBQWEsSUFBSSxJQUFJLEtBQ3RCLENBQUMsV0FBVyxJQUFJLElBQUksS0FDcEIsQ0FBQyxlQUFlLElBQUksSUFBSSxHQUFHO0VBQzNCLE1BQU0sU0FBUyxRQUFRLElBQUksSUFBSTtFQUMvQixLQUFLLE1BQU0sYUFBYSxPQUFPLEtBQUssTUFBTSxHQUN0QyxPQUFPLEdBQUcsSUFBSSxHQUFHLGVBQWUsT0FBTztDQUUvQyxPQUVJLE9BQU8sT0FBTyxJQUFJO0NBRzFCLE9BQU87QUFDWDtBQUVBLFNBQVMsZUFBZSxNQUFNO0NBQzFCLE1BQU0sU0FBUyxJQUFJLFNBQVM7Q0FDNUIsTUFBTSxvQkFBb0IsUUFBUSxJQUFJO0NBQ3RDLEtBQUssTUFBTSxPQUFPLG1CQUFtQjtFQUNqQyxNQUFNLFFBQVEsa0JBQWtCO0VBQ2hDLElBQUksWUFBWSxLQUFLLEdBQ2pCO0VBRUosSUFBSSxPQUFPLGFBQWEsZUFBZSxpQkFBaUIsVUFBVTtHQUM5RCxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsTUFBTSxRQUFRLFNBQVM7SUFDL0MsTUFBTSxPQUFPLE1BQU07SUFDbkIsUUFBUSxPQUFPLE9BQU8sS0FBSyxJQUFJO0dBQ25DO0dBQ0E7RUFDSjtFQUNBLE9BQU8sT0FBTyxLQUFLLEtBQUs7Q0FDNUI7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxTQUFTLGtCQUFrQixPQUFPO0NBQzlCLElBQUk7RUFDQSxPQUFPLEtBQUssVUFBVSxLQUFLO0NBQy9CLFNBQ08sSUFBSTtFQUNQLE9BQU87Q0FDWDtBQUNKO0FBRUEsU0FBUyxPQUFPLENBQUU7QUFFbEIsSUFBTSxlQUFlO0FBQ3JCLFNBQVMsc0JBQXNCLFFBQVE7Q0FDbkMsT0FBTyxVQUFVLE9BQU8sU0FBUztBQUNyQzs7Ozs7Ozs7Ozs7Ozs7O0FBZUEsU0FBUyxLQUFLLE9BQU87Q0FDakIsTUFBTSxjQUFjLHNCQUFzQjtDQUMxQyxNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBSztDQUNsRCxNQUFNLEVBQUUsVUFBVSxhQUFhLFdBQVcsTUFBTSxVQUFVLFFBQVEsU0FBUyxjQUFjLFNBQVMsU0FBUyxVQUFVLE1BQU0sUUFBUSxZQUFZLE1BQU0saUJBQWlCLHVCQUF1QixHQUFHLFNBQVM7Q0FDek0sTUFBTSxlQUFBLGFBQXFCLGNBQWM7RUFDckMsT0FBTyxRQUFRLGFBQWEsT0FBTyxNQUFNLFVBQVU7R0FDL0MsTUFBTSxXQUFXLGVBQWUsSUFBSTtHQUNwQyxNQUFNLGVBQWUsa0JBQWtCLElBQUk7R0FDM0MsSUFBSSxVQUNBLE1BQU0sU0FBUztJQUNYO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDSixDQUFDO0dBRUwsSUFBSSxTQUFTLE1BQU0sR0FDZixJQUFJO0lBQ0EsTUFBTSxrQkFBa0IsU0FBVSxXQUM5QixPQUFPLFFBQVEsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sV0FBVyxLQUFLLFlBQVksTUFBTSxrQkFBa0IsS0FBSyxLQUFLLEtBQUssQ0FBQyxLQUN4RyxXQUFXLEtBQUssS0FBSyxPQUFPO0lBQ2pDLElBQUksT0FBTztJQUNYLElBQUksZUFBZSxPQUFPLEdBQ3RCLE9BQU87U0FFTixJQUFJLGVBQWUsaURBQWlELEdBQ3JFLE9BQU8sSUFBSSxnQkFBZ0IsTUFBTSxLQUFLLFdBQVcsQ0FBQyxNQUFNLFdBQVcsQ0FDL0QsTUFDQSxTQUFTLEtBQUssSUFBSSxRQUFRLE1BQU0sSUFDcEMsQ0FBQyxDQUFDO1NBRUQsSUFBSSxlQUFlLDBCQUEwQixHQUM5QyxPQUFPLE1BQU0sS0FBSyxXQUFXLENBQUMsTUFBTSxXQUFXLEdBQUcsS0FBSyxHQUFHLFNBQVMsS0FBSyxJQUFJLFFBQVEsTUFBTSxLQUFLLEtBQUssQ0FBQyxDQUFDLEtBQUssRUFBRTtJQUVqSCxNQUFNLGVBQWUsVUFBVSxvQ0FBb0MsS0FBSyxLQUFLO0lBQzdFLE1BQU0sV0FBVyxNQUFNLE1BQU0sUUFBUTtLQUNqQztLQUNBLFNBQVM7TUFDTCxHQUFHLE9BQU8sWUFBWSxPQUFPLFFBQVEsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLFdBQVcsS0FBSyxZQUFZLE1BQU0sa0JBQ2pHLENBQUMsWUFBWSxLQUFLLENBQUMsQ0FBQztNQUN4QixHQUFJLFdBQ0EsQ0FBQyxZQUFZLE9BQU8sS0FBSyxFQUFFLGdCQUFnQixRQUFRO0tBQzNEO0tBQ0E7SUFDSixDQUFDO0lBQ0QsSUFBSSxZQUFZLENBQUMsZUFBZSxTQUFTLE1BQU0sR0FBRztLQUM5QyxRQUFRLEVBQUUsU0FBUyxDQUFDO0tBQ3BCLE9BQU8sRUFBRSxNQUFNLE9BQU8sU0FBUyxNQUFNLEVBQUU7SUFDM0MsT0FFSSxVQUFVLEVBQUUsU0FBUyxDQUFDO0dBRTlCLFNBQ08sT0FBTztJQUNWLFFBQVEsRUFBRSxNQUFNLENBQUM7SUFDakIsT0FBTyxFQUFFLE1BQU0sR0FBRztHQUN0QjtHQUVKLElBQUksV0FBVyxNQUFNLEdBQ2pCLElBQUk7SUFDQSxNQUFNLE9BQU8sUUFBUTtHQUN6QixTQUNPLE9BQU87SUFDVixRQUFRLEVBQUUsTUFBTSxDQUFDO0lBQ2pCLE9BQU8sRUFBRSxNQUFNLEdBQUc7R0FDdEI7RUFJUixDQUFDO0NBQ0wsR0FBRztFQUNDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKLENBQUM7Q0FDRCxNQUFNLFNBQUEsYUFBZSxZQUFZLE9BQU8sVUFBVTtFQUM5QyxNQUFNLE1BQU0sTUFBTSxhQUFhLEtBQUs7RUFDcEMsSUFBSSxPQUFPLFNBQVM7R0FDaEIsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUFFLG9CQUFvQixNQUFNLENBQUM7R0FDMUQsUUFBUSxTQUFTLGVBQWUsR0FBRztFQUN2QztDQUNKLEdBQUcsQ0FBQyxjQUFjLE9BQU8sQ0FBQztDQUMxQixhQUFNLGdCQUFnQjtFQUNsQixXQUFXLElBQUk7Q0FDbkIsR0FBRyxDQUFDLENBQUM7Q0FDTCxJQUFJLFFBQ0EsT0FBTyxPQUFPLEVBQUUsT0FBTyxDQUFDO0NBSzVCLE9BQUEsYUFBYyxjQUFjLFFBQVE7RUFBRSxZQUFZO0VBQWlCO0VBQVEsR0FBSSxDQUFDLFdBQVcsTUFBTSxLQUFLO0dBQUU7R0FBUTtFQUFRO0VBQUksVUFBVTtFQUFRLEdBQUc7Q0FBSyxHQUFHLFFBQVE7QUFDcks7QUFFQSxJQUFNLGFBQWEsRUFBRSxTQUFTLFVBQVUsT0FBTyxNQUFNLGFBQWMsT0FBTyxhQUFhO0NBQUU7Q0FBUztDQUFNO0NBQVU7QUFBTSxDQUFDLENBQUM7O0FBRTFILElBQU0scUJBQXFCO0FBRTNCLElBQUksc0JBQXNCO0NBQ3RCLElBQUksNkJBQWEsSUFBSSxJQUFJO0NBQ3pCLElBQUksa0JBQWtCO0NBQ3RCLE1BQU0sUUFBUSxVQUFVO0VBQ3BCLE1BQU0sWUFBWTtFQUNsQjtFQUNBLEtBQUssTUFBTSxZQUFZLFdBQ25CLFNBQVMsUUFBUSxTQUFTLEtBQUssS0FBSztFQUV4QyxjQUFjLGNBQWM7Q0FDaEM7Q0FDQSxNQUFNLGFBQWEsYUFBYTtFQUM1QixXQUFXLElBQUksUUFBUTtFQUN2QixPQUFPLEVBQ0gsbUJBQW1CO0dBQ2YsSUFBSSxpQkFBaUI7SUFDakIsYUFBYSxJQUFJLElBQUksVUFBVTtJQUMvQixrQkFBa0I7R0FDdEI7R0FDQSxXQUFXLE9BQU8sUUFBUTtFQUM5QixFQUNKO0NBQ0o7Q0FDQSxNQUFNLG9CQUFvQjtFQUN0Qiw2QkFBYSxJQUFJLElBQUk7RUFDckIsa0JBQWtCO0NBQ3RCO0NBQ0EsT0FBTztFQUNILElBQUksWUFBWTtHQUNaLE9BQU8sTUFBTSxLQUFLLFVBQVU7RUFDaEM7RUFDQTtFQUNBO0VBQ0E7Q0FDSjtBQUNKO0FBRUEsU0FBUyxrQkFBa0IsYUFBYSxZQUFZO0NBQ2hELE1BQU0sU0FBVSxNQUFNLFFBQVEsV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDO0NBQ25ELEtBQUssTUFBTSxPQUFPLGFBQ2QsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLGFBQWEsR0FBRyxHQUFHO0VBQ3hELE1BQU0sYUFBYSxZQUFZO0VBQy9CLE1BQU0sYUFBYSxXQUFXO0VBQzlCLElBQUksZUFDQyxTQUFTLFVBQVUsS0FBSyxNQUFNLFFBQVEsVUFBVSxNQUNqRCxZQUNBLE9BQU8sT0FBTyxrQkFBa0IsWUFBWSxVQUFVO09BRXJELElBQUksWUFBWSxNQUNqQixPQUFPLE9BQU87Q0FFdEI7Q0FFSixPQUFPO0FBQ1g7QUFFQSxJQUFNLFVBQVUsT0FBTyxRQUFRLFVBQVUsUUFDckMsYUFBYSxLQUFLLEtBQ2xCLE9BQU8sVUFBVSxlQUFlLEtBQUssT0FBTyxHQUFHO0FBQ25ELElBQUksT0FBTyxRQUFRLFNBQVM7Q0FDeEIsSUFBSSxDQUFDLE1BQ0QsT0FBTztDQUVYLElBQUksU0FBUztDQUNiLEtBQUssTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLGFBQWEsSUFBSSxHQUFHO0VBQ3pELElBQUksQ0FBQyxPQUFPLFFBQVEsR0FBRyxHQUVuQixPQUFPLE9BQU8sUUFBUSxJQUFJO0VBRTlCLFNBQVMsT0FBTztDQUNwQjtDQUNBLE9BQU87QUFDWDtBQUVBLElBQUksb0JBQW9CLFlBQVksUUFBUSxTQUFTO0FBRXJELElBQU0sa0JBQWtCLFdBQVc7Q0FDL0IsTUFBTSxVQUFVLENBQUMsR0FBRyxPQUFPLE9BQU87Q0FDbEMsT0FBTyxDQUFDLE9BQU8sWUFDWCxPQUFPLE9BQU8sS0FDZCxDQUFDLFFBQVEsTUFBTSxXQUFXLE9BQU8sZUFBZSxJQUM5QyxPQUFPLGtCQUFrQixRQUFRLFdBQVcsV0FBVyxDQUFDLE9BQU8sUUFBUSxJQUN2RSxRQUFRLE1BQU0sV0FBVyxPQUFPLGFBQWEsT0FBTyxlQUFlO0FBQzdFO0FBQ0EsSUFBSSxZQUFZLFFBQVEsZ0JBQWdCLEdBQUcsSUFDckMsSUFBSSxZQUFZLElBQUksaUJBQ3BCLElBQUksU0FBUyxnQkFBZ0IsaUJBQWlCLEdBQUcsSUFDN0MsZUFBZSxHQUFHLElBQ2xCLENBQUMsYUFBYSxHQUFHLEtBQ2Ysa0JBQWtCLE9BQ2xCLElBQUksVUFBVSxJQUFJO0FBRTlCLElBQUkscUJBQXFCLFFBQVEsYUFBYSxHQUFHLEtBQUssZ0JBQWdCLEdBQUc7QUFFekUsSUFBSSxRQUFRLFFBQVEsY0FBYyxHQUFHLEtBQUssSUFBSTtBQUU5QyxTQUFTLGlCQUFpQixPQUFPO0NBQzdCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBSyxTQUFTLEtBQUs7QUFDakQ7QUFDQSxTQUFTLHVCQUF1QixXQUFXLG1CQUFtQixTQUFTLElBQUksUUFBUSxDQUFDLEdBQUc7Q0FDbkYsS0FBSyxNQUFNLE9BQU8sV0FBVztFQUN6QixNQUFNLE9BQU8sU0FBUyxHQUFHLE9BQU8sR0FBRyxRQUFRO0VBQzNDLE1BQU0sUUFBUSxVQUFVO0VBQ3hCLElBQUksaUJBQWlCLEtBQUssS0FDdEIsaUJBQWlCLElBQUksbUJBQW1CLElBQUksQ0FBQyxHQUM3Qyx1QkFBdUIsT0FBTyxtQkFBbUIsTUFBTSxLQUFLO09BRzVELE1BQU0sS0FBSyxJQUFJO0NBRXZCO0NBQ0EsT0FBTztBQUNYO0FBRUEsSUFBSSxxQkFBcUIsU0FBUztDQUM5QixLQUFLLE1BQU0sT0FBTyxNQUNkLElBQUksV0FBVyxLQUFLLElBQUksR0FDcEIsT0FBTztDQUdmLE9BQU87QUFDWDtBQUVBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBTSxTQUFTLEtBQUssS0FBSyxDQUFDLGtCQUFrQixLQUFLO0FBQy9FO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVTtDQUNoQyxPQUFPLENBQUMsRUFBRSxZQUFZLFFBQVE7QUFDbEM7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ2xDLE9BQU8sTUFBTSxRQUFRLEtBQUssSUFDcEIsQ0FBQyxNQUFNLE1BQU0sU0FBUyxDQUFDLFlBQVksSUFBSSxDQUFDLElBQ3hDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQzlCO0FBQ0EsU0FBUyxnQkFBZ0IsV0FBVyxLQUFLO0NBQ3JDLElBQUksTUFBTSxRQUFRLFNBQVMsR0FDdkIsVUFBVSxPQUFPLEtBQUE7TUFHakIsT0FBTyxVQUFVO0FBRXpCO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxTQUFTLENBQUMsR0FBRyxXQUFXO0NBQ25ELEtBQUssTUFBTSxPQUFPLE1BQU07RUFDcEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsTUFBTSxXQUFXLGFBQWEsVUFBVTtFQUN4QyxJQUFJLGNBQWMsS0FBSyxNQUNsQixDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQUssQ0FBQyxpQkFBaUIsUUFBUSxJQUFJO0dBQ3hELE9BQU8sT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO0dBQzNDLGdCQUFnQixPQUFPLE9BQU8sTUFBTSxRQUFRO0dBQzVDLElBQUksc0JBQXNCLE9BQU8sSUFBSSxHQUNqQyxnQkFBZ0IsUUFBUSxHQUFHO0VBRW5DLE9BQ0ssSUFBSSxDQUFDLFlBQVksS0FBSyxHQUN2QixPQUFPLE9BQU87Q0FFdEI7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGVBQWUsTUFBTSxZQUFZLHVCQUF1QixXQUFXO0NBQ3hFLElBQUksQ0FBQyx1QkFDRCx3QkFBd0IsZ0JBQWdCLFlBQWEsTUFBTSxRQUFRLGtCQUFrQixVQUFVLElBQUksT0FBTyxVQUFVLElBQzlHLENBQUMsSUFDRCxDQUFDLEdBQUksU0FBUztDQUV4QixLQUFLLE1BQU0sT0FBTyxNQUFNO0VBQ3BCLE1BQU0sUUFBUSxLQUFLO0VBQ25CLE1BQU0sV0FBVyxhQUFhLFVBQVU7RUFDeEMsSUFBSSxjQUFjLEtBQUssTUFDbEIsQ0FBQyxNQUFNLFFBQVEsS0FBSyxLQUFLLENBQUMsaUJBQWlCLFFBQVEsSUFBSTtHQUN4RCxJQUFJLFlBQVksVUFBVSxLQUFLLFlBQVksc0JBQXNCLElBQUksR0FDakUsc0JBQXNCLE9BQU8sZ0JBQWdCLE9BQVEsTUFBTSxRQUFRLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFJLFFBQVE7UUFHOUYsZUFBZSxPQUFPLGtCQUFrQixVQUFVLElBQUksQ0FBQyxJQUFJLFdBQVcsTUFBTSxzQkFBc0IsTUFBTSxRQUFRO0dBRXBILElBQUksc0JBQXNCLHNCQUFzQixJQUFJLEdBQ2hELGdCQUFnQix1QkFBdUIsR0FBRztFQUVsRCxPQUNLLElBQUksVUFBVSxPQUFPLGtCQUFrQixVQUFVLElBQUksS0FBQSxJQUFZLFdBQVcsSUFBSSxHQUNqRixnQkFBZ0IsdUJBQXVCLEdBQUc7T0FHMUMsc0JBQXNCLE9BQU87Q0FFckM7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxJQUFJLDBCQUEwQixPQUFPLFNBQVM7Q0FDMUMsTUFBTSxXQUFXLEtBQUssTUFBTSxHQUFHO0NBQy9CLE1BQU0sVUFBVSxDQUFDO0NBQ2pCLElBQUksU0FBUyxTQUFTO0NBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsVUFBVSxNQUFNLFNBQVMsTUFDMUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsS0FBSyxNQUFNLElBQUksTUFBTSxHQUN4QyxRQUFRLEtBQUssR0FBRyxPQUFPLEdBQUcsU0FBUyxJQUFJO0NBRy9DLE9BQU87QUFDWDtBQUVBLElBQUksbUJBQW1CLE9BQU8sRUFBRSxlQUFlLGFBQWEsaUJBQWlCLFlBQVksS0FBSyxJQUN4RixRQUNBLGdCQUNJLFVBQVUsS0FDTixNQUNBLFFBQ0ksQ0FBQyxRQUNELFFBQ1IsZUFBZSxTQUFTLEtBQUssSUFDekIsSUFBSSxLQUFLLEtBQUssSUFDZCxhQUNJLFdBQVcsS0FBSyxJQUNoQjtBQUVsQixTQUFTLGNBQWMsSUFBSTtDQUN2QixNQUFNLE1BQU0sR0FBRztDQUNmLElBQUksWUFBWSxHQUFHLEdBQ2YsT0FBTyxJQUFJO0NBRWYsSUFBSSxhQUFhLEdBQUcsR0FDaEIsT0FBTyxjQUFjLEdBQUcsSUFBSSxDQUFDLENBQUM7Q0FFbEMsSUFBSSxpQkFBaUIsR0FBRyxHQUNwQixPQUFPLENBQUMsR0FBRyxJQUFJLGVBQWUsQ0FBQyxDQUFDLEtBQUssRUFBRSxZQUFZLEtBQUs7Q0FFNUQsSUFBSSxnQkFBZ0IsR0FBRyxHQUNuQixPQUFPLGlCQUFpQixHQUFHLElBQUksQ0FBQyxDQUFDO0NBRXJDLE9BQU8sZ0JBQWdCLElBQUksT0FBTyxFQUFFO0FBQ3hDO0FBRUEsSUFBSSxzQkFBc0IsYUFBYSxTQUFTLGNBQWMsOEJBQThCO0NBQ3hGLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxRQUFRLGFBQWE7RUFDNUIsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLFNBQVMsSUFBSSxRQUFRLE1BQU0sTUFBTSxFQUFFO0NBQ3ZDO0NBQ0EsT0FBTztFQUNIO0VBQ0EsT0FBTyxDQUFDLEdBQUcsV0FBVztFQUN0QjtFQUNBO0NBQ0o7QUFDSjtBQUVBLElBQUksZ0JBQWdCLFNBQVMsWUFBWSxJQUFJLElBQ3ZDLE9BQ0EsUUFBUSxJQUFJLElBQ1IsS0FBSyxTQUNMLFNBQVMsSUFBSSxJQUNULFFBQVEsS0FBSyxLQUFLLElBQ2QsS0FBSyxNQUFNLFNBQ1gsS0FBSyxRQUNUO0FBRWQsSUFBTSxpQkFBaUI7QUFDdkIsSUFBSSx3QkFBd0IsbUJBQW1CO0NBQzNDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLFVBQ25DLE9BQU87Q0FDWCxJQUFJLFdBQVcsZUFBZSxRQUFRLEdBQ2xDLE9BQU8sZUFBZSxTQUFTLFlBQVksU0FBUztDQUV4RCxJQUFJLFNBQVMsZUFBZSxRQUFRLEdBQzNCO09BQUEsTUFBTSxPQUFPLGVBQWUsVUFDN0IsSUFBSSxlQUFlLFNBQVMsSUFBSSxDQUFDLFlBQVksU0FBUyxnQkFDbEQsT0FBTztDQUFBO0NBSW5CLE9BQU87QUFDWDtBQUVBLElBQUksaUJBQWlCLFlBQVksUUFBUSxVQUNwQyxRQUFRLFlBQ0osQ0FBQyxZQUFZLFFBQVEsUUFBUSxLQUFLLFFBQVEsYUFBYSxTQUN4RCxDQUFDLFlBQVksUUFBUSxHQUFHLEtBQ3hCLENBQUMsWUFBWSxRQUFRLEdBQUcsS0FDeEIsQ0FBQyxZQUFZLFFBQVEsU0FBUyxLQUM5QixDQUFDLFlBQVksUUFBUSxTQUFTLEtBQzlCLFFBQVEsV0FDUixRQUFRO0FBRWhCLFNBQVMsa0JBQWtCLFFBQVEsU0FBUyxNQUFNO0NBQzlDLE1BQU0sUUFBUSxJQUFJLFFBQVEsSUFBSTtDQUM5QixJQUFLLFVBQVUsTUFBTSxRQUFRLE1BQU0sWUFBYSxNQUFNLFFBQVEsS0FBSyxHQUMvRCxPQUFPO0VBQ0g7RUFDQTtDQUNKO0NBRUosTUFBTSxRQUFRLEtBQUssTUFBTSxHQUFHO0NBQzVCLE9BQU8sTUFBTSxRQUFRO0VBQ2pCLE1BQU0sWUFBWSxNQUFNLEtBQUssR0FBRztFQUNoQyxNQUFNLFFBQVEsSUFBSSxTQUFTLFNBQVM7RUFDcEMsTUFBTSxhQUFhLElBQUksUUFBUSxTQUFTO0VBQ3hDLElBQUksU0FBUyxDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQUssU0FBUyxXQUMzQyxPQUFPLEVBQUUsS0FBSztFQUVsQixJQUFJLGNBQWMsV0FBVyxNQUN6QixPQUFPO0dBQ0gsTUFBTTtHQUNOLE9BQU87RUFDWDtFQUVKLElBQUksY0FBYyxXQUFXLFFBQVEsV0FBVyxLQUFLLE1BQ2pELE9BQU87R0FDSCxNQUFNLEdBQUcsVUFBVTtHQUNuQixPQUFPLFdBQVc7RUFDdEI7RUFFSixNQUFNLElBQUk7Q0FDZDtDQUNBLE9BQU8sRUFDSCxLQUNKO0FBQ0o7QUFFQSxJQUFJLHlCQUF5QixlQUFlLGlCQUFpQixXQUFXO0NBQ3BFLE1BQU0sT0FBTyxPQUFPLEtBQUssYUFBYSxDQUFDLENBQUMsUUFBUSxRQUFRLFFBQVEsTUFBTTtDQUN0RSxPQUFRLENBQUMsS0FBSyxVQUNULFVBQVUsS0FBSyxVQUFVLE9BQU8sS0FBSyxlQUFlLENBQUMsQ0FBQyxVQUN2RCxLQUFLLE1BQU0sUUFBUSxnQkFBZ0IsVUFDOUIsQ0FBQyxVQUFVLGdCQUFnQixJQUFJO0FBQzVDO0FBRUEsSUFBTSxlQUFlLGFBQWEsWUFBWSxVQUFVLFFBQ2xELGdCQUFnQixjQUFjLFlBQVksV0FBVyxhQUFhLEdBQUcsSUFDckUsWUFBWSxXQUFXLFVBQVUsS0FBSyxXQUFXLFdBQVcsV0FBVztBQUM3RSxJQUFJLHlCQUF5QixNQUFNLFlBQVksVUFBVTtDQUNyRCxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsU0FBUyxZQUNqQyxPQUFPO0NBRVgsSUFBSSxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQ25CLE9BQU8sWUFBWSxNQUFNLFlBQVksS0FBSztDQUU5QyxLQUFLLE1BQU0sZUFBZSxNQUN0QixJQUFJLGVBQWUsWUFBWSxhQUFhLFlBQVksS0FBSyxHQUN6RCxPQUFPO0NBR2YsT0FBTztBQUNYO0FBRUEsSUFBSSxrQkFBa0IsYUFBYSxXQUFXLGFBQWEsZ0JBQWdCLFNBQVM7Q0FDaEYsSUFBSSxLQUFLLFNBQ0wsT0FBTztNQUVOLElBQUksQ0FBQyxlQUFlLEtBQUssV0FDMUIsT0FBTyxFQUFFLGFBQWE7TUFFckIsSUFBSSxjQUFjLGVBQWUsV0FBVyxLQUFLLFVBQ2xELE9BQU8sQ0FBQztNQUVQLElBQUksY0FBYyxlQUFlLGFBQWEsS0FBSyxZQUNwRCxPQUFPO0NBRVgsT0FBTztBQUNYO0FBRUEsSUFBSSxtQkFBbUIsS0FBSyxTQUFTO0NBQ2pDLE1BQU0sUUFBUSxJQUFJLEtBQUssSUFBSTtDQUMzQixDQUFDLFFBQVEsS0FBSyxDQUFDLENBQUMsVUFDWixFQUFFLFNBQVMsTUFBTSxTQUNqQixNQUFNLEtBQUssSUFBSTtBQUN2QjtBQUVBLElBQU0saUJBQWlCO0NBQ25CLE1BQU0sZ0JBQWdCO0NBQ3RCLGdCQUFnQixnQkFBZ0I7Q0FDaEMsa0JBQWtCO0FBQ3RCO0FBQ0EsSUFBTSw2QkFBNkIsYUFBYSxvQkFBb0I7Q0FDaEUsS0FBSyxNQUFNLE9BQU8sYUFDZCxPQUFPLFlBQVk7Q0FFdkIsT0FBTyxPQUFPLGFBQWEsZUFBZTtBQUM5QztBQUNBLElBQU0scUJBQXFCO0NBQ3ZCLGFBQWE7Q0FDYixTQUFTO0NBQ1QsU0FBUztDQUNULGNBQWM7Q0FDZCxhQUFhO0NBQ2IsY0FBYztDQUNkLG9CQUFvQjtDQUNwQixTQUFTO0NBQ1QsZUFBZSxDQUFDO0NBQ2hCLGFBQWEsQ0FBQztDQUNkLGtCQUFrQixDQUFDO0FBQ3ZCO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUSxDQUFDLEdBQUc7Q0FDbkMsSUFBSSxXQUFXO0VBQ1gsR0FBRztFQUNILEdBQUc7Q0FDUDtDQUNBLElBQUksYUFBYTtFQUNiLEdBQUcsWUFBWSxrQkFBa0I7RUFDakMsV0FBVyxXQUFXLFNBQVMsYUFBYTtFQUM1QyxRQUFRLFlBQVksU0FBUyxNQUFNLEtBQUssQ0FBQztFQUN6QyxVQUFVLFNBQVMsWUFBWTtDQUNuQztDQUNBLElBQUksVUFBVSxDQUFDO0NBQ2YsSUFBSSxpQkFBaUIsU0FBUyxTQUFTLGFBQWEsS0FBSyxTQUFTLFNBQVMsTUFBTSxJQUMzRSxZQUFZLFNBQVMsaUJBQWlCLFNBQVMsTUFBTSxLQUFLLENBQUMsSUFDM0QsQ0FBQztDQUNQLElBQUksY0FBYyxTQUFTLG1CQUNyQixDQUFDLElBQ0QsWUFBWSxjQUFjO0NBQ2hDLElBQUksU0FBUztFQUNULFFBQVE7RUFDUixvQ0FBb0IsSUFBSSxJQUFJO0VBQzVCLE9BQU87RUFDUCxPQUFPO0VBQ1AsYUFBYTtDQUNqQjtDQUNBLElBQUksb0JBQW9CO0NBQ3hCLElBQUksU0FBUztFQUNULHVCQUFPLElBQUksSUFBSTtFQUNmLDBCQUFVLElBQUksSUFBSTtFQUNsQix5QkFBUyxJQUFJLElBQUk7RUFDakIsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsOEJBQWMsSUFBSSxJQUFJO0NBQzFCO0NBQ0EsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLHFDQUFxQixJQUFJLElBQUk7Q0FDbkMsSUFBSSw4QkFBOEIsbUJBQW1CLFNBQVMsSUFBSTtDQUNsRSxJQUFJLDZCQUE2QixtQkFBbUIsU0FBUyxjQUFjO0NBQzNFLE1BQU0sd0JBQXdCO0VBQzFCLFNBQVM7RUFDVCxhQUFhO0VBQ2Isa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixjQUFjO0VBQ2QsU0FBUztFQUNULFFBQVE7Q0FDWjtDQUNBLE1BQU0sa0JBQWtCLEVBQ3BCLEdBQUcsc0JBQ1A7Q0FDQSxNQUFNLDJCQUEyQixDQUFDO0NBQ2xDLE1BQU0sY0FBYyxHQUFHLFNBQVMsS0FBSyxNQUFNLFFBQVEsZ0JBQWdCLFFBQVEseUJBQXlCLElBQUk7Q0FDeEcsTUFBTSx3QkFBd0IsU0FBUztFQUNuQyxLQUFLLE1BQU0sY0FBYyxvQkFDckIsSUFBSSxzQkFBc0IsV0FBVyxNQUFNLE1BQU0sV0FBVyxLQUFLLEdBQzdELE9BQU87RUFHZixPQUFPO0NBQ1g7Q0FDQSxNQUFNLFlBQVk7RUFDZCxPQUFPLGNBQWM7RUFDckIsT0FBTyxjQUFjO0NBQ3pCO0NBQ0EsSUFBSSxrQkFBa0I7Q0FDdEIsSUFBSSxlQUFlO0NBQ25CLElBQUksa0JBQWtCO0NBQ3RCLE1BQU0sbUJBQW1CLENBQUM7Q0FDMUIsSUFBSSxtQ0FBbUMsU0FBUyxpQkFBaUIsZ0JBQWdCO0NBQ2pGLE1BQU0sWUFBWSxNQUFNLGNBQWMsU0FBUztFQUMzQyxhQUFhLE9BQU8sS0FBSztFQUN6QixPQUFPLFFBQVEsV0FBVyxVQUFVLElBQUk7Q0FDNUM7Q0FDQSxNQUFNLHNCQUFzQixTQUFTO0VBQ2pDLGFBQWEsT0FBTyxLQUFLO0VBQ3pCLE9BQU8sT0FBTztFQUNkLE9BQU8sb0JBQW9CO0NBQy9CO0NBQ0EsTUFBTSwwQkFBMEIsU0FBUztFQUNyQyxtQkFBbUIsSUFBSTtFQUN2QixNQUFNLFNBQVMsR0FBRyxLQUFLO0VBQ3ZCLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxtQkFBbUIsR0FDN0MsSUFBSSxXQUFXLE1BQU0sS0FBSyxtQkFBbUIsR0FBRztDQUV4RDtDQUNBLE1BQU0sWUFBWSxPQUFPLHNCQUFzQjtFQUMzQyxJQUFJLE9BQU8sYUFDUDtFQUVKLElBQUksQ0FBQyxTQUFTLGFBQWEsV0FBVyxTQUFTLEtBQUssb0JBQW9CO0dBQ3BFLE1BQU0sU0FBUyxFQUFFO0dBQ2pCLElBQUk7R0FDSixJQUFJLFNBQVMsVUFBVTtJQUNuQixVQUFVLGVBQWUsTUFBTSxXQUFXLEVBQUEsQ0FBRyxNQUFNO0lBQ25ELFdBQVcsbUJBQW1CLG9CQUFvQjtHQUN0RCxPQUVJLFVBQVUsTUFBTSx5QkFBeUI7SUFDckMsUUFBUTtJQUNSLGdCQUFnQjtJQUNoQixXQUFXLE9BQU87R0FDdEIsQ0FBQztHQUVMLElBQUksV0FBVyxtQkFBbUIsWUFBWSxXQUFXLFNBQ3JELFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFFBQ0osQ0FBQztFQUVUO0NBQ0o7Q0FDQSxNQUFNLDJCQUEyQixPQUFPLGlCQUFpQjtFQUNyRCxNQUFNLGFBQWEsQ0FBQyxHQUFHLEtBQUs7RUFDNUIsSUFBSSxDQUFDLFdBQVcsTUFBTSxTQUFTLFNBQzFCLGVBQ0ssSUFBSSxXQUFXLGtCQUFrQixJQUFJLE1BQU0sT0FDM0MsSUFBSSxXQUFXLGtCQUFrQixJQUFJLEVBQUUsR0FDN0M7RUFFSixNQUFNLG1CQUFtQixZQUFZLFdBQVcsZ0JBQWdCO0VBQ2hFLEtBQUssTUFBTSxRQUFRLFlBQ2YsSUFBSSxNQUNBLGVBQ00sSUFBSSxrQkFBa0IsTUFBTSxJQUFJLElBQ2hDLE1BQU0sa0JBQWtCLElBQUk7RUFHMUMsSUFBSSxDQUFDLFVBQVUsV0FBVyxrQkFBa0IsZ0JBQWdCLEdBQ3hELFdBQVcsbUJBQW1CO0NBRXRDO0NBQ0EsTUFBTSx1QkFBdUIsT0FBTyxpQkFBaUI7RUFDakQsSUFBSSxDQUFDLFNBQVMsWUFBWSxXQUFXLGdCQUFnQixrQkFBa0IsR0FBRztHQUN0RSx3QkFBd0IsU0FBUyxPQUFPLE9BQU8sWUFBWTtHQUMzRCxVQUFVLE1BQU0sS0FBSztJQUNqQixrQkFBa0IsV0FBVztJQUM3QixjQUFjLENBQUMsY0FBYyxXQUFXLGdCQUFnQjtHQUM1RCxDQUFDO0VBQ0w7Q0FDSjtDQUNBLE1BQU0sMkJBQTJCO0VBQzdCLFdBQVcsY0FBYyxlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxPQUFPO0NBQzNGO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLENBQUMsR0FBRyxRQUFRLE1BQU0sa0JBQWtCLE1BQU0sNkJBQTZCLFNBQVM7RUFDbkgsSUFBSSxRQUFRLFVBQVUsQ0FBQyxTQUFTLFVBQVU7R0FDdEMsT0FBTyxTQUFTO0dBQ2hCLE9BQU8sY0FBYztHQUNyQixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7R0FDL0IsTUFBTSxZQUFZLFNBQVMsTUFBTTtHQUNqQyxNQUFNLFNBQVMsWUFBWSxPQUFPLE9BQU8sQ0FBQyxHQUFHLEtBQUssSUFBSTtHQUN0RCxJQUFJLENBQUMsT0FBTyxtQkFBbUIsSUFBSSxJQUFJLEdBQ25DLE9BQU8sbUJBQW1CLElBQUksTUFBTSxNQUFNLFFBQVEsTUFBTSxJQUFJLE9BQU8sU0FBUyxDQUFDO0dBRWpGLElBQUksOEJBQThCLE1BQU0sUUFBUSxNQUFNLEdBQUc7SUFDckQsTUFBTSxjQUFjLE9BQU8sUUFBUSxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUs7SUFDNUQsWUFDTSxJQUFJLFNBQVMsTUFBTTtLQUFFLEdBQUc7S0FBYSxJQUFJO0lBQVUsQ0FBQyxJQUNwRCxtQkFBbUIsSUFBSSxTQUFTLE1BQU0sV0FBVztHQUMzRDtHQUNBLE1BQU0sbUJBQW1CLElBQUksV0FBVyxRQUFRLElBQUk7R0FDcEQsSUFBSSw4QkFBOEIsTUFBTSxRQUFRLGdCQUFnQixHQUFHO0lBQy9ELE1BQU0sWUFBWSxpQkFBaUI7SUFDbkMsTUFBTSxTQUFTLE9BQU8sa0JBQWtCLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSztJQUNqRSxJQUFJLFdBQ0EsT0FBTyxPQUFPO0lBRWxCLG1CQUFtQixJQUFJLFdBQVcsUUFBUSxNQUFNLE1BQU07SUFDdEQsZ0JBQWdCLFdBQVcsUUFBUSxJQUFJO0lBQ3ZDLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0dBQy9DO0dBQ0EsTUFBTSxxQkFBcUIsSUFBSSxXQUFXLGVBQWUsSUFBSTtHQUM3RCxNQUFNLDRCQUE0Qiw4QkFBOEIsTUFBTSxRQUFRLGtCQUFrQjtHQUNoRyxJQUFJLDJCQUEyQjtJQUMzQixNQUFNLGdCQUFnQixPQUFPLG9CQUFvQixLQUFLLE1BQU0sS0FBSyxJQUFJO0lBQ3JFLG1CQUFtQixJQUFJLFdBQVcsZUFBZSxNQUFNLGFBQWE7R0FDeEU7R0FDQSxNQUFNLG1CQUFtQixJQUFJLFdBQVcsYUFBYSxJQUFJO0dBQ3pELElBQUksOEJBQThCLE1BQU0sUUFBUSxnQkFBZ0IsR0FBRztJQUMvRCxNQUFNLGNBQWMsT0FBTyxrQkFBa0IsS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLO0lBQ3RFLG1CQUFtQixJQUFJLFdBQVcsYUFBYSxNQUFNLFdBQVc7R0FDcEU7R0FDQSxJQUFJLFdBQVcsYUFBYSxHQUN4QixtQkFBbUI7UUFHbkIsb0JBQW9CO0dBRXhCLFVBQVUsTUFBTSxLQUFLO0lBQ2pCO0lBQ0EsU0FBUyxVQUFVLE1BQU0sTUFBTTtJQUMvQixhQUFhLFdBQVc7SUFDeEIsR0FBSSw2QkFBNkIsRUFDN0IsZUFBZSxXQUFXLGNBQzlCO0lBQ0EsUUFBUSxXQUFXO0lBQ25CLFNBQVMsV0FBVztHQUN4QixDQUFDO0VBQ0wsT0FFSSxJQUFJLGFBQWEsTUFBTSxNQUFNO0NBRXJDO0NBQ0EsTUFBTSxnQkFBZ0IsTUFBTSxVQUFVO0VBQ2xDLElBQUksV0FBVyxRQUFRLE1BQU0sS0FBSztFQUNsQyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMzQyxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLFdBQVcsT0FDdkIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxjQUFjLFdBQVc7RUFDM0IsT0FBTyxLQUFLLG1CQUFtQixDQUFDLENBQUMsUUFBUSxrQkFBa0I7RUFDM0QsTUFBTSxZQUFZLENBQUMsY0FBYyxNQUFNO0VBQ3ZDLFdBQVcsU0FBUyxZQUFZLE1BQU07RUFDdEMsVUFBVSxNQUFNLEtBQUs7R0FDakIsUUFBUSxXQUFXO0dBQ25CLEdBQUksWUFBWSxFQUFFLFNBQVMsTUFBTSxJQUFJLENBQUM7RUFDMUMsQ0FBQztFQUNELENBQUMsYUFBYSxPQUFPLFNBQVMsVUFBVTtDQUM1QztDQUNBLE1BQU0sVUFBVSxTQUFTLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLGFBQWEsSUFBSTtDQUNqRSxNQUFNLCtCQUErQixTQUFTO0VBQzFDLE1BQU0sV0FBVyxPQUFPLElBQUk7RUFDNUIsSUFBSSxhQUFhO0VBQ2pCLElBQUksZ0JBQWdCO0VBQ3BCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLO0dBQzFDLE1BQU0sTUFBTSxTQUFTO0dBQ3JCLGFBQWEsa0JBQWtCLFVBQVUsSUFBSSxhQUFhLFdBQVc7R0FDckUsZ0JBQWdCLGtCQUFrQixhQUFhLElBQ3pDLGdCQUNBLGNBQWM7R0FDcEIsSUFBSSxlQUFlLFFBQVEsa0JBQWtCLE1BQ3pDLE9BQU87RUFFZjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0scUJBQXFCLFNBQVM7RUFDaEMsSUFBSSxDQUFDLE9BQU8sbUJBQW1CLE1BQzNCLE9BQU87RUFFWCxNQUFNLFdBQVcsT0FBTyxJQUFJO0VBQzVCLElBQUksT0FBTztFQUNYLElBQUksT0FBTztFQUNYLElBQUksYUFBYTtFQUNqQixJQUFJLHVCQUF1QjtFQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7R0FDdEMsSUFBSSxrQkFBa0IsSUFBSSxHQUN0QixPQUFPO0dBRVgsTUFBTSxNQUFNLFNBQVM7R0FDckIsT0FBTyxPQUFPLEdBQUcsS0FBSyxHQUFHLFFBQVE7R0FDakMsSUFBSSxNQUFNLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxLQUFLLFFBQ3BDLE9BQU8sZUFBZSxLQUNoQixRQUNBLE1BQU0sYUFDRixDQUFDLE1BQU0sdUJBQ1A7R0FFZCxJQUFJLE9BQU8sbUJBQW1CLElBQUksSUFBSSxHQUFHO0lBQ3JDLGFBQWEsSUFBSTtJQUNqQix1QkFBdUIsT0FBTyxtQkFBbUIsSUFBSSxJQUFJO0dBQzdEO0dBQ0EsT0FBTyxLQUFLO0dBQ1osSUFBSSxZQUFZLElBQUksS0FDaEIsZUFBZSxNQUNmLElBQUksY0FDSixDQUFDLFNBQVMsY0FBYyxzQkFDeEIsT0FBTztFQUVmO0VBQ0EsT0FBTztDQUNYO0NBQ0EsTUFBTSxrQkFBa0IsU0FBUztFQUM3QixJQUFJLE9BQU87RUFDWCxLQUFLLE1BQU0sT0FBTyxPQUFPLElBQUksR0FBRztHQUM1QixJQUFJLE1BQU0sUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLEtBQUssUUFDcEMsT0FBTztHQUVYLE9BQU8sUUFBUSxLQUFLO0VBQ3hCO0VBQ0EsT0FBTztDQUNYO0NBQ0EsTUFBTSx1QkFBdUIsTUFBTSxzQkFBc0IsT0FBTyxRQUFRO0VBQ3BFLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixJQUFJLE9BQU87R0FDUCxJQUFJLDRCQUE0QixJQUFJLEtBQUssa0JBQWtCLElBQUksR0FDM0Q7R0FFSixNQUFNLHVCQUF1QixZQUFZLElBQUksYUFBYSxJQUFJLENBQUM7R0FDL0QsTUFBTSxlQUFlLElBQUksYUFBYSxNQUFNLFlBQVksS0FBSyxJQUFJLElBQUksZ0JBQWdCLElBQUksSUFBSSxLQUFLO0dBQ2xHLE1BQU0sc0JBQXNCLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxXQUFXLFNBQVMsR0FBRztHQUN4RSxJQUFJLFlBQVksWUFBWSxLQUN2QixPQUFPLElBQUksa0JBQ1osdUJBQ0Esc0JBQXNCO0lBQ3RCLE1BQU0sYUFBYSx1QkFDYixlQUNBLGNBQWMsTUFBTSxFQUFFO0lBQzVCLElBQUksQ0FBQyxZQUFZLFVBQVUsS0FBSyxDQUFDLGVBQWUsSUFBSSxHQUFHO0tBQ25ELElBQUksV0FBVyxhQUFhLEtBQ3hCLENBQUMsVUFBVSxJQUFJLGFBQWEsSUFBSSxHQUFHLFVBQVUsR0FDN0Msb0JBQW9CO0tBRXhCLElBQUksYUFBYSxNQUFNLFVBQVU7S0FDakMsSUFBSSxxQkFDQSxvQkFBb0IsTUFBTSxVQUFVO0lBRTVDO0dBQ0osT0FFSSxjQUFjLE1BQU0sWUFBWTtHQUVwQyxJQUFJLE9BQU8sU0FBUyxDQUFDLE9BQU8sUUFBUTtJQUNoQyxJQUFJLFNBQVMsWUFDVCxXQUFXLGdCQUFnQixrQkFBa0IsR0FDN0MsUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXLFVBQVUsQ0FBQztTQUd4QyxVQUFVO0lBRWQsSUFBSSx3QkFDQSxXQUFXLFdBQ1gsV0FBVyxTQUFTLEdBRWhCO1NBQUEsQ0FEWSxVQUNMLEdBQUc7TUFDVixXQUFXLFVBQVU7TUFDckIsVUFBVSxNQUFNLEtBQUssRUFBRSxHQUFHLFdBQVcsQ0FBQztLQUMxQzs7SUFFSixJQUFJLFNBQVMsb0JBQ1Qsd0JBQ0EsQ0FBQyxZQUFZLElBQUksYUFBYSxJQUFJLENBQUMsS0FDbkMsVUFBVSxNQUFNLE1BQU0sR0FDdEIsT0FBTyxRQUFRO0dBRXZCO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sdUJBQXVCLE1BQU0sWUFBWSxhQUFhLGFBQWEsaUJBQWlCO0VBQ3RGLElBQUksb0JBQW9CO0VBQ3hCLElBQUksa0JBQWtCO0VBQ3RCLE1BQU0sU0FBUyxFQUNYLEtBQ0o7RUFDQSxJQUFJLENBQUMsU0FBUyxZQUFZLGdCQUFnQixNQUFNO0dBQzVDLElBQUksQ0FBQyxlQUFlLGFBQWE7SUFDN0IsTUFBTSx5QkFBeUIsVUFBVSxJQUFJLGdCQUFnQixJQUFJLEdBQUcsVUFBVTtJQUM5RSxJQUFJLFdBQVcsU0FBUyxHQUFHO0tBQ3ZCLGtCQUFrQixXQUFXO0tBQzdCLFdBQVcsVUFBVSxPQUFPLFVBQ3hCLENBQUMsMEJBQTBCLFVBQVU7S0FDekMsb0JBQW9CLG9CQUFvQixPQUFPO0lBQ25EO0lBQ0Esa0JBQWtCLENBQUMsQ0FBQyxJQUFJLFdBQVcsYUFBYSxJQUFJO0lBQ3BELElBQUksd0JBQ0EsTUFBTSxXQUFXLGFBQWEsSUFBSTtTQUVqQztLQUNELE1BQU0sb0JBQW9CLElBQUksZ0JBQWdCLElBQUk7S0FDbEQsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0tBQy9CLE1BQU0sYUFBYSxFQUFFLFNBQVMsTUFBTSxRQUMvQixTQUFTLGlCQUFpQixLQUFLLE1BQU0sUUFBUSxpQkFBaUIsS0FDN0QsZUFBZSxtQkFBbUIsWUFBWSxLQUFBLEdBQVcsS0FBSyxJQUM5RDtLQUNOLElBQUksV0FBVyxhQUFhLE1BQU0sVUFBVTtJQUNoRDtJQUNBLElBQUksdUJBQXVCO0lBQzNCLElBQUkscUJBQ0MsMkJBQ0ksV0FBVyxTQUFTLElBQUksV0FBVyxVQUFVLFVBQVUsSUFBSztLQUNqRSxvQkFBb0I7S0FDcEIsTUFBTSxrQkFBa0IsZUFBZSxnQkFBZ0IsYUFBYSxLQUFBLEdBQVcsT0FBTztLQUN0RixJQUFJLENBQUMsVUFBVSxXQUFXLGFBQWEsZUFBZSxHQUFHO01BQ3JELHVCQUF1QjtNQUN2QiwwQkFBMEIsV0FBVyxhQUFhLGVBQWU7S0FDckU7SUFDSjtJQUNBLE9BQU8sY0FBYyxXQUFXO0lBQ2hDLG9CQUNJLHFCQUNLLFdBQVcsYUFBYSxNQUNwQix3QkFDRyxvQkFBb0IsQ0FBQztHQUN6QztHQUNBLElBQUksYUFBYTtJQUNiLE1BQU0seUJBQXlCLElBQUksV0FBVyxlQUFlLElBQUksSUFDM0QsSUFBSSxXQUFXLGVBQWUsSUFBSSxJQUNsQyxLQUFBO0lBQ04sSUFBSSxDQUFDLHdCQUF3QjtLQUN6QixJQUFJLFdBQVcsZUFBZSxNQUFNLFdBQVc7S0FDL0MsT0FBTyxnQkFBZ0IsV0FBVztLQUNsQyxvQkFDSSxxQkFDSyxXQUFXLGVBQWUsS0FDdkIsMkJBQTJCO0lBQzNDO0dBQ0o7R0FDQSxxQkFBcUIsZ0JBQWdCLFVBQVUsTUFBTSxLQUFLLE1BQU07RUFDcEU7RUFDQSxPQUFPLG9CQUFvQixTQUFTLENBQUM7Q0FDekM7Q0FDQSxNQUFNLHVCQUF1QixNQUFNLFNBQVMsT0FBTyxlQUFlO0VBQzlELE1BQU0scUJBQXFCLElBQUksV0FBVyxRQUFRLElBQUk7RUFDdEQsTUFBTSxvQkFBb0IsV0FBVyxTQUFTLEtBQzFDLFVBQVUsT0FBTyxLQUNqQixXQUFXLFlBQVk7RUFDM0IsSUFBSSxTQUFTLGNBQWMsT0FBTztHQUM5QixvQkFBb0IsUUFBUSxTQUFTLFlBQVksYUFBYSxNQUFNLEtBQUssQ0FBQztHQUMxRSxvQkFBb0IsS0FBSyxDQUFDLFNBQVMsVUFBVTtFQUNqRCxPQUNLO0dBQ0QsbUJBQW1CLElBQUk7R0FDdkIsUUFDTSxJQUFJLFdBQVcsUUFBUSxNQUFNLEtBQUssSUFDbEMsTUFBTSxXQUFXLFFBQVEsSUFBSTtHQUNuQyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMvQztFQUNBLEtBQUssUUFDQyxDQUFDLFVBQVUsb0JBQW9CLE9BQU8sSUFBSSxJQUMxQyx1QkFDRixDQUFDLGNBQWMsVUFBVSxLQUN6QixtQkFBbUI7R0FDbkIsTUFBTSxtQkFBbUI7SUFDckIsR0FBRztJQUNILEdBQUkscUJBQXFCLFVBQVUsT0FBTyxJQUFJLEVBQUUsUUFBUSxJQUFJLENBQUM7SUFDN0QsUUFBUSxXQUFXO0lBQ25CO0dBQ0o7R0FDQSxVQUFVLE1BQU0sS0FBSyxnQkFBZ0I7RUFDekM7Q0FDSjtDQUNBLE1BQU0sYUFBYSxPQUFPLFNBQVM7RUFDL0Isb0JBQW9CLE1BQU0sSUFBSTtFQUM5QixPQUFPLE1BQU0sU0FBUyxTQUFTLGFBQWEsU0FBUyxTQUFTLG1CQUFtQixRQUFRLE9BQU8sT0FBTyxTQUFTLFNBQVMsY0FBYyxTQUFTLHlCQUF5QixDQUFDO0NBQzlLO0NBQ0EsTUFBTSw4QkFBOEIsT0FBTyxVQUFVO0VBQ2pELE1BQU0sY0FBYztFQUNwQixNQUFNLGlCQUFpQjtFQUN2QixNQUFNLGtCQUFrQixRQUNsQixNQUFNLFFBQVEsU0FBUyxJQUFJLFNBQVMsSUFBSSxDQUFDLElBQ3pDLENBQUM7RUFDUCxNQUFNLEVBQUUsV0FBVyxNQUFNLFdBQVcsS0FBSztFQUN6QyxJQUFJLGdCQUFnQixjQUNoQixPQUFPO0VBRVgsb0JBQW9CLEtBQUs7RUFDekIsSUFBSSxPQUFPO0dBQ1AsS0FBSyxNQUFNLFFBQVEsT0FBTztJQUN0QixJQUFJLGdCQUFnQixTQUFTLElBQUksTUFDNUIsQ0FBQyxJQUFJLFNBQVMsSUFBSSxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQjtLQUNsRSxNQUFNLFFBQVEsSUFBSTtLQUNsQjtJQUNKO0lBQ0EsTUFBTSxRQUFRLElBQUksUUFBUSxJQUFJO0lBQzlCLHVCQUF1QixJQUFJO0lBQzNCLE1BQU0sd0JBQXdCLE9BQU8sTUFBTSxJQUFJLElBQUksS0FDL0MsU0FBUyxLQUFLLEtBQ2QsQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsTUFBTSxRQUFRLENBQUMsT0FBTyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUM7SUFDaEUsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0lBQy9CLE1BQU0sa0JBQWtCLFNBQVMsS0FBSyxLQUFLLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxNQUFNLFFBQVEsUUFBUSxJQUFJO0lBQ3hGLHdCQUNNLDBCQUEwQixXQUFXLFFBQVEsR0FBRyxPQUFPLE1BQU0sR0FBRyxJQUFJLElBQ25FLFVBQVUsTUFBTSxRQUFRLE1BQU0sWUFDN0IsTUFBTSxRQUFRLEtBQUssS0FDbEIsU0FBUyxLQUFLLEtBQUssa0JBQ2xCLElBQUksV0FBVyxRQUFRLE1BQU0sS0FBSyxJQUNsQyxNQUFNLFdBQVcsUUFBUSxJQUFJO0dBQzNDO0dBQ0EsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFDL0MsT0FDSztHQUNELE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsa0JBQWtCO0dBQzNELFdBQVcsU0FBUztFQUN4QjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sZUFBZSxPQUFPLEVBQUUsTUFBTSxnQkFBaUI7RUFDakQsSUFBSSxTQUFTLFVBQVU7R0FDbkIsTUFBTSxjQUFjO0dBQ3BCLE1BQU0sU0FBUyxNQUFNLFNBQVMsU0FBUztJQUNuQyxZQUFZO0lBQ1osV0FBVztJQUNYO0lBQ0E7R0FDSixDQUFDO0dBQ0QsSUFBSSxnQkFBZ0IsY0FDaEIsT0FBTztHQUVYLElBQUksU0FBUyxNQUFNLEdBQUc7SUFDbEIsSUFBSSxVQUFVO0lBQ2QsWUFBWSxlQUFlO0lBQzNCLEtBQUssTUFBTSxPQUFPLFFBQVE7S0FDdEIsTUFBTSxRQUFRLE9BQU87S0FDckIsSUFBSSxPQUFPO01BQ1AsVUFBVTtNQUNWLFNBQVMsR0FBRyxnQkFBZ0IsR0FBRyxPQUFPO09BQ2xDLFNBQVMsU0FBUyxNQUFNLE9BQU8sSUFBSSxNQUFNLFVBQVU7T0FDbkQsTUFBTSxNQUFNLFFBQVEsdUJBQXVCO01BQy9DLENBQUM7S0FDTDtJQUNKO0lBQ0EsT0FBTztHQUNYLE9BQ0ssSUFBSSxTQUFTLE1BQU0sS0FBSyxDQUFDLFFBQVE7SUFDbEMsU0FBUyxpQkFBaUI7S0FDdEIsU0FBUyxVQUFVO0tBQ25CLE1BQU0sdUJBQXVCO0lBQ2pDLENBQUM7SUFDRCxPQUFPO0dBQ1gsT0FDSztJQUNELFlBQVksZUFBZTtJQUMzQixPQUFPO0dBQ1g7RUFDSjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sMkJBQTJCLE9BQU8sRUFBRSxRQUFRLGdCQUFnQixNQUFNLFdBQVcsVUFBVTtFQUN6RixPQUFPO0VBQ1AsbUJBQW1CO0NBQ3ZCLFFBQVM7RUFDTCxNQUFNLGNBQWM7RUFDcEIsSUFBSSxTQUFTLFlBQVksQ0FBQyxRQUFRLG1CQUFtQjtHQUNqRCxRQUFRLG9CQUFvQjtHQUs1QixJQUFJLENBQUMsTUFKZ0IsYUFBYTtJQUM5QjtJQUNBO0dBQ0osQ0FBQyxHQUNZO0lBQ1QsUUFBUSxRQUFRO0lBQ2hCLElBQUksZ0JBQ0EsT0FBTyxRQUFRO0dBRXZCO0VBQ0o7RUFDQSxLQUFLLE1BQU0sUUFBUSxRQUFRO0dBQ3ZCLE1BQU0sUUFBUSxPQUFPO0dBQ3JCLElBQUksT0FBTztJQUNQLE1BQU0sRUFBRSxJQUFJLEdBQUcsZUFBZTtJQUM5QixJQUFJLElBQUk7S0FDSixNQUFNLG1CQUFtQixPQUFPLE1BQU0sSUFBSSxHQUFHLElBQUk7S0FDakQsTUFBTSxvQkFBb0IsTUFBTSxNQUFNLHFCQUFxQixNQUFNLEVBQUU7S0FDbkUsTUFBTSwrQkFBK0IsV0FBVyxnQkFBZ0Isa0JBQWtCO0tBQ2xGLElBQUkscUJBQXFCLDhCQUNyQixvQkFBb0IsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJO0tBRXZDLE1BQU0saUJBQWlCO0tBQ3ZCLE1BQU0sYUFBYSxNQUFNLGNBQWMsT0FBTyxPQUFPLFVBQVUsYUFBYSxrQ0FBa0MsU0FBUyw2QkFBNkIsQ0FBQyxnQkFBZ0IsZ0JBQWdCO0tBQ3JMLElBQUksZ0JBQWdCLGNBQ2hCLE9BQU8sUUFBUTtLQUVuQixJQUFJLHFCQUFxQiw4QkFDckIsb0JBQW9CLENBQUMsR0FBRyxJQUFJLENBQUM7S0FFakMsSUFBSSxDQUFDLElBQUksU0FBUyxHQUFHLElBQUksS0FDckIsaUJBQWlCLEdBQUcsUUFBUSxnQkFDNUI7S0FFSixJQUFJLFdBQVcsR0FBRyxPQUFPO01BQ3JCLFFBQVEsUUFBUTtNQUNoQixJQUFJLGdCQUNBO0tBRVI7S0FDQSxJQUFJLENBQUMsZ0JBQWdCO01BQ2pCLG1CQUFtQixHQUFHLElBQUk7TUFDMUIsSUFBSSxZQUFZLEdBQUcsSUFBSSxJQUNqQixtQkFDSSwwQkFBMEIsV0FBVyxRQUFRLFlBQVksR0FBRyxJQUFJLElBQ2hFLElBQUksV0FBVyxRQUFRLEdBQUcsTUFBTSxXQUFXLEdBQUcsS0FBSyxJQUN2RCxNQUFNLFdBQVcsUUFBUSxHQUFHLElBQUk7S0FDMUM7S0FDQSxJQUFJLFNBQVMsNkJBQTZCLFdBQVcsR0FBRyxPQUNwRDtJQUVSO0lBQ0EsQ0FBQyxjQUFjLFVBQVUsS0FDcEIsTUFBTSx5QkFBeUI7S0FDNUI7S0FDQTtLQUNBLFFBQVE7S0FDRjtLQUNOO0lBQ0osQ0FBQztHQUNUO0VBQ0o7RUFDQSxPQUFPLFFBQVE7Q0FDbkI7Q0FDQSxNQUFNLHlCQUF5QjtFQUMzQixLQUFLLE1BQU0sUUFBUSxPQUFPLFNBQVM7R0FDL0IsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0dBQy9CLFVBQ0ssTUFBTSxHQUFHLE9BQ0osTUFBTSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsSUFDdkMsQ0FBQyxLQUFLLE1BQU0sR0FBRyxHQUFHLE1BQ3hCLFdBQVcsSUFBSTtFQUN2QjtFQUNBLE9BQU8sMEJBQVUsSUFBSSxJQUFJO0NBQzdCO0NBQ0EsTUFBTSxhQUFhLE1BQU0sVUFBVSxRQUFRLENBQUMsWUFBWSxJQUFJLEtBQUssSUFBSSxhQUFhLE1BQU0sSUFBSSxHQUN4RixDQUFDLFVBQVUsT0FBTyxRQUFRLGNBQWMsZ0JBQWdCLGNBQWM7Q0FDMUUsTUFBTSxhQUFhLE9BQU8sY0FBYyxhQUFhO0VBQ2pELE1BQU0sU0FBUyxPQUFPLFFBQ2hCLGNBQ0EsWUFBWSxZQUFZLEtBQUssQ0FBQyxZQUFZLEtBQUssSUFDM0MsaUJBQ0E7RUFDVixPQUFPLG9CQUFvQixPQUFPLFFBQVEsWUFBWSxLQUFLLElBQUksRUFBRSxHQUFHLE9BQU8sSUFBSSxRQUFRLFVBQVUsWUFBWTtDQUNqSDtDQUNBLE1BQU0sa0JBQWtCLFNBQVMsUUFBUSxJQUFJLE9BQU8sUUFBUSxjQUFjLGdCQUFnQixNQUFNLFNBQVMsbUJBQW1CLElBQUksZ0JBQWdCLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Q0FDL0osTUFBTSxpQkFBaUIsTUFBTSxPQUFPLFVBQVUsQ0FBQyxHQUFHLFlBQVksT0FBTyxhQUFhLE9BQU8sa0JBQWtCLFVBQVU7RUFDakgsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLElBQUksYUFBYTtFQUNqQixJQUFJLE9BQU87R0FDUCxNQUFNLGlCQUFpQixNQUFNO0dBQzdCLElBQUksZ0JBQWdCO0lBQ2hCLENBQUMsZUFBZSxZQUNaLElBQUksYUFBYSxNQUFNLGdCQUFnQixPQUFPLGNBQWMsQ0FBQztJQUNqRSxhQUNJLGNBQWMsZUFBZSxHQUFHLEtBQUssa0JBQWtCLEtBQUssSUFDdEQsS0FDQTtJQUNWLElBQUksaUJBQWlCLGVBQWUsR0FBRyxHQUNuQyxDQUFDLEdBQUcsZUFBZSxJQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsY0FBZSxVQUFVLFdBQVcsV0FBVyxTQUFTLFVBQVUsS0FBSyxDQUFFO1NBRWpILElBQUksZUFBZSxNQUFNO0tBQzFCLElBQUksZ0JBQWdCLGVBQWUsR0FBRyxHQUNsQyxlQUFlLEtBQUssU0FBUyxnQkFBZ0I7TUFDekMsSUFBSSxDQUFDLFlBQVksa0JBQWtCLENBQUMsWUFBWSxVQUFVO09BQ3RELElBQUksTUFBTSxRQUFRLFVBQVUsR0FDeEIsWUFBWSxVQUFVLENBQUMsQ0FBQyxXQUFXLE1BQU0sU0FBUyxTQUFTLFlBQVksS0FBSztZQUc1RSxZQUFZLFVBQ1IsZUFBZSxZQUFZLFNBQVMsQ0FBQyxDQUFDO01BRWxEO0tBQ0osQ0FBQztVQUdELGVBQWUsS0FBSyxTQUFTLGFBQWMsU0FBUyxVQUFVLFNBQVMsVUFBVSxVQUFXO0lBRXBHLE9BQ0ssSUFBSSxZQUFZLGVBQWUsR0FBRyxHQUNuQyxlQUFlLElBQUksUUFBUTtTQUUxQjtLQUNELGVBQWUsSUFBSSxRQUFRO0tBQzNCLElBQUksQ0FBQyxlQUFlLElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyxpQkFDNUMsVUFBVSxNQUFNLEtBQUs7TUFDakI7TUFDQSxRQUFRLFlBQ0YsY0FDQSxxQkFBcUIsSUFBSSxJQUNyQixZQUFZLFdBQVcsSUFDdkIsS0FBQTtLQUNkLENBQUM7SUFFVDtHQUNKO0VBQ0o7RUFDQSxDQUFDLFFBQVEsZUFBZSxRQUFRLGdCQUM1QixvQkFBb0IsTUFBTSxTQUN0QixNQUFNLE1BQ04sQ0FBQyxNQUFNLEdBQUcsYUFDVCxNQUFNLEdBQUcsaUJBQ04sTUFBTSxHQUFHLGVBQ1QsTUFBTSxHQUFHLGNBQ1gsZ0JBQWdCLE9BQU8sTUFBTSxFQUFFLElBQy9CLFlBQVksUUFBUSxhQUFhLFFBQVEsYUFBYSxDQUFDLFVBQVU7RUFDM0UsUUFBUSxrQkFDSixRQUFRLE1BQU0sRUFDVixZQUFZLFFBQVEsV0FDeEIsQ0FBQztFQUNMLElBQUksUUFBUSxrQkFDUixTQUNBLE1BQU0sTUFDTixNQUFNLEdBQUcsU0FDUixDQUFDLE1BQU0sUUFBUSxNQUFNLEdBQUcsSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLFNBQVMsSUFDekQsUUFBUSxNQUFNLEdBQUcsSUFBSTtDQUU3QjtDQUNBLE1BQU0sa0JBQWtCLE1BQU0sT0FBTyxTQUFTLFlBQVksT0FBTyxhQUFhLE9BQU8sa0JBQWtCLFVBQVU7RUFDN0csS0FBSyxNQUFNLFlBQVksT0FBTztHQUMxQixJQUFJLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxPQUFPLFFBQVEsR0FDckQ7R0FFSixNQUFNLGFBQWEsTUFBTTtHQUN6QixNQUFNLFlBQVksT0FBTyxNQUFNO0dBQy9CLE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztHQUNwQyxJQUFJLE9BQU8sTUFBTSxJQUFJLFNBQVMsR0FDMUIsVUFBVSxNQUFNLEtBQUs7SUFDakIsTUFBTTtJQUNOLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztHQUM3RCxDQUFDO0dBRUwsQ0FBQyxPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQ2xCLFNBQVMsVUFBVSxLQUNsQixTQUFTLENBQUMsTUFBTSxPQUNqQixDQUFDLGFBQWEsVUFBVSxJQUN0QixlQUFlLFdBQVcsWUFBWSxTQUFTLFdBQVcsWUFBWSxlQUFlLElBQ3JGLGNBQWMsV0FBVyxZQUFZLFNBQVMsV0FBVyxZQUFZLGVBQWU7RUFDOUY7Q0FDSjtDQUNBLE1BQU0sYUFBYSxNQUFNLE9BQU8sU0FBUyxXQUFXLGdCQUFnQixVQUFVO0VBQzFFLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixNQUFNLGVBQWUsT0FBTyxNQUFNLElBQUksSUFBSTtFQUMxQyxNQUFNLGFBQWEsWUFBWSxRQUFRLFlBQVksS0FBSztFQUV4RCxNQUFNLG1CQUFtQixVQURILElBQUksYUFBYSxJQUNRLEdBQUcsVUFBVTtFQUM1RCxJQUFJLENBQUMsa0JBQ0QsSUFBSSxhQUFhLE1BQU0sVUFBVTtFQUVyQyxJQUFJLGNBQWM7R0FDZCxVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztHQUM3RCxDQUFDO0dBQ0QsSUFBSSxXQUFXLFdBQVcsYUFBYSxLQUFLLFFBQVEsYUFBYTtJQUM3RCxtQkFBbUI7SUFDbkIsV0FBVyxVQUFVLFVBQVUsTUFBTSxVQUFVO0lBQy9DLElBQUksQ0FBQyxlQUNELFVBQVUsTUFBTSxLQUFLO0tBQ2pCO0tBQ0EsYUFBYSxXQUFXO0tBQ3hCLFNBQVMsV0FBVztJQUN4QixDQUFDO0dBRVQ7R0FDQSxRQUFRLGtCQUNKLFFBQVEsTUFBTSxFQUNWLFlBQVksUUFBUSxXQUN4QixDQUFDO0VBQ1QsT0FDSztHQUNELE1BQU0sVUFBVyxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVyxVQUN0RCxjQUFjLFVBQVU7R0FDNUIsTUFBTSxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQztHQUM5QyxJQUFJLENBQUMsU0FBUyxNQUFNLE1BQU0sa0JBQWtCLFVBQVUsS0FBSyxTQUN2RCxjQUFjLE1BQU0sWUFBWSxTQUFTLFdBQVcsZUFBZSxlQUFlO1FBR2xGLGVBQWUsTUFBTSxZQUFZLFNBQVMsV0FBVyxlQUFlLGVBQWU7RUFFM0Y7RUFDQSxJQUFJLENBQUMsb0JBQW9CLENBQUMsZUFBZTtHQUNyQyxNQUFNLFVBQVUsVUFBVSxNQUFNLE1BQU07R0FDdEMsTUFBTSxjQUFjLE9BQU8sU0FBUyxVQUFVLE9BQU8sS0FBQTtHQUNyRCxNQUFNLHNCQUFzQixlQUN0QixDQUFDLElBQ0QsdUJBQXVCLE9BQU8sT0FBTyxJQUFJO0dBQy9DLE1BQU0sU0FBUyxZQUNULGNBQ0EscUJBQXFCLFdBQVcsS0FDOUIsb0JBQW9CLEtBQUssb0JBQW9CLElBQzNDLFlBQVksV0FBVyxJQUN2QixLQUFBO0dBQ1YsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBSSxXQUFXO0lBQ2YsTUFBTTtJQUNOO0dBQ0osQ0FBQztHQUNELEtBQUssTUFBTSxZQUFZLHFCQUNuQixVQUFVLE1BQU0sS0FBSztJQUFFLE1BQU07SUFBVTtHQUFPLENBQUM7RUFFdkQ7Q0FDSjtDQUNBLE1BQU0sWUFBWSxNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sVUFBVSxNQUFNLE9BQU8sU0FBUyxLQUFLO0NBQ3JGLE1BQU0sYUFBYSxZQUFZLFVBQVUsQ0FBQyxNQUFNO0VBQzVDLE1BQU0sb0JBQW9CLFdBQVcsVUFBVSxJQUN6QyxXQUFXLFdBQVcsSUFDdEI7RUFDTixJQUFJLENBQUMsVUFBVSxhQUFhLGlCQUFpQixHQUFHO0dBQzVDLGNBQWM7SUFDVixHQUFHO0lBQ0gsR0FBRztHQUNQO0dBQ0EsS0FBSyxNQUFNLDZCQUFhLElBQUksSUFBSSxDQUFDLEdBQUcsT0FBTyxPQUFPLEdBQUcsT0FBTyxLQUFLLENBQUMsR0FDOUQsSUFBSSxJQUFJLG1CQUFtQixTQUFTLEdBQ2hDLFVBQVUsV0FBVyxJQUFJLG1CQUFtQixTQUFTLEdBQUcsU0FBUyxNQUFNLElBQUk7R0FHbkYsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBRztJQUNILE1BQU0sS0FBQTtJQUNOLE1BQU0sS0FBQTtJQUNOLEdBQUksbUJBQW1CLE9BQU8sRUFBRSxRQUFRLFlBQVksSUFBSSxDQUFDO0dBQzdELENBQUM7R0FDRCxJQUFJLFFBQVEsZ0JBQ1IsVUFBVTtFQUVsQjtDQUNKO0NBQ0EsTUFBTSxXQUFXLE9BQU8sVUFBVTtFQUM5QixPQUFPLFFBQVE7RUFDZixNQUFNLFNBQVMsTUFBTTtFQUNyQixJQUFJLE9BQU8sT0FBTztFQUNsQixJQUFJLHNCQUFzQjtFQUMxQixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsTUFBTSxpQkFBaUI7RUFDdkIsTUFBTSw4QkFBOEIsZUFBZTtHQUMvQyxzQkFDSSxDQUFDLENBQUMsSUFBSSxTQUFTLElBQUksS0FDZixFQUFFLGlCQUFpQixRQUFRLG1CQUMzQixVQUFVLFlBQVksSUFBSSxhQUFhLE1BQU0sVUFBVSxDQUFDO0VBQ3BFO0VBQ0EsSUFBSSxPQUFPO0dBQ1AsT0FBTyxjQUFjO0dBQ3JCLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSSxtQkFBbUI7R0FDdkIsTUFBTSxhQUFhLE9BQU8sT0FDcEIsY0FBYyxNQUFNLEVBQUUsSUFDdEIsY0FBYyxLQUFLO0dBQ3pCLE1BQU0sY0FBYyxNQUFNLFNBQVMsT0FBTyxRQUFRLE1BQU0sU0FBUyxPQUFPO0dBQ3hFLE1BQU0sd0JBQXdCLENBQUMsY0FBYyxNQUFNLEVBQUUsS0FDakQsQ0FBQyxTQUFTLFlBQ1YsQ0FBQyxTQUFTLFlBQ1YsQ0FBQyxJQUFJLFdBQVcsUUFBUSxJQUFJLEtBQzVCLENBQUMsTUFBTSxHQUFHO0dBQ2QsTUFBTSx1QkFBdUIseUJBQ3pCLGVBQWUsYUFBYSxJQUFJLFdBQVcsZUFBZSxJQUFJLEdBQUcsV0FBVyxhQUFhLDRCQUE0QiwyQkFBMkI7R0FDcEosTUFBTSxVQUFVLFVBQVUsTUFBTSxRQUFRLFdBQVc7R0FDbkQsSUFBSSxhQUFhLE1BQU0sWUFBWSxVQUFVLENBQUM7R0FDOUMsSUFBSSxhQUNJO1FBQUEsQ0FBQyxVQUFVLENBQUMsT0FBTyxVQUFVO0tBQzdCLE1BQU0sR0FBRyxVQUFVLE1BQU0sR0FBRyxPQUFPLEtBQUs7S0FDeEMsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLHFCQUFxQixJQUFJLEdBQUc7TUFDakUsbUJBQW1CO01BQ25CLG9CQUFvQixLQUFLLENBQUMsQ0FBQztLQUMvQjtJQUNKO1VBRUMsSUFBSSxNQUFNLEdBQUcsVUFDZCxNQUFNLEdBQUcsU0FBUyxLQUFLO0dBRTNCLE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxZQUFZLFdBQVc7R0FDcEUsTUFBTSxlQUFlLENBQUMsY0FBYyxVQUFVLEtBQUs7R0FDbkQsQ0FBQyxlQUNHLFVBQVUsTUFBTSxLQUFLO0lBQ2pCO0lBQ0EsTUFBTSxNQUFNO0lBQ1osR0FBSSxxQkFBcUIsSUFBSSxJQUN2QixFQUFFLFFBQVEsWUFBWSxXQUFXLEVBQUUsSUFDbkMsQ0FBQztHQUNYLENBQUM7R0FDTCxJQUFJLHNCQUFzQjtJQUN0QixLQUFLLENBQUMseUJBQXlCLENBQUMsV0FBVyxZQUN2QyxXQUFXLFNBQVMsR0FBRztLQUN2QixJQUFJLFNBQVMsU0FBUyxVQUNkO1VBQUEsYUFDQSxVQUFVO0tBQUEsT0FHYixJQUFJLENBQUMsYUFDTixVQUFVO0lBRWxCO0lBQ0EsT0FBUSxnQkFDSixVQUFVLE1BQU0sS0FBSztLQUFFO0tBQU0sR0FBSSxVQUFVLENBQUMsSUFBSTtJQUFZLENBQUM7R0FDckU7R0FDQSxJQUFJLENBQUMsU0FBUyxZQUFZLFNBQVMsVUFDL0IsTUFBTSxhQUFhO0lBQ1Q7SUFDTixXQUFXLE1BQU07R0FDckIsQ0FBQztHQUVMLENBQUMsZUFBZSxXQUFXLFVBQVUsTUFBTSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUM7R0FDakUsSUFBSSxTQUFTLFVBQVU7SUFDbkIsTUFBTSxjQUFjO0lBQ3BCLE1BQU0sRUFBRSxXQUFXLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQztJQUMxQyxJQUFJLGdCQUFnQixjQUNoQjtJQUVKLG9CQUFvQixDQUFDLElBQUksQ0FBQztJQUMxQiwyQkFBMkIsVUFBVTtJQUNyQyxJQUFJLENBQUMscUJBQXFCO0tBQ3RCLENBQUMsY0FBYyxVQUFVLEtBQUssVUFBVSxNQUFNLEtBQUssVUFBVTtLQUM3RDtJQUNKO0lBQ0EsTUFBTSw0QkFBNEIsa0JBQWtCLFdBQVcsUUFBUSxTQUFTLElBQUk7SUFDcEYsTUFBTSxvQkFBb0Isa0JBQWtCLFFBQVEsU0FBUywwQkFBMEIsUUFBUSxJQUFJO0lBQ25HLFFBQVEsa0JBQWtCO0lBQzFCLE9BQU8sa0JBQWtCO0lBQ3pCLFVBQVUsY0FBYyxNQUFNO0dBQ2xDLE9BQ0s7SUFDRCxNQUFNLGNBQWM7SUFDcEIsTUFBTSxpQkFBaUIsRUFBRTtJQUN6QixvQkFBb0IsQ0FBQyxJQUFJLEdBQUcsSUFBSTtJQUNoQyxTQUFTLE1BQU0sY0FBYyxPQUFPLE9BQU8sVUFBVSxhQUFhLGtDQUFrQyxTQUFTLHlCQUF5QixFQUFBLENBQUc7SUFDekksSUFBSSxnQkFBZ0IsY0FDaEI7SUFFSixvQkFBb0IsQ0FBQyxJQUFJLENBQUM7SUFDMUIsMkJBQTJCLFVBQVU7SUFDckMsSUFBSSxxQkFBcUI7S0FDckIsSUFBSSxPQUNBLFVBQVU7VUFFVCxJQUFJLFdBQVcsU0FBUyxHQUFHO01BQzVCLFVBQVUsTUFBTSx5QkFBeUI7T0FDckMsUUFBUTtPQUNSLGdCQUFnQjtPQUNWO09BQ04sV0FBVyxNQUFNO01BQ3JCLENBQUM7TUFDRCxJQUFJLGdCQUFnQixjQUNoQjtNQUVKLDJCQUEyQixVQUFVO01BQ3JDLElBQUksbUJBQW1CLGlCQUNuQixVQUFVLEtBQUE7S0FFbEI7SUFDSjtHQUNKO0dBQ0EsSUFBSSxxQkFBcUI7SUFDckIsTUFBTSxHQUFHLFNBQ0osQ0FBQyxNQUFNLFFBQVEsTUFBTSxHQUFHLElBQUksS0FBSyxNQUFNLEdBQUcsS0FBSyxTQUFTLE1BQ3pELFFBQVEsTUFBTSxHQUFHLElBQUk7SUFDekIsb0JBQW9CLE1BQU0sU0FBUyxPQUFPLFVBQVU7SUFDcEQsb0JBQ0ksT0FBTyxVQUFVLGVBQWUsS0FBSyxxQkFBcUIsSUFBSSxLQUM5RCxvQkFBb0IsS0FBSyxDQUFDLENBQUM7R0FDbkM7RUFDSjtDQUNKO0NBQ0EsTUFBTSxlQUFlLEtBQUssUUFBUTtFQUM5QixJQUFJLElBQUksV0FBVyxRQUFRLEdBQUcsS0FBSyxJQUFJLE9BQU87R0FDMUMsSUFBSSxNQUFNO0dBQ1YsT0FBTztFQUNYO0NBRUo7Q0FDQSxNQUFNLFVBQVUsT0FBTyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQzFDLE9BQU8sY0FBYztFQUNyQixJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sYUFBYSxzQkFBc0IsSUFBSTtFQUM3QyxNQUFNLGNBQWM7RUFDcEIsSUFBSSxTQUFTLFVBQVU7R0FDbkIsTUFBTSxTQUFTLE1BQU0sNEJBQTRCLFlBQVksSUFBSSxJQUFJLE9BQU8sVUFBVTtHQUN0RixVQUFVLGNBQWMsTUFBTTtHQUM5QixtQkFBbUIsT0FDYixDQUFDLFdBQVcsTUFBTSxTQUFTLElBQUksUUFBUSxJQUFJLENBQUMsSUFDNUM7RUFDVixPQUNLLElBQUksTUFBTTtHQUNYLG9CQUFvQixNQUFNLFFBQVEsSUFBSSxXQUFXLElBQUksT0FBTyxjQUFjO0lBQ3RFLE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztJQUNwQyxPQUFPLE1BQU0seUJBQXlCO0tBQ2xDLFFBQVEsU0FBUyxNQUFNLEtBQUssR0FBRyxZQUFZLE1BQU0sSUFBSTtLQUNyRCxXQUFXLE9BQU87SUFDdEIsQ0FBQztHQUNMLENBQUMsQ0FBQyxFQUFBLENBQUcsTUFBTSxPQUFPO0dBQ2xCLENBQUcsb0JBQXFCLFdBQVcsWUFBWSxVQUFVO0VBQzdELE9BRUksbUJBQW1CLFVBQVUsTUFBTSx5QkFBeUI7R0FDeEQsUUFBUTtHQUNSO0dBQ0EsV0FBVyxPQUFPO0VBQ3RCLENBQUM7RUFFTCxJQUFJLGdCQUFnQixjQUNoQixPQUFPO0VBRVgsSUFBSSxRQUFRLGNBQWMsU0FBUyxjQUFjLFNBQVMsSUFBSSxHQUFHO0dBQzdELE1BQU0sUUFBUSxJQUFJLFdBQVcsUUFBUSxJQUFJO0dBQ3pDLElBQUksT0FBTztJQUNQLE1BQU0sV0FBVyxRQUFRLElBQUk7SUFDN0Isb0JBQW9CLFFBQVEsU0FBUyxZQUFZLGFBQWEsTUFBTSxLQUFLLENBQUM7SUFDMUUsb0JBQW9CLEtBQUssQ0FBQyxTQUFTLFVBQVU7R0FDakQsT0FFSSxtQkFBbUIsSUFBSTtFQUUvQjtFQUNBLElBQUksUUFBUSxhQUNSLEtBQUssTUFBTSxhQUFhLE9BQU8sYUFBYSxPQUFPLE9BQy9DLENBQUMsT0FBTyxNQUFNLElBQUksU0FBUyxLQUN2QixJQUFJLFdBQVcsZUFBZSxXQUFXLElBQUk7RUFHekQsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFDM0MsVUFBVSxNQUFNLEtBQUs7R0FDakIsR0FBSSxDQUFDLFNBQVMsSUFBSSxLQUNiLFdBQVcsU0FBUyxLQUFLLFlBQVksV0FBVyxVQUMvQyxDQUFDLElBQ0QsRUFBRSxLQUFLO0dBQ2IsR0FBSSxTQUFTLFlBQVksQ0FBQyxPQUFPLEVBQUUsUUFBUSxJQUFJLENBQUM7R0FDaEQsR0FBSSxRQUFRLGVBQWUsV0FBVyxlQUFlLElBQy9DLEVBQUUsZUFBZSxXQUFXLGNBQWMsSUFDMUMsQ0FBQztHQUNQLFFBQVEsV0FBVztFQUN2QixDQUFDO0VBQ0QsUUFBUSxlQUNKLENBQUMsb0JBQ0Qsc0JBQXNCLFNBQVMsYUFBYSxPQUFPLGFBQWEsT0FBTyxLQUFLO0VBQ2hGLE9BQU87Q0FDWDtDQUNBLE1BQU0sY0FBYyxZQUFZLFdBQVc7RUFDdkMsSUFBSSxTQUFTLFlBQVksVUFBVSxLQUFLLENBQUMsU0FDbkMsRUFBRSxHQUFJLE9BQU8sUUFBUSxjQUFjLGVBQWdCLElBQ25ELE9BQU8sUUFDSCxjQUNBO0VBQ1YsSUFBSSxRQUNBLFNBQVMsa0JBQWtCLE9BQU8sY0FBYyxXQUFXLGNBQWMsV0FBVyxlQUFlLE1BQU07RUFFN0csT0FBTyxZQUFZLFVBQVUsSUFDdkIsU0FDQSxTQUFTLFVBQVUsSUFDZixJQUFJLFFBQVEsVUFBVSxJQUN0QixXQUFXLEtBQUssU0FBUyxJQUFJLFFBQVEsSUFBSSxDQUFDO0NBQ3hEO0NBQ0EsTUFBTSxjQUFjLGVBQWUsWUFBWSxVQUFVLElBQ25ELEVBQUUsR0FBRyxXQUFXLE9BQU8sSUFDdkIsU0FBUyxVQUFVLElBQ2YsSUFBSSxXQUFXLFFBQVEsVUFBVSxJQUNqQyxXQUFXLEtBQUssU0FBUyxJQUFJLFdBQVcsUUFBUSxJQUFJLENBQUM7Q0FDL0QsTUFBTSxpQkFBaUIsTUFBTSxjQUFjO0VBQ3ZDLE1BQU0sa0JBQWtCLGFBQWE7RUFDckMsTUFBTSxRQUFRLElBQUksZ0JBQWdCLFFBQVEsSUFBSTtFQUM5QyxPQUFPO0dBQ0gsU0FBUyxDQUFDLENBQUM7R0FDWCxTQUFTLENBQUMsQ0FBQyxJQUFJLGdCQUFnQixhQUFhLElBQUk7R0FDaEQ7R0FDQSxjQUFjLENBQUMsQ0FBQyxJQUFJLGdCQUFnQixrQkFBa0IsSUFBSTtHQUMxRCxXQUFXLENBQUMsQ0FBQyxJQUFJLGdCQUFnQixlQUFlLElBQUk7RUFDeEQ7Q0FDSjtDQUNBLE1BQU0sZUFBZSxTQUFTO0VBQzFCLE1BQU0sUUFBUSxPQUFPLHNCQUFzQixJQUFJLElBQUksS0FBQTtFQUNuRCxJQUFJLE9BQ0EsTUFBTSxTQUFTLGNBQWM7R0FDekIsdUJBQXVCLFNBQVM7R0FDaEMsTUFBTSxXQUFXLFFBQVEsU0FBUztHQUNsQyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztHQUMzQyxVQUFVLE1BQU0sS0FBSztJQUNqQixNQUFNO0lBQ04sUUFBUSxXQUFXO0dBQ3ZCLENBQUM7RUFDTCxDQUFDO09BRUE7R0FDRCxPQUFPLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxRQUFRLGtCQUFrQjtHQUMzRCxXQUFXLFNBQVMsQ0FBQztHQUNyQixVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLFdBQVcsT0FDdkIsQ0FBQztFQUNMO0NBQ0o7Q0FDQSxNQUFNLFlBQVksTUFBTSxPQUFPLFlBQVk7RUFDdkMsdUJBQXVCLElBQUk7RUFDM0IsTUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQztFQUMzQyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRztFQUVqQyxNQUFNLEVBQUUsS0FBSyxZQUFZLFNBQVMsTUFBTSxPQUFPLEdBQUcsb0JBRDdCLElBQUksV0FBVyxRQUFRLElBQUksS0FBSyxDQUFDO0VBRXRELElBQUksV0FBVyxRQUFRLE1BQU07R0FDekIsR0FBRztHQUNILEdBQUc7R0FDSDtFQUNKLENBQUM7RUFDRCxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMzQyxVQUFVLE1BQU0sS0FBSztHQUNqQjtHQUNBLFFBQVEsV0FBVztHQUNuQixTQUFTO0VBQ2IsQ0FBQztFQUNELFdBQVcsUUFBUSxlQUFlLE9BQU8sSUFBSSxTQUFTLElBQUksTUFBTTtDQUNwRTtDQUNBLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtFQUNsQyxJQUFJLFdBQVcsSUFBSSxHQUFHO0dBQ2xCLE1BQU0sbUJBQW1CLENBQUM7R0FDMUIsbUJBQW1CLElBQUksZ0JBQWdCO0dBQ3ZDLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxZQUFZLFlBQVksV0FDM0IsS0FBSyxRQUFRLFVBQVUsVUFBVSxLQUFBLEdBQVcsWUFBWSxHQUFHLE9BQU8sRUFDMUUsQ0FBQztHQUNELE9BQU8sRUFDSCxtQkFBbUI7SUFDZixtQkFBbUIsT0FBTyxnQkFBZ0I7SUFDMUMsWUFBWTtHQUNoQixFQUNKO0VBQ0o7RUFDQSxPQUFPLFVBQVUsTUFBTSxjQUFjLElBQUk7Q0FDN0M7Q0FDQSxNQUFNLGNBQWMsVUFBVTtFQUMxQixNQUFNLG1CQUFtQjtHQUFFLE1BQU0sTUFBTTtHQUFNLE9BQU8sTUFBTTtFQUFNO0VBQ2hFLE1BQU0sYUFDRixNQUFNLFVBQVUsVUFDaEIsbUJBQW1CLElBQUksZ0JBQWdCO0VBQzNDLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxjQUFjO0dBQ2pCLElBQUksc0JBQXNCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLLEtBQzdELHNCQUFzQixXQUFXLE1BQU0sYUFBYSxpQkFBaUIsTUFBTSxZQUFZLEdBQUc7SUFDMUYsTUFBTSxTQUFTLFVBQVUsVUFBVSxFQUFFLEdBQUcsWUFBWTtJQUNwRCxNQUFNLFNBQVM7S0FDWCxHQUFHO0tBQ0gsR0FBRztLQUNILGtCQUFrQixXQUFXO0tBQzdCLGNBQWMsV0FBVztLQUN6QjtLQUNBLGVBQWU7SUFDbkIsQ0FBQztHQUNMO0VBQ0osRUFDSixDQUFDO0VBQ0QsYUFBYTtHQUNULG1CQUFtQixPQUFPLGdCQUFnQjtHQUMxQyxZQUFZO0VBQ2hCO0NBQ0o7Q0FDQSxNQUFNLGFBQWEsVUFBVTtFQUN6QixPQUFPLFFBQVE7RUFDZixNQUFNLGNBQWMsT0FBTyxLQUFLLE1BQU0sYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsUUFBUSxNQUFNLGFBQWEsTUFBTSxVQUFVLElBQUk7RUFDOUcsS0FBSyxNQUFNLE9BQU8sYUFDZCx5QkFBeUIsUUFBUSx5QkFBeUIsUUFBUSxLQUFLO0VBRTNFLE1BQU0sY0FBYyxXQUFXO0dBQzNCLEdBQUc7R0FDSCxXQUFXO0lBQ1AsR0FBRztJQUNILEdBQUcsTUFBTTtHQUNiO0VBQ0osQ0FBQztFQUNELGFBQWE7R0FFVCxLQUFLLE1BQU0sT0FBTyxZQUFZLE9BQU8sQ0FBQyxHQUNsQyx5QkFBeUIsSUFBSTtHQUVqQyxZQUFZO0VBQ2hCO0NBQ0o7Q0FDQSxNQUFNLGNBQWMsTUFBTSxVQUFVLENBQUMsTUFBTTtFQUN2QyxNQUFNLGFBQWEsT0FDYixzQkFBc0IsSUFBSSxJQUMxQixPQUFPO0VBQ2IsSUFBSSxDQUFDLFFBQVEsa0JBQ1Qsd0JBQXdCLFVBQVU7RUFFdEMsS0FBSyxNQUFNLGFBQWEsWUFBWTtHQUNoQyxPQUFPLE1BQU0sT0FBTyxTQUFTO0dBQzdCLE9BQU8sTUFBTSxPQUFPLFNBQVM7R0FDN0IsT0FBTyxTQUFTLE9BQU8sU0FBUztHQUNoQyxNQUFNLFNBQVMsU0FBUztHQUN4QixDQUFDLFFBQVEsYUFBYSxNQUFNLGFBQWEsU0FBUztHQUNsRCxJQUFJLENBQUMsUUFBUSxXQUFXO0lBQ3BCLHVCQUF1QixTQUFTO0lBQ2hDLE1BQU0sV0FBVyxRQUFRLFNBQVM7R0FDdEM7R0FDQSxDQUFDLFFBQVEsYUFBYSxNQUFNLFdBQVcsYUFBYSxTQUFTO0dBQzdELENBQUMsUUFBUSxlQUFlLE1BQU0sV0FBVyxlQUFlLFNBQVM7R0FDakUsQ0FBQyxTQUFTLG9CQUNOLENBQUMsUUFBUSxvQkFDVCxNQUFNLGdCQUFnQixTQUFTO0VBQ3ZDO0VBQ0EsSUFBSSxDQUFDLFFBQVEsV0FDVCxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUUvQyxtQkFBbUIsUUFDZixVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLFlBQVksV0FBVyxFQUNuQyxDQUFDO0VBQ0wsVUFBVSxNQUFNLEtBQUs7R0FDakIsR0FBRztHQUNILEdBQUksUUFBUSxZQUFZLENBQUMsSUFBSSxFQUFFLFNBQVMsVUFBVSxFQUFFO0dBQ3BELEdBQUksUUFBUSxtQkFDTixDQUFDLElBQ0QsRUFBRSxjQUFjLENBQUMsY0FBYyxXQUFXLGdCQUFnQixFQUFFO0VBQ3RFLENBQUM7RUFDRCxDQUFDLFFBQVEsZUFBZSxVQUFVO0NBQ3RDO0NBQ0EsTUFBTSxxQkFBcUIsRUFBRSxVQUFVLFdBQVk7RUFDL0MsSUFBSyxVQUFVLFFBQVEsS0FBSyxPQUFPLFNBQy9CLENBQUMsQ0FBQyxZQUNGLE9BQU8sU0FBUyxJQUFJLElBQUksR0FBRztHQUczQixNQUFNLHVCQUZjLE9BQU8sU0FBUyxJQUFJLElBRUQsTUFBTSxDQUR6QixDQUFDO0dBRXJCLFdBQVcsT0FBTyxTQUFTLElBQUksSUFBSSxJQUFJLE9BQU8sU0FBUyxPQUFPLElBQUk7R0FDbEUsd0JBQXdCLE9BQU8sU0FBUyxDQUFDLE9BQU8sVUFBVSxVQUFVO0VBQ3hFO0NBQ0o7Q0FDQSxNQUFNLFlBQVksTUFBTSxVQUFVLENBQUMsTUFBTTtFQUNyQyxJQUFJLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDN0IsTUFBTSxvQkFBb0IsVUFBVSxRQUFRLFFBQVEsS0FBSyxVQUFVLFNBQVMsUUFBUTtFQUNwRixNQUFNLDBCQUEwQixDQUFDLE9BQU8sYUFBYSxJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sTUFBTSxDQUFDLE1BQU0sR0FBRztFQUNqRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sSUFDakIsaUJBQWlCLFFBQVEsRUFBRTtFQUUvQixJQUFJLFNBQVMsTUFBTTtHQUNmLEdBQUksU0FBUyxDQUFDO0dBQ2QsSUFBSTtJQUNBLEdBQUksU0FBUyxNQUFNLEtBQUssTUFBTSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRTtJQUNuRDtJQUNBLE9BQU87SUFDUCxHQUFHO0dBQ1A7RUFDSixDQUFDO0VBQ0QsT0FBTyxNQUFNLElBQUksSUFBSTtFQUNyQixJQUFJLFNBQVMsTUFBTSxJQUFJO0dBQ25CLE1BQU0sWUFBWSxJQUFJLFNBQVMsSUFBSTtHQUNuQyxLQUFLLE1BQU0sUUFBUSwyQkFDZixJQUFJLEVBQUUsUUFBUSxVQUNWLE9BQU8sVUFBVSxHQUFHO0VBR2hDO0VBQ0EsSUFBSSxTQUFTLENBQUMseUJBQ1Ysa0JBQWtCO0dBQ2QsVUFBVSxVQUFVLFFBQVEsUUFBUSxJQUM5QixRQUFRLFdBQ1IsU0FBUztHQUNmO0VBQ0osQ0FBQztPQUdELG9CQUFvQixNQUFNLE1BQU0sUUFBUSxLQUFLO0VBRWpELE9BQU87R0FDSCxHQUFJLG9CQUNFLEVBQUUsVUFBVSxRQUFRLFlBQVksU0FBUyxTQUFTLElBQ2xELENBQUM7R0FDUCxHQUFJLFNBQVMsY0FDUDtJQUNFLFVBQVUsQ0FBQyxDQUFDLGFBQWEsUUFBUSxRQUFRO0lBQ3pDLEtBQUssYUFBYSxRQUFRLEdBQUc7SUFDN0IsS0FBSyxhQUFhLFFBQVEsR0FBRztJQUM3QixXQUFXLGFBQWEsUUFBUSxTQUFTO0lBQ3pDLFdBQVcsYUFBYSxRQUFRLFNBQVM7SUFDekMsU0FBUyxhQUFhLFFBQVEsT0FBTztHQUN6QyxJQUNFLENBQUM7R0FDUDtHQUNBO0dBQ0EsUUFBUTtHQUNSLE1BQU0sUUFBUTtJQUNWLElBQUksS0FBSztLQUNMLE9BQU8sYUFBYSxJQUFJLElBQUk7S0FDNUIsU0FBUyxNQUFNLE9BQU87S0FDdEIsT0FBTyxhQUFhLE9BQU8sSUFBSTtLQUMvQixRQUFRLElBQUksU0FBUyxJQUFJO0tBQ3pCLE1BQU0sV0FBVyxZQUFZLElBQUksS0FBSyxJQUNoQyxJQUFJLG1CQUNBLElBQUksaUJBQWlCLHVCQUF1QixDQUFDLENBQUMsTUFBTSxNQUNwRCxNQUNKO0tBQ04sTUFBTSxrQkFBa0Isa0JBQWtCLFFBQVE7S0FDbEQsTUFBTSxPQUFPLE1BQU0sR0FBRyxRQUFRLENBQUM7S0FDL0IsSUFBSSxrQkFDRSxLQUFLLE1BQU0sV0FBVyxXQUFXLFFBQVEsSUFDekMsYUFBYSxNQUFNLEdBQUcsS0FDeEI7S0FFSixNQUFNLFdBQVcsRUFDYixHQUFHLE1BQU0sR0FDYjtLQUNBLElBQUksaUJBQWlCO01BQ2pCLFNBQVMsT0FBTztPQUNaLEdBQUcsS0FBSyxPQUFPLElBQUk7T0FDbkI7T0FDQSxHQUFJLE1BQU0sUUFBUSxJQUFJLGdCQUFnQixJQUFJLENBQUMsSUFDckMsQ0FBQyxDQUFDLENBQUMsSUFDSCxDQUFDO01BQ1g7TUFDQSxTQUFTLE1BQU07T0FBRSxNQUFNLFNBQVM7T0FBTTtNQUFLO0tBQy9DLE9BQ0s7TUFDRCxTQUFTLE1BQU07TUFDZixPQUFPLFNBQVM7S0FDcEI7S0FDQSxJQUFJLFNBQVMsTUFBTSxFQUNmLElBQUksU0FDUixDQUFDO0tBQ0Qsb0JBQW9CLE1BQU0sT0FBTyxLQUFBLEdBQVcsUUFBUTtJQUN4RCxPQUNLO0tBQ0QsUUFBUSxJQUFJLFNBQVMsTUFBTSxDQUFDLENBQUM7S0FDN0IsSUFBSSxNQUFNLElBQ04sTUFBTSxHQUFHLFFBQVE7S0FFckIsQ0FBQyxTQUFTLG9CQUFvQixRQUFRLHFCQUNsQyxFQUFFLG1CQUFtQixPQUFPLE9BQU8sSUFBSSxLQUFLLE9BQU8sV0FDbkQsT0FBTyxRQUFRLElBQUksSUFBSTtJQUMvQjtHQUNKO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sb0JBQW9CLFNBQVMsb0JBQy9CLENBQUMsU0FBUyw2QkFDVixzQkFBc0IsU0FBUyxhQUFhLE9BQU8sS0FBSztDQUM1RCxNQUFNLGdCQUFnQixhQUFhO0VBQy9CLElBQUksVUFBVSxRQUFRLEdBQUc7R0FDckIsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTLENBQUM7R0FDakMsc0JBQXNCLFVBQVUsS0FBSyxTQUFTO0lBQzFDLE1BQU0sZUFBZSxJQUFJLFNBQVMsSUFBSTtJQUN0QyxJQUFJLGNBQWM7S0FDZCxJQUFJLFdBQVcsYUFBYSxHQUFHLFlBQVk7S0FDM0MsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUFHLElBQUksR0FDbEMsYUFBYSxHQUFHLEtBQUssU0FBUyxhQUFhO01BQ3ZDLFNBQVMsV0FBVyxhQUFhLEdBQUcsWUFBWTtLQUNwRCxDQUFDO0lBRVQ7R0FDSixHQUFHLENBQUM7RUFDUjtDQUNKO0NBQ0EsTUFBTSxnQkFBZ0IsU0FBUyxjQUFjLE9BQU8sTUFBTTtFQUN0RCxJQUFJLFNBQVMsS0FBQTtFQUNiLElBQUksZUFBZSxLQUFBO0VBQ25CLElBQUksR0FBRztHQUNILEVBQUUsa0JBQWtCLEVBQUUsZUFBZTtHQUNyQyxFQUFFLFdBQVcsRUFBRSxRQUFRO0VBQzNCO0VBQ0EsSUFBSSxjQUFjLFlBQVksV0FBVztFQUN6QyxVQUFVLE1BQU0sS0FBSyxFQUNqQixjQUFjLEtBQ2xCLENBQUM7RUFDRCxNQUFNLGNBQWM7RUFDcEIsTUFBTSxpQkFBaUIsVUFBVTtHQUM3QixJQUFJLGdCQUFnQixjQUNoQixVQUFVLE1BQU0sS0FBSyxFQUFFLGNBQWMsTUFBTSxDQUFDO0dBRWhELE1BQU07RUFDVjtFQUNBLElBQUksU0FBUyxVQUFVO0dBQ25CLElBQUk7R0FDSixJQUFJO0lBQ0EsbUJBQW1CLE1BQU0sV0FBVztHQUN4QyxTQUNPLE9BQU87SUFDVixjQUFjLEtBQUs7R0FDdkI7R0FDQSxNQUFNLEVBQUUsUUFBUSxXQUFXO0dBQzNCLElBQUksZ0JBQWdCLGNBQ2hCO0dBRUosb0JBQW9CO0dBQ3BCLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsa0JBQWtCO0dBQzNELFdBQVcsU0FBUztHQUNwQixjQUFjLFlBQVksTUFBTTtFQUNwQyxPQUNLO0dBQ0QsSUFBSTtJQUNBLE1BQU0seUJBQXlCO0tBQzNCLFFBQVE7S0FDUixXQUFXLE9BQU87SUFDdEIsQ0FBQztHQUNMLFNBQ08sT0FBTztJQUNWLGNBQWMsS0FBSztHQUN2QjtHQUNBLElBQUksZ0JBQWdCLGNBQ2hCO0dBRUosTUFBTSxXQUFXLFFBQVEsZUFBZTtHQUN4QyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMvQztFQUNBLElBQUksT0FBTyxTQUFTLE1BQ2hCLEtBQUssTUFBTSxRQUFRLE9BQU8sVUFDdEIsTUFBTSxhQUFhLElBQUk7RUFHL0IsSUFBSSxjQUFjLFdBQVcsTUFBTSxHQUFHO0dBQ2xDLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFFBQVEsQ0FBQyxFQUNiLENBQUM7R0FDRCxJQUFJO0lBQ0EsU0FBUyxNQUFNLFFBQVEsYUFBYSxDQUFDO0dBQ3pDLFNBQ08sT0FBTztJQUNWLGVBQWU7R0FDbkI7RUFDSixPQUNLO0dBQ0QsSUFBSSxXQUNBLElBQUk7SUFDQSxNQUFNLFVBQVUsRUFBRSxHQUFHLFdBQVcsT0FBTyxHQUFHLENBQUM7R0FDL0MsU0FDTyxPQUFPO0lBQ1YsY0FBYyxLQUFLO0dBQ3ZCO0dBRUosWUFBWTtHQUNaLFdBQVcsV0FBVztFQUMxQjtFQUNBLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLGFBQWE7R0FDYixjQUFjO0dBQ2Qsb0JBQW9CLGNBQWMsV0FBVyxNQUFNLEtBQUssQ0FBQztHQUN6RCxhQUFhLFdBQVcsY0FBYztHQUN0QyxRQUFRLFdBQVc7RUFDdkIsQ0FBQztFQUNELElBQUksY0FDQSxNQUFNO0VBRVYsT0FBTztDQUNYO0NBQ0EsTUFBTSxjQUFjLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDdkMsSUFBSSxJQUFJLFNBQVMsSUFBSSxHQUFHO0dBQ3BCLHdCQUF3QixDQUFDLElBQUksQ0FBQztHQUM5QixJQUFJLFlBQVksUUFBUSxZQUFZLEdBQ2hDLFNBQVMsTUFBTSxZQUFZLElBQUksZ0JBQWdCLElBQUksQ0FBQyxDQUFDO1FBRXBEO0lBQ0QsU0FBUyxNQUFNLFFBQVEsWUFBWTtJQUNuQyxJQUFJLGdCQUFnQixNQUFNLFlBQVksUUFBUSxZQUFZLENBQUM7R0FDL0Q7R0FDQSxJQUFJLENBQUMsUUFBUSxhQUNULE1BQU0sV0FBVyxlQUFlLElBQUk7R0FFeEMsSUFBSSxDQUFDLFFBQVEsV0FBVztJQUNwQixNQUFNLFdBQVcsYUFBYSxJQUFJO0lBQ2xDLFdBQVcsVUFBVSxDQUFDLFlBQVksUUFBUSxZQUFZLElBQ2hELFVBQVUsTUFBTSxZQUFZLElBQUksZ0JBQWdCLElBQUksQ0FBQyxDQUFDLElBQ3RELFVBQVU7R0FDcEI7R0FDQSxJQUFJLENBQUMsUUFBUSxXQUFXO0lBQ3BCLHVCQUF1QixJQUFJO0lBQzNCLE1BQU0sV0FBVyxRQUFRLElBQUk7SUFDN0IsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87SUFDM0MsVUFBVTtHQUNkO0dBQ0EsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBRztJQUNILGNBQWMsQ0FBQyxjQUFjLFdBQVcsZ0JBQWdCO0dBQzVELENBQUM7RUFDTDtDQUNKO0NBQ0EsTUFBTSxVQUFVLFlBQVksbUJBQW1CLENBQUMsTUFBTTtFQUNsRDtFQUNBO0VBQ0EsTUFBTSxnQkFBZ0IsYUFBYSxZQUFZLFVBQVUsSUFBSTtFQUM3RCxNQUFNLHFCQUFxQixZQUFZLGFBQWE7RUFDcEQsTUFBTSxxQkFBcUIsY0FBYyxVQUFVO0VBQ25ELE1BQU0sU0FBUztFQUNmLE1BQU0sWUFBWTtFQUNsQixPQUFPLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxRQUFRLGtCQUFrQjtFQUMzRCxJQUFJLENBQUMsaUJBQWlCLG1CQUNsQixpQkFBaUI7RUFFckIsSUFBSSxDQUFDLGlCQUFpQixZQUFZO0dBQzlCLElBQUksaUJBQWlCLGlCQUFpQjtJQUNsQyxNQUFNLGdDQUFnQixJQUFJLElBQUksQ0FDMUIsR0FBRyxPQUFPLE9BQ1YsR0FBRyx1QkFBdUIsZUFBZSxnQkFBZ0IsYUFBYSxLQUFBLEdBQVcsU0FBUyxHQUFHLFdBQVcsV0FBVyxDQUN2SCxDQUFDO0lBQ0QsS0FBSyxNQUFNLGFBQWEsZUFBZTtLQUNuQyxNQUFNLFVBQVUsSUFBSSxXQUFXLGFBQWEsU0FBUztLQUNyRCxNQUFNLGdCQUFnQixJQUFJLGFBQWEsU0FBUztLQUNoRCxNQUFNLFdBQVcsSUFBSSxRQUFRLFNBQVM7S0FDdEMsSUFBSSxXQUFXLENBQUMsWUFBWSxhQUFhLEdBQ3JDLElBQUksUUFBUSxXQUFXLGFBQWE7VUFFbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLFFBQVEsR0FDdEMsU0FBUyxXQUFXLFFBQVE7SUFFcEM7R0FDSixPQUNLO0lBQ0QsSUFBSSxTQUFTLFlBQVksVUFBVSxHQUMvQixLQUFLLE1BQU0sUUFBUSxPQUFPLE9BQU87S0FDN0IsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0tBQy9CLElBQUksU0FBUyxNQUFNLElBQUk7TUFDbkIsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLElBQzVDLE1BQU0sR0FBRyxLQUFLLEtBQ2QsTUFBTSxHQUFHO01BQ2YsSUFBSSxjQUFjLGNBQWMsR0FBRztPQUMvQixNQUFNLE9BQU8sZUFBZSxRQUFRLE1BQU07T0FDMUMsSUFBSSxNQUFNO1FBQ04sS0FBSyxNQUFNO1FBQ1g7T0FDSjtNQUNKO0tBQ0o7SUFDSjtJQUVKLElBQUksaUJBQWlCLGVBQ2pCLEtBQUssTUFBTSxhQUFhLE9BQU8sT0FDM0IsU0FBUyxXQUFXLElBQUksUUFBUSxTQUFTLENBQUM7U0FJOUMsVUFBVSxDQUFDO0dBRW5CO0dBQ0EsSUFBSSxTQUFTLGtCQUFrQjtJQUMzQixjQUFjLGlCQUFpQixvQkFDekIsWUFBWSxjQUFjLElBQzFCLENBQUM7SUFDUCxJQUFJLGlCQUFpQixlQUNqQixLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLElBQUksYUFBYSxXQUFXLElBQUksUUFBUSxTQUFTLENBQUM7R0FHOUQsT0FFSSxjQUFjLFlBQVksTUFBTTtHQUVwQyxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLEVBQUUsR0FBRyxPQUFPLEVBQ3hCLENBQUM7R0FDRCxVQUFVLE1BQU0sS0FBSztJQUNqQixNQUFNLEtBQUE7SUFDTixNQUFNLEtBQUE7SUFDTixRQUFRLEVBQUUsR0FBRyxPQUFPO0dBQ3hCLENBQUM7RUFDTDtFQUNBLFNBQVM7R0FDTCxPQUFPLGlCQUFpQixrQkFBa0IsT0FBTyx3QkFBUSxJQUFJLElBQUk7R0FDakUseUJBQVMsSUFBSSxJQUFJO0dBQ2pCLHVCQUFPLElBQUksSUFBSTtHQUNmLDhCQUFjLElBQUksSUFBSTtHQUN0QixVQUFVLGlCQUFpQixjQUN2QixpQkFBaUIsbUJBQ2pCLGlCQUFpQixnQkFDZixJQUFJLElBQUksQ0FBQyxHQUFHLE9BQU8sUUFBUSxDQUFDLENBQUMsUUFBUSxTQUFTLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQyxvQkFDakUsSUFBSSxJQUFJO0dBQ2QsdUJBQU8sSUFBSSxJQUFJO0dBQ2YsVUFBVTtHQUNWLE9BQU87RUFDWDtFQUNBLE9BQU8sUUFDSCxDQUFDLGdCQUFnQixXQUNiLENBQUMsQ0FBQyxpQkFBaUIsZUFDbkIsQ0FBQyxDQUFDLGlCQUFpQixtQkFDbEIsQ0FBQyxTQUFTLG9CQUFvQixDQUFDLGNBQWMsTUFBTTtFQUM1RCxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVM7RUFDMUIsT0FBTyxjQUFjLENBQUMsQ0FBQyxpQkFBaUI7RUFDeEMsT0FBTyxTQUFTO0VBQ2hCLE9BQU8sbUJBQW1CLE1BQU07RUFDaEMsb0JBQW9CO0VBQ3BCLElBQUksQ0FBQyxpQkFBaUIsWUFDbEIsV0FBVyxTQUFTLENBQUM7RUFFekIsVUFBVSxNQUFNLEtBQUs7R0FDakIsYUFBYSxpQkFBaUIsa0JBQ3hCLFdBQVcsY0FDWDtHQUNOLFNBQVMscUJBQ0gsUUFDQSxpQkFBaUIsWUFDYixXQUFXLFVBQ1gsaUJBQWlCLGFBQ2IsVUFBVSxJQUNWLENBQUMsRUFBRSxpQkFBaUIscUJBQ2xCLGNBQ0EsQ0FBQyxVQUFVLFlBQVksY0FBYztHQUNyRCxhQUFhLGlCQUFpQixrQkFDeEIsV0FBVyxjQUNYO0dBQ04sYUFBYyxxQkFDUixDQUFDLElBQ0QsaUJBQWlCLGtCQUNiLGlCQUFpQixxQkFBcUIsY0FDbEMsZUFBZSxnQkFBZ0IsYUFBYSxLQUFBLEdBQVcsU0FBUyxJQUNoRSxXQUFXLGNBQ2YsaUJBQWlCLHFCQUFxQixhQUNsQyxlQUFlLGdCQUFnQixZQUFZLEtBQUEsR0FBVyxTQUFTLElBQy9ELGlCQUFpQixZQUNiLFdBQVcsY0FDWCxpQkFBaUIsYUFDYixlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxTQUFTLElBQ2hFLENBQUM7R0FDdkIsZUFBZSxpQkFBaUIsY0FDMUIsV0FBVyxnQkFDWCxDQUFDO0dBQ1AsR0FBSSxDQUFDLGlCQUFpQixxQkFDakIsV0FBVyxnQkFBZ0IsQ0FBQyxjQUFjLFdBQVcsZ0JBQWdCLEtBQ3BFO0lBQUUsa0JBQWtCLENBQUM7SUFBRyxjQUFjO0dBQU0sSUFDNUM7R0FDTixRQUFRLGlCQUFpQixhQUFhLFdBQVcsU0FBUyxDQUFDO0dBQzNELG9CQUFvQixpQkFBaUIseUJBQy9CLFdBQVcscUJBQ1g7R0FDTixjQUFjO0dBQ2QsZUFBZTtFQUNuQixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFNBQVMsWUFBWSxxQkFBcUIsT0FBTyxXQUFXLFVBQVUsSUFBSSxXQUFXLFdBQVcsSUFBSSxZQUFZO0VBQ2xILEdBQUcsU0FBUztFQUNaLEdBQUc7Q0FDUCxDQUFDO0NBQ0QsTUFBTSxZQUFZLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDckMsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLE1BQU0saUJBQWlCLFNBQVMsTUFBTTtFQUN0QyxJQUFJLGdCQUFnQjtHQUNoQixNQUFNLFdBQVksZUFBZSxPQUFPLGVBQWUsS0FBSyxLQUFLLGVBQWU7R0FDaEYsSUFBSSxTQUFTLE9BQ1QsaUJBQWlCO0lBQ2IsU0FBUyxNQUFNO0lBQ2YsUUFBUSxnQkFDSixXQUFXLFNBQVMsTUFBTSxLQUMxQixTQUFTLE9BQU87R0FDeEIsQ0FBQztFQUVUO0NBQ0o7Q0FDQSxNQUFNLGlCQUFpQixxQkFBcUI7RUFNeEMsTUFBTSxFQUFFLE1BQU0sTUFBTSxRQUFRLEdBQUcsY0FBYztFQUM3QyxJQUFJLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQyxRQUN2QixhQUFhO0dBQ1QsR0FBRztHQUNILEdBQUc7RUFDUDtDQUVSO0NBQ0EsVUFBVSxNQUFNLFVBQVUsRUFBRSxNQUFNLGNBQWMsQ0FBQztDQUNqRCxNQUFNLDRCQUE0QixXQUFXLFNBQVMsYUFBYSxLQUMvRCxTQUFTLGNBQWMsQ0FBQyxDQUFDLE1BQU0sV0FBVztFQUN0QyxNQUFNLFFBQVEsU0FBUyxZQUFZO0VBQ25DLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFdBQVcsTUFDZixDQUFDO0NBQ0wsQ0FBQztDQUNMLE1BQU0sc0JBQXNCLFFBQVEsVUFBVSxDQUFDLE1BQU07RUFDakQsaUJBQWlCLFlBQVksTUFBTTtFQUNuQyxJQUFJLENBQUMsUUFBUSxXQUFXO0dBQ3BCLE1BQU0saUJBQWlCLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLE9BQU87R0FDckYsV0FBVyxjQUFjO0dBQ3pCLFdBQVcsVUFBVSxDQUFDLGNBQWMsY0FBYztFQUN0RDtFQUNBLElBQUksQ0FBQyxRQUFRLGFBQ1QsVUFBVTtFQUVkLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLEdBQUc7R0FDSCxlQUFlO0VBQ25CLENBQUM7Q0FDTDtDQUNBLE1BQU0sVUFBVTtFQUNaLFNBQVM7R0FDTDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBLElBQUksVUFBVTtJQUNWLE9BQU87R0FDWDtHQUNBLElBQUksY0FBYztJQUNkLE9BQU87R0FDWDtHQUNBLElBQUksU0FBUztJQUNULE9BQU87R0FDWDtHQUNBLElBQUksT0FBTyxPQUFPO0lBQ2QsU0FBUztHQUNiO0dBQ0EsSUFBSSxpQkFBaUI7SUFDakIsT0FBTztHQUNYO0dBQ0EsSUFBSSxTQUFTO0lBQ1QsT0FBTztHQUNYO0dBQ0EsSUFBSSxPQUFPLE9BQU87SUFDZCxTQUFTO0dBQ2I7R0FDQSxJQUFJLGFBQWE7SUFDYixPQUFPO0dBQ1g7R0FDQSxJQUFJLFdBQVc7SUFDWCxPQUFPO0dBQ1g7R0FDQSxJQUFJLFNBQVMsT0FBTztJQUNoQixXQUFXO0tBQ1AsR0FBRztLQUNILEdBQUc7SUFDUDtJQUNBLDhCQUE4QixtQkFBbUIsU0FBUyxJQUFJO0lBQzlELDZCQUE2QixtQkFBbUIsU0FBUyxjQUFjO0lBQ3ZFLG1DQUNJLFNBQVMsaUJBQWlCLGdCQUFnQjtHQUNsRDtFQUNKO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKO0NBQ0EsT0FBTztFQUNILEdBQUc7RUFDSCxhQUFhO0NBQ2pCO0FBQ0o7QUFFQSxJQUFNLGdCQUFnQjtDQUNsQixNQUFNLGVBQWU7Q0FDckIsZ0JBQWdCLGVBQWU7Q0FDL0Isa0JBQWtCLGVBQWU7Q0FDakMsVUFBVSxLQUFBO0NBQ1YsY0FBYyxLQUFBO0NBQ2QsWUFBWSxLQUFBO0NBQ1osa0JBQWtCLEtBQUE7Q0FDbEIsMkJBQTJCLEtBQUE7Q0FDM0IsU0FBUyxLQUFBO0NBQ1QsYUFBYSxLQUFBO0NBQ2IsY0FBYyxLQUFBO0FBQ2xCOzs7Ozs7Ozs7Ozs7Ozs7QUFlQSxTQUFTLFFBQVEsUUFBUSxDQUFDLEdBQUc7Q0FDekIsTUFBTSxlQUFBLGFBQXFCLE9BQU8sS0FBQSxDQUFTO0NBQzNDLE1BQU0sVUFBQSxhQUFnQixPQUFPLEtBQUEsQ0FBUztDQUN0QyxNQUFNLG1CQUFBLGFBQXlCLE9BQU8sTUFBTSxXQUFXO0NBQ3ZELE1BQU0sZUFBQSxhQUFxQixPQUFPLEtBQUs7Q0FDdkMsTUFBTSxlQUFBLGFBQXFCLE9BQU8sQ0FBQyxDQUFDLE1BQU0sUUFBUTtDQUNsRCxNQUFNLGFBQUEsYUFBbUIsT0FBTyxDQUFDLENBQUMsTUFBTSxNQUFNO0NBQzlDLE1BQU0sYUFBQSxhQUFtQixPQUFPLEtBQUs7Q0FDckMsTUFBTSxDQUFDLFdBQVcsbUJBQUEsYUFBeUIsZ0JBQWdCO0VBQ3ZELEdBQUcsWUFBWSxrQkFBa0I7RUFDakMsV0FBVyxXQUFXLE1BQU0sYUFBYTtFQUN6QyxRQUFRLE1BQU0sVUFBVSxDQUFDO0VBQ3pCLFVBQVUsTUFBTSxZQUFZO0VBQzVCLGVBQWUsV0FBVyxNQUFNLGFBQWEsSUFDdkMsS0FBQSxJQUNBLE1BQU07Q0FDaEIsRUFBRTtDQUNGLElBQUksQ0FBQyxhQUFhLFdBQ2IsTUFBTSxlQUFlLGlCQUFpQixZQUFZLE1BQU0sYUFBYztFQUN2RSxpQkFBaUIsVUFBVSxNQUFNO0VBQ2pDLGFBQWEsVUFBVTtFQUN2QixJQUFJLE1BQU0sYUFBYTtHQUNuQixhQUFhLFVBQVU7SUFDbkIsR0FBRyxNQUFNO0lBQ1Q7R0FDSjtHQUNBLElBQUksTUFBTSxpQkFBaUIsQ0FBQyxXQUFXLE1BQU0sYUFBYSxHQUN0RCxNQUFNLFlBQVksTUFBTSxNQUFNLGVBQWUsTUFBTSxZQUFZO0VBRXZFLE9BQ0s7R0FDRCxNQUFNLEVBQUUsYUFBYSxHQUFHLFNBQVMsa0JBQWtCLEtBQUs7R0FDeEQsYUFBYSxVQUFVO0lBQ25CLEdBQUc7SUFDSDtHQUNKO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sVUFBVSxhQUFhLFFBQVE7Q0FDckMsTUFBTSxrQkFBa0IsUUFBUTtDQUNoQyxNQUFNLGlCQUFpQixDQUFDO0NBQ3hCLEtBQUssTUFBTSxPQUFPLGVBQ2QsSUFBSSxPQUFPLG1CQUFtQixFQUFFLE9BQU8sUUFDbkMsZUFBZSxPQUFPLGNBQWM7Q0FHNUMsSUFBSSxhQUFhLFdBQVcsQ0FBQyxNQUFNLFVBQy9CLGVBQWUsV0FBVztDQUU5QixRQUFRLFdBQVc7RUFDZixHQUFHO0VBQ0gsR0FBRztFQUNILFVBQVUsTUFBTTtDQUNwQjtDQUNBLE1BQU0sNkJBQTZCO0VBQy9CLEdBQUcsUUFBUTtFQUNYLGVBQWUsUUFBUTtDQUMzQjtDQUNBLE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxxQkFBcUIsbUJBQW1CO0NBQzdFLGdDQUFnQztFQUM1QixlQUFlLE1BQU0scUJBQXFCLGVBQWU7RUFDekQsTUFBTSxjQUFjLFFBQVEsV0FBVztHQUNuQyxXQUFXLFFBQVE7R0FDbkIsZ0JBQWdCLGdCQUFnQjtJQUM1QixHQUFHLFFBQVE7SUFDWCxlQUFlLFFBQVE7R0FDM0IsQ0FBQztHQUNELGNBQWM7RUFDbEIsQ0FBQztFQUNELGlCQUFpQixVQUFVO0dBQ3ZCLEdBQUc7R0FDSCxTQUFTO0VBQ2IsRUFBRTtFQUNGLFFBQVEsV0FBVyxVQUFVO0VBQzdCLFFBQVEsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTLEtBQUssQ0FBQztFQUM5QyxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsTUFBTSxtQkFBbUI7RUFDdEM7Q0FDSixHQUFHO0VBQUM7RUFBUztFQUFnQjtDQUFRLENBQUM7Q0FDdEMsYUFBTSxnQkFBZ0I7RUFDbEIsUUFBUSxhQUFhLGFBQWEsV0FBVyxDQUFDLE1BQU0sV0FBVyxRQUFRLE1BQU0sUUFBUTtFQUNyRixhQUFhLFVBQVUsQ0FBQyxDQUFDLE1BQU07Q0FDbkMsR0FBRyxDQUFDLFNBQVMsTUFBTSxRQUFRLENBQUM7Q0FDNUIsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxNQUFNLE1BQ04sUUFBUSxTQUFTLE9BQU8sTUFBTTtFQUVsQyxJQUFJLE1BQU0sZ0JBQ04sUUFBUSxTQUFTLGlCQUFpQixNQUFNO0NBRWhELEdBQUc7RUFBQztFQUFTLE1BQU07RUFBTSxNQUFNO0NBQWMsQ0FBQztDQUM5QyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLE1BQU0sUUFBUTtHQUNkLFFBQVEsV0FBVyxNQUFNLE1BQU07R0FDL0IsUUFBUSxZQUFZO0VBQ3hCLE9BQ0ssSUFBSSxXQUFXLFNBQ2hCLFFBQVEsV0FBVyxDQUFDLENBQUM7RUFFekIsV0FBVyxVQUFVLENBQUMsQ0FBQyxNQUFNO0NBQ2pDLEdBQUcsQ0FBQyxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksYUFBYSxXQUFXLENBQUMsTUFBTSxVQUMvQixhQUFhLFdBQVcsYUFBYSxRQUFRLFlBQVksZUFBZTtFQUU1RSxhQUFhLFVBQVUsQ0FBQyxDQUFDLE1BQU07Q0FDbkMsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDO0NBQ25CLGFBQU0sZ0JBQWdCO0VBQ2xCLE1BQU0sb0JBQ0YsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsVUFBVSxFQUM5QixDQUFDO0NBQ1QsR0FBRyxDQUFDLFNBQVMsTUFBTSxnQkFBZ0IsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLFFBQVEsZ0JBQWdCLFNBQVM7R0FDakMsTUFBTSxVQUFVLFFBQVEsVUFBVTtHQUNsQyxJQUFJLFlBQVksVUFBVSxTQUN0QixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQ0osQ0FBQztFQUVUO0NBQ0osR0FBRyxDQUFDLFNBQVMsVUFBVSxPQUFPLENBQUM7Q0FDL0IsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxNQUFNLFVBQVUsQ0FBQyxVQUFVLE1BQU0sUUFBUSxRQUFRLE9BQU8sR0FBRztHQUMzRCxRQUFRLE9BQU8sTUFBTSxRQUFRO0lBQ3pCLGVBQWU7SUFDZixHQUFHLFFBQVEsU0FBUztHQUN4QixDQUFDO0dBQ0QsSUFBSSxFQUFFLFFBQVEsU0FBUyxnQkFDbkIsUUFBUSxTQUFTLGFBQWEsY0FDOUIsUUFBUSxVQUFVO0dBRXRCLFFBQVEsVUFBVSxNQUFNO0dBQ3hCLGlCQUFpQixXQUFXLEVBQUUsR0FBRyxNQUFNLEVBQUU7RUFDN0MsT0FFSSxRQUFRLG9CQUFvQjtDQUVwQyxHQUFHLENBQUMsU0FBUyxNQUFNLE1BQU0sQ0FBQztDQUMxQixhQUFNLGdCQUFnQjtFQUNsQixJQUFJLENBQUMsUUFBUSxPQUFPLFNBQVUsQ0FBQyxXQUFXLFdBQVcsQ0FBQyxNQUFNLFFBQVM7R0FDakUsUUFBUSxVQUFVO0dBQ2xCLFFBQVEsT0FBTyxRQUFRO0VBQzNCO0VBQ0EsV0FBVyxVQUFVO0VBQ3JCLElBQUksUUFBUSxPQUFPLE9BQU87R0FDdEIsUUFBUSxPQUFPLFFBQVE7R0FDdkIsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUFFLEdBQUcsUUFBUSxXQUFXLENBQUM7RUFDMUQ7RUFDQSxRQUFRLGlCQUFpQjtDQUM3QixDQUFDO0NBQ0QsYUFBYSxRQUFRLFlBQUEsYUFBa0IsY0FBYyxrQkFBa0IsV0FBVyxPQUFPLEdBQUcsQ0FBQyxTQUFTLFNBQVMsQ0FBQztDQUNoSCxPQUFPLGFBQWE7QUFDeEI7QUFFQSxJQUFNLGtCQUFBLGFBQXdCLGNBQWMsSUFBSTtBQUNoRCxnQkFBZ0IsY0FBYzs7Ozs7Ozs7Ozs7O0FBWTlCLElBQU0sdUJBQUEsYUFBNkIsV0FBVyxlQUFlOzs7Ozs7Ozs7Ozs7OztBQWM3RCxJQUFNLGdCQUFnQixFQUFFLFVBQVUsT0FBTyxXQUFXLFdBQVcsZUFBZSxVQUFVLGFBQWEsVUFBVSxXQUFXLFNBQVMsV0FBVyxZQUFZLE9BQU8sb0JBQW9CLGNBQWMsWUFBWSxTQUFTLFVBQVUsVUFBVSxnQkFBaUI7Q0FDelAsTUFBTSxnQkFBQSxhQUFzQixlQUFlO0VBQ3ZDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0osSUFBSTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0osQ0FBQztDQUNELE9BQUEsYUFBYyxjQUFjLGdCQUFnQixVQUFVLEVBQUUsT0FBTyxjQUFjLEdBQUEsYUFDbkUsY0FBYyx1QkFBdUIsVUFBVSxFQUFFLE9BQU8sY0FBYyxRQUFRLEdBQUcsUUFBUSxDQUFDO0FBQ3hHOzs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsSUFBTSxTQUFTLFVBQVUsTUFBTSxPQUFPLFNBQVM7Q0FBRSxNQUFNLE1BQU07Q0FBTyxHQUFHO0FBQU0sQ0FBQyxDQUFDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==