import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/realtime/realtime-boundary.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { io } from "/node_modules/.vite/deps/socket__io-client.js?v=22c23eb4";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { marketEventSchema, sessionReadySchema } from "/src/contracts/event.ts";
import { useSession, sessionOptions } from "/src/features/auth/api.ts";
import { getToken, identityEpoch, registerSessionCleanup } from "/src/lib/identity.ts";
import { nftKeys } from "/src/lib/query-keys.ts";
import { Button } from "/src/components/ui/button.tsx";
import { realtimeSnapshot, retryRealtime, setRealtimeRetry, updateRealtime, useRealtime } from "/src/features/realtime/state.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/realtime/realtime-boundary.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function RealtimeBoundary() {
	_s();
	const session = useSession();
	const client = useQueryClient();
	const state = useRealtime();
	const token = getToken();
	const userId = session.data?.user.id ?? null;
	const ready = session.isSuccess;
	useEffect(() => {
		if (!ready) return;
		const lifetime = new AbortController();
		let connectedBefore = false;
		let sessionId = null;
		const epoch = identityEpoch();
		const seen = new Set();
		const versions = new Map();
		const socket = io(location.origin, {
			path: "/kurio-live",
			transports: ["websocket"],
			autoConnect: false,
			forceNew: true,
			auth: { token },
			reconnection: true,
			reconnectionDelay: 100,
			reconnectionDelayMax: 1e3,
			randomizationFactor: 0
		});
		const current = () => !lifetime.signal.aborted && epoch === identityEpoch() && token === getToken();
		async function reconcile() {
			if (!current()) return;
			updateRealtime({ syncing: true });
			try {
				const valid = await client.fetchQuery({
					...sessionOptions,
					staleTime: 0
				});
				if (!current() || (valid?.user.id ?? null) !== userId) return;
				await client.cancelQueries({ predicate: (query) => query.queryKey[0] === "nfts" || query.queryKey[0] === "cart" || query.queryKey[0] === "private" && query.queryKey[1] === userId });
				if (!current()) return;
				await client.invalidateQueries({ predicate: (query) => query.queryKey[0] === "nfts" || query.queryKey[0] === "cart" || query.queryKey[0] === "private" && query.queryKey[1] === userId });
				if (current()) updateRealtime({ syncing: false });
			} catch {
				if (current()) updateRealtime({
					status: "error",
					syncing: false
				});
			}
		}
		function cachedVersion(event) {
			if (event.type === "order.updated") {
				const previous = client.getQueryData([
					"private",
					userId,
					"orders",
					event.resourceId
				]);
				if (previous && previous.status !== "pending" && event.payload.status !== previous.status) return Infinity;
				return previous?.version ?? 0;
			}
			let version = client.getQueryData(nftKeys.detail(event.resourceId))?.version ?? 0;
			for (const [, page] of client.getQueriesData({ queryKey: nftKeys.lists() })) version = Math.max(version, page?.items.find((item) => item.id === event.resourceId)?.version ?? 0);
			return version;
		}
		async function receive(raw) {
			if (!current()) return;
			const parsed = marketEventSchema.safeParse(raw);
			if (!parsed.success) return;
			const event = parsed.data;
			const resource = `${event.type}:${event.resourceId}`;
			const permitted = event.type !== "order.updated" || !!userId && event.userId === userId && event.sessionId === sessionId;
			if (!permitted || seen.has(event.eventId) || event.version <= (versions.get(resource) ?? 0) || event.version < cachedVersion(event)) {
				socket.emit("event.ack", {
					eventId: event.eventId,
					status: "ignored"
				});
				return;
			}
			seen.add(event.eventId);
			versions.set(resource, event.version);
			if (seen.size > 500) seen.delete(seen.values().next().value);
			socket.emit("event.ack", {
				eventId: event.eventId,
				status: "accepted"
			});
			if (event.type === "nft.updated") {
				const previous = realtimeSnapshot();
				updateRealtime({
					nftVersions: {
						...previous.nftVersions,
						[event.resourceId]: event.version
					},
					lastNft: event.payload
				});
				await client.cancelQueries({ predicate: (query) => query.queryKey[0] === "nfts" || query.queryKey[0] === "cart" || query.queryKey[0] === "private" && query.queryKey[1] === userId && query.queryKey[2] === "favorites" });
				if (!current()) return;
				await client.invalidateQueries({ predicate: (query) => query.queryKey[0] === "nfts" || query.queryKey[0] === "cart" || query.queryKey[0] === "private" && query.queryKey[1] === userId && query.queryKey[2] === "favorites" });
			} else {
				await client.cancelQueries({ queryKey: [
					"private",
					userId,
					"orders"
				] });
				if (!current()) return;
				await client.invalidateQueries({ queryKey: [
					"private",
					userId,
					"orders"
				] });
				if (!current()) return;
				if (event.payload.status === "confirmed") await client.invalidateQueries({ queryKey: ["cart", `user:${userId}`] });
			}
		}
		socket.on("session.ready", (raw) => {
			const result = sessionReadySchema.safeParse(raw);
			if (current() && result.success && result.data.userId === userId) sessionId = result.data.sessionId;
		});
		socket.on("nft.updated", (event) => {
			void receive(event);
		});
		socket.on("order.updated", (event) => {
			void receive(event);
		});
		socket.on("connect", () => {
			if (!current()) return;
			updateRealtime({
				status: "connected",
				transport: socket.io.engine.transport.name
			});
			if (connectedBefore) void reconcile();
			connectedBefore = true;
		});
		socket.on("disconnect", () => {
			if (current()) updateRealtime({
				status: "disconnected",
				transport: null,
				syncing: false
			});
		});
		socket.on("connect_error", () => {
			if (!current()) return;
			updateRealtime({
				status: "error",
				transport: null,
				syncing: false
			});
			if (token) void client.fetchQuery({
				...sessionOptions,
				staleTime: 0
			}).catch(() => {});
		});
		socket.io.on("reconnect_attempt", () => {
			if (current()) updateRealtime({ status: "reconnecting" });
		});
		const unregisterRetry = setRealtimeRetry(() => {
			if (current()) {
				if (socket.connected) void reconcile();
				else socket.connect();
			}
		});
		updateRealtime({
			status: "connecting",
			transport: null
		});
		socket.connect();
		const stop = () => {
			lifetime.abort();
			unregisterRetry();
			socket.io.reconnection(false);
			socket.removeAllListeners();
			socket.io.removeAllListeners();
			socket.disconnect();
		};
		const unregister = registerSessionCleanup(stop);
		return () => {
			stop();
			unregister();
		};
	}, [
		client,
		ready,
		token,
		userId
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "realtime-feedback",
		role: "status",
		"aria-label": "Conexão em tempo real",
		"data-testid": "realtime-status",
		"data-transport": state.transport ?? "",
		children: [state.syncing ? "Reconectado. Sincronizando dados…" : state.status === "connected" ? "Atualizações ao vivo conectadas." : state.status === "connecting" ? "Conectando atualizações ao vivo…" : "Conexão ao vivo interrompida. Reconectando…", [
			"error",
			"disconnected",
			"reconnecting"
		].includes(state.status) && /* @__PURE__ */ _jsxDEV(Button, {
			variant: "link",
			onClick: retryRealtime,
			children: "Reconectar atualizações"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 102,
			columnNumber: 74
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 100,
		columnNumber: 10
	}, this);
}
_s(RealtimeBoundary, "9+mk6uGSr/CtmKjDivezULrZfk0=", false, function() {
	return [
		useSession,
		useQueryClient,
		useRealtime
	];
});
_c = RealtimeBoundary;
var _c;
$RefreshReg$(_c, "RealtimeBoundary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/realtime/realtime-boundary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/realtime/realtime-boundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/realtime/realtime-boundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/realtime/realtime-boundary.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxVQUF1QjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLG1CQUFtQiwwQkFBa0Y7QUFHOUcsU0FBUyxZQUFZLHNCQUFzQjtBQUMzQyxTQUFTLFVBQVUsZUFBZSw4QkFBOEI7QUFDaEUsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsY0FBYztBQUN2QixTQUFTLGtCQUFrQixlQUFlLGtCQUFrQixnQkFBZ0IsbUJBQW1COzs7O0FBQy9GLE9BQU8sU0FBUyxtQkFBbUI7O0NBQ2pDLE1BQU0sVUFBVSxXQUFXO0NBQUcsTUFBTSxTQUFTLGVBQWU7Q0FBRyxNQUFNLFFBQVEsWUFBWTtDQUN6RixNQUFNLFFBQVEsU0FBUztDQUFHLE1BQU0sU0FBUyxRQUFRLE1BQU0sS0FBSyxNQUFNO0NBQU0sTUFBTSxRQUFRLFFBQVE7Q0FDOUYsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE9BQU87RUFDWixNQUFNLFdBQVcsSUFBSSxnQkFBZ0I7RUFBRyxJQUFJLGtCQUFrQjtFQUFPLElBQUksWUFBMkI7RUFDcEcsTUFBTSxRQUFRLGNBQWM7RUFBRyxNQUFNLE9BQU8sSUFBSSxJQUFZO0VBQUcsTUFBTSxXQUFXLElBQUksSUFBb0I7RUFDeEcsTUFBTSxTQUE2QyxHQUFHLFNBQVMsUUFBUTtHQUNyRSxNQUFNO0dBQWUsWUFBWSxDQUFDLFdBQVc7R0FBRyxhQUFhO0dBQU8sVUFBVTtHQUM5RSxNQUFNLEVBQUUsTUFBTTtHQUFHLGNBQWM7R0FBTSxtQkFBbUI7R0FBSyxzQkFBc0I7R0FBTSxxQkFBcUI7RUFDaEgsQ0FBQztFQUNELE1BQU0sZ0JBQWdCLENBQUMsU0FBUyxPQUFPLFdBQVcsVUFBVSxjQUFjLEtBQUssVUFBVSxTQUFTO0VBQ2xHLGVBQWUsWUFBWTtHQUN6QixJQUFJLENBQUMsUUFBUSxHQUFHO0dBQ2hCLGVBQWUsRUFBRSxTQUFTLEtBQUssQ0FBQztHQUNoQyxJQUFJO0lBQ0YsTUFBTSxRQUFRLE1BQU0sT0FBTyxXQUFXO0tBQUUsR0FBRztLQUFnQixXQUFXO0lBQUUsQ0FBQztJQUN6RSxJQUFJLENBQUMsUUFBUSxNQUFNLE9BQU8sS0FBSyxNQUFNLFVBQVUsUUFBUTtJQUN2RCxNQUFNLE9BQU8sY0FBYyxFQUFFLFlBQVcsVUFBUyxNQUFNLFNBQVMsT0FBTyxVQUFVLE1BQU0sU0FBUyxPQUFPLFVBQVcsTUFBTSxTQUFTLE9BQU8sYUFBYSxNQUFNLFNBQVMsT0FBTyxPQUFRLENBQUM7SUFDcEwsSUFBSSxDQUFDLFFBQVEsR0FBRztJQUNoQixNQUFNLE9BQU8sa0JBQWtCLEVBQUUsWUFBVyxVQUFTLE1BQU0sU0FBUyxPQUFPLFVBQVUsTUFBTSxTQUFTLE9BQU8sVUFBVyxNQUFNLFNBQVMsT0FBTyxhQUFhLE1BQU0sU0FBUyxPQUFPLE9BQVEsQ0FBQztJQUN4TCxJQUFJLFFBQVEsR0FBRyxlQUFlLEVBQUUsU0FBUyxNQUFNLENBQUM7R0FDbEQsUUFBUTtJQUFFLElBQUksUUFBUSxHQUFHLGVBQWU7S0FBRSxRQUFRO0tBQVMsU0FBUztJQUFNLENBQUM7R0FBRTtFQUMvRTtFQUNBLFNBQVMsY0FBYyxPQUFvQjtHQUN6QyxJQUFJLE1BQU0sU0FBUyxpQkFBaUI7SUFDbEMsTUFBTSxXQUFXLE9BQU8sYUFBb0I7S0FBQztLQUFXO0tBQVE7S0FBVSxNQUFNO0lBQVUsQ0FBQztJQUMzRixJQUFJLFlBQVksU0FBUyxXQUFXLGFBQWEsTUFBTSxRQUFRLFdBQVcsU0FBUyxRQUFRLE9BQU87SUFDbEcsT0FBTyxVQUFVLFdBQVc7R0FDOUI7R0FDQSxJQUFJLFVBQVUsT0FBTyxhQUFrQixRQUFRLE9BQU8sTUFBTSxVQUFVLENBQUMsQ0FBQyxFQUFFLFdBQVc7R0FDckYsS0FBSyxNQUFNLEdBQUcsU0FBUyxPQUFPLGVBQTRCLEVBQUUsVUFBVSxRQUFRLE1BQU0sRUFBRSxDQUFDLEdBQUcsVUFBVSxLQUFLLElBQUksU0FBUyxNQUFNLE1BQU0sTUFBSyxTQUFRLEtBQUssT0FBTyxNQUFNLFVBQVUsQ0FBQyxFQUFFLFdBQVcsQ0FBQztHQUMxTCxPQUFPO0VBQ1Q7RUFDQSxlQUFlLFFBQVEsS0FBYztHQUNuQyxJQUFJLENBQUMsUUFBUSxHQUFHO0dBQ2hCLE1BQU0sU0FBUyxrQkFBa0IsVUFBVSxHQUFHO0dBQUcsSUFBSSxDQUFDLE9BQU8sU0FBUztHQUN0RSxNQUFNLFFBQVEsT0FBTztHQUNyQixNQUFNLFdBQVcsR0FBRyxNQUFNLEtBQUssR0FBRyxNQUFNO0dBQ3hDLE1BQU0sWUFBWSxNQUFNLFNBQVMsbUJBQW9CLENBQUMsQ0FBQyxVQUFVLE1BQU0sV0FBVyxVQUFVLE1BQU0sY0FBYztHQUNoSCxJQUFJLENBQUMsYUFBYSxLQUFLLElBQUksTUFBTSxPQUFPLEtBQUssTUFBTSxZQUFZLFNBQVMsSUFBSSxRQUFRLEtBQUssTUFBTSxNQUFNLFVBQVUsY0FBYyxLQUFLLEdBQUc7SUFDbkksT0FBTyxLQUFLLGFBQWE7S0FBRSxTQUFTLE1BQU07S0FBUyxRQUFRO0lBQVUsQ0FBQztJQUFHO0dBQzNFO0dBQ0EsS0FBSyxJQUFJLE1BQU0sT0FBTztHQUFHLFNBQVMsSUFBSSxVQUFVLE1BQU0sT0FBTztHQUM3RCxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQU07R0FDNUQsT0FBTyxLQUFLLGFBQWE7SUFBRSxTQUFTLE1BQU07SUFBUyxRQUFRO0dBQVcsQ0FBQztHQUN2RSxJQUFJLE1BQU0sU0FBUyxlQUFlO0lBQ2hDLE1BQU0sV0FBVyxpQkFBaUI7SUFDbEMsZUFBZTtLQUFFLGFBQWE7TUFBRSxHQUFHLFNBQVM7T0FBYyxNQUFNLGFBQWEsTUFBTTtLQUFRO0tBQUcsU0FBUyxNQUFNO0lBQVEsQ0FBQztJQUN0SCxNQUFNLE9BQU8sY0FBYyxFQUFFLFlBQVcsVUFBUyxNQUFNLFNBQVMsT0FBTyxVQUFVLE1BQU0sU0FBUyxPQUFPLFVBQVcsTUFBTSxTQUFTLE9BQU8sYUFBYSxNQUFNLFNBQVMsT0FBTyxVQUFVLE1BQU0sU0FBUyxPQUFPLFlBQWEsQ0FBQztJQUN6TixJQUFJLENBQUMsUUFBUSxHQUFHO0lBQ2hCLE1BQU0sT0FBTyxrQkFBa0IsRUFBRSxZQUFXLFVBQVMsTUFBTSxTQUFTLE9BQU8sVUFBVSxNQUFNLFNBQVMsT0FBTyxVQUFXLE1BQU0sU0FBUyxPQUFPLGFBQWEsTUFBTSxTQUFTLE9BQU8sVUFBVSxNQUFNLFNBQVMsT0FBTyxZQUFhLENBQUM7R0FDL04sT0FBTztJQUNMLE1BQU0sT0FBTyxjQUFjLEVBQUUsVUFBVTtLQUFDO0tBQVc7S0FBUTtJQUFRLEVBQUUsQ0FBQztJQUN0RSxJQUFJLENBQUMsUUFBUSxHQUFHO0lBQ2hCLE1BQU0sT0FBTyxrQkFBa0IsRUFBRSxVQUFVO0tBQUM7S0FBVztLQUFRO0lBQVEsRUFBRSxDQUFDO0lBQzFFLElBQUksQ0FBQyxRQUFRLEdBQUc7SUFDaEIsSUFBSSxNQUFNLFFBQVEsV0FBVyxhQUFhLE1BQU0sT0FBTyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsUUFBUSxRQUFRLFFBQVEsRUFBRSxDQUFDO0dBQ25IO0VBQ0Y7RUFDQSxPQUFPLEdBQUcsa0JBQWlCLFFBQU87R0FDaEMsTUFBTSxTQUFTLG1CQUFtQixVQUFVLEdBQUc7R0FDL0MsSUFBSSxRQUFRLEtBQUssT0FBTyxXQUFXLE9BQU8sS0FBSyxXQUFXLFFBQVEsWUFBWSxPQUFPLEtBQUs7RUFDNUYsQ0FBQztFQUNELE9BQU8sR0FBRyxnQkFBZSxVQUFTO0dBQUUsS0FBSyxRQUFRLEtBQUs7RUFBRSxDQUFDO0VBQ3pELE9BQU8sR0FBRyxrQkFBaUIsVUFBUztHQUFFLEtBQUssUUFBUSxLQUFLO0VBQUUsQ0FBQztFQUMzRCxPQUFPLEdBQUcsaUJBQWlCO0dBQ3pCLElBQUksQ0FBQyxRQUFRLEdBQUc7R0FDaEIsZUFBZTtJQUFFLFFBQVE7SUFBYSxXQUFXLE9BQU8sR0FBRyxPQUFPLFVBQVU7R0FBSyxDQUFDO0dBQ2xGLElBQUksaUJBQWlCLEtBQUssVUFBVTtHQUNwQyxrQkFBa0I7RUFDcEIsQ0FBQztFQUNELE9BQU8sR0FBRyxvQkFBb0I7R0FBRSxJQUFJLFFBQVEsR0FBRyxlQUFlO0lBQUUsUUFBUTtJQUFnQixXQUFXO0lBQU0sU0FBUztHQUFNLENBQUM7RUFBRSxDQUFDO0VBQzVILE9BQU8sR0FBRyx1QkFBdUI7R0FDL0IsSUFBSSxDQUFDLFFBQVEsR0FBRztHQUNoQixlQUFlO0lBQUUsUUFBUTtJQUFTLFdBQVc7SUFBTSxTQUFTO0dBQU0sQ0FBQztHQUNuRSxJQUFJLE9BQU8sS0FBSyxPQUFPLFdBQVc7SUFBRSxHQUFHO0lBQWdCLFdBQVc7R0FBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUN2RixDQUFDO0VBQ0QsT0FBTyxHQUFHLEdBQUcsMkJBQTJCO0dBQUUsSUFBSSxRQUFRLEdBQUcsZUFBZSxFQUFFLFFBQVEsZUFBZSxDQUFDO0VBQUUsQ0FBQztFQUNyRyxNQUFNLGtCQUFrQix1QkFBdUI7R0FBRSxJQUFJLFFBQVEsR0FBRztJQUFFLElBQUksT0FBTyxXQUFXLEtBQUssVUFBVTtTQUFRLE9BQU8sUUFBUTtHQUFFO0VBQUUsQ0FBQztFQUNuSSxlQUFlO0dBQUUsUUFBUTtHQUFjLFdBQVc7RUFBSyxDQUFDO0VBQ3hELE9BQU8sUUFBUTtFQUNmLE1BQU0sYUFBYTtHQUNqQixTQUFTLE1BQU07R0FBRyxnQkFBZ0I7R0FBRyxPQUFPLEdBQUcsYUFBYSxLQUFLO0dBQUcsT0FBTyxtQkFBbUI7R0FBRyxPQUFPLEdBQUcsbUJBQW1CO0dBQUcsT0FBTyxXQUFXO0VBQ3JKO0VBQ0EsTUFBTSxhQUFhLHVCQUF1QixJQUFJO0VBQzlDLGFBQWE7R0FBRSxLQUFLO0dBQUcsV0FBVztFQUFFO0NBQ3RDLEdBQUc7RUFBQztFQUFRO0VBQU87RUFBTztDQUFNLENBQUM7Q0FDakMsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFvQixNQUFLO0VBQVMsY0FBVztFQUF3QixlQUFZO0VBQWtCLGtCQUFnQixNQUFNLGFBQWE7WUFBckosQ0FDSixNQUFNLFVBQVUsc0NBQXNDLE1BQU0sV0FBVyxjQUFjLHFDQUFxQyxNQUFNLFdBQVcsZUFBZSxxQ0FBcUMsK0NBQy9MO0dBQUM7R0FBUztHQUFnQjtFQUFjLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFBTSxLQUFLLHdCQUFDLFFBQUQ7R0FBUSxTQUFRO0dBQU8sU0FBUzthQUFlO0VBQStCOzs7O1VBQ2hKOzs7Ozs7QUFDUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJyZWFsdGltZS1ib3VuZGFyeS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBpbywgdHlwZSBTb2NrZXQgfSBmcm9tICdzb2NrZXQuaW8tY2xpZW50J1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBtYXJrZXRFdmVudFNjaGVtYSwgc2Vzc2lvblJlYWR5U2NoZW1hLCB0eXBlIE1hcmtldEV2ZW50LCB0eXBlIFNlcnZlckV2ZW50cywgdHlwZSBDbGllbnRFdmVudHMgfSBmcm9tICdAL2NvbnRyYWN0cy9ldmVudCdcbmltcG9ydCB0eXBlIHsgTmZ0LCBDYXRhbG9nUGFnZSB9IGZyb20gJ0AvY29udHJhY3RzL25mdCdcbmltcG9ydCB0eXBlIHsgT3JkZXIgfSBmcm9tICdAL2NvbnRyYWN0cy9vcmRlcidcbmltcG9ydCB7IHVzZVNlc3Npb24sIHNlc3Npb25PcHRpb25zIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2FwaSdcbmltcG9ydCB7IGdldFRva2VuLCBpZGVudGl0eUVwb2NoLCByZWdpc3RlclNlc3Npb25DbGVhbnVwIH0gZnJvbSAnQC9saWIvaWRlbnRpdHknXG5pbXBvcnQgeyBuZnRLZXlzIH0gZnJvbSAnQC9saWIvcXVlcnkta2V5cydcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyByZWFsdGltZVNuYXBzaG90LCByZXRyeVJlYWx0aW1lLCBzZXRSZWFsdGltZVJldHJ5LCB1cGRhdGVSZWFsdGltZSwgdXNlUmVhbHRpbWUgfSBmcm9tICcuL3N0YXRlJ1xuZXhwb3J0IGZ1bmN0aW9uIFJlYWx0aW1lQm91bmRhcnkoKSB7XG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKCk7IGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7IGNvbnN0IHN0YXRlID0gdXNlUmVhbHRpbWUoKVxuICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7IGNvbnN0IHVzZXJJZCA9IHNlc3Npb24uZGF0YT8udXNlci5pZCA/PyBudWxsOyBjb25zdCByZWFkeSA9IHNlc3Npb24uaXNTdWNjZXNzXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFyZWFkeSkgcmV0dXJuXG4gICAgY29uc3QgbGlmZXRpbWUgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7IGxldCBjb25uZWN0ZWRCZWZvcmUgPSBmYWxzZTsgbGV0IHNlc3Npb25JZDogc3RyaW5nIHwgbnVsbCA9IG51bGxcbiAgICBjb25zdCBlcG9jaCA9IGlkZW50aXR5RXBvY2goKTsgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpOyBjb25zdCB2ZXJzaW9ucyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcbiAgICBjb25zdCBzb2NrZXQ6IFNvY2tldDxTZXJ2ZXJFdmVudHMsIENsaWVudEV2ZW50cz4gPSBpbyhsb2NhdGlvbi5vcmlnaW4sIHtcbiAgICAgIHBhdGg6ICcva3VyaW8tbGl2ZScsIHRyYW5zcG9ydHM6IFsnd2Vic29ja2V0J10sIGF1dG9Db25uZWN0OiBmYWxzZSwgZm9yY2VOZXc6IHRydWUsXG4gICAgICBhdXRoOiB7IHRva2VuIH0sIHJlY29ubmVjdGlvbjogdHJ1ZSwgcmVjb25uZWN0aW9uRGVsYXk6IDEwMCwgcmVjb25uZWN0aW9uRGVsYXlNYXg6IDEwMDAsIHJhbmRvbWl6YXRpb25GYWN0b3I6IDAsXG4gICAgfSlcbiAgICBjb25zdCBjdXJyZW50ID0gKCkgPT4gIWxpZmV0aW1lLnNpZ25hbC5hYm9ydGVkICYmIGVwb2NoID09PSBpZGVudGl0eUVwb2NoKCkgJiYgdG9rZW4gPT09IGdldFRva2VuKClcbiAgICBhc3luYyBmdW5jdGlvbiByZWNvbmNpbGUoKSB7XG4gICAgICBpZiAoIWN1cnJlbnQoKSkgcmV0dXJuXG4gICAgICB1cGRhdGVSZWFsdGltZSh7IHN5bmNpbmc6IHRydWUgfSlcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHZhbGlkID0gYXdhaXQgY2xpZW50LmZldGNoUXVlcnkoeyAuLi5zZXNzaW9uT3B0aW9ucywgc3RhbGVUaW1lOiAwIH0pXG4gICAgICAgIGlmICghY3VycmVudCgpIHx8ICh2YWxpZD8udXNlci5pZCA/PyBudWxsKSAhPT0gdXNlcklkKSByZXR1cm5cbiAgICAgICAgYXdhaXQgY2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBwcmVkaWNhdGU6IHF1ZXJ5ID0+IHF1ZXJ5LnF1ZXJ5S2V5WzBdID09PSAnbmZ0cycgfHwgcXVlcnkucXVlcnlLZXlbMF0gPT09ICdjYXJ0JyB8fCAocXVlcnkucXVlcnlLZXlbMF0gPT09ICdwcml2YXRlJyAmJiBxdWVyeS5xdWVyeUtleVsxXSA9PT0gdXNlcklkKSB9KVxuICAgICAgICBpZiAoIWN1cnJlbnQoKSkgcmV0dXJuXG4gICAgICAgIGF3YWl0IGNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHByZWRpY2F0ZTogcXVlcnkgPT4gcXVlcnkucXVlcnlLZXlbMF0gPT09ICduZnRzJyB8fCBxdWVyeS5xdWVyeUtleVswXSA9PT0gJ2NhcnQnIHx8IChxdWVyeS5xdWVyeUtleVswXSA9PT0gJ3ByaXZhdGUnICYmIHF1ZXJ5LnF1ZXJ5S2V5WzFdID09PSB1c2VySWQpIH0pXG4gICAgICAgIGlmIChjdXJyZW50KCkpIHVwZGF0ZVJlYWx0aW1lKHsgc3luY2luZzogZmFsc2UgfSlcbiAgICAgIH0gY2F0Y2ggeyBpZiAoY3VycmVudCgpKSB1cGRhdGVSZWFsdGltZSh7IHN0YXR1czogJ2Vycm9yJywgc3luY2luZzogZmFsc2UgfSkgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBjYWNoZWRWZXJzaW9uKGV2ZW50OiBNYXJrZXRFdmVudCkge1xuICAgICAgaWYgKGV2ZW50LnR5cGUgPT09ICdvcmRlci51cGRhdGVkJykge1xuICAgICAgICBjb25zdCBwcmV2aW91cyA9IGNsaWVudC5nZXRRdWVyeURhdGE8T3JkZXI+KFsncHJpdmF0ZScsIHVzZXJJZCwgJ29yZGVycycsIGV2ZW50LnJlc291cmNlSWRdKVxuICAgICAgICBpZiAocHJldmlvdXMgJiYgcHJldmlvdXMuc3RhdHVzICE9PSAncGVuZGluZycgJiYgZXZlbnQucGF5bG9hZC5zdGF0dXMgIT09IHByZXZpb3VzLnN0YXR1cykgcmV0dXJuIEluZmluaXR5XG4gICAgICAgIHJldHVybiBwcmV2aW91cz8udmVyc2lvbiA/PyAwXG4gICAgICB9XG4gICAgICBsZXQgdmVyc2lvbiA9IGNsaWVudC5nZXRRdWVyeURhdGE8TmZ0PihuZnRLZXlzLmRldGFpbChldmVudC5yZXNvdXJjZUlkKSk/LnZlcnNpb24gPz8gMFxuICAgICAgZm9yIChjb25zdCBbLCBwYWdlXSBvZiBjbGllbnQuZ2V0UXVlcmllc0RhdGE8Q2F0YWxvZ1BhZ2U+KHsgcXVlcnlLZXk6IG5mdEtleXMubGlzdHMoKSB9KSkgdmVyc2lvbiA9IE1hdGgubWF4KHZlcnNpb24sIHBhZ2U/Lml0ZW1zLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBldmVudC5yZXNvdXJjZUlkKT8udmVyc2lvbiA/PyAwKVxuICAgICAgcmV0dXJuIHZlcnNpb25cbiAgICB9XG4gICAgYXN5bmMgZnVuY3Rpb24gcmVjZWl2ZShyYXc6IHVua25vd24pIHtcbiAgICAgIGlmICghY3VycmVudCgpKSByZXR1cm5cbiAgICAgIGNvbnN0IHBhcnNlZCA9IG1hcmtldEV2ZW50U2NoZW1hLnNhZmVQYXJzZShyYXcpOyBpZiAoIXBhcnNlZC5zdWNjZXNzKSByZXR1cm5cbiAgICAgIGNvbnN0IGV2ZW50ID0gcGFyc2VkLmRhdGFcbiAgICAgIGNvbnN0IHJlc291cmNlID0gYCR7ZXZlbnQudHlwZX06JHtldmVudC5yZXNvdXJjZUlkfWBcbiAgICAgIGNvbnN0IHBlcm1pdHRlZCA9IGV2ZW50LnR5cGUgIT09ICdvcmRlci51cGRhdGVkJyB8fCAoISF1c2VySWQgJiYgZXZlbnQudXNlcklkID09PSB1c2VySWQgJiYgZXZlbnQuc2Vzc2lvbklkID09PSBzZXNzaW9uSWQpXG4gICAgICBpZiAoIXBlcm1pdHRlZCB8fCBzZWVuLmhhcyhldmVudC5ldmVudElkKSB8fCBldmVudC52ZXJzaW9uIDw9ICh2ZXJzaW9ucy5nZXQocmVzb3VyY2UpID8/IDApIHx8IGV2ZW50LnZlcnNpb24gPCBjYWNoZWRWZXJzaW9uKGV2ZW50KSkge1xuICAgICAgICBzb2NrZXQuZW1pdCgnZXZlbnQuYWNrJywgeyBldmVudElkOiBldmVudC5ldmVudElkLCBzdGF0dXM6ICdpZ25vcmVkJyB9KTsgcmV0dXJuXG4gICAgICB9XG4gICAgICBzZWVuLmFkZChldmVudC5ldmVudElkKTsgdmVyc2lvbnMuc2V0KHJlc291cmNlLCBldmVudC52ZXJzaW9uKVxuICAgICAgaWYgKHNlZW4uc2l6ZSA+IDUwMCkgc2Vlbi5kZWxldGUoc2Vlbi52YWx1ZXMoKS5uZXh0KCkudmFsdWUhKVxuICAgICAgc29ja2V0LmVtaXQoJ2V2ZW50LmFjaycsIHsgZXZlbnRJZDogZXZlbnQuZXZlbnRJZCwgc3RhdHVzOiAnYWNjZXB0ZWQnIH0pXG4gICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ25mdC51cGRhdGVkJykge1xuICAgICAgICBjb25zdCBwcmV2aW91cyA9IHJlYWx0aW1lU25hcHNob3QoKVxuICAgICAgICB1cGRhdGVSZWFsdGltZSh7IG5mdFZlcnNpb25zOiB7IC4uLnByZXZpb3VzLm5mdFZlcnNpb25zLCBbZXZlbnQucmVzb3VyY2VJZF06IGV2ZW50LnZlcnNpb24gfSwgbGFzdE5mdDogZXZlbnQucGF5bG9hZCB9KVxuICAgICAgICBhd2FpdCBjbGllbnQuY2FuY2VsUXVlcmllcyh7IHByZWRpY2F0ZTogcXVlcnkgPT4gcXVlcnkucXVlcnlLZXlbMF0gPT09ICduZnRzJyB8fCBxdWVyeS5xdWVyeUtleVswXSA9PT0gJ2NhcnQnIHx8IChxdWVyeS5xdWVyeUtleVswXSA9PT0gJ3ByaXZhdGUnICYmIHF1ZXJ5LnF1ZXJ5S2V5WzFdID09PSB1c2VySWQgJiYgcXVlcnkucXVlcnlLZXlbMl0gPT09ICdmYXZvcml0ZXMnKSB9KVxuICAgICAgICBpZiAoIWN1cnJlbnQoKSkgcmV0dXJuXG4gICAgICAgIGF3YWl0IGNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHByZWRpY2F0ZTogcXVlcnkgPT4gcXVlcnkucXVlcnlLZXlbMF0gPT09ICduZnRzJyB8fCBxdWVyeS5xdWVyeUtleVswXSA9PT0gJ2NhcnQnIHx8IChxdWVyeS5xdWVyeUtleVswXSA9PT0gJ3ByaXZhdGUnICYmIHF1ZXJ5LnF1ZXJ5S2V5WzFdID09PSB1c2VySWQgJiYgcXVlcnkucXVlcnlLZXlbMl0gPT09ICdmYXZvcml0ZXMnKSB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgY2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogWydwcml2YXRlJywgdXNlcklkLCAnb3JkZXJzJ10gfSlcbiAgICAgICAgaWYgKCFjdXJyZW50KCkpIHJldHVyblxuICAgICAgICBhd2FpdCBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydwcml2YXRlJywgdXNlcklkLCAnb3JkZXJzJ10gfSlcbiAgICAgICAgaWYgKCFjdXJyZW50KCkpIHJldHVyblxuICAgICAgICBpZiAoZXZlbnQucGF5bG9hZC5zdGF0dXMgPT09ICdjb25maXJtZWQnKSBhd2FpdCBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydjYXJ0JywgYHVzZXI6JHt1c2VySWR9YF0gfSlcbiAgICAgIH1cbiAgICB9XG4gICAgc29ja2V0Lm9uKCdzZXNzaW9uLnJlYWR5JywgcmF3ID0+IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHNlc3Npb25SZWFkeVNjaGVtYS5zYWZlUGFyc2UocmF3KVxuICAgICAgaWYgKGN1cnJlbnQoKSAmJiByZXN1bHQuc3VjY2VzcyAmJiByZXN1bHQuZGF0YS51c2VySWQgPT09IHVzZXJJZCkgc2Vzc2lvbklkID0gcmVzdWx0LmRhdGEuc2Vzc2lvbklkXG4gICAgfSlcbiAgICBzb2NrZXQub24oJ25mdC51cGRhdGVkJywgZXZlbnQgPT4geyB2b2lkIHJlY2VpdmUoZXZlbnQpIH0pXG4gICAgc29ja2V0Lm9uKCdvcmRlci51cGRhdGVkJywgZXZlbnQgPT4geyB2b2lkIHJlY2VpdmUoZXZlbnQpIH0pXG4gICAgc29ja2V0Lm9uKCdjb25uZWN0JywgKCkgPT4ge1xuICAgICAgaWYgKCFjdXJyZW50KCkpIHJldHVyblxuICAgICAgdXBkYXRlUmVhbHRpbWUoeyBzdGF0dXM6ICdjb25uZWN0ZWQnLCB0cmFuc3BvcnQ6IHNvY2tldC5pby5lbmdpbmUudHJhbnNwb3J0Lm5hbWUgfSlcbiAgICAgIGlmIChjb25uZWN0ZWRCZWZvcmUpIHZvaWQgcmVjb25jaWxlKClcbiAgICAgIGNvbm5lY3RlZEJlZm9yZSA9IHRydWVcbiAgICB9KVxuICAgIHNvY2tldC5vbignZGlzY29ubmVjdCcsICgpID0+IHsgaWYgKGN1cnJlbnQoKSkgdXBkYXRlUmVhbHRpbWUoeyBzdGF0dXM6ICdkaXNjb25uZWN0ZWQnLCB0cmFuc3BvcnQ6IG51bGwsIHN5bmNpbmc6IGZhbHNlIH0pIH0pXG4gICAgc29ja2V0Lm9uKCdjb25uZWN0X2Vycm9yJywgKCkgPT4ge1xuICAgICAgaWYgKCFjdXJyZW50KCkpIHJldHVyblxuICAgICAgdXBkYXRlUmVhbHRpbWUoeyBzdGF0dXM6ICdlcnJvcicsIHRyYW5zcG9ydDogbnVsbCwgc3luY2luZzogZmFsc2UgfSlcbiAgICAgIGlmICh0b2tlbikgdm9pZCBjbGllbnQuZmV0Y2hRdWVyeSh7IC4uLnNlc3Npb25PcHRpb25zLCBzdGFsZVRpbWU6IDAgfSkuY2F0Y2goKCkgPT4ge30pXG4gICAgfSlcbiAgICBzb2NrZXQuaW8ub24oJ3JlY29ubmVjdF9hdHRlbXB0JywgKCkgPT4geyBpZiAoY3VycmVudCgpKSB1cGRhdGVSZWFsdGltZSh7IHN0YXR1czogJ3JlY29ubmVjdGluZycgfSkgfSlcbiAgICBjb25zdCB1bnJlZ2lzdGVyUmV0cnkgPSBzZXRSZWFsdGltZVJldHJ5KCgpID0+IHsgaWYgKGN1cnJlbnQoKSkgeyBpZiAoc29ja2V0LmNvbm5lY3RlZCkgdm9pZCByZWNvbmNpbGUoKTsgZWxzZSBzb2NrZXQuY29ubmVjdCgpIH0gfSlcbiAgICB1cGRhdGVSZWFsdGltZSh7IHN0YXR1czogJ2Nvbm5lY3RpbmcnLCB0cmFuc3BvcnQ6IG51bGwgfSlcbiAgICBzb2NrZXQuY29ubmVjdCgpXG4gICAgY29uc3Qgc3RvcCA9ICgpID0+IHtcbiAgICAgIGxpZmV0aW1lLmFib3J0KCk7IHVucmVnaXN0ZXJSZXRyeSgpOyBzb2NrZXQuaW8ucmVjb25uZWN0aW9uKGZhbHNlKTsgc29ja2V0LnJlbW92ZUFsbExpc3RlbmVycygpOyBzb2NrZXQuaW8ucmVtb3ZlQWxsTGlzdGVuZXJzKCk7IHNvY2tldC5kaXNjb25uZWN0KClcbiAgICB9XG4gICAgY29uc3QgdW5yZWdpc3RlciA9IHJlZ2lzdGVyU2Vzc2lvbkNsZWFudXAoc3RvcClcbiAgICByZXR1cm4gKCkgPT4geyBzdG9wKCk7IHVucmVnaXN0ZXIoKSB9XG4gIH0sIFtjbGllbnQsIHJlYWR5LCB0b2tlbiwgdXNlcklkXSlcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwicmVhbHRpbWUtZmVlZGJhY2tcIiByb2xlPVwic3RhdHVzXCIgYXJpYS1sYWJlbD1cIkNvbmV4w6NvIGVtIHRlbXBvIHJlYWxcIiBkYXRhLXRlc3RpZD1cInJlYWx0aW1lLXN0YXR1c1wiIGRhdGEtdHJhbnNwb3J0PXtzdGF0ZS50cmFuc3BvcnQgPz8gJyd9PlxuICAgIHtzdGF0ZS5zeW5jaW5nID8gJ1JlY29uZWN0YWRvLiBTaW5jcm9uaXphbmRvIGRhZG9z4oCmJyA6IHN0YXRlLnN0YXR1cyA9PT0gJ2Nvbm5lY3RlZCcgPyAnQXR1YWxpemHDp8O1ZXMgYW8gdml2byBjb25lY3RhZGFzLicgOiBzdGF0ZS5zdGF0dXMgPT09ICdjb25uZWN0aW5nJyA/ICdDb25lY3RhbmRvIGF0dWFsaXphw6fDtWVzIGFvIHZpdm/igKYnIDogJ0NvbmV4w6NvIGFvIHZpdm8gaW50ZXJyb21waWRhLiBSZWNvbmVjdGFuZG/igKYnfVxuICAgIHtbJ2Vycm9yJywgJ2Rpc2Nvbm5lY3RlZCcsICdyZWNvbm5lY3RpbmcnXS5pbmNsdWRlcyhzdGF0ZS5zdGF0dXMpICYmIDxCdXR0b24gdmFyaWFudD1cImxpbmtcIiBvbkNsaWNrPXtyZXRyeVJlYWx0aW1lfT5SZWNvbmVjdGFyIGF0dWFsaXphw6fDtWVzPC9CdXR0b24+fVxuICA8L2Rpdj5cbn1cbiJdfQ==