import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/async-state.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Button } from "/src/components/ui/button.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/async-state.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function LoadingState({ label = "Carregando…" }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		"aria-busy": "true",
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 68
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-10 w-2/3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 108
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-52 w-full" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 143
			}, this),
			/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-20 w-full" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 179
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 10
	}, this);
}
_c = LoadingState;
export function ErrorState({ message, retry }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "alert",
		className: "space-y-4 rounded border p-5",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 69
		}, this), /* @__PURE__ */ _jsxDEV(Button, {
			onClick: retry,
			children: "Tentar novamente"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 85
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 10
	}, this);
}
_c2 = ErrorState;
var _c, _c2;
$RefreshReg$(_c, "LoadingState");
$RefreshReg$(_c2, "ErrorState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/async-state.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/async-state.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/async-state.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/async-state.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZ0JBQWdCOzs7QUFDekIsT0FBTyxTQUFTLGFBQWEsRUFBRSxRQUFRLGlCQUFxQztDQUMxRSxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxNQUFLO0VBQVMsYUFBVTtFQUFPLFdBQVU7WUFBOUM7R0FBMEQsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBVztHQUFZOzs7OztHQUFDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGFBQWM7Ozs7O0dBQUMsd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7Ozs7R0FBQyx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7OztFQUFNOzs7Ozs7QUFDM047O0FBQ0EsT0FBTyxTQUFTLFdBQVcsRUFBRSxTQUFTLFNBQWlEO0NBQ3JGLE9BQU8sd0JBQUMsT0FBRDtFQUFLLE1BQUs7RUFBUSxXQUFVO1lBQTVCLENBQTJELHdCQUFDLEtBQUQsWUFBSSxRQUFXOzs7O1lBQUMsd0JBQUMsUUFBRDtHQUFRLFNBQVM7YUFBTztFQUF3Qjs7OztVQUFNOzs7Ozs7QUFDMUkiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXN5bmMtc3RhdGUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vdWkvYnV0dG9uJ1xuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICcuL3VpL3NrZWxldG9uJ1xuZXhwb3J0IGZ1bmN0aW9uIExvYWRpbmdTdGF0ZSh7IGxhYmVsID0gJ0NhcnJlZ2FuZG/igKYnIH06IHsgbGFiZWw/OiBzdHJpbmcgfSkge1xuICByZXR1cm4gPGRpdiByb2xlPVwic3RhdHVzXCIgYXJpYS1idXN5PVwidHJ1ZVwiIGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPjxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57bGFiZWx9PC9zcGFuPjxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTEwIHctMi8zXCIgLz48U2tlbGV0b24gY2xhc3NOYW1lPVwiaC01MiB3LWZ1bGxcIiAvPjxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTIwIHctZnVsbFwiIC8+PC9kaXY+XG59XG5leHBvcnQgZnVuY3Rpb24gRXJyb3JTdGF0ZSh7IG1lc3NhZ2UsIHJldHJ5IH06IHsgbWVzc2FnZTogc3RyaW5nOyByZXRyeTogKCkgPT4gdm9pZCB9KSB7XG4gIHJldHVybiA8ZGl2IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInNwYWNlLXktNCByb3VuZGVkIGJvcmRlciBwLTVcIj48cD57bWVzc2FnZX08L3A+PEJ1dHRvbiBvbkNsaWNrPXtyZXRyeX0+VGVudGFyIG5vdmFtZW50ZTwvQnV0dG9uPjwvZGl2PlxufVxuIl19