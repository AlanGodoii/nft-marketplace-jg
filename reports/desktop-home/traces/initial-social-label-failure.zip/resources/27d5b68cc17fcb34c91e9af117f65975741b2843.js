import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/dialog.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Dialog as DialogPrimitive } from "/node_modules/.vite/deps/@base-ui_react_dialog.js?v=22c23eb4";
import { cn } from "/node_modules/.vite/deps/cn.js?v=22c23eb4";
import { Button } from "/src/components/ui/button.tsx";
import { XIcon } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/ui/dialog.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
function Dialog({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPrimitive.Root, {
		"data-slot": "dialog",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 10
	}, this);
}
_c = Dialog;
function DialogTrigger({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPrimitive.Trigger, {
		"data-slot": "dialog-trigger",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 10
	}, this);
}
_c2 = DialogTrigger;
function DialogPortal({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPrimitive.Portal, {
		"data-slot": "dialog-portal",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 10
	}, this);
}
_c3 = DialogPortal;
function DialogClose({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPrimitive.Close, {
		"data-slot": "dialog-close",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 10
	}, this);
}
_c4 = DialogClose;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPrimitive.Backdrop, {
		"data-slot": "dialog-overlay",
		className: cn("fixed inset-0 isolate z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
_c5 = DialogOverlay;
function DialogContent({ className, children, showCloseButton = true, ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPortal, { children: [/* @__PURE__ */ _jsxDEV(DialogOverlay, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(DialogPrimitive.Popup, {
		"data-slot": "dialog-content",
		className: cn("fixed top-1/2 left-1/2 z-50 grid w-full max-w-[calc(100%-2rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-popover p-4 text-sm text-popover-foreground ring-1 ring-foreground/10 duration-100 outline-none sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className),
		...props,
		children: [children, showCloseButton && /* @__PURE__ */ _jsxDEV(DialogPrimitive.Close, {
			"data-slot": "dialog-close",
			render: /* @__PURE__ */ _jsxDEV(Button, {
				variant: "ghost",
				className: "absolute top-2 right-2",
				size: "icon-sm"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 15
			}, this),
			children: [/* @__PURE__ */ _jsxDEV(XIcon, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: "Fechar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 5
	}, this);
}
_c6 = DialogContent;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		"data-slot": "dialog-header",
		className: cn("flex flex-col gap-2", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 85,
		columnNumber: 5
	}, this);
}
_c7 = DialogHeader;
function DialogFooter({ className, showCloseButton = false, children, ...props }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		"data-slot": "dialog-footer",
		className: cn("-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t bg-muted/50 p-4 sm:flex-row sm:justify-end", className),
		...props,
		children: [children, showCloseButton && /* @__PURE__ */ _jsxDEV(DialogPrimitive.Close, {
			render: /* @__PURE__ */ _jsxDEV(Button, { variant: "outline" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 40
			}, this),
			children: "Close"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 112,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 102,
		columnNumber: 5
	}, this);
}
_c8 = DialogFooter;
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPrimitive.Title, {
		"data-slot": "dialog-title",
		className: cn("font-heading text-base leading-none font-medium", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 122,
		columnNumber: 5
	}, this);
}
_c9 = DialogTitle;
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(DialogPrimitive.Description, {
		"data-slot": "dialog-description",
		className: cn("text-sm text-muted-foreground *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 138,
		columnNumber: 5
	}, this);
}
_c10 = DialogDescription;
export { Dialog, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogOverlay, DialogPortal, DialogTitle, DialogTrigger };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
$RefreshReg$(_c, "Dialog");
$RefreshReg$(_c2, "DialogTrigger");
$RefreshReg$(_c3, "DialogPortal");
$RefreshReg$(_c4, "DialogClose");
$RefreshReg$(_c5, "DialogOverlay");
$RefreshReg$(_c6, "DialogContent");
$RefreshReg$(_c7, "DialogHeader");
$RefreshReg$(_c8, "DialogFooter");
$RefreshReg$(_c9, "DialogTitle");
$RefreshReg$(_c10, "DialogDescription");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/dialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/ui/dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/ui/dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/ui/dialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUE7QUFFQSxZQUFZLFdBQVc7QUFDdkIsU0FBUyxVQUFVLHVCQUF1QjtBQUMxQyxTQUFTLFVBQVU7QUFFbkIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsYUFBYTs7O0FBRXRCLFNBQVMsT0FBTyxFQUFFLEdBQUcsU0FBcUM7Q0FDeEQsT0FBTyx3QkFBQyxnQkFBZ0IsTUFBakI7RUFBc0IsYUFBVTtFQUFTLEdBQUk7Q0FBUTs7Ozs7QUFDOUQ7O0FBRUEsU0FBUyxjQUFjLEVBQUUsR0FBRyxTQUF3QztDQUNsRSxPQUFPLHdCQUFDLGdCQUFnQixTQUFqQjtFQUF5QixhQUFVO0VBQWlCLEdBQUk7Q0FBUTs7Ozs7QUFDekU7O0FBRUEsU0FBUyxhQUFhLEVBQUUsR0FBRyxTQUF1QztDQUNoRSxPQUFPLHdCQUFDLGdCQUFnQixRQUFqQjtFQUF3QixhQUFVO0VBQWdCLEdBQUk7Q0FBUTs7Ozs7QUFDdkU7O0FBRUEsU0FBUyxZQUFZLEVBQUUsR0FBRyxTQUFzQztDQUM5RCxPQUFPLHdCQUFDLGdCQUFnQixPQUFqQjtFQUF1QixhQUFVO0VBQWUsR0FBSTtDQUFROzs7OztBQUNyRTs7QUFFQSxTQUFTLGNBQWMsRUFDckIsV0FDQSxHQUFHLFNBQzhCO0NBQ2pDLE9BQ0Usd0JBQUMsZ0JBQWdCLFVBQWpCO0VBQ0UsYUFBVTtFQUNWLFdBQVcsR0FDVCx5TEFDQSxTQUNGO0VBQ0EsR0FBSTtDQUNMOzs7OztBQUVMOztBQUVBLFNBQVMsY0FBYyxFQUNyQixXQUNBLFVBQ0Esa0JBQWtCLE1BQ2xCLEdBQUcsU0FHRjtDQUNELE9BQ0Usd0JBQUMsY0FBRCxhQUNFLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7V0FDaEIsd0JBQUMsZ0JBQWdCLE9BQWpCO0VBQ0UsYUFBVTtFQUNWLFdBQVcsR0FDVCwwV0FDQSxTQUNGO0VBQ0EsR0FBSTtZQU5OLENBUUcsVUFDQSxtQkFDQyx3QkFBQyxnQkFBZ0IsT0FBakI7R0FDRSxhQUFVO0dBQ1YsUUFDRSx3QkFBQyxRQUFEO0lBQ0UsU0FBUTtJQUNSLFdBQVU7SUFDVixNQUFLO0dBQ047Ozs7O2FBUEwsQ0FVRSx3QkFBQyxPQUFELENBQ0M7Ozs7YUFDRCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFVO0dBQVk7Ozs7V0FDakI7Ozs7O1VBRUo7Ozs7O1NBQ1g7Ozs7O0FBRWxCOztBQUVBLFNBQVMsYUFBYSxFQUFFLFdBQVcsR0FBRyxTQUFzQztDQUMxRSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxhQUFVO0VBQ1YsV0FBVyxHQUFHLHVCQUF1QixTQUFTO0VBQzlDLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLGFBQWEsRUFDcEIsV0FDQSxrQkFBa0IsT0FDbEIsVUFDQSxHQUFHLFNBR0Y7Q0FDRCxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxhQUFVO0VBQ1YsV0FBVyxHQUNULDRHQUNBLFNBQ0Y7RUFDQSxHQUFJO1lBTk4sQ0FRRyxVQUNBLG1CQUNDLHdCQUFDLGdCQUFnQixPQUFqQjtHQUF1QixRQUFRLHdCQUFDLFFBQUQsRUFBUSxTQUFRLFVBQVc7Ozs7O2FBQUc7RUFFdEM7Ozs7VUFFdEI7Ozs7OztBQUVUOztBQUVBLFNBQVMsWUFBWSxFQUFFLFdBQVcsR0FBRyxTQUFzQztDQUN6RSxPQUNFLHdCQUFDLGdCQUFnQixPQUFqQjtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQ1QsbURBQ0EsU0FDRjtFQUNBLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLGtCQUFrQixFQUN6QixXQUNBLEdBQUcsU0FDaUM7Q0FDcEMsT0FDRSx3QkFBQyxnQkFBZ0IsYUFBakI7RUFDRSxhQUFVO0VBQ1YsV0FBVyxHQUNULHNHQUNBLFNBQ0Y7RUFDQSxHQUFJO0NBQ0w7Ozs7O0FBRUw7O0FBRUEsU0FDRSxRQUNBLGFBQ0EsZUFDQSxtQkFDQSxjQUNBLGNBQ0EsZUFDQSxjQUNBLGFBQ0EiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiZGlhbG9nLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIlxuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgRGlhbG9nIGFzIERpYWxvZ1ByaW1pdGl2ZSB9IGZyb20gXCJAYmFzZS11aS9yZWFjdC9kaWFsb2dcIlxuaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiXG5pbXBvcnQgeyBYSWNvbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIlxuXG5mdW5jdGlvbiBEaWFsb2coeyAuLi5wcm9wcyB9OiBEaWFsb2dQcmltaXRpdmUuUm9vdC5Qcm9wcykge1xuICByZXR1cm4gPERpYWxvZ1ByaW1pdGl2ZS5Sb290IGRhdGEtc2xvdD1cImRpYWxvZ1wiIHsuLi5wcm9wc30gLz5cbn1cblxuZnVuY3Rpb24gRGlhbG9nVHJpZ2dlcih7IC4uLnByb3BzIH06IERpYWxvZ1ByaW1pdGl2ZS5UcmlnZ2VyLlByb3BzKSB7XG4gIHJldHVybiA8RGlhbG9nUHJpbWl0aXZlLlRyaWdnZXIgZGF0YS1zbG90PVwiZGlhbG9nLXRyaWdnZXJcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIERpYWxvZ1BvcnRhbCh7IC4uLnByb3BzIH06IERpYWxvZ1ByaW1pdGl2ZS5Qb3J0YWwuUHJvcHMpIHtcbiAgcmV0dXJuIDxEaWFsb2dQcmltaXRpdmUuUG9ydGFsIGRhdGEtc2xvdD1cImRpYWxvZy1wb3J0YWxcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIERpYWxvZ0Nsb3NlKHsgLi4ucHJvcHMgfTogRGlhbG9nUHJpbWl0aXZlLkNsb3NlLlByb3BzKSB7XG4gIHJldHVybiA8RGlhbG9nUHJpbWl0aXZlLkNsb3NlIGRhdGEtc2xvdD1cImRpYWxvZy1jbG9zZVwiIHsuLi5wcm9wc30gLz5cbn1cblxuZnVuY3Rpb24gRGlhbG9nT3ZlcmxheSh7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IERpYWxvZ1ByaW1pdGl2ZS5CYWNrZHJvcC5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxEaWFsb2dQcmltaXRpdmUuQmFja2Ryb3BcbiAgICAgIGRhdGEtc2xvdD1cImRpYWxvZy1vdmVybGF5XCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZml4ZWQgaW5zZXQtMCBpc29sYXRlIHotNTAgYmctYmxhY2svMTAgZHVyYXRpb24tMTAwIHN1cHBvcnRzLWJhY2tkcm9wLWZpbHRlcjpiYWNrZHJvcC1ibHVyLXhzIGRhdGEtb3BlbjphbmltYXRlLWluIGRhdGEtb3BlbjpmYWRlLWluLTAgZGF0YS1jbG9zZWQ6YW5pbWF0ZS1vdXQgZGF0YS1jbG9zZWQ6ZmFkZS1vdXQtMFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBEaWFsb2dDb250ZW50KHtcbiAgY2xhc3NOYW1lLFxuICBjaGlsZHJlbixcbiAgc2hvd0Nsb3NlQnV0dG9uID0gdHJ1ZSxcbiAgLi4ucHJvcHNcbn06IERpYWxvZ1ByaW1pdGl2ZS5Qb3B1cC5Qcm9wcyAmIHtcbiAgc2hvd0Nsb3NlQnV0dG9uPzogYm9vbGVhblxufSkge1xuICByZXR1cm4gKFxuICAgIDxEaWFsb2dQb3J0YWw+XG4gICAgICA8RGlhbG9nT3ZlcmxheSAvPlxuICAgICAgPERpYWxvZ1ByaW1pdGl2ZS5Qb3B1cFxuICAgICAgICBkYXRhLXNsb3Q9XCJkaWFsb2ctY29udGVudFwiXG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJmaXhlZCB0b3AtMS8yIGxlZnQtMS8yIHotNTAgZ3JpZCB3LWZ1bGwgbWF4LXctW2NhbGMoMTAwJS0ycmVtKV0gLXRyYW5zbGF0ZS14LTEvMiAtdHJhbnNsYXRlLXktMS8yIGdhcC00IHJvdW5kZWQteGwgYmctcG9wb3ZlciBwLTQgdGV4dC1zbSB0ZXh0LXBvcG92ZXItZm9yZWdyb3VuZCByaW5nLTEgcmluZy1mb3JlZ3JvdW5kLzEwIGR1cmF0aW9uLTEwMCBvdXRsaW5lLW5vbmUgc206bWF4LXctc20gZGF0YS1vcGVuOmFuaW1hdGUtaW4gZGF0YS1vcGVuOmZhZGUtaW4tMCBkYXRhLW9wZW46em9vbS1pbi05NSBkYXRhLWNsb3NlZDphbmltYXRlLW91dCBkYXRhLWNsb3NlZDpmYWRlLW91dC0wIGRhdGEtY2xvc2VkOnpvb20tb3V0LTk1XCIsXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICAgIHsuLi5wcm9wc31cbiAgICAgID5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgICB7c2hvd0Nsb3NlQnV0dG9uICYmIChcbiAgICAgICAgICA8RGlhbG9nUHJpbWl0aXZlLkNsb3NlXG4gICAgICAgICAgICBkYXRhLXNsb3Q9XCJkaWFsb2ctY2xvc2VcIlxuICAgICAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgcmlnaHQtMlwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cImljb24tc21cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYSWNvblxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5GZWNoYXI8L3NwYW4+XG4gICAgICAgICAgPC9EaWFsb2dQcmltaXRpdmUuQ2xvc2U+XG4gICAgICAgICl9XG4gICAgICA8L0RpYWxvZ1ByaW1pdGl2ZS5Qb3B1cD5cbiAgICA8L0RpYWxvZ1BvcnRhbD5cbiAgKVxufVxuXG5mdW5jdGlvbiBEaWFsb2dIZWFkZXIoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPFwiZGl2XCI+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiZGlhbG9nLWhlYWRlclwiXG4gICAgICBjbGFzc05hbWU9e2NuKFwiZmxleCBmbGV4LWNvbCBnYXAtMlwiLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gRGlhbG9nRm9vdGVyKHtcbiAgY2xhc3NOYW1lLFxuICBzaG93Q2xvc2VCdXR0b24gPSBmYWxzZSxcbiAgY2hpbGRyZW4sXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPiAmIHtcbiAgc2hvd0Nsb3NlQnV0dG9uPzogYm9vbGVhblxufSkge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImRpYWxvZy1mb290ZXJcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCItbXgtNCAtbWItNCBmbGV4IGZsZXgtY29sLXJldmVyc2UgZ2FwLTIgcm91bmRlZC1iLXhsIGJvcmRlci10IGJnLW11dGVkLzUwIHAtNCBzbTpmbGV4LXJvdyBzbTpqdXN0aWZ5LWVuZFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgICAge3Nob3dDbG9zZUJ1dHRvbiAmJiAoXG4gICAgICAgIDxEaWFsb2dQcmltaXRpdmUuQ2xvc2UgcmVuZGVyPXs8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgLz59PlxuICAgICAgICAgIENsb3NlXG4gICAgICAgIDwvRGlhbG9nUHJpbWl0aXZlLkNsb3NlPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBEaWFsb2dUaXRsZSh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogRGlhbG9nUHJpbWl0aXZlLlRpdGxlLlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPERpYWxvZ1ByaW1pdGl2ZS5UaXRsZVxuICAgICAgZGF0YS1zbG90PVwiZGlhbG9nLXRpdGxlXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZm9udC1oZWFkaW5nIHRleHQtYmFzZSBsZWFkaW5nLW5vbmUgZm9udC1tZWRpdW1cIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gRGlhbG9nRGVzY3JpcHRpb24oe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBEaWFsb2dQcmltaXRpdmUuRGVzY3JpcHRpb24uUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nUHJpbWl0aXZlLkRlc2NyaXB0aW9uXG4gICAgICBkYXRhLXNsb3Q9XCJkaWFsb2ctZGVzY3JpcHRpb25cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCAqOlthXTp1bmRlcmxpbmUgKjpbYV06dW5kZXJsaW5lLW9mZnNldC0zICo6W2FdOmhvdmVyOnRleHQtZm9yZWdyb3VuZFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0Nsb3NlLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nRm9vdGVyLFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ092ZXJsYXksXG4gIERpYWxvZ1BvcnRhbCxcbiAgRGlhbG9nVGl0bGUsXG4gIERpYWxvZ1RyaWdnZXIsXG59XG4iXX0=