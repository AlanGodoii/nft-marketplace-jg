import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/catalog-pagination.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { ChevronLeft, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { Button } from "/src/components/ui/button.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-pagination.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function CatalogPagination({ page, pageCount, onPageChange, disabled = false }) {
	const ready = page !== undefined && pageCount !== undefined && pageCount > 0;
	return /* @__PURE__ */ _jsxDEV("nav", {
		"aria-label": "Paginação do catálogo",
		className: "flex flex-wrap items-center justify-center gap-4 border-t pt-8",
		children: [
			/* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				className: "size-10 rounded-sm",
				"aria-label": "Página anterior",
				disabled: disabled || !ready || page <= 1,
				onClick: () => ready && onPageChange(page - 1),
				children: /* @__PURE__ */ _jsxDEV(ChevronLeft, { "aria-hidden": "true" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"aria-live": "polite",
				className: "text-xs text-muted-foreground",
				children: ready ? `Página ${page} de ${pageCount}` : "Paginação indisponível"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				className: "size-10 rounded-sm",
				"aria-label": "Próxima página",
				disabled: disabled || !ready || page >= pageCount,
				onClick: () => ready && onPageChange(page + 1),
				children: /* @__PURE__ */ _jsxDEV(ChevronRight, { "aria-hidden": "true" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = CatalogPagination;
var _c;
$RefreshReg$(_c, "CatalogPagination");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/components/catalog-pagination.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-pagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-pagination.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-pagination.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLG9CQUFvQjtBQUMxQyxTQUFTLGNBQWM7OztBQUV2QixPQUFPLFNBQVMsa0JBQWtCLEVBQUUsTUFBTSxXQUFXLGNBQWMsV0FBVyxTQUszRTtDQUNELE1BQU0sUUFBUSxTQUFTLGFBQWEsY0FBYyxhQUFhLFlBQVk7Q0FDM0UsT0FDRSx3QkFBQyxPQUFEO0VBQUssY0FBVztFQUF3QixXQUFVO1lBQWxEO0dBQ0Usd0JBQUMsUUFBRDtJQUFRLFNBQVE7SUFBVSxXQUFVO0lBQXFCLGNBQVc7SUFDbEUsVUFBVSxZQUFZLENBQUMsU0FBUyxRQUFRO0lBQUcsZUFBZSxTQUFTLGFBQWEsT0FBTyxDQUFDO2NBQ3hGLHdCQUFDLGFBQUQsRUFBYSxlQUFZLE9BQVE7Ozs7O0dBQzNCOzs7OztHQUNSLHdCQUFDLFFBQUQ7SUFBTSxhQUFVO0lBQVMsV0FBVTtjQUNoQyxRQUFRLFVBQVUsS0FBSyxNQUFNLGNBQWM7R0FDeEM7Ozs7O0dBQ04sd0JBQUMsUUFBRDtJQUFRLFNBQVE7SUFBVSxXQUFVO0lBQXFCLGNBQVc7SUFDbEUsVUFBVSxZQUFZLENBQUMsU0FBUyxRQUFRO0lBQVcsZUFBZSxTQUFTLGFBQWEsT0FBTyxDQUFDO2NBQ2hHLHdCQUFDLGNBQUQsRUFBYyxlQUFZLE9BQVE7Ozs7O0dBQzVCOzs7OztFQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJjYXRhbG9nLXBhZ2luYXRpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1BhZ2luYXRpb24oeyBwYWdlLCBwYWdlQ291bnQsIG9uUGFnZUNoYW5nZSwgZGlzYWJsZWQgPSBmYWxzZSB9OiB7XG4gIGRpc2FibGVkPzogYm9vbGVhblxuICBwYWdlPzogbnVtYmVyXG4gIHBhZ2VDb3VudD86IG51bWJlclxuICBvblBhZ2VDaGFuZ2U6IChwYWdlOiBudW1iZXIpID0+IHZvaWRcbn0pIHtcbiAgY29uc3QgcmVhZHkgPSBwYWdlICE9PSB1bmRlZmluZWQgJiYgcGFnZUNvdW50ICE9PSB1bmRlZmluZWQgJiYgcGFnZUNvdW50ID4gMFxuICByZXR1cm4gKFxuICAgIDxuYXYgYXJpYS1sYWJlbD1cIlBhZ2luYcOnw6NvIGRvIGNhdMOhbG9nb1wiIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNCBib3JkZXItdCBwdC04XCI+XG4gICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwic2l6ZS0xMCByb3VuZGVkLXNtXCIgYXJpYS1sYWJlbD1cIlDDoWdpbmEgYW50ZXJpb3JcIlxuICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWQgfHwgIXJlYWR5IHx8IHBhZ2UgPD0gMX0gb25DbGljaz17KCkgPT4gcmVhZHkgJiYgb25QYWdlQ2hhbmdlKHBhZ2UgLSAxKX0+XG4gICAgICAgIDxDaGV2cm9uTGVmdCBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgPC9CdXR0b24+XG4gICAgICA8c3BhbiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICB7cmVhZHkgPyBgUMOhZ2luYSAke3BhZ2V9IGRlICR7cGFnZUNvdW50fWAgOiAnUGFnaW5hw6fDo28gaW5kaXNwb27DrXZlbCd9XG4gICAgICA8L3NwYW4+XG4gICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwic2l6ZS0xMCByb3VuZGVkLXNtXCIgYXJpYS1sYWJlbD1cIlByw7N4aW1hIHDDoWdpbmFcIlxuICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWQgfHwgIXJlYWR5IHx8IHBhZ2UgPj0gcGFnZUNvdW50fSBvbkNsaWNrPXsoKSA9PiByZWFkeSAmJiBvblBhZ2VDaGFuZ2UocGFnZSArIDEpfT5cbiAgICAgICAgPENoZXZyb25SaWdodCBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgPC9CdXR0b24+XG4gICAgPC9uYXY+XG4gIClcbn1cbiJdfQ==