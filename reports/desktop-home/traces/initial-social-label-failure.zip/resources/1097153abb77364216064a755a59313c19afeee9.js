import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=22c23eb4";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=22c23eb4";
// node_modules/@base-ui/utils/safeReact.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* A clone of the React namespace for reading APIs that may be missing in older
* supported React versions. Bundlers can rewrite direct `React.someNewApi`
* reads into named imports, which breaks React 17. Reading from this cloned
* object keeps those lookups optional.
*
* @see https://github.com/mui/material-ui/issues/41190#issuecomment-2040873379
*/
var SafeReact = { ...import_react };
// node_modules/@base-ui/utils/useRefWithInit.mjs
var UNINITIALIZED = {};
/**
* A React.useRef() that is initialized with a function. Note that it accepts an optional
* initialization argument, so the initialization function doesn't need to be an inline closure.
*
* @usage
*   const ref = useRefWithInit(sortColumns, columns)
*/
function useRefWithInit(init, initArg) {
	const ref = import_react.useRef(UNINITIALIZED);
	if (ref.current === UNINITIALIZED) ref.current = init(initArg);
	return ref;
}
// node_modules/@base-ui/utils/useStableCallback.mjs
var useInsertionEffect = SafeReact.useInsertionEffect;
var useSafeInsertionEffect = useInsertionEffect && useInsertionEffect !== SafeReact.useLayoutEffect ? useInsertionEffect : (fn) => fn();
/**
* Stabilizes the function passed so it's always the same between renders.
*
* The function becomes non-reactive to any values it captures.
* It can safely be passed as a dependency of `React.useMemo` and `React.useEffect` without re-triggering them if its captured values change.
*
* The function must only be called inside effects and event handlers, never during render (which throws an error).
*
* This hook is a more permissive version of React 19.2's `React.useEffectEvent` in that it can be passed through contexts and called in event handler props, not just effects.
*/
function useStableCallback(callback) {
	const stable = useRefWithInit(createStableCallback).current;
	stable.next = callback;
	useSafeInsertionEffect(stable.effect);
	return stable.trampoline;
}
function createStableCallback() {
	const stable = {
		next: void 0,
		callback: assertNotCalled,
		trampoline: (...args) => stable.callback?.(...args),
		effect: () => {
			stable.callback = stable.next;
		}
	};
	return stable;
}
function assertNotCalled() {
	throw new Error("Base UI: Cannot call an event handler while rendering.");
}
// node_modules/@base-ui/utils/createLogOnce.mjs
var loggedMessages = /* @__PURE__ */ new Set();
/** Creates a dev-only logger that writes each unique message to `console[severity]` once. */
function createLogOnce(severity, prefix) {
	return function logOnce(...messages) {
		{
			const message = messages.join(" ");
			const output = prefix ? `${prefix}: ${message}` : message;
			const key = `${severity}:${output}`;
			if (!loggedMessages.has(key)) {
				loggedMessages.add(key);
				if (severity === "warn") console.warn(output);
				else console.error(output);
			}
		}
	};
}
// node_modules/@base-ui/utils/useIsoLayoutEffect.mjs
var noop = () => {};
var useIsoLayoutEffect = typeof document !== "undefined" ? import_react.useLayoutEffect : noop;
// node_modules/@base-ui/utils/mergeObjects.mjs
function mergeObjects(a, b) {
	if (a && !b) return a;
	if (!a && b) return b;
	if (a || b) return {
		...a,
		...b
	};
}
// node_modules/@base-ui/react/merge-props/mergeProps.mjs
var EMPTY_PROPS = {};
/**
* Merges multiple sets of React props. It follows the Object.assign pattern where the rightmost object's fields overwrite
* the conflicting ones from others. This doesn't apply to event handlers, `className` and `style` props.
*
* Event handlers are merged and called in right-to-left order (rightmost handler executes first, leftmost last).
* For React synthetic events, the rightmost handler can prevent prior (left-positioned) handlers from executing
* by calling `event.preventBaseUIHandler()`. For non-synthetic events (custom events with primitive/object values),
* all handlers always execute without prevention capability.
*
* The `className` prop is merged by concatenating classes in right-to-left order (rightmost class appears first in the string).
* The `style` prop is merged with rightmost styles overwriting the prior ones.
*
* Props can either be provided as objects or as functions that take the previous props as an argument.
* The function will receive the merged props up to that point (going from left to right):
* so in the case of `(obj1, obj2, fn, obj3)`, `fn` will receive the merged props of `obj1` and `obj2`.
* The function is responsible for chaining event handlers if needed (that is, we don't run the merge logic).
*
* Event handlers returned by the functions are not automatically prevented when `preventBaseUIHandler` is called.
* They must check `event.baseUIHandlerPrevented` themselves and bail out if it's true.
*
* @important **`ref` is not merged.**
* @param a Props object to merge.
* @param b Props object to merge. The function will overwrite conflicting props from `a`.
* @param c Props object to merge. The function will overwrite conflicting props from previous parameters.
* @param d Props object to merge. The function will overwrite conflicting props from previous parameters.
* @param e Props object to merge. The function will overwrite conflicting props from previous parameters.
* @returns The merged props.
* @public
*/
function mergeProps(a, b, c, d, e) {
	if (!c && !d && !e && !a) return createInitialMergedProps(b);
	let merged = createInitialMergedProps(a);
	if (b) merged = mergeInto(merged, b);
	if (c) merged = mergeInto(merged, c);
	if (d) merged = mergeInto(merged, d);
	if (e) merged = mergeInto(merged, e);
	return merged;
}
/**
* Merges an arbitrary number of React props using the same logic as {@link mergeProps}.
* This function accepts an array of props instead of individual arguments.
*
* This has slightly lower performance than {@link mergeProps} due to accepting an array
* instead of a fixed number of arguments. Prefer {@link mergeProps} when merging 5 or
* fewer prop sets for better performance.
*
* @param props Array of props to merge.
* @returns The merged props.
* @see mergeProps
* @public
*/
function mergePropsN(props) {
	if (props.length === 0) return EMPTY_PROPS;
	if (props.length === 1) return createInitialMergedProps(props[0]);
	let merged = createInitialMergedProps(props[0]);
	for (let i = 1; i < props.length; i += 1) merged = mergeInto(merged, props[i]);
	return merged;
}
function createInitialMergedProps(inputProps) {
	if (isPropsGetter(inputProps)) return { ...inputProps(EMPTY_PROPS) };
	return copyInitialProps(inputProps);
}
function mergeInto(merged, inputProps) {
	if (isPropsGetter(inputProps)) return inputProps(merged);
	return mutablyMergeInto(merged, inputProps);
}
function copyInitialProps(inputProps) {
	const copiedProps = { ...inputProps };
	for (const propName in copiedProps) {
		const propValue = copiedProps[propName];
		if (isEventHandler(propName, propValue)) copiedProps[propName] = wrapEventHandler(propValue);
	}
	return copiedProps;
}
/**
* Merges two sets of props. In case of conflicts, the external props take precedence.
*/
function mutablyMergeInto(mergedProps, externalProps) {
	if (!externalProps) return mergedProps;
	for (const propName in externalProps) {
		const externalPropValue = externalProps[propName];
		switch (propName) {
			case "style":
				mergedProps[propName] = mergeObjects(mergedProps.style, externalPropValue);
				break;
			case "className":
				mergedProps[propName] = mergeClassNames(mergedProps.className, externalPropValue);
				break;
			default: if (isEventHandler(propName, externalPropValue)) mergedProps[propName] = mergeEventHandlers(mergedProps[propName], externalPropValue);
			else mergedProps[propName] = externalPropValue;
		}
	}
	return mergedProps;
}
function isEventHandler(key, value) {
	const code0 = key.charCodeAt(0);
	const code1 = key.charCodeAt(1);
	const code2 = key.charCodeAt(2);
	return code0 === 111 && code1 === 110 && code2 >= 65 && code2 <= 90 && (typeof value === "function" || typeof value === "undefined");
}
function isPropsGetter(inputProps) {
	return typeof inputProps === "function";
}
function mergeEventHandlers(ourHandler, theirHandler) {
	if (!theirHandler) return ourHandler;
	if (!ourHandler) return wrapEventHandler(theirHandler);
	return (...args) => {
		const event = args[0];
		if (isSyntheticEvent(event)) {
			const baseUIEvent = event;
			makeEventPreventable(baseUIEvent);
			const result = theirHandler(...args);
			if (!baseUIEvent.baseUIHandlerPrevented) ourHandler?.(...args);
			return result;
		}
		const result = theirHandler(...args);
		ourHandler?.(...args);
		return result;
	};
}
function wrapEventHandler(handler) {
	if (!handler) return handler;
	return (...args) => {
		const event = args[0];
		if (isSyntheticEvent(event)) makeEventPreventable(event);
		return handler(...args);
	};
}
function makeEventPreventable(event) {
	event.preventBaseUIHandler = () => {
		event.baseUIHandlerPrevented = true;
	};
	return event;
}
function mergeClassNames(ourClassName, theirClassName) {
	if (theirClassName) {
		if (ourClassName) return theirClassName + " " + ourClassName;
		return theirClassName;
	}
	return ourClassName;
}
function isSyntheticEvent(event) {
	return event != null && typeof event === "object" && "nativeEvent" in event;
}
// node_modules/@base-ui/utils/useMergedRefs.mjs
/**
* Merges refs into a single memoized callback ref or `null`.
* This makes sure multiple refs are updated together and have the same value.
*
* This function accepts up to four refs. If you need to merge more, or have an unspecified number of refs to merge,
* use `useMergedRefsN` instead.
*/
function useMergedRefs(a, b, c, d) {
	const forkRef = useRefWithInit(createForkRef).current;
	if (didChange(forkRef, a, b, c, d)) update(forkRef, [
		a,
		b,
		c,
		d
	]);
	return forkRef.callback;
}
/**
* Merges an array of refs into a single memoized callback ref or `null`.
*
* If you need to merge a fixed number (up to four) of refs, use `useMergedRefs` instead for better performance.
*/
function useMergedRefsN(refs) {
	const forkRef = useRefWithInit(createForkRef).current;
	if (didChangeN(forkRef, refs)) update(forkRef, refs);
	return forkRef.callback;
}
function createForkRef() {
	return {
		callback: null,
		cleanup: null,
		refs: []
	};
}
function didChange(forkRef, a, b, c, d) {
	return forkRef.refs[0] !== a || forkRef.refs[1] !== b || forkRef.refs[2] !== c || forkRef.refs[3] !== d;
}
function didChangeN(forkRef, newRefs) {
	return forkRef.refs.length !== newRefs.length || forkRef.refs.some((ref, index) => ref !== newRefs[index]);
}
function update(forkRef, refs) {
	forkRef.refs = refs;
	if (refs.every((ref) => ref == null)) {
		forkRef.callback = null;
		return;
	}
	forkRef.callback = (instance) => {
		if (forkRef.cleanup) {
			forkRef.cleanup();
			forkRef.cleanup = null;
		}
		if (instance != null) {
			const cleanupCallbacks = Array(refs.length).fill(null);
			for (let i = 0; i < refs.length; i += 1) {
				const ref = refs[i];
				if (ref == null) continue;
				switch (typeof ref) {
					case "function": {
						const refCleanup = ref(instance);
						if (typeof refCleanup === "function") cleanupCallbacks[i] = refCleanup;
						break;
					}
					case "object": ref.current = instance;
				}
			}
			forkRef.cleanup = () => {
				for (let i = 0; i < refs.length; i += 1) {
					const ref = refs[i];
					if (ref == null) continue;
					switch (typeof ref) {
						case "function": {
							const cleanupCallback = cleanupCallbacks[i];
							if (typeof cleanupCallback === "function") cleanupCallback();
							else ref(null);
							break;
						}
						case "object": ref.current = null;
					}
				}
			};
		}
	};
}
// node_modules/@base-ui/utils/reactVersion.mjs
var majorVersion = parseInt("19.3.1", 10);
function isReactVersionAtLeast(reactVersionToCheck) {
	return majorVersion >= reactVersionToCheck;
}
// node_modules/@base-ui/utils/getReactElementRef.mjs
/**
* Extracts the `ref` from a React element, handling different React versions.
*/
function getReactElementRef(element) {
	if (!/*#__PURE__*/ import_react.isValidElement(element)) return null;
	const reactElement = element;
	const propsWithRef = reactElement.props;
	return (isReactVersionAtLeast(19) ? propsWithRef?.ref : reactElement.ref) ?? null;
}
// node_modules/@base-ui/utils/warn.mjs
var warn = createLogOnce("warn", "Base UI");
// node_modules/@base-ui/utils/empty.mjs
function NOOP() {}
var EMPTY_ARRAY = Object.freeze([]);
var EMPTY_OBJECT = Object.freeze({});
// node_modules/@base-ui/react/internals/getStateAttributesProps.mjs
function getStateAttributesProps(state, customMapping) {
	const props = {};
	for (const key in state) {
		const value = state[key];
		if (customMapping?.hasOwnProperty(key)) {
			const customProps = customMapping[key](value);
			if (customProps != null) Object.assign(props, customProps);
			continue;
		}
		if (value === true) props[`data-${key.toLowerCase()}`] = "";
		else if (value) props[`data-${key.toLowerCase()}`] = value.toString();
	}
	return props;
}
// node_modules/@base-ui/react/utils/resolveClassName.mjs
/**
* If the provided className is a string, it will be returned as is.
* Otherwise, the function will call the className function with the state as the first argument.
*
* @param className
* @param state
*/
function resolveClassName(className, state) {
	return typeof className === "function" ? className(state) : className;
}
// node_modules/@base-ui/react/utils/resolveStyle.mjs
/**
* If the provided style is an object, it will be returned as is.
* Otherwise, the function will call the style function with the state as the first argument.
*
* @param style
* @param state
*/
function resolveStyle(style, state) {
	return typeof style === "function" ? style(state) : style;
}
// node_modules/@base-ui/react/internals/useRenderElement.mjs
/**
* Renders a Base UI element.
*
* @param element The default HTML element to render. Can be overridden by the `render` prop.
* @param componentProps An object containing the `render` and `className` props to be used for element customization. Other props are ignored.
* @param params Additional parameters for rendering the element.
*/
function useRenderElement(element, componentProps, params = {}) {
	let renderProp = componentProps.render;
	if (params.enabled !== false) renderProp = unwrapLazyRenderProp(renderProp);
	const outProps = useRenderElementProps(componentProps, params, renderProp);
	if (params.enabled === false) return null;
	const state = params.state ?? EMPTY_OBJECT;
	return evaluateRenderProp(element, renderProp, outProps, state);
}
/**
* Computes render element final props.
*/
function useRenderElementProps(componentProps, params, renderProp) {
	const { className: classNameProp, style: styleProp } = componentProps;
	const { state = EMPTY_OBJECT, ref, props, stateAttributesMapping, enabled = true } = params;
	const className = enabled ? resolveClassName(classNameProp, state) : void 0;
	const style = enabled ? resolveStyle(styleProp, state) : void 0;
	const stateProps = enabled ? getStateAttributesProps(state, stateAttributesMapping) : EMPTY_OBJECT;
	const resolvedProps = enabled && props ? resolveRenderFunctionProps(props) : void 0;
	const outProps = enabled ? mergeObjects(stateProps, resolvedProps) ?? {} : EMPTY_OBJECT;
	if (typeof document !== "undefined") {
		if (!enabled) useMergedRefs(null, null);
		else if (Array.isArray(ref)) outProps.ref = useMergedRefsN([
			outProps.ref,
			getReactElementRef(renderProp),
			...ref
		]);
		else outProps.ref = useMergedRefs(outProps.ref, getReactElementRef(renderProp), ref);
	}
	if (!enabled) return EMPTY_OBJECT;
	if (className !== void 0) outProps.className = mergeClassNames(outProps.className, className);
	if (style !== void 0) outProps.style = mergeObjects(outProps.style, style);
	return outProps;
}
function resolveRenderFunctionProps(props) {
	if (Array.isArray(props)) return mergePropsN(props);
	return mergeProps(void 0, props);
}
var REACT_LAZY_TYPE = Symbol.for("react.lazy");
var COMPONENT_IDENTIFIER_PATTERN = /^[A-Z][A-Za-z0-9$]*$/;
var LOWERCASE_CHARACTER_PATTERN = /[a-z]/;
function unwrapLazyRenderProp(render) {
	if (render?.$$typeof !== REACT_LAZY_TYPE) return render;
	const unwrapped = import_react.Children.toArray(render)[0];
	return /*#__PURE__*/ import_react.isValidElement(unwrapped) ? unwrapped : render;
}
function evaluateRenderProp(element, render, props, state) {
	if (render) {
		if (typeof render === "function") {
			warnIfRenderPropLooksLikeComponent(render);
			return render(props, state);
		}
		const mergedProps = mergeProps(props, render.props);
		mergedProps.ref = props.ref;
		if (!/*#__PURE__*/ import_react.isValidElement(render)) throw new Error([
			"Base UI: The `render` prop was provided an invalid React element as `React.isValidElement(render)` is `false`.",
			"A valid React element must be provided to the `render` prop because it is cloned with props to replace the default element.",
			"https://base-ui.com/r/invalid-render-prop"
		].join("\n"));
		return /*#__PURE__*/ import_react.cloneElement(render, mergedProps);
	}
	return renderTag(element, props);
}
function warnIfRenderPropLooksLikeComponent(renderFn) {
	const functionName = renderFn.name;
	if (functionName.length === 0) return;
	if (!COMPONENT_IDENTIFIER_PATTERN.test(functionName)) return;
	if (!LOWERCASE_CHARACTER_PATTERN.test(functionName)) return;
	warn(`The \`render\` prop received a function named \`${functionName}\` that starts with an uppercase letter.`, "This usually means a React component was passed directly as `render={Component}`.", "Base UI calls `render` as a plain function, which can break the Rules of Hooks during reconciliation.", "If this is an intentional render callback, rename it to start with a lowercase letter.", "Use `render={<Component />}` or `render={(props) => <Component {...props} />}` instead.", "https://base-ui.com/r/invalid-render-prop");
}
function renderTag(Tag, props) {
	if (Tag === "button") return /*#__PURE__*/ (0, import_react.createElement)("button", {
		type: "button",
		...props,
		key: props.key
	});
	if (Tag === "img") return /*#__PURE__*/ (0, import_react.createElement)("img", {
		alt: "",
		...props,
		key: props.key
	});
	return /*#__PURE__*/ import_react.createElement(Tag, props);
}
export { isReactVersionAtLeast as a, mergeProps as c, useStableCallback as d, useRefWithInit as f, NOOP as i, useIsoLayoutEffect as l, EMPTY_ARRAY as n, useMergedRefs as o, SafeReact as p, EMPTY_OBJECT as r, makeEventPreventable as s, useRenderElement as t, createLogOnce as u };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlUmVuZGVyRWxlbWVudC1DWlFGZzl1MC5qcyIsIm5hbWVzIjpbIlJlYWN0Il0sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvdXRpbHMvc2FmZVJlYWN0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL2NyZWF0ZUxvZ09uY2UubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL21lcmdlT2JqZWN0cy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZXJnZS1wcm9wcy9tZXJnZVByb3BzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZS5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy91c2VNZXJnZWRSZWZzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3JlYWN0VmVyc2lvbi5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9nZXRSZWFjdEVsZW1lbnRSZWYubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvd2Fybi5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9lbXB0eS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvZ2V0U3RhdGVBdHRyaWJ1dGVzUHJvcHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcmVzb2x2ZUNsYXNzTmFtZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9yZXNvbHZlU3R5bGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuLyoqXG4gKiBBIGNsb25lIG9mIHRoZSBSZWFjdCBuYW1lc3BhY2UgZm9yIHJlYWRpbmcgQVBJcyB0aGF0IG1heSBiZSBtaXNzaW5nIGluIG9sZGVyXG4gKiBzdXBwb3J0ZWQgUmVhY3QgdmVyc2lvbnMuIEJ1bmRsZXJzIGNhbiByZXdyaXRlIGRpcmVjdCBgUmVhY3Quc29tZU5ld0FwaWBcbiAqIHJlYWRzIGludG8gbmFtZWQgaW1wb3J0cywgd2hpY2ggYnJlYWtzIFJlYWN0IDE3LiBSZWFkaW5nIGZyb20gdGhpcyBjbG9uZWRcbiAqIG9iamVjdCBrZWVwcyB0aG9zZSBsb29rdXBzIG9wdGlvbmFsLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL211aS9tYXRlcmlhbC11aS9pc3N1ZXMvNDExOTAjaXNzdWVjb21tZW50LTIwNDA4NzMzNzlcbiAqL1xuZXhwb3J0IGNvbnN0IFNhZmVSZWFjdCA9IHtcbiAgLi4uUmVhY3Rcbn07IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5jb25zdCBVTklOSVRJQUxJWkVEID0ge307XG5cbi8qKlxuICogQSBSZWFjdC51c2VSZWYoKSB0aGF0IGlzIGluaXRpYWxpemVkIHdpdGggYSBmdW5jdGlvbi4gTm90ZSB0aGF0IGl0IGFjY2VwdHMgYW4gb3B0aW9uYWxcbiAqIGluaXRpYWxpemF0aW9uIGFyZ3VtZW50LCBzbyB0aGUgaW5pdGlhbGl6YXRpb24gZnVuY3Rpb24gZG9lc24ndCBuZWVkIHRvIGJlIGFuIGlubGluZSBjbG9zdXJlLlxuICpcbiAqIEB1c2FnZVxuICogICBjb25zdCByZWYgPSB1c2VSZWZXaXRoSW5pdChzb3J0Q29sdW1ucywgY29sdW1ucylcbiAqL1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlUmVmV2l0aEluaXQoaW5pdCwgaW5pdEFyZykge1xuICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYoVU5JTklUSUFMSVpFRCk7XG4gIGlmIChyZWYuY3VycmVudCA9PT0gVU5JTklUSUFMSVpFRCkge1xuICAgIHJlZi5jdXJyZW50ID0gaW5pdChpbml0QXJnKTtcbiAgfVxuICByZXR1cm4gcmVmO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgU2FmZVJlYWN0IH0gZnJvbSBcIi4vc2FmZVJlYWN0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tIFwiLi91c2VSZWZXaXRoSW5pdC5tanNcIjtcbmNvbnN0IHVzZUluc2VydGlvbkVmZmVjdCA9IFNhZmVSZWFjdC51c2VJbnNlcnRpb25FZmZlY3Q7XG5jb25zdCB1c2VTYWZlSW5zZXJ0aW9uRWZmZWN0ID1cbi8vIFJlYWN0IDE3IGRvZXNuJ3QgaGF2ZSB1c2VJbnNlcnRpb25FZmZlY3QuXG51c2VJbnNlcnRpb25FZmZlY3QgJiZcbi8vIFByZWFjdCByZXBsYWNlcyB1c2VJbnNlcnRpb25FZmZlY3Qgd2l0aCB1c2VMYXlvdXRFZmZlY3QgYW5kIGZpcmVzIHRvbyBsYXRlLlxudXNlSW5zZXJ0aW9uRWZmZWN0ICE9PSBTYWZlUmVhY3QudXNlTGF5b3V0RWZmZWN0ID8gdXNlSW5zZXJ0aW9uRWZmZWN0IDogZm4gPT4gZm4oKTtcbi8qKlxuICogU3RhYmlsaXplcyB0aGUgZnVuY3Rpb24gcGFzc2VkIHNvIGl0J3MgYWx3YXlzIHRoZSBzYW1lIGJldHdlZW4gcmVuZGVycy5cbiAqXG4gKiBUaGUgZnVuY3Rpb24gYmVjb21lcyBub24tcmVhY3RpdmUgdG8gYW55IHZhbHVlcyBpdCBjYXB0dXJlcy5cbiAqIEl0IGNhbiBzYWZlbHkgYmUgcGFzc2VkIGFzIGEgZGVwZW5kZW5jeSBvZiBgUmVhY3QudXNlTWVtb2AgYW5kIGBSZWFjdC51c2VFZmZlY3RgIHdpdGhvdXQgcmUtdHJpZ2dlcmluZyB0aGVtIGlmIGl0cyBjYXB0dXJlZCB2YWx1ZXMgY2hhbmdlLlxuICpcbiAqIFRoZSBmdW5jdGlvbiBtdXN0IG9ubHkgYmUgY2FsbGVkIGluc2lkZSBlZmZlY3RzIGFuZCBldmVudCBoYW5kbGVycywgbmV2ZXIgZHVyaW5nIHJlbmRlciAod2hpY2ggdGhyb3dzIGFuIGVycm9yKS5cbiAqXG4gKiBUaGlzIGhvb2sgaXMgYSBtb3JlIHBlcm1pc3NpdmUgdmVyc2lvbiBvZiBSZWFjdCAxOS4yJ3MgYFJlYWN0LnVzZUVmZmVjdEV2ZW50YCBpbiB0aGF0IGl0IGNhbiBiZSBwYXNzZWQgdGhyb3VnaCBjb250ZXh0cyBhbmQgY2FsbGVkIGluIGV2ZW50IGhhbmRsZXIgcHJvcHMsIG5vdCBqdXN0IGVmZmVjdHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VTdGFibGVDYWxsYmFjayhjYWxsYmFjaykge1xuICBjb25zdCBzdGFibGUgPSB1c2VSZWZXaXRoSW5pdChjcmVhdGVTdGFibGVDYWxsYmFjaykuY3VycmVudDtcbiAgc3RhYmxlLm5leHQgPSBjYWxsYmFjaztcbiAgdXNlU2FmZUluc2VydGlvbkVmZmVjdChzdGFibGUuZWZmZWN0KTtcbiAgcmV0dXJuIHN0YWJsZS50cmFtcG9saW5lO1xufVxuZnVuY3Rpb24gY3JlYXRlU3RhYmxlQ2FsbGJhY2soKSB7XG4gIGNvbnN0IHN0YWJsZSA9IHtcbiAgICBuZXh0OiB1bmRlZmluZWQsXG4gICAgY2FsbGJhY2s6IGFzc2VydE5vdENhbGxlZCxcbiAgICB0cmFtcG9saW5lOiAoLi4uYXJncykgPT4gc3RhYmxlLmNhbGxiYWNrPy4oLi4uYXJncyksXG4gICAgZWZmZWN0OiAoKSA9PiB7XG4gICAgICBzdGFibGUuY2FsbGJhY2sgPSBzdGFibGUubmV4dDtcbiAgICB9XG4gIH07XG4gIHJldHVybiBzdGFibGU7XG59XG5mdW5jdGlvbiBhc3NlcnROb3RDYWxsZWQoKSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgLy8gVE9ETzogZml4IG11aS9uby1ndWFyZGVkLXRocm93XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG11aS9uby1ndWFyZGVkLXRocm93XG4gICAgdGhyb3cgLyogbWluaWZ5LWVycm9yLWRpc2FibGVkICovbmV3IEVycm9yKCdCYXNlIFVJOiBDYW5ub3QgY2FsbCBhbiBldmVudCBoYW5kbGVyIHdoaWxlIHJlbmRlcmluZy4nKTtcbiAgfVxufSIsImxldCBsb2dnZWRNZXNzYWdlcztcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIGxvZ2dlZE1lc3NhZ2VzID0gbmV3IFNldCgpO1xufVxuXG4vKiogQ3JlYXRlcyBhIGRldi1vbmx5IGxvZ2dlciB0aGF0IHdyaXRlcyBlYWNoIHVuaXF1ZSBtZXNzYWdlIHRvIGBjb25zb2xlW3NldmVyaXR5XWAgb25jZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVMb2dPbmNlKHNldmVyaXR5LCBwcmVmaXgpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGxvZ09uY2UoLi4ubWVzc2FnZXMpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IG1lc3NhZ2VzLmpvaW4oJyAnKTtcbiAgICAgIGNvbnN0IG91dHB1dCA9IHByZWZpeCA/IGAke3ByZWZpeH06ICR7bWVzc2FnZX1gIDogbWVzc2FnZTtcbiAgICAgIGNvbnN0IGtleSA9IGAke3NldmVyaXR5fToke291dHB1dH1gO1xuICAgICAgaWYgKCFsb2dnZWRNZXNzYWdlcy5oYXMoa2V5KSkge1xuICAgICAgICBsb2dnZWRNZXNzYWdlcy5hZGQoa2V5KTtcbiAgICAgICAgaWYgKHNldmVyaXR5ID09PSAnd2FybicpIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4ob3V0cHV0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gcmVzZXQoKSB7XG4gIGxvZ2dlZE1lc3NhZ2VzPy5jbGVhcigpO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuY29uc3Qgbm9vcCA9ICgpID0+IHt9O1xuZXhwb3J0IGNvbnN0IHVzZUlzb0xheW91dEVmZmVjdCA9IHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgPyBSZWFjdC51c2VMYXlvdXRFZmZlY3QgOiBub29wOyIsImV4cG9ydCBmdW5jdGlvbiBtZXJnZU9iamVjdHMoYSwgYikge1xuICBpZiAoYSAmJiAhYikge1xuICAgIHJldHVybiBhO1xuICB9XG4gIGlmICghYSAmJiBiKSB7XG4gICAgcmV0dXJuIGI7XG4gIH1cbiAgaWYgKGEgfHwgYikge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5hLFxuICAgICAgLi4uYlxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn0iLCJpbXBvcnQgeyBtZXJnZU9iamVjdHMgfSBmcm9tICdAYmFzZS11aS91dGlscy9tZXJnZU9iamVjdHMnO1xuY29uc3QgRU1QVFlfUFJPUFMgPSB7fTtcblxuLyogZXNsaW50LWRpc2FibGUgaWQtZGVueWxpc3QgKi9cbi8qKlxuICogTWVyZ2VzIG11bHRpcGxlIHNldHMgb2YgUmVhY3QgcHJvcHMuIEl0IGZvbGxvd3MgdGhlIE9iamVjdC5hc3NpZ24gcGF0dGVybiB3aGVyZSB0aGUgcmlnaHRtb3N0IG9iamVjdCdzIGZpZWxkcyBvdmVyd3JpdGVcbiAqIHRoZSBjb25mbGljdGluZyBvbmVzIGZyb20gb3RoZXJzLiBUaGlzIGRvZXNuJ3QgYXBwbHkgdG8gZXZlbnQgaGFuZGxlcnMsIGBjbGFzc05hbWVgIGFuZCBgc3R5bGVgIHByb3BzLlxuICpcbiAqIEV2ZW50IGhhbmRsZXJzIGFyZSBtZXJnZWQgYW5kIGNhbGxlZCBpbiByaWdodC10by1sZWZ0IG9yZGVyIChyaWdodG1vc3QgaGFuZGxlciBleGVjdXRlcyBmaXJzdCwgbGVmdG1vc3QgbGFzdCkuXG4gKiBGb3IgUmVhY3Qgc3ludGhldGljIGV2ZW50cywgdGhlIHJpZ2h0bW9zdCBoYW5kbGVyIGNhbiBwcmV2ZW50IHByaW9yIChsZWZ0LXBvc2l0aW9uZWQpIGhhbmRsZXJzIGZyb20gZXhlY3V0aW5nXG4gKiBieSBjYWxsaW5nIGBldmVudC5wcmV2ZW50QmFzZVVJSGFuZGxlcigpYC4gRm9yIG5vbi1zeW50aGV0aWMgZXZlbnRzIChjdXN0b20gZXZlbnRzIHdpdGggcHJpbWl0aXZlL29iamVjdCB2YWx1ZXMpLFxuICogYWxsIGhhbmRsZXJzIGFsd2F5cyBleGVjdXRlIHdpdGhvdXQgcHJldmVudGlvbiBjYXBhYmlsaXR5LlxuICpcbiAqIFRoZSBgY2xhc3NOYW1lYCBwcm9wIGlzIG1lcmdlZCBieSBjb25jYXRlbmF0aW5nIGNsYXNzZXMgaW4gcmlnaHQtdG8tbGVmdCBvcmRlciAocmlnaHRtb3N0IGNsYXNzIGFwcGVhcnMgZmlyc3QgaW4gdGhlIHN0cmluZykuXG4gKiBUaGUgYHN0eWxlYCBwcm9wIGlzIG1lcmdlZCB3aXRoIHJpZ2h0bW9zdCBzdHlsZXMgb3ZlcndyaXRpbmcgdGhlIHByaW9yIG9uZXMuXG4gKlxuICogUHJvcHMgY2FuIGVpdGhlciBiZSBwcm92aWRlZCBhcyBvYmplY3RzIG9yIGFzIGZ1bmN0aW9ucyB0aGF0IHRha2UgdGhlIHByZXZpb3VzIHByb3BzIGFzIGFuIGFyZ3VtZW50LlxuICogVGhlIGZ1bmN0aW9uIHdpbGwgcmVjZWl2ZSB0aGUgbWVyZ2VkIHByb3BzIHVwIHRvIHRoYXQgcG9pbnQgKGdvaW5nIGZyb20gbGVmdCB0byByaWdodCk6XG4gKiBzbyBpbiB0aGUgY2FzZSBvZiBgKG9iajEsIG9iajIsIGZuLCBvYmozKWAsIGBmbmAgd2lsbCByZWNlaXZlIHRoZSBtZXJnZWQgcHJvcHMgb2YgYG9iajFgIGFuZCBgb2JqMmAuXG4gKiBUaGUgZnVuY3Rpb24gaXMgcmVzcG9uc2libGUgZm9yIGNoYWluaW5nIGV2ZW50IGhhbmRsZXJzIGlmIG5lZWRlZCAodGhhdCBpcywgd2UgZG9uJ3QgcnVuIHRoZSBtZXJnZSBsb2dpYykuXG4gKlxuICogRXZlbnQgaGFuZGxlcnMgcmV0dXJuZWQgYnkgdGhlIGZ1bmN0aW9ucyBhcmUgbm90IGF1dG9tYXRpY2FsbHkgcHJldmVudGVkIHdoZW4gYHByZXZlbnRCYXNlVUlIYW5kbGVyYCBpcyBjYWxsZWQuXG4gKiBUaGV5IG11c3QgY2hlY2sgYGV2ZW50LmJhc2VVSUhhbmRsZXJQcmV2ZW50ZWRgIHRoZW1zZWx2ZXMgYW5kIGJhaWwgb3V0IGlmIGl0J3MgdHJ1ZS5cbiAqXG4gKiBAaW1wb3J0YW50ICoqYHJlZmAgaXMgbm90IG1lcmdlZC4qKlxuICogQHBhcmFtIGEgUHJvcHMgb2JqZWN0IHRvIG1lcmdlLlxuICogQHBhcmFtIGIgUHJvcHMgb2JqZWN0IHRvIG1lcmdlLiBUaGUgZnVuY3Rpb24gd2lsbCBvdmVyd3JpdGUgY29uZmxpY3RpbmcgcHJvcHMgZnJvbSBgYWAuXG4gKiBAcGFyYW0gYyBQcm9wcyBvYmplY3QgdG8gbWVyZ2UuIFRoZSBmdW5jdGlvbiB3aWxsIG92ZXJ3cml0ZSBjb25mbGljdGluZyBwcm9wcyBmcm9tIHByZXZpb3VzIHBhcmFtZXRlcnMuXG4gKiBAcGFyYW0gZCBQcm9wcyBvYmplY3QgdG8gbWVyZ2UuIFRoZSBmdW5jdGlvbiB3aWxsIG92ZXJ3cml0ZSBjb25mbGljdGluZyBwcm9wcyBmcm9tIHByZXZpb3VzIHBhcmFtZXRlcnMuXG4gKiBAcGFyYW0gZSBQcm9wcyBvYmplY3QgdG8gbWVyZ2UuIFRoZSBmdW5jdGlvbiB3aWxsIG92ZXJ3cml0ZSBjb25mbGljdGluZyBwcm9wcyBmcm9tIHByZXZpb3VzIHBhcmFtZXRlcnMuXG4gKiBAcmV0dXJucyBUaGUgbWVyZ2VkIHByb3BzLlxuICogQHB1YmxpY1xuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBtZXJnZVByb3BzKGEsIGIsIGMsIGQsIGUpIHtcbiAgaWYgKCFjICYmICFkICYmICFlICYmICFhKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUluaXRpYWxNZXJnZWRQcm9wcyhiKTtcbiAgfVxuXG4gIC8vIFdlIG5lZWQgdG8gbXV0YWJseSBvd24gYG1lcmdlZGAuXG4gIGxldCBtZXJnZWQgPSBjcmVhdGVJbml0aWFsTWVyZ2VkUHJvcHMoYSk7XG4gIGlmIChiKSB7XG4gICAgbWVyZ2VkID0gbWVyZ2VJbnRvKG1lcmdlZCwgYik7XG4gIH1cbiAgaWYgKGMpIHtcbiAgICBtZXJnZWQgPSBtZXJnZUludG8obWVyZ2VkLCBjKTtcbiAgfVxuICBpZiAoZCkge1xuICAgIG1lcmdlZCA9IG1lcmdlSW50byhtZXJnZWQsIGQpO1xuICB9XG4gIGlmIChlKSB7XG4gICAgbWVyZ2VkID0gbWVyZ2VJbnRvKG1lcmdlZCwgZSk7XG4gIH1cbiAgcmV0dXJuIG1lcmdlZDtcbn1cbi8qIGVzbGludC1lbmFibGUgaWQtZGVueWxpc3QgKi9cblxuLyoqXG4gKiBNZXJnZXMgYW4gYXJiaXRyYXJ5IG51bWJlciBvZiBSZWFjdCBwcm9wcyB1c2luZyB0aGUgc2FtZSBsb2dpYyBhcyB7QGxpbmsgbWVyZ2VQcm9wc30uXG4gKiBUaGlzIGZ1bmN0aW9uIGFjY2VwdHMgYW4gYXJyYXkgb2YgcHJvcHMgaW5zdGVhZCBvZiBpbmRpdmlkdWFsIGFyZ3VtZW50cy5cbiAqXG4gKiBUaGlzIGhhcyBzbGlnaHRseSBsb3dlciBwZXJmb3JtYW5jZSB0aGFuIHtAbGluayBtZXJnZVByb3BzfSBkdWUgdG8gYWNjZXB0aW5nIGFuIGFycmF5XG4gKiBpbnN0ZWFkIG9mIGEgZml4ZWQgbnVtYmVyIG9mIGFyZ3VtZW50cy4gUHJlZmVyIHtAbGluayBtZXJnZVByb3BzfSB3aGVuIG1lcmdpbmcgNSBvclxuICogZmV3ZXIgcHJvcCBzZXRzIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2UuXG4gKlxuICogQHBhcmFtIHByb3BzIEFycmF5IG9mIHByb3BzIHRvIG1lcmdlLlxuICogQHJldHVybnMgVGhlIG1lcmdlZCBwcm9wcy5cbiAqIEBzZWUgbWVyZ2VQcm9wc1xuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VQcm9wc04ocHJvcHMpIHtcbiAgaWYgKHByb3BzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBFTVBUWV9QUk9QUztcbiAgfVxuICBpZiAocHJvcHMubGVuZ3RoID09PSAxKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUluaXRpYWxNZXJnZWRQcm9wcyhwcm9wc1swXSk7XG4gIH1cblxuICAvLyBXZSBuZWVkIHRvIG11dGFibHkgb3duIGBtZXJnZWRgLlxuICBsZXQgbWVyZ2VkID0gY3JlYXRlSW5pdGlhbE1lcmdlZFByb3BzKHByb3BzWzBdKTtcbiAgZm9yIChsZXQgaSA9IDE7IGkgPCBwcm9wcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgIG1lcmdlZCA9IG1lcmdlSW50byhtZXJnZWQsIHByb3BzW2ldKTtcbiAgfVxuICByZXR1cm4gbWVyZ2VkO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5pdGlhbE1lcmdlZFByb3BzKGlucHV0UHJvcHMpIHtcbiAgaWYgKGlzUHJvcHNHZXR0ZXIoaW5wdXRQcm9wcykpIHtcbiAgICAvLyBHZXR0ZXItcmV0dXJuZWQgaGFuZGxlcnMgaW50ZW50aW9uYWxseSBrZWVwIHRoZWlyIGV4aXN0aW5nIHNlbWFudGljcy5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uaW5wdXRQcm9wcyhFTVBUWV9QUk9QUylcbiAgICB9O1xuICB9XG4gIHJldHVybiBjb3B5SW5pdGlhbFByb3BzKGlucHV0UHJvcHMpO1xufVxuZnVuY3Rpb24gbWVyZ2VJbnRvKG1lcmdlZCwgaW5wdXRQcm9wcykge1xuICBpZiAoaXNQcm9wc0dldHRlcihpbnB1dFByb3BzKSkge1xuICAgIHJldHVybiBpbnB1dFByb3BzKG1lcmdlZCk7XG4gIH1cbiAgcmV0dXJuIG11dGFibHlNZXJnZUludG8obWVyZ2VkLCBpbnB1dFByb3BzKTtcbn1cbmZ1bmN0aW9uIGNvcHlJbml0aWFsUHJvcHMoaW5wdXRQcm9wcykge1xuICBjb25zdCBjb3BpZWRQcm9wcyA9IHtcbiAgICAuLi5pbnB1dFByb3BzXG4gIH07XG5cbiAgLy8gYGNvcGllZFByb3BzYCBpcyBvdXIgZnJlc2ggb3duLW9iamVjdCBjb3B5LCBzbyBpdGVyYXRpbmcgd2l0aCBgZm9yLi4uaW5gIGlzIHNhZmUgaGVyZS5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGd1YXJkLWZvci1pblxuICBmb3IgKGNvbnN0IHByb3BOYW1lIGluIGNvcGllZFByb3BzKSB7XG4gICAgY29uc3QgcHJvcFZhbHVlID0gY29waWVkUHJvcHNbcHJvcE5hbWVdO1xuICAgIGlmIChpc0V2ZW50SGFuZGxlcihwcm9wTmFtZSwgcHJvcFZhbHVlKSkge1xuICAgICAgY29waWVkUHJvcHNbcHJvcE5hbWVdID0gd3JhcEV2ZW50SGFuZGxlcihwcm9wVmFsdWUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gY29waWVkUHJvcHM7XG59XG5cbi8qKlxuICogTWVyZ2VzIHR3byBzZXRzIG9mIHByb3BzLiBJbiBjYXNlIG9mIGNvbmZsaWN0cywgdGhlIGV4dGVybmFsIHByb3BzIHRha2UgcHJlY2VkZW5jZS5cbiAqL1xuZnVuY3Rpb24gbXV0YWJseU1lcmdlSW50byhtZXJnZWRQcm9wcywgZXh0ZXJuYWxQcm9wcykge1xuICBpZiAoIWV4dGVybmFsUHJvcHMpIHtcbiAgICByZXR1cm4gbWVyZ2VkUHJvcHM7XG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZ3VhcmQtZm9yLWluXG4gIGZvciAoY29uc3QgcHJvcE5hbWUgaW4gZXh0ZXJuYWxQcm9wcykge1xuICAgIGNvbnN0IGV4dGVybmFsUHJvcFZhbHVlID0gZXh0ZXJuYWxQcm9wc1twcm9wTmFtZV07XG4gICAgc3dpdGNoIChwcm9wTmFtZSkge1xuICAgICAgY2FzZSAnc3R5bGUnOlxuICAgICAgICB7XG4gICAgICAgICAgbWVyZ2VkUHJvcHNbcHJvcE5hbWVdID0gbWVyZ2VPYmplY3RzKG1lcmdlZFByb3BzLnN0eWxlLCBleHRlcm5hbFByb3BWYWx1ZSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIGNhc2UgJ2NsYXNzTmFtZSc6XG4gICAgICAgIHtcbiAgICAgICAgICBtZXJnZWRQcm9wc1twcm9wTmFtZV0gPSBtZXJnZUNsYXNzTmFtZXMobWVyZ2VkUHJvcHMuY2xhc3NOYW1lLCBleHRlcm5hbFByb3BWYWx1ZSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHtcbiAgICAgICAgICBpZiAoaXNFdmVudEhhbmRsZXIocHJvcE5hbWUsIGV4dGVybmFsUHJvcFZhbHVlKSkge1xuICAgICAgICAgICAgbWVyZ2VkUHJvcHNbcHJvcE5hbWVdID0gbWVyZ2VFdmVudEhhbmRsZXJzKG1lcmdlZFByb3BzW3Byb3BOYW1lXSwgZXh0ZXJuYWxQcm9wVmFsdWUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBtZXJnZWRQcm9wc1twcm9wTmFtZV0gPSBleHRlcm5hbFByb3BWYWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG1lcmdlZFByb3BzO1xufVxuZnVuY3Rpb24gaXNFdmVudEhhbmRsZXIoa2V5LCB2YWx1ZSkge1xuICAvLyBUaGlzIGFwcHJvYWNoIGlzIG1vcmUgZWZmaWNpZW50IHRoYW4gdXNpbmcgYSByZWdleC5cbiAgY29uc3QgY29kZTAgPSBrZXkuY2hhckNvZGVBdCgwKTtcbiAgY29uc3QgY29kZTEgPSBrZXkuY2hhckNvZGVBdCgxKTtcbiAgY29uc3QgY29kZTIgPSBrZXkuY2hhckNvZGVBdCgyKTtcbiAgcmV0dXJuIGNvZGUwID09PSAxMTEgLyogbyAqLyAmJiBjb2RlMSA9PT0gMTEwIC8qIG4gKi8gJiYgY29kZTIgPj0gNjUgLyogQSAqLyAmJiBjb2RlMiA8PSA5MCAvKiBaICovICYmICh0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbicgfHwgdHlwZW9mIHZhbHVlID09PSAndW5kZWZpbmVkJyk7XG59XG5mdW5jdGlvbiBpc1Byb3BzR2V0dGVyKGlucHV0UHJvcHMpIHtcbiAgcmV0dXJuIHR5cGVvZiBpbnB1dFByb3BzID09PSAnZnVuY3Rpb24nO1xufVxuZnVuY3Rpb24gbWVyZ2VFdmVudEhhbmRsZXJzKG91ckhhbmRsZXIsIHRoZWlySGFuZGxlcikge1xuICBpZiAoIXRoZWlySGFuZGxlcikge1xuICAgIHJldHVybiBvdXJIYW5kbGVyO1xuICB9XG4gIGlmICghb3VySGFuZGxlcikge1xuICAgIHJldHVybiB3cmFwRXZlbnRIYW5kbGVyKHRoZWlySGFuZGxlcik7XG4gIH1cbiAgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgY29uc3QgZXZlbnQgPSBhcmdzWzBdO1xuICAgIGlmIChpc1N5bnRoZXRpY0V2ZW50KGV2ZW50KSkge1xuICAgICAgY29uc3QgYmFzZVVJRXZlbnQgPSBldmVudDtcbiAgICAgIG1ha2VFdmVudFByZXZlbnRhYmxlKGJhc2VVSUV2ZW50KTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHRoZWlySGFuZGxlciguLi5hcmdzKTtcbiAgICAgIGlmICghYmFzZVVJRXZlbnQuYmFzZVVJSGFuZGxlclByZXZlbnRlZCkge1xuICAgICAgICBvdXJIYW5kbGVyPy4oLi4uYXJncyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSB0aGVpckhhbmRsZXIoLi4uYXJncyk7XG4gICAgb3VySGFuZGxlcj8uKC4uLmFyZ3MpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG59XG5mdW5jdGlvbiB3cmFwRXZlbnRIYW5kbGVyKGhhbmRsZXIpIHtcbiAgaWYgKCFoYW5kbGVyKSB7XG4gICAgcmV0dXJuIGhhbmRsZXI7XG4gIH1cbiAgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgY29uc3QgZXZlbnQgPSBhcmdzWzBdO1xuICAgIGlmIChpc1N5bnRoZXRpY0V2ZW50KGV2ZW50KSkge1xuICAgICAgbWFrZUV2ZW50UHJldmVudGFibGUoZXZlbnQpO1xuICAgIH1cbiAgICByZXR1cm4gaGFuZGxlciguLi5hcmdzKTtcbiAgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBtYWtlRXZlbnRQcmV2ZW50YWJsZShldmVudCkge1xuICBldmVudC5wcmV2ZW50QmFzZVVJSGFuZGxlciA9ICgpID0+IHtcbiAgICBldmVudC5iYXNlVUlIYW5kbGVyUHJldmVudGVkID0gdHJ1ZTtcbiAgfTtcbiAgcmV0dXJuIGV2ZW50O1xufVxuZXhwb3J0IGZ1bmN0aW9uIG1lcmdlQ2xhc3NOYW1lcyhvdXJDbGFzc05hbWUsIHRoZWlyQ2xhc3NOYW1lKSB7XG4gIGlmICh0aGVpckNsYXNzTmFtZSkge1xuICAgIGlmIChvdXJDbGFzc05hbWUpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBwcmVmZXItdGVtcGxhdGVcbiAgICAgIHJldHVybiB0aGVpckNsYXNzTmFtZSArICcgJyArIG91ckNsYXNzTmFtZTtcbiAgICB9XG4gICAgcmV0dXJuIHRoZWlyQ2xhc3NOYW1lO1xuICB9XG4gIHJldHVybiBvdXJDbGFzc05hbWU7XG59XG5mdW5jdGlvbiBpc1N5bnRoZXRpY0V2ZW50KGV2ZW50KSB7XG4gIHJldHVybiBldmVudCAhPSBudWxsICYmIHR5cGVvZiBldmVudCA9PT0gJ29iamVjdCcgJiYgJ25hdGl2ZUV2ZW50JyBpbiBldmVudDtcbn0iLCIvKipcbiAqIENyZWF0ZXMgYSBmb3JtYXRFcnJvck1lc3NhZ2UgZnVuY3Rpb24gd2l0aCBhIGN1c3RvbSBVUkwgYW5kIHByZWZpeC5cbiAqIEBwYXJhbSBiYXNlVXJsIC0gVGhlIGJhc2UgVVJMIGZvciB0aGUgZXJyb3IgcGFnZSAoZS5nLiwgJ2h0dHBzOi8vYmFzZS11aS5jb20vcHJvZHVjdGlvbi1lcnJvcicpXG4gKiBAcGFyYW0gcHJlZml4IC0gVGhlIHByZWZpeCBmb3IgdGhlIGVycm9yIG1lc3NhZ2UgKGUuZy4sICdCYXNlIFVJJylcbiAqIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCBmb3JtYXRzIGVycm9yIG1lc3NhZ2VzIHdpdGggdGhlIGdpdmVuIFVSTCBhbmQgcHJlZml4XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVGb3JtYXRFcnJvck1lc3NhZ2UoYmFzZVVybCwgcHJlZml4KSB7XG4gIHJldHVybiBmdW5jdGlvbiBmb3JtYXRFcnJvck1lc3NhZ2UoY29kZSwgLi4uYXJncykge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoYmFzZVVybCk7XG4gICAgdXJsLnNlYXJjaFBhcmFtcy5zZXQoJ2NvZGUnLCBjb2RlLnRvU3RyaW5nKCkpO1xuICAgIGFyZ3MuZm9yRWFjaChhcmcgPT4gdXJsLnNlYXJjaFBhcmFtcy5hcHBlbmQoJ2FyZ3NbXScsIGFyZykpO1xuICAgIHJldHVybiBgJHtwcmVmaXh9IGVycm9yICMke2NvZGV9OyB2aXNpdCAke3VybH0gZm9yIHRoZSBmdWxsIG1lc3NhZ2UuYDtcbiAgfTtcbn1cblxuLyoqXG4gKiBXQVJOSU5HOiBEb24ndCBpbXBvcnQgdGhpcyBkaXJlY3RseS4gSXQncyBpbXBvcnRlZCBieSB0aGUgY29kZSBnZW5lcmF0ZWQgYnlcbiAqIGBAbXVpL2ludGVybmFsLWJhYmVsLXBsdWdpbi1taW5pZnktZXJyb3JzYC4gTWFrZSBzdXJlIHRvIGFsd2F5cyB1c2Ugc3RyaW5nIGxpdGVyYWxzIGluIGBFcnJvcmBcbiAqIGNvbnN0cnVjdG9ycyB0byBlbnN1cmUgdGhlIHBsdWdpbiB3b3JrcyBhcyBleHBlY3RlZC4gU3VwcG9ydGVkIHBhdHRlcm5zIGluY2x1ZGU6XG4gKiAgIHRocm93IG5ldyBFcnJvcignTXkgbWVzc2FnZScpO1xuICogICB0aHJvdyBuZXcgRXJyb3IoYE15IG1lc3NhZ2U6ICR7Zm9vfWApO1xuICogICB0aHJvdyBuZXcgRXJyb3IoYE15IG1lc3NhZ2U6ICR7Zm9vfWAgKyAnYW5vdGhlciBzdHJpbmcnKTtcbiAqICAgLi4uXG4gKi9cbmNvbnN0IGZvcm1hdEVycm9yTWVzc2FnZSA9IGNyZWF0ZUZvcm1hdEVycm9yTWVzc2FnZSgnaHR0cHM6Ly9iYXNlLXVpLmNvbS9wcm9kdWN0aW9uLWVycm9yJywgJ0Jhc2UgVUknKTtcbmV4cG9ydCBkZWZhdWx0IGZvcm1hdEVycm9yTWVzc2FnZTsiLCJpbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gXCIuL3VzZVJlZldpdGhJbml0Lm1qc1wiO1xuXG4vKipcbiAqIE1lcmdlcyByZWZzIGludG8gYSBzaW5nbGUgbWVtb2l6ZWQgY2FsbGJhY2sgcmVmIG9yIGBudWxsYC5cbiAqIFRoaXMgbWFrZXMgc3VyZSBtdWx0aXBsZSByZWZzIGFyZSB1cGRhdGVkIHRvZ2V0aGVyIGFuZCBoYXZlIHRoZSBzYW1lIHZhbHVlLlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gYWNjZXB0cyB1cCB0byBmb3VyIHJlZnMuIElmIHlvdSBuZWVkIHRvIG1lcmdlIG1vcmUsIG9yIGhhdmUgYW4gdW5zcGVjaWZpZWQgbnVtYmVyIG9mIHJlZnMgdG8gbWVyZ2UsXG4gKiB1c2UgYHVzZU1lcmdlZFJlZnNOYCBpbnN0ZWFkLlxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZXJnZWRSZWZzKGEsIGIsIGMsIGQpIHtcbiAgY29uc3QgZm9ya1JlZiA9IHVzZVJlZldpdGhJbml0KGNyZWF0ZUZvcmtSZWYpLmN1cnJlbnQ7XG4gIGlmIChkaWRDaGFuZ2UoZm9ya1JlZiwgYSwgYiwgYywgZCkpIHtcbiAgICB1cGRhdGUoZm9ya1JlZiwgW2EsIGIsIGMsIGRdKTtcbiAgfVxuICByZXR1cm4gZm9ya1JlZi5jYWxsYmFjaztcbn1cblxuLyoqXG4gKiBNZXJnZXMgYW4gYXJyYXkgb2YgcmVmcyBpbnRvIGEgc2luZ2xlIG1lbW9pemVkIGNhbGxiYWNrIHJlZiBvciBgbnVsbGAuXG4gKlxuICogSWYgeW91IG5lZWQgdG8gbWVyZ2UgYSBmaXhlZCBudW1iZXIgKHVwIHRvIGZvdXIpIG9mIHJlZnMsIHVzZSBgdXNlTWVyZ2VkUmVmc2AgaW5zdGVhZCBmb3IgYmV0dGVyIHBlcmZvcm1hbmNlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlTWVyZ2VkUmVmc04ocmVmcykge1xuICBjb25zdCBmb3JrUmVmID0gdXNlUmVmV2l0aEluaXQoY3JlYXRlRm9ya1JlZikuY3VycmVudDtcbiAgaWYgKGRpZENoYW5nZU4oZm9ya1JlZiwgcmVmcykpIHtcbiAgICB1cGRhdGUoZm9ya1JlZiwgcmVmcyk7XG4gIH1cbiAgcmV0dXJuIGZvcmtSZWYuY2FsbGJhY2s7XG59XG5mdW5jdGlvbiBjcmVhdGVGb3JrUmVmKCkge1xuICByZXR1cm4ge1xuICAgIGNhbGxiYWNrOiBudWxsLFxuICAgIGNsZWFudXA6IG51bGwsXG4gICAgcmVmczogW11cbiAgfTtcbn1cbmZ1bmN0aW9uIGRpZENoYW5nZShmb3JrUmVmLCBhLCBiLCBjLCBkKSB7XG4gIC8vIHByZXR0aWVyLWlnbm9yZVxuICByZXR1cm4gZm9ya1JlZi5yZWZzWzBdICE9PSBhIHx8IGZvcmtSZWYucmVmc1sxXSAhPT0gYiB8fCBmb3JrUmVmLnJlZnNbMl0gIT09IGMgfHwgZm9ya1JlZi5yZWZzWzNdICE9PSBkO1xufVxuZnVuY3Rpb24gZGlkQ2hhbmdlTihmb3JrUmVmLCBuZXdSZWZzKSB7XG4gIHJldHVybiBmb3JrUmVmLnJlZnMubGVuZ3RoICE9PSBuZXdSZWZzLmxlbmd0aCB8fCBmb3JrUmVmLnJlZnMuc29tZSgocmVmLCBpbmRleCkgPT4gcmVmICE9PSBuZXdSZWZzW2luZGV4XSk7XG59XG5mdW5jdGlvbiB1cGRhdGUoZm9ya1JlZiwgcmVmcykge1xuICBmb3JrUmVmLnJlZnMgPSByZWZzO1xuICBpZiAocmVmcy5ldmVyeShyZWYgPT4gcmVmID09IG51bGwpKSB7XG4gICAgZm9ya1JlZi5jYWxsYmFjayA9IG51bGw7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvcmtSZWYuY2FsbGJhY2sgPSBpbnN0YW5jZSA9PiB7XG4gICAgaWYgKGZvcmtSZWYuY2xlYW51cCkge1xuICAgICAgZm9ya1JlZi5jbGVhbnVwKCk7XG4gICAgICBmb3JrUmVmLmNsZWFudXAgPSBudWxsO1xuICAgIH1cbiAgICBpZiAoaW5zdGFuY2UgIT0gbnVsbCkge1xuICAgICAgY29uc3QgY2xlYW51cENhbGxiYWNrcyA9IEFycmF5KHJlZnMubGVuZ3RoKS5maWxsKG51bGwpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZWZzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgIGNvbnN0IHJlZiA9IHJlZnNbaV07XG4gICAgICAgIGlmIChyZWYgPT0gbnVsbCkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHN3aXRjaCAodHlwZW9mIHJlZikge1xuICAgICAgICAgIGNhc2UgJ2Z1bmN0aW9uJzpcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgY29uc3QgcmVmQ2xlYW51cCA9IHJlZihpbnN0YW5jZSk7XG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgcmVmQ2xlYW51cCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIGNsZWFudXBDYWxsYmFja3NbaV0gPSByZWZDbGVhbnVwO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIGNhc2UgJ29iamVjdCc6XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHJlZi5jdXJyZW50ID0gaW5zdGFuY2U7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGZvcmtSZWYuY2xlYW51cCA9ICgpID0+IHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZWZzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgICAgY29uc3QgcmVmID0gcmVmc1tpXTtcbiAgICAgICAgICBpZiAocmVmID09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBzd2l0Y2ggKHR5cGVvZiByZWYpIHtcbiAgICAgICAgICAgIGNhc2UgJ2Z1bmN0aW9uJzpcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNsZWFudXBDYWxsYmFjayA9IGNsZWFudXBDYWxsYmFja3NbaV07XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjbGVhbnVwQ2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgIGNsZWFudXBDYWxsYmFjaygpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAvLyBMZWdhY3kgcmVmIHdpdGggbm8gYXR0YWNoLXRpbWUgY2xlYW51cDogZGV0YWNoIGJ5IGNhbGxpbmcgaXQgd2l0aCBgbnVsbGAuXG4gICAgICAgICAgICAgICAgICAvLyBJdCByZXR1cm5zIG5vdGhpbmc7IFJlYWN0IDE5IGNsZWFudXBzIGFyZSBoYW5kbGVkIGluIHRoZSBicmFuY2ggYWJvdmUuXG4gICAgICAgICAgICAgICAgICB2b2lkIHJlZihudWxsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ29iamVjdCc6XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn0iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5jb25zdCBtYWpvclZlcnNpb24gPSBwYXJzZUludChSZWFjdC52ZXJzaW9uLCAxMCk7XG5leHBvcnQgZnVuY3Rpb24gaXNSZWFjdFZlcnNpb25BdExlYXN0KHJlYWN0VmVyc2lvblRvQ2hlY2spIHtcbiAgcmV0dXJuIG1ham9yVmVyc2lvbiA+PSByZWFjdFZlcnNpb25Ub0NoZWNrO1xufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGlzUmVhY3RWZXJzaW9uQXRMZWFzdCB9IGZyb20gXCIuL3JlYWN0VmVyc2lvbi5tanNcIjtcblxuLyoqXG4gKiBFeHRyYWN0cyB0aGUgYHJlZmAgZnJvbSBhIFJlYWN0IGVsZW1lbnQsIGhhbmRsaW5nIGRpZmZlcmVudCBSZWFjdCB2ZXJzaW9ucy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFJlYWN0RWxlbWVudFJlZihlbGVtZW50KSB7XG4gIGlmICghIC8qI19fUFVSRV9fKi9SZWFjdC5pc1ZhbGlkRWxlbWVudChlbGVtZW50KSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHJlYWN0RWxlbWVudCA9IGVsZW1lbnQ7XG4gIGNvbnN0IHByb3BzV2l0aFJlZiA9IHJlYWN0RWxlbWVudC5wcm9wcztcbiAgcmV0dXJuIChpc1JlYWN0VmVyc2lvbkF0TGVhc3QoMTkpID8gcHJvcHNXaXRoUmVmPy5yZWYgOiByZWFjdEVsZW1lbnQucmVmKSA/PyBudWxsO1xufSIsImltcG9ydCB7IGNyZWF0ZUxvZ09uY2UgfSBmcm9tIFwiLi9jcmVhdGVMb2dPbmNlLm1qc1wiO1xuZXhwb3J0IGNvbnN0IHdhcm4gPSBjcmVhdGVMb2dPbmNlKCd3YXJuJywgJ0Jhc2UgVUknKTtcbmV4cG9ydCB7IHJlc2V0IH0gZnJvbSBcIi4vY3JlYXRlTG9nT25jZS5tanNcIjsiLCJleHBvcnQgZnVuY3Rpb24gTk9PUCgpIHt9XG5cbi8vIFR5cGVkIGFzIG11dGFibGUgYG5ldmVyW11gIHNvIGl0IGlzIGFzc2lnbmFibGUgdG8gYW55IGBUW11gIGZhbGxiYWNrIChmb3IgZXhhbXBsZVxuLy8gYGRlZmF1bHRWYWx1ZSA/PyBFTVBUWV9BUlJBWWAgaW4gYHVzZUNvbnRyb2xsZWRgIGNhbGxlcnMpIHdpdGhvdXQgd2lkZW5pbmcgYFRgLlxuLy8gRnJvemVuIHNvIGEgd3JpdGUgdGhyb3VnaCBhIHdpZGVuZWQgYWxpYXMgdGhyb3dzIGluc3RlYWQgb2YgbXV0YXRpbmcgdGhlIHNoYXJlZCBzaW5nbGV0b24uXG5leHBvcnQgY29uc3QgRU1QVFlfQVJSQVkgPSBPYmplY3QuZnJlZXplKFtdKTtcbmV4cG9ydCBjb25zdCBFTVBUWV9PQkpFQ1QgPSBPYmplY3QuZnJlZXplKHt9KTsiLCJleHBvcnQgZnVuY3Rpb24gZ2V0U3RhdGVBdHRyaWJ1dGVzUHJvcHMoc3RhdGUsIGN1c3RvbU1hcHBpbmcpIHtcbiAgY29uc3QgcHJvcHMgPSB7fTtcblxuICAvKiBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZ3VhcmQtZm9yLWluICovXG4gIGZvciAoY29uc3Qga2V5IGluIHN0YXRlKSB7XG4gICAgY29uc3QgdmFsdWUgPSBzdGF0ZVtrZXldO1xuICAgIGlmIChjdXN0b21NYXBwaW5nPy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICBjb25zdCBjdXN0b21Qcm9wcyA9IGN1c3RvbU1hcHBpbmdba2V5XSh2YWx1ZSk7XG4gICAgICBpZiAoY3VzdG9tUHJvcHMgIT0gbnVsbCkge1xuICAgICAgICBPYmplY3QuYXNzaWduKHByb3BzLCBjdXN0b21Qcm9wcyk7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKHZhbHVlID09PSB0cnVlKSB7XG4gICAgICBwcm9wc1tgZGF0YS0ke2tleS50b0xvd2VyQ2FzZSgpfWBdID0gJyc7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSkge1xuICAgICAgcHJvcHNbYGRhdGEtJHtrZXkudG9Mb3dlckNhc2UoKX1gXSA9IHZhbHVlLnRvU3RyaW5nKCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBwcm9wcztcbn0iLCIvKipcbiAqIElmIHRoZSBwcm92aWRlZCBjbGFzc05hbWUgaXMgYSBzdHJpbmcsIGl0IHdpbGwgYmUgcmV0dXJuZWQgYXMgaXMuXG4gKiBPdGhlcndpc2UsIHRoZSBmdW5jdGlvbiB3aWxsIGNhbGwgdGhlIGNsYXNzTmFtZSBmdW5jdGlvbiB3aXRoIHRoZSBzdGF0ZSBhcyB0aGUgZmlyc3QgYXJndW1lbnQuXG4gKlxuICogQHBhcmFtIGNsYXNzTmFtZVxuICogQHBhcmFtIHN0YXRlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQ2xhc3NOYW1lKGNsYXNzTmFtZSwgc3RhdGUpIHtcbiAgcmV0dXJuIHR5cGVvZiBjbGFzc05hbWUgPT09ICdmdW5jdGlvbicgPyBjbGFzc05hbWUoc3RhdGUpIDogY2xhc3NOYW1lO1xufSIsIi8qKlxuICogSWYgdGhlIHByb3ZpZGVkIHN0eWxlIGlzIGFuIG9iamVjdCwgaXQgd2lsbCBiZSByZXR1cm5lZCBhcyBpcy5cbiAqIE90aGVyd2lzZSwgdGhlIGZ1bmN0aW9uIHdpbGwgY2FsbCB0aGUgc3R5bGUgZnVuY3Rpb24gd2l0aCB0aGUgc3RhdGUgYXMgdGhlIGZpcnN0IGFyZ3VtZW50LlxuICpcbiAqIEBwYXJhbSBzdHlsZVxuICogQHBhcmFtIHN0YXRlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlU3R5bGUoc3R5bGUsIHN0YXRlKSB7XG4gIHJldHVybiB0eXBlb2Ygc3R5bGUgPT09ICdmdW5jdGlvbicgPyBzdHlsZShzdGF0ZSkgOiBzdHlsZTtcbn0iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZXJnZWRSZWZzLCB1c2VNZXJnZWRSZWZzTiB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZU1lcmdlZFJlZnMnO1xuaW1wb3J0IHsgZ2V0UmVhY3RFbGVtZW50UmVmIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZ2V0UmVhY3RFbGVtZW50UmVmJztcbmltcG9ydCB7IG1lcmdlT2JqZWN0cyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL21lcmdlT2JqZWN0cyc7XG5pbXBvcnQgeyB3YXJuIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvd2Fybic7XG5pbXBvcnQgeyBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBnZXRTdGF0ZUF0dHJpYnV0ZXNQcm9wcyB9IGZyb20gXCIuL2dldFN0YXRlQXR0cmlidXRlc1Byb3BzLm1qc1wiO1xuaW1wb3J0IHsgcmVzb2x2ZUNsYXNzTmFtZSB9IGZyb20gXCIuLi91dGlscy9yZXNvbHZlQ2xhc3NOYW1lLm1qc1wiO1xuaW1wb3J0IHsgcmVzb2x2ZVN0eWxlIH0gZnJvbSBcIi4uL3V0aWxzL3Jlc29sdmVTdHlsZS5tanNcIjtcbmltcG9ydCB7IG1lcmdlUHJvcHMsIG1lcmdlUHJvcHNOLCBtZXJnZUNsYXNzTmFtZXMgfSBmcm9tIFwiLi4vbWVyZ2UtcHJvcHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVFbGVtZW50IGFzIF9jcmVhdGVFbGVtZW50IH0gZnJvbSBcInJlYWN0XCI7XG4vKipcbiAqIFJlbmRlcnMgYSBCYXNlIFVJIGVsZW1lbnQuXG4gKlxuICogQHBhcmFtIGVsZW1lbnQgVGhlIGRlZmF1bHQgSFRNTCBlbGVtZW50IHRvIHJlbmRlci4gQ2FuIGJlIG92ZXJyaWRkZW4gYnkgdGhlIGByZW5kZXJgIHByb3AuXG4gKiBAcGFyYW0gY29tcG9uZW50UHJvcHMgQW4gb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGByZW5kZXJgIGFuZCBgY2xhc3NOYW1lYCBwcm9wcyB0byBiZSB1c2VkIGZvciBlbGVtZW50IGN1c3RvbWl6YXRpb24uIE90aGVyIHByb3BzIGFyZSBpZ25vcmVkLlxuICogQHBhcmFtIHBhcmFtcyBBZGRpdGlvbmFsIHBhcmFtZXRlcnMgZm9yIHJlbmRlcmluZyB0aGUgZWxlbWVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVJlbmRlckVsZW1lbnQoZWxlbWVudCwgY29tcG9uZW50UHJvcHMsIHBhcmFtcyA9IHt9KSB7XG4gIGxldCByZW5kZXJQcm9wID0gY29tcG9uZW50UHJvcHMucmVuZGVyO1xuICBpZiAocGFyYW1zLmVuYWJsZWQgIT09IGZhbHNlKSB7XG4gICAgLy8gQSBwZW5kaW5nIGxhenkgZWxlbWVudCBzdXNwZW5kcyB3aGVuIHVud3JhcHBlZCwgc28gbGVhdmUgaXQgd3JhcHBlZCB3aGlsZSBkaXNhYmxlZC5cbiAgICByZW5kZXJQcm9wID0gdW53cmFwTGF6eVJlbmRlclByb3AocmVuZGVyUHJvcCk7XG4gIH1cbiAgY29uc3Qgb3V0UHJvcHMgPSB1c2VSZW5kZXJFbGVtZW50UHJvcHMoY29tcG9uZW50UHJvcHMsIHBhcmFtcywgcmVuZGVyUHJvcCk7XG4gIGlmIChwYXJhbXMuZW5hYmxlZCA9PT0gZmFsc2UpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCBzdGF0ZSA9IHBhcmFtcy5zdGF0ZSA/PyBFTVBUWV9PQkpFQ1Q7XG4gIHJldHVybiBldmFsdWF0ZVJlbmRlclByb3AoZWxlbWVudCwgcmVuZGVyUHJvcCwgb3V0UHJvcHMsIHN0YXRlKTtcbn1cblxuLyoqXG4gKiBDb21wdXRlcyByZW5kZXIgZWxlbWVudCBmaW5hbCBwcm9wcy5cbiAqL1xuZnVuY3Rpb24gdXNlUmVuZGVyRWxlbWVudFByb3BzKGNvbXBvbmVudFByb3BzLCBwYXJhbXMsIHJlbmRlclByb3ApIHtcbiAgY29uc3Qge1xuICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lUHJvcCxcbiAgICBzdHlsZTogc3R5bGVQcm9wXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHN0YXRlID0gRU1QVFlfT0JKRUNULFxuICAgIHJlZixcbiAgICBwcm9wcyxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLFxuICAgIGVuYWJsZWQgPSB0cnVlXG4gIH0gPSBwYXJhbXM7XG4gIGNvbnN0IGNsYXNzTmFtZSA9IGVuYWJsZWQgPyByZXNvbHZlQ2xhc3NOYW1lKGNsYXNzTmFtZVByb3AsIHN0YXRlKSA6IHVuZGVmaW5lZDtcbiAgY29uc3Qgc3R5bGUgPSBlbmFibGVkID8gcmVzb2x2ZVN0eWxlKHN0eWxlUHJvcCwgc3RhdGUpIDogdW5kZWZpbmVkO1xuICBjb25zdCBzdGF0ZVByb3BzID0gZW5hYmxlZCA/IGdldFN0YXRlQXR0cmlidXRlc1Byb3BzKHN0YXRlLCBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nKSA6IEVNUFRZX09CSkVDVDtcbiAgY29uc3QgcmVzb2x2ZWRQcm9wcyA9IGVuYWJsZWQgJiYgcHJvcHMgPyByZXNvbHZlUmVuZGVyRnVuY3Rpb25Qcm9wcyhwcm9wcykgOiB1bmRlZmluZWQ7XG5cbiAgLy8gRW5zdXJlIG91dFByb3BzIGlzIGFsd2F5cyBhIG5ldyBtdXRhYmxlIG9iamVjdCB3aGVuIGVuYWJsZWQsIG5ldmVyIEVNUFRZX09CSkVDVC5cbiAgLy8gVGhpcyBwcmV2ZW50cyBwb3RlbnRpYWwgVHlwZUVycm9yIHdoZW4gc2V0dGluZyByZWYsIGNsYXNzTmFtZSwgb3Igc3R5bGUgcHJvcGVydGllcyxcbiAgLy8gc2luY2UgRU1QVFlfT0JKRUNUIGlzIGZyb3plbiBhbmQgbXV0YXRpb25zIHdvdWxkIGZhaWwgaW4gc3RyaWN0IG1vZGUuXG4gIGNvbnN0IG91dFByb3BzID0gZW5hYmxlZCA/IG1lcmdlT2JqZWN0cyhzdGF0ZVByb3BzLCByZXNvbHZlZFByb3BzKSA/PyB7fSA6IEVNUFRZX09CSkVDVDtcblxuICAvLyBTQUZFVFk6IFRoZSBgdXNlTWVyZ2VkUmVmc2AgZnVuY3Rpb25zIHVzZSBhIHNpbmdsZSBob29rIHRvIHN0b3JlIHRoZSBzYW1lIHZhbHVlLFxuICAvLyBzd2l0Y2hpbmcgYmV0d2VlbiB0aGVtIGF0IHJ1bnRpbWUgaXMgc2FmZS4gSWYgdGhpcyBhc3NlcnRpb24gZmFpbHMsIFJlYWN0IHdpbGxcbiAgLy8gdGhyb3cgYXQgcnVudGltZSBhbnl3YXkuXG4gIC8vIFRoaXMgYWxzbyBza2lwcyB0aGUgYHVzZU1lcmdlZFJlZnNgIGNhbGwgb24gdGhlIHNlcnZlciwgd2hpY2ggaXMgZmluZSBiZWNhdXNlXG4gIC8vIHJlZnMgYXJlIG5vdCB1c2VkIG9uIHRoZSBzZXJ2ZXIgc2lkZS5cbiAgLyogZXNsaW50LWRpc2FibGUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3MgKi9cbiAgaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIC8vIENhbGxlZCBvbmx5IHRvIGtlZXAgdGhlIGhvb2sgb3JkZXIgc3RhYmxlIHdoZW4gZGlzYWJsZWQ7IHRoZSBtZXJnZWQgcmVmIGlzIHVudXNlZC5cbiAgICAgIHZvaWQgdXNlTWVyZ2VkUmVmcyhudWxsLCBudWxsKTtcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocmVmKSkge1xuICAgICAgb3V0UHJvcHMucmVmID0gdXNlTWVyZ2VkUmVmc04oW291dFByb3BzLnJlZiwgZ2V0UmVhY3RFbGVtZW50UmVmKHJlbmRlclByb3ApLCAuLi5yZWZdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0UHJvcHMucmVmID0gdXNlTWVyZ2VkUmVmcyhvdXRQcm9wcy5yZWYsIGdldFJlYWN0RWxlbWVudFJlZihyZW5kZXJQcm9wKSwgcmVmKTtcbiAgICB9XG4gIH1cbiAgaWYgKCFlbmFibGVkKSB7XG4gICAgcmV0dXJuIEVNUFRZX09CSkVDVDtcbiAgfVxuICBpZiAoY2xhc3NOYW1lICE9PSB1bmRlZmluZWQpIHtcbiAgICBvdXRQcm9wcy5jbGFzc05hbWUgPSBtZXJnZUNsYXNzTmFtZXMob3V0UHJvcHMuY2xhc3NOYW1lLCBjbGFzc05hbWUpO1xuICB9XG4gIGlmIChzdHlsZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgb3V0UHJvcHMuc3R5bGUgPSBtZXJnZU9iamVjdHMob3V0UHJvcHMuc3R5bGUsIHN0eWxlKTtcbiAgfVxuICByZXR1cm4gb3V0UHJvcHM7XG59XG5mdW5jdGlvbiByZXNvbHZlUmVuZGVyRnVuY3Rpb25Qcm9wcyhwcm9wcykge1xuICBpZiAoQXJyYXkuaXNBcnJheShwcm9wcykpIHtcbiAgICByZXR1cm4gbWVyZ2VQcm9wc04ocHJvcHMpO1xuICB9XG4gIHJldHVybiBtZXJnZVByb3BzKHVuZGVmaW5lZCwgcHJvcHMpO1xufVxuXG4vLyBUaGUgc3ltYm9sIFJlYWN0IHVzZXMgaW50ZXJuYWxseSBmb3IgbGF6eSBjb21wb25lbnRzXG4vLyBodHRwczovL2dpdGh1Yi5jb20vcmVhY3QvcmVhY3QvYmxvYi9hMDU2NjI1MGIyMTA0OTliNGM1Njc3ZjVhYzJlZWRiZDcxZDUxYTFiL3BhY2thZ2VzL3NoYXJlZC9SZWFjdFN5bWJvbHMuanMjTDMxXG4vL1xuLy8gVE9ETyBkZWxldGUgb25jZSBodHRwczovL2dpdGh1Yi5jb20vcmVhY3QvcmVhY3QvaXNzdWVzLzMyMzkyIGlzIGZpeGVkXG5jb25zdCBSRUFDVF9MQVpZX1RZUEUgPSBTeW1ib2wuZm9yKCdyZWFjdC5sYXp5Jyk7XG5jb25zdCBDT01QT05FTlRfSURFTlRJRklFUl9QQVRURVJOID0gL15bQS1aXVtBLVphLXowLTkkXSokLztcbmNvbnN0IExPV0VSQ0FTRV9DSEFSQUNURVJfUEFUVEVSTiA9IC9bYS16XS87XG5cbi8vIFdvcmthcm91bmQgZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWFjdC9yZWFjdC9pc3N1ZXMvMzIzOTJcbi8vIFRoZSBGbGlnaHQgY2xpZW50IGhhbmRzIG92ZXIgYSBsYXp5IHdyYXBwZXIgaW4gcGxhY2Ugb2YgYSByZW5kZXIgZWxlbWVudCBjcmVhdGVkIGluIGFcbi8vIFNlcnZlciBDb21wb25lbnQuIFRoZSB3cmFwcGVyIGV4cG9zZXMgbm8gYC5wcm9wc2Agb3IgYC5yZWZgLCBzbyBpdCBtdXN0IGJlIHVud3JhcHBlZFxuLy8gYmVmb3JlIHRob3NlIGFyZSByZWFkLiBUaGlzIHdvcmtzIGJlY2F1c2UgdGhlIHRvQXJyYXkoKSBsb2dpYyB1bndyYXBzIHRoZSBsYXp5XG4vLyBlbGVtZW50IHR5cGUgaW5cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWFjdC9yZWFjdC9ibG9iL2EwNTY2MjUwYjIxMDQ5OWI0YzU2NzdmNWFjMmVlZGJkNzFkNTFhMWIvcGFja2FnZXMvcmVhY3Qvc3JjL1JlYWN0Q2hpbGRyZW4uanMjTDE4NlxuZXhwb3J0IGZ1bmN0aW9uIHVud3JhcExhenlSZW5kZXJQcm9wKHJlbmRlcikge1xuICAvLyBgJCR0eXBlb2ZgIGlzIGEgUmVhY3QgaW50ZXJuYWwsIGFic2VudCBmcm9tIHRoZSBwdWJsaWMgZWxlbWVudCB0eXBlcy5cbiAgaWYgKHJlbmRlcj8uJCR0eXBlb2YgIT09IFJFQUNUX0xBWllfVFlQRSkge1xuICAgIHJldHVybiByZW5kZXI7XG4gIH1cbiAgLy8gS2VlcCB0aGUgd3JhcHBlciB1bmxlc3MgaXQgdW53cmFwcyB0byBhbiBlbGVtZW50LCBzbyBhbiBpbnZhbGlkIHJlbmRlciBwcm9wIGlzIHN0aWxsXG4gIC8vIHJlcG9ydGVkIGFzIG9uZSBpbnN0ZWFkIG9mIHNpbGVudGx5IGZhbGxpbmcgYmFjayB0byB0aGUgZGVmYXVsdCBlbGVtZW50LlxuICBjb25zdCB1bndyYXBwZWQgPSBSZWFjdC5DaGlsZHJlbi50b0FycmF5KHJlbmRlcilbMF07XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQodW53cmFwcGVkKSA/IHVud3JhcHBlZCA6IHJlbmRlcjtcbn1cbmZ1bmN0aW9uIGV2YWx1YXRlUmVuZGVyUHJvcChlbGVtZW50LCByZW5kZXIsIHByb3BzLCBzdGF0ZSkge1xuICBpZiAocmVuZGVyKSB7XG4gICAgaWYgKHR5cGVvZiByZW5kZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIHdhcm5JZlJlbmRlclByb3BMb29rc0xpa2VDb21wb25lbnQocmVuZGVyKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZW5kZXIocHJvcHMsIHN0YXRlKTtcbiAgICB9XG4gICAgY29uc3QgbWVyZ2VkUHJvcHMgPSBtZXJnZVByb3BzKHByb3BzLCByZW5kZXIucHJvcHMpO1xuICAgIG1lcmdlZFByb3BzLnJlZiA9IHByb3BzLnJlZjtcblxuICAgIC8vIFRoZXJlIGlzIGEgaGlnaCBudW1iZXIgb2YgaW5kaXJlY3Rpb25zLCB0aGUgZXJyb3IgbWVzc2FnZSB0aHJvd24gYnkgUmVhY3QuY2xvbmVFbGVtZW50KCkgaXNcbiAgICAvLyBoYXJkIHRvIHVzZSBmb3IgZGV2ZWxvcGVycywgdGhpcyBsb2dpYyBwcm92aWRlcyBhIGJldHRlciBjb250ZXh0LlxuICAgIC8vXG4gICAgLy8gT3VyIGdlbmVyYWwgZ3VpZGVsaW5lIGlzIHRvIG5ldmVyIGNoYW5nZSB0aGUgY29udHJvbCBmbG93IGRlcGVuZGluZyBvbiB0aGUgZW52aXJvbm1lbnQuXG4gICAgLy8gSG93ZXZlciwgUmVhY3QuY2xvbmVFbGVtZW50KCkgdGhyb3dzIGlmIFJlYWN0LmlzVmFsaWRFbGVtZW50KCkgaXMgZmFsc2UsXG4gICAgLy8gc28gd2UgY2FuIHRocm93IGJlZm9yZSB3aXRoIGN1c3RvbSBtZXNzYWdlLlxuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBpZiAoISAvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQocmVuZGVyKSkge1xuICAgICAgICAvLyBUT0RPOiBmaXggbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG11aS9uby1ndWFyZGVkLXRocm93XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihbJ0Jhc2UgVUk6IFRoZSBgcmVuZGVyYCBwcm9wIHdhcyBwcm92aWRlZCBhbiBpbnZhbGlkIFJlYWN0IGVsZW1lbnQgYXMgYFJlYWN0LmlzVmFsaWRFbGVtZW50KHJlbmRlcilgIGlzIGBmYWxzZWAuJywgJ0EgdmFsaWQgUmVhY3QgZWxlbWVudCBtdXN0IGJlIHByb3ZpZGVkIHRvIHRoZSBgcmVuZGVyYCBwcm9wIGJlY2F1c2UgaXQgaXMgY2xvbmVkIHdpdGggcHJvcHMgdG8gcmVwbGFjZSB0aGUgZGVmYXVsdCBlbGVtZW50LicsICdodHRwczovL2Jhc2UtdWkuY29tL3IvaW52YWxpZC1yZW5kZXItcHJvcCddLmpvaW4oJ1xcbicpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jbG9uZUVsZW1lbnQocmVuZGVyLCBtZXJnZWRQcm9wcyk7XG4gIH1cbiAgLy8gYGVsZW1lbnRgIGlzIGFsd2F5cyBwcm92aWRlZCB3aGVuIHRoZXJlIGlzIG5vIGByZW5kZXJgIHByb3AuXG4gIHJldHVybiByZW5kZXJUYWcoZWxlbWVudCwgcHJvcHMpO1xufVxuZnVuY3Rpb24gd2FybklmUmVuZGVyUHJvcExvb2tzTGlrZUNvbXBvbmVudChyZW5kZXJGbikge1xuICBjb25zdCBmdW5jdGlvbk5hbWUgPSByZW5kZXJGbi5uYW1lO1xuICBpZiAoZnVuY3Rpb25OYW1lLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIUNPTVBPTkVOVF9JREVOVElGSUVSX1BBVFRFUk4udGVzdChmdW5jdGlvbk5hbWUpKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghTE9XRVJDQVNFX0NIQVJBQ1RFUl9QQVRURVJOLnRlc3QoZnVuY3Rpb25OYW1lKSkge1xuICAgIHJldHVybjtcbiAgfVxuICB3YXJuKGBUaGUgXFxgcmVuZGVyXFxgIHByb3AgcmVjZWl2ZWQgYSBmdW5jdGlvbiBuYW1lZCBcXGAke2Z1bmN0aW9uTmFtZX1cXGAgdGhhdCBzdGFydHMgd2l0aCBhbiB1cHBlcmNhc2UgbGV0dGVyLmAsICdUaGlzIHVzdWFsbHkgbWVhbnMgYSBSZWFjdCBjb21wb25lbnQgd2FzIHBhc3NlZCBkaXJlY3RseSBhcyBgcmVuZGVyPXtDb21wb25lbnR9YC4nLCAnQmFzZSBVSSBjYWxscyBgcmVuZGVyYCBhcyBhIHBsYWluIGZ1bmN0aW9uLCB3aGljaCBjYW4gYnJlYWsgdGhlIFJ1bGVzIG9mIEhvb2tzIGR1cmluZyByZWNvbmNpbGlhdGlvbi4nLCAnSWYgdGhpcyBpcyBhbiBpbnRlbnRpb25hbCByZW5kZXIgY2FsbGJhY2ssIHJlbmFtZSBpdCB0byBzdGFydCB3aXRoIGEgbG93ZXJjYXNlIGxldHRlci4nLCAnVXNlIGByZW5kZXI9ezxDb21wb25lbnQgLz59YCBvciBgcmVuZGVyPXsocHJvcHMpID0+IDxDb21wb25lbnQgey4uLnByb3BzfSAvPn1gIGluc3RlYWQuJywgJ2h0dHBzOi8vYmFzZS11aS5jb20vci9pbnZhbGlkLXJlbmRlci1wcm9wJyk7XG59XG5mdW5jdGlvbiByZW5kZXJUYWcoVGFnLCBwcm9wcykge1xuICBpZiAoVGFnID09PSAnYnV0dG9uJykge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovX2NyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiwge1xuICAgICAgdHlwZTogXCJidXR0b25cIixcbiAgICAgIC4uLnByb3BzLFxuICAgICAga2V5OiBwcm9wcy5rZXlcbiAgICB9KTtcbiAgfVxuICBpZiAoVGFnID09PSAnaW1nJykge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovX2NyZWF0ZUVsZW1lbnQoXCJpbWdcIiwge1xuICAgICAgYWx0OiBcIlwiLFxuICAgICAgLi4ucHJvcHMsXG4gICAgICBrZXk6IHByb3BzLmtleVxuICAgIH0pO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChUYWcsIHByb3BzKTtcbn0iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQVVBLElBQWEsWUFBWSxFQUN2QixHQUFHQSxhQUNMOztBQ1RBLElBQU0sZ0JBQWdCLENBQUM7Ozs7Ozs7O0FBVXZCLFNBQWdCLGVBQWUsTUFBTSxTQUFTO0NBQzVDLE1BQU0sTUFBQSxhQUFZLE9BQU8sYUFBYTtDQUN0QyxJQUFJLElBQUksWUFBWSxlQUNsQixJQUFJLFVBQVUsS0FBSyxPQUFPO0NBRTVCLE9BQU87QUFDVDs7QUNmQSxJQUFNLHFCQUFxQixVQUFVO0FBQ3JDLElBQU0seUJBRU4sc0JBRUEsdUJBQXVCLFVBQVUsa0JBQWtCLHNCQUFxQixPQUFNLEdBQUc7Ozs7Ozs7Ozs7O0FBV2pGLFNBQWdCLGtCQUFrQixVQUFVO0NBQzFDLE1BQU0sU0FBUyxlQUFlLG9CQUFvQixDQUFDLENBQUM7Q0FDcEQsT0FBTyxPQUFPO0NBQ2QsdUJBQXVCLE9BQU8sTUFBTTtDQUNwQyxPQUFPLE9BQU87QUFDaEI7QUFDQSxTQUFTLHVCQUF1QjtDQUM5QixNQUFNLFNBQVM7RUFDYixNQUFNLEtBQUE7RUFDTixVQUFVO0VBQ1YsYUFBYSxHQUFHLFNBQVMsT0FBTyxXQUFXLEdBQUcsSUFBSTtFQUNsRCxjQUFjO0dBQ1osT0FBTyxXQUFXLE9BQU87RUFDM0I7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsa0JBQWtCO0NBSXZCLE1BQWlDLElBQUksTUFBTSx3REFBd0Q7QUFFdkc7O0FDM0NBLElBQUksaUNBRWUsSUFBSSxJQUFJOztBQUkzQixTQUFnQixjQUFjLFVBQVUsUUFBUTtDQUM5QyxPQUFPLFNBQVMsUUFBUSxHQUFHLFVBQVU7RUFDUTtHQUN6QyxNQUFNLFVBQVUsU0FBUyxLQUFLLEdBQUc7R0FDakMsTUFBTSxTQUFTLFNBQVMsR0FBRyxPQUFPLElBQUksWUFBWTtHQUNsRCxNQUFNLE1BQU0sR0FBRyxTQUFTLEdBQUc7R0FDM0IsSUFBSSxDQUFDLGVBQWUsSUFBSSxHQUFHLEdBQUc7SUFDNUIsZUFBZSxJQUFJLEdBQUc7SUFDdEIsSUFBSSxhQUFhLFFBQ2YsUUFBUSxLQUFLLE1BQU07U0FFbkIsUUFBUSxNQUFNLE1BQU07R0FFeEI7RUFDRjtDQUNGO0FBQ0Y7O0FDbkJBLElBQU0sYUFBYSxDQUFDO0FBQ3BCLElBQWEscUJBQXFCLE9BQU8sYUFBYSxjQUFBLGFBQW9CLGtCQUFrQjs7QUNKNUYsU0FBZ0IsYUFBYSxHQUFHLEdBQUc7Q0FDakMsSUFBSSxLQUFLLENBQUMsR0FDUixPQUFPO0NBRVQsSUFBSSxDQUFDLEtBQUssR0FDUixPQUFPO0NBRVQsSUFBSSxLQUFLLEdBQ1AsT0FBTztFQUNMLEdBQUc7RUFDSCxHQUFHO0NBQ0w7QUFHSjs7QUNiQSxJQUFNLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUNyQixTQUFnQixXQUFXLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUN4QyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FDckIsT0FBTyx5QkFBeUIsQ0FBQztDQUluQyxJQUFJLFNBQVMseUJBQXlCLENBQUM7Q0FDdkMsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7OztBQWdCQSxTQUFnQixZQUFZLE9BQU87Q0FDakMsSUFBSSxNQUFNLFdBQVcsR0FDbkIsT0FBTztDQUVULElBQUksTUFBTSxXQUFXLEdBQ25CLE9BQU8seUJBQXlCLE1BQU0sRUFBRTtDQUkxQyxJQUFJLFNBQVMseUJBQXlCLE1BQU0sRUFBRTtDQUM5QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssR0FDckMsU0FBUyxVQUFVLFFBQVEsTUFBTSxFQUFFO0NBRXJDLE9BQU87QUFDVDtBQUNBLFNBQVMseUJBQXlCLFlBQVk7Q0FDNUMsSUFBSSxjQUFjLFVBQVUsR0FFMUIsT0FBTyxFQUNMLEdBQUcsV0FBVyxXQUFXLEVBQzNCO0NBRUYsT0FBTyxpQkFBaUIsVUFBVTtBQUNwQztBQUNBLFNBQVMsVUFBVSxRQUFRLFlBQVk7Q0FDckMsSUFBSSxjQUFjLFVBQVUsR0FDMUIsT0FBTyxXQUFXLE1BQU07Q0FFMUIsT0FBTyxpQkFBaUIsUUFBUSxVQUFVO0FBQzVDO0FBQ0EsU0FBUyxpQkFBaUIsWUFBWTtDQUNwQyxNQUFNLGNBQWMsRUFDbEIsR0FBRyxXQUNMO0NBSUEsS0FBSyxNQUFNLFlBQVksYUFBYTtFQUNsQyxNQUFNLFlBQVksWUFBWTtFQUM5QixJQUFJLGVBQWUsVUFBVSxTQUFTLEdBQ3BDLFlBQVksWUFBWSxpQkFBaUIsU0FBUztDQUV0RDtDQUNBLE9BQU87QUFDVDs7OztBQUtBLFNBQVMsaUJBQWlCLGFBQWEsZUFBZTtDQUNwRCxJQUFJLENBQUMsZUFDSCxPQUFPO0NBSVQsS0FBSyxNQUFNLFlBQVksZUFBZTtFQUNwQyxNQUFNLG9CQUFvQixjQUFjO0VBQ3hDLFFBQVEsVUFBUjtHQUNFLEtBQUs7SUFFRCxZQUFZLFlBQVksYUFBYSxZQUFZLE9BQU8saUJBQWlCO0lBQ3pFO0dBRUosS0FBSztJQUVELFlBQVksWUFBWSxnQkFBZ0IsWUFBWSxXQUFXLGlCQUFpQjtJQUNoRjtHQUVKLFNBRUksSUFBSSxlQUFlLFVBQVUsaUJBQWlCLEdBQzVDLFlBQVksWUFBWSxtQkFBbUIsWUFBWSxXQUFXLGlCQUFpQjtRQUVuRixZQUFZLFlBQVk7RUFHaEM7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxLQUFLLE9BQU87Q0FFbEMsTUFBTSxRQUFRLElBQUksV0FBVyxDQUFDO0NBQzlCLE1BQU0sUUFBUSxJQUFJLFdBQVcsQ0FBQztDQUM5QixNQUFNLFFBQVEsSUFBSSxXQUFXLENBQUM7Q0FDOUIsT0FBTyxVQUFVLE9BQWUsVUFBVSxPQUFlLFNBQVMsTUFBYyxTQUFTLE9BQWUsT0FBTyxVQUFVLGNBQWMsT0FBTyxVQUFVO0FBQzFKO0FBQ0EsU0FBUyxjQUFjLFlBQVk7Q0FDakMsT0FBTyxPQUFPLGVBQWU7QUFDL0I7QUFDQSxTQUFTLG1CQUFtQixZQUFZLGNBQWM7Q0FDcEQsSUFBSSxDQUFDLGNBQ0gsT0FBTztDQUVULElBQUksQ0FBQyxZQUNILE9BQU8saUJBQWlCLFlBQVk7Q0FFdEMsUUFBUSxHQUFHLFNBQVM7RUFDbEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsSUFBSSxpQkFBaUIsS0FBSyxHQUFHO0dBQzNCLE1BQU0sY0FBYztHQUNwQixxQkFBcUIsV0FBVztHQUNoQyxNQUFNLFNBQVMsYUFBYSxHQUFHLElBQUk7R0FDbkMsSUFBSSxDQUFDLFlBQVksd0JBQ2YsYUFBYSxHQUFHLElBQUk7R0FFdEIsT0FBTztFQUNUO0VBQ0EsTUFBTSxTQUFTLGFBQWEsR0FBRyxJQUFJO0VBQ25DLGFBQWEsR0FBRyxJQUFJO0VBQ3BCLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxJQUFJLENBQUMsU0FDSCxPQUFPO0NBRVQsUUFBUSxHQUFHLFNBQVM7RUFDbEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsSUFBSSxpQkFBaUIsS0FBSyxHQUN4QixxQkFBcUIsS0FBSztFQUU1QixPQUFPLFFBQVEsR0FBRyxJQUFJO0NBQ3hCO0FBQ0Y7QUFDQSxTQUFnQixxQkFBcUIsT0FBTztDQUMxQyxNQUFNLDZCQUE2QjtFQUNqQyxNQUFNLHlCQUF5QjtDQUNqQztDQUNBLE9BQU87QUFDVDtBQUNBLFNBQWdCLGdCQUFnQixjQUFjLGdCQUFnQjtDQUM1RCxJQUFJLGdCQUFnQjtFQUNsQixJQUFJLGNBRUYsT0FBTyxpQkFBaUIsTUFBTTtFQUVoQyxPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBQy9CLE9BQU8sU0FBUyxRQUFRLE9BQU8sVUFBVSxZQUFZLGlCQUFpQjtBQUN4RTs7Ozs7Ozs7O0FFM01BLFNBQWdCLGNBQWMsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUN4QyxNQUFNLFVBQVUsZUFBZSxhQUFhLENBQUMsQ0FBQztDQUM5QyxJQUFJLFVBQVUsU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQy9CLE9BQU8sU0FBUztFQUFDO0VBQUc7RUFBRztFQUFHO0NBQUMsQ0FBQztDQUU5QixPQUFPLFFBQVE7QUFDakI7Ozs7OztBQU9BLFNBQWdCLGVBQWUsTUFBTTtDQUNuQyxNQUFNLFVBQVUsZUFBZSxhQUFhLENBQUMsQ0FBQztDQUM5QyxJQUFJLFdBQVcsU0FBUyxJQUFJLEdBQzFCLE9BQU8sU0FBUyxJQUFJO0NBRXRCLE9BQU8sUUFBUTtBQUNqQjtBQUNBLFNBQVMsZ0JBQWdCO0NBQ3ZCLE9BQU87RUFDTCxVQUFVO0VBQ1YsU0FBUztFQUNULE1BQU0sQ0FBQztDQUNUO0FBQ0Y7QUFDQSxTQUFTLFVBQVUsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBRXRDLE9BQU8sUUFBUSxLQUFLLE9BQU8sS0FBSyxRQUFRLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDeEc7QUFDQSxTQUFTLFdBQVcsU0FBUyxTQUFTO0NBQ3BDLE9BQU8sUUFBUSxLQUFLLFdBQVcsUUFBUSxVQUFVLFFBQVEsS0FBSyxNQUFNLEtBQUssVUFBVSxRQUFRLFFBQVEsTUFBTTtBQUMzRztBQUNBLFNBQVMsT0FBTyxTQUFTLE1BQU07Q0FDN0IsUUFBUSxPQUFPO0NBQ2YsSUFBSSxLQUFLLE9BQU0sUUFBTyxPQUFPLElBQUksR0FBRztFQUNsQyxRQUFRLFdBQVc7RUFDbkI7Q0FDRjtDQUNBLFFBQVEsWUFBVyxhQUFZO0VBQzdCLElBQUksUUFBUSxTQUFTO0dBQ25CLFFBQVEsUUFBUTtHQUNoQixRQUFRLFVBQVU7RUFDcEI7RUFDQSxJQUFJLFlBQVksTUFBTTtHQUNwQixNQUFNLG1CQUFtQixNQUFNLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxJQUFJO0dBQ3JELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSyxHQUFHO0lBQ3ZDLE1BQU0sTUFBTSxLQUFLO0lBQ2pCLElBQUksT0FBTyxNQUNUO0lBRUYsUUFBUSxPQUFPLEtBQWY7S0FDRSxLQUFLLFlBQ0g7TUFDRSxNQUFNLGFBQWEsSUFBSSxRQUFRO01BQy9CLElBQUksT0FBTyxlQUFlLFlBQ3hCLGlCQUFpQixLQUFLO01BRXhCO0tBQ0Y7S0FDRixLQUFLLFVBRUQsSUFBSSxVQUFVO0lBSXBCO0dBQ0Y7R0FDQSxRQUFRLGdCQUFnQjtJQUN0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssR0FBRztLQUN2QyxNQUFNLE1BQU0sS0FBSztLQUNqQixJQUFJLE9BQU8sTUFDVDtLQUVGLFFBQVEsT0FBTyxLQUFmO01BQ0UsS0FBSyxZQUNIO09BQ0UsTUFBTSxrQkFBa0IsaUJBQWlCO09BQ3pDLElBQUksT0FBTyxvQkFBb0IsWUFDN0IsZ0JBQWdCO1lBSWhCLElBQVMsSUFBSTtPQUVmO01BQ0Y7TUFDRixLQUFLLFVBRUQsSUFBSSxVQUFVO0tBSXBCO0lBQ0Y7R0FDRjtFQUNGO0NBQ0Y7QUFDRjs7QUM1R0EsSUFBTSxlQUFlLFNBQVMsVUFBZSxFQUFFO0FBQy9DLFNBQWdCLHNCQUFzQixxQkFBcUI7Q0FDekQsT0FBTyxnQkFBZ0I7QUFDekI7Ozs7O0FDRUEsU0FBZ0IsbUJBQW1CLFNBQVM7Q0FDMUMsSUFBSSxDQUFlLDJCQUFNLGVBQWUsT0FBTyxHQUM3QyxPQUFPO0NBRVQsTUFBTSxlQUFlO0NBQ3JCLE1BQU0sZUFBZSxhQUFhO0NBQ2xDLFFBQVEsc0JBQXNCLEVBQUUsSUFBSSxjQUFjLE1BQU0sYUFBYSxRQUFRO0FBQy9FOztBQ1pBLElBQWEsT0FBTyxjQUFjLFFBQVEsU0FBUzs7QUNEbkQsU0FBZ0IsT0FBTyxDQUFDO0FBS3hCLElBQWEsY0FBYyxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQzNDLElBQWEsZUFBZSxPQUFPLE9BQU8sQ0FBQyxDQUFDOztBQ041QyxTQUFnQix3QkFBd0IsT0FBTyxlQUFlO0NBQzVELE1BQU0sUUFBUSxDQUFDO0NBR2YsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN2QixNQUFNLFFBQVEsTUFBTTtFQUNwQixJQUFJLGVBQWUsZUFBZSxHQUFHLEdBQUc7R0FDdEMsTUFBTSxjQUFjLGNBQWMsSUFBSSxDQUFDLEtBQUs7R0FDNUMsSUFBSSxlQUFlLE1BQ2pCLE9BQU8sT0FBTyxPQUFPLFdBQVc7R0FFbEM7RUFDRjtFQUNBLElBQUksVUFBVSxNQUNaLE1BQU0sUUFBUSxJQUFJLFlBQVksT0FBTztPQUNoQyxJQUFJLE9BQ1QsTUFBTSxRQUFRLElBQUksWUFBWSxPQUFPLE1BQU0sU0FBUztDQUV4RDtDQUNBLE9BQU87QUFDVDs7Ozs7Ozs7O0FDYkEsU0FBZ0IsaUJBQWlCLFdBQVcsT0FBTztDQUNqRCxPQUFPLE9BQU8sY0FBYyxhQUFhLFVBQVUsS0FBSyxJQUFJO0FBQzlEOzs7Ozs7Ozs7QUNGQSxTQUFnQixhQUFhLE9BQU8sT0FBTztDQUN6QyxPQUFPLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0FBQ3REOzs7Ozs7Ozs7QUNTQSxTQUFnQixpQkFBaUIsU0FBUyxnQkFBZ0IsU0FBUyxDQUFDLEdBQUc7Q0FDckUsSUFBSSxhQUFhLGVBQWU7Q0FDaEMsSUFBSSxPQUFPLFlBQVksT0FFckIsYUFBYSxxQkFBcUIsVUFBVTtDQUU5QyxNQUFNLFdBQVcsc0JBQXNCLGdCQUFnQixRQUFRLFVBQVU7Q0FDekUsSUFBSSxPQUFPLFlBQVksT0FDckIsT0FBTztDQUVULE1BQU0sUUFBUSxPQUFPLFNBQVM7Q0FDOUIsT0FBTyxtQkFBbUIsU0FBUyxZQUFZLFVBQVUsS0FBSztBQUNoRTs7OztBQUtBLFNBQVMsc0JBQXNCLGdCQUFnQixRQUFRLFlBQVk7Q0FDakUsTUFBTSxFQUNKLFdBQVcsZUFDWCxPQUFPLGNBQ0w7Q0FDSixNQUFNLEVBQ0osUUFBUSxjQUNSLEtBQ0EsT0FDQSx3QkFDQSxVQUFVLFNBQ1I7Q0FDSixNQUFNLFlBQVksVUFBVSxpQkFBaUIsZUFBZSxLQUFLLElBQUksS0FBQTtDQUNyRSxNQUFNLFFBQVEsVUFBVSxhQUFhLFdBQVcsS0FBSyxJQUFJLEtBQUE7Q0FDekQsTUFBTSxhQUFhLFVBQVUsd0JBQXdCLE9BQU8sc0JBQXNCLElBQUk7Q0FDdEYsTUFBTSxnQkFBZ0IsV0FBVyxRQUFRLDJCQUEyQixLQUFLLElBQUksS0FBQTtDQUs3RSxNQUFNLFdBQVcsVUFBVSxhQUFhLFlBQVksYUFBYSxLQUFLLENBQUMsSUFBSTtDQVEzRSxJQUFJLE9BQU8sYUFBYSxhQUFhO0VBQ25DLElBQUksQ0FBQyxTQUVILGNBQW1CLE1BQU0sSUFBSTtPQUN4QixJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQzFCLFNBQVMsTUFBTSxlQUFlO0dBQUMsU0FBUztHQUFLLG1CQUFtQixVQUFVO0dBQUcsR0FBRztFQUFHLENBQUM7T0FFcEYsU0FBUyxNQUFNLGNBQWMsU0FBUyxLQUFLLG1CQUFtQixVQUFVLEdBQUcsR0FBRztDQUVsRjtDQUNBLElBQUksQ0FBQyxTQUNILE9BQU87Q0FFVCxJQUFJLGNBQWMsS0FBQSxHQUNoQixTQUFTLFlBQVksZ0JBQWdCLFNBQVMsV0FBVyxTQUFTO0NBRXBFLElBQUksVUFBVSxLQUFBLEdBQ1osU0FBUyxRQUFRLGFBQWEsU0FBUyxPQUFPLEtBQUs7Q0FFckQsT0FBTztBQUNUO0FBQ0EsU0FBUywyQkFBMkIsT0FBTztDQUN6QyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ3JCLE9BQU8sWUFBWSxLQUFLO0NBRTFCLE9BQU8sV0FBVyxLQUFBLEdBQVcsS0FBSztBQUNwQztBQU1BLElBQU0sa0JBQWtCLE9BQU8sSUFBSSxZQUFZO0FBQy9DLElBQU0sK0JBQStCO0FBQ3JDLElBQU0sOEJBQThCO0FBUXBDLFNBQWdCLHFCQUFxQixRQUFRO0NBRTNDLElBQUksUUFBUSxhQUFhLGlCQUN2QixPQUFPO0NBSVQsTUFBTSxZQUFBLGFBQWtCLFNBQVMsUUFBUSxNQUFNLENBQUMsQ0FBQztDQUNqRCxPQUFvQiwyQkFBTSxlQUFlLFNBQVMsSUFBSSxZQUFZO0FBQ3BFO0FBQ0EsU0FBUyxtQkFBbUIsU0FBUyxRQUFRLE9BQU8sT0FBTztDQUN6RCxJQUFJLFFBQVE7RUFDVixJQUFJLE9BQU8sV0FBVyxZQUFZO0dBRTlCLG1DQUFtQyxNQUFNO0dBRTNDLE9BQU8sT0FBTyxPQUFPLEtBQUs7RUFDNUI7RUFDQSxNQUFNLGNBQWMsV0FBVyxPQUFPLE9BQU8sS0FBSztFQUNsRCxZQUFZLE1BQU0sTUFBTTtFQVN0QixJQUFJLENBQWUsMkJBQU0sZUFBZSxNQUFNLEdBRzVDLE1BQU0sSUFBSSxNQUFNO0dBQUM7R0FBa0g7R0FBK0g7RUFBMkMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDO0VBRzdULE9BQW9CLDJCQUFNLGFBQWEsUUFBUSxXQUFXO0NBQzVEO0NBRUEsT0FBTyxVQUFVLFNBQVMsS0FBSztBQUNqQztBQUNBLFNBQVMsbUNBQW1DLFVBQVU7Q0FDcEQsTUFBTSxlQUFlLFNBQVM7Q0FDOUIsSUFBSSxhQUFhLFdBQVcsR0FDMUI7Q0FFRixJQUFJLENBQUMsNkJBQTZCLEtBQUssWUFBWSxHQUNqRDtDQUVGLElBQUksQ0FBQyw0QkFBNEIsS0FBSyxZQUFZLEdBQ2hEO0NBRUYsS0FBSyxtREFBbUQsYUFBYSwyQ0FBMkMscUZBQXFGLHlHQUF5RywwRkFBMEYsMkZBQTJGLDJDQUEyQztBQUNoaEI7QUFDQSxTQUFTLFVBQVUsS0FBSyxPQUFPO0NBQzdCLElBQUksUUFBUSxVQUNWLE9BQW9CLGVBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBZSxVQUFVO0VBQzNDLE1BQU07RUFDTixHQUFHO0VBQ0gsS0FBSyxNQUFNO0NBQ2IsQ0FBQztDQUVILElBQUksUUFBUSxPQUNWLE9BQW9CLGVBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBZSxPQUFPO0VBQ3hDLEtBQUs7RUFDTCxHQUFHO0VBQ0gsS0FBSyxNQUFNO0NBQ2IsQ0FBQztDQUVILE9BQW9CLDJCQUFNLGNBQWMsS0FBSyxLQUFLO0FBQ3BEIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTZdfQ==