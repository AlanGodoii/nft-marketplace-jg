import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/catalog-toolbar.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { Input } from "/src/components/ui/input.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-toolbar.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function CatalogToolbar({ total, filters, onFiltersChange, disabled }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "catalog-toolbar",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "desktop-catalog-tabs desktop-home-only",
				role: "group",
				"aria-label": "Categorias do catálogo",
				"aria-describedby": "catalog-tabs-policy",
				children: [
					["all", "Todos os NFTs"],
					["new", "Novos lançamentos"],
					["trending", "Em alta"]
				].map(([tab, label]) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled,
					"aria-pressed": (filters.tab ?? "all") === tab,
					onClick: () => onFiltersChange({
						...filters,
						tab
					}),
					children: label
				}, tab, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 125
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				id: "catalog-tabs-policy",
				className: "sr-only",
				children: "Novos lançamentos: publicados desde 1 de novembro de 2026. Em alta: seleção de edições disponíveis, sem estatística de vendas."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "catalog-heading flex flex-wrap items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "catalog-title",
					className: "text-2xl font-bold",
					children: "Explore os NFTs"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-muted-foreground",
					children: total !== undefined ? `${total} NFTs encontrados` : "Catálogo indisponível"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative min-w-0 flex-1",
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "nft-search",
							className: "sr-only",
							children: "Buscar NFTs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Search, {
							"aria-hidden": "true",
							className: "pointer-events-none absolute top-3.5 left-3 size-4 text-muted-foreground"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Input, {
							id: "nft-search",
							type: "search",
							placeholder: "Buscar NFTs",
							value: filters.search,
							disabled,
							onChange: (event) => onFiltersChange({
								...filters,
								search: event.target.value
							}),
							className: "h-11 rounded-sm pl-10"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "nft-sort",
						className: "shrink-0 text-xs text-muted-foreground",
						children: "Ordenar por"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: "nft-sort",
						className: "kurio-select min-w-0 flex-1 sm:w-40",
						disabled,
						value: filters.sort,
						onChange: (event) => onFiltersChange({
							...filters,
							sort: event.target.value
						}),
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "recent",
								children: "Mais recentes"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "price-asc",
								children: "Menor preço"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 34,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "price-desc",
								children: "Maior preço"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 35,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = CatalogToolbar;
var _c;
$RefreshReg$(_c, "CatalogToolbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/components/catalog-toolbar.tsx?t=1793942997333";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-toolbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-toolbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/components/catalog-toolbar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsYUFBYTs7O0FBUXRCLE9BQU8sU0FBUyxlQUFlLEVBQUUsT0FBTyxTQUFTLGlCQUFpQixZQUFtQjtDQUNuRixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUF5QyxNQUFLO0lBQVEsY0FBVztJQUF5QixvQkFBaUI7Y0FDdEg7S0FBQyxDQUFDLE9BQU8sZUFBZTtLQUFHLENBQUMsT0FBTyxtQkFBbUI7S0FBRyxDQUFDLFlBQVksU0FBUztJQUFDLENBQUMsQ0FBVyxLQUFLLENBQUMsS0FBSyxXQUFXLHdCQUFDLFVBQUQ7S0FBa0IsTUFBSztLQUFtQjtLQUFVLGlCQUFlLFFBQVEsT0FBTyxXQUFXO0tBQUssZUFBZSxnQkFBZ0I7TUFBRSxHQUFHO01BQVM7S0FBSSxDQUFDO2VBQUk7SUFBYyxHQUF6Sjs7OztXQUF5SixDQUFDO0dBQ3hSOzs7OztHQUNMLHdCQUFDLEtBQUQ7SUFBRyxJQUFHO0lBQXNCLFdBQVU7Y0FBVTtHQUFpSTs7Ozs7R0FDakwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxJQUFHO0tBQWdCLFdBQVU7ZUFBcUI7SUFBbUI7Ozs7Y0FDekUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBaUMsVUFBVSxZQUFZLEdBQUcsTUFBTSxxQkFBcUI7SUFBMkI7Ozs7WUFDMUg7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsU0FBRDtPQUFPLFNBQVE7T0FBYSxXQUFVO2lCQUFVO01BQWtCOzs7OztNQUNsRSx3QkFBQyxRQUFEO09BQVEsZUFBWTtPQUFPLFdBQVU7TUFBNEU7Ozs7O01BQ2pILHdCQUFDLE9BQUQ7T0FBTyxJQUFHO09BQWEsTUFBSztPQUFTLGFBQVk7T0FBYyxPQUFPLFFBQVE7T0FBa0I7T0FDOUYsV0FBVSxVQUFTLGdCQUFnQjtRQUFFLEdBQUc7UUFBUyxRQUFRLE1BQU0sT0FBTztPQUFNLENBQUM7T0FDN0UsV0FBVTtNQUF5Qjs7Ozs7S0FDbEM7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO01BQVcsV0FBVTtnQkFBeUM7S0FBa0I7Ozs7ZUFDL0Ysd0JBQUMsVUFBRDtNQUFRLElBQUc7TUFBVyxXQUFVO01BQWdEO01BQVUsT0FBTyxRQUFRO01BQ3ZHLFdBQVUsVUFBUyxnQkFBZ0I7T0FBRSxHQUFHO09BQVMsTUFBTSxNQUFNLE9BQU87TUFBNkIsQ0FBQztnQkFEcEc7T0FFRSx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBUztPQUFxQjs7Ozs7T0FDNUMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVk7T0FBbUI7Ozs7O09BQzdDLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFhO09BQW1COzs7OztNQUN4Qzs7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImNhdGFsb2ctdG9vbGJhci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2VhcmNoIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5pbXBvcnQgdHlwZSB7IENhdGFsb2dDb250cm9scyB9IGZyb20gJy4uL3R5cGVzJ1xuXG5pbnRlcmZhY2UgUHJvcHMgZXh0ZW5kcyBQaWNrPENhdGFsb2dDb250cm9scywgJ2ZpbHRlcnMnIHwgJ29uRmlsdGVyc0NoYW5nZSc+IHtcbiAgdG90YWw/OiBudW1iZXJcbiAgZGlzYWJsZWQ6IGJvb2xlYW5cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENhdGFsb2dUb29sYmFyKHsgdG90YWwsIGZpbHRlcnMsIG9uRmlsdGVyc0NoYW5nZSwgZGlzYWJsZWQgfTogUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctdG9vbGJhclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZXNrdG9wLWNhdGFsb2ctdGFicyBkZXNrdG9wLWhvbWUtb25seVwiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJDYXRlZ29yaWFzIGRvIGNhdMOhbG9nb1wiIGFyaWEtZGVzY3JpYmVkYnk9XCJjYXRhbG9nLXRhYnMtcG9saWN5XCI+XG4gICAgICAgIHsoW1snYWxsJywgJ1RvZG9zIG9zIE5GVHMnXSwgWyduZXcnLCAnTm92b3MgbGFuw6dhbWVudG9zJ10sIFsndHJlbmRpbmcnLCAnRW0gYWx0YSddXSBhcyBjb25zdCkubWFwKChbdGFiLCBsYWJlbF0pID0+IDxidXR0b24ga2V5PXt0YWJ9IHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17ZGlzYWJsZWR9IGFyaWEtcHJlc3NlZD17KGZpbHRlcnMudGFiID8/ICdhbGwnKSA9PT0gdGFifSBvbkNsaWNrPXsoKSA9PiBvbkZpbHRlcnNDaGFuZ2UoeyAuLi5maWx0ZXJzLCB0YWIgfSl9PntsYWJlbH08L2J1dHRvbj4pfVxuICAgICAgPC9kaXY+XG4gICAgICA8cCBpZD1cImNhdGFsb2ctdGFicy1wb2xpY3lcIiBjbGFzc05hbWU9XCJzci1vbmx5XCI+Tm92b3MgbGFuw6dhbWVudG9zOiBwdWJsaWNhZG9zIGRlc2RlIDEgZGUgbm92ZW1icm8gZGUgMjAyNi4gRW0gYWx0YTogc2VsZcOnw6NvIGRlIGVkacOnw7VlcyBkaXNwb27DrXZlaXMsIHNlbSBlc3RhdMOtc3RpY2EgZGUgdmVuZGFzLjwvcD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZy1oZWFkaW5nIGZsZXggZmxleC13cmFwIGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICA8aDIgaWQ9XCJjYXRhbG9nLXRpdGxlXCIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkXCI+RXhwbG9yZSBvcyBORlRzPC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57dG90YWwgIT09IHVuZGVmaW5lZCA/IGAke3RvdGFsfSBORlRzIGVuY29udHJhZG9zYCA6ICdDYXTDoWxvZ28gaW5kaXNwb27DrXZlbCd9PC9wPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBmbGV4LWNvbCBnYXAtMyBzbTpmbGV4LXJvd1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZnQtc2VhcmNoXCIgY2xhc3NOYW1lPVwic3Itb25seVwiPkJ1c2NhciBORlRzPC9sYWJlbD5cbiAgICAgICAgICA8U2VhcmNoIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgdG9wLTMuNSBsZWZ0LTMgc2l6ZS00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgPElucHV0IGlkPVwibmZ0LXNlYXJjaFwiIHR5cGU9XCJzZWFyY2hcIiBwbGFjZWhvbGRlcj1cIkJ1c2NhciBORlRzXCIgdmFsdWU9e2ZpbHRlcnMuc2VhcmNofSBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gb25GaWx0ZXJzQ2hhbmdlKHsgLi4uZmlsdGVycywgc2VhcmNoOiBldmVudC50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHJvdW5kZWQtc20gcGwtMTBcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmZ0LXNvcnRcIiBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk9yZGVuYXIgcG9yPC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0IGlkPVwibmZ0LXNvcnRcIiBjbGFzc05hbWU9XCJrdXJpby1zZWxlY3QgbWluLXctMCBmbGV4LTEgc206dy00MFwiIGRpc2FibGVkPXtkaXNhYmxlZH0gdmFsdWU9e2ZpbHRlcnMuc29ydH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtldmVudCA9PiBvbkZpbHRlcnNDaGFuZ2UoeyAuLi5maWx0ZXJzLCBzb3J0OiBldmVudC50YXJnZXQudmFsdWUgYXMgdHlwZW9mIGZpbHRlcnMuc29ydCB9KX0+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicmVjZW50XCI+TWFpcyByZWNlbnRlczwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInByaWNlLWFzY1wiPk1lbm9yIHByZcOnbzwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInByaWNlLWRlc2NcIj5NYWlvciBwcmXDp288L29wdGlvbj5cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19