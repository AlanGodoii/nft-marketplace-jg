import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/catalog-page.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { Route } from "/src/routes/index.tsx?t=1793942997333";
import { apiErrorMessage } from "/src/lib/api.ts";
import { nftKeys } from "/src/lib/query-keys.ts";
import { HomePage } from "/src/features/catalog/home-page.tsx?t=1793942997333";
import { useCatalog } from "/src/features/catalog/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/catalog-page.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function CatalogPage() {
	_s();
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	const queryClient = useQueryClient();
	const query = useCatalog(search);
	const catalog = query.isPending ? { status: "loading" } : query.isError ? {
		status: "error",
		message: apiErrorMessage(query.error)
	} : {
		status: "success",
		data: query.data
	};
	const metadata = query.data ?? queryClient.getQueriesData({ queryKey: nftKeys.lists() }).map(([, data]) => data).find((data) => data !== undefined);
	const onFiltersChange = (filters) => void navigate({
		search: (previous) => ({
			...previous,
			...filters,
			page: 1
		}),
		resetScroll: false
	});
	return /* @__PURE__ */ _jsxDEV(HomePage, {
		catalog,
		options: metadata,
		updating: query.isFetching && !query.isPending,
		onRefresh: () => void queryClient.invalidateQueries({
			queryKey: nftKeys.list(search),
			exact: true
		}),
		onRetry: () => void query.refetch(),
		controls: {
			filters: search,
			onFiltersChange,
			onPageChange: (page) => {
				void navigate({
					search: (previous) => ({
						...previous,
						page
					}),
					resetScroll: false
				});
			}
		}
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 10
	}, this);
}
_s(CatalogPage, "h93ViGUZMM745ulCHOdzqCv4ecE=", false, function() {
	return [
		Route.useSearch,
		Route.useNavigate,
		useQueryClient,
		useCatalog
	];
});
_c = CatalogPage;
var _c;
$RefreshReg$(_c, "CatalogPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/catalog-page.tsx?t=1793942997333";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/catalog-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/catalog-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/catalog-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxhQUFhO0FBR3RCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGtCQUFrQjs7OztBQUczQixPQUFPLFNBQVMsY0FBYzs7Q0FDNUIsTUFBTSxTQUFTLE1BQU0sVUFBVTtDQUMvQixNQUFNLFdBQVcsTUFBTSxZQUFZO0NBQ25DLE1BQU0sY0FBYyxlQUFlO0NBQ25DLE1BQU0sUUFBUSxXQUFXLE1BQU07Q0FDL0IsTUFBTSxVQUF1QyxNQUFNLFlBQVksRUFBRSxRQUFRLFVBQVUsSUFDL0UsTUFBTSxVQUFVO0VBQUUsUUFBUTtFQUFTLFNBQVMsZ0JBQWdCLE1BQU0sS0FBSztDQUFFLElBQ3ZFO0VBQUUsUUFBUTtFQUFXLE1BQU0sTUFBTTtDQUFLO0NBQzVDLE1BQU0sV0FBVyxNQUFNLFFBQVEsWUFBWSxlQUFnQyxFQUFFLFVBQVUsUUFBUSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQUMsTUFBSyxTQUFRLFNBQVMsU0FBUztDQUNqSyxNQUFNLG1CQUFtQixZQUE0QixLQUFLLFNBQVM7RUFBRSxTQUFRLGNBQWE7R0FBRSxHQUFHO0dBQVUsR0FBRztHQUFTLE1BQU07RUFBRTtFQUFJLGFBQWE7Q0FBTSxDQUFDO0NBQ3JKLE9BQU8sd0JBQUMsVUFBRDtFQUFtQjtFQUFTLFNBQVM7RUFBVSxVQUFVLE1BQU0sY0FBYyxDQUFDLE1BQU07RUFDekYsaUJBQWlCLEtBQUssWUFBWSxrQkFBa0I7R0FBRSxVQUFVLFFBQVEsS0FBSyxNQUFNO0dBQUcsT0FBTztFQUFLLENBQUM7RUFDbkcsZUFBZSxLQUFLLE1BQU0sUUFBUTtFQUNsQyxVQUFVO0dBQUUsU0FBUztHQUFRO0dBQzNCLGVBQWMsU0FBUTtJQUFFLEtBQUssU0FBUztLQUFFLFNBQVEsY0FBYTtNQUFFLEdBQUc7TUFBVTtLQUFLO0tBQUksYUFBYTtJQUFNLENBQUM7R0FBRTtFQUM3RztDQUFJOzs7OztBQUNSIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImNhdGFsb2ctcGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBSb3V0ZSB9IGZyb20gJ0Avcm91dGVzL2luZGV4J1xuaW1wb3J0IHR5cGUgeyBDYXRhbG9nUGFnZSBhcyBDYXRhbG9nUmVzcG9uc2UgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnXG5pbXBvcnQgdHlwZSB7IENhdGFsb2dGaWx0ZXJzIH0gZnJvbSAnQC9jb250cmFjdHMvY2F0YWxvZydcbmltcG9ydCB7IGFwaUVycm9yTWVzc2FnZSB9IGZyb20gJ0AvbGliL2FwaSdcbmltcG9ydCB7IG5mdEtleXMgfSBmcm9tICdAL2xpYi9xdWVyeS1rZXlzJ1xuaW1wb3J0IHsgSG9tZVBhZ2UgfSBmcm9tICcuL2hvbWUtcGFnZSdcbmltcG9ydCB7IHVzZUNhdGFsb2cgfSBmcm9tICcuL3F1ZXJpZXMnXG5pbXBvcnQgdHlwZSB7IFJlbW90ZURhdGEgfSBmcm9tICcuL3R5cGVzJ1xuXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1BhZ2UoKSB7XG4gIGNvbnN0IHNlYXJjaCA9IFJvdXRlLnVzZVNlYXJjaCgpXG4gIGNvbnN0IG5hdmlnYXRlID0gUm91dGUudXNlTmF2aWdhdGUoKVxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgY29uc3QgcXVlcnkgPSB1c2VDYXRhbG9nKHNlYXJjaClcbiAgY29uc3QgY2F0YWxvZzogUmVtb3RlRGF0YTxDYXRhbG9nUmVzcG9uc2U+ID0gcXVlcnkuaXNQZW5kaW5nID8geyBzdGF0dXM6ICdsb2FkaW5nJyB9XG4gICAgOiBxdWVyeS5pc0Vycm9yID8geyBzdGF0dXM6ICdlcnJvcicsIG1lc3NhZ2U6IGFwaUVycm9yTWVzc2FnZShxdWVyeS5lcnJvcikgfVxuICAgICAgOiB7IHN0YXR1czogJ3N1Y2Nlc3MnLCBkYXRhOiBxdWVyeS5kYXRhIH1cbiAgY29uc3QgbWV0YWRhdGEgPSBxdWVyeS5kYXRhID8/IHF1ZXJ5Q2xpZW50LmdldFF1ZXJpZXNEYXRhPENhdGFsb2dSZXNwb25zZT4oeyBxdWVyeUtleTogbmZ0S2V5cy5saXN0cygpIH0pLm1hcCgoWywgZGF0YV0pID0+IGRhdGEpLmZpbmQoZGF0YSA9PiBkYXRhICE9PSB1bmRlZmluZWQpXG4gIGNvbnN0IG9uRmlsdGVyc0NoYW5nZSA9IChmaWx0ZXJzOiBDYXRhbG9nRmlsdGVycykgPT4gdm9pZCBuYXZpZ2F0ZSh7IHNlYXJjaDogcHJldmlvdXMgPT4gKHsgLi4ucHJldmlvdXMsIC4uLmZpbHRlcnMsIHBhZ2U6IDEgfSksIHJlc2V0U2Nyb2xsOiBmYWxzZSB9KVxuICByZXR1cm4gPEhvbWVQYWdlIGNhdGFsb2c9e2NhdGFsb2d9IG9wdGlvbnM9e21ldGFkYXRhfSB1cGRhdGluZz17cXVlcnkuaXNGZXRjaGluZyAmJiAhcXVlcnkuaXNQZW5kaW5nfVxuICAgIG9uUmVmcmVzaD17KCkgPT4gdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBuZnRLZXlzLmxpc3Qoc2VhcmNoKSwgZXhhY3Q6IHRydWUgfSl9XG4gICAgb25SZXRyeT17KCkgPT4gdm9pZCBxdWVyeS5yZWZldGNoKCl9XG4gICAgY29udHJvbHM9e3sgZmlsdGVyczogc2VhcmNoLCBvbkZpbHRlcnNDaGFuZ2UsXG4gICAgICBvblBhZ2VDaGFuZ2U6IHBhZ2UgPT4geyB2b2lkIG5hdmlnYXRlKHsgc2VhcmNoOiBwcmV2aW91cyA9PiAoeyAuLi5wcmV2aW91cywgcGFnZSB9KSwgcmVzZXRTY3JvbGw6IGZhbHNlIH0pIH0sXG4gICAgfX0gLz5cbn1cbiJdfQ==