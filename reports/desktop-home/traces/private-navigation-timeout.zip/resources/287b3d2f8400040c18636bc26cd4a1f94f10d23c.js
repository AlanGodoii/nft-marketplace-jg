import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/wallets/wallets-page.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport11_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=22c23eb4";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=22c23eb4";
import { walletInputSchema } from "/src/contracts/wallet.ts";
import { useSession } from "/src/features/auth/api.ts";
import { LoadingState, ErrorState } from "/src/components/async-state.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { apiErrorMessage } from "/src/lib/api.ts";
import { CollectorFields } from "/src/features/wallets/collector-fields.tsx";
import { useSaveWallet, useWallets } from "/src/features/wallets/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/wallets/wallets-page.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
function WalletForm({ wallet, close }) {
	_s();
	const session = useSession();
	const save = useSaveWallet();
	const form = useForm({
		resolver: zodResolver(walletInputSchema),
		defaultValues: wallet ? {
			label: wallet.label,
			role: wallet.role,
			network: wallet.network,
			address: wallet.address,
			provider: wallet.provider,
			secondaryAddress: wallet.secondaryAddress,
			collector: wallet.collector
		} : {
			label: "",
			role: "secondary",
			network: "ethereum",
			address: "",
			provider: "metamask",
			secondaryAddress: "",
			collector: {
				displayName: session.data?.user.name ?? "",
				username: "",
				profileName: "",
				email: session.data?.user.email ?? "",
				referralCode: "",
				ensName: "",
				notes: ""
			}
		}
	});
	return /* @__PURE__ */ _jsxDEV("form", {
		noValidate: true,
		className: "commerce-panel space-y-6",
		"aria-label": wallet ? "Editar carteira" : "Cadastrar carteira",
		onSubmit: form.handleSubmit((values) => save.mutate({
			id: wallet?.id,
			input: values
		}, { onSuccess: close })),
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-bold",
				children: wallet ? "Editar carteira" : "Cadastrar carteira"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(CollectorFields, {
				form,
				prefix: "wallet"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "commerce-form-grid",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "wallet-label",
							children: "Apelido da carteira"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 12
						}, this),
						/* @__PURE__ */ _jsxDEV(Input, {
							id: "wallet-label",
							...form.register("label"),
							"aria-invalid": !!form.formState.errors.label,
							"aria-describedby": "wallet-label-error"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 69
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							id: "wallet-label-error",
							className: "field-error",
							children: form.formState.errors.label?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 207
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "wallet-role",
						children: "Papel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 12
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: "wallet-role",
						...form.register("role"),
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "primary",
							children: "Principal"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 106
						}, this), /* @__PURE__ */ _jsxDEV("option", {
							value: "secondary",
							children: "Secundária"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 148
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 54
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "wallet-network",
						children: "Rede"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 12
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: "wallet-network",
						...form.register("network"),
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "ethereum",
								children: "Ethereum"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 24,
								columnNumber: 114
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "polygon",
								children: "Polygon"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 24,
								columnNumber: 156
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "solana",
								children: "Solana"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 24,
								columnNumber: 196
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 56
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "wallet-provider",
						children: "Tipo de carteira"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 12
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						id: "wallet-provider",
						...form.register("provider"),
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "metamask",
								children: "MetaMask"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 129
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "walletconnect",
								children: "WalletConnect"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 171
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "coinbase",
								children: "Coinbase Wallet"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 223
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 69
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "commerce-wide",
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "wallet-address",
								children: "Endereço da carteira"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 26,
								columnNumber: 38
							}, this),
							/* @__PURE__ */ _jsxDEV(Input, {
								id: "wallet-address",
								...form.register("address"),
								"aria-invalid": !!form.formState.errors.address,
								"aria-describedby": "wallet-address-error"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 26,
								columnNumber: 98
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								id: "wallet-address-error",
								className: "field-error",
								children: form.formState.errors.address?.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 26,
								columnNumber: 244
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "commerce-wide",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "wallet-secondary",
							children: "ENS ou carteira secundária (opcional)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 38
						}, this), /* @__PURE__ */ _jsxDEV(Input, {
							id: "wallet-secondary",
							...form.register("secondaryAddress")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 117
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 5
			}, this),
			save.isError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: apiErrorMessage(save.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 22
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap gap-4",
				children: [/* @__PURE__ */ _jsxDEV(Button, {
					type: "submit",
					disabled: save.isPending,
					children: save.isPending ? "Salvando…" : "Salvar carteira"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 43
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					type: "button",
					variant: "outline",
					onClick: close,
					children: "Cancelar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 150
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 10
	}, this);
}
_s(WalletForm, "CfwYcXnloqPZiq3YejWoawV85ik=", false, function() {
	return [
		useSession,
		useSaveWallet,
		useForm
	];
});
_c = WalletForm;
export function WalletsPage() {
	_s2();
	const query = useWallets();
	const [editing, setEditing] = useState(null);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-3xl font-bold",
				children: "Carteiras"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 41
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: "Gerencie sua carteira principal e secundária. A conexão é simulada, sem extensões." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 90
			}, this),
			query.isPending ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: "Carregando carteiras" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 24
			}, this) : query.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
				message: apiErrorMessage(query.error),
				retry: () => void query.refetch()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 88
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "wallet-list",
					children: query.data.items.length ? query.data.items.map((wallet) => /* @__PURE__ */ _jsxDEV("article", {
						className: "commerce-panel space-y-3",
						"data-testid": "wallet-card",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "font-bold",
								children: [
									wallet.label,
									" · ",
									wallet.role === "primary" ? "Principal" : "Secundária"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 182
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								wallet.network,
								" · ",
								wallet.provider
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 286
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "break-all",
								children: wallet.address
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 329
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								variant: "outline",
								onClick: () => setEditing(wallet),
								children: ["Editar ", wallet.label]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 374
							}, this)
						]
					}, wallet.id, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 94
					}, this)) : /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						children: "Nenhuma carteira cadastrada."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 479
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 7
				}, this),
				!editing && /* @__PURE__ */ _jsxDEV(Button, {
					onClick: () => setEditing("new"),
					children: "Adicionar carteira"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 20
				}, this),
				editing && /* @__PURE__ */ _jsxDEV(WalletForm, {
					wallet: editing === "new" ? undefined : editing,
					close: () => setEditing(null)
				}, editing === "new" ? "new" : `${editing.id}-${editing.version}`, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 19
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 179
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 10
	}, this);
}
_s2(WalletsPage, "GUffqhm46rEx0QIE4MwKobUr7wI=", false, function() {
	return [useWallets];
});
_c2 = WalletsPage;
var _c, _c2;
$RefreshReg$(_c, "WalletForm");
$RefreshReg$(_c2, "WalletsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/wallets/wallets-page.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/wallets/wallets-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/wallets/wallets-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/wallets/wallets-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMseUJBQXdEO0FBQ2pFLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYyxrQkFBa0I7QUFDekMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsYUFBYTtBQUN0QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLGVBQWUsa0JBQWtCOzs7O0FBQzFDLFNBQVMsV0FBVyxFQUFFLFFBQVEsU0FBaUQ7O0NBQzdFLE1BQU0sVUFBVSxXQUFXO0NBQUcsTUFBTSxPQUFPLGNBQWM7Q0FDekQsTUFBTSxPQUFPLFFBQXFCO0VBQUUsVUFBVSxZQUFZLGlCQUFpQjtFQUFHLGVBQWUsU0FBUztHQUFFLE9BQU8sT0FBTztHQUFPLE1BQU0sT0FBTztHQUFNLFNBQVMsT0FBTztHQUFTLFNBQVMsT0FBTztHQUFTLFVBQVUsT0FBTztHQUFVLGtCQUFrQixPQUFPO0dBQWtCLFdBQVcsT0FBTztFQUFVLElBQUk7R0FDdFMsT0FBTztHQUFJLE1BQU07R0FBYSxTQUFTO0dBQVksU0FBUztHQUFJLFVBQVU7R0FBWSxrQkFBa0I7R0FDeEcsV0FBVztJQUFFLGFBQWEsUUFBUSxNQUFNLEtBQUssUUFBUTtJQUFJLFVBQVU7SUFBSSxhQUFhO0lBQUksT0FBTyxRQUFRLE1BQU0sS0FBSyxTQUFTO0lBQUksY0FBYztJQUFJLFNBQVM7SUFBSSxPQUFPO0dBQUc7RUFDMUs7Q0FBRSxDQUFDO0NBQ0gsT0FBTyx3QkFBQyxRQUFEO0VBQU07RUFBVyxXQUFVO0VBQTJCLGNBQVksU0FBUyxvQkFBb0I7RUFBc0IsVUFBVSxLQUFLLGNBQWEsV0FBVSxLQUFLLE9BQU87R0FBRSxJQUFJLFFBQVE7R0FBSSxPQUFPO0VBQU8sR0FBRyxFQUFFLFdBQVcsTUFBTSxDQUFDLENBQUM7WUFBL047R0FDTCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFxQixTQUFTLG9CQUFvQjtHQUF5Qjs7Ozs7R0FDekYsd0JBQUMsaUJBQUQ7SUFBdUI7SUFBTSxRQUFPO0dBQVU7Ozs7O0dBQzlDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssd0JBQUMsU0FBRDtPQUFPLFNBQVE7aUJBQWU7TUFBMEI7Ozs7O01BQUMsd0JBQUMsT0FBRDtPQUFPLElBQUc7T0FBZSxHQUFJLEtBQUssU0FBUyxPQUFPO09BQUcsZ0JBQWMsQ0FBQyxDQUFDLEtBQUssVUFBVSxPQUFPO09BQU8sb0JBQWlCO01BQXNCOzs7OztNQUFDLHdCQUFDLEtBQUQ7T0FBRyxJQUFHO09BQXFCLFdBQVU7aUJBQWUsS0FBSyxVQUFVLE9BQU8sT0FBTztNQUFXOzs7OztLQUFNOzs7OztLQUMxUyx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQWM7S0FBWTs7OztlQUFDLHdCQUFDLFVBQUQ7TUFBUSxJQUFHO01BQWMsR0FBSSxLQUFLLFNBQVMsTUFBTTtnQkFBakQsQ0FBb0Qsd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQVU7TUFBaUI7Ozs7Z0JBQUMsd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQVk7TUFBa0I7Ozs7Y0FBUzs7Ozs7YUFBTTs7Ozs7S0FDeE0sd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUFpQjtLQUFXOzs7O2VBQUMsd0JBQUMsVUFBRDtNQUFRLElBQUc7TUFBaUIsR0FBSSxLQUFLLFNBQVMsU0FBUztnQkFBdkQ7T0FBMEQsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVc7T0FBZ0I7Ozs7O09BQUMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVU7T0FBZTs7Ozs7T0FBQyx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBUztPQUFjOzs7OztNQUFTOzs7OzthQUFNOzs7OztLQUNqUCx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQWtCO0tBQXVCOzs7O2VBQUMsd0JBQUMsVUFBRDtNQUFRLElBQUc7TUFBa0IsR0FBSSxLQUFLLFNBQVMsVUFBVTtnQkFBekQ7T0FBNEQsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVc7T0FBZ0I7Ozs7O09BQUMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWdCO09BQXFCOzs7OztPQUFDLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFXO09BQXVCOzs7OztNQUFTOzs7OzthQUFNOzs7OztLQUN2Uix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUErQix3QkFBQyxTQUFEO1FBQU8sU0FBUTtrQkFBaUI7T0FBMkI7Ozs7O09BQUMsd0JBQUMsT0FBRDtRQUFPLElBQUc7UUFBaUIsR0FBSSxLQUFLLFNBQVMsU0FBUztRQUFHLGdCQUFjLENBQUMsQ0FBQyxLQUFLLFVBQVUsT0FBTztRQUFTLG9CQUFpQjtPQUF3Qjs7Ozs7T0FBQyx3QkFBQyxLQUFEO1FBQUcsSUFBRztRQUF1QixXQUFVO2tCQUFlLEtBQUssVUFBVSxPQUFPLFNBQVM7T0FBVzs7Ozs7TUFBTTs7Ozs7O0tBQ25WLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQStCLHdCQUFDLFNBQUQ7T0FBTyxTQUFRO2lCQUFtQjtNQUE0Qzs7OztnQkFBQyx3QkFBQyxPQUFEO09BQU8sSUFBRztPQUFtQixHQUFJLEtBQUssU0FBUyxrQkFBa0I7TUFBSTs7OztjQUFNOzs7Ozs7SUFDdEw7Ozs7OztHQUNKLEtBQUssV0FBVyx3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFTLGdCQUFnQixLQUFLLEtBQUs7R0FBSzs7Ozs7R0FDakUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUFzQyx3QkFBQyxRQUFEO0tBQVEsTUFBSztLQUFTLFVBQVUsS0FBSztlQUFZLEtBQUssWUFBWSxjQUFjO0lBQTBCOzs7O2NBQUMsd0JBQUMsUUFBRDtLQUFRLE1BQUs7S0FBUyxTQUFRO0tBQVUsU0FBUztlQUFPO0lBQWdCOzs7O1lBQU07Ozs7OztFQUMzTjs7Ozs7O0FBQ1I7Ozs7Ozs7OztBQUNBLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLFFBQVEsV0FBVztDQUFHLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBZ0MsSUFBSTtDQUM5RixPQUFPLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQStCLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXFCO0dBQWE7Ozs7O0dBQUMsd0JBQUMsS0FBRCxZQUFHLHFGQUFxRjs7Ozs7R0FDNUssTUFBTSxZQUFZLHdCQUFDLGNBQUQsRUFBYyxPQUFNLHVCQUF3Qjs7OztjQUFJLE1BQU0sVUFBVSx3QkFBQyxZQUFEO0lBQVksU0FBUyxnQkFBZ0IsTUFBTSxLQUFLO0lBQUcsYUFBYSxLQUFLLE1BQU0sUUFBUTtHQUFJOzs7O2NBQUk7SUFDNUssd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZSxNQUFNLEtBQUssTUFBTSxTQUFTLE1BQU0sS0FBSyxNQUFNLEtBQUksV0FBVSx3QkFBQyxXQUFEO01BQVMsV0FBVTtNQUEyQixlQUFZO2dCQUExRDtPQUF3Rix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUEyQixPQUFPO1NBQU07U0FBSSxPQUFPLFNBQVMsWUFBWSxjQUFjO1FBQWlCOzs7Ozs7T0FBQyx3QkFBQyxLQUFEO1FBQUksT0FBTztRQUFRO1FBQUksT0FBTztPQUFZOzs7OztPQUFDLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFhLE9BQU87T0FBVzs7Ozs7T0FBQyx3QkFBQyxRQUFEO1FBQVEsU0FBUTtRQUFVLGVBQWUsV0FBVyxNQUFNO2tCQUExRCxDQUE2RCxXQUFRLE9BQU8sS0FBYzs7Ozs7O01BQVU7UUFBL1MsT0FBTzs7OztZQUF3UyxDQUFDLElBQUksd0JBQUMsS0FBRDtNQUFHLE1BQUs7Z0JBQVM7S0FBK0I7Ozs7O0lBQU87Ozs7O0lBQzlnQixDQUFDLFdBQVcsd0JBQUMsUUFBRDtLQUFRLGVBQWUsV0FBVyxLQUFLO2VBQUc7SUFBMEI7Ozs7O0lBQ2hGLFdBQVcsd0JBQUMsWUFBRDtLQUFZLFFBQVEsWUFBWSxRQUFRLFlBQVk7S0FBUyxhQUFhLFdBQVcsSUFBSTtJQUF5RSxHQUFqRSxZQUFZLFFBQVEsUUFBUSxHQUFHLFFBQVEsR0FBRyxHQUFHLFFBQVE7Ozs7V0FBWTtHQUM5Szs7Ozs7RUFDSzs7Ozs7O0FBQ1giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsid2FsbGV0cy1wYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnXG5pbXBvcnQgeyB3YWxsZXRJbnB1dFNjaGVtYSwgdHlwZSBXYWxsZXQsIHR5cGUgV2FsbGV0SW5wdXQgfSBmcm9tICdAL2NvbnRyYWN0cy93YWxsZXQnXG5pbXBvcnQgeyB1c2VTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2FwaSdcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSwgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9hc3luYy1zdGF0ZSdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7IGFwaUVycm9yTWVzc2FnZSB9IGZyb20gJ0AvbGliL2FwaSdcbmltcG9ydCB7IENvbGxlY3RvckZpZWxkcyB9IGZyb20gJy4vY29sbGVjdG9yLWZpZWxkcydcbmltcG9ydCB7IHVzZVNhdmVXYWxsZXQsIHVzZVdhbGxldHMgfSBmcm9tICcuL3F1ZXJpZXMnXG5mdW5jdGlvbiBXYWxsZXRGb3JtKHsgd2FsbGV0LCBjbG9zZSB9OiB7IHdhbGxldD86IFdhbGxldDsgY2xvc2U6ICgpID0+IHZvaWQgfSkge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpOyBjb25zdCBzYXZlID0gdXNlU2F2ZVdhbGxldCgpXG4gIGNvbnN0IGZvcm0gPSB1c2VGb3JtPFdhbGxldElucHV0Pih7IHJlc29sdmVyOiB6b2RSZXNvbHZlcih3YWxsZXRJbnB1dFNjaGVtYSksIGRlZmF1bHRWYWx1ZXM6IHdhbGxldCA/IHsgbGFiZWw6IHdhbGxldC5sYWJlbCwgcm9sZTogd2FsbGV0LnJvbGUsIG5ldHdvcms6IHdhbGxldC5uZXR3b3JrLCBhZGRyZXNzOiB3YWxsZXQuYWRkcmVzcywgcHJvdmlkZXI6IHdhbGxldC5wcm92aWRlciwgc2Vjb25kYXJ5QWRkcmVzczogd2FsbGV0LnNlY29uZGFyeUFkZHJlc3MsIGNvbGxlY3Rvcjogd2FsbGV0LmNvbGxlY3RvciB9IDoge1xuICAgIGxhYmVsOiAnJywgcm9sZTogJ3NlY29uZGFyeScsIG5ldHdvcms6ICdldGhlcmV1bScsIGFkZHJlc3M6ICcnLCBwcm92aWRlcjogJ21ldGFtYXNrJywgc2Vjb25kYXJ5QWRkcmVzczogJycsXG4gICAgY29sbGVjdG9yOiB7IGRpc3BsYXlOYW1lOiBzZXNzaW9uLmRhdGE/LnVzZXIubmFtZSA/PyAnJywgdXNlcm5hbWU6ICcnLCBwcm9maWxlTmFtZTogJycsIGVtYWlsOiBzZXNzaW9uLmRhdGE/LnVzZXIuZW1haWwgPz8gJycsIHJlZmVycmFsQ29kZTogJycsIGVuc05hbWU6ICcnLCBub3RlczogJycgfSxcbiAgfSB9KVxuICByZXR1cm4gPGZvcm0gbm9WYWxpZGF0ZSBjbGFzc05hbWU9XCJjb21tZXJjZS1wYW5lbCBzcGFjZS15LTZcIiBhcmlhLWxhYmVsPXt3YWxsZXQgPyAnRWRpdGFyIGNhcnRlaXJhJyA6ICdDYWRhc3RyYXIgY2FydGVpcmEnfSBvblN1Ym1pdD17Zm9ybS5oYW5kbGVTdWJtaXQodmFsdWVzID0+IHNhdmUubXV0YXRlKHsgaWQ6IHdhbGxldD8uaWQsIGlucHV0OiB2YWx1ZXMgfSwgeyBvblN1Y2Nlc3M6IGNsb3NlIH0pKX0+XG4gICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkXCI+e3dhbGxldCA/ICdFZGl0YXIgY2FydGVpcmEnIDogJ0NhZGFzdHJhciBjYXJ0ZWlyYSd9PC9oMj5cbiAgICA8Q29sbGVjdG9yRmllbGRzIGZvcm09e2Zvcm19IHByZWZpeD1cIndhbGxldFwiIC8+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb21tZXJjZS1mb3JtLWdyaWRcIj5cbiAgICAgIDxkaXY+PGxhYmVsIGh0bWxGb3I9XCJ3YWxsZXQtbGFiZWxcIj5BcGVsaWRvIGRhIGNhcnRlaXJhPC9sYWJlbD48SW5wdXQgaWQ9XCJ3YWxsZXQtbGFiZWxcIiB7Li4uZm9ybS5yZWdpc3RlcignbGFiZWwnKX0gYXJpYS1pbnZhbGlkPXshIWZvcm0uZm9ybVN0YXRlLmVycm9ycy5sYWJlbH0gYXJpYS1kZXNjcmliZWRieT1cIndhbGxldC1sYWJlbC1lcnJvclwiIC8+PHAgaWQ9XCJ3YWxsZXQtbGFiZWwtZXJyb3JcIiBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntmb3JtLmZvcm1TdGF0ZS5lcnJvcnMubGFiZWw/Lm1lc3NhZ2V9PC9wPjwvZGl2PlxuICAgICAgPGRpdj48bGFiZWwgaHRtbEZvcj1cIndhbGxldC1yb2xlXCI+UGFwZWw8L2xhYmVsPjxzZWxlY3QgaWQ9XCJ3YWxsZXQtcm9sZVwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdyb2xlJyl9PjxvcHRpb24gdmFsdWU9XCJwcmltYXJ5XCI+UHJpbmNpcGFsPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cInNlY29uZGFyeVwiPlNlY3VuZMOhcmlhPC9vcHRpb24+PC9zZWxlY3Q+PC9kaXY+XG4gICAgICA8ZGl2PjxsYWJlbCBodG1sRm9yPVwid2FsbGV0LW5ldHdvcmtcIj5SZWRlPC9sYWJlbD48c2VsZWN0IGlkPVwid2FsbGV0LW5ldHdvcmtcIiB7Li4uZm9ybS5yZWdpc3RlcignbmV0d29yaycpfT48b3B0aW9uIHZhbHVlPVwiZXRoZXJldW1cIj5FdGhlcmV1bTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJwb2x5Z29uXCI+UG9seWdvbjwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJzb2xhbmFcIj5Tb2xhbmE8L29wdGlvbj48L3NlbGVjdD48L2Rpdj5cbiAgICAgIDxkaXY+PGxhYmVsIGh0bWxGb3I9XCJ3YWxsZXQtcHJvdmlkZXJcIj5UaXBvIGRlIGNhcnRlaXJhPC9sYWJlbD48c2VsZWN0IGlkPVwid2FsbGV0LXByb3ZpZGVyXCIgey4uLmZvcm0ucmVnaXN0ZXIoJ3Byb3ZpZGVyJyl9PjxvcHRpb24gdmFsdWU9XCJtZXRhbWFza1wiPk1ldGFNYXNrPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cIndhbGxldGNvbm5lY3RcIj5XYWxsZXRDb25uZWN0PC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cImNvaW5iYXNlXCI+Q29pbmJhc2UgV2FsbGV0PC9vcHRpb24+PC9zZWxlY3Q+PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbW1lcmNlLXdpZGVcIj48bGFiZWwgaHRtbEZvcj1cIndhbGxldC1hZGRyZXNzXCI+RW5kZXJlw6dvIGRhIGNhcnRlaXJhPC9sYWJlbD48SW5wdXQgaWQ9XCJ3YWxsZXQtYWRkcmVzc1wiIHsuLi5mb3JtLnJlZ2lzdGVyKCdhZGRyZXNzJyl9IGFyaWEtaW52YWxpZD17ISFmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuYWRkcmVzc30gYXJpYS1kZXNjcmliZWRieT1cIndhbGxldC1hZGRyZXNzLWVycm9yXCIgLz48cCBpZD1cIndhbGxldC1hZGRyZXNzLWVycm9yXCIgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmFkZHJlc3M/Lm1lc3NhZ2V9PC9wPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb21tZXJjZS13aWRlXCI+PGxhYmVsIGh0bWxGb3I9XCJ3YWxsZXQtc2Vjb25kYXJ5XCI+RU5TIG91IGNhcnRlaXJhIHNlY3VuZMOhcmlhIChvcGNpb25hbCk8L2xhYmVsPjxJbnB1dCBpZD1cIndhbGxldC1zZWNvbmRhcnlcIiB7Li4uZm9ybS5yZWdpc3Rlcignc2Vjb25kYXJ5QWRkcmVzcycpfSAvPjwvZGl2PlxuICAgIDwvZGl2PlxuICAgIHtzYXZlLmlzRXJyb3IgJiYgPHAgcm9sZT1cImFsZXJ0XCI+e2FwaUVycm9yTWVzc2FnZShzYXZlLmVycm9yKX08L3A+fVxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTRcIj48QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17c2F2ZS5pc1BlbmRpbmd9PntzYXZlLmlzUGVuZGluZyA/ICdTYWx2YW5kb+KApicgOiAnU2FsdmFyIGNhcnRlaXJhJ308L0J1dHRvbj48QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e2Nsb3NlfT5DYW5jZWxhcjwvQnV0dG9uPjwvZGl2PlxuICA8L2Zvcm0+XG59XG5leHBvcnQgZnVuY3Rpb24gV2FsbGV0c1BhZ2UoKSB7XG4gIGNvbnN0IHF1ZXJ5ID0gdXNlV2FsbGV0cygpOyBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxXYWxsZXQgfCAnbmV3JyB8IG51bGw+KG51bGwpXG4gIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj48aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkXCI+Q2FydGVpcmFzPC9oMT48cD5HZXJlbmNpZSBzdWEgY2FydGVpcmEgcHJpbmNpcGFsIGUgc2VjdW5kw6FyaWEuIEEgY29uZXjDo28gw6kgc2ltdWxhZGEsIHNlbSBleHRlbnPDtWVzLjwvcD5cbiAgICB7cXVlcnkuaXNQZW5kaW5nID8gPExvYWRpbmdTdGF0ZSBsYWJlbD1cIkNhcnJlZ2FuZG8gY2FydGVpcmFzXCIgLz4gOiBxdWVyeS5pc0Vycm9yID8gPEVycm9yU3RhdGUgbWVzc2FnZT17YXBpRXJyb3JNZXNzYWdlKHF1ZXJ5LmVycm9yKX0gcmV0cnk9eygpID0+IHZvaWQgcXVlcnkucmVmZXRjaCgpfSAvPiA6IDw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIndhbGxldC1saXN0XCI+e3F1ZXJ5LmRhdGEuaXRlbXMubGVuZ3RoID8gcXVlcnkuZGF0YS5pdGVtcy5tYXAod2FsbGV0ID0+IDxhcnRpY2xlIGNsYXNzTmFtZT1cImNvbW1lcmNlLXBhbmVsIHNwYWNlLXktM1wiIGRhdGEtdGVzdGlkPVwid2FsbGV0LWNhcmRcIiBrZXk9e3dhbGxldC5pZH0+PGgyIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPnt3YWxsZXQubGFiZWx9IMK3IHt3YWxsZXQucm9sZSA9PT0gJ3ByaW1hcnknID8gJ1ByaW5jaXBhbCcgOiAnU2VjdW5kw6FyaWEnfTwvaDI+PHA+e3dhbGxldC5uZXR3b3JrfSDCtyB7d2FsbGV0LnByb3ZpZGVyfTwvcD48cCBjbGFzc05hbWU9XCJicmVhay1hbGxcIj57d2FsbGV0LmFkZHJlc3N9PC9wPjxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0aW5nKHdhbGxldCl9PkVkaXRhciB7d2FsbGV0LmxhYmVsfTwvQnV0dG9uPjwvYXJ0aWNsZT4pIDogPHAgcm9sZT1cInN0YXR1c1wiPk5lbmh1bWEgY2FydGVpcmEgY2FkYXN0cmFkYS48L3A+fTwvZGl2PlxuICAgICAgeyFlZGl0aW5nICYmIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0RWRpdGluZygnbmV3Jyl9PkFkaWNpb25hciBjYXJ0ZWlyYTwvQnV0dG9uPn1cbiAgICAgIHtlZGl0aW5nICYmIDxXYWxsZXRGb3JtIHdhbGxldD17ZWRpdGluZyA9PT0gJ25ldycgPyB1bmRlZmluZWQgOiBlZGl0aW5nfSBjbG9zZT17KCkgPT4gc2V0RWRpdGluZyhudWxsKX0ga2V5PXtlZGl0aW5nID09PSAnbmV3JyA/ICduZXcnIDogYCR7ZWRpdGluZy5pZH0tJHtlZGl0aW5nLnZlcnNpb259YH0gLz59XG4gICAgPC8+fVxuICA8L3NlY3Rpb24+XG59XG4iXX0=