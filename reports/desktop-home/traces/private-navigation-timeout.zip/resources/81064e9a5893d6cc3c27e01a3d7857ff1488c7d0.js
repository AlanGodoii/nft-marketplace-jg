import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/nft-card.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { ArrowUpRight, ImageOff } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { Card, CardContent } from "/src/components/ui/card.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/catalog/components/nft-card.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function NftCard({ nft }) {
	return /* @__PURE__ */ _jsxDEV(Card, {
		className: "nft-card",
		children: /* @__PURE__ */ _jsxDEV(Link, {
			to: "/nfts/$nftId",
			params: { nftId: nft.id },
			className: "nft-card-link",
			children: [
				nft.image.desktopSrc && /* @__PURE__ */ _jsxDEV("picture", {
					className: "desktop-card-art",
					children: [/* @__PURE__ */ _jsxDEV("source", {
						media: "(min-width: 1024px)",
						srcSet: nft.image.desktopSrc
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 72
					}, this), /* @__PURE__ */ _jsxDEV("img", {
						src: "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=",
						alt: `Arte original Kurio de ${nft.name}`,
						width: "258",
						height: "258",
						loading: "lazy"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 140
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 11,
					columnNumber: 34
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: nft.image.desktopSrc ? "legacy-card-art" : "",
					children: nft.image.src ? /* @__PURE__ */ _jsxDEV("img", {
						src: nft.image.src,
						alt: nft.image.alt,
						loading: "lazy",
						width: "258",
						height: "258"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 89
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "nft-art-placeholder",
						role: "img",
						"aria-label": nft.image.alt,
						children: [/* @__PURE__ */ _jsxDEV(ImageOff, {
							"aria-hidden": "true",
							className: "size-7"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 14,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Arte original indisponível" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 14,
							columnNumber: 63
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(CardContent, {
					className: "nft-card-content space-y-3 p-5",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "card-metadata text-xs text-muted-foreground",
							children: nft.collection.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 18,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "truncate text-lg font-medium",
							children: nft.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 19,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "card-metadata text-xs text-muted-foreground",
							children: [
								nft.network.name,
								" · ",
								nft.availability.status === "available" ? `${nft.availability.remaining} disponíveis` : "Esgotado"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "card-price flex items-center justify-between gap-3 border-t pt-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "card-metadata text-xs text-muted-foreground",
								children: "Preço"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 22,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1 font-bold text-primary",
								children: [
									nft.price.amount,
									" ",
									nft.price.currency
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 23,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 22,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, {
								"aria-hidden": "true",
								className: "size-5 text-primary"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_c = NftCard;
export function NftCardSkeleton() {
	return /* @__PURE__ */ _jsxDEV("div", {
		"aria-hidden": "true",
		className: "nft-card nft-card-skeleton overflow-hidden rounded-xl border",
		children: [/* @__PURE__ */ _jsxDEV(Skeleton, { className: "aspect-square w-full rounded-none" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "nft-card-content space-y-3 p-5",
			children: [
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-1/2" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-7 w-3/4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-3/4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "border-t pt-4",
					children: [/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-1/3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 40
					}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { className: "mt-1 h-5 w-1/2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 74
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 5
	}, this);
}
_c2 = NftCardSkeleton;
var _c, _c2;
$RefreshReg$(_c, "NftCard");
$RefreshReg$(_c2, "NftCardSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/components/nft-card.tsx?t=1793943067891";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/catalog/components/nft-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/catalog/components/nft-card.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/catalog/components/nft-card.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYyxnQkFBZ0I7QUFDdkMsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLGdCQUFnQjs7O0FBR3pCLE9BQU8sU0FBUyxRQUFRLEVBQUUsT0FBcUI7Q0FDN0MsT0FDRSx3QkFBQyxNQUFEO0VBQU0sV0FBVTtZQUNkLHdCQUFDLE1BQUQ7R0FBTSxJQUFHO0dBQWUsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0dBQUcsV0FBVTthQUE3RDtJQUNHLElBQUksTUFBTSxjQUFjLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CLENBQXNDLHdCQUFDLFVBQUQ7TUFBUSxPQUFNO01BQXNCLFFBQVEsSUFBSSxNQUFNO0tBQWE7Ozs7ZUFBQyx3QkFBQyxPQUFEO01BQUssS0FBSTtNQUE2RCxLQUFLLDBCQUEwQixJQUFJO01BQVEsT0FBTTtNQUFNLFFBQU87TUFBTSxTQUFRO0tBQVE7Ozs7YUFBVTs7Ozs7O0lBQ3ZTLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLElBQUksTUFBTSxhQUFhLG9CQUFvQjtlQUFLLElBQUksTUFBTSxNQUFNLHdCQUFDLE9BQUQ7TUFBSyxLQUFLLElBQUksTUFBTTtNQUFLLEtBQUssSUFBSSxNQUFNO01BQUssU0FBUTtNQUFPLE9BQU07TUFBTSxRQUFPO0tBQU87Ozs7Z0JBQ3BLLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQXNCLE1BQUs7TUFBTSxjQUFZLElBQUksTUFBTTtnQkFBdEUsQ0FDRSx3QkFBQyxVQUFEO09BQVUsZUFBWTtPQUFPLFdBQVU7TUFBVTs7OztnQkFBQyx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2NBQ3JGOzs7Ozs7SUFDQTs7Ozs7SUFDUCx3QkFBQyxhQUFEO0tBQWEsV0FBVTtlQUF2QjtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUErQyxJQUFJLFdBQVc7TUFBUTs7Ozs7TUFDbkYsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWdDLElBQUk7TUFBUzs7Ozs7TUFDM0Qsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBNEQsSUFBSSxRQUFRO1FBQUs7UUFBSSxJQUFJLGFBQWEsV0FBVyxjQUFjLEdBQUcsSUFBSSxhQUFhLFVBQVUsZ0JBQWdCO09BQWM7Ozs7OztNQUN2TCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBOEM7T0FBUTs7OztpQkFDdEUsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FBNEMsSUFBSSxNQUFNO1NBQU87U0FBRSxJQUFJLE1BQU07UUFBWTs7Ozs7ZUFDbEY7Ozs7aUJBQ0wsd0JBQUMsY0FBRDtRQUFjLGVBQVk7UUFBTyxXQUFVO09BQXVCOzs7O2VBQy9EOzs7Ozs7S0FDTTs7Ozs7O0dBQ1Q7Ozs7OztDQUNGOzs7OztBQUVWOztBQUVBLE9BQU8sU0FBUyxrQkFBa0I7Q0FDaEMsT0FDRSx3QkFBQyxPQUFEO0VBQUssZUFBWTtFQUFPLFdBQVU7WUFBbEMsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxvQ0FBcUM7Ozs7WUFDekQsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFlBQWE7Ozs7O0lBQ2pDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFlBQWE7Ozs7O0lBQ2pDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFlBQWE7Ozs7O0lBQ2pDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBK0Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsWUFBYTs7OztlQUFDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGlCQUFrQjs7OzthQUFNOzs7Ozs7R0FDMUc7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm5mdC1jYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IEFycm93VXBSaWdodCwgSW1hZ2VPZmYgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYXJkJ1xuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2tlbGV0b24nXG5pbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJy4uL3R5cGVzJ1xuXG5leHBvcnQgZnVuY3Rpb24gTmZ0Q2FyZCh7IG5mdCB9OiB7IG5mdDogTmZ0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8Q2FyZCBjbGFzc05hbWU9XCJuZnQtY2FyZFwiPlxuICAgICAgPExpbmsgdG89XCIvbmZ0cy8kbmZ0SWRcIiBwYXJhbXM9e3sgbmZ0SWQ6IG5mdC5pZCB9fSBjbGFzc05hbWU9XCJuZnQtY2FyZC1saW5rXCI+XG4gICAgICAgIHtuZnQuaW1hZ2UuZGVza3RvcFNyYyAmJiA8cGljdHVyZSBjbGFzc05hbWU9XCJkZXNrdG9wLWNhcmQtYXJ0XCI+PHNvdXJjZSBtZWRpYT1cIihtaW4td2lkdGg6IDEwMjRweClcIiBzcmNTZXQ9e25mdC5pbWFnZS5kZXNrdG9wU3JjfSAvPjxpbWcgc3JjPVwiZGF0YTppbWFnZS9naWY7YmFzZTY0LFIwbEdPRGxoQVFBQkFBRC9BQ3dBQUFBQUFRQUJBQUFDQURzPVwiIGFsdD17YEFydGUgb3JpZ2luYWwgS3VyaW8gZGUgJHtuZnQubmFtZX1gfSB3aWR0aD1cIjI1OFwiIGhlaWdodD1cIjI1OFwiIGxvYWRpbmc9XCJsYXp5XCIgLz48L3BpY3R1cmU+fVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17bmZ0LmltYWdlLmRlc2t0b3BTcmMgPyAnbGVnYWN5LWNhcmQtYXJ0JyA6ICcnfT57bmZ0LmltYWdlLnNyYyA/IDxpbWcgc3JjPXtuZnQuaW1hZ2Uuc3JjfSBhbHQ9e25mdC5pbWFnZS5hbHR9IGxvYWRpbmc9XCJsYXp5XCIgd2lkdGg9XCIyNThcIiBoZWlnaHQ9XCIyNThcIiAvPiA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5mdC1hcnQtcGxhY2Vob2xkZXJcIiByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17bmZ0LmltYWdlLmFsdH0+XG4gICAgICAgICAgICA8SW1hZ2VPZmYgYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwic2l6ZS03XCIgLz48c3Bhbj5BcnRlIG9yaWdpbmFsIGluZGlzcG9uw612ZWw8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9PC9kaXY+XG4gICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJuZnQtY2FyZC1jb250ZW50IHNwYWNlLXktMyBwLTVcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJjYXJkLW1ldGFkYXRhIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e25mdC5jb2xsZWN0aW9uLm5hbWV9PC9wPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+e25mdC5uYW1lfTwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2FyZC1tZXRhZGF0YSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntuZnQubmV0d29yay5uYW1lfSDCtyB7bmZ0LmF2YWlsYWJpbGl0eS5zdGF0dXMgPT09ICdhdmFpbGFibGUnID8gYCR7bmZ0LmF2YWlsYWJpbGl0eS5yZW1haW5pbmd9IGRpc3BvbsOtdmVpc2AgOiAnRXNnb3RhZG8nfTwvcD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtcHJpY2UgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJvcmRlci10IHB0LTRcIj5cbiAgICAgICAgICAgIDxkaXY+PHAgY2xhc3NOYW1lPVwiY2FyZC1tZXRhZGF0YSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlByZcOnbzwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSBmb250LWJvbGQgdGV4dC1wcmltYXJ5XCI+e25mdC5wcmljZS5hbW91bnR9IHtuZnQucHJpY2UuY3VycmVuY3l9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8QXJyb3dVcFJpZ2h0IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInNpemUtNSB0ZXh0LXByaW1hcnlcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgPC9MaW5rPlxuICAgIDwvQ2FyZD5cbiAgKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gTmZ0Q2FyZFNrZWxldG9uKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwibmZ0LWNhcmQgbmZ0LWNhcmQtc2tlbGV0b24gb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYm9yZGVyXCI+XG4gICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSB3LWZ1bGwgcm91bmRlZC1ub25lXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmZ0LWNhcmQtY29udGVudCBzcGFjZS15LTMgcC01XCI+XG4gICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0xLzJcIiAvPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC03IHctMy80XCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LTMvNFwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgcHQtNFwiPjxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0xLzNcIiAvPjxTa2VsZXRvbiBjbGFzc05hbWU9XCJtdC0xIGgtNSB3LTEvMlwiIC8+PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19