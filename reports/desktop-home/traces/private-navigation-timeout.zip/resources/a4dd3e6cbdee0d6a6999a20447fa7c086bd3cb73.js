import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { checkoutQuoteSchema } from "/src/contracts/checkout.ts";
import { useSession } from "/src/features/auth/api.ts";
import { identityEpoch } from "/src/lib/identity.ts";
import { scopedRequest } from "/src/lib/scoped-request.ts";
export function useCheckoutQuote() {
	const session = useSession();
	const epoch = identityEpoch();
	return useMutation({
		mutationKey: [
			"private",
			session.data?.user.id,
			"checkout-quote"
		],
		retry: false,
		mutationFn: async (input) => checkoutQuoteSchema.parse((await scopedRequest({
			method: "POST",
			url: "/checkout/quote",
			data: input
		}, epoch)).data)
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUywyQkFBK0M7QUFDeEQsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsT0FBTyxTQUFTLG1CQUFtQjtDQUNqQyxNQUFNLFVBQVUsV0FBVztDQUFHLE1BQU0sUUFBUSxjQUFjO0NBQzFELE9BQU8sWUFBWTtFQUFFLGFBQWE7R0FBQztHQUFXLFFBQVEsTUFBTSxLQUFLO0dBQUk7RUFBZ0I7RUFBRyxPQUFPO0VBQzdGLFlBQVksT0FBTyxVQUF5QixvQkFBb0IsT0FBTyxNQUFNLGNBQWM7R0FBRSxRQUFRO0dBQVEsS0FBSztHQUFtQixNQUFNO0VBQU0sR0FBRyxLQUFLLEVBQUMsQ0FBRSxJQUFJO0NBQ2xLLENBQUM7QUFDSCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdWVyaWVzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgY2hlY2tvdXRRdW90ZVNjaGVtYSwgdHlwZSBDaGVja291dElucHV0IH0gZnJvbSAnQC9jb250cmFjdHMvY2hlY2tvdXQnXG5pbXBvcnQgeyB1c2VTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2FwaSdcbmltcG9ydCB7IGlkZW50aXR5RXBvY2ggfSBmcm9tICdAL2xpYi9pZGVudGl0eSdcbmltcG9ydCB7IHNjb3BlZFJlcXVlc3QgfSBmcm9tICdAL2xpYi9zY29wZWQtcmVxdWVzdCdcbmV4cG9ydCBmdW5jdGlvbiB1c2VDaGVja291dFF1b3RlKCkge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpOyBjb25zdCBlcG9jaCA9IGlkZW50aXR5RXBvY2goKVxuICByZXR1cm4gdXNlTXV0YXRpb24oeyBtdXRhdGlvbktleTogWydwcml2YXRlJywgc2Vzc2lvbi5kYXRhPy51c2VyLmlkLCAnY2hlY2tvdXQtcXVvdGUnXSwgcmV0cnk6IGZhbHNlLFxuICAgIG11dGF0aW9uRm46IGFzeW5jIChpbnB1dDogQ2hlY2tvdXRJbnB1dCkgPT4gY2hlY2tvdXRRdW90ZVNjaGVtYS5wYXJzZSgoYXdhaXQgc2NvcGVkUmVxdWVzdCh7IG1ldGhvZDogJ1BPU1QnLCB1cmw6ICcvY2hlY2tvdXQvcXVvdGUnLCBkYXRhOiBpbnB1dCB9LCBlcG9jaCkpLmRhdGEpLFxuICB9KVxufVxuIl19