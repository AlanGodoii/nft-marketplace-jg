import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { profileSchema } from "/src/contracts/profile.ts";
import { sessionKey, useSession } from "/src/features/auth/api.ts";
import { api } from "/src/lib/api.ts";
import { identityEpoch } from "/src/lib/identity.ts";
import { scopedRequest } from "/src/lib/scoped-request.ts";
export const profileKey = (userId) => [
	"private",
	userId,
	"profile"
];
export function useProfile() {
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	return useQuery({
		queryKey: profileKey(userId),
		enabled: !!userId,
		staleTime: 15e3,
		queryFn: async ({ signal }) => profileSchema.parse((await api.get("/profile", { signal })).data)
	});
}
export function useSaveProfile(resource) {
	const session = useSession();
	const client = useQueryClient();
	const epoch = identityEpoch();
	const userId = session.data?.user.id ?? "";
	return useMutation({
		mutationKey: [
			"private",
			userId,
			"profile",
			resource
		],
		retry: false,
		mutationFn: async (data) => profileSchema.parse((await scopedRequest({
			method: resource === "data" ? "PATCH" : "PUT",
			url: resource === "data" ? "/profile" : "/profile/avatar",
			data
		}, epoch)).data),
		onSuccess: async (profile) => {
			if (epoch !== identityEpoch()) return;
			client.setQueryData(profileKey(userId), profile);
			await client.invalidateQueries({ queryKey: sessionKey });
		}
	});
}
export function useChangePassword() {
	const session = useSession();
	const epoch = identityEpoch();
	return useMutation({
		mutationKey: [
			"private",
			session.data?.user.id,
			"password"
		],
		retry: false,
		mutationFn: async (data) => {
			await scopedRequest({
				method: "POST",
				url: "/profile/password",
				data
			}, epoch);
		}
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFVBQVUsc0JBQXNCO0FBQ3RELFNBQVMscUJBQWlGO0FBQzFGLFNBQVMsWUFBWSxrQkFBa0I7QUFDdkMsU0FBUyxXQUFXO0FBQ3BCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMscUJBQXFCO0FBRTlCLE9BQU8sTUFBTSxjQUFjLFdBQW1CO0NBQUM7Q0FBVztDQUFRO0FBQVM7QUFDM0UsT0FBTyxTQUFTLGFBQWE7Q0FDM0IsTUFBTSxVQUFVLFdBQVc7Q0FBRyxNQUFNLFNBQVMsUUFBUSxNQUFNLEtBQUssTUFBTTtDQUN0RSxPQUFPLFNBQVM7RUFBRSxVQUFVLFdBQVcsTUFBTTtFQUFHLFNBQVMsQ0FBQyxDQUFDO0VBQVEsV0FBVztFQUM1RSxTQUFTLE9BQU8sRUFBRSxhQUFhLGNBQWMsT0FBTyxNQUFNLElBQUksSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDLEVBQUMsQ0FBRSxJQUFJO0NBQ2pHLENBQUM7QUFDSDtBQUNBLE9BQU8sU0FBUyxlQUFlLFVBQTZCO0NBQzFELE1BQU0sVUFBVSxXQUFXO0NBQUcsTUFBTSxTQUFTLGVBQWU7Q0FBRyxNQUFNLFFBQVEsY0FBYztDQUMzRixNQUFNLFNBQVMsUUFBUSxNQUFNLEtBQUssTUFBTTtDQUN4QyxPQUFPLFlBQVk7RUFBRSxhQUFhO0dBQUM7R0FBVztHQUFRO0dBQVc7RUFBUTtFQUFHLE9BQU87RUFDakYsWUFBWSxPQUFPLFNBQXVDLGNBQWMsT0FBTyxNQUFNLGNBQWM7R0FBRSxRQUFRLGFBQWEsU0FBUyxVQUFVO0dBQU8sS0FBSyxhQUFhLFNBQVMsYUFBYTtHQUFtQjtFQUFLLEdBQUcsS0FBSyxFQUFDLENBQUUsSUFBSTtFQUNuTyxXQUFXLE9BQU0sWUFBVztHQUMxQixJQUFJLFVBQVUsY0FBYyxHQUFHO0dBQy9CLE9BQU8sYUFBYSxXQUFXLE1BQU0sR0FBRyxPQUFPO0dBQy9DLE1BQU0sT0FBTyxrQkFBa0IsRUFBRSxVQUFVLFdBQVcsQ0FBQztFQUN6RDtDQUNGLENBQUM7QUFDSDtBQUNBLE9BQU8sU0FBUyxvQkFBb0I7Q0FDbEMsTUFBTSxVQUFVLFdBQVc7Q0FBRyxNQUFNLFFBQVEsY0FBYztDQUMxRCxPQUFPLFlBQVk7RUFBRSxhQUFhO0dBQUM7R0FBVyxRQUFRLE1BQU0sS0FBSztHQUFJO0VBQVU7RUFBRyxPQUFPO0VBQ3ZGLFlBQVksT0FBTyxTQUF5QjtHQUFFLE1BQU0sY0FBYztJQUFFLFFBQVE7SUFBUSxLQUFLO0lBQXFCO0dBQUssR0FBRyxLQUFLO0VBQUU7Q0FDL0gsQ0FBQztBQUNIIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInF1ZXJpZXMudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHByb2ZpbGVTY2hlbWEsIHR5cGUgUHJvZmlsZVVwZGF0ZSwgdHlwZSBBdmF0YXJVcGRhdGUsIHR5cGUgUGFzc3dvcmRDaGFuZ2UgfSBmcm9tICdAL2NvbnRyYWN0cy9wcm9maWxlJ1xuaW1wb3J0IHsgc2Vzc2lvbktleSwgdXNlU2Vzc2lvbiB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9hcGknXG5pbXBvcnQgeyBhcGkgfSBmcm9tICdAL2xpYi9hcGknXG5pbXBvcnQgeyBpZGVudGl0eUVwb2NoIH0gZnJvbSAnQC9saWIvaWRlbnRpdHknXG5pbXBvcnQgeyBzY29wZWRSZXF1ZXN0IH0gZnJvbSAnQC9saWIvc2NvcGVkLXJlcXVlc3QnXG5cbmV4cG9ydCBjb25zdCBwcm9maWxlS2V5ID0gKHVzZXJJZDogc3RyaW5nKSA9PiBbJ3ByaXZhdGUnLCB1c2VySWQsICdwcm9maWxlJ10gYXMgY29uc3RcbmV4cG9ydCBmdW5jdGlvbiB1c2VQcm9maWxlKCkge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpOyBjb25zdCB1c2VySWQgPSBzZXNzaW9uLmRhdGE/LnVzZXIuaWQgPz8gJydcbiAgcmV0dXJuIHVzZVF1ZXJ5KHsgcXVlcnlLZXk6IHByb2ZpbGVLZXkodXNlcklkKSwgZW5hYmxlZDogISF1c2VySWQsIHN0YWxlVGltZTogMTUwMDAsXG4gICAgcXVlcnlGbjogYXN5bmMgKHsgc2lnbmFsIH0pID0+IHByb2ZpbGVTY2hlbWEucGFyc2UoKGF3YWl0IGFwaS5nZXQoJy9wcm9maWxlJywgeyBzaWduYWwgfSkpLmRhdGEpLFxuICB9KVxufVxuZXhwb3J0IGZ1bmN0aW9uIHVzZVNhdmVQcm9maWxlKHJlc291cmNlOiAnZGF0YScgfCAnYXZhdGFyJykge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpOyBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpOyBjb25zdCBlcG9jaCA9IGlkZW50aXR5RXBvY2goKVxuICBjb25zdCB1c2VySWQgPSBzZXNzaW9uLmRhdGE/LnVzZXIuaWQgPz8gJydcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsncHJpdmF0ZScsIHVzZXJJZCwgJ3Byb2ZpbGUnLCByZXNvdXJjZV0sIHJldHJ5OiBmYWxzZSxcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoZGF0YTogUHJvZmlsZVVwZGF0ZSB8IEF2YXRhclVwZGF0ZSkgPT4gcHJvZmlsZVNjaGVtYS5wYXJzZSgoYXdhaXQgc2NvcGVkUmVxdWVzdCh7IG1ldGhvZDogcmVzb3VyY2UgPT09ICdkYXRhJyA/ICdQQVRDSCcgOiAnUFVUJywgdXJsOiByZXNvdXJjZSA9PT0gJ2RhdGEnID8gJy9wcm9maWxlJyA6ICcvcHJvZmlsZS9hdmF0YXInLCBkYXRhIH0sIGVwb2NoKSkuZGF0YSksXG4gICAgb25TdWNjZXNzOiBhc3luYyBwcm9maWxlID0+IHtcbiAgICAgIGlmIChlcG9jaCAhPT0gaWRlbnRpdHlFcG9jaCgpKSByZXR1cm5cbiAgICAgIGNsaWVudC5zZXRRdWVyeURhdGEocHJvZmlsZUtleSh1c2VySWQpLCBwcm9maWxlKVxuICAgICAgYXdhaXQgY2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHNlc3Npb25LZXkgfSlcbiAgICB9LFxuICB9KVxufVxuZXhwb3J0IGZ1bmN0aW9uIHVzZUNoYW5nZVBhc3N3b3JkKCkge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpOyBjb25zdCBlcG9jaCA9IGlkZW50aXR5RXBvY2goKVxuICByZXR1cm4gdXNlTXV0YXRpb24oeyBtdXRhdGlvbktleTogWydwcml2YXRlJywgc2Vzc2lvbi5kYXRhPy51c2VyLmlkLCAncGFzc3dvcmQnXSwgcmV0cnk6IGZhbHNlLFxuICAgIG11dGF0aW9uRm46IGFzeW5jIChkYXRhOiBQYXNzd29yZENoYW5nZSkgPT4geyBhd2FpdCBzY29wZWRSZXF1ZXN0KHsgbWV0aG9kOiAnUE9TVCcsIHVybDogJy9wcm9maWxlL3Bhc3N3b3JkJywgZGF0YSB9LCBlcG9jaCkgfSxcbiAgfSlcbn1cbiJdfQ==