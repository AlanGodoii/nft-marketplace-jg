import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/checkout/quote-values.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/checkout/quote-values.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function QuoteValues({ quote }) {
	return /* @__PURE__ */ _jsxDEV("dl", {
		className: "quote-totals",
		"aria-label": "Valores da compra",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Subtotal" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 10
			}, this), /* @__PURE__ */ _jsxDEV("dd", {
				"data-testid": "checkout-subtotal",
				children: [quote.subtotal, " ETH"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 27
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Desconto" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 5,
				columnNumber: 10
			}, this), /* @__PURE__ */ _jsxDEV("dd", {
				"data-testid": "checkout-discount",
				children: [quote.discount, " ETH"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 5,
				columnNumber: 27
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 5,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Taxa de rede" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 6,
				columnNumber: 10
			}, this), /* @__PURE__ */ _jsxDEV("dd", { children: [quote.networkFee, " ETH"] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 6,
				columnNumber: 31
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 6,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "border-t pt-4 font-bold text-primary",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Total" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 59
				}, this), /* @__PURE__ */ _jsxDEV("dd", {
					"data-testid": "checkout-total",
					children: [quote.total, " ETH"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 73
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 3,
		columnNumber: 10
	}, this);
}
_c = QuoteValues;
var _c;
$RefreshReg$(_c, "QuoteValues");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/checkout/quote-values.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/checkout/quote-values.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/checkout/quote-values.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/checkout/quote-values.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFDQSxPQUFPLFNBQVMsWUFBWSxFQUFFLFNBQTJCO0NBQ3ZELE9BQU8sd0JBQUMsTUFBRDtFQUFJLFdBQVU7RUFBZSxjQUFXO1lBQXhDO0dBQ0wsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSSxXQUFZOzs7O2FBQUMsd0JBQUMsTUFBRDtJQUFJLGVBQVk7Y0FBaEIsQ0FBcUMsTUFBTSxVQUFTLE1BQVE7Ozs7O1dBQU07Ozs7O0dBQ3hGLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUksV0FBWTs7OzthQUFDLHdCQUFDLE1BQUQ7SUFBSSxlQUFZO2NBQWhCLENBQXFDLE1BQU0sVUFBUyxNQUFROzs7OztXQUFNOzs7OztHQUN4Rix3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7O2FBQUMsd0JBQUMsTUFBRCxhQUFLLE1BQU0sWUFBVyxNQUFROzs7O1dBQU07Ozs7O0dBQzlELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBc0Qsd0JBQUMsTUFBRCxZQUFJLFFBQVM7Ozs7Y0FBQyx3QkFBQyxNQUFEO0tBQUksZUFBWTtlQUFoQixDQUFrQyxNQUFNLE9BQU0sTUFBUTs7Ozs7WUFBTTs7Ozs7O0VBQzlIOzs7Ozs7QUFDTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdW90ZS12YWx1ZXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUXVvdGUgfSBmcm9tICdAL2NvbnRyYWN0cy9jYXJ0J1xuZXhwb3J0IGZ1bmN0aW9uIFF1b3RlVmFsdWVzKHsgcXVvdGUgfTogeyBxdW90ZTogUXVvdGUgfSkge1xuICByZXR1cm4gPGRsIGNsYXNzTmFtZT1cInF1b3RlLXRvdGFsc1wiIGFyaWEtbGFiZWw9XCJWYWxvcmVzIGRhIGNvbXByYVwiPlxuICAgIDxkaXY+PGR0PlN1YnRvdGFsPC9kdD48ZGQgZGF0YS10ZXN0aWQ9XCJjaGVja291dC1zdWJ0b3RhbFwiPntxdW90ZS5zdWJ0b3RhbH0gRVRIPC9kZD48L2Rpdj5cbiAgICA8ZGl2PjxkdD5EZXNjb250bzwvZHQ+PGRkIGRhdGEtdGVzdGlkPVwiY2hlY2tvdXQtZGlzY291bnRcIj57cXVvdGUuZGlzY291bnR9IEVUSDwvZGQ+PC9kaXY+XG4gICAgPGRpdj48ZHQ+VGF4YSBkZSByZWRlPC9kdD48ZGQ+e3F1b3RlLm5ldHdvcmtGZWV9IEVUSDwvZGQ+PC9kaXY+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBwdC00IGZvbnQtYm9sZCB0ZXh0LXByaW1hcnlcIj48ZHQ+VG90YWw8L2R0PjxkZCBkYXRhLXRlc3RpZD1cImNoZWNrb3V0LXRvdGFsXCI+e3F1b3RlLnRvdGFsfSBFVEg8L2RkPjwvZGl2PlxuICA8L2RsPlxufVxuIl19