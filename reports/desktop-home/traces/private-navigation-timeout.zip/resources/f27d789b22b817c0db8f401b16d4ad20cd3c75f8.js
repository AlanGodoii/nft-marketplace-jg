import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/favorites/favorite-button.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { Button } from "/src/components/ui/button.tsx";
import { apiErrorMessage } from "/src/lib/api.ts";
import { useSession } from "/src/features/auth/api.ts";
import { useFavoriteMutation, useFavorites } from "/src/features/favorites/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/favorites/favorite-button.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function FavoriteButton({ nft }) {
	_s();
	const session = useSession();
	const favorites = useFavorites();
	const mutation = useFavoriteMutation(nft);
	const router = useRouter();
	const selected = favorites.data?.items.some((item) => item.id === nft.id) ?? false;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				"aria-pressed": selected,
				disabled: session.isPending || !!session.data && (favorites.isPending || favorites.isError) || mutation.isPending,
				onClick: () => {
					if (!session.data) {
						void router.navigate({
							to: "/login",
							search: { redirect: router.state.location.href }
						});
						return;
					}
					mutation.mutate(!selected);
				},
				children: selected ? "Remover dos favoritos" : "Adicionar aos favoritos"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 5
			}, this),
			mutation.isPending && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "text-xs",
				children: "Salvando favorito…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 28
			}, this),
			mutation.isError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: [apiErrorMessage(mutation.error), " O estado anterior foi restaurado."]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 26
			}, this),
			favorites.isError && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				children: [
					apiErrorMessage(favorites.error),
					" ",
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => void favorites.refetch(),
						children: "Recarregar favoritos"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 80
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 27
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 10
	}, this);
}
_s(FavoriteButton, "NDb4U21JHcFbWdcX8Milh2jO8d4=", false, function() {
	return [
		useSession,
		useFavorites,
		useFavoriteMutation,
		useRouter
	];
});
_c = FavoriteButton;
var _c;
$RefreshReg$(_c, "FavoriteButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/favorites/favorite-button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/favorites/favorite-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/favorites/favorite-button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/favorites/favorite-button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFFMUIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMscUJBQXFCLG9CQUFvQjs7OztBQUNsRCxPQUFPLFNBQVMsZUFBZSxFQUFFLE9BQXFCOztDQUNwRCxNQUFNLFVBQVUsV0FBVztDQUMzQixNQUFNLFlBQVksYUFBYTtDQUMvQixNQUFNLFdBQVcsb0JBQW9CLEdBQUc7Q0FDeEMsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxXQUFXLFVBQVUsTUFBTSxNQUFNLE1BQUssU0FBUSxLQUFLLE9BQU8sSUFBSSxFQUFFLEtBQUs7Q0FDM0UsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0wsd0JBQUMsUUFBRDtJQUFRLFNBQVE7SUFBVSxnQkFBYztJQUFVLFVBQVUsUUFBUSxhQUFjLENBQUMsQ0FBQyxRQUFRLFNBQVMsVUFBVSxhQUFhLFVBQVUsWUFBYSxTQUFTO0lBQzFKLGVBQWU7S0FBRSxJQUFJLENBQUMsUUFBUSxNQUFNO01BQUUsS0FBSyxPQUFPLFNBQVM7T0FBRSxJQUFJO09BQVUsUUFBUSxFQUFFLFVBQVUsT0FBTyxNQUFNLFNBQVMsS0FBSztNQUFFLENBQUM7TUFBRztLQUFPO0tBQUUsU0FBUyxPQUFPLENBQUMsUUFBUTtJQUFFO2NBQ25LLFdBQVcsMEJBQTBCO0dBQ2hDOzs7OztHQUNQLFNBQVMsYUFBYSx3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFTLFdBQVU7Y0FBVTtHQUFxQjs7Ozs7R0FDaEYsU0FBUyxXQUFXLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO2NBQVIsQ0FBaUIsZ0JBQWdCLFNBQVMsS0FBSyxHQUFFLG9DQUFxQzs7Ozs7O0dBQzFHLFVBQVUsV0FBVyx3QkFBQyxPQUFEO0lBQUssTUFBSztjQUFWO0tBQW1CLGdCQUFnQixVQUFVLEtBQUs7S0FBRTtLQUFDLHdCQUFDLFFBQUQ7TUFBUSxlQUFlLEtBQUssVUFBVSxRQUFRO2dCQUFHO0tBQTRCOzs7OztJQUFNOzs7Ozs7RUFDM0o7Ozs7OztBQUNQIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZhdm9yaXRlLWJ1dHRvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0J1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IGFwaUVycm9yTWVzc2FnZSB9IGZyb20gJ0AvbGliL2FwaSdcbmltcG9ydCB7IHVzZVNlc3Npb24gfSBmcm9tICdAL2ZlYXR1cmVzL2F1dGgvYXBpJ1xuaW1wb3J0IHsgdXNlRmF2b3JpdGVNdXRhdGlvbiwgdXNlRmF2b3JpdGVzIH0gZnJvbSAnLi9xdWVyaWVzJ1xuZXhwb3J0IGZ1bmN0aW9uIEZhdm9yaXRlQnV0dG9uKHsgbmZ0IH06IHsgbmZ0OiBOZnQgfSkge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpXG4gIGNvbnN0IGZhdm9yaXRlcyA9IHVzZUZhdm9yaXRlcygpXG4gIGNvbnN0IG11dGF0aW9uID0gdXNlRmF2b3JpdGVNdXRhdGlvbihuZnQpXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IHNlbGVjdGVkID0gZmF2b3JpdGVzLmRhdGE/Lml0ZW1zLnNvbWUoaXRlbSA9PiBpdGVtLmlkID09PSBuZnQuaWQpID8/IGZhbHNlXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBhcmlhLXByZXNzZWQ9e3NlbGVjdGVkfSBkaXNhYmxlZD17c2Vzc2lvbi5pc1BlbmRpbmcgfHwgKCEhc2Vzc2lvbi5kYXRhICYmIChmYXZvcml0ZXMuaXNQZW5kaW5nIHx8IGZhdm9yaXRlcy5pc0Vycm9yKSkgfHwgbXV0YXRpb24uaXNQZW5kaW5nfVxuICAgICAgb25DbGljaz17KCkgPT4geyBpZiAoIXNlc3Npb24uZGF0YSkgeyB2b2lkIHJvdXRlci5uYXZpZ2F0ZSh7IHRvOiAnL2xvZ2luJywgc2VhcmNoOiB7IHJlZGlyZWN0OiByb3V0ZXIuc3RhdGUubG9jYXRpb24uaHJlZiB9IH0pOyByZXR1cm4gfSBtdXRhdGlvbi5tdXRhdGUoIXNlbGVjdGVkKSB9fT5cbiAgICAgIHtzZWxlY3RlZCA/ICdSZW1vdmVyIGRvcyBmYXZvcml0b3MnIDogJ0FkaWNpb25hciBhb3MgZmF2b3JpdG9zJ31cbiAgICA8L0J1dHRvbj5cbiAgICB7bXV0YXRpb24uaXNQZW5kaW5nICYmIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+U2FsdmFuZG8gZmF2b3JpdG/igKY8L3A+fVxuICAgIHttdXRhdGlvbi5pc0Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiPnthcGlFcnJvck1lc3NhZ2UobXV0YXRpb24uZXJyb3IpfSBPIGVzdGFkbyBhbnRlcmlvciBmb2kgcmVzdGF1cmFkby48L3A+fVxuICAgIHtmYXZvcml0ZXMuaXNFcnJvciAmJiA8ZGl2IHJvbGU9XCJhbGVydFwiPnthcGlFcnJvck1lc3NhZ2UoZmF2b3JpdGVzLmVycm9yKX0gPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB2b2lkIGZhdm9yaXRlcy5yZWZldGNoKCl9PlJlY2FycmVnYXIgZmF2b3JpdG9zPC9CdXR0b24+PC9kaXY+fVxuICA8L2Rpdj5cbn1cbiJdfQ==