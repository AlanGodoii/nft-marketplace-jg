const useEffect = __vite__cjsImport0_react["useEffect"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { orderSchema, ordersSchema } from "/src/contracts/order.ts";
import { useSession } from "/src/features/auth/api.ts";
import { api } from "/src/lib/api.ts";
import { identityEpoch } from "/src/lib/identity.ts";
import { scopedRequest } from "/src/lib/scoped-request.ts";
export const orderKeys = {
	all: (userId) => [
		"private",
		userId,
		"orders"
	],
	detail: (userId, id) => [
		"private",
		userId,
		"orders",
		id
	]
};
export function useOrders() {
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	return useQuery({
		queryKey: orderKeys.all(userId),
		enabled: !!userId,
		staleTime: 0,
		queryFn: async ({ signal }) => ordersSchema.parse((await api.get("/orders", { signal })).data)
	});
}
export function useOrder(id) {
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	const client = useQueryClient();
	const query = useQuery({
		queryKey: orderKeys.detail(userId, id ?? ""),
		enabled: !!userId && !!id,
		staleTime: 0,
		queryFn: async ({ signal }) => orderSchema.parse((await api.get(`/orders/${id}`, { signal })).data)
	});
	const status = query.data?.status;
	const version = query.data?.version;
	useEffect(() => {
		if (status === "confirmed") {
			void client.invalidateQueries({ queryKey: ["cart", `user:${userId}`] });
			void client.invalidateQueries({ queryKey: ["nfts"] });
			void client.invalidateQueries({
				queryKey: orderKeys.all(userId),
				exact: true
			});
		}
	}, [
		client,
		userId,
		status,
		version
	]);
	return query;
}
export function useCreateOrder() {
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	const client = useQueryClient();
	const epoch = identityEpoch();
	return useMutation({
		mutationKey: [
			"private",
			userId,
			"order-create"
		],
		retry: false,
		mutationFn: async (attempt) => orderSchema.parse((await scopedRequest({
			method: "POST",
			url: "/orders",
			data: attempt.input,
			headers: { "Idempotency-Key": attempt.key }
		}, epoch)).data),
		onSuccess: (order) => {
			if (epoch === identityEpoch()) {
				client.setQueryData(orderKeys.detail(userId, order.id), (previous) => {
					const parsed = orderSchema.safeParse(previous);
					return parsed.success && (parsed.data.version > order.version || parsed.data.status !== "pending" && order.status === "pending") ? parsed.data : order;
				});
				void client.invalidateQueries({
					queryKey: orderKeys.all(userId),
					exact: true
				});
			}
		}
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxhQUFhLFVBQVUsc0JBQXNCO0FBQ3RELFNBQVMsYUFBYSxvQkFBMEM7QUFDaEUsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxXQUFXO0FBQ3BCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMscUJBQXFCO0FBQzlCLE9BQU8sTUFBTSxZQUFZO0NBQ3ZCLE1BQU0sV0FBbUI7RUFBQztFQUFXO0VBQVE7Q0FBUTtDQUNyRCxTQUFTLFFBQWdCLE9BQWU7RUFBQztFQUFXO0VBQVE7RUFBVTtDQUFFO0FBQzFFO0FBQ0EsT0FBTyxTQUFTLFlBQVk7Q0FDMUIsTUFBTSxVQUFVLFdBQVc7Q0FBRyxNQUFNLFNBQVMsUUFBUSxNQUFNLEtBQUssTUFBTTtDQUN0RSxPQUFPLFNBQVM7RUFBRSxVQUFVLFVBQVUsSUFBSSxNQUFNO0VBQUcsU0FBUyxDQUFDLENBQUM7RUFBUSxXQUFXO0VBQy9FLFNBQVMsT0FBTyxFQUFFLGFBQWEsYUFBYSxPQUFPLE1BQU0sSUFBSSxJQUFJLFdBQVcsRUFBRSxPQUFPLENBQUMsRUFBQyxDQUFFLElBQUk7Q0FDL0YsQ0FBQztBQUNIO0FBQ0EsT0FBTyxTQUFTLFNBQVMsSUFBYTtDQUNwQyxNQUFNLFVBQVUsV0FBVztDQUFHLE1BQU0sU0FBUyxRQUFRLE1BQU0sS0FBSyxNQUFNO0NBQUksTUFBTSxTQUFTLGVBQWU7Q0FDeEcsTUFBTSxRQUFRLFNBQVM7RUFBRSxVQUFVLFVBQVUsT0FBTyxRQUFRLE1BQU0sRUFBRTtFQUFHLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQUksV0FBVztFQUMzRyxTQUFTLE9BQU8sRUFBRSxhQUFhLFlBQVksT0FBTyxNQUFNLElBQUksSUFBSSxXQUFXLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBQyxDQUFFLElBQUk7Q0FDcEcsQ0FBQztDQUNELE1BQU0sU0FBUyxNQUFNLE1BQU07Q0FBUSxNQUFNLFVBQVUsTUFBTSxNQUFNO0NBQy9ELGdCQUFnQjtFQUNkLElBQUksV0FBVyxhQUFhO0dBQUUsS0FBSyxPQUFPLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxRQUFRLFFBQVEsUUFBUSxFQUFFLENBQUM7R0FBRyxLQUFLLE9BQU8sa0JBQWtCLEVBQUUsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO0dBQUcsS0FBSyxPQUFPLGtCQUFrQjtJQUFFLFVBQVUsVUFBVSxJQUFJLE1BQU07SUFBRyxPQUFPO0dBQUssQ0FBQztFQUFFO0NBQ2hQLEdBQUc7RUFBQztFQUFRO0VBQVE7RUFBUTtDQUFPLENBQUM7Q0FDcEMsT0FBTztBQUNUO0FBQ0EsT0FBTyxTQUFTLGlCQUFpQjtDQUMvQixNQUFNLFVBQVUsV0FBVztDQUFHLE1BQU0sU0FBUyxRQUFRLE1BQU0sS0FBSyxNQUFNO0NBQUksTUFBTSxTQUFTLGVBQWU7Q0FBRyxNQUFNLFFBQVEsY0FBYztDQUN2SSxPQUFPLFlBQVk7RUFBRSxhQUFhO0dBQUM7R0FBVztHQUFRO0VBQWM7RUFBRyxPQUFPO0VBQzVFLFlBQVksT0FBTyxZQUE2QixZQUFZLE9BQU8sTUFBTSxjQUFjO0dBQUUsUUFBUTtHQUFRLEtBQUs7R0FBVyxNQUFNLFFBQVE7R0FBTyxTQUFTLEVBQUUsbUJBQW1CLFFBQVEsSUFBSTtFQUFFLEdBQUcsS0FBSyxFQUFDLENBQUUsSUFBSTtFQUN6TSxZQUFXLFVBQVM7R0FBRSxJQUFJLFVBQVUsY0FBYyxHQUFHO0lBQUUsT0FBTyxhQUFhLFVBQVUsT0FBTyxRQUFRLE1BQU0sRUFBRSxJQUFJLGFBQXNCO0tBQUUsTUFBTSxTQUFTLFlBQVksVUFBVSxRQUFRO0tBQUcsT0FBTyxPQUFPLFlBQVksT0FBTyxLQUFLLFVBQVUsTUFBTSxXQUFZLE9BQU8sS0FBSyxXQUFXLGFBQWEsTUFBTSxXQUFXLGFBQWMsT0FBTyxPQUFPO0lBQU0sQ0FBQztJQUFHLEtBQUssT0FBTyxrQkFBa0I7S0FBRSxVQUFVLFVBQVUsSUFBSSxNQUFNO0tBQUcsT0FBTztJQUFLLENBQUM7R0FBRTtFQUFFO0NBQ3phLENBQUM7QUFDSCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdWVyaWVzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IG9yZGVyU2NoZW1hLCBvcmRlcnNTY2hlbWEsIHR5cGUgUHVyY2hhc2VBdHRlbXB0IH0gZnJvbSAnQC9jb250cmFjdHMvb3JkZXInXG5pbXBvcnQgeyB1c2VTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2FwaSdcbmltcG9ydCB7IGFwaSB9IGZyb20gJ0AvbGliL2FwaSdcbmltcG9ydCB7IGlkZW50aXR5RXBvY2ggfSBmcm9tICdAL2xpYi9pZGVudGl0eSdcbmltcG9ydCB7IHNjb3BlZFJlcXVlc3QgfSBmcm9tICdAL2xpYi9zY29wZWQtcmVxdWVzdCdcbmV4cG9ydCBjb25zdCBvcmRlcktleXMgPSB7XG4gIGFsbDogKHVzZXJJZDogc3RyaW5nKSA9PiBbJ3ByaXZhdGUnLCB1c2VySWQsICdvcmRlcnMnXSBhcyBjb25zdCxcbiAgZGV0YWlsOiAodXNlcklkOiBzdHJpbmcsIGlkOiBzdHJpbmcpID0+IFsncHJpdmF0ZScsIHVzZXJJZCwgJ29yZGVycycsIGlkXSBhcyBjb25zdCxcbn1cbmV4cG9ydCBmdW5jdGlvbiB1c2VPcmRlcnMoKSB7XG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKCk7IGNvbnN0IHVzZXJJZCA9IHNlc3Npb24uZGF0YT8udXNlci5pZCA/PyAnJ1xuICByZXR1cm4gdXNlUXVlcnkoeyBxdWVyeUtleTogb3JkZXJLZXlzLmFsbCh1c2VySWQpLCBlbmFibGVkOiAhIXVzZXJJZCwgc3RhbGVUaW1lOiAwLFxuICAgIHF1ZXJ5Rm46IGFzeW5jICh7IHNpZ25hbCB9KSA9PiBvcmRlcnNTY2hlbWEucGFyc2UoKGF3YWl0IGFwaS5nZXQoJy9vcmRlcnMnLCB7IHNpZ25hbCB9KSkuZGF0YSksXG4gIH0pXG59XG5leHBvcnQgZnVuY3Rpb24gdXNlT3JkZXIoaWQ/OiBzdHJpbmcpIHtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKTsgY29uc3QgdXNlcklkID0gc2Vzc2lvbi5kYXRhPy51c2VyLmlkID8/ICcnOyBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4gIGNvbnN0IHF1ZXJ5ID0gdXNlUXVlcnkoeyBxdWVyeUtleTogb3JkZXJLZXlzLmRldGFpbCh1c2VySWQsIGlkID8/ICcnKSwgZW5hYmxlZDogISF1c2VySWQgJiYgISFpZCwgc3RhbGVUaW1lOiAwLFxuICAgIHF1ZXJ5Rm46IGFzeW5jICh7IHNpZ25hbCB9KSA9PiBvcmRlclNjaGVtYS5wYXJzZSgoYXdhaXQgYXBpLmdldChgL29yZGVycy8ke2lkfWAsIHsgc2lnbmFsIH0pKS5kYXRhKSxcbiAgfSlcbiAgY29uc3Qgc3RhdHVzID0gcXVlcnkuZGF0YT8uc3RhdHVzOyBjb25zdCB2ZXJzaW9uID0gcXVlcnkuZGF0YT8udmVyc2lvblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzdGF0dXMgPT09ICdjb25maXJtZWQnKSB7IHZvaWQgY2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnY2FydCcsIGB1c2VyOiR7dXNlcklkfWBdIH0pOyB2b2lkIGNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ25mdHMnXSB9KTsgdm9pZCBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogb3JkZXJLZXlzLmFsbCh1c2VySWQpLCBleGFjdDogdHJ1ZSB9KSB9XG4gIH0sIFtjbGllbnQsIHVzZXJJZCwgc3RhdHVzLCB2ZXJzaW9uXSlcbiAgcmV0dXJuIHF1ZXJ5XG59XG5leHBvcnQgZnVuY3Rpb24gdXNlQ3JlYXRlT3JkZXIoKSB7XG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKCk7IGNvbnN0IHVzZXJJZCA9IHNlc3Npb24uZGF0YT8udXNlci5pZCA/PyAnJzsgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTsgY29uc3QgZXBvY2ggPSBpZGVudGl0eUVwb2NoKClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsncHJpdmF0ZScsIHVzZXJJZCwgJ29yZGVyLWNyZWF0ZSddLCByZXRyeTogZmFsc2UsXG4gICAgbXV0YXRpb25GbjogYXN5bmMgKGF0dGVtcHQ6IFB1cmNoYXNlQXR0ZW1wdCkgPT4gb3JkZXJTY2hlbWEucGFyc2UoKGF3YWl0IHNjb3BlZFJlcXVlc3QoeyBtZXRob2Q6ICdQT1NUJywgdXJsOiAnL29yZGVycycsIGRhdGE6IGF0dGVtcHQuaW5wdXQsIGhlYWRlcnM6IHsgJ0lkZW1wb3RlbmN5LUtleSc6IGF0dGVtcHQua2V5IH0gfSwgZXBvY2gpKS5kYXRhKSxcbiAgICBvblN1Y2Nlc3M6IG9yZGVyID0+IHsgaWYgKGVwb2NoID09PSBpZGVudGl0eUVwb2NoKCkpIHsgY2xpZW50LnNldFF1ZXJ5RGF0YShvcmRlcktleXMuZGV0YWlsKHVzZXJJZCwgb3JkZXIuaWQpLCAocHJldmlvdXM6IHVua25vd24pID0+IHsgY29uc3QgcGFyc2VkID0gb3JkZXJTY2hlbWEuc2FmZVBhcnNlKHByZXZpb3VzKTsgcmV0dXJuIHBhcnNlZC5zdWNjZXNzICYmIChwYXJzZWQuZGF0YS52ZXJzaW9uID4gb3JkZXIudmVyc2lvbiB8fCAocGFyc2VkLmRhdGEuc3RhdHVzICE9PSAncGVuZGluZycgJiYgb3JkZXIuc3RhdHVzID09PSAncGVuZGluZycpKSA/IHBhcnNlZC5kYXRhIDogb3JkZXIgfSk7IHZvaWQgY2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IG9yZGVyS2V5cy5hbGwodXNlcklkKSwgZXhhY3Q6IHRydWUgfSkgfSB9LFxuICB9KVxufVxuIl19