import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/footer.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { HomeFooter } from "/src/components/layout/home-footer.tsx?t=1793943067885";
import { useDesktop } from "/src/lib/use-desktop.ts";
import { Link, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/layout/footer.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function Footer() {
	_s();
	const desktop = useDesktop();
	const isHome = useRouterState({ select: (state) => state.location.pathname === "/" });
	if (desktop && isHome) return /* @__PURE__ */ _jsxDEV(HomeFooter, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 33
	}, this);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("footer", {
		className: "legacy-footer border-t",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "kurio-container flex flex-wrap items-center justify-between gap-6 py-8",
			children: [/* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				className: "text-xl font-bold",
				"aria-label": "Kurio — início",
				children: "kurio."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-muted-foreground",
				children: "Kurio · NFT Marketplace"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_s(Footer, "AYGqPVIdbrLzTxvLN+mLo/Ci0Ro=", false, function() {
	return [useDesktop, useRouterState];
});
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/footer.tsx?t=1793943067885";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/layout/footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/layout/footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/layout/footer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxNQUFNLHNCQUFzQjs7OztBQUVyQyxPQUFPLFNBQVMsU0FBUzs7Q0FDdkIsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsTUFBTSxTQUFTLGVBQWUsRUFBRSxTQUFRLFVBQVMsTUFBTSxTQUFTLGFBQWEsSUFBSSxDQUFDO0NBQ2xGLElBQUksV0FBVyxRQUFRLE9BQU8sd0JBQUMsWUFBRCxDQUFhOzs7OztDQUMzQyxPQUNFLCtDQUNBLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQ2hCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQU0sSUFBRztJQUFJLFdBQVU7SUFBb0IsY0FBVztjQUFpQjtHQUFZOzs7O2FBQ25GLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWdDO0dBQTBCOzs7O1dBQ3BFOzs7Ozs7Q0FDQzs7OztVQUNOOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZvb3Rlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSG9tZUZvb3RlciB9IGZyb20gJy4vaG9tZS1mb290ZXInXG5pbXBvcnQgeyB1c2VEZXNrdG9wIH0gZnJvbSAnQC9saWIvdXNlLWRlc2t0b3AnXG5pbXBvcnQgeyBMaW5rLCB1c2VSb3V0ZXJTdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5cbmV4cG9ydCBmdW5jdGlvbiBGb290ZXIoKSB7XG4gIGNvbnN0IGRlc2t0b3AgPSB1c2VEZXNrdG9wKClcbiAgY29uc3QgaXNIb21lID0gdXNlUm91dGVyU3RhdGUoeyBzZWxlY3Q6IHN0YXRlID0+IHN0YXRlLmxvY2F0aW9uLnBhdGhuYW1lID09PSAnLycgfSlcbiAgaWYgKGRlc2t0b3AgJiYgaXNIb21lKSByZXR1cm4gPEhvbWVGb290ZXIgLz5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwibGVnYWN5LWZvb3RlciBib3JkZXItdFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJrdXJpby1jb250YWluZXIgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNiBweS04XCI+XG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkXCIgYXJpYS1sYWJlbD1cIkt1cmlvIOKAlCBpbsOtY2lvXCI+a3VyaW8uPC9MaW5rPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkt1cmlvIMK3IE5GVCBNYXJrZXRwbGFjZTwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9vdGVyPlxuICAgIDwvPlxuICApXG59XG4iXX0=