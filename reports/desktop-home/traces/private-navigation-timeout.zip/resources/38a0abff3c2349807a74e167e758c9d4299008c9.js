import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { favoritesSchema } from "/src/contracts/cart.ts";
import { api, ApiRequestError } from "/src/lib/api.ts";
import { scopedRequest } from "/src/lib/scoped-request.ts";
import { identityEpoch } from "/src/lib/identity.ts";
import { useSession } from "/src/features/auth/api.ts";
export const favoriteKey = (userId) => [
	"private",
	userId,
	"favorites"
];
export function useFavorites() {
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	return useQuery({
		queryKey: favoriteKey(userId),
		enabled: !!userId,
		staleTime: 3e4,
		queryFn: async ({ signal }) => favoritesSchema.parse((await api.get("/favorites", { signal })).data)
	});
}
export function useFavoriteMutation(nft) {
	const client = useQueryClient();
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	const key = favoriteKey(userId);
	const epochAtRender = identityEpoch();
	return useMutation({
		mutationKey: [
			"private",
			userId,
			"favorite-mutation"
		],
		retry: false,
		mutationFn: async (adding) => favoritesSchema.parse((await scopedRequest({
			url: `/favorites/${encodeURIComponent(nft.id)}`,
			method: adding ? "POST" : "DELETE"
		}, epochAtRender)).data),
		onMutate: async (adding) => {
			const epoch = identityEpoch();
			await client.cancelQueries({ queryKey: key });
			if (epoch !== identityEpoch()) throw new ApiRequestError("A sessão mudou. Tente novamente.", "SESSION_CHANGED");
			const previous = client.getQueryData(key);
			client.setQueryData(key, { items: adding ? [...(previous?.items ?? []).filter((item) => item.id !== nft.id), nft] : (previous?.items ?? []).filter((item) => item.id !== nft.id) });
			return {
				previous,
				epoch
			};
		},
		onError: (_error, _adding, context) => {
			if (context?.epoch === identityEpoch()) client.setQueryData(key, context.previous ?? { items: [] });
		},
		onSuccess: (data, _adding, context) => {
			if (context?.epoch === identityEpoch()) client.setQueryData(key, data);
		},
		onSettled: (_data, _error, _adding, context) => {
			if (context?.epoch === identityEpoch()) return client.invalidateQueries({ queryKey: key });
		}
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFVBQVUsc0JBQXNCO0FBQ3RELFNBQVMsdUJBQXVDO0FBRWhELFNBQVMsS0FBSyx1QkFBdUI7QUFDckMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTyxNQUFNLGVBQWUsV0FBbUI7Q0FBQztDQUFXO0NBQVE7QUFBVztBQUM5RSxPQUFPLFNBQVMsZUFBZTtDQUM3QixNQUFNLFVBQVUsV0FBVztDQUMzQixNQUFNLFNBQVMsUUFBUSxNQUFNLEtBQUssTUFBTTtDQUN4QyxPQUFPLFNBQVM7RUFBRSxVQUFVLFlBQVksTUFBTTtFQUFHLFNBQVMsQ0FBQyxDQUFDO0VBQVEsV0FBVztFQUM3RSxTQUFTLE9BQU8sRUFBRSxhQUFhLGdCQUFnQixPQUFPLE1BQU0sSUFBSSxJQUFhLGNBQWMsRUFBRSxPQUFPLENBQUMsRUFBQyxDQUFFLElBQUk7Q0FDOUcsQ0FBQztBQUNIO0FBQ0EsT0FBTyxTQUFTLG9CQUFvQixLQUFVO0NBQzVDLE1BQU0sU0FBUyxlQUFlO0NBQzlCLE1BQU0sVUFBVSxXQUFXO0NBQzNCLE1BQU0sU0FBUyxRQUFRLE1BQU0sS0FBSyxNQUFNO0NBQ3hDLE1BQU0sTUFBTSxZQUFZLE1BQU07Q0FDOUIsTUFBTSxnQkFBZ0IsY0FBYztDQUNwQyxPQUFPLFlBQVk7RUFDakIsYUFBYTtHQUFDO0dBQVc7R0FBUTtFQUFtQjtFQUFHLE9BQU87RUFDOUQsWUFBWSxPQUFPLFdBQW9CLGdCQUFnQixPQUFPLE1BQU0sY0FBYztHQUFFLEtBQUssY0FBYyxtQkFBbUIsSUFBSSxFQUFFO0dBQUssUUFBUSxTQUFTLFNBQVM7RUFBUyxHQUFHLGFBQWEsRUFBQyxDQUFFLElBQUk7RUFDL0wsVUFBVSxPQUFNLFdBQVU7R0FDeEIsTUFBTSxRQUFRLGNBQWM7R0FDNUIsTUFBTSxPQUFPLGNBQWMsRUFBRSxVQUFVLElBQUksQ0FBQztHQUM1QyxJQUFJLFVBQVUsY0FBYyxHQUFHLE1BQU0sSUFBSSxnQkFBZ0Isb0NBQW9DLGlCQUFpQjtHQUM5RyxNQUFNLFdBQVcsT0FBTyxhQUF3QixHQUFHO0dBQ25ELE9BQU8sYUFBd0IsS0FBSyxFQUFFLE9BQU8sU0FBUyxDQUFDLElBQUksVUFBVSxTQUFTLENBQUMsRUFBQyxDQUFFLFFBQU8sU0FBUSxLQUFLLE9BQU8sSUFBSSxFQUFFLEdBQUcsR0FBRyxLQUFLLFVBQVUsU0FBUyxDQUFDLEVBQUMsQ0FBRSxRQUFPLFNBQVEsS0FBSyxPQUFPLElBQUksRUFBRSxFQUFFLENBQUM7R0FDekwsT0FBTztJQUFFO0lBQVU7R0FBTTtFQUMzQjtFQUNBLFVBQVUsUUFBUSxTQUFTLFlBQVk7R0FBRSxJQUFJLFNBQVMsVUFBVSxjQUFjLEdBQUcsT0FBTyxhQUFhLEtBQUssUUFBUSxZQUFZLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUFFO0VBQzdJLFlBQVksTUFBTSxTQUFTLFlBQVk7R0FBRSxJQUFJLFNBQVMsVUFBVSxjQUFjLEdBQUcsT0FBTyxhQUFhLEtBQUssSUFBSTtFQUFFO0VBQ2hILFlBQVksT0FBTyxRQUFRLFNBQVMsWUFBWTtHQUFFLElBQUksU0FBUyxVQUFVLGNBQWMsR0FBRyxPQUFPLE9BQU8sa0JBQWtCLEVBQUUsVUFBVSxJQUFJLENBQUM7RUFBRTtDQUMvSSxDQUFDO0FBQ0giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicXVlcmllcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgZmF2b3JpdGVzU2NoZW1hLCB0eXBlIEZhdm9yaXRlcyB9IGZyb20gJ0AvY29udHJhY3RzL2NhcnQnXG5pbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCdcbmltcG9ydCB7IGFwaSwgQXBpUmVxdWVzdEVycm9yIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgc2NvcGVkUmVxdWVzdCB9IGZyb20gJ0AvbGliL3Njb3BlZC1yZXF1ZXN0J1xuaW1wb3J0IHsgaWRlbnRpdHlFcG9jaCB9IGZyb20gJ0AvbGliL2lkZW50aXR5J1xuaW1wb3J0IHsgdXNlU2Vzc2lvbiB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9hcGknXG5leHBvcnQgY29uc3QgZmF2b3JpdGVLZXkgPSAodXNlcklkOiBzdHJpbmcpID0+IFsncHJpdmF0ZScsIHVzZXJJZCwgJ2Zhdm9yaXRlcyddIGFzIGNvbnN0XG5leHBvcnQgZnVuY3Rpb24gdXNlRmF2b3JpdGVzKCkge1xuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpXG4gIGNvbnN0IHVzZXJJZCA9IHNlc3Npb24uZGF0YT8udXNlci5pZCA/PyAnJ1xuICByZXR1cm4gdXNlUXVlcnkoeyBxdWVyeUtleTogZmF2b3JpdGVLZXkodXNlcklkKSwgZW5hYmxlZDogISF1c2VySWQsIHN0YWxlVGltZTogMzAwMDAsXG4gICAgcXVlcnlGbjogYXN5bmMgKHsgc2lnbmFsIH0pID0+IGZhdm9yaXRlc1NjaGVtYS5wYXJzZSgoYXdhaXQgYXBpLmdldDx1bmtub3duPignL2Zhdm9yaXRlcycsIHsgc2lnbmFsIH0pKS5kYXRhKSxcbiAgfSlcbn1cbmV4cG9ydCBmdW5jdGlvbiB1c2VGYXZvcml0ZU11dGF0aW9uKG5mdDogTmZ0KSB7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKVxuICBjb25zdCB1c2VySWQgPSBzZXNzaW9uLmRhdGE/LnVzZXIuaWQgPz8gJydcbiAgY29uc3Qga2V5ID0gZmF2b3JpdGVLZXkodXNlcklkKVxuICBjb25zdCBlcG9jaEF0UmVuZGVyID0gaWRlbnRpdHlFcG9jaCgpXG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25LZXk6IFsncHJpdmF0ZScsIHVzZXJJZCwgJ2Zhdm9yaXRlLW11dGF0aW9uJ10sIHJldHJ5OiBmYWxzZSxcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoYWRkaW5nOiBib29sZWFuKSA9PiBmYXZvcml0ZXNTY2hlbWEucGFyc2UoKGF3YWl0IHNjb3BlZFJlcXVlc3QoeyB1cmw6IGAvZmF2b3JpdGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KG5mdC5pZCl9YCwgbWV0aG9kOiBhZGRpbmcgPyAnUE9TVCcgOiAnREVMRVRFJyB9LCBlcG9jaEF0UmVuZGVyKSkuZGF0YSksXG4gICAgb25NdXRhdGU6IGFzeW5jIGFkZGluZyA9PiB7XG4gICAgICBjb25zdCBlcG9jaCA9IGlkZW50aXR5RXBvY2goKVxuICAgICAgYXdhaXQgY2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pXG4gICAgICBpZiAoZXBvY2ggIT09IGlkZW50aXR5RXBvY2goKSkgdGhyb3cgbmV3IEFwaVJlcXVlc3RFcnJvcignQSBzZXNzw6NvIG11ZG91LiBUZW50ZSBub3ZhbWVudGUuJywgJ1NFU1NJT05fQ0hBTkdFRCcpXG4gICAgICBjb25zdCBwcmV2aW91cyA9IGNsaWVudC5nZXRRdWVyeURhdGE8RmF2b3JpdGVzPihrZXkpXG4gICAgICBjbGllbnQuc2V0UXVlcnlEYXRhPEZhdm9yaXRlcz4oa2V5LCB7IGl0ZW1zOiBhZGRpbmcgPyBbLi4uKHByZXZpb3VzPy5pdGVtcyA/PyBbXSkuZmlsdGVyKGl0ZW0gPT4gaXRlbS5pZCAhPT0gbmZ0LmlkKSwgbmZ0XSA6IChwcmV2aW91cz8uaXRlbXMgPz8gW10pLmZpbHRlcihpdGVtID0+IGl0ZW0uaWQgIT09IG5mdC5pZCkgfSlcbiAgICAgIHJldHVybiB7IHByZXZpb3VzLCBlcG9jaCB9XG4gICAgfSxcbiAgICBvbkVycm9yOiAoX2Vycm9yLCBfYWRkaW5nLCBjb250ZXh0KSA9PiB7IGlmIChjb250ZXh0Py5lcG9jaCA9PT0gaWRlbnRpdHlFcG9jaCgpKSBjbGllbnQuc2V0UXVlcnlEYXRhKGtleSwgY29udGV4dC5wcmV2aW91cyA/PyB7IGl0ZW1zOiBbXSB9KSB9LFxuICAgIG9uU3VjY2VzczogKGRhdGEsIF9hZGRpbmcsIGNvbnRleHQpID0+IHsgaWYgKGNvbnRleHQ/LmVwb2NoID09PSBpZGVudGl0eUVwb2NoKCkpIGNsaWVudC5zZXRRdWVyeURhdGEoa2V5LCBkYXRhKSB9LFxuICAgIG9uU2V0dGxlZDogKF9kYXRhLCBfZXJyb3IsIF9hZGRpbmcsIGNvbnRleHQpID0+IHsgaWYgKGNvbnRleHQ/LmVwb2NoID09PSBpZGVudGl0eUVwb2NoKCkpIHJldHVybiBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pIH0sXG4gIH0pXG59XG4iXX0=