import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/orders/orders-page.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link, useRouter, useSearch } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { LoadingState, ErrorState } from "/src/components/async-state.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "/src/components/ui/dialog.tsx";
import { apiErrorMessage } from "/src/lib/api.ts";
import { QuoteValues } from "/src/features/checkout/quote-values.tsx";
import { useOrder, useOrders } from "/src/features/orders/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/orders/orders-page.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
function Receipt({ order }) {
	_s();
	const snapshot = order.snapshot;
	const [explore, setExplore] = useState(false);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		"data-testid": "order-receipt",
		children: [
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-primary",
				children: "Seus NFTs foram confirmados pela simulação."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 65
			}, this),
			/* @__PURE__ */ _jsxDEV("dl", {
				className: "receipt-meta",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Pedido" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 39
					}, this), /* @__PURE__ */ _jsxDEV("dd", {
						"data-testid": "order-id",
						children: order.id
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 54
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 34
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Transação simulada" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 107
					}, this), /* @__PURE__ */ _jsxDEV("dd", { children: order.transactionReference }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 134
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 102
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Data" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 182
					}, this), /* @__PURE__ */ _jsxDEV("dd", { children: order.updatedAt }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 195
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 177
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Rede" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 232
					}, this), /* @__PURE__ */ _jsxDEV("dd", { children: snapshot.network }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 245
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 227
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Carteira" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 283
					}, this), /* @__PURE__ */ _jsxDEV("dd", { children: [
						snapshot.wallet.label,
						" · ",
						snapshot.wallet.provider,
						" · ",
						snapshot.wallet.address
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 300
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 278
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Estado" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 400
					}, this), /* @__PURE__ */ _jsxDEV("dd", { children: "Confirmado" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 415
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 395
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("h3", {
				className: "font-bold",
				children: "Detalhes da transação"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 5
			}, this),
			snapshot.items.map((item) => /* @__PURE__ */ _jsxDEV("article", {
				className: "receipt-line",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "cart-art",
						children: item.nft.image.src ? /* @__PURE__ */ _jsxDEV("img", {
							src: item.nft.image.src,
							alt: item.nft.image.alt
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 129
						}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "Arte original indisponível" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 189
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 81
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "font-bold break-words",
								children: item.nft.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 260
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: item.edition.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 316
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								item.quantity,
								" × ",
								item.edition.price.amount,
								" ETH"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 342
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 235
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "break-all",
						children: [item.lineTotal, " ETH"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 404
					}, this)
				]
			}, item.id, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 33
			}, this)),
			/* @__PURE__ */ _jsxDEV(QuoteValues, { quote: snapshot }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs",
				children: "Recibo histórico da simulação. Não representa uma transação real em blockchain."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				onClick: () => setExplore(!explore),
				children: "Explorar transação simulada"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 5
			}, this),
			explore && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "break-all",
				children: [
					"Referência fictícia: ",
					order.transactionReference,
					". Nenhum explorador de blockchain real é utilizado."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 116
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 10
	}, this);
}
_s(Receipt, "IcA/zULVE0qmHLdWMLxj1lHUrXI=");
_c = Receipt;
function OrderDetail({ id }) {
	_s2();
	const query = useOrder(id);
	const router = useRouter();
	if (query.isPending) return /* @__PURE__ */ _jsxDEV(LoadingState, { label: "Consultando pedido" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 31
	}, this);
	if (query.isError) return /* @__PURE__ */ _jsxDEV(ErrorState, {
		message: apiErrorMessage(query.error),
		retry: () => void query.refetch()
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 29
	}, this);
	const order = query.data;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "commerce-panel space-y-6",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-bold",
				"data-testid": "order-status",
				children: order.status === "pending" ? "Pedido pendente" : order.status === "confirmed" ? "Compra confirmada" : "Pagamento recusado"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 75
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "break-all",
				children: ["Pedido: ", order.id]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 5
			}, this),
			order.status === "pending" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				children: "Aguardando o resultado do pagamento simulado. Seu carrinho foi preservado."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 38
			}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Você pode atualizar esta página para recuperar o mesmo pedido." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 133
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 36
			}, this),
			order.status === "rejected" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: order.reason
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 39
			}, this), /* @__PURE__ */ _jsxDEV(Link, {
				to: "/carrinho",
				className: "text-primary",
				children: "Revisar carrinho para uma nova tentativa"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 73
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 37
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				onClick: () => void query.refetch(),
				disabled: query.isFetching,
				children: "Consultar estado do pedido"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				to: "/pedido/confirmacao",
				search: { orderId: undefined },
				className: "text-primary",
				children: "Ver meus pedidos"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: order.status === "confirmed",
				onOpenChange: (open) => {
					if (!open) void router.navigate({
						to: "/pedido/confirmacao",
						search: { orderId: undefined }
					});
				},
				children: /* @__PURE__ */ _jsxDEV(DialogContent, {
					className: "kurio-theme review-dialog",
					children: [
						/* @__PURE__ */ _jsxDEV(DialogTitle, { children: "Compra confirmada" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 224
						}, this),
						/* @__PURE__ */ _jsxDEV(DialogDescription, { children: "Recibo imutável fornecido pela API simulada." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 268
						}, this),
						/* @__PURE__ */ _jsxDEV(Receipt, { order }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 351
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 171
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 10
	}, this);
}
_s2(OrderDetail, "JqmNA0CemEDDgNW4jpkBi8WBG/c=", false, function() {
	return [useOrder, useRouter];
});
_c2 = OrderDetail;
function OrdersList() {
	_s3();
	const query = useOrders();
	if (query.isPending) return /* @__PURE__ */ _jsxDEV(LoadingState, { label: "Carregando pedidos" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 31
	}, this);
	if (query.isError) return /* @__PURE__ */ _jsxDEV(ErrorState, {
		message: apiErrorMessage(query.error),
		retry: () => void query.refetch()
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 29
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: query.data.items.length ? query.data.items.map((order) => /* @__PURE__ */ _jsxDEV("article", {
			className: "commerce-panel space-y-3",
			children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "break-all",
					children: order.id
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 155
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: [
					order.status,
					" · ",
					order.snapshot.total,
					" ETH"
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 194
				}, this),
				/* @__PURE__ */ _jsxDEV(Link, {
					className: "text-primary",
					to: "/pedido/confirmacao",
					search: { orderId: order.id },
					children: "Acompanhar pedido"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 244
				}, this)
			]
		}, order.id, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 94
		}, this)) : /* @__PURE__ */ _jsxDEV("p", {
			role: "status",
			children: "Nenhum pedido selecionado. Você ainda não tem pedidos."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 369
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 10
	}, this);
}
_s3(OrdersList, "MMg4Smbc6yZRgyrF/8LHqMax0PA=", false, function() {
	return [useOrders];
});
_c3 = OrdersList;
export function OrdersPage() {
	_s4();
	const { orderId } = useSearch({ strict: false });
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-8",
		children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "text-3xl font-bold",
			children: "Confirmação do pedido"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 41
		}, this), orderId ? /* @__PURE__ */ _jsxDEV(OrderDetail, { id: orderId }, orderId, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 113
		}, this) : /* @__PURE__ */ _jsxDEV(OrdersList, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 158
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 10
	}, this);
}
_s4(OrdersPage, "5gjcEgYK85KvB4Nzq2cdNHrEB5c=", false, function() {
	return [useSearch];
});
_c4 = OrdersPage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Receipt");
$RefreshReg$(_c2, "OrderDetail");
$RefreshReg$(_c3, "OrdersList");
$RefreshReg$(_c4, "OrdersPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/orders/orders-page.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/orders/orders-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/orders/orders-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/orders/orders-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLFdBQVcsaUJBQWlCO0FBRTNDLFNBQVMsY0FBYyxrQkFBa0I7QUFDekMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsUUFBUSxlQUFlLG1CQUFtQixtQkFBbUI7QUFDdEUsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxVQUFVLGlCQUFpQjs7OztBQUNwQyxTQUFTLFFBQVEsRUFBRSxTQUEyQjs7Q0FDNUMsTUFBTSxXQUFXLE1BQU07Q0FBVSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM3RSxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQVksZUFBWTtZQUF2QztHQUF1RCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFlO0dBQThDOzs7OztHQUN0SSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFkO0tBQTZCLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUksU0FBVTs7OztlQUFDLHdCQUFDLE1BQUQ7TUFBSSxlQUFZO2dCQUFZLE1BQU07S0FBTzs7OzthQUFNOzs7OztLQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUkscUJBQXNCOzs7O2VBQUMsd0JBQUMsTUFBRCxZQUFLLE1BQU0scUJBQXlCOzs7O2FBQU07Ozs7O0tBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSSxPQUFROzs7O2VBQUMsd0JBQUMsTUFBRCxZQUFLLE1BQU0sVUFBYzs7OzthQUFNOzs7OztLQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUksT0FBUTs7OztlQUFDLHdCQUFDLE1BQUQsWUFBSyxTQUFTLFFBQVk7Ozs7YUFBTTs7Ozs7S0FBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7ZUFBQyx3QkFBQyxNQUFEO01BQUssU0FBUyxPQUFPO01BQU07TUFBSSxTQUFTLE9BQU87TUFBUztNQUFJLFNBQVMsT0FBTztLQUFZOzs7O2FBQU07Ozs7O0tBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSSxTQUFVOzs7O2VBQUMsd0JBQUMsTUFBRCxZQUFJLGFBQWM7Ozs7YUFBTTs7Ozs7SUFBSzs7Ozs7O0dBQ3ZiLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQVk7R0FBeUI7Ozs7O0dBQ2xELFNBQVMsTUFBTSxLQUFJLFNBQVEsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkI7S0FBZ0Qsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQVksS0FBSyxJQUFJLE1BQU0sTUFBTSx3QkFBQyxPQUFEO09BQUssS0FBSyxLQUFLLElBQUksTUFBTTtPQUFLLEtBQUssS0FBSyxJQUFJLE1BQU07TUFBTTs7OztpQkFBSSx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7OztLQUFPOzs7OztLQUFDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQXlCLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUF5QixLQUFLLElBQUk7T0FBUTs7Ozs7T0FBQyx3QkFBQyxLQUFELFlBQUksS0FBSyxRQUFRLEtBQVE7Ozs7O09BQUMsd0JBQUMsS0FBRDtRQUFJLEtBQUs7UUFBUztRQUFJLEtBQUssUUFBUSxNQUFNO1FBQU87T0FBTzs7Ozs7TUFBTTs7Ozs7O0tBQUMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FBMEIsS0FBSyxXQUFVLE1BQU87Ozs7OztJQUFVO01BQXRZLEtBQUs7Ozs7VUFBaVksQ0FBQztHQUMxYyx3QkFBQyxhQUFELEVBQWEsT0FBTyxTQUFXOzs7OztHQUMvQix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFVO0dBQWtGOzs7OztHQUN6Ryx3QkFBQyxRQUFEO0lBQVEsU0FBUTtJQUFVLGVBQWUsV0FBVyxDQUFDLE9BQU87Y0FBRztHQUFtQzs7Ozs7R0FBRSxXQUFXLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO0lBQVMsV0FBVTtjQUEzQjtLQUF1QztLQUFzQixNQUFNO0tBQXFCO0lBQXNEOzs7Ozs7RUFDMVA7Ozs7OztBQUNQOzs7QUFDQSxTQUFTLFlBQVksRUFBRSxNQUFzQjs7Q0FDM0MsTUFBTSxRQUFRLFNBQVMsRUFBRTtDQUFHLE1BQU0sU0FBUyxVQUFVO0NBQ3JELElBQUksTUFBTSxXQUFXLE9BQU8sd0JBQUMsY0FBRCxFQUFjLE9BQU0scUJBQXNCOzs7OztDQUN0RSxJQUFJLE1BQU0sU0FBUyxPQUFPLHdCQUFDLFlBQUQ7RUFBWSxTQUFTLGdCQUFnQixNQUFNLEtBQUs7RUFBRyxhQUFhLEtBQUssTUFBTSxRQUFRO0NBQUk7Ozs7O0NBQ2pILE1BQU0sUUFBUSxNQUFNO0NBQ3BCLE9BQU8sd0JBQUMsV0FBRDtFQUFTLFdBQVU7RUFBMkIsYUFBVTtZQUF4RDtHQUFpRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtJQUFvQixlQUFZO2NBQWdCLE1BQU0sV0FBVyxZQUFZLG9CQUFvQixNQUFNLFdBQVcsY0FBYyxzQkFBc0I7R0FBeUI7Ozs7O0dBQ25RLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWIsQ0FBeUIsWUFBUyxNQUFNLEVBQU07Ozs7OztHQUM3QyxNQUFNLFdBQVcsYUFBYSxnREFBRSx3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFTO0dBQTZFOzs7O2FBQUMsd0JBQUMsS0FBRCxZQUFHLGlFQUFpRTs7OztXQUFHOzs7OztHQUN0TSxNQUFNLFdBQVcsY0FBYyxnREFBRSx3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFTLE1BQU07R0FBVTs7OzthQUFDLHdCQUFDLE1BQUQ7SUFBTSxJQUFHO0lBQVksV0FBVTtjQUFlO0dBQThDOzs7O1dBQUc7Ozs7O0dBQ25LLHdCQUFDLFFBQUQ7SUFBUSxTQUFRO0lBQVUsZUFBZSxLQUFLLE1BQU0sUUFBUTtJQUFHLFVBQVUsTUFBTTtjQUFZO0dBQWtDOzs7OztHQUM3SCx3QkFBQyxNQUFEO0lBQU0sSUFBRztJQUFzQixRQUFRLEVBQUUsU0FBUyxVQUFVO0lBQUcsV0FBVTtjQUFlO0dBQXNCOzs7OztHQUM5Ryx3QkFBQyxRQUFEO0lBQVEsTUFBTSxNQUFNLFdBQVc7SUFBYSxlQUFjLFNBQVE7S0FBRSxJQUFJLENBQUMsTUFBTSxLQUFLLE9BQU8sU0FBUztNQUFFLElBQUk7TUFBdUIsUUFBUSxFQUFFLFNBQVMsVUFBVTtLQUFFLENBQUM7SUFBRTtjQUFHLHdCQUFDLGVBQUQ7S0FBZSxXQUFVO2VBQXpCO01BQXFELHdCQUFDLGFBQUQsWUFBYSxvQkFBOEI7Ozs7O01BQUMsd0JBQUMsbUJBQUQsWUFBbUIsK0NBQStEOzs7OztNQUFDLHdCQUFDLFNBQUQsRUFBZ0IsTUFBUTs7Ozs7S0FBZ0I7Ozs7OztHQUFTOzs7OztFQUNwWTs7Ozs7O0FBQ1g7Ozs7O0FBQ0EsU0FBUyxhQUFhOztDQUNwQixNQUFNLFFBQVEsVUFBVTtDQUN4QixJQUFJLE1BQU0sV0FBVyxPQUFPLHdCQUFDLGNBQUQsRUFBYyxPQUFNLHFCQUFzQjs7Ozs7Q0FDdEUsSUFBSSxNQUFNLFNBQVMsT0FBTyx3QkFBQyxZQUFEO0VBQVksU0FBUyxnQkFBZ0IsTUFBTSxLQUFLO0VBQUcsYUFBYSxLQUFLLE1BQU0sUUFBUTtDQUFJOzs7OztDQUNqSCxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWEsTUFBTSxLQUFLLE1BQU0sU0FBUyxNQUFNLEtBQUssTUFBTSxLQUFJLFVBQVMsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkI7SUFBNkQsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYSxNQUFNO0lBQU07Ozs7O0lBQUMsd0JBQUMsS0FBRDtLQUFJLE1BQU07S0FBTztLQUFJLE1BQU0sU0FBUztLQUFNO0lBQU87Ozs7O0lBQUMsd0JBQUMsTUFBRDtLQUFNLFdBQVU7S0FBZSxJQUFHO0tBQXNCLFFBQVEsRUFBRSxTQUFTLE1BQU0sR0FBRztlQUFHO0lBQXVCOzs7OztHQUFVO0tBQTNOLE1BQU07Ozs7U0FBcU4sQ0FBQyxJQUFJLHdCQUFDLEtBQUQ7R0FBRyxNQUFLO2FBQVM7RUFBeUQ7Ozs7O0NBQU87Ozs7O0FBQ2pjOzs7OztBQUNBLE9BQU8sU0FBUyxhQUFhOztDQUMzQixNQUFNLEVBQUUsWUFBWSxVQUFVLEVBQUUsUUFBUSxNQUFNLENBQUM7Q0FDL0MsT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQixDQUErQix3QkFBQyxNQUFEO0dBQUksV0FBVTthQUFxQjtFQUF5Qjs7OztZQUFFLFVBQVUsd0JBQUMsYUFBRCxFQUFhLElBQUksUUFBd0IsR0FBVjs7OztTQUFVLElBQUksd0JBQUMsWUFBRCxDQUFhOzs7O1VBQVc7Ozs7OztBQUNyTCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJvcmRlcnMtcGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmssIHVzZVJvdXRlciwgdXNlU2VhcmNoIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB0eXBlIHsgT3JkZXIgfSBmcm9tICdAL2NvbnRyYWN0cy9vcmRlcidcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSwgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9hc3luYy1zdGF0ZSdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ0NvbnRlbnQsIERpYWxvZ0Rlc2NyaXB0aW9uLCBEaWFsb2dUaXRsZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9kaWFsb2cnXG5pbXBvcnQgeyBhcGlFcnJvck1lc3NhZ2UgfSBmcm9tICdAL2xpYi9hcGknXG5pbXBvcnQgeyBRdW90ZVZhbHVlcyB9IGZyb20gJ0AvZmVhdHVyZXMvY2hlY2tvdXQvcXVvdGUtdmFsdWVzJ1xuaW1wb3J0IHsgdXNlT3JkZXIsIHVzZU9yZGVycyB9IGZyb20gJy4vcXVlcmllcydcbmZ1bmN0aW9uIFJlY2VpcHQoeyBvcmRlciB9OiB7IG9yZGVyOiBPcmRlciB9KSB7XG4gIGNvbnN0IHNuYXBzaG90ID0gb3JkZXIuc25hcHNob3Q7IGNvbnN0IFtleHBsb3JlLCBzZXRFeHBsb3JlXSA9IHVzZVN0YXRlKGZhbHNlKVxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBkYXRhLXRlc3RpZD1cIm9yZGVyLXJlY2VpcHRcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIj5TZXVzIE5GVHMgZm9yYW0gY29uZmlybWFkb3MgcGVsYSBzaW11bGHDp8Ojby48L3A+XG4gICAgPGRsIGNsYXNzTmFtZT1cInJlY2VpcHQtbWV0YVwiPjxkaXY+PGR0PlBlZGlkbzwvZHQ+PGRkIGRhdGEtdGVzdGlkPVwib3JkZXItaWRcIj57b3JkZXIuaWR9PC9kZD48L2Rpdj48ZGl2PjxkdD5UcmFuc2HDp8OjbyBzaW11bGFkYTwvZHQ+PGRkPntvcmRlci50cmFuc2FjdGlvblJlZmVyZW5jZX08L2RkPjwvZGl2PjxkaXY+PGR0PkRhdGE8L2R0PjxkZD57b3JkZXIudXBkYXRlZEF0fTwvZGQ+PC9kaXY+PGRpdj48ZHQ+UmVkZTwvZHQ+PGRkPntzbmFwc2hvdC5uZXR3b3JrfTwvZGQ+PC9kaXY+PGRpdj48ZHQ+Q2FydGVpcmE8L2R0PjxkZD57c25hcHNob3Qud2FsbGV0LmxhYmVsfSDCtyB7c25hcHNob3Qud2FsbGV0LnByb3ZpZGVyfSDCtyB7c25hcHNob3Qud2FsbGV0LmFkZHJlc3N9PC9kZD48L2Rpdj48ZGl2PjxkdD5Fc3RhZG88L2R0PjxkZD5Db25maXJtYWRvPC9kZD48L2Rpdj48L2RsPlxuICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5EZXRhbGhlcyBkYSB0cmFuc2HDp8OjbzwvaDM+XG4gICAge3NuYXBzaG90Lml0ZW1zLm1hcChpdGVtID0+IDxhcnRpY2xlIGNsYXNzTmFtZT1cInJlY2VpcHQtbGluZVwiIGtleT17aXRlbS5pZH0+PGRpdiBjbGFzc05hbWU9XCJjYXJ0LWFydFwiPntpdGVtLm5mdC5pbWFnZS5zcmMgPyA8aW1nIHNyYz17aXRlbS5uZnQuaW1hZ2Uuc3JjfSBhbHQ9e2l0ZW0ubmZ0LmltYWdlLmFsdH0gLz4gOiA8c3Bhbj5BcnRlIG9yaWdpbmFsIGluZGlzcG9uw612ZWw8L3NwYW4+fTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPjxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBicmVhay13b3Jkc1wiPntpdGVtLm5mdC5uYW1lfTwvcD48cD57aXRlbS5lZGl0aW9uLm5hbWV9PC9wPjxwPntpdGVtLnF1YW50aXR5fSDDlyB7aXRlbS5lZGl0aW9uLnByaWNlLmFtb3VudH0gRVRIPC9wPjwvZGl2PjxwIGNsYXNzTmFtZT1cImJyZWFrLWFsbFwiPntpdGVtLmxpbmVUb3RhbH0gRVRIPC9wPjwvYXJ0aWNsZT4pfVxuICAgIDxRdW90ZVZhbHVlcyBxdW90ZT17c25hcHNob3R9IC8+XG4gICAgPHAgY2xhc3NOYW1lPVwidGV4dC14c1wiPlJlY2libyBoaXN0w7NyaWNvIGRhIHNpbXVsYcOnw6NvLiBOw6NvIHJlcHJlc2VudGEgdW1hIHRyYW5zYcOnw6NvIHJlYWwgZW0gYmxvY2tjaGFpbi48L3A+XG4gICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHNldEV4cGxvcmUoIWV4cGxvcmUpfT5FeHBsb3JhciB0cmFuc2HDp8OjbyBzaW11bGFkYTwvQnV0dG9uPntleHBsb3JlICYmIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJicmVhay1hbGxcIj5SZWZlcsOqbmNpYSBmaWN0w61jaWE6IHtvcmRlci50cmFuc2FjdGlvblJlZmVyZW5jZX0uIE5lbmh1bSBleHBsb3JhZG9yIGRlIGJsb2NrY2hhaW4gcmVhbCDDqSB1dGlsaXphZG8uPC9wPn1cbiAgPC9kaXY+XG59XG5mdW5jdGlvbiBPcmRlckRldGFpbCh7IGlkIH06IHsgaWQ6IHN0cmluZyB9KSB7XG4gIGNvbnN0IHF1ZXJ5ID0gdXNlT3JkZXIoaWQpOyBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuICBpZiAocXVlcnkuaXNQZW5kaW5nKSByZXR1cm4gPExvYWRpbmdTdGF0ZSBsYWJlbD1cIkNvbnN1bHRhbmRvIHBlZGlkb1wiIC8+XG4gIGlmIChxdWVyeS5pc0Vycm9yKSByZXR1cm4gPEVycm9yU3RhdGUgbWVzc2FnZT17YXBpRXJyb3JNZXNzYWdlKHF1ZXJ5LmVycm9yKX0gcmV0cnk9eygpID0+IHZvaWQgcXVlcnkucmVmZXRjaCgpfSAvPlxuICBjb25zdCBvcmRlciA9IHF1ZXJ5LmRhdGFcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbW1lcmNlLXBhbmVsIHNwYWNlLXktNlwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPjxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZFwiIGRhdGEtdGVzdGlkPVwib3JkZXItc3RhdHVzXCI+e29yZGVyLnN0YXR1cyA9PT0gJ3BlbmRpbmcnID8gJ1BlZGlkbyBwZW5kZW50ZScgOiBvcmRlci5zdGF0dXMgPT09ICdjb25maXJtZWQnID8gJ0NvbXByYSBjb25maXJtYWRhJyA6ICdQYWdhbWVudG8gcmVjdXNhZG8nfTwvaDI+XG4gICAgPHAgY2xhc3NOYW1lPVwiYnJlYWstYWxsXCI+UGVkaWRvOiB7b3JkZXIuaWR9PC9wPlxuICAgIHtvcmRlci5zdGF0dXMgPT09ICdwZW5kaW5nJyAmJiA8PjxwIHJvbGU9XCJzdGF0dXNcIj5BZ3VhcmRhbmRvIG8gcmVzdWx0YWRvIGRvIHBhZ2FtZW50byBzaW11bGFkby4gU2V1IGNhcnJpbmhvIGZvaSBwcmVzZXJ2YWRvLjwvcD48cD5Wb2PDqiBwb2RlIGF0dWFsaXphciBlc3RhIHDDoWdpbmEgcGFyYSByZWN1cGVyYXIgbyBtZXNtbyBwZWRpZG8uPC9wPjwvPn1cbiAgICB7b3JkZXIuc3RhdHVzID09PSAncmVqZWN0ZWQnICYmIDw+PHAgcm9sZT1cImFsZXJ0XCI+e29yZGVyLnJlYXNvbn08L3A+PExpbmsgdG89XCIvY2FycmluaG9cIiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIj5SZXZpc2FyIGNhcnJpbmhvIHBhcmEgdW1hIG5vdmEgdGVudGF0aXZhPC9MaW5rPjwvPn1cbiAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4gdm9pZCBxdWVyeS5yZWZldGNoKCl9IGRpc2FibGVkPXtxdWVyeS5pc0ZldGNoaW5nfT5Db25zdWx0YXIgZXN0YWRvIGRvIHBlZGlkbzwvQnV0dG9uPlxuICAgIDxMaW5rIHRvPVwiL3BlZGlkby9jb25maXJtYWNhb1wiIHNlYXJjaD17eyBvcmRlcklkOiB1bmRlZmluZWQgfX0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCI+VmVyIG1ldXMgcGVkaWRvczwvTGluaz5cbiAgICA8RGlhbG9nIG9wZW49e29yZGVyLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCd9IG9uT3BlbkNoYW5nZT17b3BlbiA9PiB7IGlmICghb3Blbikgdm9pZCByb3V0ZXIubmF2aWdhdGUoeyB0bzogJy9wZWRpZG8vY29uZmlybWFjYW8nLCBzZWFyY2g6IHsgb3JkZXJJZDogdW5kZWZpbmVkIH0gfSkgfX0+PERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwia3VyaW8tdGhlbWUgcmV2aWV3LWRpYWxvZ1wiPjxEaWFsb2dUaXRsZT5Db21wcmEgY29uZmlybWFkYTwvRGlhbG9nVGl0bGU+PERpYWxvZ0Rlc2NyaXB0aW9uPlJlY2libyBpbXV0w6F2ZWwgZm9ybmVjaWRvIHBlbGEgQVBJIHNpbXVsYWRhLjwvRGlhbG9nRGVzY3JpcHRpb24+PFJlY2VpcHQgb3JkZXI9e29yZGVyfSAvPjwvRGlhbG9nQ29udGVudD48L0RpYWxvZz5cbiAgPC9zZWN0aW9uPlxufVxuZnVuY3Rpb24gT3JkZXJzTGlzdCgpIHtcbiAgY29uc3QgcXVlcnkgPSB1c2VPcmRlcnMoKVxuICBpZiAocXVlcnkuaXNQZW5kaW5nKSByZXR1cm4gPExvYWRpbmdTdGF0ZSBsYWJlbD1cIkNhcnJlZ2FuZG8gcGVkaWRvc1wiIC8+XG4gIGlmIChxdWVyeS5pc0Vycm9yKSByZXR1cm4gPEVycm9yU3RhdGUgbWVzc2FnZT17YXBpRXJyb3JNZXNzYWdlKHF1ZXJ5LmVycm9yKX0gcmV0cnk9eygpID0+IHZvaWQgcXVlcnkucmVmZXRjaCgpfSAvPlxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj57cXVlcnkuZGF0YS5pdGVtcy5sZW5ndGggPyBxdWVyeS5kYXRhLml0ZW1zLm1hcChvcmRlciA9PiA8YXJ0aWNsZSBjbGFzc05hbWU9XCJjb21tZXJjZS1wYW5lbCBzcGFjZS15LTNcIiBrZXk9e29yZGVyLmlkfT48cCBjbGFzc05hbWU9XCJicmVhay1hbGxcIj57b3JkZXIuaWR9PC9wPjxwPntvcmRlci5zdGF0dXN9IMK3IHtvcmRlci5zbmFwc2hvdC50b3RhbH0gRVRIPC9wPjxMaW5rIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIHRvPVwiL3BlZGlkby9jb25maXJtYWNhb1wiIHNlYXJjaD17eyBvcmRlcklkOiBvcmRlci5pZCB9fT5BY29tcGFuaGFyIHBlZGlkbzwvTGluaz48L2FydGljbGU+KSA6IDxwIHJvbGU9XCJzdGF0dXNcIj5OZW5odW0gcGVkaWRvIHNlbGVjaW9uYWRvLiBWb2PDqiBhaW5kYSBuw6NvIHRlbSBwZWRpZG9zLjwvcD59PC9kaXY+XG59XG5leHBvcnQgZnVuY3Rpb24gT3JkZXJzUGFnZSgpIHtcbiAgY29uc3QgeyBvcmRlcklkIH0gPSB1c2VTZWFyY2goeyBzdHJpY3Q6IGZhbHNlIH0pIGFzIHsgb3JkZXJJZD86IHN0cmluZyB9XG4gIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj48aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkXCI+Q29uZmlybWHDp8OjbyBkbyBwZWRpZG88L2gxPntvcmRlcklkID8gPE9yZGVyRGV0YWlsIGlkPXtvcmRlcklkfSBrZXk9e29yZGVySWR9IC8+IDogPE9yZGVyc0xpc3QgLz59PC9zZWN0aW9uPlxufVxuIl19