import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/wallets/collector-fields.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Input } from "/src/components/ui/input.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/wallets/collector-fields.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
export function CollectorFields({ form, prefix }) {
	const labels = {
		displayName: "Nome de exibição",
		username: "Nome de usuário",
		profileName: "Nome do perfil",
		email: "E-mail",
		referralCode: "Código de indicação",
		ensName: "Nome ENS"
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "commerce-form-grid",
		children: Object.keys(labels).map((key) => /* @__PURE__ */ _jsxDEV("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: `${prefix}-${key}`,
					children: labels[key]
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 5
				}, this),
				/* @__PURE__ */ _jsxDEV(Input, {
					id: `${prefix}-${key}`,
					type: key === "email" ? "email" : "text",
					...form.register(`collector.${key}`),
					"aria-invalid": !!form.formState.errors.collector?.[key],
					"aria-describedby": `${prefix}-${key}-error`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 8,
					columnNumber: 5
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					id: `${prefix}-${key}-error`,
					className: "field-error",
					children: form.formState.errors.collector?.[key]?.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 9,
					columnNumber: 5
				}, this)
			]
		}, key, true, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 107
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 10
	}, this);
}
_c = CollectorFields;
var _c;
$RefreshReg$(_c, "CollectorFields");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/wallets/collector-fields.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/wallets/collector-fields.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/wallets/collector-fields.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/wallets/collector-fields.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsU0FBUyxhQUFhOzs7QUFDdEIsT0FBTyxTQUFTLGdCQUFnQixFQUFFLE1BQU0sVUFBZ0U7Q0FDdEcsTUFBTSxTQUFTO0VBQUUsYUFBYTtFQUFvQixVQUFVO0VBQW1CLGFBQWE7RUFBa0IsT0FBTztFQUFVLGNBQWM7RUFBdUIsU0FBUztDQUFXO0NBQ3hMLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBdUIsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUE2QixLQUFJLFFBQU8sd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUN0Ryx3QkFBQyxTQUFEO0tBQU8sU0FBUyxHQUFHLE9BQU8sR0FBRztlQUFRLE9BQU87SUFBWTs7Ozs7SUFDeEQsd0JBQUMsT0FBRDtLQUFPLElBQUksR0FBRyxPQUFPLEdBQUc7S0FBTyxNQUFNLFFBQVEsVUFBVSxVQUFVO0tBQVEsR0FBSSxLQUFLLFNBQVMsYUFBYSxLQUFLO0tBQUcsZ0JBQWMsQ0FBQyxDQUFDLEtBQUssVUFBVSxPQUFPLFlBQVk7S0FBTSxvQkFBa0IsR0FBRyxPQUFPLEdBQUcsSUFBSTtJQUFVOzs7OztJQUNyTix3QkFBQyxLQUFEO0tBQUcsSUFBSSxHQUFHLE9BQU8sR0FBRyxJQUFJO0tBQVMsV0FBVTtlQUFlLEtBQUssVUFBVSxPQUFPLFlBQVksSUFBSSxFQUFFO0lBQVc7Ozs7O0dBQzFHO0tBSm1JOzs7O1NBSW5JLENBQUM7Q0FBTzs7Ozs7QUFDZiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJjb2xsZWN0b3ItZmllbGRzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFVzZUZvcm1SZXR1cm4gfSBmcm9tICdyZWFjdC1ob29rLWZvcm0nXG5pbXBvcnQgdHlwZSB7IFdhbGxldElucHV0IH0gZnJvbSAnQC9jb250cmFjdHMvd2FsbGV0J1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5leHBvcnQgZnVuY3Rpb24gQ29sbGVjdG9yRmllbGRzKHsgZm9ybSwgcHJlZml4IH06IHsgZm9ybTogVXNlRm9ybVJldHVybjxXYWxsZXRJbnB1dD47IHByZWZpeDogc3RyaW5nIH0pIHtcbiAgY29uc3QgbGFiZWxzID0geyBkaXNwbGF5TmFtZTogJ05vbWUgZGUgZXhpYmnDp8OjbycsIHVzZXJuYW1lOiAnTm9tZSBkZSB1c3XDoXJpbycsIHByb2ZpbGVOYW1lOiAnTm9tZSBkbyBwZXJmaWwnLCBlbWFpbDogJ0UtbWFpbCcsIHJlZmVycmFsQ29kZTogJ0PDs2RpZ28gZGUgaW5kaWNhw6fDo28nLCBlbnNOYW1lOiAnTm9tZSBFTlMnIH0gYXMgY29uc3RcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiY29tbWVyY2UtZm9ybS1ncmlkXCI+eyhPYmplY3Qua2V5cyhsYWJlbHMpIGFzIChrZXlvZiB0eXBlb2YgbGFiZWxzKVtdKS5tYXAoa2V5ID0+IDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCIga2V5PXtrZXl9PlxuICAgIDxsYWJlbCBodG1sRm9yPXtgJHtwcmVmaXh9LSR7a2V5fWB9PntsYWJlbHNba2V5XX08L2xhYmVsPlxuICAgIDxJbnB1dCBpZD17YCR7cHJlZml4fS0ke2tleX1gfSB0eXBlPXtrZXkgPT09ICdlbWFpbCcgPyAnZW1haWwnIDogJ3RleHQnfSB7Li4uZm9ybS5yZWdpc3RlcihgY29sbGVjdG9yLiR7a2V5fWApfSBhcmlhLWludmFsaWQ9eyEhZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmNvbGxlY3Rvcj8uW2tleV19IGFyaWEtZGVzY3JpYmVkYnk9e2Ake3ByZWZpeH0tJHtrZXl9LWVycm9yYH0gLz5cbiAgICA8cCBpZD17YCR7cHJlZml4fS0ke2tleX0tZXJyb3JgfSBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuY29sbGVjdG9yPy5ba2V5XT8ubWVzc2FnZX08L3A+XG4gIDwvZGl2Pil9PC9kaXY+XG59XG4iXX0=