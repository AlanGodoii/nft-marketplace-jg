import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/home-footer.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/layout/home-footer.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function HomeFooter() {
	_s();
	const [message, setMessage] = useState("");
	const unavailable = () => setMessage("Recurso fora do escopo desta demonstração; nenhum envio ou navegação externa foi realizado.");
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "home-footer desktop-home-only",
		children: [
			/* @__PURE__ */ _jsxDEV("section", {
				className: "footer-information kurio-container",
				"aria-label": "Informações da Kurio",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "footer-medallion",
							"aria-hidden": "true",
							children: "W"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 10,
							columnNumber: 12
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "Segurança da carteira" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 10,
							columnNumber: 74
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Proteja sua carteira e colecione arte digital verificada com confiança." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 10,
							columnNumber: 104
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 10,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						id: "criadores",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "footer-medallion",
								"aria-hidden": "true",
								children: "C"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 11,
								columnNumber: 27
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", { children: "Criadores em destaque" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 11,
								columnNumber: 89
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 11,
								columnNumber: 119
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "footer-medallion",
							"aria-hidden": "true",
							children: "D"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 12,
							columnNumber: 12
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "Alertas de lançamentos" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 12,
							columnNumber: 74
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 12,
							columnNumber: 105
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "Antecipe-se ao próximo lançamento" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 13,
							columnNumber: 12
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: (event) => {
								event.preventDefault();
								setMessage("Inscrição indisponível nesta demonstração. Nenhum e-mail foi enviado ou armazenado.");
							},
							children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "sr-only",
									htmlFor: "newsletter-email",
									children: "E-mail para novidades"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 13,
									columnNumber: 206
								}, this),
								/* @__PURE__ */ _jsxDEV(Input, {
									id: "newsletter-email",
									type: "email",
									required: true,
									placeholder: "digite seu e-mail..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 13,
									columnNumber: 289
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									type: "submit",
									children: "Enviar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 13,
									columnNumber: 377
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 13,
							columnNumber: 54
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Receba lançamentos selecionados, histórias de criadores e novidades do mercado." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 13,
							columnNumber: 421
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: "Newsletter ilustrativa, sem envio." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 13,
							columnNumber: 507
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-contact",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "kurio-container",
					children: [
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/",
							children: "KURIO"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 70
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: [
							"Feito para colecionadores,",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 124
							}, this),
							"criadores e cultura"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 95
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: ["contato@email.com", /* @__PURE__ */ _jsxDEV("small", { children: "Contato ilustrativo do layout" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 173
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 153
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: ["+55 11 4002 8922", /* @__PURE__ */ _jsxDEV("small", { children: "Telefone ilustrativo do layout" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 240
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 221
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 37
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-links kurio-container",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "Meu perfil" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 12
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/perfil",
							children: "Meu perfil"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 31
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/favoritos",
							children: "Minha coleção / lista de interesse"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 67
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/pedido/confirmacao",
							children: "Meus pedidos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 130
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: unavailable,
							children: "Atividade · indisponível"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 180
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: unavailable,
							children: "Estúdio do criador · indisponível"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 243
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Central de ajuda" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 12
					}, this), [
						"Central de ajuda",
						"Como comprar NFTs",
						"Carteira e segurança",
						"Política do mercado",
						"Denunciar item"
					].map((text) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: unavailable,
						"aria-label": `${text} (indisponível nesta demonstração)`,
						children: text
					}, text, false, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 157
					}, this))] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Coleções" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 12
					}, this), [
						["genesis", "Genesis"],
						["nomads", "Nomads"],
						["signals", "Signals"]
					].map(([collection, name]) => /* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						search: (previous) => ({
							...previous,
							collection,
							page: 1
						}),
						hash: "catalogo",
						children: name
					}, collection, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 123
					}, this))] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "Redes sociais" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 12
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "footer-socials",
							children: [
								["f", "Facebook"],
								["◎", "Instagram"],
								["𝕏", "𝕏 / Twitter"],
								["in", "in / LinkedIn"],
								["▶", "YouTube"]
							].map(([symbol, label]) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: unavailable,
								"aria-label": `${label} (link indisponível)`,
								children: /* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": "true",
									children: symbol
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 20,
									columnNumber: 275
								}, this)
							}, label, false, {
								fileName: _jsxFileName,
								lineNumber: 20,
								columnNumber: 189
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 34
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "compatible-title",
							children: "Carteiras compatíveis"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 332
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "compatible-wallets",
							children: "METAMASK · WALLETCONNECT · COINBASE"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 391
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: "Conexões simuladas, sem extensões." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 464
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				"aria-live": "polite",
				className: "footer-feedback kurio-container",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-copyright",
				children: "© 2026 Kurio. Propriedade digital para todos."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 10
	}, this);
}
_s(HomeFooter, "l8KXAebGu4sZHsyCIQX7P8si41w=");
_c = HomeFooter;
var _c;
$RefreshReg$(_c, "HomeFooter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/home-footer.tsx?t=1793943067885";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/layout/home-footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/layout/home-footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/layout/home-footer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsY0FBYztBQUN2QixTQUFTLGFBQWE7Ozs7QUFDdEIsT0FBTyxTQUFTLGFBQWE7O0NBQzNCLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sb0JBQW9CLFdBQVcsNkZBQTZGO0NBQ2xJLE9BQU8sd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFBbEI7R0FDTCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtJQUFxQyxjQUFXO2NBQW5FO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO09BQW1CLGVBQVk7aUJBQU87TUFBTzs7Ozs7TUFBQyx3QkFBQyxNQUFELFlBQUksd0JBQXlCOzs7OztNQUFDLHdCQUFDLEtBQUQsWUFBRywwRUFBMEU7Ozs7O0tBQU07Ozs7O0tBQ3BMLHdCQUFDLE9BQUQ7TUFBSyxJQUFHO2dCQUFSO09BQW9CLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO1FBQW1CLGVBQVk7a0JBQU87T0FBTzs7Ozs7T0FBQyx3QkFBQyxNQUFELFlBQUksd0JBQXlCOzs7OztPQUFDLHdCQUFDLEtBQUQsWUFBRyxpRkFBaUY7Ozs7O01BQU07Ozs7OztLQUMxTSx3QkFBQyxPQUFEO01BQUssd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBbUIsZUFBWTtpQkFBTztNQUFPOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSSx5QkFBMEI7Ozs7O01BQUMsd0JBQUMsS0FBRCxZQUFHLHVGQUF1Rjs7Ozs7S0FBTTs7Ozs7S0FDbE0sd0JBQUMsT0FBRDtNQUFLLHdCQUFDLE1BQUQsWUFBSSxvQ0FBcUM7Ozs7O01BQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVUsVUFBUztRQUFFLE1BQU0sZUFBZTtRQUFHLFdBQVcscUZBQXFGO09BQUU7aUJBQXJKO1FBQXdKLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO1NBQVUsU0FBUTttQkFBbUI7UUFBNEI7Ozs7O1FBQUMsd0JBQUMsT0FBRDtTQUFPLElBQUc7U0FBbUIsTUFBSztTQUFRO1NBQVMsYUFBWTtRQUF3Qjs7Ozs7UUFBQyx3QkFBQyxRQUFEO1NBQVEsTUFBSzttQkFBUztRQUFjOzs7OztPQUFPOzs7Ozs7TUFBQyx3QkFBQyxLQUFELFlBQUcsa0ZBQWtGOzs7OztNQUFDLHdCQUFDLFNBQUQsWUFBTyxxQ0FBeUM7Ozs7O0tBQU07Ozs7O0lBQ25pQjs7Ozs7O0dBQ1Qsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBaUIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUFpQyx3QkFBQyxNQUFEO09BQU0sSUFBRztpQkFBSTtNQUFXOzs7OztNQUFDLHdCQUFDLEtBQUQ7T0FBRztPQUEwQix3QkFBQyxNQUFELENBQUs7Ozs7O09BQUM7TUFBc0I7Ozs7O01BQUMsd0JBQUMsS0FBRCxhQUFHLHFCQUFpQix3QkFBQyxTQUFELFlBQU8sZ0NBQW9DOzs7O2NBQUk7Ozs7O01BQUMsd0JBQUMsS0FBRCxhQUFHLG9CQUFnQix3QkFBQyxTQUFELFlBQU8saUNBQXFDOzs7O2NBQUk7Ozs7O0tBQU07Ozs7OztHQUFNOzs7OztHQUN2Uyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLHdCQUFDLE1BQUQsWUFBSSxhQUFjOzs7OztNQUFDLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO2lCQUFVO01BQWdCOzs7OztNQUFDLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO2lCQUFhO01BQXdDOzs7OztNQUFDLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO2lCQUFzQjtNQUFrQjs7Ozs7TUFBQyx3QkFBQyxVQUFEO09BQVEsU0FBUztpQkFBYTtNQUFnQzs7Ozs7TUFBQyx3QkFBQyxVQUFEO09BQVEsU0FBUztpQkFBYTtNQUF5Qzs7Ozs7S0FBTTs7Ozs7S0FDelQsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSSxtQkFBb0I7Ozs7ZUFBRTtNQUFDO01BQW9CO01BQXFCO01BQXdCO01BQXVCO0tBQWdCLENBQUMsQ0FBQyxLQUFJLFNBQVEsd0JBQUMsVUFBRDtNQUFtQixTQUFTO01BQWEsY0FBWSxHQUFHLEtBQUs7Z0JBQXNDO0tBQWEsR0FBbkc7Ozs7WUFBbUcsQ0FBQyxDQUFPOzs7OztLQUM5USx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7ZUFBRTtNQUFDLENBQUMsV0FBVSxTQUFTO01BQUUsQ0FBQyxVQUFTLFFBQVE7TUFBRSxDQUFDLFdBQVUsU0FBUztLQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBVyxVQUFVLHdCQUFDLE1BQUQ7TUFBdUIsSUFBRztNQUFJLFNBQVEsY0FBYTtPQUFFLEdBQUc7T0FBVTtPQUFZLE1BQU07TUFBRTtNQUFJLE1BQUs7Z0JBQVk7S0FBVyxHQUEzRzs7OztZQUEyRyxDQUFDLENBQU87Ozs7O0tBQ2xQLHdCQUFDLE9BQUQ7TUFBSyx3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztNQUFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFrQjtRQUFDLENBQUMsS0FBSSxVQUFVO1FBQUUsQ0FBQyxLQUFJLFdBQVc7UUFBRSxDQUFDLE1BQUssY0FBYztRQUFFLENBQUMsTUFBSyxlQUFlO1FBQUUsQ0FBQyxLQUFJLFNBQVM7T0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQU8sV0FBVyx3QkFBQyxVQUFEO1FBQW9CLFNBQVM7UUFBYSxjQUFZLEdBQUcsTUFBTTtrQkFBdUIsd0JBQUMsUUFBRDtTQUFNLGVBQVk7bUJBQVE7UUFBYTs7Ozs7T0FBUyxHQUF6SDs7OztjQUF5SCxDQUFDO01BQU87Ozs7O01BQUMsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW1CO01BQXlCOzs7OztNQUFDLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFxQjtNQUFzQzs7Ozs7TUFBQyx3QkFBQyxTQUFELFlBQU8scUNBQXlDOzs7OztLQUFNOzs7OztJQUM1Zjs7Ozs7O0dBQ0wsd0JBQUMsS0FBRDtJQUFHLE1BQUs7SUFBUyxhQUFVO0lBQVMsV0FBVTtjQUFtQztHQUFXOzs7OztHQUM1Rix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFtQjtHQUFrRDs7Ozs7RUFDOUU7Ozs7OztBQUNWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImhvbWUtZm9vdGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5leHBvcnQgZnVuY3Rpb24gSG9tZUZvb3RlcigpIHtcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IHVuYXZhaWxhYmxlID0gKCkgPT4gc2V0TWVzc2FnZSgnUmVjdXJzbyBmb3JhIGRvIGVzY29wbyBkZXN0YSBkZW1vbnN0cmHDp8OjbzsgbmVuaHVtIGVudmlvIG91IG5hdmVnYcOnw6NvIGV4dGVybmEgZm9pIHJlYWxpemFkby4nKVxuICByZXR1cm4gPGZvb3RlciBjbGFzc05hbWU9XCJob21lLWZvb3RlciBkZXNrdG9wLWhvbWUtb25seVwiPlxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZvb3Rlci1pbmZvcm1hdGlvbiBrdXJpby1jb250YWluZXJcIiBhcmlhLWxhYmVsPVwiSW5mb3JtYcOnw7VlcyBkYSBLdXJpb1wiPlxuICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJmb290ZXItbWVkYWxsaW9uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+Vzwvc3Bhbj48aDI+U2VndXJhbsOnYSBkYSBjYXJ0ZWlyYTwvaDI+PHA+UHJvdGVqYSBzdWEgY2FydGVpcmEgZSBjb2xlY2lvbmUgYXJ0ZSBkaWdpdGFsIHZlcmlmaWNhZGEgY29tIGNvbmZpYW7Dp2EuPC9wPjwvZGl2PlxuICAgICAgPGRpdiBpZD1cImNyaWFkb3Jlc1wiPjxzcGFuIGNsYXNzTmFtZT1cImZvb3Rlci1tZWRhbGxpb25cIiBhcmlhLWhpZGRlbj1cInRydWVcIj5DPC9zcGFuPjxoMj5DcmlhZG9yZXMgZW0gZGVzdGFxdWU8L2gyPjxwPkNvbmhlw6dhIGFydGlzdGFzLCBlc3TDumRpb3MgZSBjb211bmlkYWRlcyBxdWUgbW9sZGFtIGEgY3VsdHVyYSBkaWdpdGFsIG5hIHJlZGUuPC9wPjwvZGl2PlxuICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJmb290ZXItbWVkYWxsaW9uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+RDwvc3Bhbj48aDI+QWxlcnRhcyBkZSBsYW7Dp2FtZW50b3M8L2gyPjxwPlJlY2ViYSBjYWxlbmTDoXJpb3MgZGUgY3VuaGFnZW0sIG5vdmlkYWRlcyBkZSBsaXN0YXMgZGUgYWNlc3NvIGUgYW7DoWxpc2VzIGRvIG1lcmNhZG8uPC9wPjwvZGl2PlxuICAgICAgPGRpdj48aDI+QW50ZWNpcGUtc2UgYW8gcHLDs3hpbW8gbGFuw6dhbWVudG88L2gyPjxmb3JtIG9uU3VibWl0PXtldmVudCA9PiB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHNldE1lc3NhZ2UoJ0luc2NyacOnw6NvIGluZGlzcG9uw612ZWwgbmVzdGEgZGVtb25zdHJhw6fDo28uIE5lbmh1bSBlLW1haWwgZm9pIGVudmlhZG8gb3UgYXJtYXplbmFkby4nKSB9fT48bGFiZWwgY2xhc3NOYW1lPVwic3Itb25seVwiIGh0bWxGb3I9XCJuZXdzbGV0dGVyLWVtYWlsXCI+RS1tYWlsIHBhcmEgbm92aWRhZGVzPC9sYWJlbD48SW5wdXQgaWQ9XCJuZXdzbGV0dGVyLWVtYWlsXCIgdHlwZT1cImVtYWlsXCIgcmVxdWlyZWQgcGxhY2Vob2xkZXI9XCJkaWdpdGUgc2V1IGUtbWFpbC4uLlwiIC8+PEJ1dHRvbiB0eXBlPVwic3VibWl0XCI+RW52aWFyPC9CdXR0b24+PC9mb3JtPjxwPlJlY2ViYSBsYW7Dp2FtZW50b3Mgc2VsZWNpb25hZG9zLCBoaXN0w7NyaWFzIGRlIGNyaWFkb3JlcyBlIG5vdmlkYWRlcyBkbyBtZXJjYWRvLjwvcD48c21hbGw+TmV3c2xldHRlciBpbHVzdHJhdGl2YSwgc2VtIGVudmlvLjwvc21hbGw+PC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLWNvbnRhY3RcIj48ZGl2IGNsYXNzTmFtZT1cImt1cmlvLWNvbnRhaW5lclwiPjxMaW5rIHRvPVwiL1wiPktVUklPPC9MaW5rPjxwPkZlaXRvIHBhcmEgY29sZWNpb25hZG9yZXMsPGJyIC8+Y3JpYWRvcmVzIGUgY3VsdHVyYTwvcD48cD5jb250YXRvQGVtYWlsLmNvbTxzbWFsbD5Db250YXRvIGlsdXN0cmF0aXZvIGRvIGxheW91dDwvc21hbGw+PC9wPjxwPis1NSAxMSA0MDAyIDg5MjI8c21hbGw+VGVsZWZvbmUgaWx1c3RyYXRpdm8gZG8gbGF5b3V0PC9zbWFsbD48L3A+PC9kaXY+PC9kaXY+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItbGlua3Mga3VyaW8tY29udGFpbmVyXCI+XG4gICAgICA8ZGl2PjxoMj5NZXUgcGVyZmlsPC9oMj48TGluayB0bz1cIi9wZXJmaWxcIj5NZXUgcGVyZmlsPC9MaW5rPjxMaW5rIHRvPVwiL2Zhdm9yaXRvc1wiPk1pbmhhIGNvbGXDp8OjbyAvIGxpc3RhIGRlIGludGVyZXNzZTwvTGluaz48TGluayB0bz1cIi9wZWRpZG8vY29uZmlybWFjYW9cIj5NZXVzIHBlZGlkb3M8L0xpbms+PGJ1dHRvbiBvbkNsaWNrPXt1bmF2YWlsYWJsZX0+QXRpdmlkYWRlIMK3IGluZGlzcG9uw612ZWw8L2J1dHRvbj48YnV0dG9uIG9uQ2xpY2s9e3VuYXZhaWxhYmxlfT5Fc3TDumRpbyBkbyBjcmlhZG9yIMK3IGluZGlzcG9uw612ZWw8L2J1dHRvbj48L2Rpdj5cbiAgICAgIDxkaXY+PGgyPkNlbnRyYWwgZGUgYWp1ZGE8L2gyPntbJ0NlbnRyYWwgZGUgYWp1ZGEnLCAnQ29tbyBjb21wcmFyIE5GVHMnLCAnQ2FydGVpcmEgZSBzZWd1cmFuw6dhJywgJ1BvbMOtdGljYSBkbyBtZXJjYWRvJywgJ0RlbnVuY2lhciBpdGVtJ10ubWFwKHRleHQgPT4gPGJ1dHRvbiBrZXk9e3RleHR9IG9uQ2xpY2s9e3VuYXZhaWxhYmxlfSBhcmlhLWxhYmVsPXtgJHt0ZXh0fSAoaW5kaXNwb27DrXZlbCBuZXN0YSBkZW1vbnN0cmHDp8OjbylgfT57dGV4dH08L2J1dHRvbj4pfTwvZGl2PlxuICAgICAgPGRpdj48aDI+Q29sZcOnw7VlczwvaDI+e1tbJ2dlbmVzaXMnLCdHZW5lc2lzJ10sWydub21hZHMnLCdOb21hZHMnXSxbJ3NpZ25hbHMnLCdTaWduYWxzJ11dLm1hcCgoW2NvbGxlY3Rpb24sbmFtZV0pID0+IDxMaW5rIGtleT17Y29sbGVjdGlvbn0gdG89XCIvXCIgc2VhcmNoPXtwcmV2aW91cyA9PiAoeyAuLi5wcmV2aW91cywgY29sbGVjdGlvbiwgcGFnZTogMSB9KX0gaGFzaD1cImNhdGFsb2dvXCI+e25hbWV9PC9MaW5rPil9PC9kaXY+XG4gICAgICA8ZGl2PjxoMj5SZWRlcyBzb2NpYWlzPC9oMj48ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1zb2NpYWxzXCI+e1tbJ2YnLCdGYWNlYm9vayddLFsn4peOJywnSW5zdGFncmFtJ10sWyfwnZWPJywn8J2VjyAvIFR3aXR0ZXInXSxbJ2luJywnaW4gLyBMaW5rZWRJbiddLFsn4pa2JywnWW91VHViZSddXS5tYXAoKFtzeW1ib2wsbGFiZWxdKSA9PiA8YnV0dG9uIGtleT17bGFiZWx9IG9uQ2xpY2s9e3VuYXZhaWxhYmxlfSBhcmlhLWxhYmVsPXtgJHtsYWJlbH0gKGxpbmsgaW5kaXNwb27DrXZlbClgfT48c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj57c3ltYm9sfTwvc3Bhbj48L2J1dHRvbj4pfTwvZGl2PjxoMiBjbGFzc05hbWU9XCJjb21wYXRpYmxlLXRpdGxlXCI+Q2FydGVpcmFzIGNvbXBhdMOtdmVpczwvaDI+PHAgY2xhc3NOYW1lPVwiY29tcGF0aWJsZS13YWxsZXRzXCI+TUVUQU1BU0sgwrcgV0FMTEVUQ09OTkVDVCDCtyBDT0lOQkFTRTwvcD48c21hbGw+Q29uZXjDtWVzIHNpbXVsYWRhcywgc2VtIGV4dGVuc8O1ZXMuPC9zbWFsbD48L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8cCByb2xlPVwic3RhdHVzXCIgYXJpYS1saXZlPVwicG9saXRlXCIgY2xhc3NOYW1lPVwiZm9vdGVyLWZlZWRiYWNrIGt1cmlvLWNvbnRhaW5lclwiPnttZXNzYWdlfTwvcD5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1jb3B5cmlnaHRcIj7CqSAyMDI2IEt1cmlvLiBQcm9wcmllZGFkZSBkaWdpdGFsIHBhcmEgdG9kb3MuPC9kaXY+XG4gIDwvZm9vdGVyPlxufVxuIl19