import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=22c23eb4";
import { walletSchema, walletsSchema, connectionSchema } from "/src/contracts/wallet.ts";
import { useSession } from "/src/features/auth/api.ts";
import { api } from "/src/lib/api.ts";
import { identityEpoch } from "/src/lib/identity.ts";
import { scopedRequest } from "/src/lib/scoped-request.ts";
export const walletKey = (userId) => [
	"private",
	userId,
	"wallets"
];
export function useWallets() {
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	return useQuery({
		queryKey: walletKey(userId),
		enabled: !!userId,
		staleTime: 0,
		queryFn: async ({ signal }) => walletsSchema.parse((await api.get("/wallets", { signal })).data)
	});
}
export function useSaveWallet() {
	const client = useQueryClient();
	const session = useSession();
	const epoch = identityEpoch();
	return useMutation({
		mutationKey: [
			"private",
			session.data?.user.id,
			"wallet-save"
		],
		retry: false,
		mutationFn: async ({ id, input }) => walletSchema.parse((await scopedRequest({
			method: id ? "PATCH" : "POST",
			url: id ? `/wallets/${id}` : "/wallets",
			data: input
		}, epoch)).data),
		onSuccess: () => {
			if (epoch === identityEpoch()) return client.invalidateQueries({ queryKey: walletKey(session.data?.user.id ?? "") });
		}
	});
}
export function useWalletConnection() {
	const session = useSession();
	const epoch = identityEpoch();
	return useMutation({
		mutationKey: [
			"private",
			session.data?.user.id,
			"wallet-connection"
		],
		retry: false,
		mutationFn: async ({ walletId, action }) => connectionSchema.parse((await scopedRequest({
			method: "POST",
			url: `/wallets/${walletId}/connection`,
			data: { action }
		}, epoch)).data)
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFVBQVUsc0JBQXNCO0FBQ3RELFNBQVMsY0FBYyxlQUFlLHdCQUEwQztBQUNoRixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLFdBQVc7QUFDcEIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsT0FBTyxNQUFNLGFBQWEsV0FBbUI7Q0FBQztDQUFXO0NBQVE7QUFBUztBQUMxRSxPQUFPLFNBQVMsYUFBYTtDQUMzQixNQUFNLFVBQVUsV0FBVztDQUFHLE1BQU0sU0FBUyxRQUFRLE1BQU0sS0FBSyxNQUFNO0NBQ3RFLE9BQU8sU0FBUztFQUFFLFVBQVUsVUFBVSxNQUFNO0VBQUcsU0FBUyxDQUFDLENBQUM7RUFBUSxXQUFXO0VBQzNFLFNBQVMsT0FBTyxFQUFFLGFBQWEsY0FBYyxPQUFPLE1BQU0sSUFBSSxJQUFJLFlBQVksRUFBRSxPQUFPLENBQUMsRUFBQyxDQUFFLElBQUk7Q0FDakcsQ0FBQztBQUNIO0FBQ0EsT0FBTyxTQUFTLGdCQUFnQjtDQUM5QixNQUFNLFNBQVMsZUFBZTtDQUFHLE1BQU0sVUFBVSxXQUFXO0NBQUcsTUFBTSxRQUFRLGNBQWM7Q0FDM0YsT0FBTyxZQUFZO0VBQUUsYUFBYTtHQUFDO0dBQVcsUUFBUSxNQUFNLEtBQUs7R0FBSTtFQUFhO0VBQUcsT0FBTztFQUMxRixZQUFZLE9BQU8sRUFBRSxJQUFJLFlBQWlELGFBQWEsT0FBTyxNQUFNLGNBQWM7R0FBRSxRQUFRLEtBQUssVUFBVTtHQUFRLEtBQUssS0FBSyxZQUFZLE9BQU87R0FBWSxNQUFNO0VBQU0sR0FBRyxLQUFLLEVBQUMsQ0FBRSxJQUFJO0VBQ3ZOLGlCQUFpQjtHQUFFLElBQUksVUFBVSxjQUFjLEdBQUcsT0FBTyxPQUFPLGtCQUFrQixFQUFFLFVBQVUsVUFBVSxRQUFRLE1BQU0sS0FBSyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQUU7Q0FDMUksQ0FBQztBQUNIO0FBQ0EsT0FBTyxTQUFTLHNCQUFzQjtDQUNwQyxNQUFNLFVBQVUsV0FBVztDQUFHLE1BQU0sUUFBUSxjQUFjO0NBQzFELE9BQU8sWUFBWTtFQUFFLGFBQWE7R0FBQztHQUFXLFFBQVEsTUFBTSxLQUFLO0dBQUk7RUFBbUI7RUFBRyxPQUFPO0VBQ2hHLFlBQVksT0FBTyxFQUFFLFVBQVUsYUFBcUUsaUJBQWlCLE9BQU8sTUFBTSxjQUFjO0dBQUUsUUFBUTtHQUFRLEtBQUssWUFBWSxTQUFTO0dBQWMsTUFBTSxFQUFFLE9BQU87RUFBRSxHQUFHLEtBQUssRUFBQyxDQUFFLElBQUk7Q0FDNU8sQ0FBQztBQUNIIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInF1ZXJpZXMudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHdhbGxldFNjaGVtYSwgd2FsbGV0c1NjaGVtYSwgY29ubmVjdGlvblNjaGVtYSwgdHlwZSBXYWxsZXRJbnB1dCB9IGZyb20gJ0AvY29udHJhY3RzL3dhbGxldCdcbmltcG9ydCB7IHVzZVNlc3Npb24gfSBmcm9tICdAL2ZlYXR1cmVzL2F1dGgvYXBpJ1xuaW1wb3J0IHsgYXBpIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgaWRlbnRpdHlFcG9jaCB9IGZyb20gJ0AvbGliL2lkZW50aXR5J1xuaW1wb3J0IHsgc2NvcGVkUmVxdWVzdCB9IGZyb20gJ0AvbGliL3Njb3BlZC1yZXF1ZXN0J1xuZXhwb3J0IGNvbnN0IHdhbGxldEtleSA9ICh1c2VySWQ6IHN0cmluZykgPT4gWydwcml2YXRlJywgdXNlcklkLCAnd2FsbGV0cyddIGFzIGNvbnN0XG5leHBvcnQgZnVuY3Rpb24gdXNlV2FsbGV0cygpIHtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKTsgY29uc3QgdXNlcklkID0gc2Vzc2lvbi5kYXRhPy51c2VyLmlkID8/ICcnXG4gIHJldHVybiB1c2VRdWVyeSh7IHF1ZXJ5S2V5OiB3YWxsZXRLZXkodXNlcklkKSwgZW5hYmxlZDogISF1c2VySWQsIHN0YWxlVGltZTogMCxcbiAgICBxdWVyeUZuOiBhc3luYyAoeyBzaWduYWwgfSkgPT4gd2FsbGV0c1NjaGVtYS5wYXJzZSgoYXdhaXQgYXBpLmdldCgnL3dhbGxldHMnLCB7IHNpZ25hbCB9KSkuZGF0YSksXG4gIH0pXG59XG5leHBvcnQgZnVuY3Rpb24gdXNlU2F2ZVdhbGxldCgpIHtcbiAgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTsgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKTsgY29uc3QgZXBvY2ggPSBpZGVudGl0eUVwb2NoKClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsncHJpdmF0ZScsIHNlc3Npb24uZGF0YT8udXNlci5pZCwgJ3dhbGxldC1zYXZlJ10sIHJldHJ5OiBmYWxzZSxcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoeyBpZCwgaW5wdXQgfTogeyBpZD86IHN0cmluZzsgaW5wdXQ6IFdhbGxldElucHV0IH0pID0+IHdhbGxldFNjaGVtYS5wYXJzZSgoYXdhaXQgc2NvcGVkUmVxdWVzdCh7IG1ldGhvZDogaWQgPyAnUEFUQ0gnIDogJ1BPU1QnLCB1cmw6IGlkID8gYC93YWxsZXRzLyR7aWR9YCA6ICcvd2FsbGV0cycsIGRhdGE6IGlucHV0IH0sIGVwb2NoKSkuZGF0YSksXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7IGlmIChlcG9jaCA9PT0gaWRlbnRpdHlFcG9jaCgpKSByZXR1cm4gY2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHdhbGxldEtleShzZXNzaW9uLmRhdGE/LnVzZXIuaWQgPz8gJycpIH0pIH0sXG4gIH0pXG59XG5leHBvcnQgZnVuY3Rpb24gdXNlV2FsbGV0Q29ubmVjdGlvbigpIHtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKTsgY29uc3QgZXBvY2ggPSBpZGVudGl0eUVwb2NoKClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsncHJpdmF0ZScsIHNlc3Npb24uZGF0YT8udXNlci5pZCwgJ3dhbGxldC1jb25uZWN0aW9uJ10sIHJldHJ5OiBmYWxzZSxcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoeyB3YWxsZXRJZCwgYWN0aW9uIH06IHsgd2FsbGV0SWQ6IHN0cmluZzsgYWN0aW9uOiAnY29ubmVjdCcgfCAnZGlzY29ubmVjdCcgfSkgPT4gY29ubmVjdGlvblNjaGVtYS5wYXJzZSgoYXdhaXQgc2NvcGVkUmVxdWVzdCh7IG1ldGhvZDogJ1BPU1QnLCB1cmw6IGAvd2FsbGV0cy8ke3dhbGxldElkfS9jb25uZWN0aW9uYCwgZGF0YTogeyBhY3Rpb24gfSB9LCBlcG9jaCkpLmRhdGEpLFxuICB9KVxufVxuIl19