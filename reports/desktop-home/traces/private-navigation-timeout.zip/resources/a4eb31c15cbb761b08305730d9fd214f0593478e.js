import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/checkout/checkout-page.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport23_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport23_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=22c23eb4";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=22c23eb4";
import { checkoutInputSchema } from "/src/contracts/checkout.ts";
import { walletInputSchema } from "/src/contracts/wallet.ts";
import { useCart, useCartMutation } from "/src/features/cart/queries.ts";
import { CollectorFields } from "/src/features/wallets/collector-fields.tsx";
import { useWalletConnection, useWallets } from "/src/features/wallets/queries.ts";
import { LoadingState, ErrorState } from "/src/components/async-state.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "/src/components/ui/dialog.tsx";
import { useSession } from "/src/features/auth/api.ts";
import { readCheckoutDraft, saveCheckoutDraft } from "/src/features/checkout/draft.ts";
import { useRealtime } from "/src/features/realtime/state.ts";
import { usePurchaseAttempt } from "/src/features/orders/attempt.ts";
import { identityEpoch } from "/src/lib/identity.ts";
import { useCreateOrder, useOrder } from "/src/features/orders/queries.ts";
import { apiErrorMessage, ApiRequestError } from "/src/lib/api.ts";
import { useCheckoutQuote } from "/src/features/checkout/queries.ts";
import { quoteDifferences } from "/src/features/checkout/quote-differences.ts";
import { QuoteValues } from "/src/features/checkout/quote-values.tsx";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/checkout/checkout-page.tsx";
import __vite__cjsImport23_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
function CheckoutCoupon({ cart }) {
	_s();
	const mutation = useCartMutation();
	const [code, setCode] = useState("");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (event) => {
					event.preventDefault();
					mutation.mutate({
						type: "coupon",
						code
					});
				},
				className: "space-y-2",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "checkout-coupon",
						children: "Cupom"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 155
					}, this),
					/* @__PURE__ */ _jsxDEV(Input, {
						id: "checkout-coupon",
						value: code,
						onChange: (event) => setCode(event.target.value),
						required: true,
						"aria-describedby": "checkout-coupon-error"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 201
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						disabled: mutation.isPending,
						children: "Aplicar cupom"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 342
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 37
			}, this),
			cart.couponCode && /* @__PURE__ */ _jsxDEV("p", { children: [
				cart.couponCode,
				" ",
				/* @__PURE__ */ _jsxDEV(Button, {
					variant: "link",
					disabled: mutation.isPending,
					onClick: () => mutation.mutate({ type: "remove-coupon" }),
					children: "Remover cupom"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 46
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 25
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				id: "checkout-coupon-error",
				role: mutation.isError ? "alert" : undefined,
				children: mutation.isError ? apiErrorMessage(mutation.error) : ""
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 10
	}, this);
}
_s(CheckoutCoupon, "SQ+lKIbzaMFERMqgVRbw78fqzPk=", false, function() {
	return [useCartMutation];
});
_c = CheckoutCoupon;
function PreviousAttempt({ attempt, clear, recover, pending }) {
	_s2();
	const previous = useOrder(attempt.orderId);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "commerce-panel space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "font-bold",
				children: "Tentativa anterior"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 56
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: "Consulte a mesma tentativa para recuperar seu pedido, inclusive após timeout ou refresh." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 105
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				disabled: pending,
				onClick: recover,
				children: "Recuperar tentativa anterior"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 200
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				to: "/pedido/confirmacao",
				search: { orderId: attempt.orderId },
				className: "text-primary",
				children: "Ver meus pedidos"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 282
			}, this),
			previous.data && previous.data.status !== "pending" && /* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				onClick: clear,
				children: "Começar outra compra"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 455
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 10
	}, this);
}
_s2(PreviousAttempt, "80c8p2T+0EiGPW+o6QIlbPQSqtg=", false, function() {
	return [useOrder];
});
_c2 = PreviousAttempt;
function CheckoutForm({ cart, wallet }) {
	_s3();
	const connection = useWalletConnection();
	const quoteMutation = useCheckoutQuote();
	const live = useRealtime();
	const createOrder = useCreateOrder();
	const { attempt, saveAttempt } = usePurchaseAttempt();
	const router = useRouter();
	const session = useSession();
	const userId = session.data?.user.id ?? "";
	const draft = readCheckoutDraft(userId, wallet);
	const reviewButton = useRef(null);
	const reviewConsent = useRef(null);
	const submitLock = useRef(false);
	const sendLock = useRef(false);
	const renderedEpoch = identityEpoch();
	const [quantities, setQuantities] = useState(draft?.quantities ?? {});
	const [excluded, setExcluded] = useState(draft?.excluded ?? []);
	const [network, setNetwork] = useState(draft?.network ?? wallet.network);
	const [reviewState, setReviewState] = useState(null);
	const [accepted, setAccepted] = useState(false);
	const [notice, setNotice] = useState("");
	const [error, setError] = useState("");
	const form = useForm({
		resolver: zodResolver(walletInputSchema),
		defaultValues: {
			label: wallet.label,
			role: wallet.role,
			network: wallet.network,
			address: wallet.address,
			provider: wallet.provider,
			secondaryAddress: wallet.secondaryAddress,
			collector: draft?.collector ?? wallet.collector
		}
	});
	const persistDraft = (patch = {}) => saveCheckoutDraft(userId, wallet.id, {
		walletVersion: wallet.version,
		collector: form.getValues("collector"),
		network,
		quantities,
		excluded,
		...patch
	});
	const revision = `${cart.items.map((item) => live.nftVersions[item.nftId] ?? 0).join()}:${cart.version}:${cart.items.map((item) => `${item.id}:${item.quantity}:${item.nft.version}`).join("|")}`;
	const review = reviewState?.revision === revision ? reviewState.value : null;
	const setReview = (value) => setReviewState(value ? {
		value,
		revision
	} : null);
	useEffect(() => {
		if (!review) return;
		const timer = setTimeout(() => {
			setReviewState(null);
			setAccepted(false);
			setNotice("A cotação expirou. Revalide antes de confirmar.");
		}, Math.max(0, Date.parse(review.expiresAt) - Date.now()));
		return () => clearTimeout(timer);
	}, [review]);
	const liveChanges = live.lastNft ? cart.items.filter((item) => item.nftId === live.lastNft.id).map((item) => {
		const edition = live.lastNft.editions.find((edition) => edition.id === item.editionId);
		return edition ? `${item.nft.name} · ${edition.name}: preço ${edition.price.amount} ETH, estoque ${edition.availability.remaining}.` : `${item.nft.name}: edição indisponível.`;
	}) : [];
	const connected = connection.data?.status === "connected" && connection.data.walletId === wallet.id && connection.data.network === network;
	const quantityErrors = Object.fromEntries(cart.items.filter((item) => !excluded.includes(item.id)).flatMap((item) => {
		const quantity = quantities[item.id] ?? item.quantity;
		const parsed = checkoutInputSchema.shape.items.element.shape.quantity.safeParse(quantity);
		const message = !parsed.success ? parsed.error.issues[0].message : quantity > item.quantity ? "Não ultrapasse a quantidade do carrinho." : "";
		return message ? [[item.id, message]] : [];
	}));
	const inputFor = (values) => checkoutInputSchema.parse({
		walletId: wallet.id,
		network,
		collector: values.collector,
		items: cart.items.filter((item) => !excluded.includes(item.id)).map((item) => ({
			itemId: item.id,
			quantity: quantities[item.id] ?? item.quantity
		}))
	});
	async function reviewInput(values) {
		setError("");
		setNotice("");
		setAccepted(false);
		if (Object.keys(quantityErrors).length) {
			setError("Corrija as quantidades indicadas.");
			return;
		}
		if (!cart.items.some((item) => !excluded.includes(item.id))) {
			setError("Selecione pelo menos um item para comprar.");
			return;
		}
		try {
			setReview(await quoteMutation.mutateAsync(inputFor(values)));
		} catch (error) {
			setReview(null);
			setError(apiErrorMessage(error));
		}
	}
	async function sendAttempt(purchase) {
		if (sendLock.current) return;
		sendLock.current = true;
		saveAttempt(purchase);
		try {
			const order = await createOrder.mutateAsync(purchase);
			if (renderedEpoch !== identityEpoch()) return;
			saveAttempt({
				...purchase,
				orderId: order.id
			});
			await router.navigate({
				to: "/pedido/confirmacao",
				search: { orderId: order.id }
			});
		} catch (error) {
			if (renderedEpoch !== identityEpoch()) return;
			if (error instanceof ApiRequestError && error.fields?.attempt?.includes("not-created")) saveAttempt(null);
			setReview(null);
			setAccepted(false);
			setError(`${apiErrorMessage(error)}${error instanceof ApiRequestError && error.fields?.attempt ? "" : " O resultado do envio pode ser desconhecido. Recupere a mesma tentativa; não inicie outra compra."}`);
		} finally {
			sendLock.current = false;
		}
	}
	async function validateConfirmedQuote() {
		if (submitLock.current || createOrder.isPending || quoteMutation.isPending) return;
		if (!review || !accepted || !connected) return;
		submitLock.current = true;
		setError("");
		try {
			const next = await quoteMutation.mutateAsync(inputFor(form.getValues()));
			if (next.fingerprint !== review.fingerprint || Date.parse(review.expiresAt) <= Date.now()) {
				setNotice(`A cotação mudou: total anterior ${review.total} ETH; total atualizado ${next.total} ETH. ${quoteDifferences(review, next)} Revise e confirme novamente.`);
				setReview(next);
				setAccepted(false);
				return;
			}
			const purchase = attempt ?? {
				key: crypto.randomUUID(),
				input: {
					quoteId: next.id,
					connectionId: connection.data.connectionId
				}
			};
			await sendAttempt(purchase);
		} catch (error) {
			setReview(null);
			setAccepted(false);
			setError(apiErrorMessage(error));
		} finally {
			submitLock.current = false;
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "checkout-layout",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6 min-w-0",
				children: [
					liveChanges.length > 0 && /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						className: "commerce-panel",
						children: [
							"Atualização ao vivo: ",
							liveChanges.join(" "),
							" A cotação anterior foi invalidada. Revalide e confirme os valores atualizados."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 32
					}, this),
					attempt && /* @__PURE__ */ _jsxDEV(PreviousAttempt, {
						attempt,
						clear: () => saveAttempt(null),
						recover: () => void sendAttempt(attempt),
						pending: createOrder.isPending
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "commerce-panel space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold",
								children: "Carteira e rede"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 51
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "break-all",
								children: [
									wallet.label,
									" · ",
									wallet.provider,
									" · ",
									wallet.address
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 105
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "checkout-network",
								children: "Rede de pagamento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV("select", {
								id: "checkout-network",
								className: "commerce-select",
								value: network,
								onChange: (event) => {
									setNetwork(event.target.value);
									persistDraft({ network: event.target.value });
									setReview(null);
									setAccepted(false);
								},
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "ethereum",
										children: "Ethereum"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 321
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "polygon",
										children: "Polygon"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 363
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "solana",
										children: "Solana"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 403
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 66
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap gap-3",
								children: [/* @__PURE__ */ _jsxDEV(Button, {
									disabled: connection.isPending,
									onClick: () => {
										setReview(null);
										connection.mutate({
											walletId: wallet.id,
											action: "connect"
										});
									},
									children: "Conectar carteira"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 45
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									variant: "outline",
									disabled: connection.isPending,
									onClick: () => {
										setReview(null);
										setAccepted(false);
										connection.mutate({
											walletId: wallet.id,
											action: "disconnect"
										});
									},
									children: "Desconectar carteira"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 210
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								children: connection.isPending ? "Conectando…" : connected ? "Carteira conectada (simulação)." : connection.data?.status === "refused" ? "Conexão recusada. Tente novamente." : "Carteira desconectada."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 7
							}, this),
							connection.isError && /* @__PURE__ */ _jsxDEV("p", {
								role: "alert",
								children: apiErrorMessage(connection.error)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 30
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 5
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						noValidate: true,
						className: "commerce-panel space-y-6",
						"aria-label": "Dados do pagamento",
						onChange: () => {
							persistDraft();
							setReview(null);
							setAccepted(false);
						},
						onSubmit: form.handleSubmit(reviewInput),
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold",
								children: "Perfil do colecionador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 206
							}, this),
							/* @__PURE__ */ _jsxDEV(CollectorFields, {
								form,
								prefix: "checkout"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 267
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "checkout-notes",
								children: "Observação do colecionador (opcional)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV("textarea", {
								id: "checkout-notes",
								...form.register("collector.notes"),
								className: "commerce-select min-h-24",
								"aria-describedby": "checkout-notes-error"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 84
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								id: "checkout-notes-error",
								className: "field-error",
								children: form.formState.errors.collector?.notes?.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 231
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								type: "submit",
								ref: reviewButton,
								disabled: !connected || quoteMutation.isPending || createOrder.isPending || !!attempt,
								children: quoteMutation.isPending ? "Revalidando cotação…" : "Revalidar e revisar compra"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 7
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 5
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 15
					}, this),
					notice && /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						children: notice
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 54
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 43
			}, this),
			/* @__PURE__ */ _jsxDEV("aside", {
				className: "commerce-panel space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-bold",
						children: "Seus NFTs"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 53
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Escolha as edições e quantidades desta compra. Itens não selecionados ficam no carrinho." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 101
					}, this),
					cart.items.map((item) => /* @__PURE__ */ _jsxDEV("article", {
						className: "checkout-item space-y-2",
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										checked: !excluded.includes(item.id),
										onChange: (event) => {
											const next = event.target.checked ? excluded.filter((id) => id !== item.id) : [...excluded, item.id];
											setExcluded(next);
											persistDraft({ excluded: next });
											setReview(null);
										}
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 118
									}, this),
									"Comprar ",
									item.nft.name
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 88
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								item.edition.name,
								" · ",
								item.nft.network.name,
								" · ",
								item.edition.price.amount,
								" ETH"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 405
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: `buy-${item.id}`,
								children: ["Quantidade a comprar de ", item.nft.name]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV(Input, {
								id: `buy-${item.id}`,
								type: "number",
								min: "1",
								step: "1",
								max: item.quantity,
								"aria-invalid": !!quantityErrors[item.id],
								"aria-describedby": `buy-${item.id}-error`,
								value: Number.isFinite(quantities[item.id] ?? item.quantity) ? quantities[item.id] ?? item.quantity : "",
								onChange: (event) => {
									const next = {
										...quantities,
										[item.id]: event.target.valueAsNumber
									};
									setQuantities(next);
									persistDraft({ quantities: next });
									setReview(null);
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 88
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "field-error",
								id: `buy-${item.id}-error`,
								children: quantityErrors[item.id]
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 7
							}, this),
							!item.available && /* @__PURE__ */ _jsxDEV("p", {
								role: "alert",
								children: "Edição indisponível ou estoque esgotado. Corrija o carrinho."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 27
							}, this)
						]
					}, item.id, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 29
					}, this)),
					/* @__PURE__ */ _jsxDEV(CheckoutCoupon, { cart }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 5
					}, this),
					review && /* @__PURE__ */ _jsxDEV(QuoteValues, { quote: review }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 46
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: !!review,
				onOpenChange: (open) => {
					if (!open) {
						setReview(null);
						setAccepted(false);
					}
				},
				children: /* @__PURE__ */ _jsxDEV(DialogContent, {
					className: "kurio-theme review-dialog",
					initialFocus: reviewConsent,
					finalFocus: reviewButton,
					children: [
						/* @__PURE__ */ _jsxDEV(DialogTitle, { children: "Revisar compra" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 213
						}, this),
						/* @__PURE__ */ _jsxDEV(DialogDescription, { children: "Confira os valores e a carteira antes de autorizar o envio." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 254
						}, this),
						review && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "break-all",
								children: [
									review.wallet.label,
									" · ",
									review.network,
									" · ",
									review.wallet.address
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 18
							}, this),
							review.items.map((item) => /* @__PURE__ */ _jsxDEV("p", { children: [
								item.nft.name,
								" · ",
								item.edition.name,
								" · ",
								item.quantity,
								" × ",
								item.edition.price.amount,
								" ETH = ",
								item.lineTotal,
								" ETH"
							] }, item.id, true, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 139
							}, this)),
							/* @__PURE__ */ _jsxDEV(QuoteValues, { quote: review }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 274
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "checkbox",
									ref: reviewConsent,
									checked: accepted,
									onChange: (event) => setAccepted(event.target.checked)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 37
								}, this), "Confirmo os itens, a carteira e os valores desta cotação."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								disabled: !accepted || quoteMutation.isPending || createOrder.isPending || !connected,
								onClick: () => void validateConfirmedQuote(),
								children: createOrder.isPending ? "Enviando pedido…" : "Finalizar compra"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 7
							}, this),
							notice && /* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								children: notice
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 18
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 16
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 105
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 3
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 110,
		columnNumber: 10
	}, this);
}
_s3(CheckoutForm, "ProsNB81CXV15o6Mg3SJG1kIQUw=", false, function() {
	return [
		useWalletConnection,
		useCheckoutQuote,
		useRealtime,
		useCreateOrder,
		usePurchaseAttempt,
		useRouter,
		useSession,
		useForm
	];
});
_c3 = CheckoutForm;
function EmptyCheckoutRecovery() {
	_s4();
	const { attempt, saveAttempt } = usePurchaseAttempt();
	const mutation = useCreateOrder();
	const router = useRouter();
	const epoch = identityEpoch();
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "commerce-panel space-y-4",
		children: [
			attempt && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "font-bold",
					children: "Tentativa anterior"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 19
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: "Recupere a tentativa anterior para consultar o resultado, mesmo com o carrinho vazio." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 68
				}, this),
				/* @__PURE__ */ _jsxDEV(Button, {
					disabled: mutation.isPending,
					onClick: () => mutation.mutate(attempt, {
						onSuccess: (order) => {
							if (epoch === identityEpoch()) {
								saveAttempt({
									...attempt,
									orderId: order.id
								});
								void router.navigate({
									to: "/pedido/confirmacao",
									search: { orderId: order.id }
								});
							}
						},
						onError: (error) => {
							if (epoch === identityEpoch() && error instanceof ApiRequestError && error.fields?.attempt?.includes("not-created")) saveAttempt(null);
						}
					}),
					children: mutation.isPending ? "Consultando tentativa…" : "Recuperar tentativa anterior"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 7
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 144,
				columnNumber: 17
			}, this),
			mutation.isError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: apiErrorMessage(mutation.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 26
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				to: "/pedido/confirmacao",
				search: { orderId: attempt?.orderId },
				className: "text-primary",
				children: "Ver meus pedidos"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 143,
		columnNumber: 10
	}, this);
}
_s4(EmptyCheckoutRecovery, "zidP7lCFg7UXSy5ClklWtT6GIiI=", false, function() {
	return [
		usePurchaseAttempt,
		useCreateOrder,
		useRouter
	];
});
_c4 = EmptyCheckoutRecovery;
export function CheckoutPage() {
	_s5();
	const cart = useCart();
	const wallets = useWallets();
	const [selected, setSelected] = useState("");
	if (cart.isPending || wallets.isPending) return /* @__PURE__ */ _jsxDEV(LoadingState, { label: "Carregando checkout" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 156,
		columnNumber: 51
	}, this);
	if (cart.isError || wallets.isError) return /* @__PURE__ */ _jsxDEV(ErrorState, {
		message: apiErrorMessage(cart.error ?? wallets.error),
		retry: () => {
			void cart.refetch();
			void wallets.refetch();
		}
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 157,
		columnNumber: 47
	}, this);
	const wallet = wallets.data.items.find((wallet) => wallet.id === selected) ?? wallets.data.items[0];
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-3xl font-bold",
				children: "Checkout"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 41
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				to: "/carrinho",
				className: "text-primary",
				children: "Voltar ao carrinho"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 89
			}, this),
			!cart.data.items.length ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				children: "Seu carrinho está vazio."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 34
			}, this), /* @__PURE__ */ _jsxDEV(EmptyCheckoutRecovery, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 79
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 32
			}, this) : !wallet ? /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				children: ["Cadastre uma carteira para continuar. ", /* @__PURE__ */ _jsxDEV(Link, {
					to: "/carteiras",
					className: "text-primary",
					children: "Gerenciar carteiras"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 175
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 120
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-lg space-y-2",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "checkout-wallet",
					children: "Carteira cadastrada"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 43
				}, this), /* @__PURE__ */ _jsxDEV("select", {
					id: "checkout-wallet",
					className: "commerce-select",
					value: wallet.id,
					onChange: (event) => setSelected(event.target.value),
					children: wallets.data.items.map((wallet) => /* @__PURE__ */ _jsxDEV("option", {
						value: wallet.id,
						children: [
							wallet.label,
							" · ",
							wallet.network
						]
					}, wallet.id, true, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 264
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 103
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV(CheckoutForm, {
				wallet,
				cart: cart.data
			}, `${wallet.id}:${wallet.version}`, false, {
				fileName: _jsxFileName,
				lineNumber: 162,
				columnNumber: 7
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 255
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 159,
		columnNumber: 10
	}, this);
}
_s5(CheckoutPage, "7DwEPSNJ3rNzJYnbSX6yQZui3ic=", false, function() {
	return [useCart, useWallets];
});
_c5 = CheckoutPage;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "CheckoutCoupon");
$RefreshReg$(_c2, "PreviousAttempt");
$RefreshReg$(_c3, "CheckoutForm");
$RefreshReg$(_c4, "EmptyCheckoutRecovery");
$RefreshReg$(_c5, "CheckoutPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/checkout/checkout-page.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/checkout/checkout-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/checkout/checkout-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/checkout/checkout-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsTUFBTSxpQkFBaUI7QUFDaEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsbUJBQW1CO0FBRTVCLFNBQVMsMkJBQW1FO0FBQzVFLFNBQVMseUJBQXdEO0FBQ2pFLFNBQVMsU0FBUyx1QkFBdUI7QUFDekMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxxQkFBcUIsa0JBQWtCO0FBQ2hELFNBQVMsY0FBYyxrQkFBa0I7QUFDekMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsYUFBYTtBQUN0QixTQUFTLFFBQVEsZUFBZSxtQkFBbUIsbUJBQW1CO0FBQ3RFLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsbUJBQW1CLHlCQUE2QztBQUN6RSxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGdCQUFnQixnQkFBZ0I7QUFFekMsU0FBUyxpQkFBaUIsdUJBQXVCO0FBQ2pELFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsbUJBQW1COzs7O0FBQzVCLFNBQVMsZUFBZSxFQUFFLFFBQXdCOztDQUNoRCxNQUFNLFdBQVcsZ0JBQWdCO0NBQUcsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDdkUsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQTJCLHdCQUFDLFFBQUQ7SUFBTSxXQUFVLFVBQVM7S0FBRSxNQUFNLGVBQWU7S0FBRyxTQUFTLE9BQU87TUFBRSxNQUFNO01BQVU7S0FBSyxDQUFDO0lBQUU7SUFBRyxXQUFVO2NBQTFHO0tBQXNILHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUFrQjtLQUFZOzs7OztLQUFDLHdCQUFDLE9BQUQ7TUFBTyxJQUFHO01BQWtCLE9BQU87TUFBTSxXQUFVLFVBQVMsUUFBUSxNQUFNLE9BQU8sS0FBSztNQUFHO01BQVMsb0JBQWlCO0tBQXlCOzs7OztLQUFDLHdCQUFDLFFBQUQ7TUFBUSxNQUFLO01BQVMsVUFBVSxTQUFTO2dCQUFXO0tBQXFCOzs7OztJQUFPOzs7Ozs7R0FDaGEsS0FBSyxjQUFjLHdCQUFDLEtBQUQ7SUFBSSxLQUFLO0lBQVc7SUFBQyx3QkFBQyxRQUFEO0tBQVEsU0FBUTtLQUFPLFVBQVUsU0FBUztLQUFXLGVBQWUsU0FBUyxPQUFPLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztlQUFHO0lBQXFCOzs7OztHQUFJOzs7OztHQUNsTCx3QkFBQyxLQUFEO0lBQUcsSUFBRztJQUF3QixNQUFNLFNBQVMsVUFBVSxVQUFVO2NBQVksU0FBUyxVQUFVLGdCQUFnQixTQUFTLEtBQUssSUFBSTtHQUFNOzs7OztFQUNySTs7Ozs7O0FBQ1A7Ozs7O0FBQ0EsU0FBUyxnQkFBZ0IsRUFBRSxTQUFTLE9BQU8sU0FBUyxXQUFtRzs7Q0FDckosTUFBTSxXQUFXLFNBQVMsUUFBUSxPQUFPO0NBQ3pDLE9BQU8sd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FBOEMsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBWTtHQUFzQjs7Ozs7R0FBQyx3QkFBQyxLQUFELFlBQUcsMkZBQTJGOzs7OztHQUFDLHdCQUFDLFFBQUQ7SUFBUSxVQUFVO0lBQVMsU0FBUztjQUFTO0dBQW9DOzs7OztHQUFDLHdCQUFDLE1BQUQ7SUFBTSxJQUFHO0lBQXNCLFFBQVEsRUFBRSxTQUFTLFFBQVEsUUFBUTtJQUFHLFdBQVU7Y0FBZTtHQUFzQjs7Ozs7R0FBRSxTQUFTLFFBQVEsU0FBUyxLQUFLLFdBQVcsYUFBYSx3QkFBQyxRQUFEO0lBQVEsU0FBUTtJQUFVLFNBQVM7Y0FBTztHQUE0Qjs7Ozs7RUFBVzs7Ozs7O0FBQ3ZoQjs7Ozs7QUFDQSxTQUFTLGFBQWEsRUFBRSxNQUFNLFVBQTBDOztDQUN0RSxNQUFNLGFBQWEsb0JBQW9CO0NBQUcsTUFBTSxnQkFBZ0IsaUJBQWlCO0NBQUcsTUFBTSxPQUFPLFlBQVk7Q0FDN0csTUFBTSxjQUFjLGVBQWU7Q0FBRyxNQUFNLEVBQUUsU0FBUyxnQkFBZ0IsbUJBQW1CO0NBQUcsTUFBTSxTQUFTLFVBQVU7Q0FDdEgsTUFBTSxVQUFVLFdBQVc7Q0FBRyxNQUFNLFNBQVMsUUFBUSxNQUFNLEtBQUssTUFBTTtDQUFJLE1BQU0sUUFBUSxrQkFBa0IsUUFBUSxNQUFNO0NBQ3hILE1BQU0sZUFBZSxPQUEwQixJQUFJO0NBQUcsTUFBTSxnQkFBZ0IsT0FBeUIsSUFBSTtDQUN6RyxNQUFNLGFBQWEsT0FBTyxLQUFLO0NBQUcsTUFBTSxXQUFXLE9BQU8sS0FBSztDQUFHLE1BQU0sZ0JBQWdCLGNBQWM7Q0FDdEcsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlDLE9BQU8sY0FBYyxDQUFDLENBQUM7Q0FDNUYsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFtQixPQUFPLFlBQVksQ0FBQyxDQUFDO0NBQ3hFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxPQUFPLFdBQVcsT0FBTyxPQUFPO0NBQ3ZFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUE0RCxJQUFJO0NBQ3RHLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzlDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sT0FBTyxRQUFxQjtFQUFFLFVBQVUsWUFBWSxpQkFBaUI7RUFBRyxlQUFlO0dBQUUsT0FBTyxPQUFPO0dBQU8sTUFBTSxPQUFPO0dBQU0sU0FBUyxPQUFPO0dBQVMsU0FBUyxPQUFPO0dBQVMsVUFBVSxPQUFPO0dBQVUsa0JBQWtCLE9BQU87R0FBa0IsV0FBVyxPQUFPLGFBQWEsT0FBTztFQUFVO0NBQUUsQ0FBQztDQUNsVCxNQUFNLGdCQUFnQixRQUFnQyxDQUFDLE1BQU0sa0JBQWtCLFFBQVEsT0FBTyxJQUFJO0VBQUUsZUFBZSxPQUFPO0VBQVMsV0FBVyxLQUFLLFVBQVUsV0FBVztFQUFHO0VBQVM7RUFBWTtFQUFVLEdBQUc7Q0FBTSxDQUFDO0NBQ3BOLE1BQU0sV0FBVyxHQUFHLEtBQUssTUFBTSxLQUFJLFNBQVEsS0FBSyxZQUFZLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsR0FBRyxLQUFLLFFBQVEsR0FBRyxLQUFLLE1BQU0sS0FBSSxTQUFRLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxTQUFTLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLEtBQUssR0FBRztDQUMxTCxNQUFNLFNBQVMsYUFBYSxhQUFhLFdBQVcsWUFBWSxRQUFRO0NBQ3hFLE1BQU0sYUFBYSxVQUFnQyxlQUFlLFFBQVE7RUFBRTtFQUFPO0NBQVMsSUFBSSxJQUFJO0NBQ3BHLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxRQUFRLGlCQUFpQjtHQUFFLGVBQWUsSUFBSTtHQUFHLFlBQVksS0FBSztHQUFHLFVBQVUsaURBQWlEO0VBQUUsR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sT0FBTyxTQUFTLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQztFQUNqTSxhQUFhLGFBQWEsS0FBSztDQUNqQyxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsTUFBTSxjQUFjLEtBQUssVUFBVSxLQUFLLE1BQU0sUUFBTyxTQUFRLEtBQUssVUFBVSxLQUFLLFFBQVMsRUFBRSxDQUFDLENBQUMsS0FBSSxTQUFRO0VBQ3hHLE1BQU0sVUFBVSxLQUFLLFFBQVMsU0FBUyxNQUFLLFlBQVcsUUFBUSxPQUFPLEtBQUssU0FBUztFQUNwRixPQUFPLFVBQVUsR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLFFBQVEsS0FBSyxVQUFVLFFBQVEsTUFBTSxPQUFPLGdCQUFnQixRQUFRLGFBQWEsVUFBVSxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUs7Q0FDMUosQ0FBQyxJQUFJLENBQUM7Q0FDTixNQUFNLFlBQVksV0FBVyxNQUFNLFdBQVcsZUFBZSxXQUFXLEtBQUssYUFBYSxPQUFPLE1BQU0sV0FBVyxLQUFLLFlBQVk7Q0FDbkksTUFBTSxpQkFBaUIsT0FBTyxZQUFZLEtBQUssTUFBTSxRQUFPLFNBQVEsQ0FBQyxTQUFTLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVEsU0FBUTtFQUMvRyxNQUFNLFdBQVcsV0FBVyxLQUFLLE9BQU8sS0FBSztFQUM3QyxNQUFNLFNBQVMsb0JBQW9CLE1BQU0sTUFBTSxRQUFRLE1BQU0sU0FBUyxVQUFVLFFBQVE7RUFDeEYsTUFBTSxVQUFVLENBQUMsT0FBTyxVQUFVLE9BQU8sTUFBTSxPQUFPLEVBQUUsQ0FBQyxVQUFVLFdBQVcsS0FBSyxXQUFXLDZDQUE2QztFQUMzSSxPQUFPLFVBQVUsQ0FBQyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDO0NBQzNDLENBQUMsQ0FBQztDQUNGLE1BQU0sWUFBWSxXQUF1QyxvQkFBb0IsTUFBTTtFQUFFLFVBQVUsT0FBTztFQUFJO0VBQVMsV0FBVyxPQUFPO0VBQVcsT0FBTyxLQUFLLE1BQU0sUUFBTyxTQUFRLENBQUMsU0FBUyxTQUFTLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFJLFVBQVM7R0FBRSxRQUFRLEtBQUs7R0FBSSxVQUFVLFdBQVcsS0FBSyxPQUFPLEtBQUs7RUFBUyxFQUFFO0NBQUUsQ0FBQztDQUNsUyxlQUFlLFlBQVksUUFBcUI7RUFDOUMsU0FBUyxFQUFFO0VBQUcsVUFBVSxFQUFFO0VBQUcsWUFBWSxLQUFLO0VBQzlDLElBQUksT0FBTyxLQUFLLGNBQWMsQ0FBQyxDQUFDLFFBQVE7R0FBRSxTQUFTLG1DQUFtQztHQUFHO0VBQU87RUFDaEcsSUFBSSxDQUFDLEtBQUssTUFBTSxNQUFLLFNBQVEsQ0FBQyxTQUFTLFNBQVMsS0FBSyxFQUFFLENBQUMsR0FBRztHQUFFLFNBQVMsNENBQTRDO0dBQUc7RUFBTztFQUM1SCxJQUFJO0dBQUUsVUFBVSxNQUFNLGNBQWMsWUFBWSxTQUFTLE1BQU0sQ0FBQyxDQUFDO0VBQUUsU0FDNUQsT0FBTztHQUFFLFVBQVUsSUFBSTtHQUFHLFNBQVMsZ0JBQWdCLEtBQUssQ0FBQztFQUFFO0NBQ3BFO0NBQ0EsZUFBZSxZQUFZLFVBQTJCO0VBQ3BELElBQUksU0FBUyxTQUFTO0VBQ3RCLFNBQVMsVUFBVTtFQUNuQixZQUFZLFFBQVE7RUFDcEIsSUFBSTtHQUNGLE1BQU0sUUFBUSxNQUFNLFlBQVksWUFBWSxRQUFRO0dBQ3BELElBQUksa0JBQWtCLGNBQWMsR0FBRztHQUN2QyxZQUFZO0lBQUUsR0FBRztJQUFVLFNBQVMsTUFBTTtHQUFHLENBQUM7R0FDOUMsTUFBTSxPQUFPLFNBQVM7SUFBRSxJQUFJO0lBQXVCLFFBQVEsRUFBRSxTQUFTLE1BQU0sR0FBRztHQUFFLENBQUM7RUFDcEYsU0FBUyxPQUFPO0dBQ2QsSUFBSSxrQkFBa0IsY0FBYyxHQUFHO0dBQ3ZDLElBQUksaUJBQWlCLG1CQUFtQixNQUFNLFFBQVEsU0FBUyxTQUFTLGFBQWEsR0FBRyxZQUFZLElBQUk7R0FDeEcsVUFBVSxJQUFJO0dBQUcsWUFBWSxLQUFLO0dBQ2xDLFNBQVMsR0FBRyxnQkFBZ0IsS0FBSyxJQUFJLGlCQUFpQixtQkFBbUIsTUFBTSxRQUFRLFVBQVUsS0FBSyxxR0FBcUc7RUFDN00sVUFBVTtHQUFFLFNBQVMsVUFBVTtFQUFNO0NBQ3ZDO0NBQ0EsZUFBZSx5QkFBeUI7RUFDdEMsSUFBSSxXQUFXLFdBQVcsWUFBWSxhQUFhLGNBQWMsV0FBVztFQUM1RSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxXQUFXO0VBQ3hDLFdBQVcsVUFBVTtFQUNyQixTQUFTLEVBQUU7RUFDWCxJQUFJO0dBQ0YsTUFBTSxPQUFPLE1BQU0sY0FBYyxZQUFZLFNBQVMsS0FBSyxVQUFVLENBQUMsQ0FBQztHQUN2RSxJQUFJLEtBQUssZ0JBQWdCLE9BQU8sZUFBZSxLQUFLLE1BQU0sT0FBTyxTQUFTLEtBQUssS0FBSyxJQUFJLEdBQUc7SUFDekYsVUFBVSxtQ0FBbUMsT0FBTyxNQUFNLHlCQUF5QixLQUFLLE1BQU0sUUFBUSxpQkFBaUIsUUFBUSxJQUFJLEVBQUUsOEJBQThCO0lBQ25LLFVBQVUsSUFBSTtJQUFHLFlBQVksS0FBSztJQUFHO0dBQ3ZDO0dBQ0EsTUFBTSxXQUFXLFdBQVc7SUFBRSxLQUFLLE9BQU8sV0FBVztJQUFHLE9BQU87S0FBRSxTQUFTLEtBQUs7S0FBSSxjQUFjLFdBQVcsS0FBTTtJQUFjO0dBQUU7R0FDbEksTUFBTSxZQUFZLFFBQVE7RUFDNUIsU0FBUyxPQUFPO0dBQUUsVUFBVSxJQUFJO0dBQUcsWUFBWSxLQUFLO0dBQUcsU0FBUyxnQkFBZ0IsS0FBSyxDQUFDO0VBQUUsVUFBVTtHQUFFLFdBQVcsVUFBVTtFQUFNO0NBQ2pJO0NBQ0EsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQWlDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDckMsWUFBWSxTQUFTLEtBQUssd0JBQUMsS0FBRDtNQUFHLE1BQUs7TUFBUyxXQUFVO2dCQUEzQjtPQUE0QztPQUFzQixZQUFZLEtBQUssR0FBRztPQUFFO01BQWtGOzs7Ozs7S0FDcE0sV0FBVyx3QkFBQyxpQkFBRDtNQUEwQjtNQUFTLGFBQWEsWUFBWSxJQUFJO01BQUcsZUFBZSxLQUFLLFlBQVksT0FBTztNQUFHLFNBQVMsWUFBWTtLQUFZOzs7OztLQUMxSix3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkI7T0FBOEMsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW9CO09BQW1COzs7OztPQUFDLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQTBCLE9BQU87U0FBTTtTQUFJLE9BQU87U0FBUztTQUFJLE9BQU87UUFBVzs7Ozs7O09BQ25MLHdCQUFDLFNBQUQ7UUFBTyxTQUFRO2tCQUFtQjtPQUF3Qjs7Ozs7T0FBQyx3QkFBQyxVQUFEO1FBQVEsSUFBRztRQUFtQixXQUFVO1FBQWtCLE9BQU87UUFBUyxXQUFVLFVBQVM7U0FBRSxXQUFXLE1BQU0sT0FBTyxLQUEwQjtTQUFHLGFBQWEsRUFBRSxTQUFTLE1BQU0sT0FBTyxNQUEyQixDQUFDO1NBQUcsVUFBVSxJQUFJO1NBQUcsWUFBWSxLQUFLO1FBQUU7a0JBQTVQO1NBQStQLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFXO1NBQWdCOzs7OztTQUFDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFVO1NBQWU7Ozs7O1NBQUMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVM7U0FBYzs7Ozs7UUFBUzs7Ozs7O09BQzFiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQXNDLHdCQUFDLFFBQUQ7U0FBUSxVQUFVLFdBQVc7U0FBVyxlQUFlO1VBQUUsVUFBVSxJQUFJO1VBQUcsV0FBVyxPQUFPO1dBQUUsVUFBVSxPQUFPO1dBQUksUUFBUTtVQUFVLENBQUM7U0FBRTttQkFBRztRQUF5Qjs7OztrQkFBQyx3QkFBQyxRQUFEO1NBQVEsU0FBUTtTQUFVLFVBQVUsV0FBVztTQUFXLGVBQWU7VUFBRSxVQUFVLElBQUk7VUFBRyxZQUFZLEtBQUs7VUFBRyxXQUFXLE9BQU87V0FBRSxVQUFVLE9BQU87V0FBSSxRQUFRO1VBQWEsQ0FBQztTQUFFO21CQUFHO1FBQTRCOzs7O2dCQUFNOzs7Ozs7T0FDamEsd0JBQUMsS0FBRDtRQUFHLE1BQUs7a0JBQVUsV0FBVyxZQUFZLGdCQUFnQixZQUFZLG9DQUFvQyxXQUFXLE1BQU0sV0FBVyxZQUFZLHVDQUF1QztPQUE0Qjs7Ozs7T0FDbk4sV0FBVyxXQUFXLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO2tCQUFTLGdCQUFnQixXQUFXLEtBQUs7T0FBSzs7Ozs7TUFDdEU7Ozs7OztLQUNULHdCQUFDLFFBQUQ7TUFBTTtNQUFXLFdBQVU7TUFBMkIsY0FBVztNQUFxQixnQkFBZ0I7T0FBRSxhQUFhO09BQUcsVUFBVSxJQUFJO09BQUcsWUFBWSxLQUFLO01BQUU7TUFBRyxVQUFVLEtBQUssYUFBYSxXQUFXO2dCQUF0TTtPQUF5TSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBb0I7T0FBMEI7Ozs7O09BQUMsd0JBQUMsaUJBQUQ7UUFBdUI7UUFBTSxRQUFPO09BQVk7Ozs7O09BQ3BULHdCQUFDLFNBQUQ7UUFBTyxTQUFRO2tCQUFpQjtPQUE0Qzs7Ozs7T0FBQyx3QkFBQyxZQUFEO1FBQVUsSUFBRztRQUFpQixHQUFJLEtBQUssU0FBUyxpQkFBaUI7UUFBRyxXQUFVO1FBQTJCLG9CQUFpQjtPQUF3Qjs7Ozs7T0FBQyx3QkFBQyxLQUFEO1FBQUcsSUFBRztRQUF1QixXQUFVO2tCQUFlLEtBQUssVUFBVSxPQUFPLFdBQVcsT0FBTztPQUFXOzs7OztPQUN6VSx3QkFBQyxRQUFEO1FBQVEsTUFBSztRQUFTLEtBQUs7UUFBYyxVQUFVLENBQUMsYUFBYSxjQUFjLGFBQWEsWUFBWSxhQUFhLENBQUMsQ0FBQztrQkFBVSxjQUFjLFlBQVkseUJBQXlCO09BQXFDOzs7OztNQUNyTjs7Ozs7O0tBQ0wsU0FBUyx3QkFBQyxLQUFEO01BQUcsTUFBSztnQkFBUztLQUFTOzs7OztLQUFHLFVBQVUsd0JBQUMsS0FBRDtNQUFHLE1BQUs7Z0JBQVU7S0FBVTs7Ozs7SUFDMUU7Ozs7OztHQUFDLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQWpCO0tBQTRDLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvQjtLQUFhOzs7OztLQUFDLHdCQUFDLEtBQUQsWUFBRywyRkFBMkY7Ozs7O0tBQzdMLEtBQUssTUFBTSxLQUFJLFNBQVEsd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CO09BQTJELHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQjtTQUE4Qix3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFXLFNBQVMsQ0FBQyxTQUFTLFNBQVMsS0FBSyxFQUFFO1VBQUcsV0FBVSxVQUFTO1dBQUUsTUFBTSxPQUFPLE1BQU0sT0FBTyxVQUFVLFNBQVMsUUFBTyxPQUFNLE9BQU8sS0FBSyxFQUFFLElBQUksQ0FBQyxHQUFHLFVBQVUsS0FBSyxFQUFFO1dBQUcsWUFBWSxJQUFJO1dBQUcsYUFBYSxFQUFFLFVBQVUsS0FBSyxDQUFDO1dBQUcsVUFBVSxJQUFJO1VBQUU7U0FBSTs7Ozs7U0FBQztTQUFTLEtBQUssSUFBSTtRQUFZOzs7Ozs7T0FBQyx3QkFBQyxLQUFEO1FBQUksS0FBSyxRQUFRO1FBQUs7UUFBSSxLQUFLLElBQUksUUFBUTtRQUFLO1FBQUksS0FBSyxRQUFRLE1BQU07UUFBTztPQUFPOzs7OztPQUNuZSx3QkFBQyxTQUFEO1FBQU8sU0FBUyxPQUFPLEtBQUs7a0JBQTVCLENBQWtDLDRCQUF5QixLQUFLLElBQUksSUFBWTs7Ozs7O09BQUMsd0JBQUMsT0FBRDtRQUFPLElBQUksT0FBTyxLQUFLO1FBQU0sTUFBSztRQUFTLEtBQUk7UUFBSSxNQUFLO1FBQUksS0FBSyxLQUFLO1FBQVUsZ0JBQWMsQ0FBQyxDQUFDLGVBQWUsS0FBSztRQUFLLG9CQUFrQixPQUFPLEtBQUssR0FBRztRQUFTLE9BQU8sT0FBTyxTQUFTLFdBQVcsS0FBSyxPQUFPLEtBQUssUUFBUSxJQUFJLFdBQVcsS0FBSyxPQUFPLEtBQUssV0FBVztRQUFJLFdBQVUsVUFBUztTQUFFLE1BQU0sT0FBTztVQUFFLEdBQUc7V0FBYSxLQUFLLEtBQUssTUFBTSxPQUFPO1NBQWM7U0FBRyxjQUFjLElBQUk7U0FBRyxhQUFhLEVBQUUsWUFBWSxLQUFLLENBQUM7U0FBRyxVQUFVLElBQUk7UUFBRTtPQUFJOzs7OztPQUN2Z0Isd0JBQUMsS0FBRDtRQUFHLFdBQVU7UUFBYyxJQUFJLE9BQU8sS0FBSyxHQUFHO2tCQUFVLGVBQWUsS0FBSztPQUFPOzs7OztPQUNsRixDQUFDLEtBQUssYUFBYSx3QkFBQyxLQUFEO1FBQUcsTUFBSztrQkFBUTtPQUErRDs7Ozs7TUFDNUY7UUFKaUUsS0FBSzs7OztZQUl0RSxDQUFDO0tBQ1Ysd0JBQUMsZ0JBQUQsRUFBc0IsS0FBTzs7Ozs7S0FBRSxVQUFVLHdCQUFDLGFBQUQsRUFBYSxPQUFPLE9BQVM7Ozs7O0lBQ2pFOzs7Ozs7R0FDUCx3QkFBQyxRQUFEO0lBQVEsTUFBTSxDQUFDLENBQUM7SUFBUSxlQUFjLFNBQVE7S0FBRSxJQUFJLENBQUMsTUFBTTtNQUFFLFVBQVUsSUFBSTtNQUFHLFlBQVksS0FBSztLQUFFO0lBQUU7Y0FBRyx3QkFBQyxlQUFEO0tBQWUsV0FBVTtLQUE0QixjQUFjO0tBQWUsWUFBWTtlQUE5RjtNQUE0Ryx3QkFBQyxhQUFELFlBQWEsaUJBQTJCOzs7OztNQUFDLHdCQUFDLG1CQUFELFlBQW1CLDhEQUE4RTs7Ozs7TUFDelYsVUFBVTtPQUFFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQTBCLE9BQU8sT0FBTztTQUFNO1NBQUksT0FBTztTQUFRO1NBQUksT0FBTyxPQUFPO1FBQVc7Ozs7OztPQUFFLE9BQU8sTUFBTSxLQUFJLFNBQVEsd0JBQUMsS0FBRDtRQUFrQixLQUFLLElBQUk7UUFBSztRQUFJLEtBQUssUUFBUTtRQUFLO1FBQUksS0FBSztRQUFTO1FBQUksS0FBSyxRQUFRLE1BQU07UUFBTztRQUFRLEtBQUs7UUFBVTtPQUFPLEtBQTVILEtBQUs7Ozs7Y0FBdUgsQ0FBQztPQUFFLHdCQUFDLGFBQUQsRUFBYSxPQUFPLE9BQVM7Ozs7O09BQ3hTLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUE4Qix3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFXLEtBQUs7U0FBZSxTQUFTO1NBQVUsV0FBVSxVQUFTLFlBQVksTUFBTSxPQUFPLE9BQU87UUFBSTs7OztrQkFBQywyREFBZ0U7Ozs7OztPQUNwTix3QkFBQyxRQUFEO1FBQVEsVUFBVSxDQUFDLFlBQVksY0FBYyxhQUFhLFlBQVksYUFBYSxDQUFDO1FBQVcsZUFBZSxLQUFLLHVCQUF1QjtrQkFBSSxZQUFZLFlBQVkscUJBQXFCO09BQTJCOzs7OztPQUNyTixVQUFVLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO2tCQUFVO09BQVU7Ozs7O01BQ3ZDOzs7OztLQUNXOzs7Ozs7R0FBUzs7Ozs7RUFDbkI7Ozs7OztBQUNQOzs7Ozs7Ozs7Ozs7OztBQUNBLFNBQVMsd0JBQXdCOztDQUMvQixNQUFNLEVBQUUsU0FBUyxnQkFBZ0IsbUJBQW1CO0NBQUcsTUFBTSxXQUFXLGVBQWU7Q0FBRyxNQUFNLFNBQVMsVUFBVTtDQUFHLE1BQU0sUUFBUSxjQUFjO0NBQ2xKLE9BQU8sd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDSixXQUFXO0lBQUUsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBWTtJQUFzQjs7Ozs7SUFBQyx3QkFBQyxLQUFELFlBQUcsd0ZBQXdGOzs7OztJQUN4Six3QkFBQyxRQUFEO0tBQVEsVUFBVSxTQUFTO0tBQVcsZUFBZSxTQUFTLE9BQU8sU0FBUztNQUM1RSxZQUFXLFVBQVM7T0FBRSxJQUFJLFVBQVUsY0FBYyxHQUFHO1FBQUUsWUFBWTtTQUFFLEdBQUc7U0FBUyxTQUFTLE1BQU07UUFBRyxDQUFDO1FBQUcsS0FBSyxPQUFPLFNBQVM7U0FBRSxJQUFJO1NBQXVCLFFBQVEsRUFBRSxTQUFTLE1BQU0sR0FBRztRQUFFLENBQUM7T0FBRTtNQUFFO01BQzVMLFVBQVMsVUFBUztPQUFFLElBQUksVUFBVSxjQUFjLEtBQUssaUJBQWlCLG1CQUFtQixNQUFNLFFBQVEsU0FBUyxTQUFTLGFBQWEsR0FBRyxZQUFZLElBQUk7TUFBRTtLQUM3SixDQUFDO2VBQUksU0FBUyxZQUFZLDJCQUEyQjtJQUF1Qzs7Ozs7R0FDNUY7Ozs7O0dBQ0QsU0FBUyxXQUFXLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO2NBQVMsZ0JBQWdCLFNBQVMsS0FBSztHQUFLOzs7OztHQUN6RSx3QkFBQyxNQUFEO0lBQU0sSUFBRztJQUFzQixRQUFRLEVBQUUsU0FBUyxTQUFTLFFBQVE7SUFBRyxXQUFVO2NBQWU7R0FBc0I7Ozs7O0VBQzlHOzs7Ozs7QUFDWDs7Ozs7Ozs7O0FBQ0EsT0FBTyxTQUFTLGVBQWU7O0NBQzdCLE1BQU0sT0FBTyxRQUFRO0NBQUcsTUFBTSxVQUFVLFdBQVc7Q0FBRyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUNqRyxJQUFJLEtBQUssYUFBYSxRQUFRLFdBQVcsT0FBTyx3QkFBQyxjQUFELEVBQWMsT0FBTSxzQkFBdUI7Ozs7O0NBQzNGLElBQUksS0FBSyxXQUFXLFFBQVEsU0FBUyxPQUFPLHdCQUFDLFlBQUQ7RUFBWSxTQUFTLGdCQUFnQixLQUFLLFNBQVMsUUFBUSxLQUFLO0VBQUcsYUFBYTtHQUFFLEtBQUssS0FBSyxRQUFRO0dBQUcsS0FBSyxRQUFRLFFBQVE7RUFBRTtDQUFJOzs7OztDQUM5SyxNQUFNLFNBQVMsUUFBUSxLQUFLLE1BQU0sTUFBSyxXQUFVLE9BQU8sT0FBTyxRQUFRLEtBQUssUUFBUSxLQUFLLE1BQU07Q0FDL0YsT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUErQix3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFxQjtHQUFZOzs7OztHQUFDLHdCQUFDLE1BQUQ7SUFBTSxJQUFHO0lBQVksV0FBVTtjQUFlO0dBQXdCOzs7OztHQUN6SixDQUFDLEtBQUssS0FBSyxNQUFNLFNBQVMsZ0RBQUUsd0JBQUMsS0FBRDtJQUFHLE1BQUs7Y0FBUztHQUEyQjs7OzthQUFDLHdCQUFDLHVCQUFELENBQXdCOzs7O1dBQUc7Ozs7Y0FBSSxDQUFDLFNBQVMsd0JBQUMsS0FBRDtJQUFHLE1BQUs7Y0FBUixDQUFpQiwwQ0FBc0Msd0JBQUMsTUFBRDtLQUFNLElBQUc7S0FBYSxXQUFVO2VBQWU7SUFBeUI7Ozs7WUFBSTs7Ozs7Y0FBSSxnREFDeFAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUFvQyx3QkFBQyxTQUFEO0tBQU8sU0FBUTtlQUFrQjtJQUEwQjs7OztjQUFDLHdCQUFDLFVBQUQ7S0FBUSxJQUFHO0tBQWtCLFdBQVU7S0FBa0IsT0FBTyxPQUFPO0tBQUksV0FBVSxVQUFTLFlBQVksTUFBTSxPQUFPLEtBQUs7ZUFBSSxRQUFRLEtBQUssTUFBTSxLQUFJLFdBQVUsd0JBQUMsVUFBRDtNQUFRLE9BQU8sT0FBTztnQkFBdEI7T0FBMkMsT0FBTztPQUFNO09BQUksT0FBTztNQUFnQjtRQUFwRCxPQUFPOzs7O1lBQTZDLENBQUM7SUFBVTs7OztZQUFNOzs7OzthQUNyVyx3QkFBQyxjQUFEO0lBQXNCO0lBQVEsTUFBTSxLQUFLO0dBQThDLEdBQW5DLEdBQUcsT0FBTyxHQUFHLEdBQUcsT0FBTzs7OztVQUFZLENBQ3ZGOzs7OztFQUNLOzs7Ozs7QUFDWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJjaGVja291dC1wYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmssIHVzZVJvdXRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCdcbmltcG9ydCB0eXBlIHsgQ2FydCB9IGZyb20gJ0AvY29udHJhY3RzL2NhcnQnXG5pbXBvcnQgeyBjaGVja291dElucHV0U2NoZW1hLCB0eXBlIENoZWNrb3V0SW5wdXQsIHR5cGUgQ2hlY2tvdXRRdW90ZSB9IGZyb20gJ0AvY29udHJhY3RzL2NoZWNrb3V0J1xuaW1wb3J0IHsgd2FsbGV0SW5wdXRTY2hlbWEsIHR5cGUgV2FsbGV0LCB0eXBlIFdhbGxldElucHV0IH0gZnJvbSAnQC9jb250cmFjdHMvd2FsbGV0J1xuaW1wb3J0IHsgdXNlQ2FydCwgdXNlQ2FydE11dGF0aW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXJ0L3F1ZXJpZXMnXG5pbXBvcnQgeyBDb2xsZWN0b3JGaWVsZHMgfSBmcm9tICdAL2ZlYXR1cmVzL3dhbGxldHMvY29sbGVjdG9yLWZpZWxkcydcbmltcG9ydCB7IHVzZVdhbGxldENvbm5lY3Rpb24sIHVzZVdhbGxldHMgfSBmcm9tICdAL2ZlYXR1cmVzL3dhbGxldHMvcXVlcmllcydcbmltcG9ydCB7IExvYWRpbmdTdGF0ZSwgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9hc3luYy1zdGF0ZSdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nQ29udGVudCwgRGlhbG9nRGVzY3JpcHRpb24sIERpYWxvZ1RpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2RpYWxvZydcbmltcG9ydCB7IHVzZVNlc3Npb24gfSBmcm9tICdAL2ZlYXR1cmVzL2F1dGgvYXBpJ1xuaW1wb3J0IHsgcmVhZENoZWNrb3V0RHJhZnQsIHNhdmVDaGVja291dERyYWZ0LCB0eXBlIENoZWNrb3V0RHJhZnQgfSBmcm9tICcuL2RyYWZ0J1xuaW1wb3J0IHsgdXNlUmVhbHRpbWUgfSBmcm9tICdAL2ZlYXR1cmVzL3JlYWx0aW1lL3N0YXRlJ1xuaW1wb3J0IHsgdXNlUHVyY2hhc2VBdHRlbXB0IH0gZnJvbSAnQC9mZWF0dXJlcy9vcmRlcnMvYXR0ZW1wdCdcbmltcG9ydCB7IGlkZW50aXR5RXBvY2ggfSBmcm9tICdAL2xpYi9pZGVudGl0eSdcbmltcG9ydCB7IHVzZUNyZWF0ZU9yZGVyLCB1c2VPcmRlciB9IGZyb20gJ0AvZmVhdHVyZXMvb3JkZXJzL3F1ZXJpZXMnXG5pbXBvcnQgdHlwZSB7IFB1cmNoYXNlQXR0ZW1wdCB9IGZyb20gJ0AvY29udHJhY3RzL29yZGVyJ1xuaW1wb3J0IHsgYXBpRXJyb3JNZXNzYWdlLCBBcGlSZXF1ZXN0RXJyb3IgfSBmcm9tICdAL2xpYi9hcGknXG5pbXBvcnQgeyB1c2VDaGVja291dFF1b3RlIH0gZnJvbSAnLi9xdWVyaWVzJ1xuaW1wb3J0IHsgcXVvdGVEaWZmZXJlbmNlcyB9IGZyb20gJy4vcXVvdGUtZGlmZmVyZW5jZXMnXG5pbXBvcnQgeyBRdW90ZVZhbHVlcyB9IGZyb20gJy4vcXVvdGUtdmFsdWVzJ1xuZnVuY3Rpb24gQ2hlY2tvdXRDb3Vwb24oeyBjYXJ0IH06IHsgY2FydDogQ2FydCB9KSB7XG4gIGNvbnN0IG11dGF0aW9uID0gdXNlQ2FydE11dGF0aW9uKCk7IGNvbnN0IFtjb2RlLCBzZXRDb2RlXSA9IHVzZVN0YXRlKCcnKVxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj48Zm9ybSBvblN1Ym1pdD17ZXZlbnQgPT4geyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyBtdXRhdGlvbi5tdXRhdGUoeyB0eXBlOiAnY291cG9uJywgY29kZSB9KSB9fSBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj48bGFiZWwgaHRtbEZvcj1cImNoZWNrb3V0LWNvdXBvblwiPkN1cG9tPC9sYWJlbD48SW5wdXQgaWQ9XCJjaGVja291dC1jb3Vwb25cIiB2YWx1ZT17Y29kZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldENvZGUoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcmVxdWlyZWQgYXJpYS1kZXNjcmliZWRieT1cImNoZWNrb3V0LWNvdXBvbi1lcnJvclwiIC8+PEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e211dGF0aW9uLmlzUGVuZGluZ30+QXBsaWNhciBjdXBvbTwvQnV0dG9uPjwvZm9ybT5cbiAgICB7Y2FydC5jb3Vwb25Db2RlICYmIDxwPntjYXJ0LmNvdXBvbkNvZGV9IDxCdXR0b24gdmFyaWFudD1cImxpbmtcIiBkaXNhYmxlZD17bXV0YXRpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBtdXRhdGlvbi5tdXRhdGUoeyB0eXBlOiAncmVtb3ZlLWNvdXBvbicgfSl9PlJlbW92ZXIgY3Vwb208L0J1dHRvbj48L3A+fVxuICAgIDxwIGlkPVwiY2hlY2tvdXQtY291cG9uLWVycm9yXCIgcm9sZT17bXV0YXRpb24uaXNFcnJvciA/ICdhbGVydCcgOiB1bmRlZmluZWR9PnttdXRhdGlvbi5pc0Vycm9yID8gYXBpRXJyb3JNZXNzYWdlKG11dGF0aW9uLmVycm9yKSA6ICcnfTwvcD5cbiAgPC9kaXY+XG59XG5mdW5jdGlvbiBQcmV2aW91c0F0dGVtcHQoeyBhdHRlbXB0LCBjbGVhciwgcmVjb3ZlciwgcGVuZGluZyB9OiB7IGF0dGVtcHQ6IFB1cmNoYXNlQXR0ZW1wdDsgY2xlYXI6ICgpID0+IHZvaWQ7IHJlY292ZXI6ICgpID0+IHZvaWQ7IHBlbmRpbmc6IGJvb2xlYW4gfSkge1xuICBjb25zdCBwcmV2aW91cyA9IHVzZU9yZGVyKGF0dGVtcHQub3JkZXJJZClcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbW1lcmNlLXBhbmVsIHNwYWNlLXktNFwiPjxoMiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5UZW50YXRpdmEgYW50ZXJpb3I8L2gyPjxwPkNvbnN1bHRlIGEgbWVzbWEgdGVudGF0aXZhIHBhcmEgcmVjdXBlcmFyIHNldSBwZWRpZG8sIGluY2x1c2l2ZSBhcMOzcyB0aW1lb3V0IG91IHJlZnJlc2guPC9wPjxCdXR0b24gZGlzYWJsZWQ9e3BlbmRpbmd9IG9uQ2xpY2s9e3JlY292ZXJ9PlJlY3VwZXJhciB0ZW50YXRpdmEgYW50ZXJpb3I8L0J1dHRvbj48TGluayB0bz1cIi9wZWRpZG8vY29uZmlybWFjYW9cIiBzZWFyY2g9e3sgb3JkZXJJZDogYXR0ZW1wdC5vcmRlcklkIH19IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiPlZlciBtZXVzIHBlZGlkb3M8L0xpbms+e3ByZXZpb3VzLmRhdGEgJiYgcHJldmlvdXMuZGF0YS5zdGF0dXMgIT09ICdwZW5kaW5nJyAmJiA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17Y2xlYXJ9PkNvbWXDp2FyIG91dHJhIGNvbXByYTwvQnV0dG9uPn08L3NlY3Rpb24+XG59XG5mdW5jdGlvbiBDaGVja291dEZvcm0oeyBjYXJ0LCB3YWxsZXQgfTogeyBjYXJ0OiBDYXJ0OyB3YWxsZXQ6IFdhbGxldCB9KSB7XG4gIGNvbnN0IGNvbm5lY3Rpb24gPSB1c2VXYWxsZXRDb25uZWN0aW9uKCk7IGNvbnN0IHF1b3RlTXV0YXRpb24gPSB1c2VDaGVja291dFF1b3RlKCk7IGNvbnN0IGxpdmUgPSB1c2VSZWFsdGltZSgpXG4gIGNvbnN0IGNyZWF0ZU9yZGVyID0gdXNlQ3JlYXRlT3JkZXIoKTsgY29uc3QgeyBhdHRlbXB0LCBzYXZlQXR0ZW1wdCB9ID0gdXNlUHVyY2hhc2VBdHRlbXB0KCk7IGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKCk7IGNvbnN0IHVzZXJJZCA9IHNlc3Npb24uZGF0YT8udXNlci5pZCA/PyAnJzsgY29uc3QgZHJhZnQgPSByZWFkQ2hlY2tvdXREcmFmdCh1c2VySWQsIHdhbGxldClcbiAgY29uc3QgcmV2aWV3QnV0dG9uID0gdXNlUmVmPEhUTUxCdXR0b25FbGVtZW50PihudWxsKTsgY29uc3QgcmV2aWV3Q29uc2VudCA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKVxuICBjb25zdCBzdWJtaXRMb2NrID0gdXNlUmVmKGZhbHNlKTsgY29uc3Qgc2VuZExvY2sgPSB1c2VSZWYoZmFsc2UpOyBjb25zdCByZW5kZXJlZEVwb2NoID0gaWRlbnRpdHlFcG9jaCgpXG4gIGNvbnN0IFtxdWFudGl0aWVzLCBzZXRRdWFudGl0aWVzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIG51bWJlcj4+KGRyYWZ0Py5xdWFudGl0aWVzID8/IHt9KVxuICBjb25zdCBbZXhjbHVkZWQsIHNldEV4Y2x1ZGVkXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihkcmFmdD8uZXhjbHVkZWQgPz8gW10pXG4gIGNvbnN0IFtuZXR3b3JrLCBzZXROZXR3b3JrXSA9IHVzZVN0YXRlKGRyYWZ0Py5uZXR3b3JrID8/IHdhbGxldC5uZXR3b3JrKVxuICBjb25zdCBbcmV2aWV3U3RhdGUsIHNldFJldmlld1N0YXRlXSA9IHVzZVN0YXRlPHsgdmFsdWU6IENoZWNrb3V0UXVvdGU7IHJldmlzaW9uOiBzdHJpbmcgfSB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFthY2NlcHRlZCwgc2V0QWNjZXB0ZWRdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtub3RpY2UsIHNldE5vdGljZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgZm9ybSA9IHVzZUZvcm08V2FsbGV0SW5wdXQ+KHsgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHdhbGxldElucHV0U2NoZW1hKSwgZGVmYXVsdFZhbHVlczogeyBsYWJlbDogd2FsbGV0LmxhYmVsLCByb2xlOiB3YWxsZXQucm9sZSwgbmV0d29yazogd2FsbGV0Lm5ldHdvcmssIGFkZHJlc3M6IHdhbGxldC5hZGRyZXNzLCBwcm92aWRlcjogd2FsbGV0LnByb3ZpZGVyLCBzZWNvbmRhcnlBZGRyZXNzOiB3YWxsZXQuc2Vjb25kYXJ5QWRkcmVzcywgY29sbGVjdG9yOiBkcmFmdD8uY29sbGVjdG9yID8/IHdhbGxldC5jb2xsZWN0b3IgfSB9KVxuICBjb25zdCBwZXJzaXN0RHJhZnQgPSAocGF0Y2g6IFBhcnRpYWw8Q2hlY2tvdXREcmFmdD4gPSB7fSkgPT4gc2F2ZUNoZWNrb3V0RHJhZnQodXNlcklkLCB3YWxsZXQuaWQsIHsgd2FsbGV0VmVyc2lvbjogd2FsbGV0LnZlcnNpb24sIGNvbGxlY3RvcjogZm9ybS5nZXRWYWx1ZXMoJ2NvbGxlY3RvcicpLCBuZXR3b3JrLCBxdWFudGl0aWVzLCBleGNsdWRlZCwgLi4ucGF0Y2ggfSlcbiAgY29uc3QgcmV2aXNpb24gPSBgJHtjYXJ0Lml0ZW1zLm1hcChpdGVtID0+IGxpdmUubmZ0VmVyc2lvbnNbaXRlbS5uZnRJZF0gPz8gMCkuam9pbigpfToke2NhcnQudmVyc2lvbn06JHtjYXJ0Lml0ZW1zLm1hcChpdGVtID0+IGAke2l0ZW0uaWR9OiR7aXRlbS5xdWFudGl0eX06JHtpdGVtLm5mdC52ZXJzaW9ufWApLmpvaW4oJ3wnKX1gXG4gIGNvbnN0IHJldmlldyA9IHJldmlld1N0YXRlPy5yZXZpc2lvbiA9PT0gcmV2aXNpb24gPyByZXZpZXdTdGF0ZS52YWx1ZSA6IG51bGxcbiAgY29uc3Qgc2V0UmV2aWV3ID0gKHZhbHVlOiBDaGVja291dFF1b3RlIHwgbnVsbCkgPT4gc2V0UmV2aWV3U3RhdGUodmFsdWUgPyB7IHZhbHVlLCByZXZpc2lvbiB9IDogbnVsbClcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXJldmlldykgcmV0dXJuXG4gICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHsgc2V0UmV2aWV3U3RhdGUobnVsbCk7IHNldEFjY2VwdGVkKGZhbHNlKTsgc2V0Tm90aWNlKCdBIGNvdGHDp8OjbyBleHBpcm91LiBSZXZhbGlkZSBhbnRlcyBkZSBjb25maXJtYXIuJykgfSwgTWF0aC5tYXgoMCwgRGF0ZS5wYXJzZShyZXZpZXcuZXhwaXJlc0F0KSAtIERhdGUubm93KCkpKVxuICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpXG4gIH0sIFtyZXZpZXddKVxuICBjb25zdCBsaXZlQ2hhbmdlcyA9IGxpdmUubGFzdE5mdCA/IGNhcnQuaXRlbXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS5uZnRJZCA9PT0gbGl2ZS5sYXN0TmZ0IS5pZCkubWFwKGl0ZW0gPT4ge1xuICAgIGNvbnN0IGVkaXRpb24gPSBsaXZlLmxhc3ROZnQhLmVkaXRpb25zLmZpbmQoZWRpdGlvbiA9PiBlZGl0aW9uLmlkID09PSBpdGVtLmVkaXRpb25JZClcbiAgICByZXR1cm4gZWRpdGlvbiA/IGAke2l0ZW0ubmZ0Lm5hbWV9IMK3ICR7ZWRpdGlvbi5uYW1lfTogcHJlw6dvICR7ZWRpdGlvbi5wcmljZS5hbW91bnR9IEVUSCwgZXN0b3F1ZSAke2VkaXRpb24uYXZhaWxhYmlsaXR5LnJlbWFpbmluZ30uYCA6IGAke2l0ZW0ubmZ0Lm5hbWV9OiBlZGnDp8OjbyBpbmRpc3BvbsOtdmVsLmBcbiAgfSkgOiBbXVxuICBjb25zdCBjb25uZWN0ZWQgPSBjb25uZWN0aW9uLmRhdGE/LnN0YXR1cyA9PT0gJ2Nvbm5lY3RlZCcgJiYgY29ubmVjdGlvbi5kYXRhLndhbGxldElkID09PSB3YWxsZXQuaWQgJiYgY29ubmVjdGlvbi5kYXRhLm5ldHdvcmsgPT09IG5ldHdvcmtcbiAgY29uc3QgcXVhbnRpdHlFcnJvcnMgPSBPYmplY3QuZnJvbUVudHJpZXMoY2FydC5pdGVtcy5maWx0ZXIoaXRlbSA9PiAhZXhjbHVkZWQuaW5jbHVkZXMoaXRlbS5pZCkpLmZsYXRNYXAoaXRlbSA9PiB7XG4gICAgY29uc3QgcXVhbnRpdHkgPSBxdWFudGl0aWVzW2l0ZW0uaWRdID8/IGl0ZW0ucXVhbnRpdHlcbiAgICBjb25zdCBwYXJzZWQgPSBjaGVja291dElucHV0U2NoZW1hLnNoYXBlLml0ZW1zLmVsZW1lbnQuc2hhcGUucXVhbnRpdHkuc2FmZVBhcnNlKHF1YW50aXR5KVxuICAgIGNvbnN0IG1lc3NhZ2UgPSAhcGFyc2VkLnN1Y2Nlc3MgPyBwYXJzZWQuZXJyb3IuaXNzdWVzWzBdLm1lc3NhZ2UgOiBxdWFudGl0eSA+IGl0ZW0ucXVhbnRpdHkgPyAnTsOjbyB1bHRyYXBhc3NlIGEgcXVhbnRpZGFkZSBkbyBjYXJyaW5oby4nIDogJydcbiAgICByZXR1cm4gbWVzc2FnZSA/IFtbaXRlbS5pZCwgbWVzc2FnZV1dIDogW11cbiAgfSkpXG4gIGNvbnN0IGlucHV0Rm9yID0gKHZhbHVlczogV2FsbGV0SW5wdXQpOiBDaGVja291dElucHV0ID0+IGNoZWNrb3V0SW5wdXRTY2hlbWEucGFyc2UoeyB3YWxsZXRJZDogd2FsbGV0LmlkLCBuZXR3b3JrLCBjb2xsZWN0b3I6IHZhbHVlcy5jb2xsZWN0b3IsIGl0ZW1zOiBjYXJ0Lml0ZW1zLmZpbHRlcihpdGVtID0+ICFleGNsdWRlZC5pbmNsdWRlcyhpdGVtLmlkKSkubWFwKGl0ZW0gPT4gKHsgaXRlbUlkOiBpdGVtLmlkLCBxdWFudGl0eTogcXVhbnRpdGllc1tpdGVtLmlkXSA/PyBpdGVtLnF1YW50aXR5IH0pKSB9KVxuICBhc3luYyBmdW5jdGlvbiByZXZpZXdJbnB1dCh2YWx1ZXM6IFdhbGxldElucHV0KSB7XG4gICAgc2V0RXJyb3IoJycpOyBzZXROb3RpY2UoJycpOyBzZXRBY2NlcHRlZChmYWxzZSlcbiAgICBpZiAoT2JqZWN0LmtleXMocXVhbnRpdHlFcnJvcnMpLmxlbmd0aCkgeyBzZXRFcnJvcignQ29ycmlqYSBhcyBxdWFudGlkYWRlcyBpbmRpY2FkYXMuJyk7IHJldHVybiB9XG4gICAgaWYgKCFjYXJ0Lml0ZW1zLnNvbWUoaXRlbSA9PiAhZXhjbHVkZWQuaW5jbHVkZXMoaXRlbS5pZCkpKSB7IHNldEVycm9yKCdTZWxlY2lvbmUgcGVsbyBtZW5vcyB1bSBpdGVtIHBhcmEgY29tcHJhci4nKTsgcmV0dXJuIH1cbiAgICB0cnkgeyBzZXRSZXZpZXcoYXdhaXQgcXVvdGVNdXRhdGlvbi5tdXRhdGVBc3luYyhpbnB1dEZvcih2YWx1ZXMpKSkgfVxuICAgIGNhdGNoIChlcnJvcikgeyBzZXRSZXZpZXcobnVsbCk7IHNldEVycm9yKGFwaUVycm9yTWVzc2FnZShlcnJvcikpIH1cbiAgfVxuICBhc3luYyBmdW5jdGlvbiBzZW5kQXR0ZW1wdChwdXJjaGFzZTogUHVyY2hhc2VBdHRlbXB0KSB7XG4gICAgaWYgKHNlbmRMb2NrLmN1cnJlbnQpIHJldHVyblxuICAgIHNlbmRMb2NrLmN1cnJlbnQgPSB0cnVlXG4gICAgc2F2ZUF0dGVtcHQocHVyY2hhc2UpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG9yZGVyID0gYXdhaXQgY3JlYXRlT3JkZXIubXV0YXRlQXN5bmMocHVyY2hhc2UpXG4gICAgICBpZiAocmVuZGVyZWRFcG9jaCAhPT0gaWRlbnRpdHlFcG9jaCgpKSByZXR1cm5cbiAgICAgIHNhdmVBdHRlbXB0KHsgLi4ucHVyY2hhc2UsIG9yZGVySWQ6IG9yZGVyLmlkIH0pXG4gICAgICBhd2FpdCByb3V0ZXIubmF2aWdhdGUoeyB0bzogJy9wZWRpZG8vY29uZmlybWFjYW8nLCBzZWFyY2g6IHsgb3JkZXJJZDogb3JkZXIuaWQgfSB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAocmVuZGVyZWRFcG9jaCAhPT0gaWRlbnRpdHlFcG9jaCgpKSByZXR1cm5cbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEFwaVJlcXVlc3RFcnJvciAmJiBlcnJvci5maWVsZHM/LmF0dGVtcHQ/LmluY2x1ZGVzKCdub3QtY3JlYXRlZCcpKSBzYXZlQXR0ZW1wdChudWxsKVxuICAgICAgc2V0UmV2aWV3KG51bGwpOyBzZXRBY2NlcHRlZChmYWxzZSlcbiAgICAgIHNldEVycm9yKGAke2FwaUVycm9yTWVzc2FnZShlcnJvcil9JHtlcnJvciBpbnN0YW5jZW9mIEFwaVJlcXVlc3RFcnJvciAmJiBlcnJvci5maWVsZHM/LmF0dGVtcHQgPyAnJyA6ICcgTyByZXN1bHRhZG8gZG8gZW52aW8gcG9kZSBzZXIgZGVzY29uaGVjaWRvLiBSZWN1cGVyZSBhIG1lc21hIHRlbnRhdGl2YTsgbsOjbyBpbmljaWUgb3V0cmEgY29tcHJhLid9YClcbiAgICB9IGZpbmFsbHkgeyBzZW5kTG9jay5jdXJyZW50ID0gZmFsc2UgfVxuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIHZhbGlkYXRlQ29uZmlybWVkUXVvdGUoKSB7XG4gICAgaWYgKHN1Ym1pdExvY2suY3VycmVudCB8fCBjcmVhdGVPcmRlci5pc1BlbmRpbmcgfHwgcXVvdGVNdXRhdGlvbi5pc1BlbmRpbmcpIHJldHVyblxuICAgIGlmICghcmV2aWV3IHx8ICFhY2NlcHRlZCB8fCAhY29ubmVjdGVkKSByZXR1cm5cbiAgICBzdWJtaXRMb2NrLmN1cnJlbnQgPSB0cnVlXG4gICAgc2V0RXJyb3IoJycpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG5leHQgPSBhd2FpdCBxdW90ZU11dGF0aW9uLm11dGF0ZUFzeW5jKGlucHV0Rm9yKGZvcm0uZ2V0VmFsdWVzKCkpKVxuICAgICAgaWYgKG5leHQuZmluZ2VycHJpbnQgIT09IHJldmlldy5maW5nZXJwcmludCB8fCBEYXRlLnBhcnNlKHJldmlldy5leHBpcmVzQXQpIDw9IERhdGUubm93KCkpIHtcbiAgICAgICAgc2V0Tm90aWNlKGBBIGNvdGHDp8OjbyBtdWRvdTogdG90YWwgYW50ZXJpb3IgJHtyZXZpZXcudG90YWx9IEVUSDsgdG90YWwgYXR1YWxpemFkbyAke25leHQudG90YWx9IEVUSC4gJHtxdW90ZURpZmZlcmVuY2VzKHJldmlldywgbmV4dCl9IFJldmlzZSBlIGNvbmZpcm1lIG5vdmFtZW50ZS5gKVxuICAgICAgICBzZXRSZXZpZXcobmV4dCk7IHNldEFjY2VwdGVkKGZhbHNlKTsgcmV0dXJuXG4gICAgICB9XG4gICAgICBjb25zdCBwdXJjaGFzZSA9IGF0dGVtcHQgPz8geyBrZXk6IGNyeXB0by5yYW5kb21VVUlEKCksIGlucHV0OiB7IHF1b3RlSWQ6IG5leHQuaWQsIGNvbm5lY3Rpb25JZDogY29ubmVjdGlvbi5kYXRhIS5jb25uZWN0aW9uSWQhIH0gfVxuICAgICAgYXdhaXQgc2VuZEF0dGVtcHQocHVyY2hhc2UpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHsgc2V0UmV2aWV3KG51bGwpOyBzZXRBY2NlcHRlZChmYWxzZSk7IHNldEVycm9yKGFwaUVycm9yTWVzc2FnZShlcnJvcikpIH0gZmluYWxseSB7IHN1Ym1pdExvY2suY3VycmVudCA9IGZhbHNlIH1cbiAgfVxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJjaGVja291dC1sYXlvdXRcIj48ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtaW4tdy0wXCI+XG4gICAge2xpdmVDaGFuZ2VzLmxlbmd0aCA+IDAgJiYgPHAgcm9sZT1cInN0YXR1c1wiIGNsYXNzTmFtZT1cImNvbW1lcmNlLXBhbmVsXCI+QXR1YWxpemHDp8OjbyBhbyB2aXZvOiB7bGl2ZUNoYW5nZXMuam9pbignICcpfSBBIGNvdGHDp8OjbyBhbnRlcmlvciBmb2kgaW52YWxpZGFkYS4gUmV2YWxpZGUgZSBjb25maXJtZSBvcyB2YWxvcmVzIGF0dWFsaXphZG9zLjwvcD59XG4gICAge2F0dGVtcHQgJiYgPFByZXZpb3VzQXR0ZW1wdCBhdHRlbXB0PXthdHRlbXB0fSBjbGVhcj17KCkgPT4gc2F2ZUF0dGVtcHQobnVsbCl9IHJlY292ZXI9eygpID0+IHZvaWQgc2VuZEF0dGVtcHQoYXR0ZW1wdCl9IHBlbmRpbmc9e2NyZWF0ZU9yZGVyLmlzUGVuZGluZ30gLz59XG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY29tbWVyY2UtcGFuZWwgc3BhY2UteS00XCI+PGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkXCI+Q2FydGVpcmEgZSByZWRlPC9oMj48cCBjbGFzc05hbWU9XCJicmVhay1hbGxcIj57d2FsbGV0LmxhYmVsfSDCtyB7d2FsbGV0LnByb3ZpZGVyfSDCtyB7d2FsbGV0LmFkZHJlc3N9PC9wPlxuICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjaGVja291dC1uZXR3b3JrXCI+UmVkZSBkZSBwYWdhbWVudG88L2xhYmVsPjxzZWxlY3QgaWQ9XCJjaGVja291dC1uZXR3b3JrXCIgY2xhc3NOYW1lPVwiY29tbWVyY2Utc2VsZWN0XCIgdmFsdWU9e25ldHdvcmt9IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldE5ldHdvcmsoZXZlbnQudGFyZ2V0LnZhbHVlIGFzIFdhbGxldFsnbmV0d29yayddKTsgcGVyc2lzdERyYWZ0KHsgbmV0d29yazogZXZlbnQudGFyZ2V0LnZhbHVlIGFzIFdhbGxldFsnbmV0d29yayddIH0pOyBzZXRSZXZpZXcobnVsbCk7IHNldEFjY2VwdGVkKGZhbHNlKSB9fT48b3B0aW9uIHZhbHVlPVwiZXRoZXJldW1cIj5FdGhlcmV1bTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJwb2x5Z29uXCI+UG9seWdvbjwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJzb2xhbmFcIj5Tb2xhbmE8L29wdGlvbj48L3NlbGVjdD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj48QnV0dG9uIGRpc2FibGVkPXtjb25uZWN0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4geyBzZXRSZXZpZXcobnVsbCk7IGNvbm5lY3Rpb24ubXV0YXRlKHsgd2FsbGV0SWQ6IHdhbGxldC5pZCwgYWN0aW9uOiAnY29ubmVjdCcgfSkgfX0+Q29uZWN0YXIgY2FydGVpcmE8L0J1dHRvbj48QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgZGlzYWJsZWQ9e2Nvbm5lY3Rpb24uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB7IHNldFJldmlldyhudWxsKTsgc2V0QWNjZXB0ZWQoZmFsc2UpOyBjb25uZWN0aW9uLm11dGF0ZSh7IHdhbGxldElkOiB3YWxsZXQuaWQsIGFjdGlvbjogJ2Rpc2Nvbm5lY3QnIH0pIH19PkRlc2NvbmVjdGFyIGNhcnRlaXJhPC9CdXR0b24+PC9kaXY+XG4gICAgICA8cCByb2xlPVwic3RhdHVzXCI+e2Nvbm5lY3Rpb24uaXNQZW5kaW5nID8gJ0NvbmVjdGFuZG/igKYnIDogY29ubmVjdGVkID8gJ0NhcnRlaXJhIGNvbmVjdGFkYSAoc2ltdWxhw6fDo28pLicgOiBjb25uZWN0aW9uLmRhdGE/LnN0YXR1cyA9PT0gJ3JlZnVzZWQnID8gJ0NvbmV4w6NvIHJlY3VzYWRhLiBUZW50ZSBub3ZhbWVudGUuJyA6ICdDYXJ0ZWlyYSBkZXNjb25lY3RhZGEuJ308L3A+XG4gICAgICB7Y29ubmVjdGlvbi5pc0Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiPnthcGlFcnJvck1lc3NhZ2UoY29ubmVjdGlvbi5lcnJvcil9PC9wPn1cbiAgICA8L3NlY3Rpb24+XG4gICAgPGZvcm0gbm9WYWxpZGF0ZSBjbGFzc05hbWU9XCJjb21tZXJjZS1wYW5lbCBzcGFjZS15LTZcIiBhcmlhLWxhYmVsPVwiRGFkb3MgZG8gcGFnYW1lbnRvXCIgb25DaGFuZ2U9eygpID0+IHsgcGVyc2lzdERyYWZ0KCk7IHNldFJldmlldyhudWxsKTsgc2V0QWNjZXB0ZWQoZmFsc2UpIH19IG9uU3VibWl0PXtmb3JtLmhhbmRsZVN1Ym1pdChyZXZpZXdJbnB1dCl9PjxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZFwiPlBlcmZpbCBkbyBjb2xlY2lvbmFkb3I8L2gyPjxDb2xsZWN0b3JGaWVsZHMgZm9ybT17Zm9ybX0gcHJlZml4PVwiY2hlY2tvdXRcIiAvPlxuICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjaGVja291dC1ub3Rlc1wiPk9ic2VydmHDp8OjbyBkbyBjb2xlY2lvbmFkb3IgKG9wY2lvbmFsKTwvbGFiZWw+PHRleHRhcmVhIGlkPVwiY2hlY2tvdXQtbm90ZXNcIiB7Li4uZm9ybS5yZWdpc3RlcignY29sbGVjdG9yLm5vdGVzJyl9IGNsYXNzTmFtZT1cImNvbW1lcmNlLXNlbGVjdCBtaW4taC0yNFwiIGFyaWEtZGVzY3JpYmVkYnk9XCJjaGVja291dC1ub3Rlcy1lcnJvclwiIC8+PHAgaWQ9XCJjaGVja291dC1ub3Rlcy1lcnJvclwiIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5jb2xsZWN0b3I/Lm5vdGVzPy5tZXNzYWdlfTwvcD5cbiAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHJlZj17cmV2aWV3QnV0dG9ufSBkaXNhYmxlZD17IWNvbm5lY3RlZCB8fCBxdW90ZU11dGF0aW9uLmlzUGVuZGluZyB8fCBjcmVhdGVPcmRlci5pc1BlbmRpbmcgfHwgISFhdHRlbXB0fT57cXVvdGVNdXRhdGlvbi5pc1BlbmRpbmcgPyAnUmV2YWxpZGFuZG8gY290YcOnw6Nv4oCmJyA6ICdSZXZhbGlkYXIgZSByZXZpc2FyIGNvbXByYSd9PC9CdXR0b24+XG4gICAgPC9mb3JtPlxuICAgIHtlcnJvciAmJiA8cCByb2xlPVwiYWxlcnRcIj57ZXJyb3J9PC9wPn17bm90aWNlICYmIDxwIHJvbGU9XCJzdGF0dXNcIj57bm90aWNlfTwvcD59XG4gIDwvZGl2Pjxhc2lkZSBjbGFzc05hbWU9XCJjb21tZXJjZS1wYW5lbCBzcGFjZS15LTZcIj48aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGRcIj5TZXVzIE5GVHM8L2gyPjxwPkVzY29saGEgYXMgZWRpw6fDtWVzIGUgcXVhbnRpZGFkZXMgZGVzdGEgY29tcHJhLiBJdGVucyBuw6NvIHNlbGVjaW9uYWRvcyBmaWNhbSBubyBjYXJyaW5oby48L3A+XG4gICAge2NhcnQuaXRlbXMubWFwKGl0ZW0gPT4gPGFydGljbGUgY2xhc3NOYW1lPVwiY2hlY2tvdXQtaXRlbSBzcGFjZS15LTJcIiBrZXk9e2l0ZW0uaWR9PjxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9eyFleGNsdWRlZC5pbmNsdWRlcyhpdGVtLmlkKX0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgY29uc3QgbmV4dCA9IGV2ZW50LnRhcmdldC5jaGVja2VkID8gZXhjbHVkZWQuZmlsdGVyKGlkID0+IGlkICE9PSBpdGVtLmlkKSA6IFsuLi5leGNsdWRlZCwgaXRlbS5pZF07IHNldEV4Y2x1ZGVkKG5leHQpOyBwZXJzaXN0RHJhZnQoeyBleGNsdWRlZDogbmV4dCB9KTsgc2V0UmV2aWV3KG51bGwpIH19IC8+Q29tcHJhciB7aXRlbS5uZnQubmFtZX08L2xhYmVsPjxwPntpdGVtLmVkaXRpb24ubmFtZX0gwrcge2l0ZW0ubmZ0Lm5ldHdvcmsubmFtZX0gwrcge2l0ZW0uZWRpdGlvbi5wcmljZS5hbW91bnR9IEVUSDwvcD5cbiAgICAgIDxsYWJlbCBodG1sRm9yPXtgYnV5LSR7aXRlbS5pZH1gfT5RdWFudGlkYWRlIGEgY29tcHJhciBkZSB7aXRlbS5uZnQubmFtZX08L2xhYmVsPjxJbnB1dCBpZD17YGJ1eS0ke2l0ZW0uaWR9YH0gdHlwZT1cIm51bWJlclwiIG1pbj1cIjFcIiBzdGVwPVwiMVwiIG1heD17aXRlbS5xdWFudGl0eX0gYXJpYS1pbnZhbGlkPXshIXF1YW50aXR5RXJyb3JzW2l0ZW0uaWRdfSBhcmlhLWRlc2NyaWJlZGJ5PXtgYnV5LSR7aXRlbS5pZH0tZXJyb3JgfSB2YWx1ZT17TnVtYmVyLmlzRmluaXRlKHF1YW50aXRpZXNbaXRlbS5pZF0gPz8gaXRlbS5xdWFudGl0eSkgPyBxdWFudGl0aWVzW2l0ZW0uaWRdID8/IGl0ZW0ucXVhbnRpdHkgOiAnJ30gb25DaGFuZ2U9e2V2ZW50ID0+IHsgY29uc3QgbmV4dCA9IHsgLi4ucXVhbnRpdGllcywgW2l0ZW0uaWRdOiBldmVudC50YXJnZXQudmFsdWVBc051bWJlciB9OyBzZXRRdWFudGl0aWVzKG5leHQpOyBwZXJzaXN0RHJhZnQoeyBxdWFudGl0aWVzOiBuZXh0IH0pOyBzZXRSZXZpZXcobnVsbCkgfX0gLz5cbiAgICAgIDxwIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCIgaWQ9e2BidXktJHtpdGVtLmlkfS1lcnJvcmB9PntxdWFudGl0eUVycm9yc1tpdGVtLmlkXX08L3A+XG4gICAgICB7IWl0ZW0uYXZhaWxhYmxlICYmIDxwIHJvbGU9XCJhbGVydFwiPkVkacOnw6NvIGluZGlzcG9uw612ZWwgb3UgZXN0b3F1ZSBlc2dvdGFkby4gQ29ycmlqYSBvIGNhcnJpbmhvLjwvcD59XG4gICAgPC9hcnRpY2xlPil9XG4gICAgPENoZWNrb3V0Q291cG9uIGNhcnQ9e2NhcnR9IC8+e3JldmlldyAmJiA8UXVvdGVWYWx1ZXMgcXVvdGU9e3Jldmlld30gLz59XG4gIDwvYXNpZGU+XG4gIDxEaWFsb2cgb3Blbj17ISFyZXZpZXd9IG9uT3BlbkNoYW5nZT17b3BlbiA9PiB7IGlmICghb3BlbikgeyBzZXRSZXZpZXcobnVsbCk7IHNldEFjY2VwdGVkKGZhbHNlKSB9IH19PjxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cImt1cmlvLXRoZW1lIHJldmlldy1kaWFsb2dcIiBpbml0aWFsRm9jdXM9e3Jldmlld0NvbnNlbnR9IGZpbmFsRm9jdXM9e3Jldmlld0J1dHRvbn0+PERpYWxvZ1RpdGxlPlJldmlzYXIgY29tcHJhPC9EaWFsb2dUaXRsZT48RGlhbG9nRGVzY3JpcHRpb24+Q29uZmlyYSBvcyB2YWxvcmVzIGUgYSBjYXJ0ZWlyYSBhbnRlcyBkZSBhdXRvcml6YXIgbyBlbnZpby48L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgIHtyZXZpZXcgJiYgPD48cCBjbGFzc05hbWU9XCJicmVhay1hbGxcIj57cmV2aWV3LndhbGxldC5sYWJlbH0gwrcge3Jldmlldy5uZXR3b3JrfSDCtyB7cmV2aWV3LndhbGxldC5hZGRyZXNzfTwvcD57cmV2aWV3Lml0ZW1zLm1hcChpdGVtID0+IDxwIGtleT17aXRlbS5pZH0+e2l0ZW0ubmZ0Lm5hbWV9IMK3IHtpdGVtLmVkaXRpb24ubmFtZX0gwrcge2l0ZW0ucXVhbnRpdHl9IMOXIHtpdGVtLmVkaXRpb24ucHJpY2UuYW1vdW50fSBFVEggPSB7aXRlbS5saW5lVG90YWx9IEVUSDwvcD4pfTxRdW90ZVZhbHVlcyBxdW90ZT17cmV2aWV3fSAvPlxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgcmVmPXtyZXZpZXdDb25zZW50fSBjaGVja2VkPXthY2NlcHRlZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEFjY2VwdGVkKGV2ZW50LnRhcmdldC5jaGVja2VkKX0gLz5Db25maXJtbyBvcyBpdGVucywgYSBjYXJ0ZWlyYSBlIG9zIHZhbG9yZXMgZGVzdGEgY290YcOnw6NvLjwvbGFiZWw+XG4gICAgICA8QnV0dG9uIGRpc2FibGVkPXshYWNjZXB0ZWQgfHwgcXVvdGVNdXRhdGlvbi5pc1BlbmRpbmcgfHwgY3JlYXRlT3JkZXIuaXNQZW5kaW5nIHx8ICFjb25uZWN0ZWR9IG9uQ2xpY2s9eygpID0+IHZvaWQgdmFsaWRhdGVDb25maXJtZWRRdW90ZSgpfT57Y3JlYXRlT3JkZXIuaXNQZW5kaW5nID8gJ0VudmlhbmRvIHBlZGlkb+KApicgOiAnRmluYWxpemFyIGNvbXByYSd9PC9CdXR0b24+XG4gICAgICB7bm90aWNlICYmIDxwIHJvbGU9XCJzdGF0dXNcIj57bm90aWNlfTwvcD59XG4gICAgPC8+fVxuICA8L0RpYWxvZ0NvbnRlbnQ+PC9EaWFsb2c+XG4gIDwvZGl2PlxufVxuZnVuY3Rpb24gRW1wdHlDaGVja291dFJlY292ZXJ5KCkge1xuICBjb25zdCB7IGF0dGVtcHQsIHNhdmVBdHRlbXB0IH0gPSB1c2VQdXJjaGFzZUF0dGVtcHQoKTsgY29uc3QgbXV0YXRpb24gPSB1c2VDcmVhdGVPcmRlcigpOyBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTsgY29uc3QgZXBvY2ggPSBpZGVudGl0eUVwb2NoKClcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbW1lcmNlLXBhbmVsIHNwYWNlLXktNFwiPlxuICAgIHthdHRlbXB0ICYmIDw+PGgyIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlRlbnRhdGl2YSBhbnRlcmlvcjwvaDI+PHA+UmVjdXBlcmUgYSB0ZW50YXRpdmEgYW50ZXJpb3IgcGFyYSBjb25zdWx0YXIgbyByZXN1bHRhZG8sIG1lc21vIGNvbSBvIGNhcnJpbmhvIHZhemlvLjwvcD5cbiAgICAgIDxCdXR0b24gZGlzYWJsZWQ9e211dGF0aW9uLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gbXV0YXRpb24ubXV0YXRlKGF0dGVtcHQsIHtcbiAgICAgICAgb25TdWNjZXNzOiBvcmRlciA9PiB7IGlmIChlcG9jaCA9PT0gaWRlbnRpdHlFcG9jaCgpKSB7IHNhdmVBdHRlbXB0KHsgLi4uYXR0ZW1wdCwgb3JkZXJJZDogb3JkZXIuaWQgfSk7IHZvaWQgcm91dGVyLm5hdmlnYXRlKHsgdG86ICcvcGVkaWRvL2NvbmZpcm1hY2FvJywgc2VhcmNoOiB7IG9yZGVySWQ6IG9yZGVyLmlkIH0gfSkgfSB9LFxuICAgICAgICBvbkVycm9yOiBlcnJvciA9PiB7IGlmIChlcG9jaCA9PT0gaWRlbnRpdHlFcG9jaCgpICYmIGVycm9yIGluc3RhbmNlb2YgQXBpUmVxdWVzdEVycm9yICYmIGVycm9yLmZpZWxkcz8uYXR0ZW1wdD8uaW5jbHVkZXMoJ25vdC1jcmVhdGVkJykpIHNhdmVBdHRlbXB0KG51bGwpIH0sXG4gICAgICB9KX0+e211dGF0aW9uLmlzUGVuZGluZyA/ICdDb25zdWx0YW5kbyB0ZW50YXRpdmHigKYnIDogJ1JlY3VwZXJhciB0ZW50YXRpdmEgYW50ZXJpb3InfTwvQnV0dG9uPlxuICAgIDwvPn1cbiAgICB7bXV0YXRpb24uaXNFcnJvciAmJiA8cCByb2xlPVwiYWxlcnRcIj57YXBpRXJyb3JNZXNzYWdlKG11dGF0aW9uLmVycm9yKX08L3A+fVxuICAgIDxMaW5rIHRvPVwiL3BlZGlkby9jb25maXJtYWNhb1wiIHNlYXJjaD17eyBvcmRlcklkOiBhdHRlbXB0Py5vcmRlcklkIH19IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiPlZlciBtZXVzIHBlZGlkb3M8L0xpbms+XG4gIDwvc2VjdGlvbj5cbn1cbmV4cG9ydCBmdW5jdGlvbiBDaGVja291dFBhZ2UoKSB7XG4gIGNvbnN0IGNhcnQgPSB1c2VDYXJ0KCk7IGNvbnN0IHdhbGxldHMgPSB1c2VXYWxsZXRzKCk7IGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGUoJycpXG4gIGlmIChjYXJ0LmlzUGVuZGluZyB8fCB3YWxsZXRzLmlzUGVuZGluZykgcmV0dXJuIDxMb2FkaW5nU3RhdGUgbGFiZWw9XCJDYXJyZWdhbmRvIGNoZWNrb3V0XCIgLz5cbiAgaWYgKGNhcnQuaXNFcnJvciB8fCB3YWxsZXRzLmlzRXJyb3IpIHJldHVybiA8RXJyb3JTdGF0ZSBtZXNzYWdlPXthcGlFcnJvck1lc3NhZ2UoY2FydC5lcnJvciA/PyB3YWxsZXRzLmVycm9yKX0gcmV0cnk9eygpID0+IHsgdm9pZCBjYXJ0LnJlZmV0Y2goKTsgdm9pZCB3YWxsZXRzLnJlZmV0Y2goKSB9fSAvPlxuICBjb25zdCB3YWxsZXQgPSB3YWxsZXRzLmRhdGEuaXRlbXMuZmluZCh3YWxsZXQgPT4gd2FsbGV0LmlkID09PSBzZWxlY3RlZCkgPz8gd2FsbGV0cy5kYXRhLml0ZW1zWzBdXG4gIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj48aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkXCI+Q2hlY2tvdXQ8L2gxPjxMaW5rIHRvPVwiL2NhcnJpbmhvXCIgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCI+Vm9sdGFyIGFvIGNhcnJpbmhvPC9MaW5rPlxuICAgIHshY2FydC5kYXRhLml0ZW1zLmxlbmd0aCA/IDw+PHAgcm9sZT1cInN0YXR1c1wiPlNldSBjYXJyaW5obyBlc3TDoSB2YXppby48L3A+PEVtcHR5Q2hlY2tvdXRSZWNvdmVyeSAvPjwvPiA6ICF3YWxsZXQgPyA8cCByb2xlPVwic3RhdHVzXCI+Q2FkYXN0cmUgdW1hIGNhcnRlaXJhIHBhcmEgY29udGludWFyLiA8TGluayB0bz1cIi9jYXJ0ZWlyYXNcIiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIj5HZXJlbmNpYXIgY2FydGVpcmFzPC9MaW5rPjwvcD4gOiA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1sZyBzcGFjZS15LTJcIj48bGFiZWwgaHRtbEZvcj1cImNoZWNrb3V0LXdhbGxldFwiPkNhcnRlaXJhIGNhZGFzdHJhZGE8L2xhYmVsPjxzZWxlY3QgaWQ9XCJjaGVja291dC13YWxsZXRcIiBjbGFzc05hbWU9XCJjb21tZXJjZS1zZWxlY3RcIiB2YWx1ZT17d2FsbGV0LmlkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0U2VsZWN0ZWQoZXZlbnQudGFyZ2V0LnZhbHVlKX0+e3dhbGxldHMuZGF0YS5pdGVtcy5tYXAod2FsbGV0ID0+IDxvcHRpb24gdmFsdWU9e3dhbGxldC5pZH0ga2V5PXt3YWxsZXQuaWR9Pnt3YWxsZXQubGFiZWx9IMK3IHt3YWxsZXQubmV0d29ya308L29wdGlvbj4pfTwvc2VsZWN0PjwvZGl2PlxuICAgICAgPENoZWNrb3V0Rm9ybSB3YWxsZXQ9e3dhbGxldH0gY2FydD17Y2FydC5kYXRhfSBrZXk9e2Ake3dhbGxldC5pZH06JHt3YWxsZXQudmVyc2lvbn1gfSAvPlxuICAgIDwvPn1cbiAgPC9zZWN0aW9uPlxufVxuIl19