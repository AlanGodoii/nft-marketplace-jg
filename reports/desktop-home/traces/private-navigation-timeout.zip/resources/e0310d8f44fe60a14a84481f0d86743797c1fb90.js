import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/main-layout.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { Outlet, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { RealtimeBoundary } from "/src/features/realtime/realtime-boundary.tsx";
import { SessionBoundary } from "/src/features/auth/session-boundary.tsx";
import { Header } from "/src/components/layout/header.tsx?t=1793943067888";
import { Footer } from "/src/components/layout/footer.tsx?t=1793943067885";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/layout/main-layout.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function MainLayout() {
	_s();
	const isHome = useRouterState({ select: (state) => state.location.pathname === "/" });
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `flex min-h-dvh flex-col kurio-theme ${isHome ? "home-desktop" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("a", {
				href: "#conteudo",
				className: "sr-only focus:not-sr-only focus:p-4",
				children: "Pular para o conteúdo"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				id: "conteudo",
				className: isHome ? "kurio-container flex-1 pt-10" : "kurio-container flex-1 py-12",
				children: [
					/* @__PURE__ */ _jsxDEV(SessionBoundary, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 14,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(RealtimeBoundary, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_s(MainLayout, "NTBeqhYWg6x6LLz0xFmM0w8qcw8=", false, function() {
	return [useRouterState];
});
_c = MainLayout;
var _c;
$RefreshReg$(_c, "MainLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/main-layout.tsx?t=1793943067888";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/layout/main-layout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/layout/main-layout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/layout/main-layout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLHNCQUFzQjtBQUN2QyxTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxjQUFjOzs7O0FBRXZCLE9BQU8sU0FBUyxhQUFhOztDQUMzQixNQUFNLFNBQVMsZUFBZSxFQUFFLFNBQVEsVUFBUyxNQUFNLFNBQVMsYUFBYSxJQUFJLENBQUM7Q0FDbEYsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyx1Q0FBdUMsU0FBUyxpQkFBaUI7WUFBakY7R0FDRSx3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFZLFdBQVU7Y0FBc0M7R0FBd0I7Ozs7O0dBQzVGLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7R0FDVCx3QkFBQyxRQUFEO0lBQU0sSUFBRztJQUFXLFdBQVcsU0FBUyxpQ0FBaUM7Y0FBekU7S0FDRSx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7S0FDbEIsd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7O0tBQ25CLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7SUFDTDs7Ozs7O0dBQ04sd0JBQUMsUUFBRCxDQUFTOzs7OztFQUNOOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtYWluLWxheW91dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgT3V0bGV0LCB1c2VSb3V0ZXJTdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBSZWFsdGltZUJvdW5kYXJ5IH0gZnJvbSAnQC9mZWF0dXJlcy9yZWFsdGltZS9yZWFsdGltZS1ib3VuZGFyeSdcbmltcG9ydCB7IFNlc3Npb25Cb3VuZGFyeSB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9zZXNzaW9uLWJvdW5kYXJ5J1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSAnLi9oZWFkZXInXG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tICcuL2Zvb3RlcidcblxuZXhwb3J0IGZ1bmN0aW9uIE1haW5MYXlvdXQoKSB7XG4gIGNvbnN0IGlzSG9tZSA9IHVzZVJvdXRlclN0YXRlKHsgc2VsZWN0OiBzdGF0ZSA9PiBzdGF0ZS5sb2NhdGlvbi5wYXRobmFtZSA9PT0gJy8nIH0pXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IG1pbi1oLWR2aCBmbGV4LWNvbCBrdXJpby10aGVtZSAke2lzSG9tZSA/ICdob21lLWRlc2t0b3AnIDogJyd9YH0+XG4gICAgICA8YSBocmVmPVwiI2NvbnRldWRvXCIgY2xhc3NOYW1lPVwic3Itb25seSBmb2N1czpub3Qtc3Itb25seSBmb2N1czpwLTRcIj5QdWxhciBwYXJhIG8gY29udGXDumRvPC9hPlxuICAgICAgPEhlYWRlciAvPlxuICAgICAgPG1haW4gaWQ9XCJjb250ZXVkb1wiIGNsYXNzTmFtZT17aXNIb21lID8gJ2t1cmlvLWNvbnRhaW5lciBmbGV4LTEgcHQtMTAnIDogJ2t1cmlvLWNvbnRhaW5lciBmbGV4LTEgcHktMTInfT5cbiAgICAgICAgPFNlc3Npb25Cb3VuZGFyeSAvPlxuICAgICAgICA8UmVhbHRpbWVCb3VuZGFyeSAvPlxuICAgICAgICA8T3V0bGV0IC8+XG4gICAgICA8L21haW4+XG4gICAgICA8Rm9vdGVyIC8+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==