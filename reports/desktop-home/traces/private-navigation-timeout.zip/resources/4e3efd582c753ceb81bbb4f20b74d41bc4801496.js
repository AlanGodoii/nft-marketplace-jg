import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/desktop-home-header.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link, useNavigate, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { Search, ShoppingCart, LogIn, UserRound } from "/node_modules/.vite/deps/lucide-react.js?v=22c23eb4";
import { Button, buttonVariants } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { AuthActions } from "/src/features/auth/auth-actions.tsx";
import { useSession } from "/src/features/auth/api.ts";
import { useCart } from "/src/features/cart/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function DesktopHomeHeader() {
	_s();
	const isHome = useRouterState({ select: (state) => state.location.pathname === "/" });
	// Mount only on Home: other screens retain their header and query lifecycles.
	return isHome ? /* @__PURE__ */ _jsxDEV(HomeHeader, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 19
	}, this) : null;
}
_s(DesktopHomeHeader, "NTBeqhYWg6x6LLz0xFmM0w8qcw8=", false, function() {
	return [useRouterState];
});
_c = DesktopHomeHeader;
function HomeHeader() {
	_s2();
	const [searchOpen, setSearchOpen] = useState(false);
	const [term, setTerm] = useState("");
	const searchInput = useRef(null);
	const searchToggle = useRef(null);
	useEffect(() => {
		if (searchOpen) searchInput.current?.focus();
	}, [searchOpen]);
	const navigate = useNavigate();
	const session = useSession();
	const cart = useCart();
	const quantity = cart.data?.items.reduce((sum, item) => sum + item.quantity, 0);
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "desktop-home-header desktop-home-only",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "kurio-container desktop-header-inner",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					"aria-label": "Kurio — início",
					className: "desktop-wordmark",
					children: "KURIO"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": "Navegação principal",
					className: "desktop-primary-nav",
					children: [
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/",
							"aria-current": "page",
							className: "is-active",
							children: "Início"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#catalogo",
							children: "Mercado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#criadores",
							children: "Criadores"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 40
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#diario",
							children: "Aprenda"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 74
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "desktop-header-actions",
					children: [
						/* @__PURE__ */ _jsxDEV(Button, {
							ref: searchToggle,
							variant: "ghost",
							"aria-label": "Abrir busca do mercado",
							"aria-expanded": searchOpen,
							"aria-controls": "header-market-search",
							onClick: () => setSearchOpen((value) => !value),
							children: /* @__PURE__ */ _jsxDEV(Search, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 199
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/carrinho",
							"aria-label": quantity === undefined ? "Carrinho" : `Carrinho, ${quantity} itens`,
							className: "desktop-cart",
							children: [/* @__PURE__ */ _jsxDEV(ShoppingCart, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 34,
								columnNumber: 136
							}, this), quantity !== undefined && /* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: quantity
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 34,
								columnNumber: 198
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 9
						}, this),
						session.data ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("details", {
							className: "desktop-account",
							children: [/* @__PURE__ */ _jsxDEV("summary", { children: [/* @__PURE__ */ _jsxDEV(UserRound, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 35,
								columnNumber: 73
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								role: "status",
								"aria-label": "Usuário conectado",
								children: session.data.user.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 35,
								columnNumber: 105
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 35,
								columnNumber: 64
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/perfil",
									children: "Perfil"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 36,
									columnNumber: 16
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/carteiras",
									children: "Carteiras"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 36,
									columnNumber: 48
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/favoritos",
									children: "Favoritos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 36,
									columnNumber: 86
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/pedido/confirmacao",
									children: "Pedidos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 36,
									columnNumber: 124
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 11
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 27
						}, this), /* @__PURE__ */ _jsxDEV(AuthActions, { showName: false }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 25
						}, this) : /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							className: buttonVariants({ className: "desktop-login" }),
							children: [/* @__PURE__ */ _jsxDEV(LogIn, { "aria-hidden": "true" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 134
							}, this), "Entrar"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 57
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 7
				}, this),
				searchOpen && /* @__PURE__ */ _jsxDEV("form", {
					id: "header-market-search",
					className: "desktop-header-search",
					onSubmit: (event) => {
						event.preventDefault();
						void navigate({
							to: "/",
							search: (previous) => ({
								...previous,
								search: term,
								page: 1
							}),
							hash: "catalogo"
						});
						setSearchOpen(false);
					},
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: "header-search",
							children: "Buscar no mercado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV(Input, {
							ref: searchInput,
							id: "header-search",
							type: "search",
							value: term,
							maxLength: 120,
							onChange: (event) => setTerm(event.target.value),
							onKeyDown: (event) => {
								if (event.key === "Escape") {
									setSearchOpen(false);
									searchToggle.current?.focus();
								}
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 65
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							type: "submit",
							children: "Buscar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 311
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 22
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 5
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 10
	}, this);
}
_s2(HomeHeader, "bqUVO1+/Sk52nEW38Wl6TtTS/PY=", false, function() {
	return [
		useNavigate,
		useSession,
		useCart
	];
});
_c2 = HomeHeader;
var _c, _c2;
$RefreshReg$(_c, "DesktopHomeHeader");
$RefreshReg$(_c2, "HomeHeader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/desktop-home-header.tsx?t=1793943067888";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/components/layout/desktop-home-header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsTUFBTSxhQUFhLHNCQUFzQjtBQUNsRCxTQUFTLFFBQVEsY0FBYyxPQUFPLGlCQUFpQjtBQUN2RCxTQUFTLFFBQVEsc0JBQXNCO0FBQ3ZDLFNBQVMsYUFBYTtBQUN0QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGVBQWU7Ozs7QUFFeEIsT0FBTyxTQUFTLG9CQUFvQjs7Q0FDbEMsTUFBTSxTQUFTLGVBQWUsRUFBRSxTQUFRLFVBQVMsTUFBTSxTQUFTLGFBQWEsSUFBSSxDQUFDOztDQUVsRixPQUFPLFNBQVMsd0JBQUMsWUFBRCxDQUFhOzs7O1lBQUk7QUFDbkM7Ozs7O0FBQ0EsU0FBUyxhQUFhOztDQUNwQixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBQ25DLE1BQU0sY0FBYyxPQUF5QixJQUFJO0NBQ2pELE1BQU0sZUFBZSxPQUEwQixJQUFJO0NBQ25ELGdCQUFnQjtFQUFFLElBQUksWUFBWSxZQUFZLFNBQVMsTUFBTTtDQUFFLEdBQUcsQ0FBQyxVQUFVLENBQUM7Q0FDOUUsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsTUFBTSxPQUFPLFFBQVE7Q0FDckIsTUFBTSxXQUFXLEtBQUssTUFBTSxNQUFNLFFBQVEsS0FBSyxTQUFTLE1BQU0sS0FBSyxVQUFVLENBQUM7Q0FDOUUsT0FBTyx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUN2Qix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsTUFBRDtLQUFNLElBQUc7S0FBSSxjQUFXO0tBQWlCLFdBQVU7ZUFBbUI7SUFBVzs7Ozs7SUFDakYsd0JBQUMsT0FBRDtLQUFLLGNBQVc7S0FBc0IsV0FBVTtlQUFoRDtNQUNFLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQUksZ0JBQWE7T0FBTyxXQUFVO2lCQUFZO01BQVk7Ozs7O01BQ25FLHdCQUFDLEtBQUQ7T0FBRyxNQUFLO2lCQUFZO01BQVU7Ozs7O01BQUMsd0JBQUMsS0FBRDtPQUFHLE1BQUs7aUJBQWE7TUFBWTs7Ozs7TUFBQyx3QkFBQyxLQUFEO09BQUcsTUFBSztpQkFBVTtNQUFVOzs7OztLQUMxRjs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQ7T0FBUSxLQUFLO09BQWMsU0FBUTtPQUFRLGNBQVc7T0FBeUIsaUJBQWU7T0FBWSxpQkFBYztPQUF1QixlQUFlLGVBQWMsVUFBUyxDQUFDLEtBQUs7aUJBQUcsd0JBQUMsUUFBRCxFQUFRLGVBQVksT0FBUTs7Ozs7TUFBUzs7Ozs7TUFDbk8sd0JBQUMsTUFBRDtPQUFNLElBQUc7T0FBWSxjQUFZLGFBQWEsWUFBWSxhQUFhLGFBQWEsU0FBUztPQUFTLFdBQVU7aUJBQWhILENBQStILHdCQUFDLGNBQUQsRUFBYyxlQUFZLE9BQVE7Ozs7aUJBQUUsYUFBYSxhQUFhLHdCQUFDLFFBQUQ7UUFBTSxlQUFZO2tCQUFRO09BQWU7Ozs7ZUFBUTs7Ozs7O01BQzdPLFFBQVEsT0FBTyxnREFBRSx3QkFBQyxXQUFEO09BQVMsV0FBVTtpQkFBbkIsQ0FBcUMsd0JBQUMsV0FBRCxhQUFTLHdCQUFDLFdBQUQsRUFBVyxlQUFZLE9BQVE7Ozs7aUJBQUMsd0JBQUMsUUFBRDtRQUFNLE1BQUs7UUFBUyxjQUFXO2tCQUFxQixRQUFRLEtBQUssS0FBSztPQUFXOzs7O2VBQVU7Ozs7aUJBQ3pMLHdCQUFDLE9BQUQ7UUFBSyx3QkFBQyxNQUFEO1NBQU0sSUFBRzttQkFBVTtRQUFZOzs7OztRQUFDLHdCQUFDLE1BQUQ7U0FBTSxJQUFHO21CQUFhO1FBQWU7Ozs7O1FBQUMsd0JBQUMsTUFBRDtTQUFNLElBQUc7bUJBQWE7UUFBZTs7Ozs7UUFBQyx3QkFBQyxNQUFEO1NBQU0sSUFBRzttQkFBc0I7UUFBYTs7Ozs7T0FBTTs7OztlQUM1Sjs7Ozs7Z0JBQUMsd0JBQUMsYUFBRCxFQUFhLFVBQVUsTUFBUTs7OztjQUFHOzs7O2lCQUFJLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQVMsV0FBVyxlQUFlLEVBQUUsV0FBVyxnQkFBZ0IsQ0FBQztpQkFBMUUsQ0FBNkUsd0JBQUMsT0FBRCxFQUFPLGVBQVksT0FBUTs7OztpQkFBQyxRQUFZOzs7Ozs7S0FDbEs7Ozs7OztJQUNKLGNBQWMsd0JBQUMsUUFBRDtLQUFNLElBQUc7S0FBdUIsV0FBVTtLQUF3QixXQUFVLFVBQVM7TUFDbEcsTUFBTSxlQUFlO01BQUcsS0FBSyxTQUFTO09BQUUsSUFBSTtPQUFLLFNBQVEsY0FBYTtRQUFFLEdBQUc7UUFBVSxRQUFRO1FBQU0sTUFBTTtPQUFFO09BQUksTUFBTTtNQUFXLENBQUM7TUFBRyxjQUFjLEtBQUs7S0FDeko7ZUFGZTtNQUdiLHdCQUFDLFNBQUQ7T0FBTyxTQUFRO2lCQUFnQjtNQUF3Qjs7Ozs7TUFBQyx3QkFBQyxPQUFEO09BQU8sS0FBSztPQUFhLElBQUc7T0FBZ0IsTUFBSztPQUFTLE9BQU87T0FBTSxXQUFXO09BQUssV0FBVSxVQUFTLFFBQVEsTUFBTSxPQUFPLEtBQUs7T0FBRyxZQUFXLFVBQVM7UUFBRSxJQUFJLE1BQU0sUUFBUSxVQUFVO1NBQUUsY0FBYyxLQUFLO1NBQUcsYUFBYSxTQUFTLE1BQU07UUFBRTtPQUFFO01BQUk7Ozs7O01BQUMsd0JBQUMsUUFBRDtPQUFRLE1BQUs7aUJBQVM7TUFBYzs7Ozs7S0FDOVU7Ozs7OztHQUNIOzs7Ozs7Q0FDQzs7Ozs7QUFDViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJkZXNrdG9wLWhvbWUtaGVhZGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlLCB1c2VSb3V0ZXJTdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBTZWFyY2gsIFNob3BwaW5nQ2FydCwgTG9nSW4sIFVzZXJSb3VuZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IEJ1dHRvbiwgYnV0dG9uVmFyaWFudHMgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5pbXBvcnQgeyBBdXRoQWN0aW9ucyB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9hdXRoLWFjdGlvbnMnXG5pbXBvcnQgeyB1c2VTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2FwaSdcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tICdAL2ZlYXR1cmVzL2NhcnQvcXVlcmllcydcblxuZXhwb3J0IGZ1bmN0aW9uIERlc2t0b3BIb21lSGVhZGVyKCkge1xuICBjb25zdCBpc0hvbWUgPSB1c2VSb3V0ZXJTdGF0ZSh7IHNlbGVjdDogc3RhdGUgPT4gc3RhdGUubG9jYXRpb24ucGF0aG5hbWUgPT09ICcvJyB9KVxuICAvLyBNb3VudCBvbmx5IG9uIEhvbWU6IG90aGVyIHNjcmVlbnMgcmV0YWluIHRoZWlyIGhlYWRlciBhbmQgcXVlcnkgbGlmZWN5Y2xlcy5cbiAgcmV0dXJuIGlzSG9tZSA/IDxIb21lSGVhZGVyIC8+IDogbnVsbFxufVxuZnVuY3Rpb24gSG9tZUhlYWRlcigpIHtcbiAgY29uc3QgW3NlYXJjaE9wZW4sIHNldFNlYXJjaE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt0ZXJtLCBzZXRUZXJtXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBzZWFyY2hJbnB1dCA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKVxuICBjb25zdCBzZWFyY2hUb2dnbGUgPSB1c2VSZWY8SFRNTEJ1dHRvbkVsZW1lbnQ+KG51bGwpXG4gIHVzZUVmZmVjdCgoKSA9PiB7IGlmIChzZWFyY2hPcGVuKSBzZWFyY2hJbnB1dC5jdXJyZW50Py5mb2N1cygpIH0sIFtzZWFyY2hPcGVuXSlcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKClcbiAgY29uc3QgY2FydCA9IHVzZUNhcnQoKVxuICBjb25zdCBxdWFudGl0eSA9IGNhcnQuZGF0YT8uaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIGl0ZW0ucXVhbnRpdHksIDApXG4gIHJldHVybiA8aGVhZGVyIGNsYXNzTmFtZT1cImRlc2t0b3AtaG9tZS1oZWFkZXIgZGVza3RvcC1ob21lLW9ubHlcIj5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImt1cmlvLWNvbnRhaW5lciBkZXNrdG9wLWhlYWRlci1pbm5lclwiPlxuICAgICAgPExpbmsgdG89XCIvXCIgYXJpYS1sYWJlbD1cIkt1cmlvIOKAlCBpbsOtY2lvXCIgY2xhc3NOYW1lPVwiZGVza3RvcC13b3JkbWFya1wiPktVUklPPC9MaW5rPlxuICAgICAgPG5hdiBhcmlhLWxhYmVsPVwiTmF2ZWdhw6fDo28gcHJpbmNpcGFsXCIgY2xhc3NOYW1lPVwiZGVza3RvcC1wcmltYXJ5LW5hdlwiPlxuICAgICAgICA8TGluayB0bz1cIi9cIiBhcmlhLWN1cnJlbnQ9XCJwYWdlXCIgY2xhc3NOYW1lPVwiaXMtYWN0aXZlXCI+SW7DrWNpbzwvTGluaz5cbiAgICAgICAgPGEgaHJlZj1cIiNjYXRhbG9nb1wiPk1lcmNhZG88L2E+PGEgaHJlZj1cIiNjcmlhZG9yZXNcIj5DcmlhZG9yZXM8L2E+PGEgaHJlZj1cIiNkaWFyaW9cIj5BcHJlbmRhPC9hPlxuICAgICAgPC9uYXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlc2t0b3AtaGVhZGVyLWFjdGlvbnNcIj5cbiAgICAgICAgPEJ1dHRvbiByZWY9e3NlYXJjaFRvZ2dsZX0gdmFyaWFudD1cImdob3N0XCIgYXJpYS1sYWJlbD1cIkFicmlyIGJ1c2NhIGRvIG1lcmNhZG9cIiBhcmlhLWV4cGFuZGVkPXtzZWFyY2hPcGVufSBhcmlhLWNvbnRyb2xzPVwiaGVhZGVyLW1hcmtldC1zZWFyY2hcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWFyY2hPcGVuKHZhbHVlID0+ICF2YWx1ZSl9PjxTZWFyY2ggYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz48L0J1dHRvbj5cbiAgICAgICAgPExpbmsgdG89XCIvY2FycmluaG9cIiBhcmlhLWxhYmVsPXtxdWFudGl0eSA9PT0gdW5kZWZpbmVkID8gJ0NhcnJpbmhvJyA6IGBDYXJyaW5obywgJHtxdWFudGl0eX0gaXRlbnNgfSBjbGFzc05hbWU9XCJkZXNrdG9wLWNhcnRcIj48U2hvcHBpbmdDYXJ0IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+e3F1YW50aXR5ICE9PSB1bmRlZmluZWQgJiYgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+e3F1YW50aXR5fTwvc3Bhbj59PC9MaW5rPlxuICAgICAgICB7c2Vzc2lvbi5kYXRhID8gPD48ZGV0YWlscyBjbGFzc05hbWU9XCJkZXNrdG9wLWFjY291bnRcIj48c3VtbWFyeT48VXNlclJvdW5kIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+PHNwYW4gcm9sZT1cInN0YXR1c1wiIGFyaWEtbGFiZWw9XCJVc3XDoXJpbyBjb25lY3RhZG9cIj57c2Vzc2lvbi5kYXRhLnVzZXIubmFtZX08L3NwYW4+PC9zdW1tYXJ5PlxuICAgICAgICAgIDxkaXY+PExpbmsgdG89XCIvcGVyZmlsXCI+UGVyZmlsPC9MaW5rPjxMaW5rIHRvPVwiL2NhcnRlaXJhc1wiPkNhcnRlaXJhczwvTGluaz48TGluayB0bz1cIi9mYXZvcml0b3NcIj5GYXZvcml0b3M8L0xpbms+PExpbmsgdG89XCIvcGVkaWRvL2NvbmZpcm1hY2FvXCI+UGVkaWRvczwvTGluaz48L2Rpdj5cbiAgICAgICAgPC9kZXRhaWxzPjxBdXRoQWN0aW9ucyBzaG93TmFtZT17ZmFsc2V9IC8+PC8+IDogPExpbmsgdG89XCIvbG9naW5cIiBjbGFzc05hbWU9e2J1dHRvblZhcmlhbnRzKHsgY2xhc3NOYW1lOiAnZGVza3RvcC1sb2dpbicgfSl9PjxMb2dJbiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPkVudHJhcjwvTGluaz59XG4gICAgICA8L2Rpdj5cbiAgICAgIHtzZWFyY2hPcGVuICYmIDxmb3JtIGlkPVwiaGVhZGVyLW1hcmtldC1zZWFyY2hcIiBjbGFzc05hbWU9XCJkZXNrdG9wLWhlYWRlci1zZWFyY2hcIiBvblN1Ym1pdD17ZXZlbnQgPT4ge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyB2b2lkIG5hdmlnYXRlKHsgdG86ICcvJywgc2VhcmNoOiBwcmV2aW91cyA9PiAoeyAuLi5wcmV2aW91cywgc2VhcmNoOiB0ZXJtLCBwYWdlOiAxIH0pLCBoYXNoOiAnY2F0YWxvZ28nIH0pOyBzZXRTZWFyY2hPcGVuKGZhbHNlKVxuICAgICAgfX0+XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwiaGVhZGVyLXNlYXJjaFwiPkJ1c2NhciBubyBtZXJjYWRvPC9sYWJlbD48SW5wdXQgcmVmPXtzZWFyY2hJbnB1dH0gaWQ9XCJoZWFkZXItc2VhcmNoXCIgdHlwZT1cInNlYXJjaFwiIHZhbHVlPXt0ZXJtfSBtYXhMZW5ndGg9ezEyMH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFRlcm0oZXZlbnQudGFyZ2V0LnZhbHVlKX0gb25LZXlEb3duPXtldmVudCA9PiB7IGlmIChldmVudC5rZXkgPT09ICdFc2NhcGUnKSB7IHNldFNlYXJjaE9wZW4oZmFsc2UpOyBzZWFyY2hUb2dnbGUuY3VycmVudD8uZm9jdXMoKSB9IH19IC8+PEJ1dHRvbiB0eXBlPVwic3VibWl0XCI+QnVzY2FyPC9CdXR0b24+XG4gICAgICA8L2Zvcm0+fVxuICAgIDwvZGl2PlxuICA8L2hlYWRlcj5cbn1cbiJdfQ==