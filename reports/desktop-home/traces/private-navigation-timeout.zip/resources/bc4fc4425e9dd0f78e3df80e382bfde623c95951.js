import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/favorites/favorites-page.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { LoadingState, ErrorState } from "/src/components/async-state.tsx";
import { apiErrorMessage } from "/src/lib/api.ts";
import { NftCard } from "/src/features/catalog/components/nft-card.tsx?t=1793943067891";
import { FavoriteButton } from "/src/features/favorites/favorite-button.tsx";
import { useFavorites } from "/src/features/favorites/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/favorites/favorites-page.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$();
export function FavoritesPage() {
	_s();
	const query = useFavorites();
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-8",
		children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "text-3xl font-bold",
			children: "Favoritos"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 41
		}, this), query.isPending ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: "Carregando favoritos" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 24
		}, this) : query.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
			message: apiErrorMessage(query.error),
			retry: () => void query.refetch()
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 88
		}, this) : query.data.items.length ? /* @__PURE__ */ _jsxDEV("div", {
			className: "favorites-grid",
			children: query.data.items.map((nft) => /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ _jsxDEV(NftCard, { nft }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 9,
					columnNumber: 306
				}, this), /* @__PURE__ */ _jsxDEV(FavoriteButton, { nft }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 9,
					columnNumber: 327
				}, this)]
			}, nft.id, true, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 266
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 205
		}, this) : /* @__PURE__ */ _jsxDEV("p", {
			role: "status",
			children: "Você ainda não tem favoritos."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 372
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 10
	}, this);
}
_s(FavoritesPage, "5ewATXVDauYvAtjwWarVzcCVJZc=", false, function() {
	return [useFavorites];
});
_c = FavoritesPage;
var _c;
$RefreshReg$(_c, "FavoritesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/favorites/favorites-page.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/favorites/favorites-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/favorites/favorites-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/favorites/favorites-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjLGtCQUFrQjtBQUN6QyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7Ozs7QUFDN0IsT0FBTyxTQUFTLGdCQUFnQjs7Q0FDOUIsTUFBTSxRQUFRLGFBQWE7Q0FDM0IsT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQixDQUErQix3QkFBQyxNQUFEO0dBQUksV0FBVTthQUFxQjtFQUFhOzs7O1lBQ25GLE1BQU0sWUFBWSx3QkFBQyxjQUFELEVBQWMsT0FBTSx1QkFBd0I7Ozs7YUFBSSxNQUFNLFVBQVUsd0JBQUMsWUFBRDtHQUFZLFNBQVMsZ0JBQWdCLE1BQU0sS0FBSztHQUFHLGFBQWEsS0FBSyxNQUFNLFFBQVE7RUFBSTs7OzthQUFJLE1BQU0sS0FBSyxNQUFNLFNBQVMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBa0IsTUFBTSxLQUFLLE1BQU0sS0FBSSxRQUFPLHdCQUFDLE9BQUQ7SUFBa0IsV0FBVTtjQUE1QixDQUF3Qyx3QkFBQyxTQUFELEVBQWMsSUFBTTs7OztjQUFDLHdCQUFDLGdCQUFELEVBQXFCLElBQU07Ozs7WUFBTTtNQUFwRixJQUFJOzs7O1VBQWdGLENBQUM7RUFBTzs7OzthQUFJLHdCQUFDLEtBQUQ7R0FBRyxNQUFLO2FBQVM7RUFBZ0M7Ozs7VUFDelo7Ozs7OztBQUNYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZhdm9yaXRlcy1wYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMb2FkaW5nU3RhdGUsIEVycm9yU3RhdGUgfSBmcm9tICdAL2NvbXBvbmVudHMvYXN5bmMtc3RhdGUnXG5pbXBvcnQgeyBhcGlFcnJvck1lc3NhZ2UgfSBmcm9tICdAL2xpYi9hcGknXG5pbXBvcnQgeyBOZnRDYXJkIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvbmZ0LWNhcmQnXG5pbXBvcnQgeyBGYXZvcml0ZUJ1dHRvbiB9IGZyb20gJy4vZmF2b3JpdGUtYnV0dG9uJ1xuaW1wb3J0IHsgdXNlRmF2b3JpdGVzIH0gZnJvbSAnLi9xdWVyaWVzJ1xuZXhwb3J0IGZ1bmN0aW9uIEZhdm9yaXRlc1BhZ2UoKSB7XG4gIGNvbnN0IHF1ZXJ5ID0gdXNlRmF2b3JpdGVzKClcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPjxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGRcIj5GYXZvcml0b3M8L2gxPlxuICAgIHtxdWVyeS5pc1BlbmRpbmcgPyA8TG9hZGluZ1N0YXRlIGxhYmVsPVwiQ2FycmVnYW5kbyBmYXZvcml0b3NcIiAvPiA6IHF1ZXJ5LmlzRXJyb3IgPyA8RXJyb3JTdGF0ZSBtZXNzYWdlPXthcGlFcnJvck1lc3NhZ2UocXVlcnkuZXJyb3IpfSByZXRyeT17KCkgPT4gdm9pZCBxdWVyeS5yZWZldGNoKCl9IC8+IDogcXVlcnkuZGF0YS5pdGVtcy5sZW5ndGggPyA8ZGl2IGNsYXNzTmFtZT1cImZhdm9yaXRlcy1ncmlkXCI+e3F1ZXJ5LmRhdGEuaXRlbXMubWFwKG5mdCA9PiA8ZGl2IGtleT17bmZ0LmlkfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj48TmZ0Q2FyZCBuZnQ9e25mdH0gLz48RmF2b3JpdGVCdXR0b24gbmZ0PXtuZnR9IC8+PC9kaXY+KX08L2Rpdj4gOiA8cCByb2xlPVwic3RhdHVzXCI+Vm9jw6ogYWluZGEgbsOjbyB0ZW0gZmF2b3JpdG9zLjwvcD59XG4gIDwvc2VjdGlvbj5cbn1cbiJdfQ==