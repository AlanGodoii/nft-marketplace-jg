import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/profile/profile-page.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=22c23eb4";
import { Link, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=22c23eb4";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=22c23eb4";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=22c23eb4";
import { z } from "/node_modules/.vite/deps/zod.js?v=22c23eb4";
import { avatarDataSchema, avatarMaxBytes, passwordFormSchema, profileUpdateSchema } from "/src/contracts/profile.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { ErrorState, LoadingState } from "/src/components/async-state.tsx";
import { ApiRequestError, apiErrorMessage } from "/src/lib/api.ts";
import { identityEpoch } from "/src/lib/identity.ts";
import { adoptSession } from "/src/features/auth/lifecycle.ts";
import { useChangePassword, useProfile, useSaveProfile } from "/src/features/profile/queries.ts";
var _jsxFileName = "/workspace/nft-marketplace-jg/src/features/profile/profile-page.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=22c23eb4";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
const labels = {
	name: "Nome de exibição",
	email: "E-mail",
	username: "Nome de usuário",
	website: "Website",
	bio: "Biografia"
};
function fields(profile) {
	return {
		name: profile.name,
		email: profile.email,
		username: profile.username,
		website: profile.website,
		bio: profile.bio,
		version: profile.version
	};
}
function ProfileEditor({ profile }) {
	_s();
	const [notice, setNotice] = useState("");
	const form = useForm({
		resolver: zodResolver(profileUpdateSchema),
		defaultValues: fields(profile)
	});
	const save = useSaveProfile("data");
	return /* @__PURE__ */ _jsxDEV("form", {
		"aria-label": "Dados do perfil",
		noValidate: true,
		className: "commerce-panel auth-form",
		onSubmit: form.handleSubmit((values) => {
			setNotice("");
			save.mutate({
				...values,
				version: profile.version
			}, {
				onSuccess: (updated) => {
					form.reset(fields(updated));
					setNotice("Perfil atualizado.");
				},
				onError: (error) => {
					if (error instanceof ApiRequestError) {
						for (const key of Object.keys(labels)) if (error.fields?.[key]) form.setError(key, { message: error.fields[key][0] });
					}
				}
			});
		}),
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-bold",
				children: "Informações do colecionador"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "commerce-form-grid",
				children: Object.keys(labels).map((key) => /* @__PURE__ */ _jsxDEV("div", {
					className: key === "bio" ? "profile-wide space-y-2" : "space-y-2",
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							htmlFor: `profile-${key}`,
							children: labels[key]
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 7
						}, this),
						key === "bio" ? /* @__PURE__ */ _jsxDEV("textarea", {
							id: "profile-bio",
							rows: 4,
							...form.register(key),
							"aria-invalid": !!form.formState.errors[key],
							"aria-describedby": `profile-${key}-error`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 24
						}, this) : /* @__PURE__ */ _jsxDEV(Input, {
							id: `profile-${key}`,
							type: key === "email" ? "email" : key === "website" ? "url" : "text",
							autoComplete: key === "name" ? "name" : key === "email" ? "email" : key === "username" ? "username" : "url",
							...form.register(key),
							"aria-invalid": !!form.formState.errors[key],
							"aria-describedby": `profile-${key}-error`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 175
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							id: `profile-${key}-error`,
							className: "field-error",
							children: form.formState.errors[key]?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 7
						}, this)
					]
				}, key, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 102
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 5
			}, this),
			save.isError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: apiErrorMessage(save.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 22
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				children: notice
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				type: "submit",
				disabled: save.isPending,
				children: save.isPending ? "Salvando…" : "Salvar perfil"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 10
	}, this);
}
_s(ProfileEditor, "h871wjLqkFE9CkjPheX3Dv0RnFA=", false, function() {
	return [useForm, useSaveProfile];
});
_c = ProfileEditor;
function AvatarEditor({ profile }) {
	_s2();
	const [selected, setSelected] = useState(null);
	const [error, setError] = useState("");
	const [notice, setNotice] = useState("");
	const [reading, setReading] = useState(false);
	const save = useSaveProfile("avatar");
	async function choose(file) {
		setError("");
		setNotice("");
		setSelected(null);
		if (!file) return;
		if (![
			"image/png",
			"image/jpeg",
			"image/webp"
		].includes(file.type) || file.size > avatarMaxBytes || file.size === 0) {
			setError("Use PNG, JPEG ou WebP de até 256 KiB.");
			return;
		}
		setReading(true);
		try {
			const data = await new Promise((resolve, reject) => {
				const reader = new FileReader();
				reader.onload = () => resolve(String(reader.result));
				reader.onerror = reject;
				reader.readAsDataURL(file);
			});
			setSelected(avatarDataSchema.parse(data));
		} catch {
			setError("Não foi possível ler a imagem.");
		} finally {
			setReading(false);
		}
	}
	function submit(avatar) {
		setError("");
		setNotice("");
		save.mutate({
			avatar,
			version: profile.version
		}, { onSuccess: () => {
			setSelected(null);
			setNotice(avatar ? "Avatar atualizado." : "Avatar removido.");
		} });
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "commerce-panel space-y-4",
		"aria-labelledby": "avatar-title",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				id: "avatar-title",
				className: "text-xl font-bold",
				children: "Avatar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 5
			}, this),
			selected || profile.avatar ? /* @__PURE__ */ _jsxDEV("img", {
				className: "profile-avatar",
				src: selected ?? profile.avatar,
				width: 112,
				height: 112,
				alt: selected ? "Prévia do avatar selecionado" : `Avatar de ${profile.name}`
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 35
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "profile-avatar profile-avatar-empty",
				role: "img",
				"aria-label": "Nenhum avatar cadastrado",
				children: profile.name.slice(0, 1).toUpperCase()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 209
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "profile-avatar",
				children: "Imagem do avatar"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Input, {
				id: "profile-avatar",
				type: "file",
				accept: "image/png,image/jpeg,image/webp",
				"aria-invalid": !!error,
				"aria-describedby": "avatar-help avatar-error",
				disabled: reading || save.isPending,
				onChange: (event) => void choose(event.target.files?.[0])
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				id: "avatar-help",
				className: "text-sm text-muted-foreground",
				children: "PNG, JPEG ou WebP. Até 256 KiB e 4096×4096 px. SVG não é aceito."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				id: "avatar-error",
				className: "field-error",
				role: "alert",
				children: error || (save.isError ? apiErrorMessage(save.error) : "")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				children: reading ? "Lendo imagem…" : notice
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ _jsxDEV(Button, {
					type: "button",
					disabled: !selected || save.isPending || reading,
					onClick: () => submit(selected),
					children: "Salvar avatar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 43
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					type: "button",
					variant: "outline",
					disabled: !profile.avatar || save.isPending,
					onClick: () => submit(null),
					children: "Remover avatar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 170
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 10
	}, this);
}
_s2(AvatarEditor, "h1W7bVkRfNyhfSltE0bJqf2IqWI=", false, function() {
	return [useSaveProfile];
});
_c2 = AvatarEditor;
function PasswordEditor() {
	_s3();
	const form = useForm({
		resolver: zodResolver(passwordFormSchema),
		defaultValues: {
			currentPassword: "",
			newPassword: "",
			confirmPassword: ""
		}
	});
	const change = useChangePassword();
	const router = useRouter();
	const epoch = identityEpoch();
	return /* @__PURE__ */ _jsxDEV("form", {
		className: "commerce-panel auth-form",
		"aria-label": "Alterar senha",
		noValidate: true,
		onSubmit: form.handleSubmit((values) => change.mutate({
			currentPassword: values.currentPassword,
			newPassword: values.newPassword
		}, {
			onSuccess: async () => {
				if (epoch !== identityEpoch()) return;
				form.reset();
				await adoptSession(null, null);
				await router.invalidate();
				await router.navigate({
					to: "/login",
					search: { redirect: "/perfil" },
					replace: true
				});
			},
			onError: (error) => {
				if (error instanceof ApiRequestError && error.fields?.currentPassword) form.setError("currentPassword", { message: error.fields.currentPassword[0] });
			}
		})),
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-bold",
				children: "Alterar senha"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-muted-foreground",
				children: "Após salvar, todas as sessões serão encerradas. Entre novamente com a nova senha. Sua coleção e seus pedidos serão preservados."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 5
			}, this),
			[
				"currentPassword",
				"newPassword",
				"confirmPassword"
			].map((key) => /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: `profile-${key}`,
						children: {
							currentPassword: "Senha atual",
							newPassword: "Nova senha",
							confirmPassword: "Confirmar nova senha"
						}[key]
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV(Input, {
						id: `profile-${key}`,
						type: "password",
						autoComplete: key === "currentPassword" ? "current-password" : "new-password",
						...form.register(key),
						"aria-invalid": !!form.formState.errors[key],
						"aria-describedby": `${key}-error`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						id: `${key}-error`,
						className: "field-error",
						children: form.formState.errors[key]?.message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 7
					}, this)
				]
			}, key, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 82
			}, this)),
			change.isError && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: apiErrorMessage(change.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 24
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				type: "submit",
				disabled: change.isPending,
				children: change.isPending ? "Alterando…" : "Alterar senha e sair"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 72,
		columnNumber: 10
	}, this);
}
_s3(PasswordEditor, "ng+PiKOyNprxF9SDDw6JG1x3tEM=", false, function() {
	return [
		useForm,
		useChangePassword,
		useRouter
	];
});
_c3 = PasswordEditor;
export function ProfilePage() {
	_s4();
	const profile = useProfile();
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "space-y-8",
		children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "text-3xl font-bold",
			children: "Perfil"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 46
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "mt-3 text-muted-foreground",
			children: "Sua identidade de colecionador na Kurio."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 92
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 41
		}, this), profile.isPending ? /* @__PURE__ */ _jsxDEV(LoadingState, { label: "Carregando perfil…" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 26
		}, this) : profile.isError ? /* @__PURE__ */ _jsxDEV(ErrorState, {
			message: apiErrorMessage(profile.error),
			retry: () => void profile.refetch()
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 90
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "profile-layout",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV(ProfileEditor, { profile: profile.data }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 34
				}, this), /* @__PURE__ */ _jsxDEV(PasswordEditor, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 74
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV(AvatarEditor, { profile: profile.data }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 127
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: "/carteiras",
					className: "inline-block underline",
					children: "Gerenciar carteiras"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 166
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 98
			}, this)]
		}, profile.data.id, true, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 185
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 89,
		columnNumber: 10
	}, this);
}
_s4(ProfilePage, "3n4HTshNmHS4cQEeyLn4vD/Tl/M=", false, function() {
	return [useProfile];
});
_c4 = ProfilePage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "ProfileEditor");
$RefreshReg$(_c2, "AvatarEditor");
$RefreshReg$(_c3, "PasswordEditor");
$RefreshReg$(_c4, "ProfilePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/profile/profile-page.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/nft-marketplace-jg/src/features/profile/profile-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/nft-marketplace-jg/src/features/profile/profile-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/nft-marketplace-jg/src/features/profile/profile-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLGlCQUFpQjtBQUNoQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsa0JBQWtCLGdCQUFnQixvQkFBb0IsMkJBQTZEO0FBQzVILFNBQVMsY0FBYztBQUN2QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxZQUFZLG9CQUFvQjtBQUN6QyxTQUFTLGlCQUFpQix1QkFBdUI7QUFDakQsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUIsWUFBWSxzQkFBc0I7Ozs7QUFFOUQsTUFBTSxTQUFTO0NBQUUsTUFBTTtDQUFvQixPQUFPO0NBQVUsVUFBVTtDQUFtQixTQUFTO0NBQVcsS0FBSztBQUFZO0FBQzlILFNBQVMsT0FBTyxTQUFpQztDQUMvQyxPQUFPO0VBQUUsTUFBTSxRQUFRO0VBQU0sT0FBTyxRQUFRO0VBQU8sVUFBVSxRQUFRO0VBQVUsU0FBUyxRQUFRO0VBQVMsS0FBSyxRQUFRO0VBQUssU0FBUyxRQUFRO0NBQVE7QUFDdEo7QUFDQSxTQUFTLGNBQWMsRUFBRSxXQUFpQzs7Q0FDeEQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEVBQUU7Q0FDdkMsTUFBTSxPQUFPLFFBQXVCO0VBQUUsVUFBVSxZQUFZLG1CQUFtQjtFQUFHLGVBQWUsT0FBTyxPQUFPO0NBQUUsQ0FBQztDQUNsSCxNQUFNLE9BQU8sZUFBZSxNQUFNO0NBQ2xDLE9BQU8sd0JBQUMsUUFBRDtFQUFNLGNBQVc7RUFBa0I7RUFBVyxXQUFVO0VBQTJCLFVBQVUsS0FBSyxjQUFhLFdBQVU7R0FDOUgsVUFBVSxFQUFFO0dBQUcsS0FBSyxPQUFPO0lBQUUsR0FBRztJQUFRLFNBQVMsUUFBUTtHQUFRLEdBQUc7SUFBRSxZQUFXLFlBQVc7S0FBRSxLQUFLLE1BQU0sT0FBTyxPQUFPLENBQUM7S0FBRyxVQUFVLG9CQUFvQjtJQUFFO0lBQUcsVUFBUyxVQUFTO0tBQzlLLElBQUksaUJBQWlCLGlCQUFpQjtXQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssTUFBTSxHQUE4QixJQUFJLE1BQU0sU0FBUyxNQUFNLEtBQUssU0FBUyxLQUFLLEVBQUUsU0FBUyxNQUFNLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQzs7SUFDdkw7R0FBRSxDQUFDO0VBQ0wsQ0FBQztZQUpNO0dBS0wsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBb0I7R0FBK0I7Ozs7O0dBQ2pFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQXVCLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBNkIsS0FBSSxRQUFPLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLFFBQVEsUUFBUSwyQkFBMkI7ZUFBM0Q7TUFDL0Ysd0JBQUMsU0FBRDtPQUFPLFNBQVMsV0FBVztpQkFBUSxPQUFPO01BQVk7Ozs7O01BQ3JELFFBQVEsUUFBUSx3QkFBQyxZQUFEO09BQVUsSUFBRztPQUFjLE1BQU07T0FBRyxHQUFJLEtBQUssU0FBUyxHQUFHO09BQUcsZ0JBQWMsQ0FBQyxDQUFDLEtBQUssVUFBVSxPQUFPO09BQU0sb0JBQWtCLFdBQVcsSUFBSTtNQUFVOzs7O2lCQUFJLHdCQUFDLE9BQUQ7T0FBTyxJQUFJLFdBQVc7T0FBTyxNQUFNLFFBQVEsVUFBVSxVQUFVLFFBQVEsWUFBWSxRQUFRO09BQVEsY0FBYyxRQUFRLFNBQVMsU0FBUyxRQUFRLFVBQVUsVUFBVSxRQUFRLGFBQWEsYUFBYTtPQUFPLEdBQUksS0FBSyxTQUFTLEdBQUc7T0FBRyxnQkFBYyxDQUFDLENBQUMsS0FBSyxVQUFVLE9BQU87T0FBTSxvQkFBa0IsV0FBVyxJQUFJO01BQVU7Ozs7O01BQ3ZlLHdCQUFDLEtBQUQ7T0FBRyxJQUFJLFdBQVcsSUFBSTtPQUFTLFdBQVU7aUJBQWUsS0FBSyxVQUFVLE9BQU8sSUFBSSxFQUFFO01BQVc7Ozs7O0tBQzVGO09BSnlLOzs7O1dBSXpLLENBQUM7R0FBTzs7Ozs7R0FDWixLQUFLLFdBQVcsd0JBQUMsS0FBRDtJQUFHLE1BQUs7Y0FBUyxnQkFBZ0IsS0FBSyxLQUFLO0dBQUs7Ozs7O0dBQ2pFLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO2NBQVU7R0FBVTs7Ozs7R0FDNUIsd0JBQUMsUUFBRDtJQUFRLE1BQUs7SUFBUyxVQUFVLEtBQUs7Y0FBWSxLQUFLLFlBQVksY0FBYztHQUF3Qjs7Ozs7RUFDcEc7Ozs7OztBQUNSOzs7OztBQUNBLFNBQVMsYUFBYSxFQUFFLFdBQWlDOztDQUN2RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7Q0FDNUQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FBRyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUFHLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzlILE1BQU0sT0FBTyxlQUFlLFFBQVE7Q0FDcEMsZUFBZSxPQUFPLE1BQWE7RUFDakMsU0FBUyxFQUFFO0VBQUcsVUFBVSxFQUFFO0VBQUcsWUFBWSxJQUFJO0VBQzdDLElBQUksQ0FBQyxNQUFNO0VBQ1gsSUFBSSxDQUFDO0dBQUM7R0FBYTtHQUFjO0VBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLGtCQUFrQixLQUFLLFNBQVMsR0FBRztHQUFFLFNBQVMsdUNBQXVDO0dBQUc7RUFBTztFQUNqTCxXQUFXLElBQUk7RUFDZixJQUFJO0dBQ0YsTUFBTSxPQUFPLE1BQU0sSUFBSSxTQUFpQixTQUFTLFdBQVc7SUFBRSxNQUFNLFNBQVMsSUFBSSxXQUFXO0lBQUcsT0FBTyxlQUFlLFFBQVEsT0FBTyxPQUFPLE1BQU0sQ0FBQztJQUFHLE9BQU8sVUFBVTtJQUFRLE9BQU8sY0FBYyxJQUFJO0dBQUUsQ0FBQztHQUMxTSxZQUFZLGlCQUFpQixNQUFNLElBQUksQ0FBQztFQUMxQyxRQUFRO0dBQUUsU0FBUyxnQ0FBZ0M7RUFBRSxVQUFVO0dBQUUsV0FBVyxLQUFLO0VBQUU7Q0FDckY7Q0FDQSxTQUFTLE9BQU8sUUFBdUI7RUFDckMsU0FBUyxFQUFFO0VBQUcsVUFBVSxFQUFFO0VBQzFCLEtBQUssT0FBTztHQUFFO0dBQVEsU0FBUyxRQUFRO0VBQVEsR0FBRyxFQUFFLGlCQUFpQjtHQUFFLFlBQVksSUFBSTtHQUFHLFVBQVUsU0FBUyx1QkFBdUIsa0JBQWtCO0VBQUUsRUFBRSxDQUFDO0NBQzdKO0NBQ0EsT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtFQUEyQixtQkFBZ0I7WUFBOUQ7R0FDTCx3QkFBQyxNQUFEO0lBQUksSUFBRztJQUFlLFdBQVU7Y0FBb0I7R0FBVTs7Ozs7R0FDN0QsWUFBWSxRQUFRLFNBQVMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBaUIsS0FBSyxZQUFZLFFBQVE7SUFBUyxPQUFPO0lBQUssUUFBUTtJQUFLLEtBQUssV0FBVyxpQ0FBaUMsYUFBYSxRQUFRO0dBQVM7Ozs7Y0FBSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFzQyxNQUFLO0lBQU0sY0FBVztjQUE0QixRQUFRLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVk7R0FBTzs7Ozs7R0FDL1Ysd0JBQUMsU0FBRDtJQUFPLFNBQVE7Y0FBaUI7R0FBdUI7Ozs7O0dBQ3ZELHdCQUFDLE9BQUQ7SUFBTyxJQUFHO0lBQWlCLE1BQUs7SUFBTyxRQUFPO0lBQWtDLGdCQUFjLENBQUMsQ0FBQztJQUFPLG9CQUFpQjtJQUEyQixVQUFVLFdBQVcsS0FBSztJQUFXLFdBQVUsVUFBUyxLQUFLLE9BQU8sTUFBTSxPQUFPLFFBQVEsRUFBRTtHQUFJOzs7OztHQUNsUCx3QkFBQyxLQUFEO0lBQUcsSUFBRztJQUFjLFdBQVU7Y0FBZ0M7R0FBbUU7Ozs7O0dBQ2pJLHdCQUFDLEtBQUQ7SUFBRyxJQUFHO0lBQWUsV0FBVTtJQUFjLE1BQUs7Y0FBUyxVQUFVLEtBQUssVUFBVSxnQkFBZ0IsS0FBSyxLQUFLLElBQUk7R0FBTzs7Ozs7R0FDekgsd0JBQUMsS0FBRDtJQUFHLE1BQUs7Y0FBVSxVQUFVLGtCQUFrQjtHQUFVOzs7OztHQUN4RCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQXNDLHdCQUFDLFFBQUQ7S0FBUSxNQUFLO0tBQVMsVUFBVSxDQUFDLFlBQVksS0FBSyxhQUFhO0tBQVMsZUFBZSxPQUFPLFFBQVE7ZUFBRztJQUFxQjs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBUSxNQUFLO0tBQVMsU0FBUTtLQUFVLFVBQVUsQ0FBQyxRQUFRLFVBQVUsS0FBSztLQUFXLGVBQWUsT0FBTyxJQUFJO2VBQUc7SUFBc0I7Ozs7WUFBTTs7Ozs7O0VBQzVTOzs7Ozs7QUFDWDs7Ozs7QUFDQSxTQUFTLGlCQUFpQjs7Q0FFeEIsTUFBTSxPQUFPLFFBQWdCO0VBQUUsVUFBVSxZQUFZLGtCQUFrQjtFQUFHLGVBQWU7R0FBRSxpQkFBaUI7R0FBSSxhQUFhO0dBQUksaUJBQWlCO0VBQUc7Q0FBRSxDQUFDO0NBQ3hKLE1BQU0sU0FBUyxrQkFBa0I7Q0FBRyxNQUFNLFNBQVMsVUFBVTtDQUFHLE1BQU0sUUFBUSxjQUFjO0NBQzVGLE9BQU8sd0JBQUMsUUFBRDtFQUFNLFdBQVU7RUFBMkIsY0FBVztFQUFnQjtFQUFXLFVBQVUsS0FBSyxjQUFhLFdBQVUsT0FBTyxPQUFPO0dBQUUsaUJBQWlCLE9BQU87R0FBaUIsYUFBYSxPQUFPO0VBQVksR0FBRztHQUFFLFdBQVcsWUFBWTtJQUNqUCxJQUFJLFVBQVUsY0FBYyxHQUFHO0lBQy9CLEtBQUssTUFBTTtJQUFHLE1BQU0sYUFBYSxNQUFNLElBQUk7SUFBRyxNQUFNLE9BQU8sV0FBVztJQUFHLE1BQU0sT0FBTyxTQUFTO0tBQUUsSUFBSTtLQUFVLFFBQVEsRUFBRSxVQUFVLFVBQVU7S0FBRyxTQUFTO0lBQUssQ0FBQztHQUNqSztHQUFHLFVBQVMsVUFBUztJQUFFLElBQUksaUJBQWlCLG1CQUFtQixNQUFNLFFBQVEsaUJBQWlCLEtBQUssU0FBUyxtQkFBbUIsRUFBRSxTQUFTLE1BQU0sT0FBTyxnQkFBZ0IsR0FBRyxDQUFDO0dBQUU7RUFBRSxDQUFDLENBQUM7WUFIMUs7R0FJTCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFvQjtHQUFpQjs7Ozs7R0FDbkQsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBZ0M7R0FBa0k7Ozs7O0dBQzdLO0lBQUM7SUFBbUI7SUFBZTtHQUFpQixDQUFDLENBQVcsS0FBSSxRQUFPLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDM0Usd0JBQUMsU0FBRDtNQUFPLFNBQVMsV0FBVztnQkFBUTtPQUFFLGlCQUFpQjtPQUFlLGFBQWE7T0FBYyxpQkFBaUI7TUFBdUIsRUFBRTtLQUFZOzs7OztLQUN0Six3QkFBQyxPQUFEO01BQU8sSUFBSSxXQUFXO01BQU8sTUFBSztNQUFXLGNBQWMsUUFBUSxvQkFBb0IscUJBQXFCO01BQWdCLEdBQUksS0FBSyxTQUFTLEdBQUc7TUFBRyxnQkFBYyxDQUFDLENBQUMsS0FBSyxVQUFVLE9BQU87TUFBTSxvQkFBa0IsR0FBRyxJQUFJO0tBQVU7Ozs7O0tBQ25PLHdCQUFDLEtBQUQ7TUFBRyxJQUFJLEdBQUcsSUFBSTtNQUFTLFdBQVU7Z0JBQWUsS0FBSyxVQUFVLE9BQU8sSUFBSSxFQUFFO0tBQVc7Ozs7O0lBQ3BGO01BSndHOzs7O1VBSXhHLENBQUM7R0FDTCxPQUFPLFdBQVcsd0JBQUMsS0FBRDtJQUFHLE1BQUs7Y0FBUyxnQkFBZ0IsT0FBTyxLQUFLO0dBQUs7Ozs7O0dBQ3JFLHdCQUFDLFFBQUQ7SUFBUSxNQUFLO0lBQVMsVUFBVSxPQUFPO2NBQVksT0FBTyxZQUFZLGVBQWU7R0FBK0I7Ozs7O0VBQ2hIOzs7Ozs7QUFDUjs7Ozs7Ozs7O0FBQ0EsT0FBTyxTQUFTLGNBQWM7O0NBQzVCLE1BQU0sVUFBVSxXQUFXO0NBQzNCLE9BQU8sd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkIsQ0FBK0Isd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQXFCO0VBQVU7Ozs7WUFBQyx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUE2QjtFQUEyQzs7OztVQUFNOzs7O1lBQ2pMLFFBQVEsWUFBWSx3QkFBQyxjQUFELEVBQWMsT0FBTSxxQkFBc0I7Ozs7YUFBSSxRQUFRLFVBQVUsd0JBQUMsWUFBRDtHQUFZLFNBQVMsZ0JBQWdCLFFBQVEsS0FBSztHQUFHLGFBQWEsS0FBSyxRQUFRLFFBQVE7RUFBSTs7OzthQUFJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDbEwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUEyQix3QkFBQyxlQUFELEVBQWUsU0FBUyxRQUFRLEtBQU87Ozs7Y0FBQyx3QkFBQyxnQkFBRCxDQUFpQjs7OztZQUFNOzs7OzthQUFDLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQWpCLENBQTZCLHdCQUFDLGNBQUQsRUFBYyxTQUFTLFFBQVEsS0FBTzs7OztjQUFDLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO0tBQWEsV0FBVTtlQUF5QjtJQUF5Qjs7OztZQUFROzs7OztXQUN0UDtLQUZvTixRQUFRLEtBQUs7Ozs7U0FFak8sQ0FDRTs7Ozs7O0FBQ1giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicHJvZmlsZS1wYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluaywgdXNlUm91dGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tICdyZWFjdC1ob29rLWZvcm0nXG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJ1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcbmltcG9ydCB7IGF2YXRhckRhdGFTY2hlbWEsIGF2YXRhck1heEJ5dGVzLCBwYXNzd29yZEZvcm1TY2hlbWEsIHByb2ZpbGVVcGRhdGVTY2hlbWEsIHR5cGUgUHJvZmlsZSwgdHlwZSBQcm9maWxlVXBkYXRlIH0gZnJvbSAnQC9jb250cmFjdHMvcHJvZmlsZSdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7IEVycm9yU3RhdGUsIExvYWRpbmdTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9hc3luYy1zdGF0ZSdcbmltcG9ydCB7IEFwaVJlcXVlc3RFcnJvciwgYXBpRXJyb3JNZXNzYWdlIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgaWRlbnRpdHlFcG9jaCB9IGZyb20gJ0AvbGliL2lkZW50aXR5J1xuaW1wb3J0IHsgYWRvcHRTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2xpZmVjeWNsZSdcbmltcG9ydCB7IHVzZUNoYW5nZVBhc3N3b3JkLCB1c2VQcm9maWxlLCB1c2VTYXZlUHJvZmlsZSB9IGZyb20gJy4vcXVlcmllcydcblxuY29uc3QgbGFiZWxzID0geyBuYW1lOiAnTm9tZSBkZSBleGliacOnw6NvJywgZW1haWw6ICdFLW1haWwnLCB1c2VybmFtZTogJ05vbWUgZGUgdXN1w6FyaW8nLCB3ZWJzaXRlOiAnV2Vic2l0ZScsIGJpbzogJ0Jpb2dyYWZpYScgfSBhcyBjb25zdFxuZnVuY3Rpb24gZmllbGRzKHByb2ZpbGU6IFByb2ZpbGUpOiBQcm9maWxlVXBkYXRlIHtcbiAgcmV0dXJuIHsgbmFtZTogcHJvZmlsZS5uYW1lLCBlbWFpbDogcHJvZmlsZS5lbWFpbCwgdXNlcm5hbWU6IHByb2ZpbGUudXNlcm5hbWUsIHdlYnNpdGU6IHByb2ZpbGUud2Vic2l0ZSwgYmlvOiBwcm9maWxlLmJpbywgdmVyc2lvbjogcHJvZmlsZS52ZXJzaW9uIH1cbn1cbmZ1bmN0aW9uIFByb2ZpbGVFZGl0b3IoeyBwcm9maWxlIH06IHsgcHJvZmlsZTogUHJvZmlsZSB9KSB7XG4gIGNvbnN0IFtub3RpY2UsIHNldE5vdGljZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgZm9ybSA9IHVzZUZvcm08UHJvZmlsZVVwZGF0ZT4oeyByZXNvbHZlcjogem9kUmVzb2x2ZXIocHJvZmlsZVVwZGF0ZVNjaGVtYSksIGRlZmF1bHRWYWx1ZXM6IGZpZWxkcyhwcm9maWxlKSB9KVxuICBjb25zdCBzYXZlID0gdXNlU2F2ZVByb2ZpbGUoJ2RhdGEnKVxuICByZXR1cm4gPGZvcm0gYXJpYS1sYWJlbD1cIkRhZG9zIGRvIHBlcmZpbFwiIG5vVmFsaWRhdGUgY2xhc3NOYW1lPVwiY29tbWVyY2UtcGFuZWwgYXV0aC1mb3JtXCIgb25TdWJtaXQ9e2Zvcm0uaGFuZGxlU3VibWl0KHZhbHVlcyA9PiB7XG4gICAgc2V0Tm90aWNlKCcnKTsgc2F2ZS5tdXRhdGUoeyAuLi52YWx1ZXMsIHZlcnNpb246IHByb2ZpbGUudmVyc2lvbiB9LCB7IG9uU3VjY2VzczogdXBkYXRlZCA9PiB7IGZvcm0ucmVzZXQoZmllbGRzKHVwZGF0ZWQpKTsgc2V0Tm90aWNlKCdQZXJmaWwgYXR1YWxpemFkby4nKSB9LCBvbkVycm9yOiBlcnJvciA9PiB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBBcGlSZXF1ZXN0RXJyb3IpIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGxhYmVscykgYXMgKGtleW9mIHR5cGVvZiBsYWJlbHMpW10pIGlmIChlcnJvci5maWVsZHM/LltrZXldKSBmb3JtLnNldEVycm9yKGtleSwgeyBtZXNzYWdlOiBlcnJvci5maWVsZHNba2V5XVswXSB9KVxuICAgIH0gfSlcbiAgfSl9PlxuICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZFwiPkluZm9ybWHDp8O1ZXMgZG8gY29sZWNpb25hZG9yPC9oMj5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbW1lcmNlLWZvcm0tZ3JpZFwiPnsoT2JqZWN0LmtleXMobGFiZWxzKSBhcyAoa2V5b2YgdHlwZW9mIGxhYmVscylbXSkubWFwKGtleSA9PiA8ZGl2IGNsYXNzTmFtZT17a2V5ID09PSAnYmlvJyA/ICdwcm9maWxlLXdpZGUgc3BhY2UteS0yJyA6ICdzcGFjZS15LTInfSBrZXk9e2tleX0+XG4gICAgICA8bGFiZWwgaHRtbEZvcj17YHByb2ZpbGUtJHtrZXl9YH0+e2xhYmVsc1trZXldfTwvbGFiZWw+XG4gICAgICB7a2V5ID09PSAnYmlvJyA/IDx0ZXh0YXJlYSBpZD1cInByb2ZpbGUtYmlvXCIgcm93cz17NH0gey4uLmZvcm0ucmVnaXN0ZXIoa2V5KX0gYXJpYS1pbnZhbGlkPXshIWZvcm0uZm9ybVN0YXRlLmVycm9yc1trZXldfSBhcmlhLWRlc2NyaWJlZGJ5PXtgcHJvZmlsZS0ke2tleX0tZXJyb3JgfSAvPiA6IDxJbnB1dCBpZD17YHByb2ZpbGUtJHtrZXl9YH0gdHlwZT17a2V5ID09PSAnZW1haWwnID8gJ2VtYWlsJyA6IGtleSA9PT0gJ3dlYnNpdGUnID8gJ3VybCcgOiAndGV4dCd9IGF1dG9Db21wbGV0ZT17a2V5ID09PSAnbmFtZScgPyAnbmFtZScgOiBrZXkgPT09ICdlbWFpbCcgPyAnZW1haWwnIDoga2V5ID09PSAndXNlcm5hbWUnID8gJ3VzZXJuYW1lJyA6ICd1cmwnfSB7Li4uZm9ybS5yZWdpc3RlcihrZXkpfSBhcmlhLWludmFsaWQ9eyEhZm9ybS5mb3JtU3RhdGUuZXJyb3JzW2tleV19IGFyaWEtZGVzY3JpYmVkYnk9e2Bwcm9maWxlLSR7a2V5fS1lcnJvcmB9IC8+fVxuICAgICAgPHAgaWQ9e2Bwcm9maWxlLSR7a2V5fS1lcnJvcmB9IGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e2Zvcm0uZm9ybVN0YXRlLmVycm9yc1trZXldPy5tZXNzYWdlfTwvcD5cbiAgICA8L2Rpdj4pfTwvZGl2PlxuICAgIHtzYXZlLmlzRXJyb3IgJiYgPHAgcm9sZT1cImFsZXJ0XCI+e2FwaUVycm9yTWVzc2FnZShzYXZlLmVycm9yKX08L3A+fVxuICAgIDxwIHJvbGU9XCJzdGF0dXNcIj57bm90aWNlfTwvcD5cbiAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17c2F2ZS5pc1BlbmRpbmd9PntzYXZlLmlzUGVuZGluZyA/ICdTYWx2YW5kb+KApicgOiAnU2FsdmFyIHBlcmZpbCd9PC9CdXR0b24+XG4gIDwvZm9ybT5cbn1cbmZ1bmN0aW9uIEF2YXRhckVkaXRvcih7IHByb2ZpbGUgfTogeyBwcm9maWxlOiBQcm9maWxlIH0pIHtcbiAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTsgY29uc3QgW25vdGljZSwgc2V0Tm90aWNlXSA9IHVzZVN0YXRlKCcnKTsgY29uc3QgW3JlYWRpbmcsIHNldFJlYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IHNhdmUgPSB1c2VTYXZlUHJvZmlsZSgnYXZhdGFyJylcbiAgYXN5bmMgZnVuY3Rpb24gY2hvb3NlKGZpbGU/OiBGaWxlKSB7XG4gICAgc2V0RXJyb3IoJycpOyBzZXROb3RpY2UoJycpOyBzZXRTZWxlY3RlZChudWxsKVxuICAgIGlmICghZmlsZSkgcmV0dXJuXG4gICAgaWYgKCFbJ2ltYWdlL3BuZycsICdpbWFnZS9qcGVnJywgJ2ltYWdlL3dlYnAnXS5pbmNsdWRlcyhmaWxlLnR5cGUpIHx8IGZpbGUuc2l6ZSA+IGF2YXRhck1heEJ5dGVzIHx8IGZpbGUuc2l6ZSA9PT0gMCkgeyBzZXRFcnJvcignVXNlIFBORywgSlBFRyBvdSBXZWJQIGRlIGF0w6kgMjU2IEtpQi4nKTsgcmV0dXJuIH1cbiAgICBzZXRSZWFkaW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBuZXcgUHJvbWlzZTxzdHJpbmc+KChyZXNvbHZlLCByZWplY3QpID0+IHsgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTsgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHJlc29sdmUoU3RyaW5nKHJlYWRlci5yZXN1bHQpKTsgcmVhZGVyLm9uZXJyb3IgPSByZWplY3Q7IHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpIH0pXG4gICAgICBzZXRTZWxlY3RlZChhdmF0YXJEYXRhU2NoZW1hLnBhcnNlKGRhdGEpKVxuICAgIH0gY2F0Y2ggeyBzZXRFcnJvcignTsOjbyBmb2kgcG9zc8OtdmVsIGxlciBhIGltYWdlbS4nKSB9IGZpbmFsbHkgeyBzZXRSZWFkaW5nKGZhbHNlKSB9XG4gIH1cbiAgZnVuY3Rpb24gc3VibWl0KGF2YXRhcjogc3RyaW5nIHwgbnVsbCkge1xuICAgIHNldEVycm9yKCcnKTsgc2V0Tm90aWNlKCcnKVxuICAgIHNhdmUubXV0YXRlKHsgYXZhdGFyLCB2ZXJzaW9uOiBwcm9maWxlLnZlcnNpb24gfSwgeyBvblN1Y2Nlc3M6ICgpID0+IHsgc2V0U2VsZWN0ZWQobnVsbCk7IHNldE5vdGljZShhdmF0YXIgPyAnQXZhdGFyIGF0dWFsaXphZG8uJyA6ICdBdmF0YXIgcmVtb3ZpZG8uJykgfSB9KVxuICB9XG4gIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJjb21tZXJjZS1wYW5lbCBzcGFjZS15LTRcIiBhcmlhLWxhYmVsbGVkYnk9XCJhdmF0YXItdGl0bGVcIj5cbiAgICA8aDIgaWQ9XCJhdmF0YXItdGl0bGVcIiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZFwiPkF2YXRhcjwvaDI+XG4gICAge3NlbGVjdGVkIHx8IHByb2ZpbGUuYXZhdGFyID8gPGltZyBjbGFzc05hbWU9XCJwcm9maWxlLWF2YXRhclwiIHNyYz17c2VsZWN0ZWQgPz8gcHJvZmlsZS5hdmF0YXIhfSB3aWR0aD17MTEyfSBoZWlnaHQ9ezExMn0gYWx0PXtzZWxlY3RlZCA/ICdQcsOpdmlhIGRvIGF2YXRhciBzZWxlY2lvbmFkbycgOiBgQXZhdGFyIGRlICR7cHJvZmlsZS5uYW1lfWB9IC8+IDogPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWF2YXRhciBwcm9maWxlLWF2YXRhci1lbXB0eVwiIHJvbGU9XCJpbWdcIiBhcmlhLWxhYmVsPVwiTmVuaHVtIGF2YXRhciBjYWRhc3RyYWRvXCI+e3Byb2ZpbGUubmFtZS5zbGljZSgwLCAxKS50b1VwcGVyQ2FzZSgpfTwvZGl2Pn1cbiAgICA8bGFiZWwgaHRtbEZvcj1cInByb2ZpbGUtYXZhdGFyXCI+SW1hZ2VtIGRvIGF2YXRhcjwvbGFiZWw+XG4gICAgPElucHV0IGlkPVwicHJvZmlsZS1hdmF0YXJcIiB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlL3BuZyxpbWFnZS9qcGVnLGltYWdlL3dlYnBcIiBhcmlhLWludmFsaWQ9eyEhZXJyb3J9IGFyaWEtZGVzY3JpYmVkYnk9XCJhdmF0YXItaGVscCBhdmF0YXItZXJyb3JcIiBkaXNhYmxlZD17cmVhZGluZyB8fCBzYXZlLmlzUGVuZGluZ30gb25DaGFuZ2U9e2V2ZW50ID0+IHZvaWQgY2hvb3NlKGV2ZW50LnRhcmdldC5maWxlcz8uWzBdKX0gLz5cbiAgICA8cCBpZD1cImF2YXRhci1oZWxwXCIgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5QTkcsIEpQRUcgb3UgV2ViUC4gQXTDqSAyNTYgS2lCIGUgNDA5NsOXNDA5NiBweC4gU1ZHIG7Do28gw6kgYWNlaXRvLjwvcD5cbiAgICA8cCBpZD1cImF2YXRhci1lcnJvclwiIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2Vycm9yIHx8IChzYXZlLmlzRXJyb3IgPyBhcGlFcnJvck1lc3NhZ2Uoc2F2ZS5lcnJvcikgOiAnJyl9PC9wPlxuICAgIDxwIHJvbGU9XCJzdGF0dXNcIj57cmVhZGluZyA/ICdMZW5kbyBpbWFnZW3igKYnIDogbm90aWNlfTwvcD5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0zXCI+PEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9eyFzZWxlY3RlZCB8fCBzYXZlLmlzUGVuZGluZyB8fCByZWFkaW5nfSBvbkNsaWNrPXsoKSA9PiBzdWJtaXQoc2VsZWN0ZWQpfT5TYWx2YXIgYXZhdGFyPC9CdXR0b24+PEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cIm91dGxpbmVcIiBkaXNhYmxlZD17IXByb2ZpbGUuYXZhdGFyIHx8IHNhdmUuaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBzdWJtaXQobnVsbCl9PlJlbW92ZXIgYXZhdGFyPC9CdXR0b24+PC9kaXY+XG4gIDwvc2VjdGlvbj5cbn1cbmZ1bmN0aW9uIFBhc3N3b3JkRWRpdG9yKCkge1xuICB0eXBlIFZhbHVlcyA9IHouaW5mZXI8dHlwZW9mIHBhc3N3b3JkRm9ybVNjaGVtYT5cbiAgY29uc3QgZm9ybSA9IHVzZUZvcm08VmFsdWVzPih7IHJlc29sdmVyOiB6b2RSZXNvbHZlcihwYXNzd29yZEZvcm1TY2hlbWEpLCBkZWZhdWx0VmFsdWVzOiB7IGN1cnJlbnRQYXNzd29yZDogJycsIG5ld1Bhc3N3b3JkOiAnJywgY29uZmlybVBhc3N3b3JkOiAnJyB9IH0pXG4gIGNvbnN0IGNoYW5nZSA9IHVzZUNoYW5nZVBhc3N3b3JkKCk7IGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpOyBjb25zdCBlcG9jaCA9IGlkZW50aXR5RXBvY2goKVxuICByZXR1cm4gPGZvcm0gY2xhc3NOYW1lPVwiY29tbWVyY2UtcGFuZWwgYXV0aC1mb3JtXCIgYXJpYS1sYWJlbD1cIkFsdGVyYXIgc2VuaGFcIiBub1ZhbGlkYXRlIG9uU3VibWl0PXtmb3JtLmhhbmRsZVN1Ym1pdCh2YWx1ZXMgPT4gY2hhbmdlLm11dGF0ZSh7IGN1cnJlbnRQYXNzd29yZDogdmFsdWVzLmN1cnJlbnRQYXNzd29yZCwgbmV3UGFzc3dvcmQ6IHZhbHVlcy5uZXdQYXNzd29yZCB9LCB7IG9uU3VjY2VzczogYXN5bmMgKCkgPT4ge1xuICAgIGlmIChlcG9jaCAhPT0gaWRlbnRpdHlFcG9jaCgpKSByZXR1cm5cbiAgICBmb3JtLnJlc2V0KCk7IGF3YWl0IGFkb3B0U2Vzc2lvbihudWxsLCBudWxsKTsgYXdhaXQgcm91dGVyLmludmFsaWRhdGUoKTsgYXdhaXQgcm91dGVyLm5hdmlnYXRlKHsgdG86ICcvbG9naW4nLCBzZWFyY2g6IHsgcmVkaXJlY3Q6ICcvcGVyZmlsJyB9LCByZXBsYWNlOiB0cnVlIH0pXG4gIH0sIG9uRXJyb3I6IGVycm9yID0+IHsgaWYgKGVycm9yIGluc3RhbmNlb2YgQXBpUmVxdWVzdEVycm9yICYmIGVycm9yLmZpZWxkcz8uY3VycmVudFBhc3N3b3JkKSBmb3JtLnNldEVycm9yKCdjdXJyZW50UGFzc3dvcmQnLCB7IG1lc3NhZ2U6IGVycm9yLmZpZWxkcy5jdXJyZW50UGFzc3dvcmRbMF0gfSkgfSB9KSl9PlxuICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZFwiPkFsdGVyYXIgc2VuaGE8L2gyPlxuICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+QXDDs3Mgc2FsdmFyLCB0b2RhcyBhcyBzZXNzw7VlcyBzZXLDo28gZW5jZXJyYWRhcy4gRW50cmUgbm92YW1lbnRlIGNvbSBhIG5vdmEgc2VuaGEuIFN1YSBjb2xlw6fDo28gZSBzZXVzIHBlZGlkb3Mgc2Vyw6NvIHByZXNlcnZhZG9zLjwvcD5cbiAgICB7KFsnY3VycmVudFBhc3N3b3JkJywgJ25ld1Bhc3N3b3JkJywgJ2NvbmZpcm1QYXNzd29yZCddIGFzIGNvbnN0KS5tYXAoa2V5ID0+IDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCIga2V5PXtrZXl9PlxuICAgICAgPGxhYmVsIGh0bWxGb3I9e2Bwcm9maWxlLSR7a2V5fWB9Pnt7IGN1cnJlbnRQYXNzd29yZDogJ1NlbmhhIGF0dWFsJywgbmV3UGFzc3dvcmQ6ICdOb3ZhIHNlbmhhJywgY29uZmlybVBhc3N3b3JkOiAnQ29uZmlybWFyIG5vdmEgc2VuaGEnIH1ba2V5XX08L2xhYmVsPlxuICAgICAgPElucHV0IGlkPXtgcHJvZmlsZS0ke2tleX1gfSB0eXBlPVwicGFzc3dvcmRcIiBhdXRvQ29tcGxldGU9e2tleSA9PT0gJ2N1cnJlbnRQYXNzd29yZCcgPyAnY3VycmVudC1wYXNzd29yZCcgOiAnbmV3LXBhc3N3b3JkJ30gey4uLmZvcm0ucmVnaXN0ZXIoa2V5KX0gYXJpYS1pbnZhbGlkPXshIWZvcm0uZm9ybVN0YXRlLmVycm9yc1trZXldfSBhcmlhLWRlc2NyaWJlZGJ5PXtgJHtrZXl9LWVycm9yYH0gLz5cbiAgICAgIDxwIGlkPXtgJHtrZXl9LWVycm9yYH0gY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57Zm9ybS5mb3JtU3RhdGUuZXJyb3JzW2tleV0/Lm1lc3NhZ2V9PC9wPlxuICAgIDwvZGl2Pil9XG4gICAge2NoYW5nZS5pc0Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiPnthcGlFcnJvck1lc3NhZ2UoY2hhbmdlLmVycm9yKX08L3A+fVxuICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtjaGFuZ2UuaXNQZW5kaW5nfT57Y2hhbmdlLmlzUGVuZGluZyA/ICdBbHRlcmFuZG/igKYnIDogJ0FsdGVyYXIgc2VuaGEgZSBzYWlyJ308L0J1dHRvbj5cbiAgPC9mb3JtPlxufVxuZXhwb3J0IGZ1bmN0aW9uIFByb2ZpbGVQYWdlKCkge1xuICBjb25zdCBwcm9maWxlID0gdXNlUHJvZmlsZSgpXG4gIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj48ZGl2PjxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGRcIj5QZXJmaWw8L2gxPjxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U3VhIGlkZW50aWRhZGUgZGUgY29sZWNpb25hZG9yIG5hIEt1cmlvLjwvcD48L2Rpdj5cbiAgICB7cHJvZmlsZS5pc1BlbmRpbmcgPyA8TG9hZGluZ1N0YXRlIGxhYmVsPVwiQ2FycmVnYW5kbyBwZXJmaWzigKZcIiAvPiA6IHByb2ZpbGUuaXNFcnJvciA/IDxFcnJvclN0YXRlIG1lc3NhZ2U9e2FwaUVycm9yTWVzc2FnZShwcm9maWxlLmVycm9yKX0gcmV0cnk9eygpID0+IHZvaWQgcHJvZmlsZS5yZWZldGNoKCl9IC8+IDogPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWxheW91dFwiIGtleT17cHJvZmlsZS5kYXRhLmlkfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+PFByb2ZpbGVFZGl0b3IgcHJvZmlsZT17cHJvZmlsZS5kYXRhfSAvPjxQYXNzd29yZEVkaXRvciAvPjwvZGl2Pjxhc2lkZSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj48QXZhdGFyRWRpdG9yIHByb2ZpbGU9e3Byb2ZpbGUuZGF0YX0gLz48TGluayB0bz1cIi9jYXJ0ZWlyYXNcIiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgdW5kZXJsaW5lXCI+R2VyZW5jaWFyIGNhcnRlaXJhczwvTGluaz48L2FzaWRlPlxuICAgIDwvZGl2Pn1cbiAgPC9zZWN0aW9uPlxufVxuIl19